﻿// <copyright file="AutoMapperTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Configurations
{
   using System.Collections.Generic;
   using System.Linq;
   using AutoMapper;
   using JobScoringService.Configurations.AutoMapperConfiguration;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ViewModels;
   using JobScoringService.Test.Common;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public class AutoMapperTest
   {

      private readonly IMapper mapperUnderTest;

      public AutoMapperTest()
      {
         this.mapperUnderTest = new MapperConfiguration(cfg => { cfg.AddProfile<AutoMapperProfile>(); })
            .CreateMapper();
      }

      [Fact]
      public void Map_FromJobGraderResponseLineItemToRollupRow_MapsAllProperties()
      {
         JobGraderResponseLineItem fromItem = new JobGraderResponseLineItem()
         {
            ProductCode = "hiThere",
            EnteredDollarAmount = 1,
            TraneNetDollars = 2,
            UnadjustedListPrice = 3,
            VariationPrice = 4
         };

         RollupRow toItem = this.mapperUnderTest.Map<RollupRow>(fromItem);

         Assert.Equal(fromItem.ProductCode, toItem.ProductCode);
         Assert.Equal(fromItem.ProductCode, toItem.ProductCodeTrimmed);
         Assert.Equal(fromItem.EnteredDollarAmount, toItem.EnteredDollarAmount);
         Assert.Equal(fromItem.TraneNetDollars, toItem.TraneNetDollars);
         Assert.Equal(fromItem.UnadjustedListPrice, toItem.UnadjustedListPrice);
         Assert.Equal(fromItem.VariationPrice, toItem.VariationPrice);
      }

      [Fact]
      public void Map_FromEnumerableJobGraderResponseLineItemToEnumerableRollupRow_MapsCollections()
      {
         IEnumerable<JobGraderResponseLineItem> fromItems = new JobGraderResponseLineItem[]
         {
            new JobGraderResponseLineItem ()
            {
               ProductCode = "hiThere",
               EnteredDollarAmount = 1,
               TraneNetDollars = 2,
               UnadjustedListPrice = 3,
               VariationPrice = 4
            }
         };

         IEnumerable<RollupRow> toItems = this.mapperUnderTest.Map<IEnumerable<RollupRow>>(fromItems);

         Assert.Single(toItems);
         Assert.Equal(fromItems.First().ProductCode, toItems.First().ProductCode);
      }

      [Fact]
      public void Map_FromJobAggregatedGradeToJobAggregatedGradeViewModel_ReturnsMappedViewModel()
      {
         // Arrange
         JobAggregatedGrade jobAggregatedGrade = CommonHelper.GetJobAggregatedGradeModel();

         // Act
         JobAggregatedGradeViewModel jobAggregatedGradeView = this.mapperUnderTest.Map<JobAggregatedGradeViewModel>(jobAggregatedGrade);

         // Assert
         Assert.Equal(jobAggregatedGrade.LETTER_SCORE, jobAggregatedGradeView.LetterScore);
         Assert.Equal(jobAggregatedGrade.CREATED_DATE, jobAggregatedGradeView.CreatedDate);
         Assert.Equal(jobAggregatedGrade.BID_ALTERNATE_ID, jobAggregatedGradeView.BidAlternateId);
         Assert.Equal(jobAggregatedGradeView.ExcludedFromTopper, jobAggregatedGradeView.ExcludedFromTopper);
      }
   }
}
