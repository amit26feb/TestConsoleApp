﻿// <copyright file="CommonHelper.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Common
{
   using System;
   using System.Collections.Generic;
   using DataAccess.Paging;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ViewModels;
   using TSMT.DataAccess;

   /// <summary>
   /// Helper class to include methods which can be used throughout test methods
   /// </summary>
   public static class CommonHelper
   {
      public static JobSizeModel GetJobSize()
      {
         return new JobSizeModel
         {
            JobSize = "$10K - $20K",
            FromAmount = 10000.0m,
            ToAmount = 20000.0m
         };
      }

      public static JobScoreQuintile GetJobScoreQuintile()
      {
         return new JobScoreQuintile
         {
            JobSize = "$30K - $50K",
            ProductCode = "0018",
            Location = "A0",
            InfoJobCount = 5,
            InfoGeography = "National",
            InfoJobSize = "All Jobs",
            StartB = 0.483m,
            StartC = 0.442m,
            StartD = 0.432m,
            StartE = 0.425m
         };
      }

      public static JobScoreQuintile GetJobScoreQuintileForCutOffDisplay()
      {
         return new JobScoreQuintile
         {
            JobSize = "$0K - $10K",
            ProductCode = "0021",
            Location = "A0",
            InfoJobCount = 5,
            InfoGeography = "National",
            InfoJobSize = "All Jobs",
            StartB = 0.543m,
            StartC = 0.483m,
            StartD = 0.723m,
            StartE = 0.328m
         };
      }

      public static JobGraderRequest GetJobGraderRequest()
      {
         List<JobGraderRequestLineItem> jobLineItems = new List<JobGraderRequestLineItem>()
         {
            new JobGraderRequestLineItem()
            {
               Product = "Pckaged Terminal Air Condition",
               ProductCode = "0061",
               UnitQuantity = 1,
               QuantityLPAF = 1,
               QuantityShipLPAF = 1,
               UnadjustedListPrice = 1931,
               AdjustedListPrice = 1790.037m,
               EnteredCPLPAF = 0.927m,
               EnteredMultiplier = 0.4106060371m,
               EnteredDollarAmount = 734.9999988323727m,
               TraneNetDollars = 0,
               VariationPrice = 0,
               FapDollars = 749.228m
            },
            new JobGraderRequestLineItem()
            {
               Product = "Mini-Split P-Series",
               ProductCode = "0045",
               UnitQuantity = 1,
               QuantityLPAF = 1.23m,
               QuantityShipLPAF = 1,
               UnadjustedListPrice = 1942.56m,
               AdjustedListPrice = 1670.037m,
               EnteredCPLPAF = 0.675m,
               EnteredMultiplier = 0.439287192m,
               EnteredDollarAmount = 815.32638294926237m,
               TraneNetDollars = 0,
               VariationPrice = 0,
               FapDollars = 749.228m
            }
         };
         return new JobGraderRequest
         {
            Job = "JAV ME Teachey - Sysco Project",
            Bid = "Base Bid",
            SalesOffice = "Greenville Main Office",
            SalesPerson = "Paul Jensen[D04]",
            JobClassCode = "**********",
            JobLocation = "Greenville Main Office",
            Currency = "$USD",
            StrategicJobType = "2",
            SalesOfficeCode = "F5",
            JobLineItems = jobLineItems
         };
      }

      public static JobGraderRequest GetJobGraderRequestForEmptyQuintile()
      {
         List<JobGraderRequestLineItem> jobLineItems = new List<JobGraderRequestLineItem>()
         {
            new JobGraderRequestLineItem()
            {
               Product = "Algoma High School CUH Copy",
               ProductCode = "0046",
               UnitQuantity = 0,
               QuantityLPAF = 0m,
               QuantityShipLPAF = 0,
               UnadjustedListPrice = 0.1m,
               AdjustedListPrice = 0m,
               EnteredCPLPAF = 0m,
               EnteredMultiplier = 0m,
               EnteredDollarAmount = 12567.123m,
               TraneNetDollars = 0,
               VariationPrice = 0,
               FapDollars = 0m
            }
         };
         return new JobGraderRequest
         {
            Job = "Algoma High School CUH",
            Bid = "Base Bid",
            SalesOffice = "Madison Main Office",
            SalesPerson = "Paul Jensen[D04]",
            JobClassCode = "**********",
            JobLocation = "Madison Main Office",
            Currency = "$USD",
            StrategicJobType = "2",
            SalesOfficeCode = "F5",
            JobLineItems = jobLineItems
         };
      }

      public static JobGraderResponse GetJobGraderResponse()
      {
         List<JobGraderResponseLineItem> jobLineItemsResponse = new List<JobGraderResponseLineItem>()
         {
            new JobGraderResponseLineItem()
            {
               Product = "Central Station AHU",
               ProductCode = "0050",
               UnitQuantity = 1,
               QuantityLPAF = 1.0m,
               QuantityShipLPAF = 1.0m,
               UnadjustedListPrice = 25717.02m,
               AdjustedListPrice = 25717.02m,
               EnteredCPLPAF = 1.0m,
               EnteredMultiplier = 0.47m,
               EnteredDollarAmount = 12087.0m,
               ObjectStatus = "Working",
               EquipmentLine = "true",
               RatedMultiplierAltDisplay = "0.47/1.0",
               RatedLocation = "UPPER MIDWEST",
               RatedJobSize = "$50K - $100K",
               CutoffAltDisplayGrade1 = "0.418/1.0",
               CutoffAltDisplayGrade2 = "0.38/1.0",
               CutoffAltDisplayGrade3 = "0.367/1.0",
               CutoffAltDisplayGrade4 = "0.358/0.93",
               LetterScore = "A",
               TraneNetDollars = 0.0m,
               VariationPrice = 0.0m,
               FapDollars = 0.0m,
               RatedCutoffGrade1 = 0.418m,
               RatedCutoffGrade2 = 0.38m,
               RatedCutoffGrade3 = 0.367m,
               RatedCutoffGrade4 = 0.333m,
               RatedMultiplier = 0.47m
            }
         };
         return new JobGraderResponse
         {
            Job = "Borg - Warner Life Test",
            Bid = "Base Bid",
            SalesOffice = "Madison Main Office",
            SalesPerson = "Alex Bakel [C29]",
            JobClassCode = "**********",
            JobLocation = "Madison Main Office",
            Currency = "$USD",
            TotalEquipmentRevenue = 64588.86m,
            ObjectStatus = "Working",
            RatedMultiplierAltDisplay = "127.972/1.0",
            CutoffAltDisplayGrade1 = "243.769/1.0",
            CutoffAltDisplayGrade2 = "195.947/1.0",
            CutoffAltDisplayGrade3 = "131.69/1.0",
            CutoffAltDisplayGrade4 = "99.767/1.0",
            StepDownCutoffAltDisplayGrade1 = "243.768/1.0",
            StepDownCutoffAltDisplayGrade2 = "195.946/1.0",
            StepDownCutoffAltDisplayGrade3 = "131.689/1.0",
            StepDownCutoffAltDisplayGrade4 = "99.766/1.0",
            LetterScore = "D",
            EnteredABDollarNextScore = 401.47m,
            EnteredBCDollarNextScore = 235.67m,
            EnteredCDDollarNextScore = 12.89m,
            EnteredDEDollarNextScore = -97.79m,
            EnteredABDollarStepDownScore = 401.47m,
            EnteredBCDollarStepDownScore = 235.67m,
            EnteredCDDollarStepDownScore = 12.89m,
            EnteredDEDollarStepDownScore = -97.79m,
            StepDownRatedCutoffGrade1 = 243.768m,
            StepDownRatedCutoffGrade2 = 195.946m,
            StepDownRatedCutoffGrade3 = 131.689m,
            StepDownRatedCutoffGrade4 = 99.766m,
            RatedCutoffGrade1 = 243.769m,
            RatedCutoffGrade2 = 195.947m,
            RatedCutoffGrade3 = 131.690m,
            RatedCutoffGrade4 = 99.767m,
            RatedMultiplier = 127.972m,
            DisplayABDollarAmount = 401.47m,
            DisplayBCDollarAmount = 235.67m,
            DisplayCDDollarAmount = 12.89m,
            DisplayDEDollarAmount = -97.79m,
            JobLineItems = jobLineItemsResponse.ToArray()
         };
      }

      public static JobScoreTotal GetJobScoreTotal()
      {
         return new JobScoreTotal
         {
            TotalQtyLPAFAndQtyShipLPAF = 3.467m,
            TotaJobSizeDollar = 3.356m,
            TotalEnteredDollar = 5.678m,
            TotalABBreakPointDollar = 845.145m,
            TotalBCBreakPointDollar = 679.3453m,
            TotalCDBreakPointDollar = 456.567m,
            TotalDEBreakPointDollar = 345.890m,
            TotalValidProductEnteredDollar = 443.678m
         };
      }

      /// <summary>
      /// Method to get product code filter
      /// </summary>
      /// <returns>Product code filter view model</returns>
      public static ProductCodeFilterViewModel GetProductCodeFilter()
      {
         ProductCodeFilterViewModel productCodeFilterView = new ProductCodeFilterViewModel();
         List<Filter> filters = new List<Filter>
         {
            new Filter() { Field = "prodCode", Operator = "Eq", Value = "1350" },
            new Filter() { Field = "prodCode", Operator = "Eq", Value = "1274" }
         };

         productCodeFilterView.Filters = new List<FilterCollection>
         {
            new FilterCollection() { Filters = filters, Logic = "or" },
         };

         return productCodeFilterView;
      }

      /// <summary>
      /// Gets product codes
      /// </summary>
      /// <returns>Product codes</returns>
      public static IEnumerable<ProductCodeViewModel> GetProductCodes()
      {
         return new List<ProductCodeViewModel>
         {
            new ProductCodeViewModel()
            {
               ProdCode = "751",
               Description = "Natl Accts - Sterling Jewelers",
               ProdCodeType = "VFAC",
               Status = "C"
            },
            new ProductCodeViewModel()
            {
               ProdCode = "752",
               Description = "Walgreen Drug National Acct",
               ProdCodeType = "VFAC",
               Status = "C"
            }
         };
      }

      /// <summary>
      /// Get obsolete product codes
      /// </summary>
      /// <returns>Obsolete product codes</returns>
      public static IEnumerable<ProductCodeViewModel> GetObsoleteProductCodes()
      {
         return new List<ProductCodeViewModel>
         {
            new ProductCodeViewModel()
            {
               ProdCode = "0061",
               Description = "Natl Accts - Sterling Jewelers",
               ProdCodeType = "VFAC",
               Status = "O"
            },
            new ProductCodeViewModel()
            {
               ProdCode = "0045",
               Description = "Low Pressure Recovery Unit",
               ProdCodeType = "VFAC",
               Status = "O"
            }
         };
      }

      public static JobGraderRequest GetJobGraderRequestWithExcludedProdCode()
      {
         List<JobGraderRequestLineItem> jobLineItems = new List<JobGraderRequestLineItem>()
         {
            new JobGraderRequestLineItem()
            {
               Product = "CO2 sensors and relay",
               ProductCode = "0019",
               UnitQuantity = 1,
               QuantityLPAF = 1,
               QuantityShipLPAF = 1,
               UnadjustedListPrice = 676,
               AdjustedListPrice = 1710.037m,
               EnteredCPLPAF = 0.927m,
               EnteredMultiplier = 0.41076871m,
               EnteredDollarAmount = 734.9727m,
               TraneNetDollars = 0,
               VariationPrice = 0,
               FapDollars = 8789.228m
            }
         };
         return new JobGraderRequest
         {
            Job = "Carter G. Woodson Elementary",
            Bid = "Test Bid",
            SalesOffice = "Madison Main Office",
            SalesPerson = "Paul Jensen[D04]",
            JobClassCode = "**********",
            JobLocation = "Madison Main Office",
            Currency = "$USD",
            StrategicJobType = "2",
            SalesOfficeCode = "F5",
            JobLineItems = jobLineItems
         };
      }

      public static JobGraderResponse GetJobGraderResponseForLetterScoreA()
      {
         return new JobGraderResponse
         {
            LetterScore = "A",
            DisplayABDollarAmount = -154.63m,
            DisplayBCDollarAmount = -4639.94m,
            DisplayCDDollarAmount = -7423.93m,
            DisplayDEDollarAmount = -10517.25m,
            EnteredABDollarNextScore = 0.04m,
            EnteredBCDollarNextScore = -4485.27m,
            EnteredCDDollarNextScore = -7269.26m,
            EnteredDEDollarNextScore = -10362.58m,
            EnteredABDollarStepDownScore = -154.63m,
            EnteredBCDollarStepDownScore = -4639.94m,
            EnteredCDDollarStepDownScore = -7423.93m,
            EnteredDEDollarStepDownScore = -10517.25m,
         };
      }

      public static JobGraderResponse GetJobGraderResponseForLetterScoreB()
      {
         return new JobGraderResponse
         {
            LetterScore = "B",
            DisplayABDollarAmount = 4485.29m,
            DisplayBCDollarAmount = -154.69m,
            DisplayCDDollarAmount = -2938.68m,
            DisplayDEDollarAmount = -6032m,
            EnteredABDollarNextScore = 4485.29m,
            EnteredBCDollarNextScore = -0.02m,
            EnteredCDDollarNextScore = -2784.01m,
            EnteredDEDollarNextScore = -5877.33m,
            EnteredABDollarStepDownScore = 4330.62m,
            EnteredBCDollarStepDownScore = -154.69m,
            EnteredCDDollarStepDownScore = -2938.68m,
            EnteredDEDollarStepDownScore = -6032m,
         };
      }

      public static JobGraderResponse GetJobGraderResponseForLetterScoreC()
      {
         return new JobGraderResponse
         {
            LetterScore = "C",
            DisplayABDollarAmount = 4640m,
            DisplayBCDollarAmount = 154.69m,
            DisplayCDDollarAmount = -2783.97m,
            DisplayDEDollarAmount = -5877.29m,
            EnteredABDollarNextScore = 4640m,
            EnteredBCDollarNextScore = 154.69m,
            EnteredCDDollarNextScore = -2629.3m,
            EnteredDEDollarNextScore = -5722.62m,
            EnteredABDollarStepDownScore = 4485.33m,
            EnteredBCDollarStepDownScore = 0.02m,
            EnteredCDDollarStepDownScore = -2783.97m,
            EnteredDEDollarStepDownScore = -5877.29m,
         };
      }

      public static JobGraderResponse GetJobGraderResponseForLetterScoreE()
      {
         return new JobGraderResponse
         {
            LetterScore = "E",
            DisplayABDollarAmount = 58290.62m,
            DisplayBCDollarAmount = 54578.64m,
            DisplayCDDollarAmount = 51175.99m,
            DisplayDEDollarAmount = 47618.67m,
            EnteredABDollarNextScore = 58290.62m,
            EnteredBCDollarNextScore = 54578.64m,
            EnteredCDDollarNextScore = 51175.99m,
            EnteredDEDollarNextScore = 47618.67m,
            EnteredABDollarStepDownScore = 58135.96m,
            EnteredBCDollarStepDownScore = 54423.97m,
            EnteredCDDollarStepDownScore = 51021.32m,
            EnteredDEDollarStepDownScore = 47464m,
         };
      }

      /// <summary>
      /// Get job aggregated grade model
      /// </summary>
      /// <returns>Job aggregated grade model</returns>
      public static JobAggregatedGrade GetJobAggregatedGradeModel()
      {
         return CommonHelper.GetAggregatedGrade("A", DateTime.Parse("2020-09-30"), 1234, 2);
      }

      /// <summary>
      /// Get job aggregated grade model
      /// </summary>
      /// <param name="letterScore">Letter score</param>
      /// <param name="createdDate">Created date</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="jobScoreId">Job score id</param>
      /// <returns>Job aggregated grade model</returns>
      public static JobAggregatedGrade GetAggregatedGrade(string letterScore, DateTime createdDate, int bidAlternateId, int jobScoreId)
      {
         return new JobAggregatedGrade()
         {
            LETTER_SCORE = letterScore,
            CREATED_DATE = createdDate,
            BID_ALTERNATE_ID = bidAlternateId,
            JOB_SCORE_ID = jobScoreId,
            EXCLUDED_FROM_TOPPER = "Y",
         };
      }

      /// <summary>
      /// Get job aggregated grade view model
      /// </summary>
      /// <returns>Job aggregated grade view model</returns>
      public static JobAggregatedGradeViewModel GetJobAggregatedGradeViewModel()
      {
         return CommonHelper.GetJobAggregatedGradeViewModel("A", DateTime.Parse("2020-09-30"), 1234);
      }

      /// <summary>
      /// Get job aggregated grade view model
      /// </summary>
      /// <param name="letterScore">Letter score</param>
      /// <param name="createdDate">Created date</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Job aggregated grade view model</returns>
      public static JobAggregatedGradeViewModel GetJobAggregatedGradeViewModel(string letterScore, DateTime createdDate, int bidAlternateId)
      {
         return new JobAggregatedGradeViewModel
         {
            LetterScore = letterScore,
            CreatedDate = createdDate,
            BidAlternateId = bidAlternateId,
            ExcludedFromTopper = "A",
         };
      }
   }
}
