﻿// <copyright file="JobScoringServiceDomainExceptionTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Common.Exceptions
{
   using System;
   using JobScoringService.Common.Exceptions;
   using Xunit;

   /// <summary>
   /// JobScoringService Domain Exception Test
   /// </summary>
   public class JobScoringServiceDomainExceptionTest
   {
      /// <summary>
      /// Ensures basic constructor leads to a canned error message in the domain exception message
      /// </summary>
      [Fact]
      public void DomainException_BasicConstructor_DoesNotAutomaticallyDefineMessage()
      {
         // Act
         JobScoringServiceDomainException domainException = new JobScoringServiceDomainException();

         // Assert
         Assert.NotNull(domainException.Message);
      }

      /// <summary>
      /// Ensures constructor override with message has the message retained as the domain exception message
      /// </summary>
      [Fact]
      public void DomainException_ConstructorWithMessage__PreservesErrorAttributes()
      {
         // Setup
         string errorMessage = "error text";

         // Act
         JobScoringServiceDomainException domainException = new JobScoringServiceDomainException(errorMessage);

         // Assert
         Assert.Equal(domainException.Message, errorMessage);
      }

      /// <summary>
      /// Ensures constructor override with message and inner exception has these retained as domain exception attributes
      /// </summary>
      [Fact]
      public void DomainException_ConstructorWithMessageAndException__PreservesErrorAttributes()
      {
         // Setup
         string errorMessage = "error text";
         Exception ex = new Exception();

         // Act
         JobScoringServiceDomainException domainException = new JobScoringServiceDomainException(errorMessage, ex);

         // Assert
         Assert.Equal(domainException.Message, errorMessage);
         Assert.Equal(domainException.InnerException, ex);
      }
   }
}
