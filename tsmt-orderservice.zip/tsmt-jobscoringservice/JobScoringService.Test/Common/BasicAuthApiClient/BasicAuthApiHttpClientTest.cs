﻿// <copyright file="BasicAuthApiHttpClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Common.BasicAuthApiClient
{
   using System;
   using System.Net;
   using System.Net.Http.Headers;
   using System.Text;
   using JobScoringService.Common.BasicAuthApiClient;
   using Xunit;

   /// <summary>
   /// BasicAuthApiHttpClient Test
   /// </summary>
   public class BasicAuthApiHttpClientTest
   {
      [Fact]
      public void BasicAuthApiHttpClient_BeforeSetBasicAuthParameters_HasNoAuthorizationSetUp()
      {
         // Setup
         BasicAuthApiHttpClient clientUnderTest = new BasicAuthApiHttpClient();

         // Act
         AuthenticationHeaderValue authHeaderValue = clientUnderTest.DefaultRequestHeaders.Authorization;

         // Assert
         Assert.Null(authHeaderValue);
      }

      [Fact]
      public void SetBasicAuthParameters_SetsAuthorizationRequestHeader()
      {
         // Setup
         string username = "someusername";
         string password = "somepassword";
         BasicAuthApiHttpClient clientUnderTest = new BasicAuthApiHttpClient();

         // Act
         clientUnderTest.SetBasicAuthParameters(username, password);
         AuthenticationHeaderValue authHeaderValue = clientUnderTest.DefaultRequestHeaders.Authorization;

         // Assert
         Assert.NotNull(authHeaderValue);
         Assert.Equal(AuthenticationSchemes.Basic.ToString(), authHeaderValue.Scheme);
         Assert.Equal(Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}")), authHeaderValue.Parameter);
      }
   }
}
