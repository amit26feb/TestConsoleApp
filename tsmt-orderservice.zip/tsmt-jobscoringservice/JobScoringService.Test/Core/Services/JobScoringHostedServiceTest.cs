// <copyright file="JobScoringHostedServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Threading.Tasks;
   using Amazon.S3.Model;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using S3Wrapper;
   using Xunit;

   /// <summary>
   /// Provides the methods to verify the business logic in SQS queue
   /// </summary>
   public class JobScoringHostedServiceTest
   {
      private readonly JobScoringHostedService hostedService;

      private readonly Mock<ILogger<JobScoringHostedService>> logger;
      private readonly Mock<IServiceProvider> serviceProvider;
      private readonly Mock<IJobScoringProcessService> jobScoreProcessService;
      private readonly Mock<IS3Repository> s3Repository;
      private readonly Mock<IJobScoreCalculatorService> jobScoreCalculatorService;
      private readonly Mock<IJobGraderRequestBuilder> jobGraderBuilder;

      private readonly int drAddressId = 20;
      private readonly int jobId = 111;
      private readonly int hqtrCreditJobId = 2222;
      private readonly int bidAlternateId = 3344;
      private readonly string signature = "someSignature";
      private readonly string exemptSpaNumbersCsvData =
         "SPA Number,Description\n" +
         "12-1234,Pizza Hut\n" +
         "21-4321,Pepsi\n";

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoringHostedServiceTest"/> class.
      /// </summary>
      public JobScoringHostedServiceTest()
      {
         this.logger = new Mock<ILogger<JobScoringHostedService>>();
         this.serviceProvider = new Mock<IServiceProvider>();
         this.s3Repository = new Mock<IS3Repository>();
         this.jobScoreCalculatorService = new Mock<IJobScoreCalculatorService>();
         this.jobGraderBuilder = new Mock<IJobGraderRequestBuilder>();
         this.jobScoreProcessService = new Mock<IJobScoringProcessService>();

         Settings settings = new Settings() { IHostingServiceTimeIntervalInSeconds = 10, ScoringExemptSpaNumberBucket = "kirbyBuckets", ScoringExemptSpaNumberCsvFilename = "funky.csv", MaxRetryAttempts = 5 };
         Mock<IOptions<Settings>> jobScoringSettings = new Mock<IOptions<Settings>>();
         jobScoringSettings.Setup(ap => ap.Value).Returns(settings);

         this.hostedService = new JobScoringHostedService(
            this.logger.Object,
            jobScoringSettings.Object,
            this.serviceProvider.Object,
            this.s3Repository.Object,
            this.jobGraderBuilder.Object,
            this.jobScoreProcessService.Object,
            this.jobScoreCalculatorService.Object);
      }

      /// <summary>
      /// Verify for concurrent process completion.
      /// </summary>
      [Fact]
      public void ConcurrentProcess_Execute()
      {
         // Arrange
         object obj = new object();

         Mock<IServiceScope> serviceScope = new Mock<IServiceScope>();
         serviceScope.Setup(x => x.ServiceProvider).Returns(this.serviceProvider.Object);

         Mock<IServiceScopeFactory> serviceScopeFactory = new Mock<IServiceScopeFactory>();
         serviceScopeFactory.Setup(x => x.CreateScope()).Returns(serviceScope.Object);
         this.serviceProvider.Setup(x => x.GetService(typeof(IServiceScopeFactory))).Returns(serviceScopeFactory.Object);

         MemoryStream stream = new MemoryStream();
         StreamWriter writer = new StreamWriter(stream);
         writer.Write(this.exemptSpaNumbersCsvData);
         writer.Flush();
         stream.Seek(0, SeekOrigin.Begin);
         GetObjectResponse response = new GetObjectResponse() { ResponseStream = stream };
         response.Metadata.Add("signature", this.signature);
         this.s3Repository.Setup(m => m.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(response));

         this.jobScoreProcessService.Setup(x => x.GetJobsToGrade(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(Enumerable.Empty<CreditJob>()));

         // Act
         Task result = Task.Run(() => this.hostedService.ConcurrentProcess(obj));
         result.Wait();

         // Assert
         Assert.True(result.IsCompleted);
      }

      /// <summary>
      /// Verify grade process completion for successful grading.
      /// </summary>
      [Fact]
      public void GradeJobs_GradeSuccess_RecordsGrade()
      {
         // Arrange
         HashSet<string> spaNumbersExemptFromScoring = new HashSet<string>();  // No SPA numbers are exempt from scoring.
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>()
         {
            new CreditJob()
            {
               DrAddressId = this.drAddressId,
               JobId = this.jobId,
               HqtrCreditJobId = this.hqtrCreditJobId,
               BidAlternateId = this.bidAlternateId,
            }
         };

         this.jobScoreProcessService.Setup(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));

         JobGraderRequest gradeRequest = new JobGraderRequest();
         this.jobGraderBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(gradeRequest));

         JobGraderResponse gradeResponse = new JobGraderResponse() { LetterScore = "X" };
         this.jobScoreCalculatorService.Setup(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()))
            .Returns(Task.FromResult(gradeResponse));

         this.jobScoreProcessService.Setup(x => x.RecordGrade(It.IsAny<CreditJobScoreProcessViewModel>())).Returns(Task.CompletedTask);

         // Act
         Task result = Task.Run(() => this.hostedService.GradeJobs(creditJobs, spaNumbersExemptFromScoring));
         result.Wait();

         // Assert
         this.jobScoreCalculatorService.Verify(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()), Times.Once);
         this.jobGraderBuilder.Verify(x => x.BuildJobGraderRequest(this.drAddressId, this.jobId, this.bidAlternateId, true), Times.Once);
         this.jobScoreProcessService.Verify(x => x.MarkAsProcessed(this.hqtrCreditJobId, 0), Times.Once);
         this.jobScoreProcessService.Verify(x => x.RecordGrade(It.Is<CreditJobScoreProcessViewModel>(x => x.ExcludedFromTopper == false && x.LetterScore == "X")), Times.Once);
      }

      /// <summary>
      /// Verify grade process increments retry count.
      /// </summary>
      [Fact]
      public void GradeJobs_UpdateRetryCount_IfPreviouslyProcessed()
      {
         // Arrange
         HashSet<string> spaNumbersExemptFromScoring = new HashSet<string>();  // No SPA numbers are exempt from scoring.
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>()
         {
            new CreditJob()
            {
               DrAddressId = this.drAddressId,
               JobId = this.jobId,
               HqtrCreditJobId = this.hqtrCreditJobId,
               BidAlternateId = this.bidAlternateId,
               ProcessDate = DateTime.Now,
            }
         };

         this.jobScoreProcessService.Setup(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));

         JobGraderRequest gradeRequest = new JobGraderRequest();
         this.jobGraderBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(gradeRequest));

         JobGraderResponse gradeResponse = new JobGraderResponse() { LetterScore = "X" };
         this.jobScoreCalculatorService.Setup(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()))
            .Returns(Task.FromResult(gradeResponse));

         this.jobScoreProcessService.Setup(x => x.RecordGrade(It.IsAny<CreditJobScoreProcessViewModel>())).Returns(Task.CompletedTask);

         // Act
         Task result = Task.Run(() => this.hostedService.GradeJobs(creditJobs, spaNumbersExemptFromScoring));
         result.Wait();

         // Assert
         this.jobScoreCalculatorService.Verify(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()), Times.Once);
         this.jobGraderBuilder.Verify(x => x.BuildJobGraderRequest(this.drAddressId, this.jobId, this.bidAlternateId, true), Times.Once);
         this.jobScoreProcessService.Verify(x => x.MarkAsProcessed(this.hqtrCreditJobId, 1), Times.Once);
         this.jobScoreProcessService.Verify(x => x.RecordGrade(It.Is<CreditJobScoreProcessViewModel>(x => x.ExcludedFromTopper == false && x.LetterScore == "X")), Times.Once);
      }

      /// <summary>
      /// Verify grade process completion for successful grading, when credit job to be graded has an exempt SPA number then ExcludedFromTopper should be "Y".
      /// </summary>
      [Fact]
      public void GradeJobs_ExemptSpaNumber_ReceivesExcludedFromTopper()
      {
         // Arrange
         string exemptSpaNumber = "12-1234";
         HashSet<string> spaNumbersExemptFromScoring = new HashSet<string>() { exemptSpaNumber };
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>()
         {
            new CreditJob()
            {
               DrAddressId = this.drAddressId,
               JobId = this.jobId,
               HqtrCreditJobId = this.hqtrCreditJobId,
               BidAlternateId = this.bidAlternateId,
               SpaNumber = exemptSpaNumber,
            }
         };
         JobGraderRequest gradeRequest = new JobGraderRequest();
         this.jobGraderBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(gradeRequest));

         JobGraderResponse gradeResponse = new JobGraderResponse() { LetterScore = "X" };
         this.jobScoreCalculatorService.Setup(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()))
            .Returns(Task.FromResult(gradeResponse));

         this.jobScoreProcessService.Setup(x => x.RecordGrade(It.IsAny<CreditJobScoreProcessViewModel>())).Returns(Task.CompletedTask);
         this.jobScoreProcessService.Setup(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));

         // Act
         Task result = Task.Run(() => this.hostedService.GradeJobs(creditJobs, spaNumbersExemptFromScoring));
         result.Wait();

         // Assert
         this.jobScoreCalculatorService.Verify(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()), Times.Once);
         this.jobGraderBuilder.Verify(x => x.BuildJobGraderRequest(this.drAddressId, this.jobId, this.bidAlternateId, true), Times.Once);
         this.jobScoreProcessService.Verify(x => x.MarkAsProcessed(this.hqtrCreditJobId, 0), Times.Once);
         this.jobScoreProcessService.Verify(x => x.RecordGrade(It.Is<CreditJobScoreProcessViewModel>(x => x.ExcludedFromTopper == true && x.LetterScore == "X")), Times.Once);
      }

      /// <summary>
      /// Verify Y score gets applied when the JobGrader returns null (saying it is unsuccessful).
      /// </summary>
      [Fact]
      public void GradeJobs_NullGraderResponse_RecordsYGrade()
      {
         // Arrange
         HashSet<string> spaNumbersExemptFromScoring = new HashSet<string>();  // No SPA numbers are exempt from scoring.
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>()
         {
            new CreditJob()
            {
               DrAddressId = this.drAddressId,
               JobId = this.jobId,
               HqtrCreditJobId = this.hqtrCreditJobId,
               BidAlternateId = this.bidAlternateId,
            }
         };

         this.jobScoreProcessService.Setup(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));

         JobGraderRequest gradeRequest = new JobGraderRequest();
         this.jobGraderBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(gradeRequest));

         JobGraderResponse gradeResponse = null;  // JobGrader returns null when unsuccessful.
         this.jobScoreCalculatorService.Setup(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()))
            .Returns(Task.FromResult(gradeResponse));

         this.jobScoreProcessService.Setup(x => x.RecordGrade(It.IsAny<CreditJobScoreProcessViewModel>())).Returns(Task.CompletedTask);

         // Act
         Task result = Task.Run(() => this.hostedService.GradeJobs(creditJobs, spaNumbersExemptFromScoring));
         result.Wait();

         // Assert
         this.jobScoreCalculatorService.Verify(x => x.GetJobGrade(It.IsAny<JobGraderRequest>()), Times.Once);
         this.jobGraderBuilder.Verify(x => x.BuildJobGraderRequest(this.drAddressId, this.jobId, this.bidAlternateId, true), Times.Once);
         this.jobScoreProcessService.Verify(x => x.MarkAsProcessed(this.hqtrCreditJobId, 0), Times.Once);
         this.jobScoreProcessService.Verify(x => x.RecordGrade(It.Is<CreditJobScoreProcessViewModel>(x => x.ExcludedFromTopper == true && x.LetterScore == "Y")), Times.Once);
      }

      /// <summary>
      /// Verify TIG/International jobs are scored as 'Y' and ExcludedFromTopper as 'Y'.
      /// </summary>
      [Fact]
      public void GradeJobs_TigOfficeJob_ReceivesExcludedFromTopper()
      {
         // Arrange
         HashSet<string> spaNumbersExemptFromScoring = new HashSet<string>();  // No SPA numbers are exempt from scoring.
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>()
         {
            new CreditJob()
            {
               DrAddressId = this.drAddressId,
               JobId = this.jobId,
               HqtrCreditJobId = this.hqtrCreditJobId,
               BidAlternateId = this.bidAlternateId,
               ProcessDate = DateTime.Now,
            }
         };

         this.jobScoreProcessService.Setup(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));

         this.jobGraderBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Throws(new TigSalesOfficeException());
         this.jobScoreProcessService.Setup(x => x.RecordGrade(It.IsAny<CreditJobScoreProcessViewModel>())).Returns(Task.CompletedTask);

         // Act
         Task result = Task.Run(() => this.hostedService.GradeJobs(creditJobs, spaNumbersExemptFromScoring));
         result.Wait();

         // Assert
         this.jobGraderBuilder.Verify(x => x.BuildJobGraderRequest(this.drAddressId, this.jobId, this.bidAlternateId, true), Times.Once);
         this.jobScoreProcessService.Verify(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
         this.jobScoreProcessService.Verify(x => x.RecordGrade(It.Is<CreditJobScoreProcessViewModel>(x => x.ExcludedFromTopper == true && x.LetterScore == "Y")), Times.Once);
      }

      [Fact]
      public async Task GradeJobs_CallsApiWithFinalScoreTrue()
      {
         // Arrange
         HashSet<string> spaNumbersExemptFromScoring = new HashSet<string>();  // No SPA numbers are exempt from scoring.
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>()
         {
            new CreditJob()
            {
               DrAddressId = this.drAddressId,
               JobId = this.jobId,
               HqtrCreditJobId = this.hqtrCreditJobId,
               BidAlternateId = this.bidAlternateId,
               ProcessDate = DateTime.Now,
            }
         };
         this.jobScoreProcessService.Setup(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));
         this.jobScoreProcessService.Setup(x => x.GetJobsToGrade(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(creditJobs));

         // Act
         await this.hostedService.GradeJobs(creditJobs, spaNumbersExemptFromScoring);

         // Assert
         this.jobGraderBuilder.Verify(b => b.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), true), Times.Once);
      }

      [Fact]
      public async Task GradeJobs_GivenMarkAsProcessedFails_SkipsGradingJob()
      {
         // Arrange
         HashSet<string> spaNumbersExemptFromScoring = new HashSet<string>();  // No SPA numbers are exempt from scoring.
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>()
         {
            new CreditJob()
            {
               DrAddressId = this.drAddressId,
               JobId = this.jobId,
               HqtrCreditJobId = this.hqtrCreditJobId,
               BidAlternateId = this.bidAlternateId,
               ProcessDate = DateTime.Now,
            }
         };

         this.jobScoreProcessService.Setup(x => x.MarkAsProcessed(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(false));
         this.jobScoreProcessService.Setup(x => x.GetJobsToGrade(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(creditJobs));

         // Act
         await this.hostedService.GradeJobs(creditJobs, spaNumbersExemptFromScoring);

         // Assert
         this.jobGraderBuilder.Verify(b => b.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify for stop async completion.
      /// </summary>
      [Fact]
      public void StopAsync_Completes()
      {
         // Arrange
         Mock<IServiceScope> serviceScope = new Mock<IServiceScope>();
         serviceScope.Setup(x => x.ServiceProvider).Returns(this.serviceProvider.Object);

         Mock<IServiceScopeFactory> serviceScopeFactory = new Mock<IServiceScopeFactory>();
         serviceScopeFactory.Setup(x => x.CreateScope()).Returns(serviceScope.Object);
         this.serviceProvider.Setup(x => x.GetService(typeof(IServiceScopeFactory))).Returns(serviceScopeFactory.Object);

         // Act
         Task result = Task.Run(() => this.hostedService.StopAsync(new System.Threading.CancellationToken(false)));
         result.Wait();

         // Assert
         Assert.True(result.IsCompleted);
      }
   }
}
