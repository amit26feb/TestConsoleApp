﻿// <copyright file="SalesOfficeScoringDataServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class SalesOfficeScoringDataServiceTest
   {
      private readonly SalesOfficeScoringDataService serviceUnderTest;
      private readonly Mock<IJobScoreQuintileRepository> jobScoreQuintileRepository;
      private readonly Mock<IJobSizeRepository> jobSizeRepository;
      private readonly Mock<IJobSizeFactorRepository> jobSizeFactorRepository;
      private readonly Mock<IExcludedProductCodeRepository> excludedProductCodeRepository;
      private readonly Mock<IJobsApiClient> jobsApiClient;
      private readonly Mock<ILogger<SalesOfficeScoringDataService>> logger;
      private readonly Mock<IConfiguration> configuration;
      private readonly int salesOfficeId = 123;
      private readonly string salesOfficeCode = "asdf";
      private readonly string[] prodCodes = new string[] { "hiThere" };
      private readonly string usCustChannel = "COMMSALE";
      private readonly string canadianCustChannel = "CANADA";

      public SalesOfficeScoringDataServiceTest()
      {
         this.jobScoreQuintileRepository = new Mock<IJobScoreQuintileRepository>();
         this.jobSizeRepository = new Mock<IJobSizeRepository>();
         this.jobSizeFactorRepository = new Mock<IJobSizeFactorRepository>();
         this.excludedProductCodeRepository = new Mock<IExcludedProductCodeRepository>();
         this.jobsApiClient = new Mock<IJobsApiClient>();
         this.logger = new Mock<ILogger<SalesOfficeScoringDataService>>();
         this.configuration = new Mock<IConfiguration>();
         this.configuration.Setup(x => x["tsmt-JobScoringService-CurrencyExchangeRate"]).Returns("1");

         this.serviceUnderTest = new SalesOfficeScoringDataService(
            this.jobScoreQuintileRepository.Object,
            this.jobSizeFactorRepository.Object,
            this.jobSizeRepository.Object,
            this.excludedProductCodeRepository.Object,
            this.jobsApiClient.Object,
            this.logger.Object,
            this.configuration.Object);
      }

      [Fact]
      public async Task GetScoringData_NoJobSizeFactor_ThrowsError()
      {
         // Arrange
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult<JobSizeFactorModel>(null));

         // Act and Assert
         await Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.usCustChannel));
      }

      [Fact]
      public async Task GetScoringData_NoSalesOffice_ThrowsError()
      {
         // Arrange
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes)).Returns(Task.FromResult<IEnumerable<JobScoreQuintile>>(null));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult<SalesOffice>(null));

         // Act and Assert
         await Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.usCustChannel));
      }

      [Fact]
      public async Task GetScoringData_NoSalesOfficeCode_ThrowsError()
      {
         // Arrange
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes)).Returns(Task.FromResult<IEnumerable<JobScoreQuintile>>(null));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = null }));

         // Act and Assert
         await Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.usCustChannel));
      }

      [Fact]
      public async Task GetScoringData_NoQuintiles_ReturnsScoringData()
      {
         // Arrange
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel() { JobSizeFactor = 123 }));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes)).Returns(Task.FromResult<IEnumerable<JobScoreQuintile>>(null));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act and Assert
         SalesOfficeScoringDataViewModel result = await this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.usCustChannel);

         Assert.NotNull(result);
         Assert.Equal(1, result.CurrencyExchangeRate);
         Assert.Equal(123, result.JobSizeFactor);
         Assert.Empty(result.ProductCodeQuintiles);
      }

      [Fact]
      public async Task GetScoringData_NoJobSizes_ReturnsScoringData()
      {
         // Arrange
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel() { JobSizeFactor = 2 }));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes)).Returns(Task.FromResult(new JobScoreQuintile[] { new JobScoreQuintile() }.AsEnumerable()));
         this.jobSizeRepository.Setup(js => js.GetJobSizes()).Returns(Task.FromResult<IEnumerable<JobSizeModel>>(null));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act and Assert
         SalesOfficeScoringDataViewModel result = await this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.usCustChannel);

         Assert.NotNull(result);
         Assert.Equal(1, result.CurrencyExchangeRate);
         Assert.Equal(2, result.JobSizeFactor);
         Assert.Empty(result.ProductCodeQuintiles);
      }

      [Fact]
      public async Task GetScoringData_NoExcludedProductCodes_ThrowsError()
      {
         // Arrange
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes))
            .Returns(Task.FromResult(new List<JobScoreQuintile>() { new JobScoreQuintile() }.AsEnumerable()));
         this.jobSizeRepository.Setup(jsqr => jsqr.GetJobSizes())
            .Returns(Task.FromResult(new List<JobSizeModel>() { new JobSizeModel() { JobSize = "a" } }.AsEnumerable()));
         this.excludedProductCodeRepository.Setup(epcr => epcr.GetExcludedProductCodes()).Returns(Task.FromResult<IEnumerable<ExcludedProductCode>>(null));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act and Assert
         await Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.usCustChannel));
      }

      [Fact]
      public async Task GetScoringData_BadCustomerChannelId_ThrowsError()
      {
         // Arrange
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes))
            .Returns(Task.FromResult(new List<JobScoreQuintile>() { new JobScoreQuintile() }.AsEnumerable()));
         this.jobSizeRepository.Setup(jsqr => jsqr.GetJobSizes())
            .Returns(Task.FromResult(new List<JobSizeModel>() { new JobSizeModel() { JobSize = "$30K - $50K" } }.AsEnumerable()));
         this.excludedProductCodeRepository.Setup(epcr => epcr.GetExcludedProductCodes())
            .Returns(Task.FromResult(new List<ExcludedProductCode>() { new ExcludedProductCode() }.AsEnumerable()));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act and Assert
         await Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, "badCustChannelId"));
      }

      [Fact]
      public async Task GetScoringData_CanadianCustChannel_UsesCanadianExchangeRate()
      {
         // Arrange
         JobScoreQuintile aQuintile = new JobScoreQuintile() { JobSize = "$30K - $50K", StartB = 1, StartC = 2, StartD = 3, StartE = 4 };
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel()));
         this.jobSizeRepository.Setup(jsqr => jsqr.GetJobSizes())
            .Returns(Task.FromResult(new List<JobSizeModel>() { new JobSizeModel() { JobSize = "$30K - $50K" } }.AsEnumerable()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes))
            .Returns(Task.FromResult(new List<JobScoreQuintile>() { aQuintile }.AsEnumerable()));
         this.excludedProductCodeRepository.Setup(epcr => epcr.GetExcludedProductCodes())
            .Returns(Task.FromResult(new List<ExcludedProductCode>() { new ExcludedProductCode() { ProductCode = "asdf" } }.AsEnumerable()));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act
         SalesOfficeScoringDataViewModel result = await this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.canadianCustChannel);

         // Assert
         Assert.Equal(1.0m, result.CurrencyExchangeRate);
      }

      [Fact]
      public async Task GetScoringData_HasJobSize_UsesMinAndMaxProps()
      {
         // Arrange
         JobScoreQuintile aQuintile = new JobScoreQuintile() { JobSize = "$30K - $50K", StartB = 1, StartC = 2, StartD = 3, StartE = 4 };
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel()));
         this.jobSizeRepository.Setup(jsqr => jsqr.GetJobSizes())
            .Returns(Task.FromResult(new List<JobSizeModel>() { new JobSizeModel() { JobSize = "$30K - $50K", FromAmount = 30000, ToAmount = 50000 } }.AsEnumerable()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes))
            .Returns(Task.FromResult(new List<JobScoreQuintile>() { aQuintile }.AsEnumerable()));
         this.excludedProductCodeRepository.Setup(epcr => epcr.GetExcludedProductCodes())
            .Returns(Task.FromResult(new List<ExcludedProductCode>() { new ExcludedProductCode() { ProductCode = "asdf" } }.AsEnumerable()));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act
         SalesOfficeScoringDataViewModel result = await this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.canadianCustChannel);

         // Assert
         Assert.Equal(30000, result.ProductCodeQuintiles.First().Quintiles.First().JobSizeMin);
         Assert.Equal(50000, result.ProductCodeQuintiles.First().Quintiles.First().JobSizeMax);
      }

      [Fact]
      public async Task GetScoringData_NoCorrespondingJobSize_DefaultsMinAndMaxProps()
      {
         // Arrange
         JobScoreQuintile aQuintile = new JobScoreQuintile() { JobSize = "$30K - $50K", StartB = 1, StartC = 2, StartD = 3, StartE = 4 };
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel()));
         this.jobSizeRepository.Setup(jsqr => jsqr.GetJobSizes())
            .Returns(Task.FromResult(new List<JobSizeModel>() { new JobSizeModel() { JobSize = "DOESNT MATCH!" } }.AsEnumerable()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes))
            .Returns(Task.FromResult(new List<JobScoreQuintile>() { aQuintile }.AsEnumerable()));
         this.excludedProductCodeRepository.Setup(epcr => epcr.GetExcludedProductCodes())
            .Returns(Task.FromResult(new List<ExcludedProductCode>() { new ExcludedProductCode() { ProductCode = "asdf" } }.AsEnumerable()));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act
         SalesOfficeScoringDataViewModel result = await this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.canadianCustChannel);

         // Assert
         Assert.Equal(0, result.ProductCodeQuintiles.First().Quintiles.First().JobSizeMin);
         Assert.Equal(decimal.MaxValue, result.ProductCodeQuintiles.First().Quintiles.First().JobSizeMax);
      }

      [Fact]
      public async Task GetScoringData_UsCustChannelAndMultipleAndExcludedProductCode_Uses1ForExchangeRateAndSetsExemptFlag()
      {
         // Arrange
         string excludedProductCode = "excluded";
         IEnumerable<string> allProductCodes = this.prodCodes.Append(excludedProductCode);
         JobScoreQuintile aQuintile = new JobScoreQuintile() { ProductCode = this.prodCodes.First(), JobSize = "$30K - $50K", StartB = 1, StartC = 2, StartD = 3, StartE = 4 };
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel() { JobSizeFactor = .85m }));
         this.jobSizeRepository.Setup(jsqr => jsqr.GetJobSizes())
            .Returns(Task.FromResult(new List<JobSizeModel>() { new JobSizeModel() { JobSize = "$30K - $50K" } }.AsEnumerable()));

         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, allProductCodes))
            .Returns(Task.FromResult(new List<JobScoreQuintile>()
            {
               aQuintile,
               new JobScoreQuintile() { ProductCode = excludedProductCode },
            }.AsEnumerable()));
         this.excludedProductCodeRepository.Setup(epcr => epcr.GetExcludedProductCodes())
            .Returns(Task.FromResult(new List<ExcludedProductCode>() { new ExcludedProductCode() { ProductCode = excludedProductCode } }.AsEnumerable()));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act
         SalesOfficeScoringDataViewModel result = await this.serviceUnderTest.GetScoringData(this.salesOfficeId, allProductCodes, this.usCustChannel);

         // Assert
         Assert.Equal(2, result.ProductCodeQuintiles.Count());
         Assert.Equal(1, result.CurrencyExchangeRate);
         Assert.Equal(.85m, result.JobSizeFactor);
         ProductCodeQuintilesViewModel firstPDQ = result.ProductCodeQuintiles.First();
         Assert.Equal(aQuintile.ProductCode, firstPDQ.ProductCode);
         Assert.False(firstPDQ.IsExempt);
         QuintileViewModel firstQ = firstPDQ.Quintiles.First();
         Assert.Equal(aQuintile.StartB, firstQ.StartB);
         Assert.Equal(aQuintile.StartC, firstQ.StartC);
         Assert.Equal(aQuintile.StartD, firstQ.StartD);
         Assert.Equal(aQuintile.StartE, firstQ.StartE);

         Assert.Equal(excludedProductCode, result.ProductCodeQuintiles.Last().ProductCode);
         Assert.True(result.ProductCodeQuintiles.Last().IsExempt);
      }

      [Fact]
      public async Task GetScoringData_MultipleQuintilesForOneProductCode_GroupsQuintilesCorrectly()
      {
         // Arrange
         JobScoreQuintile aQuintile = new JobScoreQuintile() { ProductCode = this.prodCodes.First(), JobSize = "$30K - $50K", StartB = 1, StartC = 2, StartD = 3, StartE = 4 };
         JobScoreQuintile anotherQuintile = new JobScoreQuintile() { ProductCode = this.prodCodes.First(), JobSize = "$51K - $700K", StartB = 5, StartC = 6, StartD = 7, StartE = 8 };
         this.jobSizeFactorRepository.Setup(jsfr => jsfr.GetJobSizeFactor()).Returns(Task.FromResult(new JobSizeFactorModel() { JobSizeFactor = .85m }));
         this.jobSizeRepository.Setup(jsqr => jsqr.GetJobSizes())
            .Returns(Task.FromResult(new List<JobSizeModel>() { new JobSizeModel() { JobSize = "$30K - $50K" }, new JobSizeModel() { JobSize = "$51K - $700K" } }.AsEnumerable()));
         this.jobScoreQuintileRepository.Setup(jsqr => jsqr.GetJobScoreQuintiles(this.salesOfficeCode, this.prodCodes))
            .Returns(Task.FromResult(new List<JobScoreQuintile>() { aQuintile, anotherQuintile }.AsEnumerable()));
         this.excludedProductCodeRepository.Setup(epcr => epcr.GetExcludedProductCodes())
            .Returns(Task.FromResult(new List<ExcludedProductCode>() { new ExcludedProductCode() { ProductCode = "asdf" } }.AsEnumerable()));
         this.jobsApiClient.Setup(j => j.GetSalesOffice(this.salesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Code = this.salesOfficeCode }));

         // Act
         SalesOfficeScoringDataViewModel result = await this.serviceUnderTest.GetScoringData(this.salesOfficeId, this.prodCodes, this.usCustChannel);

         // Assert
         Assert.Single(result.ProductCodeQuintiles);
         Assert.Equal(aQuintile.ProductCode, result.ProductCodeQuintiles.First().ProductCode);
         Assert.False(result.ProductCodeQuintiles.First().IsExempt);
         QuintileViewModel firstQ = result.ProductCodeQuintiles.First().Quintiles.First();
         Assert.Equal(aQuintile.StartB, firstQ.StartB);
         Assert.Equal(aQuintile.StartC, firstQ.StartC);
         Assert.Equal(aQuintile.StartD, firstQ.StartD);
         Assert.Equal(aQuintile.StartE, firstQ.StartE);

         QuintileViewModel lastQ = result.ProductCodeQuintiles.First().Quintiles.Last();
         Assert.Equal(anotherQuintile.StartB, lastQ.StartB);
         Assert.Equal(anotherQuintile.StartC, lastQ.StartC);
         Assert.Equal(anotherQuintile.StartD, lastQ.StartD);
         Assert.Equal(anotherQuintile.StartE, lastQ.StartE);
      }
   }
}
