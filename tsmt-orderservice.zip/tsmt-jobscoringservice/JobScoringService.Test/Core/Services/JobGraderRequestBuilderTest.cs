﻿// <copyright file="JobGraderRequestBuilderTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Runtime.CompilerServices;
   using System.Threading.Tasks;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Tests for the Job Grader Request Builder
   /// </summary>
   public class JobGraderRequestBuilderTest
   {
      private readonly JobGraderRequestBuilder serviceUnderTest;
      private readonly Mock<ILogger<JobGraderRequestBuilder>> mockLogger;
      private readonly Mock<IJobsApiClient> mockJobsApiClient;
      private readonly Mock<IBidsApiClient> mockBidsApiClient;
      private readonly Mock<ISalesRollupApiClient> mockSalesRollupApiClient;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobGraderRequestBuilderTest"/> class.
      /// </summary>
      public JobGraderRequestBuilderTest()
      {
         this.mockLogger = new Mock<ILogger<JobGraderRequestBuilder>>();
         this.mockJobsApiClient = new Mock<IJobsApiClient>();
         this.mockBidsApiClient = new Mock<IBidsApiClient>();
         this.mockSalesRollupApiClient = new Mock<ISalesRollupApiClient>();

         this.serviceUnderTest = new JobGraderRequestBuilder(
            this.mockLogger.Object,
            this.mockJobsApiClient.Object,
            this.mockBidsApiClient.Object,
            this.mockSalesRollupApiClient.Object);
      }

      [Fact]
      public async Task BuildJobGraderRequest_EncountersNoExceptions_SuccessfullyBuildsRequest()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidAlternateId = 30;
         Job job = new Job()
         {
            JobGeneral = new JobGeneral() { CustChannelId = "COMMSALE", JobName = "Job Name" },
            JobOfficeAndPeople = new JobOfficeAndPeople() { SalesOfficeId = 10, LocationOffice = 20, CommCode = "A01", SalesOfficeCode = "A1" },
            JobClassificationList = new List<JobClassification>()
         };
         Bid bid = new Bid() { BidAlternateId = bidAlternateId, BidName = "My Bid" };
         string salesOfficeName = "Sales Office Name";
         string locationOfficeName = "Location Office Name";
         string salesPerson = "[A01] John Doe";
         IEnumerable<JobGraderRequestLineItem> lineItems = new List<JobGraderRequestLineItem>()
         {
            new JobGraderRequestLineItem(),
            new JobGraderRequestLineItem(),
            new JobGraderRequestLineItem(),
         }.AsEnumerable();

         Mock<JobGraderRequestBuilder> mockServiceUnderTest = new Mock<JobGraderRequestBuilder>(
            this.mockLogger.Object,
            this.mockJobsApiClient.Object,
            this.mockBidsApiClient.Object,
            this.mockSalesRollupApiClient.Object);

         mockServiceUnderTest.Setup(x => x.GetJob(drAddressId, jobId))
            .Returns(Task.FromResult(job));

         mockServiceUnderTest.Setup(x => x.GetBid(drAddressId, jobId, bidAlternateId))
            .Returns(Task.FromResult(bid));

         mockServiceUnderTest.Setup(x => x.GetOfficeName(job.JobOfficeAndPeople.SalesOfficeId, "Sales Office"))
            .Returns(Task.FromResult(salesOfficeName));

         mockServiceUnderTest.Setup(x => x.GetOfficeName(job.JobOfficeAndPeople.LocationOffice, "Location Office"))
            .Returns(Task.FromResult(locationOfficeName));

         mockServiceUnderTest.Setup(x => x.GetSalesPerson(job.JobOfficeAndPeople.SalesOfficeId, job.JobOfficeAndPeople.CommCode))
            .Returns(Task.FromResult(salesPerson));

         mockServiceUnderTest.Setup(x => x.GetRollupLineItems(drAddressId, jobId, bid.BidAlternateId))
            .Returns(Task.FromResult(lineItems));

         mockServiceUnderTest.Setup(x => x.BuildJobGraderRequest(drAddressId, jobId, bidAlternateId, It.IsAny<bool>())).CallBase();  // We do NOT want to mock this, even though its virtual -- we want to test the logic below!

         // Act
         JobGraderRequest jobGraderRequest = await mockServiceUnderTest.Object.BuildJobGraderRequest(drAddressId, jobId, bidAlternateId);

         // Assert
         Assert.NotNull(jobGraderRequest);
         Assert.Equal(job.JobGeneral.JobName, jobGraderRequest.Job);
         Assert.Equal("$USD", jobGraderRequest.Currency);
         Assert.Equal(salesOfficeName, jobGraderRequest.SalesOffice);
         Assert.Equal(locationOfficeName, jobGraderRequest.JobLocation);
         Assert.Equal(salesPerson, jobGraderRequest.SalesPerson);
         Assert.Equal(bid.BidName, jobGraderRequest.Bid);
         Assert.Equal(lineItems, jobGraderRequest.JobLineItems);
         Assert.Equal("**********", jobGraderRequest.JobClassCode);
         Assert.Equal(string.Empty, jobGraderRequest.StrategicJobType);
         Assert.Equal(job.JobOfficeAndPeople.SalesOfficeCode, jobGraderRequest.SalesOfficeCode);
      }

      [Theory]
      [InlineData(false)]
      [InlineData(true)]
      public async Task BuildJobGraderRequest_GivenFinalScoreFlag_SetsIsFinalScoreOnRequest(bool givenFinalScoreFlag)
      {
         // Arrange
         string salesOfficeName = "Sales Office Name";
         string locationOfficeName = "Location Office Name";
         string commCode = "bleh";
         Job job = new Job()
         {
            JobGeneral = new JobGeneral() { CustChannelId = "COMMSALE", JobName = "Job Name" },
            JobOfficeAndPeople = new JobOfficeAndPeople() { SalesOfficeId = 10, LocationOffice = 20, CommCode = "A01" }
         };

         this.mockJobsApiClient.Setup(c => c.GetSalesOffice(job.JobOfficeAndPeople.SalesOfficeId)).Returns(Task.FromResult(new SalesOffice() { Name = salesOfficeName }));
         this.mockJobsApiClient.Setup(c => c.GetSalesOffice(job.JobOfficeAndPeople.LocationOffice)).Returns(Task.FromResult(new SalesOffice() { Name = locationOfficeName }));
         this.mockJobsApiClient.Setup(c => c.GetCommissionCodes(It.IsAny<int>())).Returns(Task.FromResult(
            (IEnumerable<CommissionCode>)new CommissionCode[]
            {
               new CommissionCode() { CommCode = commCode, CommCodeDisplay = "Comm Code Display" }
            }));
         this.mockJobsApiClient.Setup(j => j.GetJob(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(job));

         Bid bid = new Bid() { BidAlternateId = 100, BidName = "Biddy McBiderson" };
         this.mockBidsApiClient.Setup(b => b.GetBidAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(bid));

         this.mockSalesRollupApiClient.Setup(c => c.GetRollupData(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<SalesRollupType>())).Returns(Task.FromResult(new SalesRollup()));

         // Act
         var request = await this.serviceUnderTest.BuildJobGraderRequest(10, 20, 30, givenFinalScoreFlag);

         // Assert
         Assert.Equal(givenFinalScoreFlag, request.IsFinalScore);
      }

      [Fact]
      public async Task GetJob_ApiReturnsWellFormedJob_ReturnsJob()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;

         this.mockJobsApiClient.Setup(x => x.GetJob(drAddressId, jobId))
            .Returns(Task.FromResult(new Job() { JobGeneral = new JobGeneral(), JobOfficeAndPeople = new JobOfficeAndPeople() }));

         // Act
         Job job = await this.serviceUnderTest.GetJob(drAddressId, jobId);

         // Assert
         Assert.NotNull(job);
      }

      [Fact]
      public void GetJob_ApiReturnsNull_ThrowsExpectedException()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;

         this.mockJobsApiClient.Setup(x => x.GetJob(drAddressId, jobId))
            .Returns(Task.FromResult<Job>(null));

         // Act
         Task<JobScoringServiceDomainException> ex = Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetJob(drAddressId, jobId));
         JobScoringServiceDomainException expectedException = ex.Result;

         // Assert
         Assert.StartsWith("Unable to get well-formed Job via call to Jobs API client", expectedException.Message);
      }

      [Fact]
      public void GetJob_ApiReturnsPoorlyFormedJob_ThrowsExpectedException()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;

         this.mockJobsApiClient.Setup(x => x.GetJob(drAddressId, jobId))
            .Returns(Task.FromResult(new Job() { JobGeneral = new JobGeneral(), JobOfficeAndPeople = null }));  // JobOfficeAndPeople being null means it is a poorly formed job.

         // Act
         Task<JobScoringServiceDomainException> ex = Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetJob(drAddressId, jobId));
         JobScoringServiceDomainException expectedException = ex.Result;

         // Assert
         Assert.StartsWith("Unable to get well-formed Job via call to Jobs API client", expectedException.Message);
      }

      [Fact]
      public void GetJob_ApiRetunsTigOffice_ThrowsTigException()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         Job job = new Job()
         {
            JobOfficeAndPeople = new JobOfficeAndPeople()
            {
               SalesOfficeId = JobGraderRequestBuilder.SalesOfficeTIG,
            },
         };

         this.mockJobsApiClient.Setup(x => x.GetJob(drAddressId, jobId))
            .Returns(Task.FromResult<Job>(job));

         // Act
         Assert.ThrowsAsync<TigSalesOfficeException>(() => this.serviceUnderTest.GetJob(drAddressId, jobId));

         this.mockBidsApiClient.Verify(x => x.GetBidAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task GetBid_ApiReturnsBid_ReturnsBid()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidAlternateId = 3;

         this.mockBidsApiClient.Setup(x => x.GetBidAsync(drAddressId, jobId, bidAlternateId))
            .Returns(Task.FromResult(
               new Bid()
               {
                  CurrentBidInd = "Y",
                  BidAlternateId = bidAlternateId
               }));

         // Act
         Bid bid = await this.serviceUnderTest.GetBid(drAddressId, jobId, bidAlternateId);

         // Assert
         Assert.NotNull(bid);
         Assert.Equal(bidAlternateId, bid.BidAlternateId);
      }

      [Fact]
      public void GetBidToHonor_ApiReturnsNull_ThrowsExpectedException()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidAlternateId = 3;

         this.mockBidsApiClient.Setup(x => x.GetBidAsync(drAddressId, jobId, bidAlternateId))
            .Returns(Task.FromResult<Bid>(null));

         // Act
         Task<JobScoringServiceDomainException> ex = Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetBid(drAddressId, jobId, bidAlternateId));
         JobScoringServiceDomainException expectedException = ex.Result;

         // Assert
         Assert.StartsWith("Unable to get bid via call to Bids API client", expectedException.Message);
      }

      [Fact]
      public void GetCurrencyFromCustChannelId_ForCOMMSALE_ReturnsUSD()
      {
         // Arrange
         string custChannelId = "COMMSALE";
         string expectedCurrency = "$USD";

         // Act
         string currency = JobGraderRequestBuilder.GetCurrencyFromCustChannelId(custChannelId);

         // Assert
         Assert.Equal(expectedCurrency, currency);
      }

      [Fact]
      public void GetCurrencyFromCustChannelId_ForCANADA_ReturnsCAD()
      {
         // Arrange
         string custChannelId = "CANADA";
         string expectedCurrency = "$CAD";

         // Act
         string currency = JobGraderRequestBuilder.GetCurrencyFromCustChannelId(custChannelId);

         // Assert
         Assert.Equal(expectedCurrency, currency);
      }

      [Fact]
      public void GetCurrencyFromCustChannelId_ForNullCustChannelId_ThrowsExpectedException()
      {
         // Arrange
         string custChannelId = null;

         // Act
         JobScoringServiceDomainException expectedException = Assert.Throws<JobScoringServiceDomainException>(() => JobGraderRequestBuilder.GetCurrencyFromCustChannelId(custChannelId));

         // Assert
         Assert.Equal("Unable to interpret Currency from CustChannelId ().", expectedException.Message);
      }

      [Fact]
      public void GetCurrencyFromCustChannelId_ForInvalidCustChannelId_ThrowsExpectedException()
      {
         // Arrange
         string custChannelId = "OTHER";  // Not a valid CustChannelId

         // Act
         JobScoringServiceDomainException expectedException = Assert.Throws<JobScoringServiceDomainException>(() => JobGraderRequestBuilder.GetCurrencyFromCustChannelId(custChannelId));

         // Assert
         Assert.Equal("Unable to interpret Currency from CustChannelId (OTHER).", expectedException.Message);
      }

      [Fact]
      public async Task GetOfficeName_ApiReturnsSalesOfficeWithName_ReturnsSalesOfficeName()
      {
         // Arrange
         int salesOfficeId = 1;
         string officeTypeForErrorReporting = "Some Office Type";
         string expectedOfficeName = "Office Name";

         this.mockJobsApiClient.Setup(x => x.GetSalesOffice(salesOfficeId))
            .Returns(Task.FromResult(new SalesOffice { Name = expectedOfficeName }));

         // Act
         string salesOfficeName = await this.serviceUnderTest.GetOfficeName(salesOfficeId, officeTypeForErrorReporting);

         // Assert
         Assert.NotNull(salesOfficeName);
         Assert.Equal(expectedOfficeName, salesOfficeName);
      }

      [Fact]
      public void GetOfficeName_ApiReturnsNull_ThrowsExpectedException()
      {
         // Arrange
         int salesOfficeId = 1;
         string officeTypeForErrorReporting = "Some Office Type";

         this.mockJobsApiClient.Setup(x => x.GetSalesOffice(salesOfficeId))
            .Returns(Task.FromResult<SalesOffice>(null));

         // Act
         Task<JobScoringServiceDomainException> ex = Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetOfficeName(salesOfficeId, officeTypeForErrorReporting));
         JobScoringServiceDomainException expectedException = ex.Result;

         // Assert
         Assert.Equal(string.Format("Unable to get {0} via call to Jobs API client, for {0} Id ({1}).", officeTypeForErrorReporting, salesOfficeId), expectedException.Message);
      }

      [Fact]
      public void GetOfficeName_ApiReturnsSalesOfficeLackingName_ThrowsExpectedException()
      {
         // Arrange
         int salesOfficeId = 1;
         string officeTypeForErrorReporting = "Some Office Type";

         this.mockJobsApiClient.Setup(x => x.GetSalesOffice(salesOfficeId))
            .Returns(Task.FromResult(new SalesOffice { Name = string.Empty }));

         // Act
         Task<JobScoringServiceDomainException> ex = Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetOfficeName(salesOfficeId, officeTypeForErrorReporting));
         JobScoringServiceDomainException expectedException = ex.Result;

         // Assert
         Assert.Equal(string.Format("Blank {0} Name, for {0} Id ({1}).", officeTypeForErrorReporting, salesOfficeId), expectedException.Message);
      }

      [Fact]
      public async Task GetSalesPerson_EmptyCommCode_ReturnsNull()
      {
         // Arrange
         int salesOfficeId = 1;
         string commCode = null;

         Mock<JobGraderRequestBuilder> mockServiceUnderTest = new Mock<JobGraderRequestBuilder>(
            this.mockLogger.Object,
            this.mockJobsApiClient.Object,
            this.mockBidsApiClient.Object,
            this.mockSalesRollupApiClient.Object);  // Need to mock service in order to verify LogWarningMessage gets called.

         mockServiceUnderTest.Setup(x => x.GetSalesPerson(salesOfficeId, commCode)).CallBase();  // We do NOT want to mock this, even though its virtual -- we want to test the logic below!

         // Act
         string salesPerson = await mockServiceUnderTest.Object.GetSalesPerson(salesOfficeId, commCode);

         // Assert
         Assert.Null(salesPerson);
         mockServiceUnderTest.Verify(x => x.LogWarningMessage(It.IsAny<string>()), Times.Once);  // Warning because we are payload will have blank SalesPerson.
      }

      [Fact]
      public async Task GetSalesPerson_CommCodeNotInSalesOfficeCommCodes_ReturnsNull()
      {
         // Arrange
         int salesOfficeId = 1;
         string commCode = "A01";  // Not in the list of office comm codes, below.
         IEnumerable<CommissionCode> officeCommissionCodes = new List<CommissionCode>()
         {
            new CommissionCode() { SalesOfficeId = salesOfficeId, CommCode = "B02", Name = "John Doe", CommCodeDisplay = "[B02] John Doe" },
            new CommissionCode() { SalesOfficeId = salesOfficeId, CommCode = "C03", Name = "Jane Boe", CommCodeDisplay = "[C03] Jane Boe" }
         }.AsEnumerable();

         this.mockJobsApiClient.Setup(x => x.GetCommissionCodes(salesOfficeId))
            .Returns(Task.FromResult(officeCommissionCodes));

         Mock<JobGraderRequestBuilder> mockServiceUnderTest = new Mock<JobGraderRequestBuilder>(
            this.mockLogger.Object,
            this.mockJobsApiClient.Object,
            this.mockBidsApiClient.Object,
            this.mockSalesRollupApiClient.Object);  // Need to mock service in order to verify LogWarningMessage gets called.

         mockServiceUnderTest.Setup(x => x.GetSalesPerson(salesOfficeId, commCode)).CallBase();  // We do NOT want to mock this, even though its virtual -- we want to test the logic below!

         // Act
         string salesPerson = await mockServiceUnderTest.Object.GetSalesPerson(salesOfficeId, commCode);

         // Assert
         Assert.Null(salesPerson);
         mockServiceUnderTest.Verify(x => x.LogWarningMessage(It.IsAny<string>()), Times.Once);  // Warning because we are payload will have blank SalesPerson.
      }

      [Fact]
      public async Task GetSalesPerson_MatchingCommCodeLacksDisplayName_ReturnsCommCode()
      {
         // Arrange
         int salesOfficeId = 1;
         string commCode = "B02";
         IEnumerable<CommissionCode> officeCommissionCodes = new List<CommissionCode>()
         {
            new CommissionCode() { SalesOfficeId = salesOfficeId, CommCode = commCode, Name = "John Doe", CommCodeDisplay = string.Empty },  // Matches on comm code, but lacks display name
            new CommissionCode() { SalesOfficeId = salesOfficeId, CommCode = "C03", Name = "Jane Boe", CommCodeDisplay = "[C03] Jane Boe" }
         }.AsEnumerable();

         this.mockJobsApiClient.Setup(x => x.GetCommissionCodes(salesOfficeId))
            .Returns(Task.FromResult(officeCommissionCodes));

         // Act
         string salesPerson = await this.serviceUnderTest.GetSalesPerson(salesOfficeId, commCode);

         // Assert
         Assert.Equal(commCode, salesPerson);
      }

      [Fact]
      public async Task GetSalesPerson_MatchingCommCodeHasDisplayName_ReturnsCommCodeDisplay()
      {
         // Arrange
         int salesOfficeId = 1;
         string commCode = "B02";
         string commCodeDisplay = "[B02] John Doe";
         IEnumerable<CommissionCode> officeCommissionCodes = new List<CommissionCode>()
         {
            new CommissionCode() { SalesOfficeId = salesOfficeId, CommCode = commCode, Name = "John Doe", CommCodeDisplay = commCodeDisplay },
            new CommissionCode() { SalesOfficeId = salesOfficeId, CommCode = "C03", Name = "Jane Boe", CommCodeDisplay = "[C03] Jane Boe" }
         }.AsEnumerable();

         this.mockJobsApiClient.Setup(x => x.GetCommissionCodes(salesOfficeId))
            .Returns(Task.FromResult(officeCommissionCodes));

         // Act
         string salesPerson = await this.serviceUnderTest.GetSalesPerson(salesOfficeId, commCode);

         // Assert
         Assert.Equal(commCodeDisplay, salesPerson);
      }

      [Fact]
      public async Task GetRollupLineItems_ApiReturnsSalesRollup_ReturnsRollupLineItems()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidId = 3;
         SalesRollup salesRollup = new SalesRollup()
         {
            Rows = new List<SalesRollupRow>()
            {
               new SalesRollupRow()
                {
                  VariationPrice = 0.75m,
                  FapDollars = 1m,
                  TraneNetDollars = 1m,
               },
               new SalesRollupRow()
               {
                  VariationPrice = null,
                  FapDollars = null,
                  TraneNetDollars = null,
               },
               new SalesRollupRow(),
            }
         };

         this.mockSalesRollupApiClient.Setup(x => x.GetRollupData(drAddressId, jobId, bidId, SalesRollupType.Code))
            .Returns(Task.FromResult(salesRollup));

         // Act
         IEnumerable<JobGraderRequestLineItem> rollupLineItems = await this.serviceUnderTest.GetRollupLineItems(drAddressId, jobId, bidId);

         // Assert
         Assert.NotNull(rollupLineItems);
         Assert.Equal(3, rollupLineItems.Count());
         Assert.Equal(0.75m, rollupLineItems.ElementAt(0).VariationPrice);
         Assert.Equal(1m, rollupLineItems.ElementAt(0).FapDollars);
         Assert.Equal(1m, rollupLineItems.ElementAt(0).TraneNetDollars);
         Assert.Equal(0m, rollupLineItems.ElementAt(1).VariationPrice);
         Assert.Equal(0m, rollupLineItems.ElementAt(1).FapDollars);
         Assert.Equal(0m, rollupLineItems.ElementAt(1).TraneNetDollars);
      }

      [Fact]
      public void GetRollupLineItems_ApiReturnsNull_ThrowsExpectedException()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidId = 3;
         SalesRollup salesRollup = null;

         this.mockSalesRollupApiClient.Setup(x => x.GetRollupData(drAddressId, jobId, bidId, SalesRollupType.Code))
            .Returns(Task.FromResult(salesRollup));

         // Act
         Task<JobScoringServiceDomainException> ex = Assert.ThrowsAsync<JobScoringServiceDomainException>(() => this.serviceUnderTest.GetRollupLineItems(drAddressId, jobId, bidId));
         JobScoringServiceDomainException expectedException = ex.Result;

         // Assert
         Assert.StartsWith("Unable to get sales rollup data via call to SalesRollup API client", expectedException.Message);
      }

      [Fact]
      public void GetJobStrategyFromClassification_ReturnsValid()
      {
         // Arrange
         List<JobClassification> jcs = new List<JobClassification>();
         JobClassification jc1 = new JobClassification() { JobClassId = 88, JobCode = "1" };
         JobClassification jc2 = new JobClassification() { JobClassId = JobGraderRequestBuilder.JobClassificationJobStrategyId, JobCode = "3" };
         jcs.Add(jc1);
         jcs.Add(jc2);

         // Act
         string strategy = this.serviceUnderTest.GetJobStrategy(jcs);

         // Assert
         Assert.Equal("3", strategy);
      }

      [Fact]
      public void GetJobStrategyFromClassification_ReturnsEmpty()
      {
         // Arrange
         List<JobClassification> jcs = new List<JobClassification>();
         JobClassification jc1 = new JobClassification() { JobClassId = 88, JobCode = "1" };
         JobClassification jc2 = new JobClassification() { JobClassId = 77, JobCode = "3" };
         jcs.Add(jc1);
         jcs.Add(jc2);

         // Act
         string strategy = this.serviceUnderTest.GetJobStrategy(jcs);

         // Assert
         Assert.Equal(string.Empty, strategy);
      }
   }
}
