﻿// <copyright file="JobScoreReportServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Security.Claims;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.Services;
   using JobScoringService.Test.Common;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using Xunit;

   public class JobScoreReportServiceTest
   {
      private const int JobId = 222;
      private const int BidAlternateId = 666555;
      private readonly Mock<IJobScoreReportRepository> jobScoreReportRepository;
      private readonly Mock<IHttpContextAccessor> contextAccessor;
      private readonly IJobScoreReportService jobScoreReportService;
      private readonly Mock<IJobGraderRequestBuilder> jobGraderRequestBuilder;
      private readonly Mock<IJobGraderApiClient> jobGraderApiClient;

      public JobScoreReportServiceTest()
      {
         this.jobScoreReportRepository = new Mock<IJobScoreReportRepository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.jobGraderRequestBuilder = new Mock<IJobGraderRequestBuilder>();
         this.jobGraderApiClient = new Mock<IJobGraderApiClient>();
         this.jobScoreReportService = new JobScoreReportService(this.jobScoreReportRepository.Object, this.contextAccessor.Object, this.jobGraderRequestBuilder.Object, this.jobGraderApiClient.Object);
      }

      [Fact]
      public async Task SaveJobScoreInfo_GivenJobScoreDetail_CreatesEntry()
      {
         // Arrange
         JobGraderResponse jobGradeResponse = CommonHelper.GetJobGraderResponse();

         List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "testuser")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
         this.jobScoreReportRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()))
            .Returns(Task.FromResult(10));
         this.jobScoreReportRepository.Setup(x => x.SaveJobScoreDetails(It.IsAny<JobScoreReport>())).Returns(true);
         this.jobGraderRequestBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), false)).Returns(Task.FromResult(It.IsAny<JobGraderRequest>()));
         this.jobGraderApiClient.Setup(x => x.GradeJob(It.IsAny<JobGraderRequest>())).Returns(Task.FromResult(It.IsAny<JobGraderResponse>()));

         // Act
         bool result = await this.jobScoreReportService.SaveJobScoreInfo(jobGradeResponse, JobId, BidAlternateId);

         // Assert
         Assert.True(result);
         this.jobScoreReportRepository.Verify(x => x.GetSequenceNumber("JOB_SCORE", 1), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.GetSequenceNumber("JOB_SCORE_LINE", 1), Times.Once);
         this.jobGraderRequestBuilder.Verify(x => x.BuildJobGraderRequest(It.IsAny<int>(), JobId, BidAlternateId, false), Times.Once);
         this.jobGraderApiClient.Verify(x => x.GradeJob(It.IsAny<JobGraderRequest>()), Times.Once);
         this.jobScoreReportRepository.Verify(
             x => x.SaveJobScoreDetails(It.Is<JobScoreReport>(
            x => x.JobScore.LETTER_SCORE == "D" &&
            x.JobScore.JOB_SCORE_ID == 10 &&
            x.JobScore.CREATED_USER == "testuser" &&
            x.JobScoreLine.First().JOB_SCORE_ID == 10 &&
            x.JobScoreLine.First().JOB_SCORE_LINE_ID == 10 &&
            x.JobScoreLine.First().JOB_SIZE == "$50K - $100K" &&
            x.JobScoreLine.First().LETTER_SCORE == "A")), Times.Once);
      }

      [Fact]
      public async Task SaveJobScoreInfo_JobScoreEntryNotCreated_JobGraderApiNotCalledAndReturnsFalse()
      {
         // Arrange
         JobGraderResponse jobGradeResponse = CommonHelper.GetJobGraderResponse();

         List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "testuser")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
         this.jobScoreReportRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()))
            .Returns(Task.FromResult(10));
         this.jobScoreReportRepository.Setup(x => x.SaveJobScoreDetails(It.IsAny<JobScoreReport>())).Returns(false);

         // Act
         bool result = await this.jobScoreReportService.SaveJobScoreInfo(jobGradeResponse, JobId, BidAlternateId);

         // Assert
         Assert.False(result);
         this.jobScoreReportRepository.Verify(x => x.GetSequenceNumber("JOB_SCORE", 1), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.GetSequenceNumber("JOB_SCORE_LINE", 1), Times.Once);
         this.jobGraderRequestBuilder.Verify(x => x.BuildJobGraderRequest(It.IsAny<int>(), JobId, BidAlternateId, false), Times.Never);
         this.jobGraderApiClient.Verify(x => x.GradeJob(It.IsAny<JobGraderRequest>()), Times.Never);
         this.jobScoreReportRepository.Verify(x => x.SaveJobScoreDetails(It.IsAny<JobScoreReport>()), Times.Once);
      }

      [Fact]
      public async Task SaveJobScoreInfo_JobScoreEntryCreatedAndJobGraderApiThrowsException_ReturnsFalse()
      {
         // Arrange
         JobGraderResponse jobGradeResponse = CommonHelper.GetJobGraderResponse();

         List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "testuser")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
         this.jobScoreReportRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()))
            .Returns(Task.FromResult(10));
         this.jobScoreReportRepository.Setup(x => x.SaveJobScoreDetails(It.IsAny<JobScoreReport>())).Returns(true);
         this.jobGraderRequestBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), false)).Returns(Task.FromResult(It.IsAny<JobGraderRequest>()));
         this.jobGraderApiClient.Setup(x => x.GradeJob(It.IsAny<JobGraderRequest>())).ThrowsAsync(new Exception("Exception"));

         // Act
         bool result = await this.jobScoreReportService.SaveJobScoreInfo(jobGradeResponse, JobId, BidAlternateId);

         // Assert
         Assert.False(result);
         this.jobScoreReportRepository.Verify(x => x.GetSequenceNumber("JOB_SCORE", 1), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.GetSequenceNumber("JOB_SCORE_LINE", 1), Times.Once);
         this.jobGraderRequestBuilder.Verify(x => x.BuildJobGraderRequest(It.IsAny<int>(), JobId, BidAlternateId, false), Times.Once);
         this.jobGraderApiClient.Verify(x => x.GradeJob(It.IsAny<JobGraderRequest>()), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.SaveJobScoreDetails(It.IsAny<JobScoreReport>()), Times.Once);
      }
   }
}
