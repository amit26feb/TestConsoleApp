﻿// <copyright file="JobScoreCalculatorServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using JobScoringService.Configurations.AutoMapperConfiguration;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using JobScoringService.Test.Common;
   using Microsoft.Extensions.Configuration;
   using Moq;
   using Xunit;

   public class JobScoreCalculatorServiceTest
   {
      private readonly Mock<IJobGradeFactorRepository> jobGradeFactorRepository;
      private readonly JobScoreCalculatorService jobScoreCalculatorService;
      private readonly Mock<IJobScoreMasterRepository> jobScoreMasterRepository;
      private readonly Mock<IExcludedProductCodeRepository> excludedProductCodeRepository;
      private readonly Mock<IJobSizeRepository> jobSizeRepository;
      private readonly Mock<IProductApiClient> mockProductApiClient;
      private readonly Mock<IPricingApiClient> mockPricingApiClient;
      private readonly IMapper mapper;
      private readonly Mock<IConfiguration> configuration;
      private JobGraderResponse jobGraderResponse = new JobGraderResponse();
      private JobGraderRequest jobGraderRequest = new JobGraderRequest();
      private JobScoreTotal jobScoreTotal = new JobScoreTotal();
      private JobScoreQuintile jobScoreQuintile = new JobScoreQuintile();
      private IEnumerable<ExcludedProductCode> excludedProductCodes = new List<ExcludedProductCode>() { new ExcludedProductCode { ProductCode = "19" } };

      public JobScoreCalculatorServiceTest()
      {
         this.jobGradeFactorRepository = new Mock<IJobGradeFactorRepository>();
         this.jobScoreMasterRepository = new Mock<IJobScoreMasterRepository>();
         this.mockPricingApiClient = new Mock<IPricingApiClient>();
         this.excludedProductCodeRepository = new Mock<IExcludedProductCodeRepository>();
         this.jobSizeRepository = new Mock<IJobSizeRepository>();
         this.mockProductApiClient = new Mock<IProductApiClient>();
         this.jobScoreMasterRepository.SetupGet(x => x.JobGradeFactorRepository).Returns(this.jobGradeFactorRepository.Object);
         this.jobScoreMasterRepository.SetupGet(x => x.ExcludedProductCodeRepository).Returns(this.excludedProductCodeRepository.Object);
         this.jobScoreMasterRepository.SetupGet(x => x.JobSizeRepository).Returns(this.jobSizeRepository.Object);
         MapperConfiguration config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });
         this.mapper = config.CreateMapper();
         this.configuration = new Mock<IConfiguration>();
         this.configuration.Setup(x => x["tsmt-JobScoringService-CurrencyExchangeRate"]).Returns("1");
         this.jobScoreCalculatorService = new JobScoreCalculatorService(this.jobScoreMasterRepository.Object, this.mapper, this.mockProductApiClient.Object, this.configuration.Object, this.mockPricingApiClient.Object);
      }

      /// <summary>
      /// Get job grade factor
      /// </summary>
      /// <returns>Job grade factor</returns>
      [Fact]
      public async Task GetJobGradeFactor_HasRecords_ReturnsJobGradeFactor()
      {
         // Arrange
         JobGradeFactorModel jobGradeFactorModel = new JobGradeFactorModel()
         {
            JobGradeFactor = 0.001m
         };
         this.jobGradeFactorRepository.Setup(x => x.GetJobGradeFactor()).Returns(Task.FromResult(jobGradeFactorModel));

         // Act
         decimal result = await this.jobScoreCalculatorService.GetJobGradeFactor();

         // Assert
         Assert.Equal(jobGradeFactorModel.JobGradeFactor, result);
         this.jobGradeFactorRepository.Verify(x => x.GetJobGradeFactor(), Times.Once);
      }

      /// <summary>
      ///  Get excluded product codes - return excluded product codes
      /// </summary>
      /// <returns>Excluded product codes</returns>
      [Fact]
      public async Task GetExcludedProductCodes_HasRecords_ReturnsExcludedProductCodes()
      {
         // Arrange
         IEnumerable<ExcludedProductCode> excludedProductCodes = new List<ExcludedProductCode>() { new ExcludedProductCode { ProductCode = "0019" } };

         this.excludedProductCodeRepository.Setup(x => x.GetExcludedProductCodes()).Returns(Task.FromResult(excludedProductCodes));

         // Act
         IEnumerable<ExcludedProductCode> result = await this.jobScoreCalculatorService.GetExcludedProductCodes();

         // Assert
         Assert.Equal(excludedProductCodes, result);
         this.excludedProductCodeRepository.Verify(x => x.GetExcludedProductCodes(), Times.Once);
      }

      [Theory]
      [InlineData(0.32567, "E")]
      [InlineData(0.35424, "D")]
      [InlineData(0.36454, "C")]
      [InlineData(0.43674, "B")]
      [InlineData(0.46224, "A")]
      public void DetermineLetterScore_CalculationRequest_ReturnsJobScore(decimal ratedMultiplier, string expectedScore)
      {
         // Arrange
         JobScoreQuintile jobScoreQuintile = new JobScoreQuintile
         {
            StartE = 0.35m,
            StartD = 0.356m,
            StartC = 0.395m,
            StartB = 0.445m
         };

         // Act
         string result = this.jobScoreCalculatorService.DetermineLetterScore(jobScoreQuintile, ratedMultiplier);

         // Assert
         Assert.Equal(expectedScore, result);
      }

      /// <summary>
      /// Get job grade factor
      /// </summary>
      /// <returns>Empty job grade factor</returns>
      [Fact]
      public async Task GetJobGradeFactor_HasNoRecords_ReturnsEmptyJobGradeFactor()
      {
         // Arrange
         JobGradeFactorModel jobGradeFactorModel = new JobGradeFactorModel();
         this.jobGradeFactorRepository.Setup(x => x.GetJobGradeFactor()).Returns(Task.FromResult(jobGradeFactorModel));
         decimal jobGradeFactor = 0.0m;

         // Act
         decimal result = await this.jobScoreCalculatorService.GetJobGradeFactor();

         // Assert
         Assert.Equal(jobGradeFactor, result);
         this.jobGradeFactorRepository.Verify(x => x.GetJobGradeFactor(), Times.Once);
      }

      /// <summary>
      /// Get job size
      /// </summary>
      /// <returns>Job size</returns>
      [Fact]
      public async Task GetJobSize_HasRecords_ReturnsJobSize()
      {
         // Arrange
         JobSizeModel jobSizeModel = new JobSizeModel()
         {
            JobSize = "$10K - $20K",
            FromAmount = 10000,
            ToAmount = 20000
         };
         decimal jobSizeDollar = 15000;
         IEnumerable<JobSizeModel> jobSizeList = new List<JobSizeModel>() { jobSizeModel };
         this.jobSizeRepository.Setup(x => x.GetJobSizes()).Returns(Task.FromResult(jobSizeList));

         // Act
         string result = await this.jobScoreCalculatorService.GetJobSize(jobSizeDollar);

         // Assert
         Assert.Equal(jobSizeModel.JobSize, result);
         this.jobSizeRepository.Verify(x => x.GetJobSizes(), Times.Once);
      }

      /// <summary>
      /// Get job size
      /// </summary>
      /// <returns>Empty job size</returns>
      [Fact]
      public async Task GetJobSize_HasNoRecords_ReturnsEmptyString()
      {
         // Arrange
         JobSizeModel jobSizeModel = new JobSizeModel();
         decimal jobSizeDollar = 10000;
         IEnumerable<JobSizeModel> jobSizeList = new List<JobSizeModel>() { jobSizeModel };
         this.jobSizeRepository.Setup(x => x.GetJobSizes()).Returns(Task.FromResult(jobSizeList));

         // Act
         string result = await this.jobScoreCalculatorService.GetJobSize(jobSizeDollar);

         // Assert
         Assert.Empty(result);
         this.jobSizeRepository.Verify(x => x.GetJobSizes(), Times.Once);
      }

      /// <summary>
      /// Job score validation - returns true
      /// </summary>
      [Fact]
      public void JobScoreValidation_NotExcludedProductCodeAndUnAdjustedListPriceGreaterthanZero_ReturnsTrue()
      {
         // Arrange
         string prodCode = "123";
         decimal unAdjustedListPrice = 1.00m;

         // Act
         bool result = this.jobScoreCalculatorService.JobScoreValidation(prodCode, unAdjustedListPrice, this.excludedProductCodes);

         // Assert
         Assert.True(result);
      }

      /// <summary>
      /// Job score validation - returns false
      /// </summary>
      [Fact]
      public void JobScoreValidation_ExcludedProductCodeAndUnAdjustedListPriceIsZero_ReturnsFalse()
      {
         // Arrange
         string prodCode = "0019";
         decimal unAdjustedListPrice = 0.00m;

         // Act
         bool result = this.jobScoreCalculatorService.JobScoreValidation(prodCode, unAdjustedListPrice, this.excludedProductCodes);

         // Assert
         Assert.False(result);
      }

      /// <summary>
      ///  Get job grade - returns job grader response
      /// </summary>
      /// <returns>Job grader response</returns>
      [Fact]
      public async Task GetJobGrade_NotExcludedProductCodeAndUnAdjustedListPriceIsGreaterthanZero_ReturnsJobGraderResponse()
      {
         // Arrange
         JobGradeFactorModel jobGradeFactor = new JobGradeFactorModel { JobGradeFactor = 0.001m };
         this.jobGraderRequest = CommonHelper.GetJobGraderRequest();
         IEnumerable<JobSizeModel> jobSizeList = new List<JobSizeModel>() { CommonHelper.GetJobSize() };
         IEnumerable<ProductCodeViewModel> productCodeViewModels = CommonHelper.GetProductCodes();
         ProductCodeFilterViewModel productCodeFilterView = CommonHelper.GetProductCodeFilter();
         this.excludedProductCodeRepository.Setup(x => x.GetExcludedProductCodes()).Returns(Task.FromResult(this.excludedProductCodes));
         this.jobGradeFactorRepository.Setup(x => x.GetJobGradeFactor()).Returns(Task.FromResult(jobGradeFactor));
         this.jobSizeRepository.Setup(x => x.GetJobSizes()).Returns(Task.FromResult(jobSizeList));
         this.mockPricingApiClient.SetupSequence(x => x.GetJobScoreQuintile(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(CommonHelper.GetJobScoreQuintile())).Returns(Task.FromResult(CommonHelper.GetJobScoreQuintileForCutOffDisplay()));
         this.mockProductApiClient.Setup(x => x.GetProductCodes(It.IsAny<ProductCodeFilterViewModel>()))
            .Returns(Task.FromResult(productCodeViewModels));

         // Act
         JobGraderResponse result = await this.jobScoreCalculatorService.GetJobGrade(this.jobGraderRequest);

         // Assert
         Assert.Equal(result.Bid, this.jobGraderRequest.Bid);
         Assert.Equal("National", result.JobLineItems.ElementAt(0).RatedLocation);
         Assert.Equal("All Jobs", result.JobLineItems.ElementAt(0).RatedJobSize);
         Assert.Equal(0.483m, result.JobLineItems.ElementAt(0).RatedCutoffGrade1);
         Assert.Equal(0.442m, result.JobLineItems.ElementAt(0).RatedCutoffGrade2);
         Assert.Equal(0.432m, result.JobLineItems.ElementAt(0).RatedCutoffGrade3);
         Assert.Equal(0.425m, result.JobLineItems.ElementAt(0).RatedCutoffGrade4);
         Assert.Equal("0.483/1.0", result.JobLineItems.ElementAt(0).CutoffAltDisplayGrade1);
         Assert.Equal("0.442/1.0", result.JobLineItems.ElementAt(0).CutoffAltDisplayGrade2);
         Assert.Equal("0.432/1.0", result.JobLineItems.ElementAt(0).CutoffAltDisplayGrade3);
         Assert.Equal("0.425/1.0", result.JobLineItems.ElementAt(0).CutoffAltDisplayGrade4);
         Assert.Equal(0.381m, result.JobLineItems.ElementAt(0).RatedMultiplier);
         Assert.Equal("0.381/1.0", result.JobLineItems.ElementAt(0).RatedMultiplierAltDisplay);
         Assert.Equal("E", result.JobLineItems.ElementAt(0).LetterScore);
         Assert.Equal(0.543m, result.JobLineItems.ElementAt(1).RatedCutoffGrade1);
         Assert.Equal(0.483m, result.JobLineItems.ElementAt(1).RatedCutoffGrade2);
         Assert.Equal(0.723m, result.JobLineItems.ElementAt(1).RatedCutoffGrade3);
         Assert.Equal(0.328m, result.JobLineItems.ElementAt(1).RatedCutoffGrade4);
         Assert.Equal("0.543/1.0", result.JobLineItems.ElementAt(1).CutoffAltDisplayGrade1);
         Assert.Equal("0.483/1.0", result.JobLineItems.ElementAt(1).CutoffAltDisplayGrade2);
         Assert.Equal("0.723/1.0", result.JobLineItems.ElementAt(1).CutoffAltDisplayGrade3);
         Assert.Equal("0.358/0.916", result.JobLineItems.ElementAt(1).CutoffAltDisplayGrade4);
         Assert.Equal("Greenville Main Office", result.JobLocation);
         Assert.Equal("E", result.LetterScore);
         Assert.Equal(0.359m, result.RatedMultiplier);
         Assert.Equal(1550.33m, result.TotalEquipmentRevenue);
         Assert.Equal(1m, result.JobLineItems[0].QuantityLPAF);
         Assert.Equal(0.411m, result.JobLineItems[0].EnteredMultiplier);
         this.excludedProductCodeRepository.Verify(x => x.GetExcludedProductCodes(), Times.Once);
         this.jobGradeFactorRepository.Verify(x => x.GetJobGradeFactor(), Times.Once);
         this.jobSizeRepository.Verify(x => x.GetJobSizes(), Times.Once);
         this.mockPricingApiClient.Verify(x => x.GetJobScoreQuintile(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));
         this.mockProductApiClient.Verify(x => x.GetProductCodes(It.IsAny<ProductCodeFilterViewModel>()), Times.Once);
      }

      [Fact]
      public async Task GetJobGrade_ObsoleteProductCode_ReturnsNullLetterScore()
      {
         // Arrange
         JobGradeFactorModel jobGradeFactor = new JobGradeFactorModel { JobGradeFactor = 0.001m };
         this.jobGraderRequest = CommonHelper.GetJobGraderRequest();
         IEnumerable<JobSizeModel> jobSizeList = new List<JobSizeModel>() { CommonHelper.GetJobSize() };
         IEnumerable<ProductCodeViewModel> productCodeViewModels = CommonHelper.GetObsoleteProductCodes();
         ProductCodeFilterViewModel productCodeFilterView = CommonHelper.GetProductCodeFilter();
         this.excludedProductCodeRepository.Setup(x => x.GetExcludedProductCodes()).Returns(Task.FromResult(this.excludedProductCodes));
         this.jobGradeFactorRepository.Setup(x => x.GetJobGradeFactor()).Returns(Task.FromResult(jobGradeFactor));
         this.jobSizeRepository.Setup(x => x.GetJobSizes()).Returns(Task.FromResult(jobSizeList));
         this.mockProductApiClient.Setup(x => x.GetProductCodes(It.IsAny<ProductCodeFilterViewModel>()))
            .Returns(Task.FromResult(productCodeViewModels));

         // Act
         JobGraderResponse result = await this.jobScoreCalculatorService.GetJobGrade(this.jobGraderRequest);

         // Assert
         Assert.Null(result.JobLineItems.ElementAt(0).LetterScore);
         Assert.Null(result.LetterScore);
         this.excludedProductCodeRepository.Verify(x => x.GetExcludedProductCodes(), Times.Once);
         this.jobGradeFactorRepository.Verify(x => x.GetJobGradeFactor(), Times.Once);
         this.jobSizeRepository.Verify(x => x.GetJobSizes(), Times.Once);
         this.mockPricingApiClient.Verify(x => x.GetJobScoreQuintile(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never());
         this.mockProductApiClient.Verify(x => x.GetProductCodes(It.IsAny<ProductCodeFilterViewModel>()), Times.Once);
      }

      /// <summary>
      ///  Get job grade with error message for no data in quintile
      /// </summary>
      /// <returns>Zero cut off grades and error message</returns>
      [Fact]
      public async Task GetJobGrade_GivenQuintileRecordDoesNotExistForALineItem_ReturnsZeroCutOffGradesAndErrorMessage()
      {
         // Arrange
         string errorMessage = "Scoring lookup is empty for Job Size: $10K - $20K, Product Code: 0046, Sales Office: Madison Main Office";
         JobGradeFactorModel jobGradeFactor = new JobGradeFactorModel { JobGradeFactor = 0.001m };
         this.jobGraderRequest = CommonHelper.GetJobGraderRequestForEmptyQuintile();
         IEnumerable<JobSizeModel> jobSizeList = new List<JobSizeModel>() { CommonHelper.GetJobSize() };
         this.excludedProductCodeRepository.Setup(x => x.GetExcludedProductCodes()).Returns(Task.FromResult(this.excludedProductCodes));
         this.jobGradeFactorRepository.Setup(x => x.GetJobGradeFactor()).Returns(Task.FromResult(jobGradeFactor));
         this.jobSizeRepository.Setup(x => x.GetJobSizes()).Returns(Task.FromResult(jobSizeList));
         JobScoreQuintile jobScoreQuintile = null;
         this.mockPricingApiClient.Setup(x => x.GetJobScoreQuintile(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(jobScoreQuintile));

         // Act
         var result = await this.jobScoreCalculatorService.GetJobGrade(this.jobGraderRequest);

         // Assert
         Assert.Equal(0m, result.JobLineItems.ElementAt(0).RatedCutoffGrade1);
         Assert.Equal(0m, result.JobLineItems.ElementAt(0).RatedCutoffGrade2);
         Assert.Equal(0m, result.JobLineItems.ElementAt(0).RatedCutoffGrade3);
         Assert.Equal(0m, result.JobLineItems.ElementAt(0).RatedCutoffGrade4);
         Assert.Equal(errorMessage, result.ErrorMessage);
         this.mockPricingApiClient.Verify(x => x.GetJobScoreQuintile(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
      }

      [Theory]
      [InlineData(0.409, "0.409/1.0")]
      [InlineData(0.391, "0.391/1.0")]
      [InlineData(0.373, "0.373/1.0")]
      [InlineData(0.351, "0.358/0.98")]
      public void CalculateAlternativeDisplay_ForGivenNextScoreRatedMultiplierGreaterThanZero_ReturnsAlternativeDisplay(decimal nextScoreRatedMultiplier, string expectedAlternativeDisplay)
      {
         // Act
         string result = this.jobScoreCalculatorService.CalculateAlternativeDisplay(nextScoreRatedMultiplier);

         // Assert
         Assert.Equal(expectedAlternativeDisplay, result);
      }

      [Fact]
      public void CalculateAlternativeDisplay_ForGivenNextScoreRatedMultiplierEqualToZero_ReturnsEmptyString()
      {
         // Arrange
         decimal nextScoreRatedMultiplier = 0.0m;
         string alternativeDisplay = string.Empty;

         // Act
         string result = this.jobScoreCalculatorService.CalculateAlternativeDisplay(nextScoreRatedMultiplier);

         // Assert
         Assert.Equal(alternativeDisplay, result);
      }

      [Fact]
      public void AssignJobScoreTotalValues_AssignTotalValuesToJobScoreTotal_AssignedSuccessfully()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponse();
         this.jobScoreTotal = CommonHelper.GetJobScoreTotal();
         decimal lpafProduct = 0.1m;
         decimal totalQtyLPAFAndQtyShipLPAF = 3.567m;
         decimal totalEnteredDollar = 5.678m;
         decimal totalABBreakPointDollar = 845.1868m;
         decimal totalBCBreakPointDollar = 679.3833m;
         decimal totalCDBreakPointDollar = 456.6037m;
         decimal totalDEBreakPointDollar = 345.9233m;

         // Act
         this.jobScoreCalculatorService.AssignJobScoreTotalValues(this.jobScoreTotal, this.jobGraderResponse.JobLineItems[0], lpafProduct);

         // Assert
         Assert.Equal(this.jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF, totalQtyLPAFAndQtyShipLPAF);
         Assert.Equal(this.jobScoreTotal.TotalEnteredDollar, totalEnteredDollar);
         Assert.Equal(this.jobScoreTotal.TotalABBreakPointDollar, totalABBreakPointDollar);
         Assert.Equal(this.jobScoreTotal.TotalBCBreakPointDollar, totalBCBreakPointDollar);
         Assert.Equal(this.jobScoreTotal.TotalCDBreakPointDollar, totalCDBreakPointDollar);
         Assert.Equal(this.jobScoreTotal.TotalDEBreakPointDollar, totalDEBreakPointDollar);
      }

      [Fact]
      public void CalculateJobGrade_JobScoreTotalHasValue_CalculatedValuesInJobGradeResponse()
      {
         // Arrange
         this.jobScoreTotal = CommonHelper.GetJobScoreTotal();
         this.jobGraderResponse = CommonHelper.GetJobGraderResponse();
         this.jobScoreQuintile = CommonHelper.GetJobScoreQuintile();
         decimal jobGradeFactor = 0.001m;
         decimal ratedMultiplier = 127.972m;
         string ratedMultiplierAltDisplay = "127.972/1.0";
         decimal startB = 0.483m;
         decimal startC = 0.442m;
         decimal startD = 0.432m;
         decimal startE = 0.425m;
         string letterScore = "D";
         decimal ratedCutoffGrade1 = 243.769m;
         decimal ratedCutoffGrade2 = 195.947m;
         decimal ratedCutoffGrade3 = 131.690m;
         decimal ratedCutoffGrade4 = 99.766m;
         string cutoffAltDisplayGrade1 = "243.769/1.0";
         string cutoffAltDisplayGrade2 = "195.947/1.0";
         string cutoffAltDisplayGrade3 = "131.69/1.0";
         string cutoffAltDisplayGrade4 = "99.766/1.0";
         decimal stepDownRatedCutoffGrade1 = 243.768m;
         decimal stepDownRatedCutoffGrade2 = 195.946m;
         decimal stepDownRatedCutoffGrade3 = 131.689m;
         decimal stepDownRatedCutoffGrade4 = 99.766m;
         string stepDownCutoffAltDisplayGrade1 = "243.768/1.0";
         string stepDownCutoffAltDisplayGrade2 = "195.946/1.0";
         string stepDownCutoffAltDisplayGrade3 = "131.689/1.0";
         string stepDownCutoffAltDisplayGrade4 = "99.766/1.0";
         decimal enteredABDollarNextScore = 401.47m;
         decimal enteredBCDollarNextScore = 235.67m;
         decimal enteredCDDollarNextScore = 12.89m;
         decimal enteredDEDollarNextScore = -97.79m;
         decimal enteredABDollarStepDownScore = 401.47m;
         decimal enteredBCDollarStepDownScore = 235.67m;
         decimal enteredCDDollarStepDownScore = 12.89m;
         decimal enteredDEDollarStepDownScore = -97.79m;

         // Act
         this.jobScoreCalculatorService.CalculateJobGrade(this.jobScoreTotal, this.jobGraderResponse, jobGradeFactor);

         // Assert
         Assert.Equal(this.jobGraderResponse.RatedMultiplier, ratedMultiplier);
         Assert.Equal(this.jobGraderResponse.RatedMultiplierAltDisplay, ratedMultiplierAltDisplay);
         Assert.Equal(this.jobScoreQuintile.StartB, startB);
         Assert.Equal(this.jobScoreQuintile.StartC, startC);
         Assert.Equal(this.jobScoreQuintile.StartD, startD);
         Assert.Equal(this.jobScoreQuintile.StartE, startE);
         Assert.Equal(this.jobGraderResponse.LetterScore, letterScore);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade1, ratedCutoffGrade1);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade2, ratedCutoffGrade2);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade3, ratedCutoffGrade3);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade4, ratedCutoffGrade4);
         Assert.Equal(this.jobGraderResponse.CutoffAltDisplayGrade1, cutoffAltDisplayGrade1);
         Assert.Equal(this.jobGraderResponse.CutoffAltDisplayGrade2, cutoffAltDisplayGrade2);
         Assert.Equal(this.jobGraderResponse.CutoffAltDisplayGrade3, cutoffAltDisplayGrade3);
         Assert.Equal(this.jobGraderResponse.CutoffAltDisplayGrade4, cutoffAltDisplayGrade4);
         Assert.Equal(this.jobGraderResponse.StepDownRatedCutoffGrade1, stepDownRatedCutoffGrade1);
         Assert.Equal(this.jobGraderResponse.StepDownRatedCutoffGrade2, stepDownRatedCutoffGrade2);
         Assert.Equal(this.jobGraderResponse.StepDownRatedCutoffGrade3, stepDownRatedCutoffGrade3);
         Assert.Equal(this.jobGraderResponse.StepDownRatedCutoffGrade4, stepDownRatedCutoffGrade4);
         Assert.Equal(this.jobGraderResponse.StepDownCutoffAltDisplayGrade1, stepDownCutoffAltDisplayGrade1);
         Assert.Equal(this.jobGraderResponse.StepDownCutoffAltDisplayGrade2, stepDownCutoffAltDisplayGrade2);
         Assert.Equal(this.jobGraderResponse.StepDownCutoffAltDisplayGrade3, stepDownCutoffAltDisplayGrade3);
         Assert.Equal(this.jobGraderResponse.StepDownCutoffAltDisplayGrade4, stepDownCutoffAltDisplayGrade4);
         Assert.Equal(this.jobGraderResponse.EnteredABDollarNextScore, enteredABDollarNextScore);
         Assert.Equal(this.jobGraderResponse.EnteredBCDollarNextScore, enteredBCDollarNextScore);
         Assert.Equal(this.jobGraderResponse.EnteredCDDollarNextScore, enteredCDDollarNextScore);
         Assert.Equal(this.jobGraderResponse.EnteredDEDollarNextScore, enteredDEDollarNextScore);
         Assert.Equal(this.jobGraderResponse.EnteredABDollarStepDownScore, enteredABDollarStepDownScore);
         Assert.Equal(this.jobGraderResponse.EnteredBCDollarStepDownScore, enteredBCDollarStepDownScore);
         Assert.Equal(this.jobGraderResponse.EnteredCDDollarStepDownScore, enteredCDDollarStepDownScore);
         Assert.Equal(this.jobGraderResponse.EnteredDEDollarStepDownScore, enteredDEDollarStepDownScore);
      }

      [Fact]
      public async Task GetJobGrade_AllLineItemsAreExcludedForScoring_JobScoreNotCalculated()
      {
         // Arrange
         JobSizeFactorModel jobSizeFactor = new JobSizeFactorModel { JobSizeFactor = 0.85m };
         JobGradeFactorModel jobGradeFactor = new JobGradeFactorModel { JobGradeFactor = 0.001m };
         this.jobGraderRequest = CommonHelper.GetJobGraderRequestWithExcludedProdCode();
         IEnumerable<JobSizeModel> jobSizeList = new List<JobSizeModel>() { CommonHelper.GetJobSize() };
         this.excludedProductCodeRepository.Setup(x => x.GetExcludedProductCodes()).Returns(Task.FromResult(this.excludedProductCodes));
         this.jobGradeFactorRepository.Setup(x => x.GetJobGradeFactor()).Returns(Task.FromResult(jobGradeFactor));
         this.jobSizeRepository.Setup(x => x.GetJobSizes()).Returns(Task.FromResult(jobSizeList));

         // Act
         JobGraderResponse result = await this.jobScoreCalculatorService.GetJobGrade(this.jobGraderRequest);

         // Assert
         Assert.Null(result.LetterScore);
         this.excludedProductCodeRepository.Verify(x => x.GetExcludedProductCodes(), Times.Once);
         this.jobGradeFactorRepository.Verify(x => x.GetJobGradeFactor(), Times.Once);
         this.jobSizeRepository.Verify(x => x.GetJobSizes(), Times.Once);
         this.mockPricingApiClient.Verify(x => x.GetJobScoreQuintile(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
      }

      [Fact]
      public void CalculateDisplayDollarAmount_OnLetterScoreValueAsA_DisplayDollarAmountValuesInJobGradeResponse()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreA();
         string letterScore = "A";
         decimal displayABDollarAmount = -154.63m;
         decimal displayBCDollarAmount = -4639.94m;
         decimal displayCDDollarAmount = -7423.93m;
         decimal displayDEDollarAmount = -10517.25m;

         // Act
         this.jobScoreCalculatorService.CalculateDisplayDollarAmount(this.jobGraderResponse);

         // Assert
         Assert.Equal(this.jobGraderResponse.LetterScore, letterScore);
         Assert.Equal(this.jobGraderResponse.DisplayABDollarAmount, displayABDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayBCDollarAmount, displayBCDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayCDDollarAmount, displayCDDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayDEDollarAmount, displayDEDollarAmount);
      }

      [Fact]
      public void CalculateDisplayDollarAmount_OnLetterScoreValueAsB_DisplayDollarAmountValuesInJobGradeResponse()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreB();
         string letterScore = "B";
         decimal displayABDollarAmount = 4485.29m;
         decimal displayBCDollarAmount = -154.69m;
         decimal displayCDDollarAmount = -2938.68m;
         decimal displayDEDollarAmount = -6032m;

         // Act
         this.jobScoreCalculatorService.CalculateDisplayDollarAmount(this.jobGraderResponse);

         // Assert
         Assert.Equal(this.jobGraderResponse.LetterScore, letterScore);
         Assert.Equal(this.jobGraderResponse.DisplayABDollarAmount, displayABDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayBCDollarAmount, displayBCDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayCDDollarAmount, displayCDDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayDEDollarAmount, displayDEDollarAmount);
      }

      [Fact]
      public void CalculateDisplayDollarAmount_OnLetterScoreValueAsC_DisplayDollarAmountValuesInJobGradeResponse()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreC();
         string letterScore = "C";
         decimal displayABDollarAmount = 4640m;
         decimal displayBCDollarAmount = 154.69m;
         decimal displayCDDollarAmount = -2783.97m;
         decimal displayDEDollarAmount = -5877.29m;

         // Act
         this.jobScoreCalculatorService.CalculateDisplayDollarAmount(this.jobGraderResponse);

         // Assert
         Assert.Equal(this.jobGraderResponse.LetterScore, letterScore);
         Assert.Equal(this.jobGraderResponse.DisplayABDollarAmount, displayABDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayBCDollarAmount, displayBCDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayCDDollarAmount, displayCDDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayDEDollarAmount, displayDEDollarAmount);
      }

      [Fact]
      public void CalculateDisplayDollarAmount_OnLetterScoreValueAsD_DisplayDollarAmountValuesInJobGradeResponse()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponse();
         string letterScore = "D";
         decimal displayABDollarAmount = 401.47m;
         decimal displayBCDollarAmount = 235.67m;
         decimal displayCDDollarAmount = 12.89m;
         decimal displayDEDollarAmount = -97.79m;

         // Act
         this.jobScoreCalculatorService.CalculateDisplayDollarAmount(this.jobGraderResponse);

         // Assert
         Assert.Equal(this.jobGraderResponse.LetterScore, letterScore);
         Assert.Equal(this.jobGraderResponse.DisplayABDollarAmount, displayABDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayBCDollarAmount, displayBCDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayCDDollarAmount, displayCDDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayDEDollarAmount, displayDEDollarAmount);
      }

      [Fact]
      public void CalculateDisplayDollarAmount_OnLetterScoreValueAsE_DisplayDollarAmountValuesInJobGradeResponse()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreE();
         string letterScore = "E";
         decimal displayABDollarAmount = 58290.62m;
         decimal displayBCDollarAmount = 54578.64m;
         decimal displayCDDollarAmount = 51175.99m;
         decimal displayDEDollarAmount = 47618.67m;

         // Act
         this.jobScoreCalculatorService.CalculateDisplayDollarAmount(this.jobGraderResponse);

         // Assert
         Assert.Equal(this.jobGraderResponse.LetterScore, letterScore);
         Assert.Equal(this.jobGraderResponse.DisplayABDollarAmount, displayABDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayBCDollarAmount, displayBCDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayCDDollarAmount, displayCDDollarAmount);
         Assert.Equal(this.jobGraderResponse.DisplayDEDollarAmount, displayDEDollarAmount);
      }

      [Fact]
      public void CalculateRatedCutOff_WhenLetterScoreIsA_SetsRatedCutOffValue()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreA();
         decimal jobGradeFactor = 0.001m;
         decimal ratedCutoffGrade1 = 0.483m;
         decimal ratedCutoffGrade2 = 0.442m;
         decimal ratedCutoffGrade3 = 0.432m;
         decimal ratedCutoffGrade4 = 0.425m;

         // Act
         this.jobScoreCalculatorService.CalculateRatedCutOff(jobGradeFactor, this.jobGraderResponse, CommonHelper.GetJobScoreQuintile());

         // Assert
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade1, ratedCutoffGrade1);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade2, ratedCutoffGrade2);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade3, ratedCutoffGrade3);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade4, ratedCutoffGrade4);
         Assert.Equal("0.483/1.0", this.jobGraderResponse.CutoffAltDisplayGrade1);
         Assert.Equal("0.442/1.0", this.jobGraderResponse.CutoffAltDisplayGrade2);
         Assert.Equal("0.432/1.0", this.jobGraderResponse.CutoffAltDisplayGrade3);
         Assert.Equal("0.425/1.0", this.jobGraderResponse.CutoffAltDisplayGrade4);
      }

      [Fact]
      public void CalculateRatedCutOff_WhenLetterScoreIsB_SetsRatedCutOffValue()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreB();
         decimal jobGradeFactor = 0.001m;
         decimal ratedCutoffGrade1 = 0.484m;
         decimal ratedCutoffGrade2 = 0.442m;
         decimal ratedCutoffGrade3 = 0.432m;
         decimal ratedCutoffGrade4 = 0.425m;

         // Act
         this.jobScoreCalculatorService.CalculateRatedCutOff(jobGradeFactor, this.jobGraderResponse, CommonHelper.GetJobScoreQuintile());

         // Assert
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade1, ratedCutoffGrade1);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade2, ratedCutoffGrade2);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade3, ratedCutoffGrade3);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade4, ratedCutoffGrade4);
         Assert.Equal("0.484/1.0", this.jobGraderResponse.CutoffAltDisplayGrade1);
         Assert.Equal("0.442/1.0", this.jobGraderResponse.CutoffAltDisplayGrade2);
         Assert.Equal("0.432/1.0", this.jobGraderResponse.CutoffAltDisplayGrade3);
         Assert.Equal("0.425/1.0", this.jobGraderResponse.CutoffAltDisplayGrade4);
      }

      [Fact]
      public void CalculateRatedCutOff_WhenLetterScoreIsC_SetsRatedCutOffValue()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreC();
         decimal jobGradeFactor = 0.001m;
         decimal ratedCutoffGrade1 = 0.484m;
         decimal ratedCutoffGrade2 = 0.443m;
         decimal ratedCutoffGrade3 = 0.432m;
         decimal ratedCutoffGrade4 = 0.425m;

         // Act
         this.jobScoreCalculatorService.CalculateRatedCutOff(jobGradeFactor, this.jobGraderResponse, CommonHelper.GetJobScoreQuintile());

         // Assert
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade1, ratedCutoffGrade1);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade2, ratedCutoffGrade2);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade3, ratedCutoffGrade3);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade4, ratedCutoffGrade4);
         Assert.Equal("0.484/1.0", this.jobGraderResponse.CutoffAltDisplayGrade1);
         Assert.Equal("0.443/1.0", this.jobGraderResponse.CutoffAltDisplayGrade2);
         Assert.Equal("0.432/1.0", this.jobGraderResponse.CutoffAltDisplayGrade3);
         Assert.Equal("0.425/1.0", this.jobGraderResponse.CutoffAltDisplayGrade4);
      }

      [Fact]
      public void CalculateRatedCutOff_WhenLetterScoreIsD_SetsRatedCutOffValue()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponse();
         decimal jobGradeFactor = 0.001m;
         decimal ratedCutoffGrade1 = 0.484m;
         decimal ratedCutoffGrade2 = 0.443m;
         decimal ratedCutoffGrade3 = 0.433m;
         decimal ratedCutoffGrade4 = 0.425m;

         // Act
         this.jobScoreCalculatorService.CalculateRatedCutOff(jobGradeFactor, this.jobGraderResponse, CommonHelper.GetJobScoreQuintile());

         // Assert
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade1, ratedCutoffGrade1);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade2, ratedCutoffGrade2);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade3, ratedCutoffGrade3);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade4, ratedCutoffGrade4);
         Assert.Equal("0.484/1.0", this.jobGraderResponse.CutoffAltDisplayGrade1);
         Assert.Equal("0.443/1.0", this.jobGraderResponse.CutoffAltDisplayGrade2);
         Assert.Equal("0.433/1.0", this.jobGraderResponse.CutoffAltDisplayGrade3);
         Assert.Equal("0.425/1.0", this.jobGraderResponse.CutoffAltDisplayGrade4);
      }

      [Fact]
      public void CalculateRatedCutOff_WhenLetterScoreIsE_SetsRatedCutOffValue()
      {
         // Arrange
         this.jobGraderResponse = CommonHelper.GetJobGraderResponseForLetterScoreE();
         decimal jobGradeFactor = 0.001m;
         decimal ratedCutoffGrade1 = 0.484m;
         decimal ratedCutoffGrade2 = 0.443m;
         decimal ratedCutoffGrade3 = 0.433m;
         decimal ratedCutoffGrade4 = 0.426m;

         // Act
         this.jobScoreCalculatorService.CalculateRatedCutOff(jobGradeFactor, this.jobGraderResponse, CommonHelper.GetJobScoreQuintile());

         // Assert
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade1, ratedCutoffGrade1);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade2, ratedCutoffGrade2);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade3, ratedCutoffGrade3);
         Assert.Equal(this.jobGraderResponse.RatedCutoffGrade4, ratedCutoffGrade4);
         Assert.Equal("0.484/1.0", this.jobGraderResponse.CutoffAltDisplayGrade1);
         Assert.Equal("0.443/1.0", this.jobGraderResponse.CutoffAltDisplayGrade2);
         Assert.Equal("0.433/1.0", this.jobGraderResponse.CutoffAltDisplayGrade3);
         Assert.Equal("0.426/1.0", this.jobGraderResponse.CutoffAltDisplayGrade4);
      }
   }
}
