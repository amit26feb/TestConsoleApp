// <copyright file="OrderCreationHostedServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System;
   using System.Threading.Tasks;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using Xunit;

   /// <summary>
   /// Provides the methods to verify the business logic in SQS queue
   /// </summary>
   public class OrderCreationHostedServiceTest
   {
      private readonly OrderCreationHostedService hostedService;

      private readonly Mock<ILogger<OrderCreationHostedService>> logger;
      private readonly Mock<IServiceProvider> serviceProvider;
      private readonly Mock<IOrderCreationProcessService> orderCreationProcessService;

      /// <summary>
      /// Initializes a new instance of the <see cref="OrderCreationHostedServiceTest"/> class.
      /// </summary>
      public OrderCreationHostedServiceTest()
      {
         this.logger = new Mock<ILogger<OrderCreationHostedService>>();
         this.serviceProvider = new Mock<IServiceProvider>();
         this.orderCreationProcessService = new Mock<IOrderCreationProcessService>();

         Settings settings = new Settings() { IHostingServiceTimeIntervalInSeconds = 10, ScoringExemptSpaNumberBucket = "kirbyBuckets", ScoringExemptSpaNumberCsvFilename = "funky.csv", MaxRetryAttempts = 5 };
         Mock<IOptions<Settings>> jobScoringSettings = new Mock<IOptions<Settings>>();
         jobScoringSettings.Setup(ap => ap.Value).Returns(settings);

         this.hostedService = new OrderCreationHostedService(
            this.logger.Object,
            jobScoringSettings.Object,
            this.serviceProvider.Object,
            this.orderCreationProcessService.Object);
      }

      /// <summary>
      /// Verify for concurrent process completion.
      /// </summary>
      [Fact]
      public void ConcurrentProcess_Execute()
      {
         // Arrange
         object obj = new object();

         Mock<IServiceScope> serviceScope = new Mock<IServiceScope>();
         serviceScope.Setup(x => x.ServiceProvider).Returns(this.serviceProvider.Object);

         Mock<IServiceScopeFactory> serviceScopeFactory = new Mock<IServiceScopeFactory>();
         serviceScopeFactory.Setup(x => x.CreateScope()).Returns(serviceScope.Object);
         this.serviceProvider.Setup(x => x.GetService(typeof(IServiceScopeFactory))).Returns(serviceScopeFactory.Object);

         this.orderCreationProcessService.Setup(x => x.ImportRecentlyTransmittedOrders())
            .Returns(Task.CompletedTask);

         // Act
         Task result = Task.Run(() => this.hostedService.ConcurrentProcess(obj));
         result.Wait();

         // Assert
         Assert.True(result.IsCompleted);
      }

      /// <summary>
      /// Verify for stop async completion.
      /// </summary>
      [Fact]
      public void StopAsync_Completes()
      {
         // Arrange
         Mock<IServiceScope> serviceScope = new Mock<IServiceScope>();
         serviceScope.Setup(x => x.ServiceProvider).Returns(this.serviceProvider.Object);

         Mock<IServiceScopeFactory> serviceScopeFactory = new Mock<IServiceScopeFactory>();
         serviceScopeFactory.Setup(x => x.CreateScope()).Returns(serviceScope.Object);
         this.serviceProvider.Setup(x => x.GetService(typeof(IServiceScopeFactory))).Returns(serviceScopeFactory.Object);

         // Act
         Task result = Task.Run(() => this.hostedService.StopAsync(new System.Threading.CancellationToken(false)));
         result.Wait();

         // Assert
         Assert.True(result.IsCompleted);
      }
   }
}
