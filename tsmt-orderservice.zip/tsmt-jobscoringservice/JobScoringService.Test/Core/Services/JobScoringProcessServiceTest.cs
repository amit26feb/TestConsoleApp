﻿// <copyright file="JobScoringProcessServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using JobScoringService.Configurations.AutoMapperConfiguration;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using JobScoringService.Test.Common;
   using Moq;
   using Xunit;

   public class JobScoringProcessServiceTest
   {
      private const int DrAddressId = 10;
      private const int JobId = 222;
      private const int SalesOrderId = 44410;
      private const int HqtrCreditJobId = 99988;
      private const int BidAlternateId = 666555;
      private const string SpaNumber = "19-123456";

      private readonly Mock<IJobScoreRepository> repository;
      private readonly IJobScoringProcessService service;
      private readonly JobScoringProcessService jobScoringProcessService;
      private readonly Mock<IJobScoreReportRepository> jobScoreReportRepository;
      private readonly IEnumerable<int> bidAlternateIds;
      private readonly IMapper mapper;

      public JobScoringProcessServiceTest()
      {
         this.repository = new Mock<IJobScoreRepository>();
         this.jobScoreReportRepository = new Mock<IJobScoreReportRepository>();
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });
         this.mapper = config.CreateMapper();
         this.service = new JobScoringProcessService(this.repository.Object, this.mapper, this.jobScoreReportRepository.Object);
         this.jobScoringProcessService = new JobScoringProcessService(this.repository.Object, this.mapper, this.jobScoreReportRepository.Object);
         this.bidAlternateIds = new List<int>()
         {
            1234,
            5678
         };
      }

      [Fact]
      public async Task BuildProcessEntries_NoStageRecords_DoesNothing()
      {
         // Arrange
         IEnumerable<SalesOrder> salesOrders = new List<SalesOrder>();
         this.repository.Setup(x => x.GetNewTransmittedOrders())
            .Returns(Task.FromResult(salesOrders));

         // Act
         await this.service.BuildProcessEntries();

         // Assert
         this.repository.Verify(x => x.GetNewTransmittedOrders(), Times.Once);
         this.repository.Verify(x => x.DoesCreditJobExist(It.IsAny<int>()), Times.Never);
         this.repository.Verify(x => x.CreateCreditJobProcessEntry(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
         this.repository.Verify(x => x.DeleteCreditJobFromStaging(It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task BuildProcessEntries_ExistingCreditJob_DoesNotCreateEntry()
      {
         // Arrange
         IEnumerable<SalesOrder> salesOrders = new List<SalesOrder>()
         {
            new SalesOrder()
            {
               SalesOrderId = JobScoringProcessServiceTest.SalesOrderId,
               JobId = JobScoringProcessServiceTest.JobId,
               HqtrCreditJobId = JobScoringProcessServiceTest.HqtrCreditJobId,
               DrAddressId = JobScoringProcessServiceTest.DrAddressId,
            }
         };
         this.repository.Setup(x => x.GetNewTransmittedOrders())
            .Returns(Task.FromResult(salesOrders));

         this.repository.Setup(x => x.DoesCreditJobExist(It.IsAny<int>()))
            .Returns(Task.FromResult(true));

         // Act
         await this.service.BuildProcessEntries();

         // Assert
         this.repository.Verify(x => x.GetNewTransmittedOrders(), Times.Once);
         this.repository.Verify(x => x.DoesCreditJobExist(JobScoringProcessServiceTest.HqtrCreditJobId), Times.Once);
         this.repository.Verify(x => x.CreateCreditJobProcessEntry(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
         this.repository.Verify(x => x.DeleteCreditJobFromStaging(JobScoringProcessServiceTest.HqtrCreditJobId), Times.Once);
      }

      [Fact]
      public async Task BuildProcessEntries_NewCreditJob_CreatesEntry()
      {
         // Arrange
         IEnumerable<SalesOrder> salesOrders = new List<SalesOrder>()
         {
            new SalesOrder()
            {
               SalesOrderId = JobScoringProcessServiceTest.SalesOrderId,
               JobId = JobScoringProcessServiceTest.JobId,
               HqtrCreditJobId = JobScoringProcessServiceTest.HqtrCreditJobId,
               DrAddressId = JobScoringProcessServiceTest.DrAddressId,
               BidAlternateId = JobScoringProcessServiceTest.BidAlternateId,
               SpaNumber = JobScoringProcessServiceTest.SpaNumber,
            }
         };
         this.repository.Setup(x => x.GetNewTransmittedOrders())
            .Returns(Task.FromResult(salesOrders));

         this.repository.Setup(x => x.DoesCreditJobExist(It.IsAny<int>()))
            .Returns(Task.FromResult(false));

         // Act
         await this.service.BuildProcessEntries();

         // Assert
         this.repository.Verify(x => x.GetNewTransmittedOrders(), Times.Once);
         this.repository.Verify(x => x.DoesCreditJobExist(JobScoringProcessServiceTest.HqtrCreditJobId), Times.Once);
         this.repository.Verify(x => x.CreateCreditJobProcessEntry(JobScoringProcessServiceTest.DrAddressId, JobScoringProcessServiceTest.JobId, JobScoringProcessServiceTest.HqtrCreditJobId, JobScoringProcessServiceTest.BidAlternateId, JobScoringProcessServiceTest.SpaNumber), Times.Once);
         this.repository.Verify(x => x.DeleteCreditJobFromStaging(JobScoringProcessServiceTest.HqtrCreditJobId), Times.Once);
      }

      [Fact]
      public async Task BuildProcessEntries_MultipleSalesOrders_GetGrouped()
      {
         // Arrange
         IEnumerable<SalesOrder> salesOrders = new List<SalesOrder>()
         {
            new SalesOrder()
            {
               SalesOrderId = JobScoringProcessServiceTest.SalesOrderId,
               HqtrCreditJobId = JobScoringProcessServiceTest.HqtrCreditJobId,
               DrAddressId = JobScoringProcessServiceTest.DrAddressId,
            },
            new SalesOrder()
            {
               SalesOrderId = JobScoringProcessServiceTest.SalesOrderId + 1,
               HqtrCreditJobId = JobScoringProcessServiceTest.HqtrCreditJobId,
               DrAddressId = JobScoringProcessServiceTest.DrAddressId,
            },
            new SalesOrder()
            {
               SalesOrderId = JobScoringProcessServiceTest.SalesOrderId + 2,
               HqtrCreditJobId = JobScoringProcessServiceTest.HqtrCreditJobId + 1,
               DrAddressId = JobScoringProcessServiceTest.DrAddressId,
            },
         };
         this.repository.Setup(x => x.GetNewTransmittedOrders())
            .Returns(Task.FromResult(salesOrders));

         this.repository.Setup(x => x.DoesCreditJobExist(JobScoringProcessServiceTest.HqtrCreditJobId))
            .Returns(Task.FromResult(true));
         this.repository.Setup(x => x.DoesCreditJobExist(JobScoringProcessServiceTest.HqtrCreditJobId + 1))
            .Returns(Task.FromResult(false));

         // Act
         await this.service.BuildProcessEntries();

         // Assert
         this.repository.Verify(x => x.GetNewTransmittedOrders(), Times.Once);
         this.repository.Verify(x => x.DoesCreditJobExist(It.IsAny<int>()), Times.Exactly(2));
         this.repository.Verify(x => x.CreateCreditJobProcessEntry(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()), Times.Once);
         this.repository.Verify(x => x.DeleteCreditJobFromStaging(It.IsAny<int>()), Times.Exactly(2));
      }

      [Fact]
      public async Task GetJobsToGrade_Execute_ReturnsData()
      {
         // Arrange
         int maxNumRetries = 5;
         int minutesPauseBeforeRetryingCreditJob = 3;
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>();
         this.repository.Setup(x => x.GetCreditJobsToGrade(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(creditJobs));

         // Act
         IEnumerable<CreditJob> results = await this.service.GetJobsToGrade(maxNumRetries, minutesPauseBeforeRetryingCreditJob);

         // Assert
         Assert.Equal(creditJobs, results);
         this.repository.Verify(x => x.GetCreditJobsToGrade(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
      }

      [Fact]
      public async Task MarkAsProcessed_Execute_Successful()
      {
         // Arrange
         this.repository.Setup(x => x.MarkCreditJobForProcessing(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(true));

         // Act
         await this.service.MarkAsProcessed(JobScoringProcessServiceTest.HqtrCreditJobId);

         // Assert
         this.repository.Verify(x => x.MarkCreditJobForProcessing(JobScoringProcessServiceTest.HqtrCreditJobId, 0), Times.Once);
      }

      [Fact]
      public async Task RecordGrade_Execute_ReturnsData()
      {
         // Arrange
         CreditJobScoreProcessViewModel creditJobScore = new CreditJobScoreProcessViewModel()
         {
            HqtrCreditJobId = JobScoringProcessServiceTest.HqtrCreditJobId,
            ExcludedFromTopper = false,
            LetterScore = "Y"
         };
         this.repository.Setup(x => x.SetCreditJobScoreResult(It.IsAny<CreditJobScoreProcessViewModel>()))
            .Returns(Task.CompletedTask);

         // Act
         await this.service.RecordGrade(creditJobScore);

         // Assert
         this.repository.Verify(x => x.SetCreditJobScoreResult(creditJobScore), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGrade_RetrievedSuccessfully_ReturnsJobAggregatedGradeViewModel()
      {
         // Arrange
         int jobId = 10256;
         int bidAlternateId = 20;
         JobAggregatedGrade jobAggregatedGrade = CommonHelper.GetJobAggregatedGradeModel();
         this.repository.Setup(x => x.GetJobAggregatedGrade(jobId, bidAlternateId)).Returns(Task.FromResult(jobAggregatedGrade));

         // Act
         JobAggregatedGradeViewModel result = await this.service.GetJobAggregatedGrade(jobId, bidAlternateId);

         // Assert
         Assert.True(this.CompareJobAggregatedScoreModels(jobAggregatedGrade, result));
         this.repository.Verify(x => x.GetJobAggregatedGrade(jobId, bidAlternateId));
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_HasJobAggregatedGradeData_ReturnsJobAggregatedGradeViewModels()
      {
         // Arrange
         IEnumerable<int> bidAlternateIdsForUnorderedProduct = new List<int>()
         {
            1234
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGradesForUnorderedProduct = new List<JobAggregatedGrade>()
         {
            CommonHelper.GetAggregatedGrade("A", DateTime.Parse("2020-09-30"), 1234, 1),
            CommonHelper.GetAggregatedGrade("Z", DateTime.Parse("2020-10-30"), 1234, 2)
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGradesForOrderedProduct = new List<JobAggregatedGrade>()
         {
            CommonHelper.GetAggregatedGrade("Z", DateTime.Parse("2020-10-30"), 5678, 2),
            CommonHelper.GetAggregatedGrade("A", DateTime.Parse("2020-09-30"), 5678, 2)
         };
         IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGrade = new List<JobAggregatedGradeViewModel>()
         {
            CommonHelper.GetJobAggregatedGradeViewModel("A", DateTime.Parse("2020-09-30"), 5678),
            CommonHelper.GetJobAggregatedGradeViewModel("Z", DateTime.Parse("2020-10-30"), 1234)
         };
         this.repository.Setup(x => x.GetJobAggregatedGradeListForOrderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(jobAggregatedGradesForOrderedProduct));
         this.jobScoreReportRepository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.jobScoreReportRepository.Setup(x => x.GetJobAggregatedGradeListForUnorderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(jobAggregatedGradesForUnorderedProduct));

         // Act
         IEnumerable<JobAggregatedGradeViewModel> result = await this.jobScoringProcessService.GetJobAggregatedGradeList(DrAddressId, JobId, this.bidAlternateIds);

         // Assert
         // mapping of JobAggregatedGrade to JobAggregatedGradeViewModel has been verified in automapper test
         Assert.Equal(result.Count(), jobAggregatedGrade.Count());
         Assert.True(this.CompareJobAggregatedScoreViewModels(jobAggregatedGrade.First(), result.First()));
         Assert.True(this.CompareJobAggregatedScoreViewModels(jobAggregatedGrade.ElementAt(1), result.ElementAt(1)));
         this.repository.Verify(x => x.GetJobAggregatedGradeListForOrderedProduct(JobId, this.bidAlternateIds), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.GetJobAggregatedGradeListForUnorderedProduct(JobId, bidAlternateIdsForUnorderedProduct), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_NoGradesForOrderedProductExists_ReturnsJobAggregatedGradesForUnorderedProduct()
      {
         // Arrange
         int jobId = 10256;
         int drAddressId = 142;
         IEnumerable<JobAggregatedGrade> jobAggregatedGradesForUnorderedProduct = new List<JobAggregatedGrade>()
         {
            CommonHelper.GetJobAggregatedGradeModel()
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGradesForOrderedProduct = Enumerable.Empty<JobAggregatedGrade>();
         IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGradeList = new List<JobAggregatedGradeViewModel>()
         {
            CommonHelper.GetJobAggregatedGradeViewModel()
         };
         this.repository.Setup(x => x.GetJobAggregatedGradeListForOrderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(jobAggregatedGradesForOrderedProduct));
         this.jobScoreReportRepository.Setup(x => x.GetJobAggregatedGradeListForUnorderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(jobAggregatedGradesForUnorderedProduct));

         // Act
         IEnumerable<JobAggregatedGradeViewModel> result = await this.jobScoringProcessService.GetJobAggregatedGradeList(drAddressId, jobId, this.bidAlternateIds);

         // Assert
         // mapping of JobAggregatedGrade to JobAggregatedGradeViewModel has been verified in automapper test
         Assert.Single(result);
         Assert.True(this.CompareJobAggregatedScoreViewModels(jobAggregatedGradeList.First(), result.First()));
         this.repository.Verify(x => x.GetJobAggregatedGradeListForOrderedProduct(jobId, this.bidAlternateIds), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.GetJobAggregatedGradeListForUnorderedProduct(jobId, this.bidAlternateIds), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_NoGradesForUnorderedProductExists_ReturnsJobAggregatedGradesForOrderedProduct()
      {
         // Arrange
         int jobId = 10256;
         int drAddressId = 142;
         IEnumerable<int> bidAlternateIdForUnordered = new List<int>()
         {
            5678
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGradesForOrderedProduct = new List<JobAggregatedGrade>()
         {
            CommonHelper.GetJobAggregatedGradeModel()
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGradesForUnorderedProduct = Enumerable.Empty<JobAggregatedGrade>();
         IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGradeList = new List<JobAggregatedGradeViewModel>()
         {
            CommonHelper.GetJobAggregatedGradeViewModel()
         };
         this.repository.Setup(x => x.GetJobAggregatedGradeListForOrderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(jobAggregatedGradesForOrderedProduct));
         this.jobScoreReportRepository.Setup(x => x.GetJobAggregatedGradeListForUnorderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(jobAggregatedGradesForUnorderedProduct));

         // Act
         IEnumerable<JobAggregatedGradeViewModel> result = await this.jobScoringProcessService.GetJobAggregatedGradeList(drAddressId, jobId, this.bidAlternateIds);

         // Assert
         // mapping of JobAggregatedGrade to JobAggregatedGradeViewModel has been verified in automapper test
         Assert.Single(result);
         Assert.True(this.CompareJobAggregatedScoreViewModels(jobAggregatedGradeList.First(), result.First()));
         this.repository.Verify(x => x.GetJobAggregatedGradeListForOrderedProduct(jobId, this.bidAlternateIds), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.GetJobAggregatedGradeListForUnorderedProduct(jobId, bidAlternateIdForUnordered), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_EmptyUnorderedBidAlternateId_ReturnsJobAggregatedGradesForOrderedProduct()
      {
         // Arrange
         int jobId = 10256;
         int drAddressId = 142;
         IEnumerable<int> bidAlternateIdForOrdered = new List<int>()
         {
            1234,
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGradesForOrderedProduct = new List<JobAggregatedGrade>()
         {
            CommonHelper.GetJobAggregatedGradeModel()
         };
         IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGradeList = new List<JobAggregatedGradeViewModel>()
         {
            CommonHelper.GetJobAggregatedGradeViewModel()
         };
         this.repository.Setup(x => x.GetJobAggregatedGradeListForOrderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(jobAggregatedGradesForOrderedProduct));

         // Act
         IEnumerable<JobAggregatedGradeViewModel> result = await this.jobScoringProcessService.GetJobAggregatedGradeList(drAddressId, jobId, bidAlternateIdForOrdered);

         // Assert
         // mapping of JobAggregatedGrade to JobAggregatedGradeViewModel has been verified in automapper test
         Assert.Single(result);
         Assert.True(this.CompareJobAggregatedScoreViewModels(jobAggregatedGradeList.First(), result.First()));
         this.repository.Verify(x => x.GetJobAggregatedGradeListForOrderedProduct(jobId, bidAlternateIdForOrdered), Times.Once);
         this.jobScoreReportRepository.Verify(x => x.GetJobAggregatedGradeListForUnorderedProduct(It.IsAny<int>(), It.IsAny<IEnumerable<int>>()), Times.Never);
      }

      /// <summary>
      /// Function to check mapping of JobAggregatedGrade to JobAggregatedGradeViewModel
      /// </summary>
      /// <param name="jobAggregatedGrade">Job aggregated grade model</param>
      /// <param name="jobAggregatedGradeViewModel">Job aggregated grade view model</param>
      /// <returns>True if validated successfully else false</returns>
      private bool CompareJobAggregatedScoreViewModels(JobAggregatedGradeViewModel jobAggregatedGrade, JobAggregatedGradeViewModel jobAggregatedGradeViewModel) =>
         jobAggregatedGrade.LetterScore == jobAggregatedGradeViewModel.LetterScore &&
         jobAggregatedGrade.BidAlternateId == jobAggregatedGradeViewModel.BidAlternateId &&
         jobAggregatedGrade.CreatedDate == jobAggregatedGradeViewModel.CreatedDate;

      /// <summary>
      /// Function to check mapping of JobAggregatedGrade to JobAggregatedGradeViewModel
      /// </summary>
      /// <param name="jobAggregatedGrade">Job aggregated grade model</param>
      /// <param name="jobAggregatedGradeViewModel">Job aggregated grade view model</param>
      /// <returns>True if validated successfully else false</returns>
      private bool CompareJobAggregatedScoreModels(JobAggregatedGrade jobAggregatedGrade, JobAggregatedGradeViewModel jobAggregatedGradeViewModel) => jobAggregatedGrade.LETTER_SCORE == jobAggregatedGradeViewModel.LetterScore
                                                 && jobAggregatedGrade.CREATED_DATE == jobAggregatedGradeViewModel.CreatedDate;
   }
}
