﻿// <copyright file="OrderCreationProcessServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class OrderCreationProcessServiceTest
   {
      private const int DrAddressId = 10;
      private const int JobId = 222;
      private const int HqtrJobId = 100222;
      private const int SalesOrderId = 44410;
      private const int HqtrCreditJobId = 99988;
      private const int BidAlternateId = 6655;
      private const int HqtrBidAlternateId = 1006655;
      private const string SpaNumber = "19-123456";

      private readonly Mock<ILogger<JobScoringHostedService>> logger;
      private readonly Mock<IOrderRepository> orderRepository;
      private readonly Mock<IJobScoreRepository> scoreRepository;
      private readonly IOrderCreationProcessService service;

      public OrderCreationProcessServiceTest()
      {
         this.logger = new Mock<ILogger<JobScoringHostedService>>();
         this.orderRepository = new Mock<IOrderRepository>();
         this.scoreRepository = new Mock<IJobScoreRepository>();
         this.service = new OrderCreationProcessService(
            this.logger.Object,
            this.scoreRepository.Object,
            this.orderRepository.Object);
      }

      [Fact]
      public async Task ImportRecentlyTransmittedOrders_NoOrdersRecords_DoesNothing()
      {
         // Arrange
         DateTime lastExecuteDate = DateTime.Now;
         IEnumerable<EnterpriseSalesOrder> salesOrders = new List<EnterpriseSalesOrder>();
         this.scoreRepository.Setup(x => x.GetLastExecution())
            .Returns(Task.FromResult(lastExecuteDate));
         this.orderRepository.Setup(x => x.GetNewTransmittedOrders(It.IsAny<DateTime>()))
            .Returns(Task.FromResult(salesOrders));

         // calc adjusted execution date
         DateTime queryDate = lastExecuteDate.AddMinutes(-5);

         // Act
         await this.service.ImportRecentlyTransmittedOrders();

         // Assert
         this.scoreRepository.Verify(x => x.GetLastExecution(), Times.Once);
         this.orderRepository.Verify(x => x.GetNewTransmittedOrders(queryDate), Times.Once);
         this.scoreRepository.Verify(x => x.CreateStagingEntry(It.IsAny<SalesOrder>()), Times.Never);
      }

      [Fact]
      public async Task ImportRecentlyTransmittedOrders_NewSalesOrder_CreatesEntry()
      {
         // Arrange
         IEnumerable<EnterpriseSalesOrder> enterpriseSalesOrders = new List<EnterpriseSalesOrder>()
         {
            new EnterpriseSalesOrder()
            {
               SalesOrdId = OrderCreationProcessServiceTest.SalesOrderId,
               JobId = OrderCreationProcessServiceTest.HqtrJobId,
               CreditJobId = OrderCreationProcessServiceTest.HqtrCreditJobId,
               BidAlternateId = OrderCreationProcessServiceTest.HqtrBidAlternateId,
               SpaNumber = OrderCreationProcessServiceTest.SpaNumber,
               OriginatingDrAddress = OrderCreationProcessServiceTest.DrAddressId,
            }
         };
         Bid bid = new Bid()
         {
            BidAlternateId = OrderCreationProcessServiceTest.BidAlternateId,
         };
         JobLookup job = new JobLookup()
         {
            JobId = OrderCreationProcessServiceTest.JobId,
            DrAddressId = OrderCreationProcessServiceTest.DrAddressId
         };
         DateTime lastExecuteDate = DateTime.Now;

         this.scoreRepository.Setup(x => x.GetLastExecution())
            .Returns(Task.FromResult(lastExecuteDate));

         this.scoreRepository.Setup(x => x.GetJob(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(job));

         this.scoreRepository.Setup(x => x.GetBid(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(bid));

         this.orderRepository.Setup(x => x.GetNewTransmittedOrders(It.IsAny<DateTime>()))
            .Returns(Task.FromResult(enterpriseSalesOrders));

         // Act
         await this.service.ImportRecentlyTransmittedOrders();

         // Assert
         this.scoreRepository.Verify(x => x.GetLastExecution(), Times.Once);
         this.orderRepository.Verify(x => x.GetNewTransmittedOrders(It.IsAny<DateTime>()), Times.Once);
         this.scoreRepository.Verify(x => x.GetJob(OrderCreationProcessServiceTest.DrAddressId, OrderCreationProcessServiceTest.HqtrJobId), Times.Once);
         this.scoreRepository.Verify(x => x.GetBid(OrderCreationProcessServiceTest.DrAddressId, OrderCreationProcessServiceTest.HqtrBidAlternateId), Times.Once);
         this.scoreRepository.Verify(x => x.CreateStagingEntry(It.IsAny<SalesOrder>()), Times.Once);
      }

      [Fact]
      public async Task ImportRecentlyTransmittedOrders_NoLocalBid_DoesNotInsert()
      {
         // Arrange
         IEnumerable<EnterpriseSalesOrder> enterpriseSalesOrders = new List<EnterpriseSalesOrder>()
         {
            new EnterpriseSalesOrder()
            {
               SalesOrdId = OrderCreationProcessServiceTest.SalesOrderId,
               JobId = OrderCreationProcessServiceTest.HqtrJobId,
               CreditJobId = OrderCreationProcessServiceTest.HqtrCreditJobId,
               BidAlternateId = OrderCreationProcessServiceTest.HqtrBidAlternateId,
               SpaNumber = OrderCreationProcessServiceTest.SpaNumber,
               OriginatingDrAddress = OrderCreationProcessServiceTest.DrAddressId,
            }
         };
         JobLookup job = new JobLookup()
         {
            JobId = OrderCreationProcessServiceTest.JobId,
            DrAddressId = OrderCreationProcessServiceTest.DrAddressId
         };
         DateTime lastExecuteDate = DateTime.Now;

         this.scoreRepository.Setup(x => x.GetLastExecution())
            .Returns(Task.FromResult(lastExecuteDate));

         this.scoreRepository.Setup(x => x.GetJob(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(job));

         this.scoreRepository.Setup(x => x.GetBid(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult<Bid>(null));

         this.orderRepository.Setup(x => x.GetNewTransmittedOrders(It.IsAny<DateTime>()))
            .Returns(Task.FromResult(enterpriseSalesOrders));

         // Act
         await this.service.ImportRecentlyTransmittedOrders();

         // Assert
         this.scoreRepository.Verify(x => x.GetLastExecution(), Times.Once);
         this.orderRepository.Verify(x => x.GetNewTransmittedOrders(It.IsAny<DateTime>()), Times.Once);
         this.scoreRepository.Verify(x => x.GetJob(OrderCreationProcessServiceTest.DrAddressId, OrderCreationProcessServiceTest.HqtrJobId), Times.Once);
         this.scoreRepository.Verify(x => x.GetBid(OrderCreationProcessServiceTest.DrAddressId, OrderCreationProcessServiceTest.HqtrBidAlternateId), Times.Once);
         this.scoreRepository.Verify(x => x.CreateStagingEntry(It.IsAny<SalesOrder>()), Times.Never);
      }

      [Fact]
      public async Task ImportRecentlyTransmittedOrders_NoLocalJob_DoesNotInsert()
      {
         // Arrange
         IEnumerable<EnterpriseSalesOrder> enterpriseSalesOrders = new List<EnterpriseSalesOrder>()
         {
            new EnterpriseSalesOrder()
            {
               SalesOrdId = OrderCreationProcessServiceTest.SalesOrderId,
               JobId = OrderCreationProcessServiceTest.HqtrJobId,
               CreditJobId = OrderCreationProcessServiceTest.HqtrCreditJobId,
               BidAlternateId = OrderCreationProcessServiceTest.HqtrBidAlternateId,
               SpaNumber = OrderCreationProcessServiceTest.SpaNumber,
               OriginatingDrAddress = OrderCreationProcessServiceTest.DrAddressId,
            }
         };
         DateTime lastExecuteDate = DateTime.Now;

         this.scoreRepository.Setup(x => x.GetLastExecution())
            .Returns(Task.FromResult(lastExecuteDate));

         this.scoreRepository.Setup(x => x.GetJob(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult<JobLookup>(null));

         this.orderRepository.Setup(x => x.GetNewTransmittedOrders(It.IsAny<DateTime>()))
            .Returns(Task.FromResult(enterpriseSalesOrders));

         // Act
         await this.service.ImportRecentlyTransmittedOrders();

         // Assert
         this.scoreRepository.Verify(x => x.GetLastExecution(), Times.Once);
         this.orderRepository.Verify(x => x.GetNewTransmittedOrders(It.IsAny<DateTime>()), Times.Once);
         this.scoreRepository.Verify(x => x.GetJob(OrderCreationProcessServiceTest.DrAddressId, OrderCreationProcessServiceTest.HqtrJobId), Times.Once);
         this.scoreRepository.Verify(x => x.GetBid(OrderCreationProcessServiceTest.DrAddressId, OrderCreationProcessServiceTest.HqtrBidAlternateId), Times.Never);
         this.scoreRepository.Verify(x => x.CreateStagingEntry(It.IsAny<SalesOrder>()), Times.Never);
      }
   }
}
