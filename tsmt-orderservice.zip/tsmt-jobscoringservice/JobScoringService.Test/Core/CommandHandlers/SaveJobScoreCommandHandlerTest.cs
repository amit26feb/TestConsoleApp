﻿// <copyright file="SaveJobScoreCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.CommandHandlers
{
   using System.Threading;
   using System.Threading.Tasks;
   using JobScoringService.Core.CommandHandlers;
   using JobScoringService.Core.Commands;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using JobScoringService.Test.Common;
   using Moq;
   using Xunit;

   public class SaveJobScoreCommandHandlerTest
   {
      private readonly Mock<IJobScoreReportService> mockJobScoreReportService;
      private readonly SaveJobScoreCommandHandler saveJobScoreCommandHandler;
      private readonly CancellationToken cancellationToken = default;

      /// <summary>
      /// Initializes a new instance of the <see cref="SaveJobScoreCommandHandlerTest"/> class.
      /// </summary>
      public SaveJobScoreCommandHandlerTest()
      {
         this.mockJobScoreReportService = new Mock<IJobScoreReportService>();
         this.saveJobScoreCommandHandler = new SaveJobScoreCommandHandler(this.mockJobScoreReportService.Object);
      }

      [Fact]
      public async Task Handle_SaveJobScore_Success()
      {
         // Arrange
         int jobId = 529;
         int bidAlternateId = 7219;
         JobGraderResponse jobGraderResponse = CommonHelper.GetJobGraderResponse();

         SaveJobScoreCommand saveJobScoreCommand = new SaveJobScoreCommand(jobId, bidAlternateId, jobGraderResponse);
         this.mockJobScoreReportService.Setup(x => x.SaveJobScoreInfo(It.IsAny<JobGraderResponse>(), It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(true));

         // Act
         bool result = await this.saveJobScoreCommandHandler.Handle(saveJobScoreCommand, this.cancellationToken);

         // Assert
         Assert.True(result);
         this.mockJobScoreReportService.Verify(x => x.SaveJobScoreInfo(saveJobScoreCommand.JobGraderResponse, saveJobScoreCommand.JobId, saveJobScoreCommand.BidAlternateId), Times.Once);
      }
   }
}
