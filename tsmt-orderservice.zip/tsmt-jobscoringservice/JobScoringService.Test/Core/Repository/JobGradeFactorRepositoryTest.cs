﻿// <copyright file="JobGradeFactorRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>using System;

namespace JobScoringService.Test.Core.Repository
{
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;
   using Moq;
   using Xunit;

   public class JobGradeFactorRepositoryTest
   {
      private readonly JobGradeFactorRepository jobGradeFactorRepository;
      private readonly Mock<IDocumentDBConnectionFactory> documentDbConnectionFactoryMock;
      private readonly Mock<IOptions<Settings>> settings;
      private readonly Mock<IDocumentDBProvider> documentDbProviderMock;
      private readonly Mock<IDocumentDBCollection<JobGradeFactorModel>> documentDbCollectionMock;

      public JobGradeFactorRepositoryTest()
      {
         this.documentDbProviderMock = new Mock<IDocumentDBProvider>();
         this.settings = new Mock<IOptions<Settings>>();
         Settings appSetting = new Settings() { DocumentDBConnectionString = "DummyConnectionString", DocumentDBJobGradeFactorCollectionName = "TSMT-JobScoring" };
         this.settings.Setup(app => app.Value).Returns(appSetting);

         this.documentDbCollectionMock = new Mock<IDocumentDBCollection<JobGradeFactorModel>>();
         this.documentDbConnectionFactoryMock = new Mock<IDocumentDBConnectionFactory>();
         this.documentDbConnectionFactoryMock.Setup(x => x.GetCollection<JobGradeFactorModel>(appSetting.DocumentDBJobGradeFactorCollectionName)).Returns(this.documentDbCollectionMock.Object);
         this.jobGradeFactorRepository = new JobGradeFactorRepository(this.documentDbConnectionFactoryMock.Object, this.settings.Object);
      }

      /// <summary>
      /// Get job grade factor
      /// </summary>
      /// <returns>Job grade factor model</returns>
      [Fact]
      public async Task GetJobGradeFactor_HasRecords_ReturnsJobGradeFactor()
      {
         // Arrange
         JobGradeFactorModel jobGradeFactorModel = new JobGradeFactorModel()
         {
            JobGradeFactor = 0.001m
         };
         this.documentDbCollectionMock.Setup(x => x.FindOneAsync(It.IsAny<FilterDefinition<JobGradeFactorModel>>(), null)).Returns(Task.FromResult(jobGradeFactorModel));

         // Act
         var result = await this.jobGradeFactorRepository.GetJobGradeFactor();

         // Assert
         Assert.Equal(jobGradeFactorModel, result);
         this.documentDbCollectionMock.Verify(x => x.FindOneAsync(It.IsAny<FilterDefinition<JobGradeFactorModel>>(), null), Times.Once);
      }
   }
}
