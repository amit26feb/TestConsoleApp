﻿// <copyright file="JobScoreReportRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using DataAccess.Core.Abstractions;
   using JobScoringService.Common.Constants;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Test.Common;
   using Microsoft.Extensions.Logging;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   public class JobScoreReportRepositoryTest
   {
      private readonly Mock<IRepository<JobScore>> repository;
      private readonly IJobScoreReportRepository jobScoreReportRepository;
      private readonly Mock<IConnectionFactory> connectionFactory;
      private readonly Mock<ILogger<string>> logger;

      public JobScoreReportRepositoryTest()
      {
         this.repository = new Mock<IRepository<JobScore>>();
         this.logger = new Mock<ILogger<string>>();
         this.connectionFactory = new Mock<IConnectionFactory>();
         this.jobScoreReportRepository = new JobScoreReportRepository(this.repository.Object, this.logger.Object, this.connectionFactory.Object);
      }

      [Fact]
      public async Task GetSequenceNumber_ForGivenTableName_ReturnsSequenceNumber()
      {
         // Arrange
         int generatedSequenceNumber = 34;
         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(generatedSequenceNumber));
         int howManyToReserve = 10;

         // Act
         int result = await this.jobScoreReportRepository.GetSequenceNumber("JOB_REPORT", howManyToReserve);

         // Assert
         Assert.Equal(result, generatedSequenceNumber);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public void HonorDrAddressId_GivenDrAddressId_ExecutedSuccessfully()
      {
         // Arrange
         int drAddressId = 12;
         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

         // Act
         this.jobScoreReportRepository.HonorDrAddressId(drAddressId);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGradeListForOrderedProduct_RetrievedSuccessfully_ReturnsJobAggregatedScoreModels()
      {
         // Arrange
         int jobId = 10256;
         IEnumerable<int> bidAlternateIds = new List<int>()
         {
            1234
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGrades = new List<JobAggregatedGrade>()
         {
            CommonHelper.GetJobAggregatedGradeModel()
         };
         this.repository.Setup(x => x.GetListAsync<JobAggregatedGrade>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobAggregatedGrades));

         // Act
         IEnumerable<JobAggregatedGrade> result = await this.jobScoreReportRepository.GetJobAggregatedGradeListForUnorderedProduct(jobId, bidAlternateIds);

         // Assert
         Assert.Equal(jobAggregatedGrades, result);
         this.repository.Verify(
             x => x.GetListAsync<JobAggregatedGrade>(JobScoreQueries.GetJobAggregatedGradeForUnorderedProduct, It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId
             && (IEnumerable<int>)y.GetType().GetProperty("BID_ALTERNATE_IDS").GetValue(y) == bidAlternateIds)), Times.Once);
      }
   }
}
