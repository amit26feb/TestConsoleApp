﻿// <copyright file="JobScoreQuintileRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Repository
{
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;
   using Moq;
   using Xunit;

   public class JobScoreQuintileRepositoryTest
   {
      private readonly JobScoreQuintileRepository jobScoreQuintileRepository;
      private readonly Mock<IDocumentDBConnectionFactory> documentDbConnectionFactoryMock;
      private readonly Mock<IOptions<Settings>> settings;
      private readonly Mock<IDocumentDBCollection<JobScoreQuintile>> documentDbCollectionMock;

      public JobScoreQuintileRepositoryTest()
      {
         this.settings = new Mock<IOptions<Settings>>();
         Settings appSetting = new Settings() { DocumentDBConnectionString = "DummyConnectionString", DocumentDBScoreQuintileCollectionName = "TSMT-JobScoring" };
         this.settings.Setup(app => app.Value).Returns(appSetting);

         this.documentDbCollectionMock = new Mock<IDocumentDBCollection<JobScoreQuintile>>();
         this.documentDbConnectionFactoryMock = new Mock<IDocumentDBConnectionFactory>();
         this.documentDbConnectionFactoryMock.Setup(x => x.GetCollection<JobScoreQuintile>(appSetting.DocumentDBScoreQuintileCollectionName)).Returns(this.documentDbCollectionMock.Object);
         this.jobScoreQuintileRepository = new JobScoreQuintileRepository(this.documentDbConnectionFactoryMock.Object, this.settings.Object);
      }
   }
}
