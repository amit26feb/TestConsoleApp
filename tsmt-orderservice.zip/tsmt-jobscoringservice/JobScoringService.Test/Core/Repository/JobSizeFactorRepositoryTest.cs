﻿// <copyright file="JobSizeFactorRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>using System;

namespace JobScoringService.Test.Core.Repository
{
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;
   using Moq;
   using Xunit;

   public class JobSizeFactorRepositoryTest
   {
      private readonly JobSizeFactorRepository jobSizeFactorRepository;
      private readonly Mock<IDocumentDBConnectionFactory> documentDbConnectionFactoryMock;
      private readonly Mock<IOptions<Settings>> settings;
      private readonly Mock<IDocumentDBProvider> documentDbProviderMock;
      private readonly Mock<IDocumentDBCollection<JobSizeFactorModel>> documentDbCollectionMock;

      public JobSizeFactorRepositoryTest()
      {
         this.documentDbProviderMock = new Mock<IDocumentDBProvider>();
         this.settings = new Mock<IOptions<Settings>>();
         Settings appSetting = new Settings() { DocumentDBConnectionString = "DummyConnectionString", DocumentDBJobSizeFactorCollectionName = "TSMT-JobScoring" };
         this.settings.Setup(app => app.Value).Returns(appSetting);

         this.documentDbCollectionMock = new Mock<IDocumentDBCollection<JobSizeFactorModel>>();
         this.documentDbConnectionFactoryMock = new Mock<IDocumentDBConnectionFactory>();
         this.documentDbConnectionFactoryMock.Setup(x => x.GetCollection<JobSizeFactorModel>(appSetting.DocumentDBJobSizeFactorCollectionName)).Returns(this.documentDbCollectionMock.Object);
         this.jobSizeFactorRepository = new JobSizeFactorRepository(this.documentDbConnectionFactoryMock.Object, this.settings.Object);
      }

      /// <summary>
      /// Get job size factor
      /// </summary>
      /// <returns>Job size factor model</returns>
      [Fact]
      public async Task GetJobSizeFactor_HasRecords_ReturnsJobSizeFactor()
      {
         // Arrange
         JobSizeFactorModel jobSizeFactorModel = new JobSizeFactorModel()
         {
            JobSizeFactor = 0.85m
         };
         this.documentDbCollectionMock.Setup(x => x.FindOneAsync(It.IsAny<FilterDefinition<JobSizeFactorModel>>(), null)).Returns(Task.FromResult(jobSizeFactorModel));

         // Act
         JobSizeFactorModel result = await this.jobSizeFactorRepository.GetJobSizeFactor();

         // Assert
         Assert.Equal(jobSizeFactorModel, result);
         this.documentDbCollectionMock.Verify(x => x.FindOneAsync(It.IsAny<FilterDefinition<JobSizeFactorModel>>(), null), Times.Once);
      }
   }
}
