﻿// <copyright file="OrderRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Common.Constants;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   public class OrderRepositoryTest
   {
      private readonly Mock<IRepository<EnterpriseSalesOrder>> repository;
      private readonly IOrderRepository orderRepository;

      private readonly int salesOrderId = 33;

      public OrderRepositoryTest()
      {
         this.repository = new Mock<IRepository<EnterpriseSalesOrder>>();
         this.orderRepository = new OrderRepository(this.repository.Object);
      }

      [Fact]
      public async Task GetCreditJobsToGrade_HasRecords_ReturnsEnumerable()
      {
         // Arrange
         DateTime queryDate = DateTime.Now;
         IEnumerable<EnterpriseSalesOrder> salesOrders = new List<EnterpriseSalesOrder>() { new EnterpriseSalesOrder() { SalesOrdId = this.salesOrderId } };

         this.repository.Setup(x => x.ExecuteListQuery<EnterpriseSalesOrder>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(salesOrders));

         // Act
         IEnumerable<EnterpriseSalesOrder> result = await this.orderRepository.GetNewTransmittedOrders(queryDate);

         // Assert
         Assert.Equal(salesOrders, result);
         this.repository.Verify(x => x.ExecuteListQuery<EnterpriseSalesOrder>(OrderQueries.GetNewOrders, It.IsAny<object>()), Times.Once);
      }
   }
}
