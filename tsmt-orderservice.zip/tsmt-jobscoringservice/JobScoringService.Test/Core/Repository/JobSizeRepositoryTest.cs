﻿// <copyright file="JobSizeRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>using System;

namespace JobScoringService.Test.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Text;
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;
   using Moq;
   using Xunit;

   public class JobSizeRepositoryTest
   {
      private readonly JobSizeRepository jobSizeRepository;
      private readonly Mock<IDocumentDBConnectionFactory> documentDBConnectionFactory;
      private readonly Mock<IOptions<Settings>> settings;
      private readonly Mock<IDocumentDBProvider> documentDBProviderMock;
      private readonly Mock<IDocumentDBCollection<JobSizeModel>> documentDBCollectionMock;

      public JobSizeRepositoryTest()
      {
         this.documentDBProviderMock = new Mock<IDocumentDBProvider>();
         this.settings = new Mock<IOptions<Settings>>();
         Settings appSetting = new Settings() { DocumentDBConnectionString = "DummyConnectionString", DocumentDBJobSizeCollectionName = "TSMT-JobScoring" };
         this.settings.Setup(app => app.Value).Returns(appSetting);
         this.documentDBCollectionMock = new Mock<IDocumentDBCollection<JobSizeModel>>();
         this.documentDBConnectionFactory = new Mock<IDocumentDBConnectionFactory>();
         this.documentDBConnectionFactory.Setup(x => x.GetCollection<JobSizeModel>(appSetting.DocumentDBJobSizeCollectionName)).Returns(this.documentDBCollectionMock.Object);
         this.jobSizeRepository = new JobSizeRepository(this.documentDBConnectionFactory.Object, this.settings.Object);
      }

      /// <summary>
      /// Get job size
      /// </summary>
      /// <returns>List of job size</returns>
      [Fact]
      public async Task GetJobSize_ForGivenJobSizeDollar_ReturnsJobSize()
      {
         // Arrange
         JobSizeModel jobSizeModel = new JobSizeModel()
         {
            FromAmount = 10000,
            ToAmount = 20000,
            JobSize = "$10K-$20K"
         };

         IEnumerable<JobSizeModel> jobSizeList = new List<JobSizeModel>() { jobSizeModel };
         this.documentDBCollectionMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<JobSizeModel>>(), It.IsAny<FindOptions<JobSizeModel>>())).Returns(Task.FromResult(jobSizeList));

         // Act
         IEnumerable<JobSizeModel> result = await this.jobSizeRepository.GetJobSizes();

         // Assert
         Assert.Equal(jobSizeList, result);
         this.documentDBCollectionMock.Verify(x => x.FindAsync(It.IsAny<FilterDefinition<JobSizeModel>>(), It.IsAny<FindOptions<JobSizeModel>>()), Times.Once);
      }
   }
}
