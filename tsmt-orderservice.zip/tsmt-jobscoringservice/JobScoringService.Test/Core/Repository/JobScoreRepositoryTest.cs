﻿// <copyright file="JobScoreRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Common.Constants;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ViewModels;
   using JobScoringService.Test.Common;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   public class JobScoreRepositoryTest
   {
      private readonly Mock<IRepository<SalesOrder>> repository;
      private readonly IJobScoreRepository scoreRepository;

      private readonly int drAddressId = 33;
      private readonly int jobId = 555;
      private readonly int hqtrCreditJobId = 1234;
      private readonly int bidAlternateId = 666777;
      private readonly string spaNumber = "19-123456";

      public JobScoreRepositoryTest()
      {
         this.repository = new Mock<IRepository<SalesOrder>>();
         this.scoreRepository = new JobScoreRepository(this.repository.Object);
      }

      [Fact]
      public async Task GetCreditJobsToGrade_HasRecords_ReturnsEnumerable()
      {
         // Arrange
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>() { new CreditJob() { HqtrCreditJobId = this.hqtrCreditJobId } };
         int maxNumRetries = 5;
         int minutesPauseBeforeRetryingCreditJob = 3;

         this.repository.Setup(x => x.ExecuteListQuery<CreditJob>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(creditJobs));

         // Act
         IEnumerable<CreditJob> result = await this.scoreRepository.GetCreditJobsToGrade(maxNumRetries, minutesPauseBeforeRetryingCreditJob);

         // Assert
         Assert.Equal(creditJobs, result);
         this.repository.Verify(x => x.ExecuteListQuery<CreditJob>(JobScoreQueries.GetJobScorePendingProcess, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetNewTransmittedOrders_HasRecords_ReturnsEnumerable()
      {
         // Arrange
         IEnumerable<SalesOrder> salesOrders = new List<SalesOrder>() { new SalesOrder() };

         this.repository.Setup(x => x.ExecuteListQuery<SalesOrder>(It.IsAny<string>()))
            .Returns(Task.FromResult(salesOrders));

         // Act
         IEnumerable<SalesOrder> results = await this.scoreRepository.GetNewTransmittedOrders();

         // Assert
         Assert.Equal(salesOrders, results);
         this.repository.Verify(x => x.ExecuteListQuery<SalesOrder>(JobScoreQueries.GetJobScoreStagingEntries), Times.Once);
      }

      [Fact]
      public async Task CreateCreditJobProcessEntry_NoErrors_ExecutesSuccessfully()
      {
         // Arrange
         int rowsCreated = 1;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(rowsCreated));

         // Act
         await this.scoreRepository.CreateCreditJobProcessEntry(this.drAddressId, this.jobId, this.hqtrCreditJobId, this.bidAlternateId, this.spaNumber);

         // Assert
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.CreateProcessEntry, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task CreateCreditJobProcessEntry_InsertFails_ThrowsInvalidOperationException()
      {
         // Arrange
         int rowsCreated = 0;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(rowsCreated));

         // Act
         Exception ex = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            this.scoreRepository.CreateCreditJobProcessEntry(this.drAddressId, this.jobId, this.hqtrCreditJobId, this.bidAlternateId, this.spaNumber));

         // Assert
         Assert.Equal("An unexpected number of rows were created during an operation. The expected count was 1; the actual count is 0 (HqtrCreditJob=1234)", ex.Message);
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.CreateProcessEntry, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task DoesCreditJobExist_NoRecords_ReturnsFalse()
      {
         // Arrange
         CreditJob nullCreditJob = null;
         this.repository.Setup(x => x.GetAsync<CreditJob>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(nullCreditJob));

         // Act
         bool result = await this.scoreRepository.DoesCreditJobExist(this.hqtrCreditJobId);

         // Assert
         Assert.False(result);
         this.repository.Verify(x => x.GetAsync<CreditJob>(JobScoreQueries.GetCreditJobById, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task DoesCreditJobExist_FoundRecord_ReturnsTrue()
      {
         // Arrange
         CreditJob creditJob = new CreditJob();
         this.repository.Setup(x => x.GetAsync<CreditJob>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(creditJob));

         // Act
         bool result = await this.scoreRepository.DoesCreditJobExist(this.hqtrCreditJobId);

         // Assert
         Assert.True(result);
         this.repository.Verify(x => x.GetAsync<CreditJob>(JobScoreQueries.GetCreditJobById, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task HasCreditJobBeenGraded_NoRecordsNotGraded_ReturnsFalse()
      {
         // Arrange
         CreditJob nullCreditJob = null;
         this.repository.Setup(x => x.GetAsync<CreditJob>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(nullCreditJob));

         // Act
         bool result = await this.scoreRepository.HasCreditJobBeenGraded(this.hqtrCreditJobId);

         // Assert
         Assert.False(result);
         this.repository.Verify(x => x.GetAsync<CreditJob>(JobScoreQueries.GetCreditJobById, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task HasCreditJobBeenGraded_FoundRecordWithoutValue_ReturnsTrue()
      {
         // Arrange
         CreditJob creditJob = new CreditJob();
         this.repository.Setup(x => x.GetAsync<CreditJob>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(creditJob));

         // Act
         bool result = await this.scoreRepository.HasCreditJobBeenGraded(this.hqtrCreditJobId);

         // Assert
         Assert.False(result);
         this.repository.Verify(x => x.GetAsync<CreditJob>(JobScoreQueries.GetCreditJobById, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task HasCreditJobBeenGraded_FoundRecordWithValue_ReturnsTrue()
      {
         // Arrange
         CreditJob creditJob = new CreditJob() { LetterScore = "X" };
         this.repository.Setup(x => x.GetAsync<CreditJob>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(creditJob));

         // Act
         bool result = await this.scoreRepository.HasCreditJobBeenGraded(this.hqtrCreditJobId);

         // Assert
         Assert.True(result);
         this.repository.Verify(x => x.GetAsync<CreditJob>(JobScoreQueries.GetCreditJobById, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task MarkCreditJobForProcessing_NoErrors_ExecutesSuccessfully()
      {
         // Arrange
         int rowsUpdated = 1;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(rowsUpdated));

         // Act
         await this.scoreRepository.MarkCreditJobForProcessing(this.hqtrCreditJobId);

         // Assert
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.MarkForProcessing, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task RemoveCreditJobFromStaging_NoErrors_ExecutesSuccessfully()
      {
         // Arrange
         int rowsUpdated = 1;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(rowsUpdated));

         // Act
         await this.scoreRepository.DeleteCreditJobFromStaging(this.hqtrCreditJobId);

         // Assert
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.DeleteFromStaging, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task RemoveCreditJobFromStaging_DeleteFails_ThrowsInvalidOperationException()
      {
         // Arrange
         int rowsUpdated = 0;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(rowsUpdated));

         // Act
         Exception ex = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            this.scoreRepository.DeleteCreditJobFromStaging(this.hqtrCreditJobId));

         // Assert
         Assert.Equal("No rows were deleted during an operation. It was expected to delete one or more rows (HqtrCreditJob=1234)", ex.Message);
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.DeleteFromStaging, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task SetCreditJobScoreResult_NoErrors_ExecutesSuccessfully()
      {
         // Arrange
         CreditJobScoreProcessViewModel creditJobScore = new CreditJobScoreProcessViewModel()
         {
            HqtrCreditJobId = this.hqtrCreditJobId,
            ExcludedFromTopper = false,
            LetterScore = "Y"
         };
         int rowsUpdated = 1;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(rowsUpdated));

         // Act
         await this.scoreRepository.SetCreditJobScoreResult(creditJobScore);

         // Assert
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.SetScoreResults, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task SetCreditJobScoreResult_UpdateFails_ThrowsInvalidOperationException()
      {
         // Arrange
         CreditJobScoreProcessViewModel creditJobScore = new CreditJobScoreProcessViewModel()
         {
            HqtrCreditJobId = this.hqtrCreditJobId,
            ExcludedFromTopper = true,
            LetterScore = "Y"
         };
         int rowsUpdated = 0;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(rowsUpdated));

         // Act
         Exception ex = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            this.scoreRepository.SetCreditJobScoreResult(creditJobScore));

         // Assert
         Assert.Equal("An unexpected number of rows were modified during an operation. The expected count was 1; the actual count is 0 (HqtrCreditJob=1234)", ex.Message);
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.SetScoreResults, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task CreateStagingEntry_SuccessfulInsert_Returns()
      {
         // Arrange
         SalesOrder so = new SalesOrder();
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(1));

         // Act
         await this.scoreRepository.CreateStagingEntry(so);

         // Assert
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.CreateStageEntry, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task CreateStagingEntry_FailInsert_ThrowsError()
      {
         // Arrange
         SalesOrder so = new SalesOrder() { SalesOrderId = 1234 };
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(0));

         // Act
         Exception ex = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            this.scoreRepository.CreateStagingEntry(so));

         // Assert
         string err = "An unexpected number of rows were created during an operation. The expected count was 1; the actual count is 0 (HqtrSalesOrderId=1234)";
         Assert.Equal(err, ex.Message);
         this.repository.Verify(x => x.ExecuteAsync<int>(JobScoreQueries.CreateStageEntry, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetBid_HasData_ReturnsObject()
      {
         // Arrange
         Bid bid = new Bid();
         this.repository.Setup(x => x.GetAsync<Bid>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(bid));

         // Act
         Bid result = await this.scoreRepository.GetBid(this.drAddressId, this.bidAlternateId);

         // Assert
         Assert.Equal(bid, result);
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetAsync<Bid>(JobScoreQueries.GetBidAlternateByHqtrId, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetBid_NoData_ReturnsNull()
      {
         // Arrange
         this.repository.Setup(x => x.GetAsync<Bid>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult<Bid>(null));

         // Act
         Bid result = await this.scoreRepository.GetBid(this.drAddressId, this.bidAlternateId);

         // Assert
         Assert.Null(result);
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetAsync<Bid>(JobScoreQueries.GetBidAlternateByHqtrId, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetJob_HasData_ReturnsObject()
      {
         // Arrange
         JobLookup job = new JobLookup();
         this.repository.Setup(x => x.GetAsync<JobLookup>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(job));

         // Act
         JobLookup result = await this.scoreRepository.GetJob(this.drAddressId, this.jobId);

         // Assert
         Assert.Equal(job, result);
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetAsync<JobLookup>(JobScoreQueries.GetJobByHqtrId, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetJob_NoData_ReturnsNull()
      {
         // Arrange
         this.repository.Setup(x => x.GetAsync<JobLookup>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult<JobLookup>(null));

         // Act
         JobLookup result = await this.scoreRepository.GetJob(this.drAddressId, this.jobId);

         // Assert
         Assert.Null(result);
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetAsync<JobLookup>(JobScoreQueries.GetJobByHqtrId, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetLastExecution_HasData_ReturnsDate()
      {
         // Arrange
         DateTime? tmpDate = DateTime.Now;
         this.repository.Setup(x => x.ExecuteQuery<DateTime?>(It.IsAny<string>()))
            .Returns(Task.FromResult(tmpDate));

         // Act
         DateTime result = await this.scoreRepository.GetLastExecution();

         // Assert
         Assert.Equal(tmpDate, result);
         this.repository.Verify(x => x.ExecuteQuery<DateTime?>(JobScoreQueries.GetLastExecution), Times.Once);
      }

      [Fact]
      public async Task GetLastExecution_NoData_ReturnsDefault()
      {
         // Arrange
         DateTime? tmpDate = null;
         this.repository.Setup(x => x.ExecuteQuery<DateTime?>(It.IsAny<string>()))
            .Returns(Task.FromResult(tmpDate));

         // Act
         DateTime result = await this.scoreRepository.GetLastExecution();

         // Assert
         Assert.Equal(new DateTime(2020, 5, 18), result);
         this.repository.Verify(x => x.ExecuteQuery<DateTime?>(JobScoreQueries.GetLastExecution), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGrade_RetrievedSuccessfully_ReturnsJobAggregatedScoreModel()
      {
         // Assert
         int jobId = 10256;
         int bidAlternateId = 20;
         JobAggregatedGrade jobAggregatedGrade = CommonHelper.GetJobAggregatedGradeModel();
         this.repository.Setup(x => x.GetAsync<JobAggregatedGrade>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobAggregatedGrade));

         // Act
         JobAggregatedGrade result = await this.scoreRepository.GetJobAggregatedGrade(jobId, bidAlternateId);

         // Assert
         Assert.Equal(jobAggregatedGrade, result);
         this.repository.Verify(
             x => x.GetAsync<JobAggregatedGrade>(JobScoreQueries.GetJobAggregatedGrade, It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId
             && (int)y.GetType().GetProperty("BID_ALTERNATE_ID").GetValue(y) == bidAlternateId && y.GetType().GetProperties().Length == 2)), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGradeListForOrderedProduct_RetrievedSuccessfully_ReturnsJobAggregatedScoreModels()
      {
         // Arrange
         int jobId = 10256;
         IEnumerable<int> bidAlternateIds = new List<int>()
         {
            1234
         };
         IEnumerable<JobAggregatedGrade> jobAggregatedGrades = new List<JobAggregatedGrade>()
         {
            CommonHelper.GetJobAggregatedGradeModel()
         };
         this.repository.Setup(x => x.GetListAsync<JobAggregatedGrade>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobAggregatedGrades));

         // Act
         IEnumerable<JobAggregatedGrade> result = await this.scoreRepository.GetJobAggregatedGradeListForOrderedProduct(jobId, bidAlternateIds);

         // Assert
         Assert.Equal(jobAggregatedGrades, result);
         this.repository.Verify(
             x => x.GetListAsync<JobAggregatedGrade>(JobScoreQueries.GetJobAggregatedGradeForOrderedProduct, It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId
             && (IEnumerable<int>)y.GetType().GetProperty("BID_ALTERNATE_IDS").GetValue(y) == bidAlternateIds)), Times.Once);
      }
   }
}
