﻿// <copyright file="ExcludedProductCodeRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>using System;
namespace JobScoringService.Test.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;
   using Moq;
   using Xunit;

   public class ExcludedProductCodeRepositoryTest
   {
      private readonly ExcludedProductCodeRepository excludedProductCodeRepository;
      private readonly Mock<IDocumentDBConnectionFactory> documentDbConnectionFactoryMock;
      private readonly Mock<IOptions<Settings>> settings;
      private readonly Mock<IDocumentDBCollection<ExcludedProductCode>> documentDbCollectionMock;

      public ExcludedProductCodeRepositoryTest()
      {
         this.settings = new Mock<IOptions<Settings>>();
         Settings appSetting = new Settings() { DocumentDBConnectionString = "DummyConnectionString", DocumentDBJobGradeFactorCollectionName = "TSMT-JobScoring" };
         this.settings.Setup(app => app.Value).Returns(appSetting);

         this.documentDbCollectionMock = new Mock<IDocumentDBCollection<ExcludedProductCode>>();
         this.documentDbConnectionFactoryMock = new Mock<IDocumentDBConnectionFactory>();
         this.documentDbConnectionFactoryMock.Setup(x => x.GetCollection<ExcludedProductCode>(appSetting.DocumentDBExcludedProductCodeCollectionName)).Returns(this.documentDbCollectionMock.Object);
         this.excludedProductCodeRepository = new ExcludedProductCodeRepository(this.documentDbConnectionFactoryMock.Object, this.settings.Object);
      }

      /// <summary>
      /// Get excluded product codes - return excluded product codes
      /// </summary>
      /// <returns>Excluded product codes</returns>
      [Fact]
      public async Task GetExcludedProductCodes_HasRecords_ReturnsExcludedProductCodes()
      {
         // Arrange
         IEnumerable<ExcludedProductCode> excludedProductCodes = new List<ExcludedProductCode>() { new ExcludedProductCode { ProductCode = "0019" } };
         this.documentDbCollectionMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<ExcludedProductCode>>(), null)).Returns(Task.FromResult(excludedProductCodes));

         // Act
         IEnumerable<ExcludedProductCode> result = await this.excludedProductCodeRepository.GetExcludedProductCodes();

         // Assert
         Assert.Equal(excludedProductCodes, result);
         this.documentDbCollectionMock.Verify(x => x.FindAsync(It.IsAny<FilterDefinition<ExcludedProductCode>>(), null), Times.Once);
      }
   }
}
