﻿// <copyright file="SaveJobScoreCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Validators
{
   using System.Linq;
   using FluentValidation.Results;
   using JobScoringService.Core.Commands;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Validators;
   using JobScoringService.Test.Common;
   using Xunit;

   public class SaveJobScoreCommandValidatorTest
   {
      [Fact]
      public void Validate_ValidData_ReturnsTrue()
      {
         // Arrange
         int jobId = 529;
         int bidAlternateId = 7219;
         JobGraderResponse jobGraderResponse = CommonHelper.GetJobGraderResponse();

         // Act
         ValidationResult result = new SaveJobScoreCommandValidator().Validate(new SaveJobScoreCommand(jobId, bidAlternateId, jobGraderResponse));

         // Assert
         Assert.True(result.IsValid);
      }

      [Fact]
      public void Validate_LineItemsHasNoData_ReturnsFalse()
      {
         // Arrange
         int jobId = 529;
         int bidAlternateId = 7219;

         JobGraderResponse jobGraderResponse = new JobGraderResponse();

         // Act
         ValidationResult result = new SaveJobScoreCommandValidator().Validate(new SaveJobScoreCommand(jobId, bidAlternateId, jobGraderResponse));

         // Assert
         Assert.False(result.IsValid);
         Assert.Equal("Line Item Response cannot be empty", result.Errors.First().ErrorMessage);
      }

      [Fact]
      public void Validate_BidAlternateIdIsZero_ReturnsFalse()
      {
         // Arrange
         int jobId = 529;
         int bidAlternateId = 0;

         JobGraderResponse jobGraderResponse = CommonHelper.GetJobGraderResponse();

         // Act
         ValidationResult result = new SaveJobScoreCommandValidator().Validate(new SaveJobScoreCommand(jobId, bidAlternateId, jobGraderResponse));

         // Assert
         Assert.False(result.IsValid);
         Assert.Equal("Bid Alternate Id must not be 0", result.Errors.First().ErrorMessage);
      }

      [Fact]
      public void Validate_JobIdIsZero_ReturnsFalse()
      {
         // Arrange
         int jobId = 0;
         int bidAlternateId = 7219;

         JobGraderResponse jobGraderResponse = CommonHelper.GetJobGraderResponse();

         // Act
         ValidationResult result = new SaveJobScoreCommandValidator().Validate(new SaveJobScoreCommand(jobId, bidAlternateId, jobGraderResponse));

         // Assert
         Assert.False(result.IsValid);
         Assert.Equal("Job Id must not be 0", result.Errors.First().ErrorMessage);
      }
   }
}
