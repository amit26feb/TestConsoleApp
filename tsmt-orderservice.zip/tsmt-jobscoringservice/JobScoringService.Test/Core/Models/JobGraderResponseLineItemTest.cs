﻿// <copyright file="JobGraderResponseLineItemTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Models
{
   using JobScoringService.Core.Models;
   using Xunit;

   public class JobGraderResponseLineItemTest
   {
      [Fact]
      public void JobGraderResponseLineItemModels()
      {
         JobGraderResponseLineItem jgrli = new JobGraderResponseLineItem()
         {
            UnadjustedListPrice = 88773212,
            AdjustedListPrice = 4332233,
            EnteredCPLPAF = 0.322m,
            EnteredDollarAmount = 10,
            RatedCutoffGrade1 = 3490,
            RatedCutoffGrade2 = 8980,
            RatedCutoffGrade3 = 210,
            RatedCutoffGrade4 = 9870,
            RatedMultiplier = 20
         };

         Assert.Equal(88773212, jgrli.UnadjustedListPrice);
         Assert.Equal(4332233, jgrli.AdjustedListPrice);
         Assert.Equal(0.322m, jgrli.EnteredCPLPAF);
         Assert.Equal(10, jgrli.EnteredDollarAmount);
         Assert.Equal(3490, jgrli.RatedCutoffGrade1);
         Assert.Equal(8980, jgrli.RatedCutoffGrade2);
         Assert.Equal(210, jgrli.RatedCutoffGrade3);
         Assert.Equal(9870, jgrli.RatedCutoffGrade4);
         Assert.Equal(20, jgrli.RatedMultiplier);
      }
   }
}
