﻿// <copyright file="JobGraderResponseTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.Models
{
   using JobScoringService.Core.Models;
   using Xunit;

   public class JobGraderResponseTest
   {
      [Fact]
      public void JobGraderResponseModels()
      {
         JobGraderResponse jgr = new JobGraderResponse()
         {
            TotalEquipmentRevenue = 222334455,
             RatedCutoffGrade1 = 349,
             RatedCutoffGrade2 = 898,
             RatedCutoffGrade3 = 21,
             RatedCutoffGrade4 = 987,
             RatedMultiplier = 2
         };

         Assert.Equal(222334455, jgr.TotalEquipmentRevenue);
         Assert.Equal(349, jgr.RatedCutoffGrade1);
         Assert.Equal(898, jgr.RatedCutoffGrade2);
         Assert.Equal(21, jgr.RatedCutoffGrade3);
         Assert.Equal(987, jgr.RatedCutoffGrade4);
         Assert.Equal(2, jgr.RatedMultiplier);
      }
   }
}
