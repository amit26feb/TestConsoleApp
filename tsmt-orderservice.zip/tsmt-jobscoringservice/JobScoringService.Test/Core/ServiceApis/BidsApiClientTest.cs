﻿// <copyright file="BidsApiClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.ServiceApis
{
   using System.Net;
   using System.Net.Http;
   using System.Net.Http.Formatting;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ServiceAPI;
   using Microsoft.Extensions.Logging;
   using Moq;
   using TSMT.ApiClient;
   using TSMT.ApiClient.Services;
   using Xunit;

   /// <summary>
   /// Tests for the bids api client
   /// </summary>
   public class BidsApiClientTest
   {
      private readonly Mock<IApiHttpClient> mockHttp;
      private readonly IBidsApiClient clientUnderTest;
      private readonly Mock<IOktaTokenService> mockOktaTokenService;
      private readonly Mock<ILogger<BidsApiClient>> mockLogger;

      private readonly int drAddressId = 10;
      private readonly int jobId = 100;
      private readonly int bidAlternateId = 1000;

      /// <summary>
      /// Initializes a new instance of the <see cref="BidsApiClientTest"/> class.
      /// </summary>
      public BidsApiClientTest()
      {
         this.mockHttp = new Mock<IApiHttpClient>();
         this.mockOktaTokenService = new Mock<IOktaTokenService>();
         this.mockLogger = new Mock<ILogger<BidsApiClient>>();

         this.clientUnderTest = new BidsApiClient("http://dontmatter.com", this.mockHttp.Object, this.mockOktaTokenService.Object, this.mockLogger.Object);
      }

      /// <summary>
      /// Tests that the call to EnsureAuthorization will fetch an access token from Okta
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task EnsureAuthorization_FetchesAccessTokenFromOkta()
      {
         // Arrange
         string authToken = "CAT123";

         this.mockOktaTokenService.Setup(x => x.GetAccessToken())
            .Returns(Task.FromResult(authToken));

         // Act
         await this.clientUnderTest.EnsureAuthorization();

         // Assert
         this.mockOktaTokenService.Verify(x => x.GetAccessToken(), Times.Once);
      }

      /// <summary>
      /// GetBid unsuccessful returns null
      /// </summary>
      /// <returns>Null</returns>
      [Fact]
      public async Task GetBid_Unsuccessful_ReturnsNull()
      {
         // Arrange
         this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
            .Returns(Task.FromResult(new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest)));

         // Act
         Bid result = await this.clientUnderTest.GetBidAsync(this.drAddressId, this.jobId, this.bidAlternateId);

         // Assert
         Assert.Null(result);
      }

      /// <summary>
      /// GetBid successful returns expected response
      /// </summary>
      /// <returns>Http response message</returns>
      [Fact]
      public async Task GetBid_Successful_ReturnsResponse()
      {
         // Arrange
         Bid responseData = new Bid()
         {
            BidAlternateId = 657058,
            CurrentBidInd = "Y",
            BidName = "Alt Bid",
            Description = null,
            BaseBidYesNo = 0,
         };
         HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
         {
            Content = new ObjectContent<Bid>(responseData, new JsonMediaTypeFormatter())
         };
         this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
           .Returns(Task.FromResult(response));

         // Act
         Bid result = await this.clientUnderTest.GetBidAsync(this.drAddressId, this.jobId, this.bidAlternateId);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(responseData, result);
      }
   }
}
