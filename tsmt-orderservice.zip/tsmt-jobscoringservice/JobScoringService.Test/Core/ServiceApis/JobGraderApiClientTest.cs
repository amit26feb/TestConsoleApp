﻿// <copyright file="JobGraderApiClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.ServiceApis
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Net.Http;
   using System.Net.Http.Formatting;
   using System.Threading.Tasks;
   using AutoFixture;
   using JobScoringService.Common.BasicAuthApiClient;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ServiceAPI;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Tests for the job grader api client
   /// </summary>
   public class JobGraderApiClientTest
   {
      private readonly Mock<IBasicAuthApiHttpClient> mockHttp;
      private readonly IJobGraderApiClient clientUnderTest;
      private readonly Mock<ILogger<JobGraderApiClient>> mockLogger;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobGraderApiClientTest"/> class.
      /// </summary>
      public JobGraderApiClientTest()
      {
         this.mockHttp = new Mock<IBasicAuthApiHttpClient>();
         this.mockLogger = new Mock<ILogger<JobGraderApiClient>>();

         this.clientUnderTest = new JobGraderApiClient("http://dontmatter.com", "someusername", "somepassword", this.mockHttp.Object, this.mockLogger.Object);
      }

      /// <summary>
      /// GradeJob unsuccessful returns null
      /// </summary>
      /// <returns>Null</returns>
      [Fact]
      public async Task GradeJob_UnSuccessful_ReturnsNull()
      {
         // Arrange
         JobGraderRequest jobGraderRequest = new JobGraderRequest();
         this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<HttpContent>())).Returns(Task.FromResult(new HttpResponseMessage(HttpStatusCode.BadRequest)));

         // Act
         var result = await this.clientUnderTest.GradeJob(jobGraderRequest);

         // Assert
         Assert.Null(result);
         this.mockHttp.Verify(x => x.PostAsync(It.IsAny<string>(), It.IsAny<HttpContent>()), Times.Once);
      }

      /// <summary>
      /// GradeJob successful returns expected response
      /// </summary>
      /// <returns>Http response message</returns>
      [Fact]
      public async Task GradeJob_Successful_ReturnsResponse()
      {
         // Arrange
         var fixture = new Fixture();
         JobGraderRequest jobGraderRequest = new JobGraderRequest()
         {
            JobLineItems = new List<JobGraderRequestLineItem>() { fixture.Create<JobGraderRequestLineItem>() }
         };
         var responseData = fixture.Create<JobGraderResponse>();
         var response = new HttpResponseMessage(HttpStatusCode.OK)
         {
            Content = new ObjectContent<JobGraderResponse>(responseData, new JsonMediaTypeFormatter())
         };
         this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<HttpContent>())).Returns(Task.FromResult(response));

         // Act
         var result = await this.clientUnderTest.GradeJob(jobGraderRequest);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(responseData, result);
         this.mockHttp.Verify(x => x.PostAsync(It.IsAny<string>(), It.IsAny<HttpContent>()), Times.Once);
      }
   }
}
