﻿// <copyright file="ProductApiClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.ServiceApis
{
   using System.Collections.Generic;
   using System.Net;
   using System.Net.Http;
   using System.Net.Http.Formatting;
   using System.Threading.Tasks;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.ViewModels;
   using JobScoringService.Test.Common;
   using Microsoft.Extensions.Logging;
   using Moq;
   using TSMT.ApiClient;
   using Xunit;

   /// <summary>
   /// Test class for product api client
   /// </summary>
   public class ProductApiClientTest
   {
      private const string TestUrl = @"https://xkcd.com/";
      private readonly Mock<IApiHttpClient> mockHttp;
      private readonly ProductApiClient clientUnderTest;
      private readonly Mock<ILogger<ProductApiClient>> mockLogger;

      /// <summary>
      /// Initializes a new instance of the <see cref="ProductApiClientTest"/> class.
      /// </summary>
      public ProductApiClientTest()
      {
         this.mockHttp = new Mock<IApiHttpClient>();
         this.mockLogger = new Mock<ILogger<ProductApiClient>>();
         this.clientUnderTest = new ProductApiClient(TestUrl, this.mockHttp.Object, this.mockLogger.Object);
      }

      [Fact]
      public void Constructor_ConfiguresHttpClientWithAuthorization()
      {
         // Arrange
         var http = new Mock<IApiHttpClient>();
         var logger = new Mock<ILogger<ProductApiClient>>();

         // Act
         var client = new ProductApiClient(TestUrl, http.Object, logger.Object);

         // Assert
         http.Verify(c => c.AddClientCredentialAuthorizationToken(), Times.Once);
      }

      /// <summary>
      /// Get product code details - success
      /// </summary>
      /// <returns>Http response which contains product code details</returns>
      [Fact]
      public async Task GetProductCodes_HasData_ReturnsProductCodes()
      {
         // Arrange
         IEnumerable<ProductCodeViewModel> productCodes = CommonHelper.GetProductCodes();
         ProductCodeFilterViewModel productCodeFilterView = CommonHelper.GetProductCodeFilter();
         HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
         {
            Content = new ObjectContent<IEnumerable<ProductCodeViewModel>>(productCodes, new JsonMediaTypeFormatter())
         };
         this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<HttpContent>()))
            .Returns(Task.FromResult(response));

         // Act
         IEnumerable<ProductCodeViewModel> result = await this.clientUnderTest.GetProductCodes(productCodeFilterView);

         // Assert
         Assert.Equal(productCodes, result);
         this.mockHttp.Verify(m => m.PostAsync($"ProductData/ProductCodes", It.IsAny<HttpContent>()), Times.Once);
      }

      /// <summary>
      ///  Get product code details - failure
      /// </summary>
      /// <returns>Null</returns>
      [Fact]
      public async Task GetProductCodes_HasNoData_ReturnsNull()
      {
         // Arrange
         ProductCodeFilterViewModel productCodeFilterView = new ProductCodeFilterViewModel();

         this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<HttpContent>()))
            .Returns(Task.FromResult(new HttpResponseMessage(HttpStatusCode.BadRequest)));

         // Act
         IEnumerable<ProductCodeViewModel> result = await this.clientUnderTest.GetProductCodes(productCodeFilterView);

         // Assert
         Assert.Null(result);
         this.mockHttp.Verify(m => m.PostAsync($"ProductData/ProductCodes", It.IsAny<HttpContent>()), Times.Once);
      }
   }
}
