﻿// <copyright file="PricingApiClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.ServiceApis
{
   using System.Net;
   using System.Net.Http;
   using System.Net.Http.Formatting;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ServiceAPI;
   using Moq;
   using TSMT.ApiClient;
   using Xunit;

   /// <summary>
   ///  Test for Pricing Service api client
   /// </summary>
   public class PricingApiClientTest
   {
      private readonly Mock<IApiHttpClient> mockHttp;
      private readonly PricingApiClient clientUnderTest;

      /// <summary>
      /// Initializes a new instance of the <see cref="PricingApiClientTest"/> class.
      /// </summary>
      public PricingApiClientTest()
      {
         this.mockHttp = new Mock<IApiHttpClient>();
         this.clientUnderTest = new PricingApiClient("http://dontmatter.com", this.mockHttp.Object);
      }

      /// <summary>
      /// Get job score quintile and records exist
      /// </summary>
      /// <returns>Job score quintile</returns>
      [Fact]
      public async Task GetJobScoreQuintile_HasRecords_ReturnsJobScoreQuintile()
      {
         // Arrange
         string productCode = "0018";
         string salesOfficeCode = "122";
         string jobSize = "$30K - $50K";
         JobScoreQuintile jobScoreQuintile = new JobScoreQuintile()
         {
            JobSize = "$30K - $50K",
            ProductCode = "0018",
            Location = "A0",
            InfoJobCount = 5,
            InfoGeography = "National",
            InfoJobSize = "All Jobs",
            StartB = 0.483m,
            StartC = 0.442m,
            StartD = 0.432m,
            StartE = 0.425m
         };

         HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
         {
            Content = new ObjectContent<JobScoreQuintile>(jobScoreQuintile, new JsonMediaTypeFormatter())
         };
         this.mockHttp.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(response));

         // Act
         JobScoreQuintile result = await this.clientUnderTest.GetJobScoreQuintile(productCode, salesOfficeCode, jobSize);

         // Assert
         Assert.Equal(jobScoreQuintile, result);
         this.mockHttp.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
      }

      /// <summary>
      /// Get job score quintile and no record exists
      /// </summary>
      /// <returns>null</returns>
      [Fact]
      public async Task GetJobScoreQuintile_HasNoRecords_ReturnsNull()
      {
         // Arrange
         string productCode = "0018";
         string salesOfficeCode = "123";
         string jobSize = "$30K - $50K";
         JobScoreQuintile jobScoreQuintile = null;

         HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
         {
            Content = new ObjectContent<JobScoreQuintile>(jobScoreQuintile, new JsonMediaTypeFormatter())
         };
         this.mockHttp.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(response));

         // Act
         JobScoreQuintile result = await this.clientUnderTest.GetJobScoreQuintile(productCode, salesOfficeCode, jobSize);

         // Assert
         Assert.Null(result);
         this.mockHttp.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Once);
      }

      /// <summary>
      /// Get job score quintile with invalid input parameter
      /// </summary>
      /// <param name="productCode">Product code</param>
      /// <param name="salesOfficeCode">Sales office code</param>
      /// <param name="jobSize">Job size</param>
      /// <returns>null</returns>
      [Theory]
      [InlineData("", "123", "$0 - $100")]
      [InlineData("100", "", "$0 - $100")]
      [InlineData("100", "123", "")]
      [InlineData(null, "123", "$0 - $100")]
      [InlineData("100", null, "$0 - $100")]
      [InlineData("100", "123", null)]
      public async Task GetJobScoreQuintile_InvalidInputParameter_ReturnsNull(string productCode, string salesOfficeCode, string jobSize)
      {
         // Arrange
         JobScoreQuintile jobScoreQuintile = null;

         HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
         {
            Content = new ObjectContent<JobScoreQuintile>(jobScoreQuintile, new JsonMediaTypeFormatter())
         };

         // Act
         JobScoreQuintile result = await this.clientUnderTest.GetJobScoreQuintile(productCode, salesOfficeCode, jobSize);

         // Assert
         Assert.Null(result);
         this.mockHttp.Verify(x => x.GetAsync(It.IsAny<string>()), Times.Never);
      }

      /// <summary>
      /// Get job score quintile and records exist for '$1000k + jobs
      /// </summary>
      /// <returns>Job score quintile</returns>
      [Fact]
      public async Task GetJobScoreQuintileWithSpacePlus_HasRecords_ReturnsJobScoreQuintile()
      {
         // Arrange
         string productCode = "0018";
         string salesOfficeCode = "122";
         string jobSize = "$1000K +";
         JobScoreQuintile jobScoreQuintile = new JobScoreQuintile()
         {
            JobSize = "$1000K +",
            ProductCode = "0298",
            Location = "ZK",
            InfoJobCount = 5,
            InfoGeography = "Pacific Northwest",
            InfoJobSize = "All Jobs",
            StartB = 0.483m,
            StartC = 0.442m,
            StartD = 0.432m,
            StartE = 0.425m
         };

         HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
         {
            Content = new ObjectContent<JobScoreQuintile>(jobScoreQuintile, new JsonMediaTypeFormatter())
         };
         string expectedUrl = "ScoreQuintile?productCode=0018&salesOfficeCode=122&jobSize=%241000K%20%2B";
         this.mockHttp.Setup(x => x.GetAsync(It.IsAny<string>())).Returns(Task.FromResult(response));

         // Act
         JobScoreQuintile result = await this.clientUnderTest.GetJobScoreQuintile(productCode, salesOfficeCode, jobSize);

         // Assert
         Assert.Equal(jobScoreQuintile, result);
         this.mockHttp.Verify(h => h.GetAsync(It.Is<string>(actualUrl => string.Equals(expectedUrl, actualUrl))), Times.Once);
      }
   }
}
