﻿// <copyright file="SalesRollupApiClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Core.ServiceApis
{
   using System.Collections.Generic;
   using System.Net.Http;
   using System.Net.Http.Formatting;
   using System.Text;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ServiceAPI;
   using Microsoft.Extensions.Logging;
   using Moq;
   using TSMT.ApiClient;
   using TSMT.ApiClient.Services;
   using Xunit;

   /// <summary>
   /// Tests for the sales rollup api client
   /// </summary>
   public class SalesRollupApiClientTest
   {
      private readonly SalesRollupApiClient apiClientUnderTest;
      private readonly string salesRollupServiceUrl;
      private readonly Mock<IApiHttpClient> mockApiHttpClient;
      private readonly Mock<IOktaTokenService> mockOktaTokenService;
      private readonly Mock<ILogger<SalesRollupApiClient>> mockLogger;

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesRollupApiClientTest"/> class.
      /// </summary>
      public SalesRollupApiClientTest()
      {
         this.salesRollupServiceUrl = "https://www.brett.com/salesrollup/api/v1/";
         this.mockApiHttpClient = new Mock<IApiHttpClient>();
         this.mockOktaTokenService = new Mock<IOktaTokenService>();
         this.mockLogger = new Mock<ILogger<SalesRollupApiClient>>();

         this.apiClientUnderTest = new SalesRollupApiClient(this.salesRollupServiceUrl, this.mockApiHttpClient.Object, this.mockOktaTokenService.Object, this.mockLogger.Object);
      }

      /// <summary>
      /// Tests if the base service URL is set on construction
      /// </summary>
      [Fact]
      public void SetsHttpClientBaseAddress_GivenSalesRollupServiceUrl()
      {
         this.mockApiHttpClient.Verify(x => x.SetBaseAddress(It.Is<string>(x => x == this.salesRollupServiceUrl)), Times.Once);
      }

      /// <summary>
      /// Tests that the call to EnsureAuthorization will fetch an access token from Okta
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task EnsureAuthorization_FetchesAccessTokenFromOkta()
      {
         // Arrange
         string authToken = "CAT123";

         this.mockOktaTokenService.Setup(x => x.GetAccessToken())
            .Returns(Task.FromResult(authToken));

         // Act
         await this.apiClientUnderTest.EnsureAuthorization();

         // Assert
         this.mockOktaTokenService.Verify(x => x.GetAccessToken(), Times.Once);
      }

      /// <summary>
      /// Tests if sales rollup data is fetched with the correct uri
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetsRollupData_UsingCorrectRouteUri()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidId = 3;
         SalesRollupType rollupType = SalesRollupType.Code;

         string correctRouteUri = $"{drAddressId}/Jobs/{jobId}/SalesRollup/Code?bidId={bidId}&calculatePricingPolicy=false";

         this.mockApiHttpClient.Setup(x => x.GetAsync(correctRouteUri))
            .Returns(Task.FromResult(new HttpResponseMessage
            {
               StatusCode = System.Net.HttpStatusCode.OK,
               Content = new StringContent("{}", Encoding.UTF8, "application/json")
            }));

         // Act
         var rollupData = await this.apiClientUnderTest.GetRollupData(drAddressId, jobId, bidId, rollupType);

         // Assert
         this.mockApiHttpClient.Verify(x => x.GetAsync(correctRouteUri), Times.Once);
      }

      /// <summary>
      /// Tests if sales rollup data is not null when good response status
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetsRollupData_WhenGoodResponseStatus()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidId = 3;
         SalesRollupType rollupType = SalesRollupType.Code;

         string correctRouteUri = $"{drAddressId}/Jobs/{jobId}/SalesRollup/Code?bidId={bidId}&calculatePricingPolicy=false";

         this.mockApiHttpClient.Setup(x => x.GetAsync(correctRouteUri))
            .Returns(Task.FromResult(new HttpResponseMessage
            {
               StatusCode = System.Net.HttpStatusCode.OK,
               Content = new StringContent("{}", Encoding.UTF8, "application/json")
            }));

         // Act
         var rollupData = await this.apiClientUnderTest.GetRollupData(drAddressId, jobId, bidId, rollupType);

         // Assert
         Assert.NotNull(rollupData);
      }

      /// <summary>
      /// Tests if GetRollupData success returns expected response
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetsRollupData_Successful_ReturnsExpectedResponse()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidId = 3;
         SalesRollupType rollupType = SalesRollupType.Code;
         SalesRollup responseData = new SalesRollup()
         {
            Rows = new List<SalesRollupRow>()
            {
               new SalesRollupRow()
               {
                  Children = null,
                  ItemDescription = "123 Fan Coils",
                  ProductCode = "123",
                  UnitQuantity = 5,
                  QuantityLpaf = 0.985m,
                  QuickShipLpaf = 1m,
                  UnadjustedListPrice = 123.23m,
                  AdjustedListPrice = 110.33m,
                  EnteredCostPointLpaf = 0.366m,
                  EnteredMultiplier = 0.6m,
                  EnteredDollars = 105.44m
               }
            }
         };
         var response = new HttpResponseMessage(System.Net.HttpStatusCode.OK)
         {
            Content = new ObjectContent<SalesRollup>(responseData, new JsonMediaTypeFormatter())
         };

         string correctRouteUri = $"{drAddressId}/Jobs/{jobId}/SalesRollup/Code?bidId={bidId}&calculatePricingPolicy=false";

         this.mockApiHttpClient.Setup(x => x.GetAsync(correctRouteUri))
            .Returns(Task.FromResult(response));

         // Act
         var result = await this.apiClientUnderTest.GetRollupData(drAddressId, jobId, bidId, rollupType);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(responseData, result);
      }

      /// <summary>
      /// Tests if sales rollup data is null when bad response status
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetsNullRollupData_WhenBadResponseStatus()
      {
         // Arrange
         int drAddressId = 1;
         int jobId = 2;
         int bidId = 3;
         SalesRollupType rollupType = SalesRollupType.Code;

         string correctRouteUri = $"{drAddressId}/Jobs/{jobId}/SalesRollup/{rollupType}?bidId={bidId}&calculatePricingPolicy=false";

         this.mockApiHttpClient.Setup(x => x.GetAsync(correctRouteUri))
            .Returns(Task.FromResult(new HttpResponseMessage
            {
               StatusCode = System.Net.HttpStatusCode.InternalServerError,
               Content = new StringContent("{}", Encoding.UTF8, "application/json")
            }));

         // Act
         var rollupData = await this.apiClientUnderTest.GetRollupData(drAddressId, jobId, bidId, rollupType);

         // Assert
         Assert.Null(rollupData);
      }
   }
}