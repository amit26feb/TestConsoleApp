﻿// <copyright file="JobScoringControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Runtime.InteropServices;
   using System.Threading.Tasks;
   using CrossCuttingServices.Common.Exceptions;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Controllers;
   using JobScoringService.Core.Commands;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using JobScoringService.Test.Common;
   using MediatR;
   using Microsoft.AspNetCore.Http;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// JobScoringController Test
   /// </summary>
   public class JobScoringControllerTest
   {
      private readonly Mock<IJobGraderRequestBuilder> jobGraderRequestBuilder;
      private readonly Mock<IJobScoringProcessService> jobScoringProcessService;
      private readonly Mock<ILogger<JobScoringController>> logger;
      private readonly Mock<IHttpContextAccessor> contextAccessor;
      private readonly Mock<IMediator> mediatorMock;
      private readonly JobScoringController jobScoringControllerUnderTest;
      private readonly Mock<IJobScoreCalculatorService> jobScoreCalculatorService;
      private readonly int drAddressId;

      public JobScoringControllerTest()
      {
         this.jobGraderRequestBuilder = new Mock<IJobGraderRequestBuilder>();
         this.jobScoringProcessService = new Mock<IJobScoringProcessService>();
         this.logger = new Mock<ILogger<JobScoringController>>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.jobScoreCalculatorService = new Mock<IJobScoreCalculatorService>();
         this.mediatorMock = new Mock<IMediator>();
         this.jobScoringControllerUnderTest = new JobScoringController(this.jobGraderRequestBuilder.Object, this.jobScoringProcessService.Object, this.logger.Object, this.contextAccessor.Object, this.jobScoreCalculatorService.Object, this.mediatorMock.Object);
         this.drAddressId = 142;
      }

      /// <summary>
      /// Verifies Status returns OK result
      /// </summary>
      [Fact]
      public void Status_Execute()
      {
         // Act
         var result = this.jobScoringControllerUnderTest.Status();

         // Assert
         Assert.IsType<OkResult>(result);
      }

      [Fact]
      public async Task GetJobGraderRequestPayload_BadDrAddressId_BadRequestResponse()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 20;

         // Notice we didn't mock up the contextAccessor to contain a DR_ADDRESS_ID.

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGraderRequestPayload(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Equal("Invalid request, DrAddressId is not valid", ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task GetJobGraderRequestPayload_InvalidParameters_BadRequestResponse()
      {
         // Arrange
         int jobId = 0;  // This is invalid.
         int bidAlternateId = 20;

         var httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 78);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);  // This should constitute a valid DrAddressId.

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGraderRequestPayload(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Equal("Invalid request, please check the request parameters", ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task GetJobGraderRequestPayload_BuilderThrowsDomainException_BadRequestResponse()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 20;

         var httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 78);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);  // This should constitute a valid DrAddressId.

         string domainExceptionMessage = "it bombed";
         JobScoringServiceDomainException domainException = new JobScoringServiceDomainException(domainExceptionMessage);
         this.jobGraderRequestBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .ThrowsAsync(domainException);

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGraderRequestPayload(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Equal("Unable to build the JobGraderRequest payload. " + domainExceptionMessage, ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task GetJobGraderRequestPayload_ValidRequest_ReturnsOk()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 20;

         var httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 78);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);  // This should constitute a valid DrAddressId.

         string jobName = "Sample Job";
         JobGraderRequest returnedPayload = new JobGraderRequest() { Job = jobName };
         this.jobGraderRequestBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(returnedPayload));

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGraderRequestPayload(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.OK, ((JsonResult)actionResult).StatusCode);
         Assert.IsType<JobGraderRequest>(((JsonResult)actionResult).Value);
         JobGraderRequest responsePayload = ((JsonResult)actionResult).Value as JobGraderRequest;
         Assert.Equal(jobName, responsePayload.Job);
         this.jobGraderRequestBuilder.Verify(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), false), Times.Once);
      }

      [Fact]
      public async Task GetJobGrade_BadDrAddressId_BadRequestResponse()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 20;

         // Notice we didn't mock up the contextAccessor to contain a DR_ADDRESS_ID.

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGrade(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Equal("Invalid request, DrAddressId is not valid", ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task GetJobGrade_InvalidParameters_BadRequestResponse()
      {
         // Arrange
         int jobId = 0;  // This is invalid.
         int bidAlternateId = 20;

         var httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 78);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);  // This should constitute a valid DrAddressId.

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGrade(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Equal("Invalid request, please check the request parameters", ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task GetJobGrade_BuilderThrowsDomainException_BadRequestResponse()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 20;

         var httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 78);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);  // This should constitute a valid DrAddressId.

         string domainExceptionMessage = "it bombed";
         JobScoringServiceDomainException domainException = new JobScoringServiceDomainException(domainExceptionMessage);
         this.jobGraderRequestBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .ThrowsAsync(domainException);

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGrade(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Equal("JobGrade could not be retrieved, because the JobGraderRequest payload could not be built. " + domainExceptionMessage, ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task GetJobGrade_NullResponseFromGrader_ReturnsNoContent()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 20;

         var httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 78);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);  // This should constitute a valid DrAddressId.

         string jobName = "Sample Job";
         JobGraderRequest returnedPayload = new JobGraderRequest() { Job = jobName };
         this.jobGraderRequestBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(returnedPayload));

         JobGraderResponse jobGraderResponse = null;
         this.jobScoreCalculatorService.Setup(x => x.GetJobGrade(returnedPayload))
           .Returns(Task.FromResult(jobGraderResponse));

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGrade(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
         this.jobGraderRequestBuilder.Verify(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()), Times.Once);
         this.jobScoreCalculatorService.Verify(x => x.GetJobGrade(returnedPayload), Times.Once);
      }

      [Fact]
      public async Task GetJobGrade_ValidRequest_ReturnsOk()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 20;

         var httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 78);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);  // This should constitute a valid DrAddressId.

         string jobName = "Sample Job";
         JobGraderRequest returnedPayload = new JobGraderRequest() { Job = jobName };
         this.jobGraderRequestBuilder.Setup(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()))
            .Returns(Task.FromResult(returnedPayload));

         JobGraderResponse jobGraderResponse = new JobGraderResponse()
         {
           LetterScore = "B",
           CutoffAltDisplayGrade1 = "0.478/1.0",
           CutoffAltDisplayGrade2 = "0.428/1.0",
           CutoffAltDisplayGrade3 = "0.4/1.0",
           CutoffAltDisplayGrade4 = "0.372/1.0",
           RatedMultiplierAltDisplay = "0.478/1.0",
           TotalEquipmentRevenue = 3310.88m,
         };

         this.jobScoreCalculatorService.Setup(x => x.GetJobGrade(returnedPayload))
           .Returns(Task.FromResult(jobGraderResponse));

         // Act
         var actionResult = await this.jobScoringControllerUnderTest.GetJobGrade(jobId, bidAlternateId);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
         Assert.IsType<JobGraderResponse>(((OkObjectResult)actionResult).Value);
         JobGraderResponse graderResponse = ((OkObjectResult)actionResult).Value as JobGraderResponse;
         Assert.Equal(jobGraderResponse, graderResponse);
         this.jobGraderRequestBuilder.Verify(x => x.BuildJobGraderRequest(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<bool>()), Times.Once);
         this.jobScoreCalculatorService.Verify(x => x.GetJobGrade(returnedPayload), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGrade_ValidRequest_ReturnsOk()
      {
         // Arrange
         int jobId = 10256;
         int bidAlternateId = 20;
         JobAggregatedGradeViewModel jobAggregatedGradeViewModel = CommonHelper.GetJobAggregatedGradeViewModel();
         this.jobScoringProcessService.Setup(x => x.GetJobAggregatedGrade(jobId, bidAlternateId)).Returns(Task.FromResult(jobAggregatedGradeViewModel));

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGrade(jobId, bidAlternateId);

         // Assert
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
         Assert.Equal(jobAggregatedGradeViewModel, ((OkObjectResult)actionResult).Value);
         this.jobScoringProcessService.Verify(x => x.GetJobAggregatedGrade(jobId, bidAlternateId));
      }

      [Fact]
      public async Task GetJobAggregatedGrade_ValidRequestWithNoData_ReturnsNoContent()
      {
         // Arrange
         int jobId = 10;
         int bidAlternateId = 1210;
         JobAggregatedGradeViewModel jobAggregatedGradeViewModel = null;
         this.jobScoringProcessService.Setup(x => x.GetJobAggregatedGrade(jobId, bidAlternateId)).Returns(Task.FromResult(jobAggregatedGradeViewModel));

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGrade(jobId, bidAlternateId);

         // Assert
         Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
         this.jobScoringProcessService.Verify(x => x.GetJobAggregatedGrade(jobId, bidAlternateId));
      }

      [Fact]
      public async Task GetJobAggregatedGrade_InvalidInput_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         int bidAlternateId = 1210;

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGrade(jobId, bidAlternateId);

         // Assert
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
      }

      [Fact]
      public async Task SaveJobScore_ValidInput_ReturnsNoContentResult()
      {
         // Arrange
         bool createdStatus = true;
         int jobId = 55778;
         int bidAlternateId = 67865;
         JobGraderResponse jobGraderResponse = CommonHelper.GetJobGraderResponse();
         SaveJobScoreCommand request = new SaveJobScoreCommand(jobId, bidAlternateId, jobGraderResponse);
         this.mediatorMock.Setup(x => x.Send(It.IsAny<SaveJobScoreCommand>(), default)).Returns(Task.FromResult(createdStatus));

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.SaveJobScore(jobId, bidAlternateId, request);

         // Assert
         Assert.IsType<NoContentResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(request, default), Times.Once);
      }

      [Fact]
      public async Task SaveJobScore_SaveJobScoreRequestIsNull_ReturnsBadRequestObjectResult()
      {
         // Arrange
         int jobId = 55778;
         int bidAlternateId = 67865;
         SaveJobScoreCommand request = null;

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.SaveJobScore(jobId, bidAlternateId, request);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(request, default), Times.Never);
         Assert.Equal("Invalid request for saving job score, please check the request parameter", ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task SaveJobScore_EntryNotCreated_ReturnsBadRequestObjectResult()
      {
         // Arrange
         bool createdStatus = false;
         int jobId = 55778;
         int bidAlternateId = 67865;
         JobGraderResponse jobGraderResponse = CommonHelper.GetJobGraderResponse();
         SaveJobScoreCommand request = new SaveJobScoreCommand(jobId, bidAlternateId, jobGraderResponse);
         this.mediatorMock.Setup(x => x.Send(It.IsAny<SaveJobScoreCommand>(), default)).Returns(Task.FromResult(createdStatus));

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.SaveJobScore(jobId, bidAlternateId, request);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(request, default), Times.Once);
         Assert.Equal("Unexpected error occurred while saving job score", ((BadRequestObjectResult)actionResult).Value);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_ValidRequest_ReturnsOk()
      {
         // Arrange
         int jobId = 10256;
         IEnumerable<int> bidAlternateIds = new List<int>()
         {
            20,
            111,
         };
         IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGradeViewModel = new List<JobAggregatedGradeViewModel>()
         {
            CommonHelper.GetJobAggregatedGradeViewModel()
         };
         DefaultHttpContext httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 142);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);
         this.jobScoringProcessService.Setup(x => x.GetJobAggregatedGradeList(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(jobAggregatedGradeViewModel));

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGradeList(jobId, bidAlternateIds);

         // Assert
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
         Assert.Equal(jobAggregatedGradeViewModel, ((OkObjectResult)actionResult).Value);
         this.jobScoringProcessService.Verify(x => x.GetJobAggregatedGradeList(this.drAddressId, jobId, bidAlternateIds), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_ValidRequestWithNoData_ReturnsNoContent()
      {
         // Arrange
         int jobId = 10;
         IEnumerable<int> bidAlternateIds = new List<int>()
         {
            2020,
            11111,
         };
         DefaultHttpContext httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 142);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);
         IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGradeViewModel = null;
         this.jobScoringProcessService.Setup(x => x.GetJobAggregatedGradeList(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(jobAggregatedGradeViewModel));

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGradeList(jobId, bidAlternateIds);

         // Assert
         Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
         this.jobScoringProcessService.Verify(x => x.GetJobAggregatedGradeList(this.drAddressId, jobId, bidAlternateIds), Times.Once);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_NullBidAlternateIds_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 123;
         IEnumerable<int> bidAlternateIds = null;
         string errorMessage = "Invalid request, please check the request parameter";
         DefaultHttpContext httpContext = new DefaultHttpContext();
         httpContext.Items.Add("DR_ADDRESS_ID", 142);
         this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGradeList(jobId, bidAlternateIds);

         // Assert
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Contains((((ObjectResult)actionResult).Value as JsonErrorResponse).Messages, x => x == errorMessage);
         this.jobScoringProcessService.Verify(x => x.GetJobAggregatedGradeList(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IEnumerable<int>>()), Times.Never);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_EmptyBidAlternateIds_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 123;
         IEnumerable<int> bidAlternateIds = Enumerable.Empty<int>();
         string errorMessage = "Invalid request, please check the request parameter";

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGradeList(jobId, bidAlternateIds);

         // Assert
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Contains((((ObjectResult)actionResult).Value as JsonErrorResponse).Messages, x => x == errorMessage);
         this.jobScoringProcessService.Verify(x => x.GetJobAggregatedGradeList(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IEnumerable<int>>()), Times.Never);
      }

      [Fact]
      public async Task GetJobAggregatedGradeList_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         IEnumerable<int> bidAlternateIds = new List<int>()
         {
            2020,
            11111,
         };
         string errorMessage = "Invalid request, please check the request parameter";

         // Act
         IActionResult actionResult = await this.jobScoringControllerUnderTest.GetJobAggregatedGradeList(jobId, bidAlternateIds);

         // Assert
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Contains((((ObjectResult)actionResult).Value as JsonErrorResponse).Messages, x => x == errorMessage);
         this.jobScoringProcessService.Verify(x => x.GetJobAggregatedGradeList(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IEnumerable<int>>()), Times.Never);
      }
   }
}
