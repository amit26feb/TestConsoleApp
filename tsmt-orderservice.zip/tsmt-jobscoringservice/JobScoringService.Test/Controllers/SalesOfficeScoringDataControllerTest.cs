﻿// <copyright file="SalesOfficeScoringDataControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test.Controllers
{
   using System;
   using System.Threading.Tasks;
   using JobScoringService.Controllers;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class SalesOfficeScoringDataControllerTest
   {
      private readonly SalesOfficeScoringDataController controllerUnderTest;
      private readonly Mock<ISalesOfficeScoringDataService> salesOfficeScoringDataService;
      private readonly Mock<ILogger<SalesOfficeScoringDataController>> logger;
      private readonly int salesOfficeId = 123;
      private readonly string[] prodCodes = new string[] { "hiThere" };
      private readonly string custChannelId = "espn";

      public SalesOfficeScoringDataControllerTest()
      {
         this.salesOfficeScoringDataService = new Mock<ISalesOfficeScoringDataService>();
         this.logger = new Mock<ILogger<SalesOfficeScoringDataController>>();
         this.controllerUnderTest = new SalesOfficeScoringDataController(this.salesOfficeScoringDataService.Object, this.logger.Object);
      }

      [Fact]
      public async Task Search_NoSalesOfficeId_ReturnsBadRequest()
      {
         // Arrange
         int emptySalesOfficeCode = 0;

         // Act
         IActionResult result = await this.controllerUnderTest.Search(emptySalesOfficeCode, new SalesOfficeScoringDataSearchViewModel() { ProdCodes = this.prodCodes, CustChannelId = this.custChannelId });

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Sales office id greater than 0 is required.", ((BadRequestObjectResult)result).Value);
      }

      [Fact]
      public async Task Search_NoProdCodes_ReturnsOk()
      {
         // Arrange
         string[] emptyProductCodes = new string[] { };

         // Act
         IActionResult result = await this.controllerUnderTest.Search(this.salesOfficeId, new SalesOfficeScoringDataSearchViewModel() { ProdCodes = emptyProductCodes, CustChannelId = this.custChannelId });

         // Assert
         Assert.IsType<OkObjectResult>(result);
      }

      [Fact]
      public async Task Search_NoCustChannelId_ReturnsBadRequest()
      {
         // Arrange
         string emptyCustChannelId = string.Empty;

         // Act
         IActionResult result = await this.controllerUnderTest.Search(this.salesOfficeId, new SalesOfficeScoringDataSearchViewModel() { ProdCodes = this.prodCodes, CustChannelId = emptyCustChannelId }) ;

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Cust channel id is required.", ((BadRequestObjectResult)result).Value);
      }

      [Fact]
      public async Task Search_NoScoringDataFound_ReturnsOk()
      {
         // Arrange
         this.salesOfficeScoringDataService.Setup(s => s.GetScoringData(this.salesOfficeId, this.prodCodes, this.custChannelId))
            .Returns(Task.FromResult<SalesOfficeScoringDataViewModel>(null));

         // Act
         IActionResult result = await this.controllerUnderTest.Search(this.salesOfficeId, new SalesOfficeScoringDataSearchViewModel() { ProdCodes = this.prodCodes, CustChannelId = this.custChannelId });

         // Assert
         Assert.IsType<OkObjectResult>(result);
      }

      [Fact]
      public async Task Search_HasScoringData_ReturnsOK()
      {
         // Arrange
         SalesOfficeScoringDataViewModel someScore = new SalesOfficeScoringDataViewModel();
         this.salesOfficeScoringDataService.Setup(s => s.GetScoringData(this.salesOfficeId, this.prodCodes, this.custChannelId))
            .Returns(Task.FromResult(someScore));

         // Act
         IActionResult result = await this.controllerUnderTest.Search(this.salesOfficeId, new SalesOfficeScoringDataSearchViewModel() { ProdCodes = this.prodCodes, CustChannelId = this.custChannelId });

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(someScore, ((OkObjectResult)result).Value);
      }

      [Fact]
      public async Task Search_GetScoringDataException_ReturnsProblem()
      {
         // Arrange
         this.salesOfficeScoringDataService.Setup(s => s.GetScoringData(this.salesOfficeId, this.prodCodes, this.custChannelId))
            .Throws(new Exception("something turrible happended."));

         // Act
         IActionResult result = await this.controllerUnderTest.Search(this.salesOfficeId, new SalesOfficeScoringDataSearchViewModel() { ProdCodes = this.prodCodes, CustChannelId = this.custChannelId });

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Could not get sales office scoring data for salesOfficeId 123 prodCodes hiThere custChannelId espn.", ((ObjectResult)result).Value);
      }
   }
}
