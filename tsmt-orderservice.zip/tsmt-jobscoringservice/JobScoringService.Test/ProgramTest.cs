﻿// <copyright file="ProgramTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Test
{
    using System;
    using System.IO;
    using System.Net;
    using JobScoringService;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.TestHost;
    using Xunit;

    /// <summary>
    /// Program Test
    /// </summary>
    public class ProgramTest
    {
        /// <summary>
        /// Should build web host
        /// </summary>
        [Fact]
        public async void ShouldBuildWebHost()
        {
            // Arrange
            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
            string appRootPath = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory,
                "..",
                "..",
                "..",
                "..",
                "JobScoringService"));
            var webHostBuilder = Program.BuildWebHost(Array.Empty<string>())
                .UseContentRoot(appRootPath);
            var server = new TestServer(webHostBuilder);
            var client = server.CreateClient();

            // Act
            var response = await client.GetAsync(" ");

            // Assert
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }
    }
}
