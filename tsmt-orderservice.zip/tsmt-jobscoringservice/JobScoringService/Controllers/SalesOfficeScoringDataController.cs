﻿// <copyright file="SalesOfficeScoringDataController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Controllers
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Job Scoring Service
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/[controller]/{salesOfficeId}")]
   [Authorize]
   public class SalesOfficeScoringDataController : Controller
   {
      private readonly ISalesOfficeScoringDataService salesOfficeScoringDataService;
      private readonly ILogger<SalesOfficeScoringDataController> logger;

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesOfficeScoringDataController"/> class.
      /// </summary>
      /// <param name="salesOfficeScoringDataService">Sales office scoring data service</param>
      /// <param name="logger">logger for logs</param>
      public SalesOfficeScoringDataController(ISalesOfficeScoringDataService salesOfficeScoringDataService, ILogger<SalesOfficeScoringDataController> logger)
      {
         this.salesOfficeScoringDataService = salesOfficeScoringDataService;
         this.logger = logger;
      }

      /// <summary>
      /// Get Job Scoring Data for a given sales office, product codes, and customer channel id
      /// </summary>
      /// <param name="salesOfficeId">Sales office id for the job</param>
      /// <param name="model">ProdCodes and custChannelId inputs</param>
      /// <returns>Job scoring data</returns>
      [HttpPost]
      [ProducesResponseType(typeof(SalesOfficeScoringDataViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> Search(int salesOfficeId, [FromBody] SalesOfficeScoringDataSearchViewModel model)
      {
         if (salesOfficeId <= 0)
         {
            this.logger.LogError("Search requested with invalid sales office id");
            return this.BadRequest("Sales office id greater than 0 is required.");
         }

         if (string.IsNullOrWhiteSpace(model.CustChannelId))
         {
            this.logger.LogError("Search requested without cust channel id");
            return this.BadRequest("Cust channel id is required.");
         }

         try
         {
            SalesOfficeScoringDataViewModel scoringData = await this.salesOfficeScoringDataService.GetScoringData(salesOfficeId, model.ProdCodes, model.CustChannelId);
            return this.Ok(scoringData);
         }
         catch (Exception ex)
         {
            string errorDesc = $"Could not get sales office scoring data";
            this.logger.LogError(ex, errorDesc, salesOfficeId, model.ProdCodes, model.CustChannelId);
            return this.BadRequest($"{errorDesc} for salesOfficeId {salesOfficeId} prodCodes {string.Join(", ", model.ProdCodes)} custChannelId {model.CustChannelId}.");
         }
      }
   }
}
