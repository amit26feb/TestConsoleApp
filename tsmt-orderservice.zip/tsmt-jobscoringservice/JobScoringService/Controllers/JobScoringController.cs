// <copyright file="JobScoringController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace JobScoringService.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using Castle.Core.Internal;
   using CrossCuttingServices.Common.Exceptions;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Core.Commands;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Http;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Newtonsoft.Json;
   using Newtonsoft.Json.Serialization;

   /// <summary>
   /// Job Scoring Service
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/[controller]")]
   [Authorize]
   public class JobScoringController : Controller
   {
      private readonly IJobGraderRequestBuilder jobGraderRequestBuilder;
      private readonly IJobScoringProcessService jobScoringProcessService;
      private readonly ILogger<JobScoringController> logger;
      private readonly IHttpContextAccessor contextAccessor;
      private readonly IJobScoreCalculatorService jobScoreCalculatorService;
      private readonly IMediator mediator;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoringController"/> class.
      /// </summary>
      /// <param name="jobGraderRequestBuilder">JobGraderRequest builder</param>
      /// <param name="jobScoringProcessService">Job scoring process service</param>
      /// <param name="logger">Job scoring logger</param>
      /// <param name="contextAccessor">HTTP context accessor</param>
      /// <param name="jobScoreCalculatorService">Job score calculator service</param>
      /// <param name="mediator">Mediator</param>
      public JobScoringController(IJobGraderRequestBuilder jobGraderRequestBuilder, IJobScoringProcessService jobScoringProcessService, ILogger<JobScoringController> logger, IHttpContextAccessor contextAccessor, IJobScoreCalculatorService jobScoreCalculatorService, IMediator mediator)
      {
         this.jobGraderRequestBuilder = jobGraderRequestBuilder;
         this.jobScoringProcessService = jobScoringProcessService;
         this.logger = logger;
         this.contextAccessor = contextAccessor;
         this.jobScoreCalculatorService = jobScoreCalculatorService;
         this.mediator = mediator;
      }

      /// <summary>
      /// Return Ok Status
      /// </summary>
      /// <returns>Return Status</returns>
      [Route("~/api/v{version:apiVersion}/[controller]/Status")]
      [HttpGet]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      public IActionResult Status()
      {
         return this.Ok();
      }

      /// <summary>
      /// Retrieve JobGraderRequest payload, for a given job and bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>JobGraderRequest payload, suitable for making calls to the JobGrader API</returns>
      [Route("{jobId}/JobGraderRequestPayloadForBid/{bidAlternateId}")]
      [HttpGet]
      [ProducesResponseType(typeof(JobGraderRequest), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetJobGraderRequestPayload(int jobId, int bidAlternateId)
      {
         int drAddressId = this.GetDrAddressIdFromHttpContext();
         if (drAddressId <= 0)
         {
            string errorMessage = "Invalid request, DrAddressId is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(errorMessage);
         }

         if (jobId > 0 && bidAlternateId > 0)
         {
            JobGraderRequest jobGraderRequest = null;
            try
            {
               jobGraderRequest = await this.jobGraderRequestBuilder.BuildJobGraderRequest(drAddressId, jobId, bidAlternateId);
            }
            catch (JobScoringServiceDomainException domainException)
            {
               /* Building a JobGraderRequest is highly dependent on calls to other APIs, and there are several points of failure and reasons why the payload cannot be built.
                * In short, the exceptions thrown are not really exceptional.
                * So we capture and report these exceptions, rather than forcing the caller to investigate why the request payload could not be built. */
               string errorMessage = "Unable to build the JobGraderRequest payload. " + domainException.Message;
               this.logger.LogError(errorMessage);
               return (IActionResult)this.BadRequest(errorMessage);
            }

            // Unfortunately, we have to do some gymnastics, to format the outputted JSON in PascalCase, which is what the current JobGrader API expects.
            // Because without intervention, the JSON would be output in camelCase.
            return new JsonResult(jobGraderRequest)
            {
               StatusCode = (int)HttpStatusCode.OK,
               SerializerSettings = new JsonSerializerSettings() { ContractResolver = new DefaultContractResolver() },  // According to the interwebs, this produces PascalCase instead of camelCase.  And it seems to work.
               ContentType = "application/json",
            };
         }
         else
         {
            string errorMessage = "Invalid request, please check the request parameters";
            this.logger.LogError(errorMessage);
            return (IActionResult)this.BadRequest(errorMessage);
         }
      }

      /// <summary>
      /// Retrieve JobGraderResponse, for a given job and bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>JobGraderResponse (letter grade), as returned from the JobGrader API</returns>
      [Route("{jobId}/JobGradeForBid/{bidAlternateId}")]
      [HttpGet]
      [ProducesResponseType(typeof(JobGraderResponse), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetJobGrade(int jobId, int bidAlternateId)
      {
         int drAddressId = this.GetDrAddressIdFromHttpContext();
         if (drAddressId <= 0)
         {
            string errorMessage = "Invalid request, DrAddressId is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(errorMessage);
         }

         if (jobId > 0 && bidAlternateId > 0)
         {
            JobGraderRequest jobGraderRequest = null;
            try
            {
               jobGraderRequest = await this.jobGraderRequestBuilder.BuildJobGraderRequest(drAddressId, jobId, bidAlternateId);
            }
            catch (JobScoringServiceDomainException domainException)
            {
               /* Building a JobGraderRequest is highly dependent on calls to other APIs, and there are several points of failure and reasons why the payload cannot be built.
                * In short, the exceptions thrown are not really exceptional.
                * So we capture and report these exceptions, rather than forcing the caller to investigate why the request payload could not be built. */
               string errorMessage = "JobGrade could not be retrieved, because the JobGraderRequest payload could not be built. " + domainException.Message;
               this.logger.LogError(errorMessage);
               return (IActionResult)this.BadRequest(errorMessage);
            }

            JobGraderResponse jobGraderResponse = await this.jobScoreCalculatorService.GetJobGrade(jobGraderRequest);

            return (jobGraderResponse != null) ? (IActionResult)this.Ok(jobGraderResponse) : this.NoContent();
         }
         else
         {
            string errorMessage = "Invalid request, please check the request parameters";
            this.logger.LogError(errorMessage);
            return (IActionResult)this.BadRequest(errorMessage);
         }
      }

      /// <summary>
      /// Retrieve job aggregated grade for a given job id and bid alternate id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Job aggregated grade</returns>
      [Route("{jobId}/Bids/{bidAlternateId}/AggregateGrade")]
      [HttpGet]
      [ProducesResponseType(typeof(JobAggregatedGradeViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetJobAggregatedGrade(int jobId, int bidAlternateId)
      {
         if (jobId > 0 && bidAlternateId > 0)
         {
            JobAggregatedGradeViewModel jobAggregatedGrade = await this.jobScoringProcessService.GetJobAggregatedGrade(jobId, bidAlternateId);
            return jobAggregatedGrade == null ? (IActionResult)this.NoContent() : (IActionResult)this.Ok(jobAggregatedGrade);
         }

         string errorMessage = $"Invalid request, please check the request parameters: jobId - {jobId}, bidAlternateId - {bidAlternateId}";
         this.logger.LogError(errorMessage);
         return this.BadRequest(errorMessage);
      }

      /// <summary>
      /// Save job score information
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid Alternate Id</param>
      /// <param name="request">Command for saving job score info</param>
      /// <returns>No content if the create is successful/Bad request response if the request is invalid</returns>
      [Route("{jobId}/Bid/{bidAlternateId}/Report")]
      [HttpPost]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> SaveJobScore(int jobId, int bidAlternateId, [FromBody]SaveJobScoreCommand request)
      {
         string errorMessage = "Invalid request for saving job score, please check the request parameter";
         if (request != null && request.JobGraderResponse != null)
         {
            request.JobId = jobId;
            request.BidAlternateId = bidAlternateId;
            bool createStatus = await this.mediator.Send(request);
            if (createStatus)
            {
               return this.NoContent();
            }

            errorMessage = "Unexpected error occurred while saving job score";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(errorMessage);
      }

      /// <summary>
      /// Retrieve list of job aggregated grade for a given job id and bid alternate ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateIds">Bid alternate ids</param>
      /// <returns>Job aggregated grade list</returns>
      [Route("{jobId}/Bids/AggregateGrades")]
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<JobAggregatedGradeViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetJobAggregatedGradeList(int jobId, IEnumerable<int> bidAlternateIds)
      {
         int drAddressId = this.GetDrAddressIdFromHttpContext();
         if (jobId > 0 && bidAlternateIds?.Any() == true)
         {
            IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGrades = await this.jobScoringProcessService.GetJobAggregatedGradeList(drAddressId, jobId, bidAlternateIds);
            return jobAggregatedGrades?.Any() == true ? (IActionResult)this.Ok(jobAggregatedGrades) : (IActionResult)this.NoContent();
         }

         string errorMessage = "Invalid request, please check the request parameter";
         this.logger.LogInformation(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      private int GetDrAddressIdFromHttpContext()
      {
         int contextValue = 0;
         if (this.contextAccessor.HttpContext != null && this.contextAccessor.HttpContext.Items != null && this.contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID"))
         {
            int.TryParse(this.contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out contextValue);
         }

         return contextValue;
      }
   }
}
