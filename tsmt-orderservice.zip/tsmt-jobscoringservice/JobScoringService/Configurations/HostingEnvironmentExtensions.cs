﻿// <copyright file="HostingEnvironmentExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Configurations
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Hosting;

    /// <summary>
    /// Web hosting environment extensions
    /// </summary>
    public static class HostingEnvironmentExtensions
    {
        /// <summary>
        /// UAT Environment
        /// </summary>
        public const string UATEnvironment = "UAT";

        /// <summary>
        /// Check Is UAT
        /// </summary>
        /// <param name="hostingEnvironment">Web hosting environment</param>
        /// <returns>Web hosting environment details</returns>
        public static bool IsUAT(this IWebHostEnvironment hostingEnvironment)
        {
            return hostingEnvironment.IsEnvironment(UATEnvironment);
        }
    }
}
