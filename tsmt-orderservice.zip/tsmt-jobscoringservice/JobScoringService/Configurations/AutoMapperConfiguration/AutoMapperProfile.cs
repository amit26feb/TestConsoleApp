﻿// <copyright file="AutoMapperProfile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Configurations.AutoMapperConfiguration
{
   using AutoMapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ViewModels;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// Mapping views
   /// </summary>
   public class AutoMapperProfile : Profile
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="AutoMapperProfile"/> class.
      /// </summary>
      public AutoMapperProfile() => this.MapForViewing();

      private void MapForViewing()
      {
         this.CreateMap<JobGraderRequestLineItem, JobGraderResponseLineItem>()
                .ReverseMap();

         this.CreateMap<JobGraderResponseLineItem, RollupRow>();
         this.CreateMap<JobAggregatedGrade, JobAggregatedGradeViewModel>()
            .ForMember(dest => dest.LetterScore, opt => opt.MapFrom(src => src.LETTER_SCORE))
            .ForMember(dest => dest.CreatedDate, opt => opt.MapFrom(src => src.CREATED_DATE))
            .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
            .ForMember(dest => dest.ExcludedFromTopper, opt => opt.MapFrom(src => src.EXCLUDED_FROM_TOPPER));
      }
   }
}