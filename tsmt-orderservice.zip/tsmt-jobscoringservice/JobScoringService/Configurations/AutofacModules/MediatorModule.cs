﻿// <copyright file="MediatorModule.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.Configurations.AutofacModules
{
   using System.Collections.Generic;
   using System.Net.Http;
   using System.Reflection;
   using Autofac;
   using Autofac.Core;
   using Autofac.Extras.AggregateService;
   using CacheProviderWrapper;
   using CrossCuttingServices.Core.Behaviors;
   using DocumentDBWrapper;
   using FluentValidation;
   using global::DataAccess.Core.Abstractions;
   using JobScoringService.Common.BasicAuthApiClient;
   using JobScoringService.Core;
   using JobScoringService.Core.Behaviors;
   using JobScoringService.Core.Commands;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.Services;
   using JobScoringService.Core.Validators;
   using MediatR;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.Hosting;
   using Microsoft.Extensions.Options;
   using S3Wrapper;
   using TraneSalesTools;
   using TSMT.ApiClient;
   using TSMT.ApiClient.Services;
   using TSMT.DataAccess;
   using TSMT.Settings;

   /// <summary>
   /// Mediator Module
   /// </summary>
   public class MediatorModule : Autofac.Module
   {
      private readonly IConfiguration config;

      /// <summary>
      /// Initializes a new instance of the <see cref="MediatorModule"/> class.
      /// </summary>
      /// <param name="configuration">IConfiguration to load the service url</param>
      public MediatorModule(IConfiguration configuration)
      {
         this.config = configuration;
      }

      /// <summary>
      /// Load the dependencies
      /// </summary>
      /// <param name="builder">builder</param>
      protected override void Load(ContainerBuilder builder)
      {
         builder.RegisterType(typeof(Mediator)).As(typeof(IMediator));

         builder.Register<SingleInstanceFactory>(context =>
            {
               var componentContext = context.Resolve<IComponentContext>();
               return t =>
               {
                return componentContext.TryResolve(t, out object o) ? o : null;
             };
            });

         builder.Register<MultiInstanceFactory>(context =>
         {
            var componentContext = context.Resolve<IComponentContext>();

            return t =>
               {
                var resolved = (IEnumerable<object>)componentContext.Resolve(typeof(IEnumerable<>).MakeGenericType(t));
                return resolved;
             };
         });

         builder.RegisterGeneric(typeof(LoggingBehavior<,>)).As(typeof(IPipelineBehavior<,>));
         builder.RegisterGeneric(typeof(ValidatorBehavior<,>)).As(typeof(IPipelineBehavior<,>));
         builder.RegisterGeneric(typeof(Repository<>)).As(typeof(IRepository<>));

         builder.RegisterType(typeof(ApiHttpClient)).As(typeof(IApiHttpClient));
         builder.RegisterType(typeof(BasicAuthApiHttpClient)).As(typeof(IBasicAuthApiHttpClient));
         builder.RegisterType(typeof(HttpContextAccessor)).As(typeof(IHttpContextAccessor));
         builder.RegisterType(typeof(OktaTokenService)).As(typeof(IOktaTokenService)).SingleInstance();
         builder.RegisterType(typeof(HttpClient));
         builder.RegisterType(typeof(TSMTSettings));

         builder.RegisterAssemblyTypes(typeof(ISalesOfficeService).GetTypeInfo().Assembly).AsImplementedInterfaces();
         builder.RegisterType(typeof(RedisCacheProviderV2)).As(typeof(ICacheProvider));
         builder.RegisterType(typeof(RedisConnectionFactory)).As(typeof(IRedisConnectionFactory)).SingleInstance();

         builder.RegisterAssemblyTypes(typeof(IS3Repository).GetTypeInfo().Assembly).AsImplementedInterfaces();

         builder.RegisterType(typeof(MultipleDBConnectionFactory))
            .As(typeof(IConnectionFactory))
            .InstancePerLifetimeScope()
            .WithParameter("connectionType", DatabaseConnectionType.TSTRN);
         builder.RegisterType(typeof(JobScoreRepository)).As(typeof(IJobScoreRepository));
         builder.RegisterType(typeof(OrderRepository)).As(typeof(IOrderRepository));
         builder.RegisterType(typeof(JobSizeRepository)).As(typeof(IJobSizeRepository));
         builder.RegisterType(typeof(JobGradeFactorRepository)).As(typeof(IJobGradeFactorRepository));
         builder.RegisterType(typeof(JobScoreQuintileRepository)).As(typeof(IJobScoreQuintileRepository));
         builder.RegisterType(typeof(ExcludedProductCodeRepository)).As(typeof(IExcludedProductCodeRepository));
         builder.RegisterType(typeof(JobSizeFactorRepository)).As(typeof(IJobSizeFactorRepository));
         builder.RegisterType(typeof(BidsApiClient)).As(typeof(IBidsApiClient)).WithParameter("bidServiceUrl", this.config["bidServiceUrl"]);
         builder.RegisterType(typeof(JobsApiClient)).As(typeof(IJobsApiClient)).WithParameter("jobServiceUrl", this.config["jobServiceUrl"]);
         builder.RegisterType(typeof(ProductApiClient)).As(typeof(IProductApiClient)).WithParameter("productServiceUrl", this.config["productServiceUrl"]);
         builder.RegisterType(typeof(PricingApiClient)).As(typeof(IPricingApiClient)).WithParameter("pricingServiceUrl", this.config["pricingServiceUrl"]);
         builder.RegisterType(typeof(SalesRollupApiClient)).As(typeof(ISalesRollupApiClient)).WithParameter("salesRollupServiceUrl", this.config["salesRollupServiceUrl"]);
         builder.RegisterType(typeof(JobGraderApiClient)).As(typeof(IJobGraderApiClient))
            .WithParameter("jobGraderServiceUrl", this.config["jobGraderServiceUrl"])
            .WithParameter("basicAuthUsername", this.config["jobGraderServiceUsername"])
            .WithParameter("basicAuthPassword", this.config["JobGraderServicePassword"]);

         builder.RegisterType(typeof(JobGraderRequestBuilder)).As(typeof(IJobGraderRequestBuilder));
         builder.RegisterType(typeof(JobScoringProcessService)).As(typeof(IJobScoringProcessService));
         builder.RegisterType(typeof(OrderCreationProcessService)).As(typeof(IOrderCreationProcessService));

         builder.RegisterType(typeof(JobScoringHostedService)).As(typeof(IHostedService));
         builder.RegisterType(typeof(OrderCreationHostedService)).As(typeof(IHostedService));
         builder.RegisterType(typeof(JobScoreCalculatorService)).As(typeof(IJobScoreCalculatorService));
         builder.RegisterType(typeof(JobScoreReportService)).As(typeof(IJobScoreReportService));
         builder.RegisterType(typeof(JobScoreReportRepository)).As(typeof(IJobScoreReportRepository));
         builder.RegisterType(typeof(SalesOfficeScoringDataService)).As(typeof(ISalesOfficeScoringDataService));

         builder.RegisterType(typeof(Repository<EnterpriseSalesOrder>))
               .As(typeof(IRepository<EnterpriseSalesOrder>))
               .WithParameter(
                  new ResolvedParameter(
                    (pi, ctx) => pi.ParameterType.IsAssignableFrom(typeof(DataAccess.Core.Infrastructure.ConnectionFactory)),
                    (pi, ctx) => new MultipleDBConnectionFactory(ctx.Resolve<IOptions<TSMTSettings>>(), DatabaseConnectionType.ESTRN)));
         builder.RegisterType<DocumentDBConnectionFactory>().AsImplementedInterfaces()
           .WithParameter("connectionString", this.config["DocumentDBConnectionString"]);
         builder.RegisterAggregateService<IJobScoreMasterRepository>();
         builder.RegisterAssemblyTypes(typeof(SaveJobScoreCommand).GetTypeInfo().Assembly)
            .AsClosedTypesOf(typeof(IRequestHandler<,>));
         builder.RegisterAssemblyTypes(typeof(SaveJobScoreCommandValidator).Assembly)
            .AsClosedTypesOf(typeof(IValidator<>));
      }
   }
}
