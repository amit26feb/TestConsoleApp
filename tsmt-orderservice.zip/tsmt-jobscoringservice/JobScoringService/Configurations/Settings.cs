// <copyright file="Settings.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   /// <summary>
   /// Settings for Job Scoring
   /// </summary>
   public class Settings
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="Settings"/> class.
      /// Settings for job scoring
      /// </summary>
      public Settings()
      {
      }

      /// <summary>
      /// Gets or sets IHostingServiceTimeIntervalInSeconds
      /// </summary>
      public int IHostingServiceTimeIntervalInSeconds { get; set; }

      /// <summary>
      /// Gets or sets ScoringExemptSpaNumberBucket
      /// </summary>
      public string ScoringExemptSpaNumberBucket { get; set; }

      /// <summary>
      /// Gets or sets ScoringExemptSpaNumberCsvFilename
      /// </summary>
      public string ScoringExemptSpaNumberCsvFilename { get; set; }

      /// <summary>
      /// Gets or sets MaxRetryAttempts
      /// NOTE: This cannot exceed 9 without increasing the capacity of the JOB_SCORE_PROCESS.RETRY_COUNT column, which is currently defined as a NUMBER(1).
      /// </summary>
      public int MaxRetryAttempts { get; set; }

      /// <summary>
      /// Gets or sets MinutesPauseBeforeRetryingCreditJob
      /// This tells us the minutes to wait before retrying a credit job that recently failed
      /// </summary>
      public int MinutesPauseBeforeRetryingCreditJob { get; set; }

      /// <summary>
      /// Gets or sets gets document db url
      /// </summary>
      public string DocumentDBConnectionString { get; set; }

      /// <summary>
      /// Gets or sets document db job size collection name
      /// </summary>
      public string DocumentDBJobSizeCollectionName { get; set; }

      /// <summary>
      /// Gets or sets document db job grade factor collection name
      /// </summary>
      public string DocumentDBJobGradeFactorCollectionName { get; set; }

      /// <summary>
      /// Gets or sets document db score quintile collection name
      /// </summary>
      public string DocumentDBScoreQuintileCollectionName { get; set; }

      /// <summary>
      /// Gets or sets document db excluded product code collection name
      /// </summary>
      public string DocumentDBExcludedProductCodeCollectionName { get; set; }

      /// <summary>
      /// Gets or sets document db excluded sales office collection name
      /// </summary>
      public string DocumentDBExcludedSalesOfficeCollectionName { get; set; }

      /// <summary>
      /// Gets or sets document db job size factor collection name
      /// </summary>
      public string DocumentDBJobSizeFactorCollectionName { get; set; }
   }
}
