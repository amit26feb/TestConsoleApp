﻿// <copyright file="OrderQueries.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.Constants
{
   /// <summary>
   /// Queries to support the retrival of new sales orders
   /// </summary>
   public static class OrderQueries
   {
      /// <summary>
      /// Get recently transmitted enterprise sales orders (FIRST SALES_ORDER FOR A CREDIT JOB ONLY)
      /// </summary>
      public const string GetNewOrders =
         @"
SELECT  
    so.sales_ord_id,
    j.job_id,
    cj.credit_job_id,
    cj.bid_alternate_id,
    cj.spa_number,
    so.date_created,
    j.originating_dr_address,
    j.watcom_job_id
FROM sales_order so
JOIN credit_job cj ON so.credit_job_id = cj.credit_job_id
JOIN job j ON cj.job_id = j.job_id
WHERE
    so.date_created > :LAST_DATE
    and so.date_created = (
        select min(so2.date_created)
        from sales_order so2 
        where so2.credit_job_id = cj.credit_job_id        
    )";
   }
}
