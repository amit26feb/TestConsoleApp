// <copyright file="JobScoreQueries.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.Constants
{
   /// <summary>
   /// Queries to support the CREDIT JOB SCORE process
   /// </summary>
   public static class JobScoreQueries
   {
      /// <summary>
      /// Get Credit Job by Hqtr Id.
      /// </summary>
      public const string GetCreditJobById =
         @"SELECT
            hqtr_credit_job_id,
            dr_address_id,
            job_id,
            bid_alternate_id,
            process_date,
            retry_count,
            letter_score
         FROM
            credit_job_score_process
         WHERE
            hqtr_credit_job_id = :HQTR_CREDIT_JOB_ID";

      /// <summary>
      /// Query records in CREDIT_JOB_SCORE_STAGE to obtain records which potentially need to be processed.
      /// </summary>
      public const string GetJobScoreStagingEntries =
         @"SELECT
            sales_ord_id,
            dr_address_id,
            hqtr_credit_job_id,
            created_date,
            job_id,
            bid_alternate_id,
            spa_number
         FROM
            credit_job_score_stage";

      /// <summary>
      /// Query records in CREDIT_JOB_SCORE_PROCESS to obtain records which need to be processed.
      /// We are looking for "unscored" credit jobs that:
      ///   * have not been attempted yet (PROCESS_DATE is null for these)
      ///   OR
      ///   * have been attempted already, without reaching the maximum number or retries, also respecting a "waiting period" where we wait a bit before retrying the same credit job
      /// </summary>
      public const string GetJobScorePendingProcess =
         @"SELECT
            hqtr_credit_job_id,
            dr_address_id,
            job_id,
            bid_alternate_id,
            process_date,
            retry_count,
            spa_number
         FROM
            credit_job_score_process
         WHERE
            letter_score IS NULL
            AND (
              (process_date IS NULL) OR 
              (process_date IS NOT NULL AND NVL(retry_count,0) < :MAX_NUM_RETRIES AND process_date < F_DBDATE - ((1 / 1440) * :MINUTES_PAUSE))
            )
         FETCH FIRST 50 ROWS ONLY";

      /// <summary>
      /// Create entry for a credit job to be scored
      /// </summary>
      public const string CreateProcessEntry =
         @"INSERT INTO credit_job_score_process (
            hqtr_credit_job_id,
            dr_address_id,
            job_id,
            bid_alternate_id,
            created_date,
            spa_number
          ) VALUES (
            :HQTR_CREDIT_JOB_ID,
            :DR_ADDRESS_ID,
            :JOB_ID,
            :BID_ALTERNATE_ID,
            F_DBDATE(),
            :SPA_NUMBER
          )";

      /// <summary>
      /// Remove all records from CREDIT_JOB_SCORE_STAGE for a credit job
      /// </summary>
      public const string DeleteFromStaging =
         @"DELETE FROM credit_job_score_stage
           WHERE  hqtr_credit_job_id = :HQTR_CREDIT_JOB_ID";

      /// <summary>
      /// Mark CREDIT_JOB as having been processed (submitted for scoring)
      /// </summary>
      public const string MarkForProcessing =
         @"UPDATE credit_job_score_process
           SET    process_date = F_DBDATE,
                  retry_count = :RETRY_COUNT
           WHERE  hqtr_credit_job_id = :HQTR_CREDIT_JOB_ID
           AND    (process_date is null or retry_count = :RETRY_COUNT - 1)";

      /// <summary>
      /// Add LETTER_SCORE to CREDIT_JOB (scoring completed)
      /// </summary>
      public const string SetScoreResults =
         @"UPDATE credit_job_score_process
           SET    letter_score = :LETTER_SCORE,
                  excluded_from_topper = :EXCLUDED_FROM_TOPPER
           WHERE  hqtr_credit_job_id = :HQTR_CREDIT_JOB_ID";

      /// <summary>
      /// Create entry for a newly transmitted sales order
      /// </summary>
      public const string CreateStageEntry =
         @"INSERT INTO credit_job_score_stage (
            sales_ord_id,
            dr_address_id,
            hqtr_credit_job_id,
            created_date,
            job_id,
            bid_alternate_id,
            spa_number
          ) VALUES (
            :SALES_ORDER_ID,
            :DR_ADDRESS_ID,
            :HQTR_CREDIT_JOB_ID,
            F_DBDATE(),
            :JOB_ID,
            :BID_ALTERNATE_ID,
            :SPA_NUMBER
          )";

      /// <summary>
      /// Get bid alternate by Hqtr Bid Alternate Id
      /// </summary>
      public const string GetBidAlternateByHqtrId =
         @"SELECT 
               bid_alternate_id
           FROM
               bid_alternate
           WHERE
               hqtr_bid_alternate_id = :HQTR_BID_ALTERNATE_ID";

      /// <summary>
      /// Get letter score by bid alternate id and job id
      /// </summary>
      public const string GetJobAggregatedGrade = @"SELECT 
                                                           * 
                                                         FROM 
                                                           (
                                                             SELECT 
                                                               LETTER_SCORE, 
                                                               CREATED_DATE, 
                                                               EXCLUDED_FROM_TOPPER 
                                                             FROM 
                                                               CREDIT_JOB_SCORE_PROCESS 
                                                             WHERE 
                                                               BID_ALTERNATE_ID = :BID_ALTERNATE_ID 
                                                               AND JOB_ID = :JOB_ID 
                                                             ORDER BY 
                                                               CREATED_DATE
                                                           ) 
                                                         WHERE 
                                                           ROWNUM = 1";

      /// <summary>
      /// Get job by Hqtr Job Id
      /// </summary>
      public const string GetJobByHqtrId =
         @"SELECT 
               job_id,
               dr_address_id
           FROM
               job
           WHERE
               hqtr_job_id = :HQTR_JOB_ID";

      /// <summary>
      /// Get time of last insertion
      /// </summary>
      public const string GetLastExecution =
         @"SELECT MAX(created_date)
           FROM   credit_job_score_process";

      /// <summary>
      /// Create entry for score information for job
      /// </summary>
      public const string JobScoreInsertQuery =
         @"INSERT INTO JOB_SCORE(
            JOB_SCORE_ID,
            JOB_ID,
            BID_ALTERNATE_ID,
            CREATED_DATE,
            CREATED_USER,
            JOB_SIZE,
            LETTER_SCORE,
            EXCLUDED
          ) VALUES(
            :JOB_SCORE_ID,
            :JOB_ID,
            :BID_ALTERNATE_ID,
            F_DBDATE(),
            :CREATED_USER,
            :JOB_SIZE,
            :LETTER_SCORE,
            :EXCLUDED
             )";

      /// <summary>
      /// Create entry for score information for line item
      /// </summary>
      public const string JobScoreLineInsertQuery =
         @"INSERT INTO JOB_SCORE_LINE (
            JOB_SCORE_LINE_ID,
            JOB_SCORE_ID,
            PROD_CODE,
            LETTER_SCORE,
            EXCLUDED,
            JOB_SIZE
          ) VALUES (
            :JOB_SCORE_LINE_ID,
            :JOB_SCORE_ID,
            :PROD_CODE,
            :LETTER_SCORE,
            :EXCLUDED,
            :JOB_SIZE
          )";

      /// <summary>
      /// Get sequence number for a specific table
      /// </summary>
      public const string GetSequenceNumberQuery =
         @"SELECT PKG_SEQUENCE_NUMBER.GET_NEXT_SEQUENCE(: TABLENAME, : HOWMANYTORESERVE) FROM DUAL";

      /// <summary>
      /// Retrieve list of job aggregated grade for ordered product for a given job id and bid alternate ids
      /// </summary>
      public const string GetJobAggregatedGradeForOrderedProduct = @"SELECT BID_ALTERNATE_ID,
                                                                            LETTER_SCORE,
                                                                            CREATED_DATE,
                                                                            EXCLUDED_FROM_TOPPER
                                                                     FROM CREDIT_JOB_SCORE_PROCESS
                                                                     WHERE  JOB_ID = : JOB_ID AND BID_ALTERNATE_ID IN :BID_ALTERNATE_IDS";

      /// <summary>
      /// Retrieve list of job aggregated grade for unordered product for a given job id and bid alternate ids
      /// </summary>
      public const string GetJobAggregatedGradeForUnorderedProduct = @"SELECT BID_ALTERNATE_ID,
                                                                            LETTER_SCORE,
                                                                            CREATED_DATE,
                                                                            JOB_SCORE_ID
                                                                     FROM JOB_SCORE
                                                                     WHERE  JOB_ID = : JOB_ID AND BID_ALTERNATE_ID IN :BID_ALTERNATE_IDS";
   }
}
