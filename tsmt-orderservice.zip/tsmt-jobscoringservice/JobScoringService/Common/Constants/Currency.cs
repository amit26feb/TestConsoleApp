﻿// <copyright file="Currency.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.Constants
{
   /// <summary>
   /// Currency types
   /// </summary>
   public static class Currency
   {
      /// <summary>
      /// USD
      /// </summary>
      public const string USD = "$USD";

      /// <summary>
      /// Canadian
      /// </summary>
      public const string CAD = "$CAD";
   }
}
