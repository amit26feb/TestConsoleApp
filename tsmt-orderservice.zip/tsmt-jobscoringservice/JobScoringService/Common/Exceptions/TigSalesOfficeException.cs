﻿// <copyright file="TigSalesOfficeException.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.Exceptions
{
   /// <summary>
   /// Special Exception to short-circuit scoring of TIG sales office jobs
   /// </summary>
   public class TigSalesOfficeException : JobScoringServiceDomainException
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="TigSalesOfficeException"/> class.
      /// </summary>
      public TigSalesOfficeException()
      {
      }
   }
}
