// <copyright file="JobScoreEnum.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.Enumerators
{
   /// <summary>
   /// Enum for job score
   /// </summary>
   public enum JobScore
   {
      /// <summary>
      /// Job score A
      /// </summary>
      A,

      /// <summary>
      /// Job score B
      /// </summary>
      B,

      /// <summary>
      /// Job score C
      /// </summary>
      C,

      /// <summary>
      /// Job score D
      /// </summary>
      D,

      /// <summary>
      /// Job score E
      /// </summary>
      E
   }
}
