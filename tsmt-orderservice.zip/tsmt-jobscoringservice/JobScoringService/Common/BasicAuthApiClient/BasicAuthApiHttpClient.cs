﻿// <copyright file="BasicAuthApiHttpClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.BasicAuthApiClient
{
   using System;
   using System.Net.Http;
   using System.Net.Http.Headers;
   using System.Text;
   using Microsoft.AspNetCore.Server.HttpSys;

   /// <summary>
   /// API Http Client class that uses basic authentication (username and password).
   /// </summary>
   public class BasicAuthApiHttpClient : HttpClient, IBasicAuthApiHttpClient
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="BasicAuthApiHttpClient"/> class.
      /// </summary>
      public BasicAuthApiHttpClient()
          : base()
      {
      }

      /// <inheritdoc/>
      public void SetBasicAuthParameters(string username, string password)
      {
         this.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            AuthenticationSchemes.Basic.ToString(),
            Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}")));
      }
   }
}
