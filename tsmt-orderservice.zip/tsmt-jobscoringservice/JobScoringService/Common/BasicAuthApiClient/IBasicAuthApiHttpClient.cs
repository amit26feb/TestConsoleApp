﻿// <copyright file="IBasicAuthApiHttpClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Common.BasicAuthApiClient
{
   using System;
   using System.Net.Http;
   using System.Threading.Tasks;

   /// <summary>
   /// Interface for BasicAuthApiHttpClient to enable unit testing http methods against an http client that utilizes basic auth
   /// </summary>
   public interface IBasicAuthApiHttpClient
   {
      /// <summary>
      /// Gets or sets the base address of the URI to send/get requests
      /// </summary>
      Uri BaseAddress { get; set; }

      /// <summary>
      /// Sets up basic authentication on the underlying HttpClient.
      /// </summary>
      /// <param name="username">basic auth username</param>
      /// <param name="password">basic auth password</param>
      void SetBasicAuthParameters(string username, string password);

      /// <summary>
      /// Get data from the uri
      /// </summary>
      /// <param name="requestUri">Uri to get from</param>
      /// <returns>Task of HttpResponseMessage</returns>
      Task<HttpResponseMessage> GetAsync(string requestUri);

      /// <summary>
      /// Post data to the uri
      /// </summary>
      /// <param name="requestUri">Uri to post to</param>
      /// <param name="content">HttpContent to post</param>
      /// <returns>Task of HttpResponseMessage</returns>
      Task<HttpResponseMessage> PostAsync(string requestUri, HttpContent content);

      /// <summary>
      /// Put data to the uri
      /// </summary>
      /// <param name="requestUri">Uri to put to</param>
      /// <param name="content">HttpContent to put</param>
      /// <returns>Task of HttpResponseMessage</returns>
      Task<HttpResponseMessage> PutAsync(string requestUri, HttpContent content);
   }
}
