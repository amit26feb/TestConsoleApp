﻿// <copyright file="Program.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService
{
    using System.IO;
    using JobScoringService.Configurations;
    using Microsoft.AspNetCore;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using NLog.Web;
    using TSMT.Settings;

    /// <summary>
    /// Program
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Service entry point
        /// </summary>
        /// <param name="args">Args</param>
        public static void Main(string[] args)
        {
            BuildWebHost(args).Build().Run();
        }

        /// <summary>
        /// Builds web host
        /// </summary>
        /// <param name="args">Arguments</param>
        /// <returns>App</returns>
        public static IWebHostBuilder BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .ConfigureAppConfiguration((builderContext, config) =>
                {
                    IWebHostEnvironment env = builderContext.HostingEnvironment;
                    config.AddJsonFile("appsettings.json", optional: false)
                    .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);
                    IConfigurationRoot configBuilder = config.Build();
                    config.Add(new TsmtConfigurationSource<ConfigParameterConstants>(env.EnvironmentName, configBuilder["AWSRegion"].ToString()));
                    config.AddEnvironmentVariables();
                })
                .ConfigureLogging((hostingContext, builder) =>
                {
                    builder.AddConfiguration(hostingContext.Configuration.GetSection("Logging"));
                    builder.AddConsole();
                    builder.AddDebug();
                })
                .UseNLog();
    }
}
