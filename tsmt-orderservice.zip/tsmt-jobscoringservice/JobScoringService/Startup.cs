﻿// <copyright file="Startup.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Reflection;
   using Amazon.S3;
   using App.Metrics;
   using Autofac;
   using Autofac.Extensions.DependencyInjection;
   using AutoMapper;
   using CrossCuttingServices.Common.Filters;
   using CrossCuttingServices.Common.Middlewares;
   using JobScoringService.Common.Configurations.AutofacModules;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Configurations.AutoMapperConfiguration;
   using JobScoringService.Core.Services;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Builder;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.AspNetCore.Mvc.Authorization;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.OpenApi.Models;
   using NLog.Web;
   using Okta.AspNetCore;
   using TraneSalesTools.Middlewares;
   using TSMT.Settings;

   /// <summary>
   /// Startup
   /// </summary>
   public class Startup
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="Startup"/> class.
      /// </summary>
      /// <param name="configuration">Iconfigration</param>
      /// <param name="env">Environment</param>
      public Startup(IConfiguration configuration, IWebHostEnvironment env)
      {
         this.Configuration = configuration;
         this.HostingEnvironment = env;
         NLogBuilder.ConfigureNLog($"nlog.{env.EnvironmentName}.config");
      }

      /// <summary>
      /// Gets iConfiguration
      /// </summary>
      public IConfiguration Configuration { get; }

      /// <summary>
      /// Gets the web hosting Environment.
      /// </summary>
      public IWebHostEnvironment HostingEnvironment { get; }

      /// <summary>
      /// Configure Services
      /// </summary>
      /// <param name="services">Services</param>
      /// <returns>IService Provider</returns>
      // This method gets called by the runtime. Use this method to add services to the container.
      public IServiceProvider ConfigureServices(IServiceCollection services)
      {
         // Add framework services.
         IMetricsRoot metrics = AppMetrics.CreateDefaultBuilder()
            .Configuration.Configure(
                  options =>
                  {
                     options.AddEnvTag(this.HostingEnvironment.EnvironmentName);
                  })
               .Report.ToInfluxDb(options =>
               {
                  options.InfluxDb.BaseUri = new Uri(this.Configuration["InfluxDbUrl"]);
                  options.InfluxDb.Database = this.Configuration["InfluxDb"];
                  options.InfluxDb.UserName = this.Configuration["InfluxDbUserName"];
                  options.InfluxDb.Password = this.Configuration["InfluxDbPassword"];
                  options.InfluxDb.CreateDataBaseIfNotExists = true;
               }).Build();

         services.AddMetrics(metrics);
         services.AddMetricsReportingHostedService();
         services.AddMetricsEndpoints();
         services.AddMetricsTrackingMiddleware();

         // Add framework services.
         services.AddMvc(options =>
         {
            options.Filters.Add(typeof(HttpGlobalExceptionFilter<JobScoringServiceDomainException>));

            AuthorizationPolicy policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
            options.Filters.Add(new AuthorizeFilter(policy));
         })
            .AddControllersAsServices()
            .AddMetrics()
            .AddNewtonsoftJson()
            .AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null);  // During calls to JsonConvert.SerializeObject, this keeps the JSON attributes looking exactly like the model attributes, so it doesn't camelCase them.  We want this behavior because the current JobGrader API is expecting a request payload that is PascalCased instead of camelCased.

         services.Configure<TSMTSettings>(this.Configuration);
         services.Configure<Settings>(this.Configuration);
         services.AddAWSService<IAmazonS3>(ServiceLifetime.Transient);

         // Add framework services.
         services.AddSwaggerGen(options =>
         {
#pragma warning disable SA1118 // Parameter must not span multiple lines
            options.SwaggerDoc("v1", new OpenApiInfo
            {
               Title = "Job Scoring Service HTTP API",
               Version = "v1",
               Description = "Job Scoring Service HTTP API"
            });
            OpenApiSecurityScheme apiKeyScheme = new OpenApiSecurityScheme()
            {
               Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
               Name = "Authorization",
               In = ParameterLocation.Header,
               Type = SecuritySchemeType.ApiKey,
               Scheme = "Bearer",
               BearerFormat = "JWT"
            };
            options.AddSecurityDefinition("Bearer", apiKeyScheme);
            options.AddSecurityRequirement(new OpenApiSecurityRequirement()
            {
               {
                  new OpenApiSecurityScheme
                  {
                     Reference = new OpenApiReference
                        {
                           Type = ReferenceType.SecurityScheme,
                           Id = "Bearer",
                        },
                     Scheme = "OAuth2",
                     Name = "Bearer",
                     In = ParameterLocation.Header
                  }, new List<string>()
               }
            });

            //// Set the comments path for the Swagger JSON and UI.
            string xmlFile = $"{Assembly.GetEntryAssembly().GetName().Name}.xml";
            string xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            options.IncludeXmlComments(xmlPath);
         });

         services.AddAuthentication(options =>
         {
            options.DefaultAuthenticateScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultChallengeScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultSignInScheme = OktaDefaults.ApiAuthenticationScheme;
         })
         .AddOktaWebApi(new OktaWebApiOptions()
         {
            OktaDomain = this.Configuration["OktaDomain"],
            AuthorizationServerId = this.Configuration["OktaAuthorizationServerID"]
         });

         services.AddCors(options =>
         {
            options.AddPolicy(
                   "CorsPolicy",
                   builder => builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader()
                   .WithExposedHeaders("Content-Disposition"));
         });

         services.AddApiVersioning();
         services.AddOptions();
         services.AddAutoMapper(typeof(AutoMapperProfile));
         services.AddHttpClient();

         // configure autofac
         ContainerBuilder container = new ContainerBuilder();
         container.Populate(services);

         // The mediator module uses the pipeline, notification and Request/Response Command handler
         // This is stored as a separate Module
         container.RegisterModule(new MediatorModule(this.Configuration));

         return new AutofacServiceProvider(container.Build());
      }

      /// <summary>
      /// Configure
      /// </summary>
      /// <param name="app">IApplication builder</param>
      /// <param name="env">Environment</param>
      // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
      public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
      {
         string live = "/liveness";
         string pathBase = this.Configuration["PATH_BASE"];

         if (!string.IsNullOrWhiteSpace(pathBase))
         {
            app.UsePathBase(pathBase);
         }

         app.UseMiddleware<LoggerMiddleware>();
         app.UseMetricsAllMiddleware();
         app.UseMetricsAllEndpoints();
#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
         app.Map(live, lapp => lapp.Run(async ctx => ctx.Response.StatusCode = 200));
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously

         app.UseRouting();
         app.UseCors("CorsPolicy");

         app.UseAuthentication();
         app.UseAuthorization();
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseDrAddressIdResolver();
         });
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseVPDAuthenticator();
         });

         app.UseEndpoints(endpoints =>
         {
            endpoints.MapControllers();
         });

         app.UseSwagger()
            .UseSwaggerUI(c =>
            {
               c.SwaggerEndpoint($"{(!string.IsNullOrWhiteSpace(pathBase) ? pathBase : string.Empty)}/swagger/v1/swagger.json", "JobScoringService.API V1");
            });
      }
   }
}