﻿// <copyright file="CreditJobScoreProcessViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   /// <summary>
   /// View for credit job score process
   /// </summary>
   public class CreditJobScoreProcessViewModel
   {
      /// <summary>
      /// Gets or sets headquarters credit job id
      /// </summary>
      public int HqtrCreditJobId { get; set; }

      /// <summary>
      /// Gets or sets letter score
      /// </summary>
      public string LetterScore { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether excluded from topper or not
      /// </summary>
      public bool ExcludedFromTopper { get; set; }
   }
}
