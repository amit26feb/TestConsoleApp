﻿// <copyright file="ProductCodeFilterViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   using System.Collections.Generic;
   using DataAccess.Paging;

   /// <summary>
   /// View model for product code filter
   /// </summary>
   public class ProductCodeFilterViewModel
   {
      /// <summary>
      /// Gets or sets filters
      /// </summary>
      public List<FilterCollection> Filters { get; set; }
   }
}
