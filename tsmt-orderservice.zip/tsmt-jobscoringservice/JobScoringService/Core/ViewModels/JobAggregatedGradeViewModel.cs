﻿// <copyright file="JobAggregatedGradeViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   using System;

   /// <summary>
   /// Job aggregated grade properties
   /// </summary>
   public class JobAggregatedGradeViewModel
   {
      /// <summary>
      /// Gets or sets letter score
      /// </summary>
      public string LetterScore { get; set; }

      /// <summary>
      /// Gets or sets created date
      /// </summary>
      public DateTime CreatedDate { get; set; }

      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets excluded from topper
      /// </summary>
      public string ExcludedFromTopper { get; set; }
   }
}
