﻿// <copyright file="JobScoringDataViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;

   /// <summary>
   /// Class containing job scoring related properties
   /// </summary>
   public class SalesOfficeScoringDataViewModel
   {
      /// <summary>
      /// Gets or sets an enumeration of product code quintiles
      /// </summary>
      public IEnumerable<ProductCodeQuintilesViewModel> ProductCodeQuintiles { get; set; }

      /// <summary>
      /// Gets or sets the job scoring factor
      /// </summary>
      public decimal JobSizeFactor { get; set; }

      /// <summary>
      /// Gets or sets the currency exchange rate
      /// </summary>
      public decimal CurrencyExchangeRate { get; set; }
   }
}
