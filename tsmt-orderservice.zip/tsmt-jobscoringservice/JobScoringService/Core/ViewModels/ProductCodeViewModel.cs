﻿// <copyright file="ProductCodeViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   /// <summary>
   /// View model for product code details
   /// </summary>
   public class ProductCodeViewModel
   {
      /// <summary>
      /// Gets or sets prod code
      /// </summary>
      public string ProdCode { get; set; }

      /// <summary>
      /// Gets or sets description
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets product code type
      /// </summary>
      public string ProdCodeType { get; set; }

      /// <summary>
      /// Gets or sets status
      /// </summary>
      public string Status { get; set; }
   }
}
