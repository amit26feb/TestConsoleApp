﻿// <copyright file="ProductCodeQuintilesViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;

   /// <summary>
   /// Class containing quintile data for a given product code
   /// </summary>
   public class ProductCodeQuintilesViewModel
   {
      /// <summary>
      /// Gets or sets the product code that this quintile information applies to
      /// </summary>
      public string ProductCode { get; set; }

      /// <summary>
      /// Gets or sets a collection of quintiles, there are 10 job size buckets per product code
      /// </summary>
      public IEnumerable<QuintileViewModel> Quintiles { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the product code is exempt from scoring
      /// </summary>
      public bool IsExempt { get; set; }
   }
}
