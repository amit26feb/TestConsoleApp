﻿// <copyright file="QuintileViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;

   /// <summary>
   /// Class for quintile or job bucket related properties
   /// </summary>
   public class QuintileViewModel
   {
      /// <summary>
      /// Gets or sets jobe size min
      /// </summary>
      public decimal JobSizeMin { get; set; }

      /// <summary>
      /// Gets or sets job size max
      /// </summary>
      public decimal JobSizeMax { get; set; }

      /// <summary>
      ///  Gets or sets start b
      /// </summary>
      public decimal StartB { get; set; }

      /// <summary>
      ///  Gets or sets start c
      /// </summary>
      public decimal StartC { get; set; }

      /// <summary>
      ///  Gets or sets start d
      /// </summary>
      public decimal StartD { get; set; }

      /// <summary>
      ///  Gets or sets start e
      /// </summary>
      public decimal StartE { get; set; }
   }
}
