﻿// <copyright file="SalesOfficeScoringDataSearchViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ViewModels
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;

   /// <summary>
   /// Input params for SalesOfficeScoringDataSearch
   /// </summary>
   public class SalesOfficeScoringDataSearchViewModel
   {
      /// <summary>
      /// Gets or sets prodCodes
      /// </summary>
      public IEnumerable<string> ProdCodes { get; set; }

      /// <summary>
      /// Gets or sets custChannelId
      /// </summary>
      public string CustChannelId { get; set; }
   }
}
