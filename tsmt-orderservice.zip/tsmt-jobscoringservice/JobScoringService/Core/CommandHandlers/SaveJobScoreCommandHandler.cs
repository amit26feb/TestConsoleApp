﻿// <copyright file="SaveJobScoreCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.CommandHandlers
{
   using System.Threading;
   using System.Threading.Tasks;
   using JobScoringService.Core.Commands;
   using JobScoringService.Core.Services;
   using MediatR;

   /// <summary>
   /// Handler which process the command for saving job score info
   /// </summary>
   public class SaveJobScoreCommandHandler : IRequestHandler<SaveJobScoreCommand, bool>
   {
      private readonly IJobScoreReportService jobScoreReportService;

      /// <summary>
      /// Initializes a new instance of the <see cref="SaveJobScoreCommandHandler"/> class.
      /// </summary>
      /// <param name="jobScoreReportService">Job score report service</param>
      public SaveJobScoreCommandHandler(IJobScoreReportService jobScoreReportService)
      {
         this.jobScoreReportService = jobScoreReportService;
      }

      /// <summary>
      /// Handler which process the saving job score info
      /// </summary>
      /// <param name="request">Request payload for saving job score info</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>Boolean</returns>
      public async Task<bool> Handle(SaveJobScoreCommand request, CancellationToken cancellationToken)
      {
         return await this.jobScoreReportService.SaveJobScoreInfo(request.JobGraderResponse, request.JobId, request.BidAlternateId);
      }
   }
}
