﻿// <copyright file="IJobScoreReportService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for job score reporting service
   /// </summary>
   public interface IJobScoreReportService
   {
      /// <summary>
      /// Saving job score information
      /// </summary>
      /// <param name="jobGraderResponse">Job Grade Response which needs to be saved</param>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Returns true if data saved successfully else false</returns>
      Task<bool> SaveJobScoreInfo(JobGraderResponse jobGraderResponse, int jobId, int bidAlternateId);
   }
}
