﻿// <copyright file="IJobGraderRequestBuilder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for building Job Grader request payloads
   /// </summary>
   public interface IJobGraderRequestBuilder
   {
      /// <summary>
      /// Builds a Job Grader request payload, for a given job
      /// </summary>
      /// <param name="drAddressId">The dr address ID for the job</param>
      /// <param name="jobId">The job ID</param>
      /// <param name="bidAlternateId">The bid alternate ID</param>
      /// <param name="isFinalScore">If [true] then this request will be flagged as the final scoring request.</param>
      /// <returns>JobGraderRequest payload</returns>
      Task<JobGraderRequest> BuildJobGraderRequest(int drAddressId, int jobId, int bidAlternateId, bool isFinalScore = false);
   }
}
