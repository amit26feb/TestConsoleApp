﻿// <copyright file="IJobScoringProcessService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ViewModels;

   /// <summary>
   /// Interface for Job Score Service
   /// </summary>
   public interface IJobScoringProcessService
   {
      /// <summary>
      /// Updating process data
      /// </summary>
      /// <returns>Task</returns>
      Task BuildProcessEntries();

      /// <summary>
      /// Get listing of credit jobs to be submitted for grading
      /// </summary>
      /// <param name="maxNumRetries">Maximum number of allowable retries</param>
      /// <param name="minutesPauseBeforeRetryingCreditJob">Minutes to wait before retrying a credit job that recently failed</param>
      /// <returns>collection of credit jobs</returns>
      Task<IEnumerable<CreditJob>> GetJobsToGrade(int maxNumRetries, int minutesPauseBeforeRetryingCreditJob);

      /// <summary>
      /// Mark credit job as having been submitted for grading
      /// </summary>
      /// <param name="hqtrCreditJobId">Credit Job Id</param>
      /// <param name="retryCount">(optional) allow for tracking of number of retry attempts</param>
      /// <returns>Task</returns>
      Task<bool> MarkAsProcessed(int hqtrCreditJobId, int retryCount = 0);

      /// <summary>
      /// Record results of successful grade operation
      /// </summary>
      /// <param name="creditJobScore">View for credit job score</param>
      /// <returns>Task</returns>
      Task RecordGrade(CreditJobScoreProcessViewModel creditJobScore);

      /// <summary>
      /// Retrieve job aggregated grade for a given job id and bid alternate id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Job aggregated grade</returns>
      Task<JobAggregatedGradeViewModel> GetJobAggregatedGrade(int jobId, int bidAlternateId);

      /// <summary>
      /// Retrieve list of job aggregated grade for a given job id and bid alternate ids
      /// </summary>
      /// <param name="drAddressId">Dr address id</param>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateIds">Bid alternate ids</param>
      /// <returns>Job aggregated grade list</returns>
      Task<IEnumerable<JobAggregatedGradeViewModel>> GetJobAggregatedGradeList(int drAddressId, int jobId, IEnumerable<int> bidAlternateIds);
   }
}
