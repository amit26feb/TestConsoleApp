﻿// <copyright file="IJobScoreCalculatorService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Service for job score calculator
   /// </summary>
   public interface IJobScoreCalculatorService
   {
      /// <summary>
      /// Get job grade factor
      /// </summary>
      /// <returns>Job grade factor</returns>
      Task<decimal> GetJobGradeFactor();

      /// <summary>
      /// Get excluded product codes
      /// </summary>
      /// <returns>Excluded product codes</returns>
      Task<IEnumerable<ExcludedProductCode>> GetExcludedProductCodes();

      /// <summary>
      /// Get job size
      /// </summary>
      /// <param name="jobSizeDollar">Job size dollar</param>
      /// <returns>Job size</returns>
      Task<string> GetJobSize(decimal jobSizeDollar);

      /// <summary>
      /// Calculate alternative display for given next score rated multiplier
      /// </summary>
      /// <param name="nextScoreRatedMultiplier">Next score rated multiplier</param>
      /// <returns>Alternative display</returns>
      string CalculateAlternativeDisplay(decimal nextScoreRatedMultiplier);

      /// <summary>
      /// Job score validation based on product code and unadjusted list price
      /// </summary>
      /// <param name="productCode">Product code</param>
      /// <param name="unAdjustedListprice">Unadjusted list price</param>
      /// <param name="excludedProductCodes">Excluded product codes</param>
      /// <returns>Boolean</returns>
      bool JobScoreValidation(string productCode, decimal unAdjustedListprice, IEnumerable<ExcludedProductCode> excludedProductCodes);

      /// <summary>
      /// Get job grade
      /// </summary>
      /// <param name="jobGraderRequest">Job grader request</param>
      /// <returns>Job grader response</returns>
      Task<JobGraderResponse> GetJobGrade(JobGraderRequest jobGraderRequest);

      /// <summary>
      /// Calculate display dollar amount based on letter score value
      /// </summary>
      /// <param name="response">Job grader response</param>
      void CalculateDisplayDollarAmount(JobGraderResponse response);

      /// <summary>
      /// Calculating rated cutoff value based on job score
      /// </summary>
      /// <param name="jobGradeFactor">Job grade factor</param>
      /// <param name="response">Job score response</param>
      /// <param name="jobScoreQuintile">Job score quintile data</param>
      void CalculateRatedCutOff(decimal jobGradeFactor, JobGraderResponse response, JobScoreQuintile jobScoreQuintile);
   }
}
