// <copyright file="OrderCreationHostedService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Threading.Tasks;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;

   /// <summary>
   /// Service to identify newly created orders as a background process
   /// </summary>
   public class OrderCreationHostedService : HostedServiceBase
   {
      private readonly IOrderCreationProcessService orderCreationService;

      /// <summary>
      /// Initializes a new instance of the <see cref="OrderCreationHostedService"/> class.
      /// </summary>
      /// <param name="log">Logging the information</param>
      /// <param name="jobScoringSettings">settings</param>
      /// <param name="serviceProvider">Service Provider</param>
      /// <param name="orderCreationService">instance of Order Creation Process service</param>
      public OrderCreationHostedService(
            ILogger<OrderCreationHostedService> log,
            IOptions<Settings> jobScoringSettings,
            IServiceProvider serviceProvider,
            IOrderCreationProcessService orderCreationService)
            : base(log, jobScoringSettings, serviceProvider)
      {
         this.orderCreationService = orderCreationService;
      }

      /// <summary>
      /// Worker process
      /// </summary>
      /// <returns>Task</returns>
      protected override async Task DoProcesss()
      {
         try
         {
            await this.IdentifyCreatedOrders();
         }
         catch (Exception ex)
         {
            this.Logger.LogError("Order Creation background encountered an error during processing - {0}", ex.ToString());
         }
      }

      /// <summary>
      /// Process recently transmitted sales orders to determine credit jobs to grade
      /// </summary>
      /// <returns>task</returns>
      private async Task IdentifyCreatedOrders()
      {
         await this.orderCreationService.ImportRecentlyTransmittedOrders();
      }
   }
}
