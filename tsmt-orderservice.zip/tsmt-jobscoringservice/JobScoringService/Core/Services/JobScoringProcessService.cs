﻿// <copyright file="JobScoringProcessService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ViewModels;

   /// <summary>
   /// Service for Job Score operations on process data
   /// </summary>
   public class JobScoringProcessService : IJobScoringProcessService
   {
      private readonly IJobScoreRepository repository;
      private readonly IMapper mapper;
      private readonly IJobScoreReportRepository jobScoreReportRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoringProcessService"/> class.
      /// </summary>
      /// <param name="repository">repository</param>
      /// <param name="mapper">mapper</param>
      /// <param name="jobScoreReportRepository">Job score report repository</param>
      public JobScoringProcessService(IJobScoreRepository repository, IMapper mapper, IJobScoreReportRepository jobScoreReportRepository)
      {
         this.repository = repository;
         this.mapper = mapper;
         this.jobScoreReportRepository = jobScoreReportRepository;
      }

      /// <inheritdoc/>
      public async Task BuildProcessEntries()
      {
         // get recently transmitted sales orders
         IEnumerable<SalesOrder> newSalesOrders = await this.repository.GetNewTransmittedOrders();

         // group by key - only interested in a single credit job
         var newHqtrIdGroups = newSalesOrders.GroupBy(x => x.HqtrCreditJobId);

         foreach (var hqtrGroup in newHqtrIdGroups)
         {
            // check if credit job has already been graded
            //   if it has not already been created - create the entry
            // remove all credit job records from staging table
            bool creditJobExists = await this.repository.DoesCreditJobExist(hqtrGroup.Key);
            if (!creditJobExists)
            {
               // getting the first item in the group collection is sufficient; we're only interested in the credit job / job attributes
               SalesOrder salesOrder = hqtrGroup.First();

               await this.repository.CreateCreditJobProcessEntry(salesOrder.DrAddressId, salesOrder.JobId, salesOrder.HqtrCreditJobId, salesOrder.BidAlternateId, salesOrder.SpaNumber);
            }

            await this.repository.DeleteCreditJobFromStaging(hqtrGroup.Key);
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<CreditJob>> GetJobsToGrade(int maxNumRetries, int minutesPauseBeforeRetryingCreditJob)
      {
         return await this.repository.GetCreditJobsToGrade(maxNumRetries, minutesPauseBeforeRetryingCreditJob);
      }

      /// <inheritdoc/>
      public async Task<bool> MarkAsProcessed(int hqtrCreditJobId, int retryCount = 0)
      {
         return await this.repository.MarkCreditJobForProcessing(hqtrCreditJobId, retryCount);
      }

      /// <summary>
      /// Record results of successful grade operation
      /// </summary>
      /// <param name="creditJobScore">View for credit job score</param>
      /// <returns>Task</returns>
      public async Task RecordGrade(CreditJobScoreProcessViewModel creditJobScore)
      {
         await this.repository.SetCreditJobScoreResult(creditJobScore);
      }

      /// <summary>
      /// Retrieve job aggregated grade for a given job id and bid alternate id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Job aggregated grade</returns>
      public async Task<JobAggregatedGradeViewModel> GetJobAggregatedGrade(int jobId, int bidAlternateId)
      {
         JobAggregatedGrade jobAggregatedGrade = await this.repository.GetJobAggregatedGrade(jobId, bidAlternateId);
         return this.mapper.Map<JobAggregatedGrade, JobAggregatedGradeViewModel>(jobAggregatedGrade);
      }

      /// <summary>
      /// Retrieve list of job aggregated grade for a given job id and bid alternate ids
      /// </summary>
      /// <param name="drAddressId">Dr address id</param>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateIds">Bid alternate ids</param>
      /// <returns>Job aggregated grade list</returns>
      public async Task<IEnumerable<JobAggregatedGradeViewModel>> GetJobAggregatedGradeList(int drAddressId, int jobId, IEnumerable<int> bidAlternateIds)
      {
         IEnumerable<int> unorderedBidAlternateIds = new List<int>();
         List<JobAggregatedGrade> jobAggregatedGrades = (await this.repository.GetJobAggregatedGradeListForOrderedProduct(jobId, bidAlternateIds)).ToList();
         if (jobAggregatedGrades.Count > 0)
         {
            // Unordered bid alternate ids are obtained by selecting the list of bid alternate ids which have no data in the job aggregated grade list
            unorderedBidAlternateIds = bidAlternateIds.Where(x => !jobAggregatedGrades.Select(y => y.BID_ALTERNATE_ID).Contains(x)).ToList();

            // Filtered job aggregated grades are obtained as follows
            // 1. Grouping the grades based on bid alternate id
            // 2. Order the job aggregated grades in ascending order based on the created date for each bid alternate id
            // 3. Select the first job aggregated grade for each bid alternate id
            jobAggregatedGrades = jobAggregatedGrades.GroupBy(x => x.BID_ALTERNATE_ID).Select(s => s.OrderBy(y => y.CREATED_DATE).First()).ToList();
         }
         else
         {
            // When no grade exists in job aggregated grade list, all bid alternate ids are set as unordered
            unorderedBidAlternateIds = bidAlternateIds;
         }

         if (unorderedBidAlternateIds.Any())
         {
            this.jobScoreReportRepository.HonorDrAddressId(drAddressId);
            IEnumerable<JobAggregatedGrade> jobAggregatedGradesForUnorderedProduct = await this.jobScoreReportRepository.GetJobAggregatedGradeListForUnorderedProduct(jobId, unorderedBidAlternateIds);
            if (jobAggregatedGradesForUnorderedProduct.Any())
            {
               // Filtered job aggregated grades for unordered are obtained as follows
               // 1. Grouping the grades based on bid alternate id
               // 2. Order the job aggregated grades in descending order based on the job score id for each bid alternate id
               // 3. Select the first job aggregated grade for unordered product for each bid alternate id
               jobAggregatedGradesForUnorderedProduct = jobAggregatedGradesForUnorderedProduct.GroupBy(x => x.BID_ALTERNATE_ID).Select(s => s.OrderByDescending(y => y.JOB_SCORE_ID).First()).ToList();

               // Add the grades for unordered product to job aggregated grade list
               jobAggregatedGrades.AddRange(jobAggregatedGradesForUnorderedProduct);
            }
         }

         IEnumerable<JobAggregatedGradeViewModel> jobAggregatedGradeViewModels = this.mapper.Map<IEnumerable<JobAggregatedGrade>, IEnumerable<JobAggregatedGradeViewModel>>(jobAggregatedGrades);
         return jobAggregatedGradeViewModels;
      }
   }
}
