// <copyright file="JobScoringHostedService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Threading.Tasks;
   using Amazon.S3.Model;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using S3Wrapper;

   /// <summary>
   /// Service for scoring jobs as a background process
   /// </summary>
   public class JobScoringHostedService : HostedServiceBase
   {
      private readonly IJobScoringProcessService jobScoringService;
      private readonly IS3Repository s3Repo;
      private readonly IJobGraderRequestBuilder jobGraderBuilder;
      private readonly IJobScoreCalculatorService jobScoreCalculatorService;

      private HashSet<string> exemptSpaNumbers;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoringHostedService"/> class.
      /// </summary>
      /// <param name="log">Logging the information</param>
      /// <param name="jobScoringSettings">settings</param>
      /// <param name="serviceProvider">Service Provider</param>
      /// <param name="s3Repo">repository for S3 bucket (which houses the file of exempt SPA numbers)</param>
      /// <param name="jobGraderBuilder">instance of Job Grader Request Builder</param>
      /// <param name="jobScoringService">instance of Job Scoring Process service</param>
      /// <param name="jobScoreCalculatorService">instance of job score calculator service</param>
      public JobScoringHostedService(
            ILogger<JobScoringHostedService> log,
            IOptions<Settings> jobScoringSettings,
            IServiceProvider serviceProvider,
            IS3Repository s3Repo,
            IJobGraderRequestBuilder jobGraderBuilder,
            IJobScoringProcessService jobScoringService,
            IJobScoreCalculatorService jobScoreCalculatorService)
            : base(log, jobScoringSettings, serviceProvider)
      {
         this.jobScoringService = jobScoringService;
         this.s3Repo = s3Repo;
         this.jobGraderBuilder = jobGraderBuilder;
         this.jobScoreCalculatorService = jobScoreCalculatorService;
      }

      /// <summary>
      /// Submit jobs for grading and store successful results
      /// </summary>
      /// <param name="creditJobs">collection of jobs to be graded</param>
      /// <param name="spaNumbersExemptFromScoring">HashSet of SPA numbers that tell us a credit job should be exempt from normal scoring, and instead recieve a Z score</param>
      /// <returns>task</returns>
      public async Task GradeJobs(IEnumerable<CreditJob> creditJobs, HashSet<string> spaNumbersExemptFromScoring)
      {
         foreach (CreditJob cj in creditJobs)
         {
            int retryCount = cj.RetryCount;

            // Increment retry count, if this isn't the first try.
            if (cj.ProcessDate.HasValue)
            {
               retryCount++;
            }

            CreditJobScoreProcessViewModel creditJobScore = new CreditJobScoreProcessViewModel()
            {
               HqtrCreditJobId = cj.HqtrCreditJobId,
               ExcludedFromTopper = false,
               LetterScore = "Y"
            };

            try
            {
               // Mark as being processed (so an incremented retry count is saved, and remembered for the next go-around).
               if (await this.jobScoringService.MarkAsProcessed(cj.HqtrCreditJobId, retryCount))
               {

                  // This is a "normal" scoring scenario.

                  // build payload
                  JobGraderRequest request = await this.jobGraderBuilder.BuildJobGraderRequest(cj.DrAddressId, cj.JobId, cj.BidAlternateId, true);

                  // submit for grading
                  JobGraderResponse response = await this.jobScoreCalculatorService.GetJobGrade(request);

                  // record successful response, otherwise record a Y score.
                  if (response != null && response.LetterScore != null)
                  {
                     await this.ValidateSpaAndRecordGrade(creditJobScore, response, spaNumbersExemptFromScoring, cj.SpaNumber);
                  }
                  else
                  {
                     // We need to exclude job from toppers when job grading was unsuccessful.
                     creditJobScore.ExcludedFromTopper = true;

                     // We apply a "Y" score when the JobGrader API is unsuccessful.
                     // This seems peculiar at first glance, but apparently there are several "good reasons" why the JobGrader would be unsuccessful, and in the majority
                     // of those cases, we don't really need the job to be scored.  For example, the JobGrader currently returns a 500 if we send a SalesOffice that it
                     // doesn't have pier group pricing for -- which means they don't care about the sales office.
                     //
                     // So rather than retrying another attempt scoring attempt later, we'll apply a score of "Y", and move on.  Consistently applying the Y score does
                     // allows us to investigate later if we hear reports of a widespread lack of scores on jobs that should have received a proper score.
                     await this.jobScoringService.RecordGrade(creditJobScore);
                  }

                  this.Logger.LogInformation($"{cj.HqtrCreditJobId} was scored a {creditJobScore.LetterScore}");
               }
               else
               {
                  this.Logger.LogInformation($"{cj.HqtrCreditJobId} was unable to be marked as 'processed'.  Assuming another process has taken it...skipping");
               }
            }
            catch (TigSalesOfficeException)
            {
               // job identified from the international office
               //   mark ExcludedFromTopper as "Y"
               creditJobScore.ExcludedFromTopper = true;
               await this.jobScoringService.RecordGrade(creditJobScore);
            }
            catch (Exception ex)
            {
               this.Logger.LogError(
                  "An error occured during job scoring (Hqtr Credit Job Id: {0}) - {1}",
                  cj.HqtrCreditJobId,
                  ex.ToString());

               if (retryCount >= this.JobScoringSettings.Value.MaxRetryAttempts)
               {
                  // We are "done" with the retries, for this credit job.
                  this.Logger.LogError(
                     "Credit job (Hqtr Credit Job Id: {0}) will not receive a score, as the maximum number of retries has been reached, without success.",
                     cj.HqtrCreditJobId);

                  // We COULD apply a "Y" score to it, but then we wouldn't have a way to differentiate failures on the TSMT side (with Jobs, Bids, SalesRollup APIs)
                  // versus the JobGrader (Mendix) API -- aside from digging into CloudWatch, which really sucks.
               }
            }
         }
      }

      /// <summary>
      /// Worker process
      /// </summary>
      /// <returns>Task</returns>
      protected override async Task DoProcesss()
      {
         try
         {
            // We want to be aware of the SPA numbers that are exempt from scoring -- but we use a class member to store this information so we don't need to re-fetch it with every execution of the IHostedService.
            if (this.exemptSpaNumbers == null)
            {
               await this.LearnOfScoringExemptSpaNumbers();
            }

            await this.BuildJobsToGrade();

            IEnumerable<CreditJob> creditJobs = await this.GetJobsToGrade();

            await this.GradeJobs(creditJobs, this.exemptSpaNumbers);
         }
         catch (Exception ex)
         {
            this.Logger.LogError("Job Score background encountered an error during processing - {0}", ex.ToString());
         }
      }

      /// <summary>
      /// Process recently transmitted sales orders to determine credit jobs to grade
      /// </summary>
      /// <returns>task</returns>
      private async Task BuildJobsToGrade()
      {
         await this.jobScoringService.BuildProcessEntries();
      }

      /// <summary>
      /// Get jobs to be graded
      /// </summary>
      /// <returns>collection of jobs to be graded</returns>
      private async Task<IEnumerable<CreditJob>> GetJobsToGrade()
      {
         return await this.jobScoringService.GetJobsToGrade(this.JobScoringSettings.Value.MaxRetryAttempts, this.JobScoringSettings.Value.MinutesPauseBeforeRetryingCreditJob);
      }

      /// <summary>
      /// Attempts to retrieve and remember (in a class member) the SPA numbers that are exempt from scoring.
      /// </summary>
      /// <returns>task</returns>
      private async Task LearnOfScoringExemptSpaNumbers()
      {
         string bucket = this.JobScoringSettings.Value.ScoringExemptSpaNumberBucket;
         string csvFilename = this.JobScoringSettings.Value.ScoringExemptSpaNumberCsvFilename;

         try
         {
            this.Logger.LogInformation("Retrieving SPA Numbers that are exempt from job scoring...");

            // Retrieve the CSV file that tells us which SPA Numbers are exempt from scoring.
            GetObjectResponse s3resp = await this.s3Repo.GetObjectAsync(bucket, csvFilename);
            if (s3resp.ResponseStream != null)
            {
               string[] lineValues;
               char[] separators = { ',' };
               StreamReader sr = new StreamReader(s3resp.ResponseStream);

               this.exemptSpaNumbers = new HashSet<string>();  // If we have gotten this far, we can initialize the HashSet class member, knowing the caller checks this class member to see we have already acquired the exempt SPA numbers.

               sr.ReadLine();  // Skip over the row that lists column names
               string line;
               while ((line = sr.ReadLine()) != null)
               {
                  lineValues = line.Split(separators, StringSplitOptions.None);
                  if (lineValues.Any())
                  {
                     string spaNumber = lineValues[0];
                     this.exemptSpaNumbers.Add(spaNumber);
                  }
               }

               this.Logger.LogInformation("...retrieved SPA Numbers that are exempt from job scoring; Count of exampt SPA Numbers = " + this.exemptSpaNumbers.Count);
            }
            else
            {
               throw new JobScoringServiceDomainException(string.Format("Unable to retrieve exempt SPA numbers, as S3 response stream was null for bucket '{0}' and CSV file '{1}''.", bucket, csvFilename));
            }
         }
         catch (Exception ex)
         {
            throw new JobScoringServiceDomainException(string.Format("Unexpected error while attempting to learn of exempt SPA numbers, using S3 bucket '{0}' and CSV file '{1}'.  Error Message: {2}", bucket, csvFilename, ex.Message), ex);
         }
      }

      private async Task ValidateSpaAndRecordGrade(CreditJobScoreProcessViewModel creditJobScore, JobGraderResponse response, HashSet<string> spaNumbersExemptFromScoring, string spaNumber)
      {
         creditJobScore.LetterScore = response.LetterScore;

         // Check to see if the credit job has a SPA number that would exempt it from normal scoring.
         if (spaNumbersExemptFromScoring != null && !string.IsNullOrWhiteSpace(spaNumber) && spaNumbersExemptFromScoring.Contains(spaNumber))
         {
            // The SPA number says this credit job is exempt from normal scoring, so we are making ExcludedFromTopper as Y.
            creditJobScore.ExcludedFromTopper = true;
         }

         await this.jobScoringService.RecordGrade(creditJobScore);
      }
   }
}
