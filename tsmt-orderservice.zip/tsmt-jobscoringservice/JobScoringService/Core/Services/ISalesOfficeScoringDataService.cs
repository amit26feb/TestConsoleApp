﻿// <copyright file="ISalesOfficeScoringDataService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using JobScoringService.Core.ViewModels;

   /// <summary>
   /// Service for getting scoring data for a sales office
   /// </summary>
   public interface ISalesOfficeScoringDataService
   {
      /// <summary>
      /// Creates and returns a SalesOfficeScoringDataViewModel for a given sales office id and product codes
      /// </summary>
      /// <param name="salesOfficeId">Sales office id to get data for</param>
      /// <param name="prodCodes">Product code to get data for</param>
      /// <param name="customerChannelId">Customer channel id for determining currency conversion rate</param>
      /// <returns>Model containing scoring data for a given sales office code and product codes</returns>
      Task<SalesOfficeScoringDataViewModel> GetScoringData(int salesOfficeId, IEnumerable<string> prodCodes, string customerChannelId);
   }
}
