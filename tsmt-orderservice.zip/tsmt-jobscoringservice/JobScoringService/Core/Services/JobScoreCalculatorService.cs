﻿// <copyright file="JobScoreCalculatorService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using DataAccess.Paging;
   using JobScoringService.Common.Constants;
   using JobScoringService.Common.Enumerators;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.ViewModels;
   using Microsoft.Extensions.Configuration;
   using TSMT.DataAccess;
   using JobScore = Common.Enumerators.JobScore;

   /// <summary>
   /// Service for job score calculator
   /// </summary>
   public class JobScoreCalculatorService : IJobScoreCalculatorService
   {
      /// <summary>
      /// Canadian to US dollar conversion rate
      /// </summary>
      private readonly decimal canadianConversionRate;
      private readonly IJobGradeFactorRepository jobGradeFactorRepository;
      private readonly IJobScoreMasterRepository jobScoreMasterRepository;
      private readonly IExcludedProductCodeRepository excludedProductCodeRepository;
      private readonly IJobSizeRepository jobSizeRepository;
      private readonly IMapper mapper;
      private readonly IProductApiClient productApiClient;
      private readonly IPricingApiClient pricingApiClient;
      private readonly IConfiguration configuration;

      // Based on the rated multiplier reference value we will calculate the alternate view for next score
      private readonly decimal ratedMultiplierReferenceValue = 0.358m;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoreCalculatorService"/> class.
      /// </summary>
      /// <param name="jobScoreMasterRepository">Job score master repository</param>
      /// <param name="mapper">Mapper for maping views</param>
      /// <param name="productApiClient">Product api client</param>
      /// <param name="pricingApiClient">Pricing api client</param>
      /// <param name="configuration">Configuration to load the canadian conversion rate value</param>
      public JobScoreCalculatorService(IJobScoreMasterRepository jobScoreMasterRepository, IMapper mapper, IProductApiClient productApiClient, IConfiguration configuration, IPricingApiClient pricingApiClient)
      {
         this.jobScoreMasterRepository = jobScoreMasterRepository;
         this.jobGradeFactorRepository = this.jobScoreMasterRepository.JobGradeFactorRepository;
         this.excludedProductCodeRepository = this.jobScoreMasterRepository.ExcludedProductCodeRepository;
         this.jobSizeRepository = this.jobScoreMasterRepository.JobSizeRepository;
         this.mapper = mapper;
         this.productApiClient = productApiClient;
         this.pricingApiClient = pricingApiClient;
         this.configuration = configuration;
         this.canadianConversionRate = Convert.ToDecimal(this.configuration["tsmt-JobScoringService-CurrencyExchangeRate"]);
      }

      /// <summary>
      /// Perform calculation for job scoring and returns final grade
      /// </summary>
      /// <param name="jobGraderRequest">Request for job scoring calculation</param>
      /// <returns>Job grader response</returns>
      public async Task<JobGraderResponse> GetJobGrade(JobGraderRequest jobGraderRequest)
      {
         JobScoreTotal jobScoreTotal = new JobScoreTotal();
         string salesOfficeCode = jobGraderRequest.SalesOfficeCode;
         decimal jobGradeFactor = await this.GetJobGradeFactor();

         // Created object for response
         JobGraderResponse jobGraderResponse = new JobGraderResponse
         {
            Job = jobGraderRequest.Job,
            Bid = jobGraderRequest.Bid,
            Currency = jobGraderRequest.Currency,
            SalesOffice = jobGraderRequest.SalesOffice,
            SalesPerson = jobGraderRequest.SalesPerson,
            JobClassCode = jobGraderRequest.JobClassCode,
            JobLocation = jobGraderRequest.JobLocation,
            JobLineItems = this.mapper.Map<IEnumerable<JobGraderRequestLineItem>, IEnumerable<JobGraderResponseLineItem>>(jobGraderRequest.JobLineItems).ToArray()
         };

         // Get prod code details for obsolete validation
         ProductCodeFilterViewModel productCodeFilterView = new ProductCodeFilterViewModel();
         List<Filter> filters = jobGraderResponse.JobLineItems.Select(lineItem => new Filter
         {
            Field = "prodCode",
            Operator = "Eq",
            Value = lineItem.ProductCode
         }).ToList();

         List<FilterCollection> filtersCollection = new List<FilterCollection>
         {
            new FilterCollection() { Filters = filters, Logic = "or" },
         };
         productCodeFilterView.Filters = filtersCollection;
         IEnumerable<ProductCodeViewModel> prodCodeDetails = await this.productApiClient.GetProductCodes(productCodeFilterView);

         // Get excluded product codes
         IEnumerable<ExcludedProductCode> excludedProductCodes = await this.GetExcludedProductCodes();

         // THE FOLLOWING JOB SIZE DOLLAR LOGIC IS USED FOR CALCULATING JOB SCORES BOTH HERE IN JOB SCORING SERVICE AND IN SALSES AND PRICING ROLLUP SERVICES
         // (in TSMT.PriceRollupCalculationEngine)
         // IF THIS LOGIC CHANGES, PLEASE MAKE THE CHANGES IN ALL 3 PLACES OR NOTIFY THE OTHER TEAMS RESPONSIBLE FOR THE OTHER CODE OF THE CHANGE
         // THERE IS A SHARED FUNCTION IN TSMT.RollupDomain THAT CAN BE UPDATED/REFERENCED IF THIS LOGIC GETS ANY MORE COMPLICATED THAN A SIMPLE SUM
         //
         // If the job is in Canadian dollars we need to pass in the Canadian conversion rate, otherwise 1 = no conversion needed.
         decimal conversionRate = jobGraderResponse.Currency == Currency.CAD ? this.canadianConversionRate : 1;
         decimal totalEnteredDollar = jobGraderResponse.JobLineItems.Sum(x => x.EnteredDollarAmount);
         decimal totalJobSizeDollar = conversionRate != 1 ? totalEnteredDollar / conversionRate : totalEnteredDollar;

         // END OF SHARED JOB SIZE DOLLAR LOGIC CODE
         string jobSize = await this.GetJobSize(totalJobSizeDollar);
         foreach (JobGraderResponseLineItem lineItem in jobGraderResponse.JobLineItems)
         {
            string productCode = lineItem.ProductCode.TrimStart(new char[] { '0' });

            // Add entered dollar to job score total
            jobScoreTotal.TotalEnteredDollar += lineItem.EnteredDollarAmount;

            // Round off entered dollars to display
            lineItem.EnteredDollarAmount = Math.Round(lineItem.EnteredDollarAmount, 2);

            // Job score validation before calculating job score
            if (this.JobScoreValidation(productCode, lineItem.UnadjustedListPrice, excludedProductCodes)
               && !this.IsObsoleteProductCode(lineItem.ProductCode, prodCodeDetails))
            {
               decimal lpafProduct = lineItem.UnadjustedListPrice * lineItem.QuantityLPAF * lineItem.QuantityShipLPAF;

               // Determining the peer group for a line items
               JobScoreQuintile jobScoreQuintile = await this.pricingApiClient.GetJobScoreQuintile(lineItem.ProductCode, salesOfficeCode, jobSize);

               if (jobScoreQuintile != null)
               {
                  // Assigning peer group result to response
                  lineItem.RatedLocation = jobScoreQuintile.InfoGeography;
                  lineItem.RatedJobSize = jobScoreQuintile.InfoJobSize;
                  lineItem.RatedCutoffGrade1 = jobScoreQuintile.StartB;
                  lineItem.RatedCutoffGrade2 = jobScoreQuintile.StartC;
                  lineItem.RatedCutoffGrade3 = jobScoreQuintile.StartD;
                  lineItem.RatedCutoffGrade4 = jobScoreQuintile.StartE;
                  lineItem.CutoffAltDisplayGrade1 = this.CalculateAlternativeDisplay(lineItem.RatedCutoffGrade1);
                  lineItem.CutoffAltDisplayGrade2 = this.CalculateAlternativeDisplay(lineItem.RatedCutoffGrade2);
                  lineItem.CutoffAltDisplayGrade3 = this.CalculateAlternativeDisplay(lineItem.RatedCutoffGrade3);
                  lineItem.CutoffAltDisplayGrade4 = this.CalculateAlternativeDisplay(lineItem.RatedCutoffGrade4);
                  if (lpafProduct > 0)
                  {
                     lineItem.RatedMultiplier = Math.Round(lineItem.EnteredDollarAmount / lpafProduct, 5);
                  }

                  lineItem.RatedMultiplierAltDisplay = this.CalculateAlternativeDisplay(lineItem.RatedMultiplier);
                  lineItem.LetterScore = this.DetermineLetterScore(jobScoreQuintile, lineItem.RatedMultiplier);
               }
               else
               {
                  jobGraderResponse.ErrorMessage = $"Scoring lookup is empty for Job Size: {jobSize}, Product Code: {lineItem.ProductCode}, Sales Office: {jobGraderResponse.SalesOffice}";
                  break;
               }

               // Assign required values into job score total for job score calculation based on line item values and lpaf product
               this.AssignJobScoreTotalValues(jobScoreTotal, lineItem, lpafProduct);
            }
         }

         // check if all line items are excluded from scoring
         if (!jobGraderResponse.JobLineItems.All(x => x.LetterScore == null))
         {
            // Calculate Job level letter score & cut off values
            this.CalculateJobGrade(jobScoreTotal, jobGraderResponse, jobGradeFactor);
         }

         return jobGraderResponse;
      }

      /// <summary>
      /// Assign required values into job score total for job score calculation based on line item values and lpaf product
      /// </summary>
      /// <param name="jobScoreTotal">Job score total</param>
      /// <param name="lineItem">Job score line item</param>
      /// <param name="lpafProduct">Lpaf product</param>
      public void AssignJobScoreTotalValues(JobScoreTotal jobScoreTotal, JobGraderResponseLineItem lineItem, decimal lpafProduct)
      {
         // Add total quantity lpaf and quantity ship lpaf to job score total
         jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF += lpafProduct;

         // Calculate total break point dollars
         jobScoreTotal.TotalABBreakPointDollar += lpafProduct * lineItem.RatedCutoffGrade1;
         jobScoreTotal.TotalBCBreakPointDollar += lpafProduct * lineItem.RatedCutoffGrade2;
         jobScoreTotal.TotalCDBreakPointDollar += lpafProduct * lineItem.RatedCutoffGrade3;
         jobScoreTotal.TotalDEBreakPointDollar += lpafProduct * lineItem.RatedCutoffGrade4;

         // Add total dollars for valid product codes
         jobScoreTotal.TotalValidProductEnteredDollar += lineItem.EnteredDollarAmount;
      }

      /// <summary>
      /// Calculate job grade
      /// </summary>
      /// <param name="jobScoreTotal">Job score total</param>
      /// <param name="jobGraderResponse">Job grader response</param>
      /// <param name="jobGradeFactor">Job grade factor</param>
      public void CalculateJobGrade(JobScoreTotal jobScoreTotal, JobGraderResponse jobGraderResponse, decimal jobGradeFactor)
      {
         JobScoreQuintile jobScoreQuintile = new JobScoreQuintile();

         // Assign total equipment revenue
         jobGraderResponse.TotalEquipmentRevenue = Math.Round(jobScoreTotal.TotalEnteredDollar, 2);

         // Calculate rated multipler
         if (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF > 0)
         {
            jobGraderResponse.RatedMultiplier = Math.Round(jobScoreTotal.TotalValidProductEnteredDollar / jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF, 5);

            // Calculate alternative rated multipler
            jobGraderResponse.RatedMultiplierAltDisplay = this.CalculateAlternativeDisplay(jobGraderResponse.RatedMultiplier);

            jobScoreQuintile.StartB = jobScoreTotal.TotalABBreakPointDollar / jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF;
            jobScoreQuintile.StartC = jobScoreTotal.TotalBCBreakPointDollar / jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF;
            jobScoreQuintile.StartD = jobScoreTotal.TotalCDBreakPointDollar / jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF;
            jobScoreQuintile.StartE = jobScoreTotal.TotalDEBreakPointDollar / jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF;

            // Determine letter score
            jobGraderResponse.LetterScore = this.DetermineLetterScore(jobScoreQuintile, jobGraderResponse.RatedMultiplier);
         }

         // Calling method to set rated cutoff based on the score
         this.CalculateRatedCutOff(jobGradeFactor, jobGraderResponse, jobScoreQuintile);

         // Calculate ent dollar amount for the job
         jobGraderResponse.EnteredABDollarNextScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.RatedCutoffGrade1) - jobScoreTotal.TotalValidProductEnteredDollar;
         jobGraderResponse.EnteredBCDollarNextScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.RatedCutoffGrade2) - jobScoreTotal.TotalValidProductEnteredDollar;
         jobGraderResponse.EnteredCDDollarNextScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.RatedCutoffGrade3) - jobScoreTotal.TotalValidProductEnteredDollar;
         jobGraderResponse.EnteredDEDollarNextScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.RatedCutoffGrade4) - jobScoreTotal.TotalValidProductEnteredDollar;

         // Calculate step down rated cut off grades
         jobGraderResponse.StepDownRatedCutoffGrade1 = jobScoreQuintile.StartB;
         jobGraderResponse.StepDownRatedCutoffGrade2 = jobScoreQuintile.StartC;
         jobGraderResponse.StepDownRatedCutoffGrade3 = jobScoreQuintile.StartD;
         jobGraderResponse.StepDownRatedCutoffGrade4 = jobScoreQuintile.StartE;

         // Calculate step down ent dollar amount for the job
         jobGraderResponse.EnteredABDollarStepDownScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.StepDownRatedCutoffGrade1) - jobScoreTotal.TotalValidProductEnteredDollar;
         jobGraderResponse.EnteredBCDollarStepDownScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.StepDownRatedCutoffGrade2) - jobScoreTotal.TotalValidProductEnteredDollar;
         jobGraderResponse.EnteredCDDollarStepDownScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.StepDownRatedCutoffGrade3) - jobScoreTotal.TotalValidProductEnteredDollar;
         jobGraderResponse.EnteredDEDollarStepDownScore = (jobScoreTotal.TotalQtyLPAFAndQtyShipLPAF * jobGraderResponse.StepDownRatedCutoffGrade4) - jobScoreTotal.TotalValidProductEnteredDollar;

         // Calculate step down alternate display for cut off grade
         jobGraderResponse.StepDownCutoffAltDisplayGrade1 = this.CalculateAlternativeDisplay(jobScoreQuintile.StartB);
         jobGraderResponse.StepDownCutoffAltDisplayGrade2 = this.CalculateAlternativeDisplay(jobScoreQuintile.StartC);
         jobGraderResponse.StepDownCutoffAltDisplayGrade3 = this.CalculateAlternativeDisplay(jobScoreQuintile.StartD);
         jobGraderResponse.StepDownCutoffAltDisplayGrade4 = this.CalculateAlternativeDisplay(jobScoreQuintile.StartE);

         // Call this method to set display dollar values based on the letter score
         this.CalculateDisplayDollarAmount(jobGraderResponse);
      }

      /// <summary>
      /// Get job grade factor
      /// </summary>
      /// <returns>Job grade factor</returns>
      public async Task<decimal> GetJobGradeFactor()
      {
         JobGradeFactorModel jobGradeFactor = await this.jobGradeFactorRepository.GetJobGradeFactor();
         return jobGradeFactor.JobGradeFactor;
      }

      /// <summary>
      /// Get excluded product codes
      /// </summary>
      /// <returns>Excluded product codes</returns>
      public async Task<IEnumerable<ExcludedProductCode>> GetExcludedProductCodes()
      {
         IEnumerable<ExcludedProductCode> excludedProductCodes = await this.excludedProductCodeRepository.GetExcludedProductCodes();
         return excludedProductCodes;
      }

      /// <summary>
      /// Determine letter score
      /// </summary>
      /// <param name="jobScoreQuintile">Job score quintile details</param>
      /// <param name="ratedMultiplier">Rated multiplier</param>
      /// <returns>Letter score</returns>
      public string DetermineLetterScore(JobScoreQuintile jobScoreQuintile, decimal ratedMultiplier)
      {
         JobScore calculatedJobScore = jobScoreQuintile switch
         {
            JobScoreQuintile quintile when ratedMultiplier <= quintile.StartE => JobScore.E,
            JobScoreQuintile quintile when ratedMultiplier <= quintile.StartD => JobScore.D,
            JobScoreQuintile quintile when ratedMultiplier <= quintile.StartC => JobScore.C,
            JobScoreQuintile quintile when ratedMultiplier <= quintile.StartB => JobScore.B,
            _ => JobScore.A,
         };
         return calculatedJobScore.ToString();
      }

      /// <summary>
      /// Get job size
      /// </summary>
      /// <param name="jobSizeDollar">Job size dollar</param>
      /// <returns>Job size</returns>
      public async Task<string> GetJobSize(decimal jobSizeDollar)
      {
         IEnumerable<JobSizeModel> jobSizeList = await this.jobSizeRepository.GetJobSizes();
         JobSizeModel jobSizeModel = jobSizeList.Where(x => x.FromAmount <= jobSizeDollar && x.ToAmount >= jobSizeDollar).OrderBy(x => x.ToAmount).FirstOrDefault();
         if (jobSizeModel != null)
         {
            return jobSizeModel.JobSize;
         }

         return string.Empty;
      }

      /// <summary>
      /// Job score validation based on product code and unadjusted list price
      /// </summary>
      /// <param name="productCode">Product code</param>
      /// <param name="unAdjustedListprice">Unadjusted list price</param>
      /// <param name="excludedProductCodes">Excluded product codes</param>
      /// <returns>Boolean</returns>
      public bool JobScoreValidation(string productCode, decimal unAdjustedListprice, IEnumerable<ExcludedProductCode> excludedProductCodes)
      {
         return !excludedProductCodes.Any(x => x.ProductCode == productCode) && unAdjustedListprice > 0;
      }

      /// <summary>
      /// Validate that product code is obsolete or not
      /// </summary>
      /// <param name="productCode">Product code</param>
      /// <param name="productCodeDetails">Product code details</param>
      /// <returns>Boolean</returns>
      public bool IsObsoleteProductCode(string productCode, IEnumerable<ProductCodeViewModel> productCodeDetails)
      {
         return productCodeDetails.Any(x => x.ProdCode == productCode && x.Status == "O");
      }

      /// <summary>
      /// Calculate alternative display for given next score rated multiplier
      /// </summary>
      /// <param name="nextScoreRatedMultiplier">Next score rated multiplier</param>
      /// <returns>Alternative display</returns>
      public string CalculateAlternativeDisplay(decimal nextScoreRatedMultiplier)
      {
         string alternativeDisplay = string.Empty;
         if (nextScoreRatedMultiplier > 0)
         {
            decimal cutOffResult;
            if (nextScoreRatedMultiplier >= this.ratedMultiplierReferenceValue)
            {
               cutOffResult = Math.Round(nextScoreRatedMultiplier, 3);
               alternativeDisplay = string.Concat(cutOffResult.ToString("0.###"), "/1.0");
            }
            else
            {
               cutOffResult = Math.Round(nextScoreRatedMultiplier / this.ratedMultiplierReferenceValue, 3);
               alternativeDisplay = string.Concat(this.ratedMultiplierReferenceValue, "/", cutOffResult.ToString("0.###"));
            }
         }

         return alternativeDisplay;
      }

      /// <summary>
      /// Calculate display dollar amount based on letter score value
      /// </summary>
      /// <param name="response">Job grader response</param>
      public void CalculateDisplayDollarAmount(JobGraderResponse response)
      {
         switch (response.LetterScore)
         {
            case "A":
               response.DisplayABDollarAmount = response.EnteredABDollarStepDownScore;
               response.DisplayBCDollarAmount = response.EnteredBCDollarStepDownScore;
               response.DisplayCDDollarAmount = response.EnteredCDDollarStepDownScore;
               response.DisplayDEDollarAmount = response.EnteredDEDollarStepDownScore;
               break;

            case "B":
               response.DisplayABDollarAmount = response.EnteredABDollarNextScore;
               response.DisplayBCDollarAmount = response.EnteredBCDollarStepDownScore;
               response.DisplayCDDollarAmount = response.EnteredCDDollarStepDownScore;
               response.DisplayDEDollarAmount = response.EnteredDEDollarStepDownScore;
               break;

            case "C":
               response.DisplayABDollarAmount = response.EnteredABDollarNextScore;
               response.DisplayBCDollarAmount = response.EnteredBCDollarNextScore;
               response.DisplayCDDollarAmount = response.EnteredCDDollarStepDownScore;
               response.DisplayDEDollarAmount = response.EnteredDEDollarStepDownScore;
               break;

            case "D":
               response.DisplayABDollarAmount = response.EnteredABDollarNextScore;
               response.DisplayBCDollarAmount = response.EnteredBCDollarNextScore;
               response.DisplayCDDollarAmount = response.EnteredCDDollarNextScore;
               response.DisplayDEDollarAmount = response.EnteredDEDollarStepDownScore;
               break;

            case "E":
               response.DisplayABDollarAmount = response.EnteredABDollarNextScore;
               response.DisplayBCDollarAmount = response.EnteredBCDollarNextScore;
               response.DisplayCDDollarAmount = response.EnteredCDDollarNextScore;
               response.DisplayDEDollarAmount = response.EnteredDEDollarNextScore;
               break;
         }
      }

      /// <summary>
      /// Calculating rated cutoff value based on job score
      /// </summary>
      /// <param name="jobGradeFactor">Job grade factor</param>
      /// <param name="response">Job score response</param>
      /// <param name="jobScoreQuintile">Job score quintile data</param>
      public void CalculateRatedCutOff(decimal jobGradeFactor, JobGraderResponse response, JobScoreQuintile jobScoreQuintile)
      {
         // Assign calculated rated cut off grade values without round off for accurate cut off grade
         decimal ratedCutOffGrade1 = jobScoreQuintile.StartB;
         decimal ratedCutOffGrade2 = jobScoreQuintile.StartC;
         decimal ratedCutOffGrade3 = jobScoreQuintile.StartD;
         decimal ratedCutOffGrade4 = jobScoreQuintile.StartE;
         switch (response.LetterScore)
         {
            case "B":
               ratedCutOffGrade1 = jobScoreQuintile.StartB + jobGradeFactor;
               break;

            case "C":
               ratedCutOffGrade1 = jobScoreQuintile.StartB + jobGradeFactor;
               ratedCutOffGrade2 = jobScoreQuintile.StartC + jobGradeFactor;
               break;

            case "D":
               ratedCutOffGrade1 = jobScoreQuintile.StartB + jobGradeFactor;
               ratedCutOffGrade2 = jobScoreQuintile.StartC + jobGradeFactor;
               ratedCutOffGrade3 = jobScoreQuintile.StartD + jobGradeFactor;
               break;

            case "E":
               ratedCutOffGrade1 = jobScoreQuintile.StartB + jobGradeFactor;
               ratedCutOffGrade2 = jobScoreQuintile.StartC + jobGradeFactor;
               ratedCutOffGrade3 = jobScoreQuintile.StartD + jobGradeFactor;
               ratedCutOffGrade4 = jobScoreQuintile.StartE + jobGradeFactor;
               break;
         }

         // Rated cut off grades round off by job grade response model for display
         response.RatedCutoffGrade1 = ratedCutOffGrade1;
         response.RatedCutoffGrade2 = ratedCutOffGrade2;
         response.RatedCutoffGrade3 = ratedCutOffGrade3;
         response.RatedCutoffGrade4 = ratedCutOffGrade4;

         response.CutoffAltDisplayGrade1 = this.CalculateAlternativeDisplay(ratedCutOffGrade1);
         response.CutoffAltDisplayGrade2 = this.CalculateAlternativeDisplay(ratedCutOffGrade2);
         response.CutoffAltDisplayGrade3 = this.CalculateAlternativeDisplay(ratedCutOffGrade3);
         response.CutoffAltDisplayGrade4 = this.CalculateAlternativeDisplay(ratedCutOffGrade4);
      }
   }
}
