﻿// <copyright file="IOrderCreationProcessService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System.Threading.Tasks;

   /// <summary>
   /// Interface for Job Score Service
   /// </summary>
   public interface IOrderCreationProcessService
   {
      /// <summary>
      /// Identify orders recently transmitted and create records in staging
      /// </summary>
      /// <returns>Task</returns>
      Task ImportRecentlyTransmittedOrders();
   }
}
