﻿// <copyright file="SalesOfficeScoringDataService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using JobScoringService.Common.Constants;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Core;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ServiceAPI;
   using JobScoringService.Core.ViewModels;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.Logging;

   /// <inheritdoc/>
   public class SalesOfficeScoringDataService : ISalesOfficeScoringDataService
   {
      private readonly decimal canadianConversionRate;
      private readonly IJobScoreQuintileRepository jobScoreQuintileRepository;
      private readonly IJobSizeFactorRepository jobSizeFactorRepository;
      private readonly IJobSizeRepository jobSizeRepository;
      private readonly IExcludedProductCodeRepository excludedProductCodeRepository;
      private readonly IJobsApiClient jobsApiClient;
      private readonly ILogger<SalesOfficeScoringDataService> logger;
      private readonly IConfiguration configuration;

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesOfficeScoringDataService"/> class.
      /// </summary>
      /// <param name="jobScoreQuintileRepository">Job score quintile repository</param>
      /// <param name="jobSizeFactorRepository">Job size factor repository</param>
      /// <param name="jobSizeRepository">Job size repository</param>
      /// <param name="excludedProductCodeRepository">Excluded product code repository</param>
      /// <param name="jobsApiClient">Jobs api client</param>
      /// <param name="logger">Logger of logs</param>
      /// <param name="configuration">Configuration to load the canadian conversion rate value</param>
      public SalesOfficeScoringDataService(
         IJobScoreQuintileRepository jobScoreQuintileRepository,
         IJobSizeFactorRepository jobSizeFactorRepository,
         IJobSizeRepository jobSizeRepository,
         IExcludedProductCodeRepository excludedProductCodeRepository,
         IJobsApiClient jobsApiClient,
         ILogger<SalesOfficeScoringDataService> logger,
         IConfiguration configuration)
      {
         this.jobScoreQuintileRepository = jobScoreQuintileRepository;
         this.jobSizeFactorRepository = jobSizeFactorRepository;
         this.jobSizeRepository = jobSizeRepository;
         this.excludedProductCodeRepository = excludedProductCodeRepository;
         this.jobsApiClient = jobsApiClient;
         this.logger = logger;
         this.configuration = configuration;
         this.canadianConversionRate = Convert.ToDecimal(this.configuration["tsmt-JobScoringService-CurrencyExchangeRate"]);
      }

      /// <inheritdoc/>
      public async Task<SalesOfficeScoringDataViewModel> GetScoringData(int salesOfficeId, IEnumerable<string> prodCodes, string customerChannelId)
      {
         // Make sure we can get all the stuff we need first.
         JobSizeFactorModel jobSizeFactorModel = await this.jobSizeFactorRepository.GetJobSizeFactor();
         if (jobSizeFactorModel == null)
         {
            this.HandleDomainError("Unable to fetch job size factor.");
         }
         else
         {
            SalesOffice salesOffice = await this.jobsApiClient.GetSalesOffice(salesOfficeId);
            if (salesOffice == null || salesOffice.Code == null)
            {
               this.HandleDomainError("Invalid or unfetchable sales office.", salesOfficeId);
            }
            else
            {
               string currency = JobGraderRequestBuilder.GetCurrencyFromCustChannelId(customerChannelId);
               SalesOfficeScoringDataViewModel result = new SalesOfficeScoringDataViewModel()
               {
                  CurrencyExchangeRate = currency == Currency.CAD ? this.canadianConversionRate : 1,
                  JobSizeFactor = jobSizeFactorModel.JobSizeFactor,
                  ProductCodeQuintiles = Enumerable.Empty<ProductCodeQuintilesViewModel>()
               };

               if (prodCodes?.Any() == true)
               {
                  IEnumerable<JobScoreQuintile> jobScoreQuintiles = await this.jobScoreQuintileRepository.GetJobScoreQuintiles(salesOffice.Code, prodCodes);
                  IEnumerable<JobSizeModel> jobSizes = await this.jobSizeRepository.GetJobSizes();
                  if (jobScoreQuintiles?.Any() == true && jobSizes?.Any() == true)
                  {
                     Dictionary<string, JobSizeModel> jobSizeDict = jobSizes.ToDictionary(js => js.JobSize);
                     IEnumerable<ExcludedProductCode> excludedProductCodes = await this.excludedProductCodeRepository.GetExcludedProductCodes();
                     if (excludedProductCodes?.Any() != true)
                     {
                        this.HandleDomainError("Unable to fetch excluded product codes.");
                     }
                     else
                     {
                        IEnumerable<string> excludedProductCodeStrings = excludedProductCodes.Select(p => p.ProductCode);

                        result.ProductCodeQuintiles = jobScoreQuintiles.GroupBy(jsq => jsq.ProductCode)
                           .Select(g => new ProductCodeQuintilesViewModel()
                           {
                              ProductCode = g.Key,
                              IsExempt = excludedProductCodeStrings.Contains(g.Key),
                              Quintiles = g.Select(q =>
                              new QuintileViewModel()
                              {
                                 JobSizeMin = this.SafeDictionaryGet(jobSizeDict, q.JobSize, true),
                                 JobSizeMax = this.SafeDictionaryGet(jobSizeDict, q.JobSize, false),
                                 StartB = q.StartB,
                                 StartC = q.StartC,
                                 StartD = q.StartD,
                                 StartE = q.StartE
                              })
                           });
                     }
                  }
               }

               return result;
            }
         }

         return null;
      }

      private decimal SafeDictionaryGet(Dictionary<string, JobSizeModel> jobSizeDict, string value, bool isMin)
      {
         if (jobSizeDict.TryGetValue(value, out JobSizeModel jobSize)) {
            return isMin ? jobSize.FromAmount : jobSize.ToAmount;
         }
         else
         {
            return isMin ? 0 : decimal.MaxValue;
         }
      }

      private void HandleDomainError(string errorMessage, params object[] args)
      {
         this.logger.LogError(errorMessage, args);
         throw new JobScoringServiceDomainException(errorMessage);
      }
   }
}
