﻿// <copyright file="JobScoreReportService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using JobScoringService.Core.ServiceAPI;
   using Microsoft.AspNetCore.Http;

   /// <summary>
   /// Service for job score reporting
   /// </summary>
   public class JobScoreReportService : IJobScoreReportService
   {
      private readonly IJobScoreReportRepository jobScoreReportRepository;
      private readonly IHttpContextAccessor contextAccessor;
      private readonly IJobGraderRequestBuilder jobGraderRequestBuilder;
      private readonly IJobGraderApiClient jobGraderApiClient;
      private readonly int drAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoreReportService"/> class.
      /// </summary>
      /// <param name="jobScoreReportRepository">Instance of job score report service</param>
      /// <param name="contextAccessor">Context accessor</param>
      /// <param name="jobGraderRequestBuilder">Service to build request for job scoring</param>
      /// <param name="jobGraderApiClient">Api client for job grader service</param>
      public JobScoreReportService(IJobScoreReportRepository jobScoreReportRepository, IHttpContextAccessor contextAccessor, IJobGraderRequestBuilder jobGraderRequestBuilder, IJobGraderApiClient jobGraderApiClient)
      {
         this.jobScoreReportRepository = jobScoreReportRepository;
         this.contextAccessor = contextAccessor;
         this.jobGraderRequestBuilder = jobGraderRequestBuilder;
         this.jobGraderApiClient = jobGraderApiClient;
         if (contextAccessor.HttpContext != null &&
                contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
                int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.jobScoreReportRepository.HonorDrAddressId(drAddressIdToHonor);
            this.drAddressId = drAddressIdToHonor;
         }
         else
         {
            this.jobScoreReportRepository.HonorDrAddressId(-1);
         }
      }

      /// <summary>
      /// Saving job score information
      /// </summary>
      /// <param name="jobGraderResponse">Job grade response which needs to be saved</param>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Returns true if data saved successfully else false</returns>
      public async Task<bool> SaveJobScoreInfo(JobGraderResponse jobGraderResponse, int jobId, int bidAlternateId)
      {
         // Building request to save job score information
         JobScore jobScore = new JobScore()
         {
            BID_ALTERNATE_ID = bidAlternateId,
            JOB_ID = jobId,
            LETTER_SCORE = jobGraderResponse.LetterScore,
            CREATED_USER = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower(),
            JOB_SCORE_ID = await this.jobScoreReportRepository.GetSequenceNumber("JOB_SCORE", 1),
         };

         List<JobScoreLine> jobScoreLineItems = new List<JobScoreLine>();

         foreach (JobGraderResponseLineItem jobLineItem in jobGraderResponse.JobLineItems)
         {
            JobScoreLine jobScoreLine = new JobScoreLine()
            {
               JOB_SCORE_ID = jobScore.JOB_SCORE_ID,
               JOB_SCORE_LINE_ID = await this.jobScoreReportRepository.GetSequenceNumber("JOB_SCORE_LINE", 1),
               LETTER_SCORE = jobLineItem.LetterScore,
               PROD_CODE = jobLineItem.ProductCode,
               JOB_SIZE = jobLineItem.RatedJobSize
            };
            jobScoreLineItems.Add(jobScoreLine);
         }

         JobScoreReport jobScoreReport = new JobScoreReport()
         {
            JobScore = jobScore,
            JobScoreLine = jobScoreLineItems
         };
         bool isJobScoreReportSaved = this.jobScoreReportRepository.SaveJobScoreDetails(jobScoreReport);
         if (isJobScoreReportSaved)
         {
            // once the job score report info got saved, make a call to job grade mendix api
            return await this.GradeJob(this.drAddressId, jobId, bidAlternateId);
         }

         return isJobScoreReportSaved;
      }

      /// <summary>
      /// Scoring job by calling mendix api
      /// </summary>
      /// <param name="drAddressId">Dr address id</param>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>True/False</returns>
      private async Task<bool> GradeJob(int drAddressId, int jobId, int bidAlternateId)
      {
         try
         {
            JobGraderRequest jobGradeRequest = await this.jobGraderRequestBuilder.BuildJobGraderRequest(drAddressId, jobId, bidAlternateId);
            await this.jobGraderApiClient.GradeJob(jobGradeRequest);
         }
         catch (Exception)
         {
            return false;
         }

         return true;
      }
   }
}
