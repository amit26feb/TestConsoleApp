﻿// <copyright file="OrderCreationProcessService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Repository;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Service to identify and queue newly transmitted orders
   /// </summary>
   public class OrderCreationProcessService : IOrderCreationProcessService
   {
      private readonly ILogger logger;
      private readonly IJobScoreRepository jobScoreRepository;
      private readonly IOrderRepository orderRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="OrderCreationProcessService"/> class.
      /// </summary>
      /// <param name="log">Logging the information</param>
      /// <param name="jobScoreRepository">instance of Job Score repository</param>
      /// <param name="orderRepository">instance of Order repository</param>
      public OrderCreationProcessService(
            ILogger<JobScoringHostedService> log,
            IJobScoreRepository jobScoreRepository,
            IOrderRepository orderRepository)
      {
         this.logger = log;
         this.jobScoreRepository = jobScoreRepository;
         this.orderRepository = orderRepository;
      }

      /// <inheritdoc/>
      public async Task ImportRecentlyTransmittedOrders()
      {
         // get time of last execution
         DateTime lastExecution = await this.GetLastExecution();

         // TEMP - shouldn't totally trust the last execution
         //     it's the "current" time when the process record was inserted
         //     FOE fetchs the SYSDATE (from ES) and applies it to the local record, which is then transmitted and used as DATE_CREATED
         //     so, need a little room for error - while assuming F_DBDATE and SYSDATE *are* in the same timezone
         DateTime criteriaDate = lastExecution.AddMinutes(-5);

         // look for newly created orders
         IEnumerable<EnterpriseSalesOrder> newOrders = await this.GetNewOrders(criteriaDate);

         if (newOrders.Any())
         {
            foreach (EnterpriseSalesOrder so in newOrders)
            {
               try
               {
                  await this.CreateStagingRecord(so);
               }
               catch (InvalidOperationException ex)
               {
                  // can log the message directly, it was formatted when created
                  this.logger.LogError(ex.Message);
               }
            }
         }
      }

      /// <summary>
      /// Create a staging order entry from an Enterprise Sales Order, converting job and bid to local ids
      /// </summary>
      /// <param name="eso">Enterprised Sales Order</param>
      /// <returns>Task</returns>
      private async Task CreateStagingRecord(EnterpriseSalesOrder eso)
      {
         SalesOrder so = new SalesOrder()
         {
            SalesOrderId = eso.SalesOrdId, // continue using ES Sales Order Id
            HqtrCreditJobId = eso.CreditJobId,
            CreatedDate = eso.DateCreated,
            SpaNumber = eso.SpaNumber
         };

         // Lookup local Job record, using Hqtr Id
         //  if not job was found, assume the job did not originate from the current environment
         JobLookup job = await this.jobScoreRepository.GetJob(eso.OriginatingDrAddress, eso.JobId);
         if (job == null)
         {
            return;
         }

         so.JobId = job.JobId;
         so.DrAddressId = job.DrAddressId;

         // Lookup local Bid record, using Hqtr Id
         //  if not bid was found, assume the bid did not originate from the current environment
         Bid bid = await this.jobScoreRepository.GetBid(eso.OriginatingDrAddress, eso.BidAlternateId);
         if (bid == null)
         {
            return;
         }

         so.BidAlternateId = bid.BidAlternateId;

         // finally, create the record
         await this.jobScoreRepository.CreateStagingEntry(so);
      }

      private async Task<DateTime> GetLastExecution()
      {
         return await this.jobScoreRepository.GetLastExecution();
      }

      private async Task<IEnumerable<EnterpriseSalesOrder>> GetNewOrders(DateTime lastExecution)
      {
         return await this.orderRepository.GetNewTransmittedOrders(lastExecution);
      }
   }
}
