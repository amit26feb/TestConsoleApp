﻿// <copyright file="HostedServiceBase.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Threading;
   using System.Threading.Tasks;
   using Microsoft.Extensions.Hosting;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;

   /// <summary>
   /// Base hosting service, to eliminate duplicated code
   /// </summary>
   public abstract class HostedServiceBase : IHostedService
   {
      private readonly ILogger logger;
      private readonly IOptions<Settings> jobScoringSettings;

      private Timer timer;
      private bool inProgress = false;

      /// <summary>
      /// Initializes a new instance of the <see cref="HostedServiceBase"/> class.
      /// </summary>
      /// <param name="log">Logging the information</param>
      /// <param name="jobScoringSettings">settings</param>
      /// <param name="serviceProvider">Service Provider</param>
      protected HostedServiceBase(ILogger log, IOptions<Settings> jobScoringSettings, IServiceProvider serviceProvider)
      {
         this.jobScoringSettings = jobScoringSettings;
         this.Services = serviceProvider;
         this.logger = log;
      }

      /// <summary>
      /// Gets Service Provider
      /// </summary>
      public IServiceProvider Services
      {
         get;
         private set;
      }

      /// <summary>
      /// Gets logger instance
      /// </summary>
      protected ILogger Logger => this.logger;

      /// <summary>
      /// Gets Job Scoring Settings
      /// </summary>
      protected IOptions<Settings> JobScoringSettings => this.jobScoringSettings;

      /// <summary>
      /// Start job scoring background service
      /// </summary>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      public Task StartAsync(CancellationToken cancellationToken)
      {
         this.Logger.LogTrace("Job scoring background service is starting");
         this.timer = new Timer(async obj => await this.ConcurrentProcess(obj), null, TimeSpan.Zero, TimeSpan.FromSeconds(this.jobScoringSettings.Value.IHostingServiceTimeIntervalInSeconds));
         return Task.CompletedTask;
      }

      /// <summary>
      /// Stop the job scoring background service
      /// </summary>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      public Task StopAsync(CancellationToken cancellationToken)
      {
         this.Logger.LogTrace("Job scoring background service is stopping");
         this.timer?.Change(Timeout.Infinite, 0);
         return Task.CompletedTask;
      }

      /// <summary>
      /// Perform job scoring workload
      /// </summary>
      /// <param name="state">Default parameter</param>
      /// <returns>A <see cref="Task"/> Representing the asynchronous operation.</returns>
      public async Task ConcurrentProcess(object state)
      {
         if (this.inProgress)
         {
            return;
         }

         this.inProgress = true;
         while (this.inProgress)
         {
            await this.DoProcesss();

            this.inProgress = false;
         }
      }

      /// <summary>
      /// Processs worker
      /// </summary>
      /// <returns>Task</returns>
      protected abstract Task DoProcesss();
   }
}
