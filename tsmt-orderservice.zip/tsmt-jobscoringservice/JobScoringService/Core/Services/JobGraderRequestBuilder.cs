﻿// <copyright file="JobGraderRequestBuilder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using JobScoringService.Common.Exceptions;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ServiceAPI;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// A service for building Job Grader request payloads
   /// </summary>
   public class JobGraderRequestBuilder : IJobGraderRequestBuilder
   {
      /// <summary>
      /// Sales Office Id identifying TIG Sales Office
      /// </summary>
      public const int SalesOfficeTIG = 357;

      /// <summary>
      /// The database id for the job classification, Job Strategy
      /// </summary>
      public const int JobClassificationJobStrategyId = 110;

      /// <summary>
      /// The class logger
      /// </summary>
      private readonly ILogger<JobGraderRequestBuilder> logger;

      /// <summary>
      /// The jobs API client
      /// </summary>
      private readonly IJobsApiClient jobsApiClient;

      /// <summary>
      /// The bids API client
      /// </summary>
      private readonly IBidsApiClient bidsApiClient;

      /// <summary>
      /// The sales rollup API client
      /// </summary>
      private readonly ISalesRollupApiClient salesRollupApiClient;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobGraderRequestBuilder"/> class.
      /// </summary>
      /// <param name="logger">The class logger</param>
      /// <param name="jobsApiClient">The jobs API client</param>
      /// <param name="bidsApiClient">The bids API client</param>
      /// <param name="salesRollupApiClient">The sales rollup API client</param>
      public JobGraderRequestBuilder(
         ILogger<JobGraderRequestBuilder> logger,
         IJobsApiClient jobsApiClient,
         IBidsApiClient bidsApiClient,
         ISalesRollupApiClient salesRollupApiClient)
      {
         this.logger = logger;
         this.jobsApiClient = jobsApiClient;
         this.bidsApiClient = bidsApiClient;
         this.salesRollupApiClient = salesRollupApiClient;
      }

      /// <summary>
      /// Interprets Currency ($USD or $CAD) from a CustChannel
      /// </summary>
      /// <param name="custChannelId">identifies a CustChannel</param>
      /// <returns>currency string ($USD or $CAD)</returns>
      public static string GetCurrencyFromCustChannelId(string custChannelId)
      {
         string currency = null;

         switch (custChannelId)
         {
            case "COMMSALE":
               currency = "$USD";
               break;
            case "CANADA":
               currency = "$CAD";
               break;
            default:
               throw new JobScoringServiceDomainException(
                  string.Format(
                     "Unable to interpret Currency from CustChannelId ({0}).",
                     custChannelId ?? string.Empty));
         }

         return currency;
      }

      /// <inheritdoc/>
      public virtual async Task<JobGraderRequest> BuildJobGraderRequest(int drAddressId, int jobId, int bidAlternateId, bool isFinalScore = false)
      {
         JobGraderRequest jobGraderRequest = new JobGraderRequest();

         await this.jobsApiClient.EnsureAuthorization();
         await this.bidsApiClient.EnsureAuthorization();
         await this.salesRollupApiClient.EnsureAuthorization();

         Job job = await this.GetJob(drAddressId, jobId);

         if (job.JobOfficeAndPeople.SalesOfficeId == JobGraderRequestBuilder.SalesOfficeTIG)
         {
            // International orders are not graded, therefore we can bypass the remaining work to create a request
            throw new TigSalesOfficeException();
         }

         Bid bid = await this.GetBid(drAddressId, jobId, bidAlternateId);

         jobGraderRequest.Job = job.JobGeneral.JobName;
         jobGraderRequest.Currency = GetCurrencyFromCustChannelId(job.JobGeneral.CustChannelId);
         jobGraderRequest.SalesOffice = await this.GetOfficeName(job.JobOfficeAndPeople.SalesOfficeId, "Sales Office");
         jobGraderRequest.JobLocation = await this.GetOfficeName(job.JobOfficeAndPeople.LocationOffice, "Location Office");
         jobGraderRequest.SalesPerson = await this.GetSalesPerson(job.JobOfficeAndPeople.SalesOfficeId, job.JobOfficeAndPeople.CommCode);
         jobGraderRequest.Bid = bid.BidName;
         jobGraderRequest.IsFinalScore = isFinalScore;
         jobGraderRequest.JobLineItems = await this.GetRollupLineItems(drAddressId, jobId, bid.BidAlternateId);
         jobGraderRequest.JobClassCode = "**********";  // In the future, we may want to pursue a more meaningful composite JobClassCode.
         jobGraderRequest.StrategicJobType = this.GetJobStrategy(job.JobClassificationList);
         jobGraderRequest.SalesOfficeCode = job.JobOfficeAndPeople.SalesOfficeCode;

         return jobGraderRequest;
      }

      /// <summary>
      /// Wrapper around call to log a warning, to facilitate better unit testings.
      /// </summary>
      /// <param name="message">warning message to log</param>
      public virtual void LogWarningMessage(string message)
      {
         this.logger.LogWarning(message);
      }

      /// <summary>
      /// Gets high-level job data, given job identifiers.
      /// </summary>
      /// <param name="drAddressId">helps identify a job</param>
      /// <param name="jobId">job identifier</param>
      /// <returns>high-level job data</returns>
      public virtual async Task<Job> GetJob(int drAddressId, int jobId)
      {
         Job job = await this.jobsApiClient.GetJob(drAddressId, jobId);
         if (job == null || job.JobGeneral == null || job.JobOfficeAndPeople == null)
         {
            throw new JobScoringServiceDomainException(
               string.Format(
                  "Unable to get well-formed Job via call to Jobs API client. (DrAddressId={0}, JobId={1})",
                  drAddressId,
                  jobId));
         }

         return job;
      }

      /// <summary>
      /// Gets the bid, given bid alternate identifiers.
      /// </summary>
      /// <param name="drAddressId">helps identify a bid</param>
      /// <param name="jobId">job identifier</param>
      /// <param name="bidAlternateId">bid alternate identifier</param>
      /// <returns>bid</returns>
      public virtual async Task<Bid> GetBid(int drAddressId, int jobId, int bidAlternateId)
      {
         Bid bid = await this.bidsApiClient.GetBidAsync(drAddressId, jobId, bidAlternateId);
         if (bid == null)
         {
            throw new JobScoringServiceDomainException(
            string.Format(
               "Unable to get bid via call to Bids API client. (DrAddressId={0}, JobId={1}, BidAlternateId={2})",
               drAddressId,
               jobId,
               bidAlternateId));
         }

         return bid;
      }

      /// <summary>
      /// Gets the name of a sales office.
      /// </summary>
      /// <param name="salesOfficeId">identifies a sales office</param>
      /// <param name="officeTypeForErrorReporting">describes the type of sales office being fetched, to provide a more detailed error message if an exception arises</param>
      /// <returns>name of a sales office</returns>
      public virtual async Task<string> GetOfficeName(int salesOfficeId, string officeTypeForErrorReporting)
      {
         SalesOffice salesOffice = await this.jobsApiClient.GetSalesOffice(salesOfficeId);
         if (salesOffice == null)
         {
            throw new JobScoringServiceDomainException(
               string.Format(
                  "Unable to get {0} via call to Jobs API client, for {0} Id ({1}).",
                  officeTypeForErrorReporting,
                  salesOfficeId));
         }
         else if (string.IsNullOrEmpty(salesOffice.Name))
         {
            throw new JobScoringServiceDomainException(
               string.Format(
                  "Blank {0} Name, for {0} Id ({1}).",
                  officeTypeForErrorReporting,
                  salesOfficeId));
         }

         return salesOffice.Name;
      }

      /// <summary>
      /// Gets sales person display name for a commissioned user.
      /// </summary>
      /// <param name="salesOfficeId">identifies the sales office that the commissioned user belongs to</param>
      /// <param name="commCode">identifies the commissioned user</param>
      /// <returns>sales person display name</returns>
      public virtual async Task<string> GetSalesPerson(int salesOfficeId, string commCode)
      {
         string salesPerson = null;

         if (string.IsNullOrEmpty(commCode))
         {
            this.LogWarningMessage("JobGrader request payload will have a blank Sales Person because the Job has a blank CommCode.");
         }
         else
         {
            IEnumerable<CommissionCode> commissionCodes = await this.jobsApiClient.GetCommissionCodes(salesOfficeId);
            CommissionCode commissionCode = commissionCodes?.FirstOrDefault(cc => cc.CommCode == commCode);
            if (commissionCode == null)
            {
               this.LogWarningMessage(
                  string.Format(
                     "JobGrader request payload will have a blank Sales Person because the job CommCode ({0}) was not found under the job SalesOfficeId ({1}) CommCodes.",
                     commCode,
                     salesOfficeId));
            }
            else if (string.IsNullOrEmpty(commissionCode.CommCodeDisplay))
            {
               salesPerson = commCode;  // Sending a CommCode (without name) for SalesPerson is better than nothing.
            }
            else
            {
               salesPerson = commissionCode.CommCodeDisplay;
            }
         }

         return salesPerson;
      }

      /// <summary>
      /// Gets a collection of Product Code price rollup line items for a given job and bid.
      /// </summary>
      /// <param name="drAddressId">helps identify the job and bid</param>
      /// <param name="jobId">identifies a job</param>
      /// <param name="bidId">identifies a bid to honor, for the rollup</param>
      /// <returns>price rollup line times (Product Code lines)</returns>
      public virtual async Task<IEnumerable<JobGraderRequestLineItem>> GetRollupLineItems(int drAddressId, int jobId, int bidId)
      {
         SalesRollup salesRollup = await this.salesRollupApiClient.GetRollupData(drAddressId, jobId, bidId, SalesRollupType.Code);
         if (salesRollup == null)
         {
            throw new JobScoringServiceDomainException(
            string.Format(
               "Unable to get sales rollup data via call to SalesRollup API client. (DrAddressId={0}, JobId={1}, BidId={2})",
               drAddressId,
               jobId,
               bidId));
         }

         List<JobGraderRequestLineItem> jobLineItems = new List<JobGraderRequestLineItem>();
         if (salesRollup.Rows != null)
         {
            foreach (SalesRollupRow salesRollupRow in salesRollup.Rows)
            {
               JobGraderRequestLineItem jobLineItem = new JobGraderRequestLineItem()
               {
                  Product = salesRollupRow.ItemDescription,
                  ProductCode = salesRollupRow.ProductCode,
                  UnitQuantity = salesRollupRow.UnitQuantity ?? 0,  // Seems sketchy, but we were told the UnitQuantity was not used by the JobGrader algorithm.
                  // For the Multipliers and Dollar amounts below, we should be safe to treat nulls as zero.
                  QuantityLPAF = salesRollupRow.QuantityLpaf ?? 0m,
                  QuantityShipLPAF = salesRollupRow.QuickShipLpaf ?? 0m,
                  UnadjustedListPrice = salesRollupRow.UnadjustedListPrice ?? 0m,
                  AdjustedListPrice = salesRollupRow.AdjustedListPrice ?? 0m,
                  EnteredCPLPAF = salesRollupRow.EnteredCostPointLpaf ?? 0m,
                  EnteredMultiplier = salesRollupRow.EnteredMultiplier ?? 0m,
                  EnteredDollarAmount = salesRollupRow.EnteredDollars ?? 0m,
                  TraneNetDollars = salesRollupRow.TraneNetDollars ?? 0m,
                  VariationPrice = salesRollupRow.VariationPrice ?? 0m,
                  FapDollars = salesRollupRow.FapDollars ?? 0m
               };
               jobLineItems.Add(jobLineItem);
            }
         }

         return jobLineItems;
      }

      /// <summary>
      /// Find the specific classification we are looking at, job strategy and send back the job code for that classification
      /// </summary>
      /// <param name="jobClassifications">The list of classifications set on this job</param>
      /// <returns>The job code, 1,2,3,4 or 0 for the chosen Job Strategy</returns>
      public string GetJobStrategy(IEnumerable<JobClassification> jobClassifications)
      {
         string returnStrategy = string.Empty;

         if (jobClassifications != null)
         {
            JobClassification jc = jobClassifications.SingleOrDefault(x => x.JobClassId == JobClassificationJobStrategyId);
            if (jc != null)
            {
               returnStrategy = jc.JobCode;
            }
         }

         return returnStrategy;
      }
   }
}
