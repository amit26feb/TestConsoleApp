﻿// <copyright file="ExcludedProductCode.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using MongoDB.Bson.Serialization.Attributes;

   /// <summary>
   /// Excluded product code model
   /// </summary>
   [BsonIgnoreExtraElements]
   public class ExcludedProductCode
   {
      /// <summary>
      /// Gets or sets product code
      /// </summary>
      public string ProductCode { get; set; }
   }
}
