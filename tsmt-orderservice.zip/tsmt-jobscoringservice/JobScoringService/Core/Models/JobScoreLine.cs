﻿// <copyright file="JobScoreLine.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Model for job score for line item
   /// </summary>
   public class JobScoreLine
   {
      /// <summary>
      /// Gets or sets job score line id
      /// </summary>
      public int JOB_SCORE_LINE_ID { get; set; }

      /// <summary>
      /// Gets or sets job score id
      /// </summary>
      public int JOB_SCORE_ID { get; set; }

      /// <summary>
      /// Gets or sets product code
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets letter score
      /// </summary>
      public string LETTER_SCORE { get; set; }

      /// <summary>
      /// Gets or sets excluded status
      /// </summary>
      public string EXCLUDED { get; set; }

      /// <summary>
      /// Gets or sets job size
      /// </summary>
      public string JOB_SIZE { get; set; }
   }
}
