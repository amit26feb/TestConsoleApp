﻿// <copyright file="JobGraderResponse.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System;

   /// <summary>
   /// Response data for Job Grader
   /// </summary>
   public class JobGraderResponse : JobGraderResponseShared
   {
      /// <summary>
      /// totalEquipmentRevenue
      /// </summary>
      private decimal totalEquipmentRevenue;

      /// <summary>
      /// Entered ab dollar next score
      /// </summary>
      private decimal enteredABDollarNextScore;

      /// <summary>
      /// Entered bc dollar next score
      /// </summary>
      private decimal enteredBCDollarNextScore;

      /// <summary>
      /// Entered cd dollar next score
      /// </summary>
      private decimal enteredCDDollarNextScore;

      /// <summary>
      /// Entered de dollar next score
      /// </summary>
      private decimal enteredDEDollarNextScore;

      /// <summary>
      /// Entered ab dollar step down score
      /// </summary>
      private decimal enteredABDollarStepDownScore;

      /// <summary>
      /// Entered bc dollar step down score
      /// </summary>
      private decimal enteredBCDollarStepDownScore;

      /// <summary>
      /// Entered cd dollar step down score
      /// </summary>
      private decimal enteredCDDollarStepDownScore;

      /// <summary>
      /// Entered de dollar step down score
      /// </summary>
      private decimal enteredDEDollarStepDownScore;

      /// <summary>
      /// Step down rated cut off grade 1
      /// </summary>
      private decimal stepDownRatedCutoffGrade1;

      /// <summary>
      /// Step down rated cut off grade 2
      /// </summary>
      private decimal stepDownRatedCutoffGrade2;

      /// <summary>
      /// Step down rated cut off grade 3
      /// </summary>
      private decimal stepDownRatedCutoffGrade3;

      /// <summary>
      /// Step down rated cut off grade 4
      /// </summary>
      private decimal stepDownRatedCutoffGrade4;

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string Job { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string Bid { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string SalesOffice { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string SalesPerson { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string JobClassCode { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string JobLocation { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string Currency { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal TotalEquipmentRevenue
      {
         get
         {
            return this.totalEquipmentRevenue;
         }

         set
         {
            this.totalEquipmentRevenue = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string ObjectStatus { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string RatedMultiplierAltDisplay { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade1 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade2 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade3 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade4 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string StepDownCutoffAltDisplayGrade1 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string StepDownCutoffAltDisplayGrade2 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string StepDownCutoffAltDisplayGrade3 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string StepDownCutoffAltDisplayGrade4 { get; set; }

      /// <summary>
      /// Gets or sets LetterScore
      /// </summary>
      public string LetterScore { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal DisplayABDollarAmount { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal DisplayBCDollarAmount { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal DisplayCDDollarAmount { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal DisplayDEDollarAmount { get; set; }

      /// <summary>
      /// Gets or sets entered ab dollar next score
      /// </summary>
      public decimal EnteredABDollarNextScore
      {
         get
         {
            return this.enteredABDollarNextScore;
         }

         set
         {
            this.enteredABDollarNextScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets entered bc dollar next score
      /// </summary>
      public decimal EnteredBCDollarNextScore
      {
         get
         {
            return this.enteredBCDollarNextScore;
         }

         set
         {
            this.enteredBCDollarNextScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets entered cd dollar next score
      /// </summary>
      public decimal EnteredCDDollarNextScore
      {
         get
         {
            return this.enteredCDDollarNextScore;
         }

         set
         {
            this.enteredCDDollarNextScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets entered de dollar next score
      /// </summary>
      public decimal EnteredDEDollarNextScore
      {
         get
         {
            return this.enteredDEDollarNextScore;
         }

         set
         {
            this.enteredDEDollarNextScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets entered ab dollar step down score
      /// </summary>
      public decimal EnteredABDollarStepDownScore
      {
         get
         {
            return this.enteredABDollarStepDownScore;
         }

         set
         {
            this.enteredABDollarStepDownScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets entered bc dollar step down score
      /// </summary>
      public decimal EnteredBCDollarStepDownScore
      {
         get
         {
            return this.enteredBCDollarStepDownScore;
         }

         set
         {
            this.enteredBCDollarStepDownScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets entered cd dollar step down score
      /// </summary>
      public decimal EnteredCDDollarStepDownScore
      {
         get
         {
            return this.enteredCDDollarStepDownScore;
         }

         set
         {
            this.enteredCDDollarStepDownScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets entered de dollar step down score
      /// </summary>
      public decimal EnteredDEDollarStepDownScore
      {
         get
         {
            return this.enteredDEDollarStepDownScore;
         }

         set
         {
            this.enteredDEDollarStepDownScore = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets step down rated cut off grade 1
      /// </summary>
      public decimal StepDownRatedCutoffGrade1
      {
         get
         {
            return this.stepDownRatedCutoffGrade1;
         }

         set
         {
            this.stepDownRatedCutoffGrade1 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets step down rated cut off grade 2
      /// </summary>
      public decimal StepDownRatedCutoffGrade2
      {
         get
         {
            return this.stepDownRatedCutoffGrade2;
         }

         set
         {
            this.stepDownRatedCutoffGrade2 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets step down rated cut off grade 3
      /// </summary>
      public decimal StepDownRatedCutoffGrade3
      {
         get
         {
            return this.stepDownRatedCutoffGrade3;
         }

         set
         {
            this.stepDownRatedCutoffGrade3 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets step down rated cut off grade 4
      /// </summary>
      public decimal StepDownRatedCutoffGrade4
      {
         get
         {
            return this.stepDownRatedCutoffGrade4;
         }

         set
         {
            this.stepDownRatedCutoffGrade4 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets error message
      /// </summary>
      public string ErrorMessage { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public JobGraderResponseLineItem[] JobLineItems { get; set; }
   }
}