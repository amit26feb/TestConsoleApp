﻿// <copyright file="JobGradeFactorModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using MongoDB.Bson;
   using MongoDB.Bson.Serialization.Attributes;

   /// <summary>
   /// Job grade factor model
   /// </summary>
   [BsonIgnoreExtraElements]
   public class JobGradeFactorModel
   {
      /// <summary>
      /// Gets or sets job grade factor
      /// </summary>
      [BsonRepresentation(BsonType.Decimal128)]
      public decimal JobGradeFactor { get; set; }
   }
}