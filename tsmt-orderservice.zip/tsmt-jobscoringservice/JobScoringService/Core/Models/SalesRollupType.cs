﻿// <copyright file="SalesRollupType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Denotes the Sales Rollup grid layout
   /// </summary>
   public enum SalesRollupType
   {
      /// <summary>
      /// The product code type
      /// </summary>
      Code,

      /// <summary>
      /// The product family type
      /// </summary>
      Family,

      /// <summary>
      /// The product model type
      /// </summary>
      Model
   }
}