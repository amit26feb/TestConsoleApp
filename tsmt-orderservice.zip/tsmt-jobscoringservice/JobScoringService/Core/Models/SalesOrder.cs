﻿// <copyright file="SalesOrder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// CREDIT_JOB_SCORE_STAGE entry, representative of a transmitted sales order
   /// </summary>
   public class SalesOrder : IDataEntity
   {
      /// <summary>
      /// Gets or sets Sales Order Id (PK)
      /// </summary>
      public int SalesOrderId { get; set; }

      /// <summary>
      /// Gets or sets Dr Address Id (PK)
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets Hqtr Credit Job Id
      /// </summary>
      public int HqtrCreditJobId { get; set; }

      /// <summary>
      /// Gets or sets Created Date - when stage record was first created
      /// </summary>
      public DateTime CreatedDate { get; set; }

      /// <summary>
      /// Gets or sets Job Id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets Bid Alternate Id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets SPA (Special Pricing Authorization) Number
      /// </summary>
      public string SpaNumber { get; set; }
   }
}
