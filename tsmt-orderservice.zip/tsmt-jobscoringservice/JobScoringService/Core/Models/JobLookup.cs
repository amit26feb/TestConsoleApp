﻿// <copyright file="JobLookup.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Job properties
   /// </summary>
   public class JobLookup
   {
      /// <summary>
      /// Gets or sets Job Id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets Dr Address Id
      /// </summary>
      public int DrAddressId { get; set; }
   }
}
