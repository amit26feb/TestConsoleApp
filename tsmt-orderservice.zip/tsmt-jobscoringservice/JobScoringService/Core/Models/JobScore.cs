﻿// <copyright file="JobScore.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
    using System;
    using TSMT.DataAccess;

   /// <summary>
   /// Model for job score
   /// </summary>
   public class JobScore : IDataEntity
   {
      /// <summary>
      /// Gets or sets job score id
      /// </summary>
      public int JOB_SCORE_ID { get; set; }

      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets created date
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets created user
      /// </summary>
      public string CREATED_USER { get; set; }

      /// <summary>
      /// Gets or sets job size
      /// </summary>
      public string JOB_SIZE { get; set; }

      /// <summary>
      /// Gets or sets letter score
      /// </summary>
      public string LETTER_SCORE { get; set; }

      /// <summary>
      /// Gets or sets excluded indicator
      /// </summary>
      public string EXCLUDED { get; set; }
   }
}
