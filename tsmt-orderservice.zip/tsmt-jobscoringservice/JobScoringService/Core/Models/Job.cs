﻿// <copyright file="Job.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System.Collections.Generic;

   /// <summary>
   /// Job properties
   /// </summary>
   public class Job
   {
      /// <summary>
      /// Gets or sets the collection of general properties for a job
      /// </summary>
      public JobGeneral JobGeneral { get; set; }

      /// <summary>
      /// Gets or sets properties related to office and people, for a job
      /// </summary>
      public JobOfficeAndPeople JobOfficeAndPeople { get; set; }

      /// <summary>
      /// Gets or sets properties related to the classifications for the job
      /// </summary>
      public List<JobClassification> JobClassificationList { get; set; }
   }
}
