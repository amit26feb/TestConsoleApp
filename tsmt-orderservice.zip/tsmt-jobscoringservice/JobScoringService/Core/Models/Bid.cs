// <copyright file="Bid.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Bid properties
   /// </summary>
   public class Bid
   {
      /// <summary>
      /// Gets or sets BidAlternateId
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets CurrentBidInd
      /// </summary>
      public string CurrentBidInd { get; set; }

      /// <summary>
      /// Gets or sets BidName
      /// </summary>
      public string BidName { get; set; }

      /// <summary>
      /// Gets or sets Description
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets BaseBidYesNo
      /// </summary>
      public int BaseBidYesNo { get; set; }
   }
}
