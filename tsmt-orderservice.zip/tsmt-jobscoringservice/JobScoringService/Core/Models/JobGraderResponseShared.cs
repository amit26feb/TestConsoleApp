﻿// <copyright file="JobGraderResponseShared.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System;

   public class JobGraderResponseShared
   {
      /// <summary>
      /// ratedCutoffGrade1
      /// </summary>
      private decimal ratedCutoffGrade1;

      /// <summary>
      /// ratedCutoffGrade2
      /// </summary>
      private decimal ratedCutoffGrade2;

      /// <summary>
      /// ratedCutoffGrade3
      /// </summary>
      private decimal ratedCutoffGrade3;

      /// <summary>
      /// ratedCutoffGrade4
      /// </summary>
      private decimal ratedCutoffGrade4;

      /// <summary>
      /// ratedMultiplier
      /// </summary>
      private decimal ratedMultiplier;

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal RatedCutoffGrade1
      {
         get
         {
            return this.ratedCutoffGrade1;
         }

         set
         {
            this.ratedCutoffGrade1 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal RatedCutoffGrade2
      {
         get
         {
            return this.ratedCutoffGrade2;
         }

         set
         {
            this.ratedCutoffGrade2 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal RatedCutoffGrade3
      {
         get
         {
            return this.ratedCutoffGrade3;
         }

         set
         {
            this.ratedCutoffGrade3 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal RatedCutoffGrade4
      {
         get
         {
            return this.ratedCutoffGrade4;
         }

         set
         {
            this.ratedCutoffGrade4 = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public decimal RatedMultiplier
      {
         get
         {
            return this.ratedMultiplier;
         }

         set
         {
            this.ratedMultiplier = Math.Round(value, 3);
         }
      }
   }
}
