﻿// <copyright file="CreditJob.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System;

   /// <summary>
   /// Model representing information necessary to run CREDIT JOB SCORE process
   /// </summary>
   public class CreditJob
   {
      /// <summary>
      /// Gets or sets Credit Job Id
      /// </summary>
      public int HqtrCreditJobId { get; set; }

      /// <summary>
      /// Gets or sets Dr Address Id (PK)
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets Job Id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets Bid Alternate Id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets last time credit job was submitted for grading
      /// </summary>
      public DateTime? ProcessDate { get; set; }

      /// <summary>
      /// Gets or sets Retry Count - number of times credit job has been retried for grading
      /// </summary>
      public int RetryCount { get; set; }

      /// <summary>
      /// Gets or sets Letter Score
      /// </summary>
      public string LetterScore { get; set; }

      /// <summary>
      /// Gets or sets SPA (Special Pricing Authorization) Number
      /// </summary>
      public string SpaNumber { get; set; }
   }
}
