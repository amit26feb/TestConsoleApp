﻿// <copyright file="JobScoreTotal.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Calculate Total Values for job score calculation
   /// </summary>
   public class JobScoreTotal
   {
      /// <summary>
      /// Gets or sets total quantity lpaf and quantity ship lpaf
      /// </summary>
      public decimal TotalQtyLPAFAndQtyShipLPAF { get; set; }

      /// <summary>
      /// Gets or sets total job size sollar
      /// </summary>
      public decimal TotaJobSizeDollar { get; set; }

      /// <summary>
      /// Gets or sets total entered dollar
      /// </summary>
      public decimal TotalEnteredDollar { get; set; }

      /// <summary>
      /// Gets or sets total ab break point dollar
      /// </summary>
      public decimal TotalABBreakPointDollar { get; set; }

      /// <summary>
      /// Gets or sets total bc break point dollar
      /// </summary>
      public decimal TotalBCBreakPointDollar { get; set; }

      /// <summary>
      /// Gets or sets total cd break point dollar
      /// </summary>
      public decimal TotalCDBreakPointDollar { get; set; }

      /// <summary>
      /// Gets or sets total de break point dollar
      /// </summary>
      public decimal TotalDEBreakPointDollar { get; set; }

      /// <summary>
      /// Gets or sets total valid product entered dollar
      /// </summary>
      public decimal TotalValidProductEnteredDollar { get; set; }
   }
}