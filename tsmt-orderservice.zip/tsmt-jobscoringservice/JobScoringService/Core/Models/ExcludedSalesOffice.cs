﻿// <copyright file="ExcludedSalesOffice.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Excluded sales office model
   /// </summary>
   public class ExcludedSalesOffice
   {
      /// <summary>
      /// Gets or sets code
      /// </summary>
      public string Code { get; set; }
   }
}