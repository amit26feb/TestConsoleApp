﻿// <copyright file="CommissionCode.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Properties for commissioned individuals (called a CommCode in Trane lore)
   /// </summary>
   public class CommissionCode
   {
      /// <summary>
      /// Gets or sets Name
      /// </summary>
      public string Name { get; set; }

      /// <summary>
      /// Gets or sets CommCode
      /// </summary>
      public string CommCode { get; set; }

      /// <summary>
      /// Gets or sets CommCodeDisplay
      /// </summary>
      public string CommCodeDisplay { get; set; }

      /// <summary>
      /// Gets or sets SalesOfficeId
      /// </summary>
      public int SalesOfficeId { get; set; }
   }
}
