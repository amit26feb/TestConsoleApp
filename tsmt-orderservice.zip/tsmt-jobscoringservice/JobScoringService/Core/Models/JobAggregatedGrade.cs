﻿// <copyright file="JobAggregatedGrade.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System;

   /// <summary>
   /// Job aggregated grade properties
   /// </summary>
   public class JobAggregatedGrade
   {
      /// <summary>
      /// Gets or sets letter score
      /// </summary>
      public string LETTER_SCORE { get; set; }

      /// <summary>
      /// Gets or sets created date
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets excluded from topper
      /// </summary>
      public string EXCLUDED_FROM_TOPPER { get; set; }

      /// <summary>
      /// Gets or sets job score id
      /// </summary>
      public int JOB_SCORE_ID { get; set; }
   }
}
