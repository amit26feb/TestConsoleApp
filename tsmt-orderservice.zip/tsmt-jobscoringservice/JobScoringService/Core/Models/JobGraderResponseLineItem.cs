﻿// <copyright file="JobGraderResponseLineItem.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System;

   /// <summary>
   /// Line Item data for Job Grader response
   /// </summary>
   public class JobGraderResponseLineItem : JobGraderResponseShared
   {
      /// <summary>
      /// unadjustedListPrice
      /// </summary>
      private decimal unadjustedListPrice;

      /// <summary>
      /// adjustedListPrice
      /// </summary>
      private decimal adjustedListPrice;

      /// <summary>
      /// enteredCPLPAF
      /// </summary>
      private decimal enteredCPLPAF;

      /// <summary>
      /// enteredMultiplier
      /// </summary>
      private decimal enteredMultiplier;

      /// <summary>
      /// Gets or sets Product
      /// </summary>
      public string Product { get; set; }

      /// <summary>
      /// Gets or sets Product Code
      /// </summary>
      public string ProductCode { get; set; }

      /// <summary>
      /// Gets or sets Unit Quantity
      /// </summary>
      public int UnitQuantity { get; set; }

      /// <summary>
      /// Gets or sets Quantity LPAF
      /// </summary>
      public decimal QuantityLPAF { get; set; }

      /// <summary>
      /// Gets or sets Quantity Ship LPAF (AKA Quick Ship LPAF)
      /// </summary>
      public decimal QuantityShipLPAF { get; set; }

      /// <summary>
      /// Gets or sets Unadjusted List Price
      /// </summary>
      public decimal UnadjustedListPrice
      {
         get
         {
            return this.unadjustedListPrice;
         }

         set
         {
            this.unadjustedListPrice = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets Adjusted List Price
      /// </summary>
      public decimal AdjustedListPrice
      {
         get
         {
            return this.adjustedListPrice;
         }

         set
         {
            this.adjustedListPrice = Math.Round(value, 2);
         }
      }

      /// <summary>
      /// Gets or sets Entered CPLPAF
      /// </summary>
      public decimal EnteredCPLPAF
      {
         get
         {
            return this.enteredCPLPAF;
         }

         set
         {
            this.enteredCPLPAF = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets Entered Multiplier
      /// </summary>
      public decimal EnteredMultiplier
      {
         get
         {
            return this.enteredMultiplier;
         }

         set
         {
            this.enteredMultiplier = Math.Round(value, 3);
         }
      }

      /// <summary>
      /// Gets or sets Entered Dollar Amount
      /// </summary>
      public decimal EnteredDollarAmount { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string ObjectStatus { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string EquipmentLine { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string RatedMultiplierAltDisplay { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string RatedLocation { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string RatedJobSize { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade1 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade2 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade3 { get; set; }

      /// <summary>
      /// Gets or sets property
      /// </summary>
      public string CutoffAltDisplayGrade4 { get; set; }

      /// <summary>
      /// Gets or sets LetterScore
      /// </summary>
      public string LetterScore { get; set; }

      /// <summary>
      /// Gets or sets trane net dollars
      /// </summary>
      public decimal TraneNetDollars { get; set; }

      /// <summary>
      /// Gets or sets variation price
      /// </summary>
      public decimal VariationPrice { get; set; }

      /// <summary>
      /// Gets or sets fap dollars
      /// </summary>
      public decimal FapDollars { get; set; }
   }
}
