﻿// <copyright file="JobScoreQuintile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace JobScoringService.Core.Models
{
   using MongoDB.Bson;
   using MongoDB.Bson.Serialization.Attributes;

   /// <summary>
   /// Job score quintile entity
   /// </summary>
   [BsonIgnoreExtraElements]
   public class JobScoreQuintile
   {
      private readonly string jobSizeValueSeparator = "-";

      /// <summary>
      ///  Gets or sets job size
      /// </summary>
      public string JobSize { get; set; }

      /// <summary>
      ///  Gets or sets product code
      /// </summary>
      public string ProductCode { get; set; }

      /// <summary>
      ///  Gets or sets location
      /// </summary>
      public string Location { get; set; }

      /// <summary>
      ///  Gets or sets info job count
      /// </summary>
      public int InfoJobCount { get; set; }

      /// <summary>
      ///  Gets or sets info Geography
      /// </summary>
      public string InfoGeography { get; set; }

      /// <summary>
      ///  Gets or sets info job size
      /// </summary>
      public string InfoJobSize { get; set; }

      /// <summary>
      ///  Gets or sets start b
      /// </summary>
      [BsonRepresentation(BsonType.Decimal128)]
      public decimal StartB { get; set; }

      /// <summary>
      ///  Gets or sets start c
      /// </summary>
      [BsonRepresentation(BsonType.Decimal128)]
      public decimal StartC { get; set; }

      /// <summary>
      ///  Gets or sets start d
      /// </summary>
      [BsonRepresentation(BsonType.Decimal128)]
      public decimal StartD { get; set; }

      /// <summary>
      ///  Gets or sets start e
      /// </summary>
      [BsonRepresentation(BsonType.Decimal128)]
      public decimal StartE { get; set; }
   }
}
