﻿// <copyright file="JobOfficeAndPeople.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Office and People related properties for a Job
   /// </summary>
   public class JobOfficeAndPeople
   {
      /// <summary>
      /// Gets or sets SalesOfficeId
      /// </summary>
      public int SalesOfficeId { get; set; }

      /// <summary>
      /// Gets or sets LocationOffice
      /// </summary>
      public int LocationOffice { get; set; }

      /// <summary>
      /// Gets or sets CommCode (to identify the key individual receiving sales commission for the job)
      /// </summary>
      public string CommCode { get; set; }

      /// <summary>
      /// Gets or sets sales office code
      /// /// </summary>
      public string SalesOfficeCode { get; set; }
   }
}
