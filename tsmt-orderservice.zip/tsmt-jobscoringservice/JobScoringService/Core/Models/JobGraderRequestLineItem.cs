﻿// <copyright file="JobGraderRequestLineItem.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// Line Item data for Job Grader request
   /// </summary>
   public class JobGraderRequestLineItem
   {
      /// <summary>
      /// Gets or sets Product
      /// </summary>
      public string Product { get; set; }

      /// <summary>
      /// Gets or sets Product Code
      /// </summary>
      public string ProductCode { get; set; }

      /// <summary>
      /// Gets or sets Unit Quantity
      /// </summary>
      public int UnitQuantity { get; set; }

      /// <summary>
      /// Gets or sets Quantity LPAF
      /// </summary>
      public decimal QuantityLPAF { get; set; }

      /// <summary>
      /// Gets or sets Quantity Ship LPAF (AKA Quick Ship LPAF)
      /// </summary>
      public decimal QuantityShipLPAF { get; set; }

      /// <summary>
      /// Gets or sets Unadjusted List Price
      /// </summary>
      public decimal UnadjustedListPrice { get; set; }

      /// <summary>
      /// Gets or sets Adjusted List Price
      /// </summary>
      public decimal AdjustedListPrice { get; set; }

      /// <summary>
      /// Gets or sets Entered CPLPAF
      /// </summary>
      public decimal EnteredCPLPAF { get; set; }

      /// <summary>
      /// Gets or sets Entered Multiplier
      /// </summary>
      public decimal EnteredMultiplier { get; set; }

      /// <summary>
      /// Gets or sets Entered Dollar Amount
      /// </summary>
      public decimal EnteredDollarAmount { get; set; }

      /// <summary>
      /// Gets or sets trane net dollars
      /// </summary>
      public decimal TraneNetDollars { get; set; }

      /// <summary>
      /// Gets or sets variation price
      /// </summary>
      public decimal VariationPrice { get; set; }

      /// <summary>
      /// Gets or sets fap dollars
      /// </summary>
      public decimal FapDollars { get; set; }
   }
}