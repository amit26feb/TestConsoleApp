﻿// <copyright file="EnterpriseSalesOrder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// A sales order obtained from ESTRN
   /// </summary>
   public class EnterpriseSalesOrder : IDataEntity
   {
      /// <summary>
      /// Gets or sets Sales Order Id (PK)
      /// </summary>
      public int SalesOrdId { get; set; }

      /// <summary>
      /// Gets or sets Job Id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets Hqtr Credit Job Id
      /// </summary>
      public int CreditJobId { get; set; }

      /// <summary>
      /// Gets or sets Bid Alternate Id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets SPA (Special Pricing Authorization) Number
      /// </summary>
      public string SpaNumber { get; set; }

      /// <summary>
      /// Gets or sets Created Date - when stage record was first created
      /// </summary>
      public DateTime DateCreated { get; set; }

      /// <summary>
      /// Gets or sets Originating DR Address (TSTRN Dr Address Id)
      /// </summary>
      public int OriginatingDrAddress { get; set; }

      /// <summary>
      /// Gets or sets Watcom Job Id (TSTRN Job Id)
      /// </summary>
      public int WatcomJobId { get; set; }
   }
}
