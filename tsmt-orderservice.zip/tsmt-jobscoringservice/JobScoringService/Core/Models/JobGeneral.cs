﻿// <copyright file="JobGeneral.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   /// <summary>
   /// General properties for a Job
   /// </summary>
   public class JobGeneral
   {
      /// <summary>
      /// Gets or sets JobName
      /// </summary>
      public string JobName { get; set; }

      /// <summary>
      /// Gets or sets CustChannelId
      /// </summary>
      public string CustChannelId { get; set; }
   }
}