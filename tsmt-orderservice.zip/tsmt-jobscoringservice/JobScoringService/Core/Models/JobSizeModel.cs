﻿// <copyright file="JobSizeModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using MongoDB.Bson;
   using MongoDB.Bson.Serialization.Attributes;

   /// <summary>
   /// Job size model
   /// </summary>
   [BsonIgnoreExtraElements]
   public class JobSizeModel
   {
      /// <summary>
      /// Gets or sets job size
      /// </summary>
      public string JobSize { get; set; }

      /// <summary>
      /// Gets or sets from amount
      /// </summary>
      [BsonRepresentation(BsonType.Decimal128)]
      public decimal FromAmount { get; set; }

      /// <summary>
      /// Gets or sets to amount
      /// </summary>
      [BsonRepresentation(BsonType.Decimal128)]
      public decimal ToAmount { get; set; }
   }
}
