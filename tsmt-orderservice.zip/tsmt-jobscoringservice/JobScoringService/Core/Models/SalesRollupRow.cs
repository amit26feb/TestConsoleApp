﻿// <copyright file="SalesRollupRow.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System.Collections.Generic;

   /// <summary>
   /// Sales Rollup row data model (can also contain nested rows)
   /// </summary>
   public class SalesRollupRow
   {
      /// <summary>
      ///  Gets or sets records part of this group (ie children)
      /// </summary>
      public IList<SalesRollupRow> Children { get; set; }

      /// <summary>
      /// Gets or sets text description of row
      /// </summary>
      public string ItemDescription { get; set; }

      /// <summary>
      /// Gets or sets product code
      /// </summary>
      public string ProductCode { get; set; }

      /// <summary>
      /// Gets or sets unit quantity
      /// </summary>
      public int? UnitQuantity { get; set; }

      /// <summary>
      /// Gets or sets quantity LPAF
      /// </summary>
      public decimal? QuantityLpaf { get; set; }

      /// <summary>
      /// Gets or sets quick ship LPAF
      /// </summary>
      public decimal? QuickShipLpaf { get; set; }

      /// <summary>
      /// Gets or sets unadjusted list price
      /// </summary>
      public decimal? UnadjustedListPrice { get; set; }

      /// <summary>
      /// Gets or sets adjusted list price
      /// </summary>
      public decimal? AdjustedListPrice { get; set; }

      /// <summary>
      /// Gets or sets entered cost point LPAF
      /// </summary>
      public decimal? EnteredCostPointLpaf { get; set; }

      /// <summary>
      /// Gets or sets entered multiplier
      /// </summary>
      public decimal? EnteredMultiplier { get; set; }

      /// <summary>
      /// Gets or sets entered dollars
      /// </summary>
      public decimal? EnteredDollars { get; set; }

      /// <summary>
      /// Gets or sets trane net dollars
      /// </summary>
      public decimal? TraneNetDollars { get; set; }

      /// <summary>
      /// Gets or sets variation price
      /// </summary>
      public decimal? VariationPrice { get; set; }

      /// <summary>
      /// Gets or sets fap dollars
      /// </summary>
      public decimal? FapDollars { get; set; }
   }
}
