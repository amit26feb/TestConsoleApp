﻿// <copyright file="JobGraderRequest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System.Collections.Generic;

   /// <summary>
   /// Request data for Job Grader
   /// </summary>
   public class JobGraderRequest
   {
      /// <summary>
      /// Gets or sets Job Name
      /// </summary>
      public string Job { get; set; }

      /// <summary>
      /// Gets or sets Bid Name
      /// </summary>
      public string Bid { get; set; }

      /// <summary>
      /// Gets or sets Sales Office Name
      /// </summary>
      public string SalesOffice { get; set; }

      /// <summary>
      /// Gets or sets Sales Person Name
      /// </summary>
      public string SalesPerson { get; set; }

      /// <summary>
      /// Gets or sets Job Class Code
      /// </summary>
      public string JobClassCode { get; set; }

      /// <summary>
      /// Gets or sets Job Location Name
      /// </summary>
      public string JobLocation { get; set; }

      /// <summary>
      /// Gets or sets Currency ($USD or $CAD)
      /// </summary>
      public string Currency { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether this request is triggered by the first release of a sales order.  Otherwise false.
      /// </summary>
      public bool IsFinalScore { get; set; }

      /// <summary>
      /// Gets or sets Job Strategy
      /// </summary>
      public string StrategicJobType { get; set; }

      /// <summary>
      /// Gets or sets sales office code
      /// </summary>
      public string SalesOfficeCode { get; set; }

      /// <summary>
      /// Gets or sets the Job Line Items
      /// </summary>
      public IEnumerable<JobGraderRequestLineItem> JobLineItems { get; set; }
   }
}