﻿// <copyright file="JobClassification.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System.ComponentModel.DataAnnotations;

   /// <summary>
   /// Input model to Job Classification
   /// </summary>
   public class JobClassification
   {
      /// <summary>
      /// Gets or sets JobCodeId
      /// </summary>
      public int JobCodeId { get; set; }

      /// <summary>
      /// Gets or sets JobCode
      /// </summary>
      public string JobCode { get; set; }

      /// <summary>
      /// Gets or sets Job Identifier (with DR Address ID, forms unique key)
      /// </summary>
      [Range(1, int.MaxValue)]
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets Dr Address Id Identifier
      /// </summary>
      [Range(1, int.MaxValue)]
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets JOB_CLASS_ID
      /// </summary>
      public int JobClassId { get; set; }

      /// <summary>
      /// Gets or sets Classification List Item Identifier
      /// </summary>
      public string DescriptionValues { get; set; }

      /// <summary>
      /// Gets or sets Classification Identifier
      /// </summary>
      public string ClassificationDescription { get; set; }
   }
}
