﻿// <copyright file="SalesRollup.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
   using System.Collections.Generic;

   /// <summary>
   /// Sales Rollup data model
   /// </summary>
   public class SalesRollup
   {
      /// <summary>
      /// Gets or sets collection of rollup rows
      /// </summary>
      public IList<SalesRollupRow> Rows { get; set; }
   }
}
