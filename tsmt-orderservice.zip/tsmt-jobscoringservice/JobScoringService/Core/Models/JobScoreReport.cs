﻿// <copyright file="JobScoreReport.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Models
{
    using System.Collections.Generic;

   /// <summary>
   /// Model for job score report
   /// </summary>
   public class JobScoreReport
   {
      /// <summary>
      /// Gets or sets score for job
      /// </summary>
      public JobScore JobScore { get; set; }

      /// <summary>
      /// Gets or sets score for line item
      /// </summary>
      public IEnumerable<JobScoreLine> JobScoreLine { get; set; }
   }
}
