﻿// <copyright file="IJobSizeRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for job size repository
   /// </summary>
   public interface IJobSizeRepository
   {
      /// <summary>
      /// Get job size
      /// </summary>
      /// <returns>List of job size</returns>
      Task<IEnumerable<JobSizeModel>> GetJobSizes();
   }
}
