﻿// <copyright file="JobGradeFactorRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;

   /// <summary>
   /// Repository for job grade factor
   /// </summary>
   public class JobGradeFactorRepository : IJobGradeFactorRepository
   {
      private readonly IDocumentDBCollection<JobGradeFactorModel> documentDbJobGradeFactorCollection;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobGradeFactorRepository"/> class.
      /// </summary>
      /// <param name="settings">Settings</param>
      /// <param name="documentDbConnectionFactory">Document db connection factory</param>
      public JobGradeFactorRepository(IDocumentDBConnectionFactory documentDbConnectionFactory, IOptions<Settings> settings)
      {
         this.documentDbJobGradeFactorCollection = documentDbConnectionFactory.GetCollection<JobGradeFactorModel>(settings.Value.DocumentDBJobGradeFactorCollectionName);
      }

      /// <summary>
      /// Get job grade factor
      /// </summary>
      /// <returns>Job grade factor model</returns>
      public async Task<JobGradeFactorModel> GetJobGradeFactor()
      {
        return await this.documentDbJobGradeFactorCollection.FindOneAsync(FilterDefinition<JobGradeFactorModel>.Empty, null);
      }
   }
}
