// <copyright file="MultipleDBConnectionFactory.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core
{
   using Microsoft.Extensions.Options;
   using TSMT.Settings;

   /// <summary>
   /// Enum for which enterprise database to connect to
   /// </summary>
   public enum DatabaseConnectionType
   {
      /// <summary>
      /// ESTRNx
      /// </summary>
      ESTRN,

      /// <summary>
      /// TSTRNx
      /// </summary>
      TSTRN
   }

   /// <summary>
   /// JobScoring Connection Factory that can be configured to connect to either ESTRN or TSTRN
   /// </summary>
   public class MultipleDBConnectionFactory : DataAccess.Core.Infrastructure.ConnectionFactory
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="MultipleDBConnectionFactory"/> class.
      /// </summary>
      /// <param name="options">TSMTSettings</param>
      /// <param name="connectionType">Database type to connect to.</param>
      public MultipleDBConnectionFactory(IOptions<TSMTSettings> options, DatabaseConnectionType connectionType)
         : base(options, true, connectionType == DatabaseConnectionType.ESTRN ? options.Value.CloudDBConnectionString : options.Value.VPNDBConnectionString)
      {
      }
   }
}
