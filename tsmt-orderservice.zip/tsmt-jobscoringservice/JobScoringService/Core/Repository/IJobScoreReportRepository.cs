﻿// <copyright file="IJobScoreReportRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for job score report repository
   /// </summary>
   public interface IJobScoreReportRepository
   {
      /// <summary>
      /// Method to get maximum sequence number of specific table
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <param name="howManyToReserve">How many blocks of new IDs to reserve for a table</param>
      /// <returns>Maximum sequence number of specific table</returns>
      Task<int> GetSequenceNumber(string tableName, int howManyToReserve);

      /// <summary>
      /// Saving job score information
      /// </summary>
      /// <param name="jobScoreReport">Job score report</param>
      /// <returns>Returns true if data saved successfully else false</returns>
      bool SaveJobScoreDetails(JobScoreReport jobScoreReport);

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Retrieve list of job aggregated grade for unordered product for a given job id and bid alternate ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateIds">Bid alternate ids</param>
      /// <returns>Job aggregated grade list for unordered product</returns>
      Task<IEnumerable<JobAggregatedGrade>> GetJobAggregatedGradeListForUnorderedProduct(int jobId, IEnumerable<int> bidAlternateIds);
   }
}
