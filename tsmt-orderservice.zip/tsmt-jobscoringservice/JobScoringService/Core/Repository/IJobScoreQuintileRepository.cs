﻿// <copyright file="IJobScoreQuintileRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace JobScoringService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for job score quintile repository
   /// </summary>
   public interface IJobScoreQuintileRepository
   {
      /// <summary>
      /// Get job score quintiles
      /// </summary>
      /// <param name="salesOfficeCode">Sales office code to fetch quintiles for</param>
      /// <param name="productCodes">Product codes to fetch quintiles for</param>
      /// <returns>Enumeration of job score quintiles</returns>
      Task<IEnumerable<JobScoreQuintile>> GetJobScoreQuintiles(string salesOfficeCode, IEnumerable<string> productCodes);
   }
}
