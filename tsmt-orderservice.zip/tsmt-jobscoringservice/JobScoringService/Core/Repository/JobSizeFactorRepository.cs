﻿// <copyright file="JobSizeFactorRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;

   /// <summary>
   /// Repository for job size factor
   /// </summary>
   public class JobSizeFactorRepository : IJobSizeFactorRepository
   {
      private readonly IDocumentDBCollection<JobSizeFactorModel> documentDbJobSizeFactorCollection;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobSizeFactorRepository"/> class.
      /// </summary>
      /// <param name="settings">Settings</param>
      /// <param name="documentDbConnectionFactory">Document db connection factory</param>
      public JobSizeFactorRepository(IDocumentDBConnectionFactory documentDbConnectionFactory, IOptions<Settings> settings)
      {
         this.documentDbJobSizeFactorCollection = documentDbConnectionFactory.GetCollection<JobSizeFactorModel>(settings.Value.DocumentDBJobSizeFactorCollectionName);
      }

      /// <summary>
      /// Get job size factor
      /// </summary>
      /// <returns>Job size factor model</returns>
      public async Task<JobSizeFactorModel> GetJobSizeFactor()
      {
         return await this.documentDbJobSizeFactorCollection.FindOneAsync(FilterDefinition<JobSizeFactorModel>.Empty, null);
      }
   }
}
