﻿// <copyright file="IJobScoreRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ViewModels;

   /// <summary>
   /// Interface for Job Score database interactions
   /// </summary>
   public interface IJobScoreRepository
   {
      /// <summary>
      /// Get listing of recently transmitted sales orders which may require processing
      /// </summary>
      /// <returns>Collection of orders to consider as basis for grading</returns>
      Task<IEnumerable<SalesOrder>> GetNewTransmittedOrders();

      /// <summary>
      /// Delete all staging records for a given credit job
      /// </summary>
      /// <param name="hqtrCreditJobId">Hqtr Credit Job ID reference / parent key for sales orders</param>
      /// <returns>Task</returns>
      Task DeleteCreditJobFromStaging(int hqtrCreditJobId);

      /// <summary>
      /// Get listing of credit jobs that are candidates for a grading attempt
      /// </summary>
      /// <param name="maxNumRetries">Maximum number of allowable retries</param>
      /// <param name="minutesPauseBeforeRetryingCreditJob">Minutes to wait before retrying a credit job that recently failed</param>
      /// <returns>Collection of jobs to re-attempt grading process</returns>
      Task<IEnumerable<CreditJob>> GetCreditJobsToGrade(int maxNumRetries, int minutesPauseBeforeRetryingCreditJob);

      /// <summary>
      /// Create a new entry to track grading of a credit job
      /// </summary>
      /// <param name="drAddressId">Dr Address Id</param>
      /// <param name="jobId">Job Id</param>
      /// <param name="hqtrCreditJobId">Hqtr Credit Job Id</param>
      /// <param name="bidAlternateId">Bid Alternate Id</param>
      /// <param name="spaNumber">SPA (Special Pricing Authorization) Number</param>
      /// <returns>Task</returns>
      Task CreateCreditJobProcessEntry(int drAddressId, int jobId, int hqtrCreditJobId, int bidAlternateId, string spaNumber);

      /// <summary>
      /// Check if Credit Job has been created.
      /// </summary>
      /// <param name="hqtrCreditJobId">Hqtr Credit Job Id</param>
      /// <returns>TRUE - when credit job has been created for processing, but may not have been scored</returns>
      Task<bool> DoesCreditJobExist(int hqtrCreditJobId);

      /// <summary>
      /// Check if Credit Job has been successfully graded.
      /// </summary>
      /// <param name="hqtrCreditJobId">Hqtr Credit Job Id</param>
      /// <returns>TRUE - when credit job has been sucessfully graded</returns>
      Task<bool> HasCreditJobBeenGraded(int hqtrCreditJobId);

      /// <summary>
      /// Identify a credit job has been submitted for grading.
      /// </summary>
      /// <param name="hqtrCreditJobId">Hqtr Credit Job Id</param>
      /// <param name="retryCount">(optional) allow for tracking of number of retry attempts</param>
      /// <returns>Task indicating the record was successfully updated</returns>
      Task<bool> MarkCreditJobForProcessing(int hqtrCreditJobId, int retryCount = 0);

      /// <summary>
      /// Update credit job with results of successful scoring operation
      /// </summary>
      /// <param name="creditJobScore">View for credit job score</param>
      /// <returns>Task</returns>
      Task SetCreditJobScoreResult(CreditJobScoreProcessViewModel creditJobScore);

      /// <summary>
      /// Create new staging table entry
      /// </summary>
      /// <param name="so">record for insertion</param>
      /// <returns>Task</returns>
      Task CreateStagingEntry(SalesOrder so);

      /// <summary>
      /// Get a bid alternate by hqtr_bid_alternate_id
      /// </summary>
      /// <param name="drAddressId">Dr Address Id to honor for request</param>
      /// <param name="hqtrBidAlternateId">Enterprise / Hqtr Bid Alternate Id</param>
      /// <returns>Bid</returns>
      Task<Bid> GetBid(int drAddressId, int hqtrBidAlternateId);

      /// <summary>
      /// Get a job by hqtr_job_id
      /// </summary>
      /// <param name="drAddressId">Dr Address Id to honor for request</param>
      /// <param name="hqtrJobId">Enterprise / Hqtr Job Id</param>
      /// <returns>Bid</returns>
      Task<JobLookup> GetJob(int drAddressId, int hqtrJobId);

      /// <summary>
      /// Get the timestamp of the last record inserted into the process table.
      /// We'll use this to determine the last execution time and basis for looking for new orders.
      /// </summary>
      /// <returns>Timestamp of last execution</returns>
      Task<DateTime> GetLastExecution();

      /// <summary>
      /// Retrieve job aggregated grade for a given job id and bid alternate id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Job aggregated grade</returns>
      Task<JobAggregatedGrade> GetJobAggregatedGrade(int jobId, int bidAlternateId);

      /// <summary>
      /// Retrieve list of job aggregated grade for ordered product for a given job id and bid alternate ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateIds">Bid alternate ids</param>
      /// <returns>Job aggregated grade list for ordered product</returns>
      Task<IEnumerable<JobAggregatedGrade>> GetJobAggregatedGradeListForOrderedProduct(int jobId, IEnumerable<int> bidAlternateIds);
   }
}
