﻿// <copyright file="ExcludedProductCodeRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;

   /// <summary>
   /// Repository for excluded product code repository
   /// </summary>
   public class ExcludedProductCodeRepository : IExcludedProductCodeRepository
   {
      private readonly IDocumentDBCollection<ExcludedProductCode> documentDbCollection;

      /// <summary>
      /// Initializes a new instance of the <see cref="ExcludedProductCodeRepository"/> class.
      /// </summary>
      /// <param name="settings">Settings</param>
      /// <param name="documentDbConnectionFactory">Document db connection factory</param>
      public ExcludedProductCodeRepository(IDocumentDBConnectionFactory documentDbConnectionFactory, IOptions<Settings> settings)
      {
         this.documentDbCollection = documentDbConnectionFactory.GetCollection<ExcludedProductCode>(settings.Value.DocumentDBExcludedProductCodeCollectionName);
      }

      /// <summary>
      /// Get excluded product codes
      /// </summary>
      /// <returns>Excluded product codes</returns>
      public async Task<IEnumerable<ExcludedProductCode>> GetExcludedProductCodes()
      {
         return await this.documentDbCollection.FindAsync(FilterDefinition<ExcludedProductCode>.Empty, null);
      }
   }
}
