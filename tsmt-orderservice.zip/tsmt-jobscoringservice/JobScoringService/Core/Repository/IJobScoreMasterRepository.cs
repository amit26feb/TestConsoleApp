﻿// <copyright file="IJobScoreMasterRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   /// <summary>
   /// Interface for job score master repository
   /// </summary>
   public interface IJobScoreMasterRepository
   {
      /// <summary>
      /// Gets job grade factor
      /// </summary>
      IJobGradeFactorRepository JobGradeFactorRepository { get; }

      /// <summary>
      /// Gets excluded product code repository interface
      /// </summary>
      IExcludedProductCodeRepository ExcludedProductCodeRepository { get; }

      /// <summary>
      /// Gets job size
      /// </summary>
      IJobSizeRepository JobSizeRepository { get; }

      /// <summary>
      /// Gets job size factor
      /// </summary>
      IJobSizeFactorRepository JobSizeFactorRepository { get; }
   }
}
