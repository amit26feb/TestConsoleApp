﻿// <copyright file="JobSizeRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using DocumentDBWrapper;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.Services;
   using Microsoft.Extensions.Options;
   using MongoDB.Driver;

   /// <summary>
   /// Repository for job size
   /// </summary>
   public class JobSizeRepository : IJobSizeRepository
   {
      private readonly IDocumentDBCollection<JobSizeModel> documentDbJobSizeCollection;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobSizeRepository"/> class.
      /// </summary>
      /// <param name="settings">Settings</param>
      /// <param name="documentDbConnectionFactory">Document db connection factory</param>
      public JobSizeRepository(IDocumentDBConnectionFactory documentDbConnectionFactory, IOptions<Settings> settings)
      {
         this.documentDbJobSizeCollection = documentDbConnectionFactory.GetCollection<JobSizeModel>(settings.Value.DocumentDBJobSizeCollectionName);
      }

      /// <summary>
      /// Get job size
      /// </summary>
      /// <returns>List of job size</returns>
      public async Task<IEnumerable<JobSizeModel>> GetJobSizes()
      {
         IEnumerable<JobSizeModel> jobSizeList = await this.documentDbJobSizeCollection.FindAsync(FilterDefinition<JobSizeModel>.Empty);
         return jobSizeList;
      }
   }
}