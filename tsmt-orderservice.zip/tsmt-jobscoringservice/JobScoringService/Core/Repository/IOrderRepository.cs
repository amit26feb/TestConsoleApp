﻿// <copyright file="IOrderRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for Order database interactions
   /// </summary>
   public interface IOrderRepository
   {
      /// <summary>
      /// Get listing of recently transmitted sales orders which may require processing
      /// </summary>
      /// <param name="startDate">first date to consider for new orders</param>
      /// <returns>Collection of orders to consider as basis for grading</returns>
      Task<IEnumerable<EnterpriseSalesOrder>> GetNewTransmittedOrders(DateTime startDate);
   }
}
