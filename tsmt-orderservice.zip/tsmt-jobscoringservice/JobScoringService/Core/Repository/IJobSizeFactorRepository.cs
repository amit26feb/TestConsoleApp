﻿// <copyright file="IJobSizeFactorRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for job size factor repository
   /// </summary>
   public interface IJobSizeFactorRepository
   {
      /// <summary>
      /// Get job size factor
      /// </summary>
      /// <returns>Job size factor model</returns>
      Task<JobSizeFactorModel> GetJobSizeFactor();
   }
}
