﻿// <copyright file="IExcludedProductCodeRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace JobScoringService.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for excluded product code repository
   /// </summary>
   public interface IExcludedProductCodeRepository
   {
      /// <summary>
      /// Get excluded product codes
      /// </summary>
      /// <returns>Excluded product codes</returns>
      Task<IEnumerable<ExcludedProductCode>> GetExcludedProductCodes();
   }
}
