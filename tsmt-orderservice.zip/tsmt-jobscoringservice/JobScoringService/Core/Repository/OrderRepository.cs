﻿// <copyright file="OrderRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using Dapper;
   using JobScoringService.Common.Constants;
   using JobScoringService.Core.Models;
   using TSMT.DataAccess;

   /// <summary>
   /// Repository for Job Score operations on TSTRN data
   /// </summary>
   public class OrderRepository : IOrderRepository
   {
      /// <summary>
      /// Repository, defined as CreditJob to get configuration for ESTRN
      /// </summary>
      private readonly IRepository<EnterpriseSalesOrder> repository;

      /// <summary>
      /// Initializes a new instance of the <see cref="OrderRepository"/> class.
      /// </summary>
      /// <param name="repository">Repository</param>
      public OrderRepository(IRepository<EnterpriseSalesOrder> repository)
      {
         DefaultTypeMap.MatchNamesWithUnderscores = true;
         this.repository = repository;
         this.repository.HonorDrAddressId(-1);
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<EnterpriseSalesOrder>> GetNewTransmittedOrders(DateTime startDate)
      {
         var param = new
         {
            LAST_DATE = startDate,
         };

         return await this.repository.ExecuteListQuery<EnterpriseSalesOrder>(OrderQueries.GetNewOrders, param);
      }
   }
}
