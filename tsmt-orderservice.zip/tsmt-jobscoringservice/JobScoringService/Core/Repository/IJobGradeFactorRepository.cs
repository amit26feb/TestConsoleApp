﻿// <copyright file="IJobGradeFactorRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Interface for job grade factor repository
   /// </summary>
   public interface IJobGradeFactorRepository
   {
      /// <summary>
      /// Get job grade factor
      /// </summary>
      /// <returns>Job grade factor model</returns>
      Task<JobGradeFactorModel> GetJobGradeFactor();
   }
}
