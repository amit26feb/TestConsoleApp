﻿// <copyright file="JobScoreReportRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Linq;
   using System.Threading.Tasks;
   using Dapper;
   using DataAccess.Core.Abstractions;
   using JobScoringService.Common.Constants;
   using JobScoringService.Core.Models;
   using Microsoft.Extensions.Logging;
   using Oracle.ManagedDataAccess.Client;
   using TSMT.DataAccess;

   /// <summary>
   /// Repository for job score reporting
   /// </summary>
   public class JobScoreReportRepository : IJobScoreReportRepository
   {
      private readonly IRepository<JobScore> repository;
      private readonly ILogger<string> logger;
      private readonly IConnectionFactory connectionFactory;
      private IDbConnection connection;
      private IDbTransaction transaction;
      private int? drAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoreReportRepository"/> class.
      /// </summary>
      /// <param name="repository">Repository</param>
      /// <param name="logger">Instance of logger</param>
      /// <param name="connectionFactory">Instance of connection factory</param>
      public JobScoreReportRepository(IRepository<JobScore> repository, ILogger<string> logger, IConnectionFactory connectionFactory)
      {
         this.repository = repository;
         this.logger = logger;
         this.connectionFactory = connectionFactory;
      }

      /// <summary>
      /// Gets a database connection.
      /// Pays attention to a specific DrAddressId if we have been told to do so.
      /// </summary>
      private IDbConnection GetConnection
      {
         get
         {
            if (this.drAddressId.HasValue)
            {
               return this.connectionFactory.GetOpenConnectionForDrAddressId(this.drAddressId.Value);
            }

            return this.connectionFactory.GetConnection;
         }
      }

      /// <summary>
      /// Method to get maximum sequence number of specific table
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <param name="howManyToReserve">How many blocks of new IDs to reserve for a table</param>
      /// <returns>Maximum sequence number of specific table</returns>
      public async Task<int> GetSequenceNumber(string tableName, int howManyToReserve)
      {
         var param = new
         {
            TABLENAME = tableName,
            HOWMANYTORESERVE = howManyToReserve
         };
         int sequenceNumber = await this.repository.ExecuteQuery<int>(JobScoreQueries.GetSequenceNumberQuery, param);
         return sequenceNumber;
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         // Keep track of it, in case we have the ConnectionFactory generate a new connection in this repository.
         this.drAddressId = drAddressId;

         // Tell all IRepository instances about it.
         this.repository.HonorDrAddressId(drAddressId);
      }

      /// <summary>
      /// Saving job score information
      /// </summary>
      /// <param name="jobScoreReport">Job score report</param>
      /// <returns>Returns true if data saved successfully else false</returns>
      public bool SaveJobScoreDetails(JobScoreReport jobScoreReport)
      {
         using (this.connection = this.GetConnection)
         {
            using (this.transaction = this.connection.BeginTransaction())
            {
               try
               {
                  this.connection.ExecuteAsync(JobScoreQueries.JobScoreInsertQuery, jobScoreReport.JobScore);
                  this.BulkInsertJobEntities(jobScoreReport.JobScoreLine, JobScoreQueries.JobScoreLineInsertQuery);
                  this.transaction.Commit();
                  return true;
               }
               catch (Exception ex)
               {
                  this.logger.LogError(ex.Message);
                  this.transaction.Rollback();
                  return false;
               }
            }
         }
      }

      /// <summary>
      /// Retrieve list of job aggregated grade for unordered product for a given job id and bid alternate ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateIds">Bid alternate ids</param>
      /// <returns>Job aggregated grade list for unordered product</returns>
      public async Task<IEnumerable<JobAggregatedGrade>> GetJobAggregatedGradeListForUnorderedProduct(int jobId, IEnumerable<int> bidAlternateIds)
      {
         var param = new
         {
            JOB_ID = jobId,
            BID_ALTERNATE_IDS = bidAlternateIds
         };
         return await this.repository.GetListAsync<JobAggregatedGrade>(JobScoreQueries.GetJobAggregatedGradeForUnorderedProduct, param);
      }

      private void BulkInsertJobEntities(IEnumerable<object> insertData, string insertQuery)
      {
         if (insertData.Any())
         {
            using (var command = (OracleCommand)this.connection.CreateCommand())
            {
               command.CommandText = insertQuery;
               command.CommandType = CommandType.Text;
               command.ArrayBindCount = insertData.Count();
               command.BindByName = true;

               foreach (var prop in insertData.First().GetType().GetProperties())
               {
                  var data = insertData.Select(x => prop.GetValue(x) == null ? DBNull.Value : prop.GetValue(x)).ToArray();
                  var propType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                  if (propType == typeof(int))
                  {
                     command.Parameters.Add(":" + prop.Name, OracleDbType.Int64, data, ParameterDirection.Input);
                  }
                  else if (propType == typeof(DateTime))
                  {
                     command.Parameters.Add(":" + prop.Name, OracleDbType.Date, data, ParameterDirection.Input);
                  }
                  else if (propType == typeof(string))
                  {
                     command.Parameters.Add(":" + prop.Name, OracleDbType.Varchar2, data, ParameterDirection.Input);
                  }
                  else if (propType == typeof(double))
                  {
                     command.Parameters.Add(":" + prop.Name, OracleDbType.Double, data, ParameterDirection.Input);
                  }
                  else if (propType == typeof(decimal))
                  {
                     command.Parameters.Add(":" + prop.Name, OracleDbType.Decimal, data, ParameterDirection.Input);
                  }
                  else
                  {
                     this.logger.LogError($"Unknown data type of parameter is: {propType.ToString()}");
                  }
               }

               command.ExecuteNonQuery();
            }
         }
      }
   }
}
