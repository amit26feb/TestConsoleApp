﻿// <copyright file="JobScoreQuintileRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace JobScoringService.Core.Repository
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
    using DocumentDBWrapper;
    using JobScoringService.Core.Models;
    using JobScoringService.Core.Services;
    using Microsoft.Extensions.Options;
    using MongoDB.Driver;

   /// <summary>
   /// Repository for job score quintile
   /// </summary>
   public class JobScoreQuintileRepository : IJobScoreQuintileRepository
   {
      private readonly IDocumentDBCollection<JobScoreQuintile> documentDbCollection;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoreQuintileRepository"/> class.
      /// </summary>
      /// <param name="settings">Settings</param>
      /// <param name="documentDbConnectionFactory">Document db connection factory</param>
      public JobScoreQuintileRepository(IDocumentDBConnectionFactory documentDbConnectionFactory, IOptions<Settings> settings)
      {
         this.documentDbCollection = documentDbConnectionFactory.GetCollection<JobScoreQuintile>(settings.Value.DocumentDBScoreQuintileCollectionName);
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<JobScoreQuintile>> GetJobScoreQuintiles(string salesOfficeCode, IEnumerable<string> productCodes)
      {
         productCodes = productCodes.Select(pc => pc.TrimStart('0'));

         FilterDefinition<JobScoreQuintile> jobScoreQuintileFilter =
            Builders<JobScoreQuintile>.Filter.In(x => x.ProductCode, productCodes) &
            Builders<JobScoreQuintile>.Filter.Eq(x => x.Location, salesOfficeCode);

         return await this.documentDbCollection.FindAsync(jobScoreQuintileFilter);
      }
   }
}
