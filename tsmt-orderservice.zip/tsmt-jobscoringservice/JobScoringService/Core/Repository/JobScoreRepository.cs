﻿// <copyright file="JobScoreRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using Dapper;
   using JobScoringService.Common.Constants;
   using JobScoringService.Core.Models;
   using JobScoringService.Core.ViewModels;
   using TSMT.DataAccess;

   /// <summary>
   /// Repository for Job Score operations on TSTRN data
   /// </summary>
   public class JobScoreRepository : IJobScoreRepository
   {
      private readonly IRepository<SalesOrder> repository;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoreRepository"/> class.
      /// </summary>
      /// <param name="repository">Repository</param>
      public JobScoreRepository(IRepository<SalesOrder> repository)
      {
         DefaultTypeMap.MatchNamesWithUnderscores = true;
         this.repository = repository;
         this.repository.HonorDrAddressId(-1);
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<CreditJob>> GetCreditJobsToGrade(int maxNumRetries, int minutesPauseBeforeRetryingCreditJob)
      {
         var param = new
         {
            MAX_NUM_RETRIES = maxNumRetries,
            MINUTES_PAUSE = minutesPauseBeforeRetryingCreditJob,
         };

         return await this.repository.ExecuteListQuery<CreditJob>(JobScoreQueries.GetJobScorePendingProcess, param);
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<SalesOrder>> GetNewTransmittedOrders()
      {
         return await this.repository.ExecuteListQuery<SalesOrder>(JobScoreQueries.GetJobScoreStagingEntries);
      }

      /// <inheritdoc/>
      public async Task CreateCreditJobProcessEntry(int drAddressId, int jobId, int hqtrCreditJobId, int bidAlternateId, string spaNumber)
      {
         var param = new
         {
            DR_ADDRESS_ID = drAddressId,
            JOB_ID = jobId,
            HQTR_CREDIT_JOB_ID = hqtrCreditJobId,
            BID_ALTERNATE_ID = bidAlternateId,
            SPA_NUMBER = spaNumber,
         };

         int rowsCreated = await this.repository.ExecuteAsync<int>(JobScoreQueries.CreateProcessEntry, param);
         if (rowsCreated != 1)
         {
            throw new InvalidOperationException(
               string.Format(
                  "An unexpected number of rows were created during an operation. The expected count was 1; the actual count is {0} (HqtrCreditJob={1})",
                  rowsCreated,
                  hqtrCreditJobId));
         }
      }

      /// <inheritdoc/>
      public async Task<bool> DoesCreditJobExist(int hqtrCreditJobId)
      {
         var param = new
         {
            HQTR_CREDIT_JOB_ID = hqtrCreditJobId,
         };

         CreditJob result = await this.repository.GetAsync<CreditJob>(JobScoreQueries.GetCreditJobById, param);
         return result != null;
      }

      /// <inheritdoc/>
      public async Task<bool> HasCreditJobBeenGraded(int hqtrCreditJobId)
      {
         var param = new
         {
            HQTR_CREDIT_JOB_ID = hqtrCreditJobId,
         };

         CreditJob result = await this.repository.GetAsync<CreditJob>(JobScoreQueries.GetCreditJobById, param);
         return result != null && !string.IsNullOrWhiteSpace(result.LetterScore);
      }

      /// <inheritdoc/>
      public async Task<bool> MarkCreditJobForProcessing(int hqtrCreditJobId, int retryCount = 0)
      {
         var param = new
         {
            HQTR_CREDIT_JOB_ID = hqtrCreditJobId,
            RETRY_COUNT = retryCount,
         };

         int rowsUpdated = await this.repository.ExecuteAsync<int>(JobScoreQueries.MarkForProcessing, param);
         return rowsUpdated != 0;
      }

      /// <inheritdoc/>
      public async Task DeleteCreditJobFromStaging(int hqtrCreditJobId)
      {
         var param = new
         {
            HQTR_CREDIT_JOB_ID = hqtrCreditJobId,
         };

         int rowsDeleted = await this.repository.ExecuteAsync<int>(JobScoreQueries.DeleteFromStaging, param);
         if (rowsDeleted == 0)
         {
            throw new InvalidOperationException(
               string.Format(
                  "No rows were deleted during an operation. It was expected to delete one or more rows (HqtrCreditJob={0})",
                  hqtrCreditJobId));
         }
      }

      /// <summary>
      /// Record results of successful grade operation
      /// </summary>
      /// <param name="creditJobScore">View for credit job score</param>
      /// <returns>Task</returns>
      public async Task SetCreditJobScoreResult(CreditJobScoreProcessViewModel creditJobScore)
      {
         var param = new
         {
            HQTR_CREDIT_JOB_ID = creditJobScore.HqtrCreditJobId,
            LETTER_SCORE = creditJobScore.LetterScore,
            EXCLUDED_FROM_TOPPER = creditJobScore.ExcludedFromTopper ? "Y" : "N"
         };

         int rowsUpdated = await this.repository.ExecuteAsync<int>(JobScoreQueries.SetScoreResults, param);
         if (rowsUpdated != 1)
         {
            throw new InvalidOperationException(
               string.Format(
                  "An unexpected number of rows were modified during an operation. The expected count was 1; the actual count is {0} (HqtrCreditJob={1})",
                  rowsUpdated,
                  creditJobScore.HqtrCreditJobId));
         }
      }

      /// <inheritdoc/>
      public async Task CreateStagingEntry(SalesOrder so)
      {
         var param = new
         {
            SALES_ORDER_ID = so.SalesOrderId,
            DR_ADDRESS_ID = so.DrAddressId,
            HQTR_CREDIT_JOB_ID = so.HqtrCreditJobId,
            JOB_ID = so.JobId,
            BID_ALTERNATE_ID = so.BidAlternateId,
            SPA_NUMBER = so.SpaNumber
         };

         int rowsCreated = await this.repository.ExecuteAsync<int>(JobScoreQueries.CreateStageEntry, param);
         if (rowsCreated != 1)
         {
            throw new InvalidOperationException(
               string.Format(
                  "An unexpected number of rows were created during an operation. The expected count was 1; the actual count is {0} (HqtrSalesOrderId={1})",
                  rowsCreated,
                  so.SalesOrderId));
         }
      }

      /// <inheritdoc/>
      public async Task<Bid> GetBid(int drAddressId, int hqtrBidAlternateId)
      {
         var param = new
         {
            HQTR_BID_ALTERNATE_ID = hqtrBidAlternateId
         };

         this.repository.HonorDrAddressId(drAddressId);
         return await this.repository.GetAsync<Bid>(JobScoreQueries.GetBidAlternateByHqtrId, param);
      }

      /// <inheritdoc/>
      public async Task<JobLookup> GetJob(int drAddressId, int hqtrJobId)
      {
         var param = new
         {
            HQTR_JOB_ID = hqtrJobId
         };

         this.repository.HonorDrAddressId(drAddressId);
         return await this.repository.GetAsync<JobLookup>(JobScoreQueries.GetJobByHqtrId, param);
      }

      /// <inheritdoc/>
      public async Task<DateTime> GetLastExecution()
      {
         DateTime? result = await this.repository.ExecuteQuery<DateTime?>(JobScoreQueries.GetLastExecution);

         // one time only, the system won't have data
         return result ?? new DateTime(2020, 5, 18, 0, 0, 0, DateTimeKind.Utc);
      }

      /// <summary>
      /// Retrieve job aggregated grade for a given job id and bid alternate id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Job aggregated grade</returns>
      public async Task<JobAggregatedGrade> GetJobAggregatedGrade(int jobId, int bidAlternateId)
      {
         var param = new
         {
            JOB_ID = jobId,
            BID_ALTERNATE_ID = bidAlternateId
         };

         return await this.repository.GetAsync<JobAggregatedGrade>(JobScoreQueries.GetJobAggregatedGrade, param);
      }

      /// <summary>
      /// Retrieve list of job aggregated grade for ordered product for a given job id and bid alternate ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateIds">Bid alternate ids</param>
      /// <returns>Job aggregated grade list for ordered product</returns>
      public async Task<IEnumerable<JobAggregatedGrade>> GetJobAggregatedGradeListForOrderedProduct(int jobId, IEnumerable<int> bidAlternateIds)
      {
         var param = new
         {
            JOB_ID = jobId,
            BID_ALTERNATE_IDS = bidAlternateIds
         };
         return await this.repository.GetListAsync<JobAggregatedGrade>(JobScoreQueries.GetJobAggregatedGradeForOrderedProduct, param);
      }
   }
}
