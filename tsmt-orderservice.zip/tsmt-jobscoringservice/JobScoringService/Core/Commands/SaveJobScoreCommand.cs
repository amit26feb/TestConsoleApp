﻿// <copyright file="SaveJobScoreCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Commands
{
   using System.Runtime.Serialization;
   using JobScoringService.Core.Models;
   using MediatR;

   /// <summary>
   /// Command to save job score data
   /// </summary>
   [DataContract]
   public class SaveJobScoreCommand : IRequest<bool>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="SaveJobScoreCommand"/> class.
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="jobGraderResponse">Response which needs to be saved</param>
      public SaveJobScoreCommand(int jobId, int bidAlternateId, JobGraderResponse jobGraderResponse)
      {
         this.JobId = jobId;
         this.BidAlternateId = bidAlternateId;
         this.JobGraderResponse = jobGraderResponse;
      }

      /// <summary>
      /// Gets job grader response
      /// </summary>
      [DataMember]
      public JobGraderResponse JobGraderResponse { get; private set; }

      /// <summary>
      /// Gets or sets gets job id
      /// </summary>
      [DataMember]
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets gets bid alternate id
      /// </summary>
      [DataMember]
      public int BidAlternateId { get; set; }
   }
}
