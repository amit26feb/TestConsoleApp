﻿// <copyright file="SaveJobScoreCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.Validators
{
    using FluentValidation;
    using JobScoringService.Core.Commands;

   /// <summary>
   /// Validates the command for updating task
   /// </summary>
   public class SaveJobScoreCommandValidator : AbstractValidator<SaveJobScoreCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="SaveJobScoreCommandValidator"/> class.
      /// </summary>
      public SaveJobScoreCommandValidator()
      {
         this.RuleFor(command => command.JobGraderResponse.JobLineItems).NotEmpty().WithMessage("Line Item Response cannot be empty");
         this.RuleFor(command => command.JobId).NotEqual(0).WithMessage("Job Id must not be 0");
         this.RuleFor(command => command.BidAlternateId).NotEqual(0).WithMessage("Bid Alternate Id must not be 0");
      }
   }
}
