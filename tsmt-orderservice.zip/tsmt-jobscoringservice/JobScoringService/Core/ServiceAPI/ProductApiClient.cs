﻿// <copyright file="ProductApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Collections.Generic;
   using System.Net.Http;
   using System.Text;
   using System.Threading.Tasks;
   using JobScoringService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
   using Newtonsoft.Json;
   using TSMT.ApiClient;

   /// <summary>
   /// API client for product service
   /// </summary>
   public class ProductApiClient : IProductApiClient
   {
      private readonly IApiHttpClient httpClient;
      private readonly ILogger<ProductApiClient> logger;

      /// <summary>
      /// Initializes a new instance of the <see cref="ProductApiClient"/> class.
      /// </summary>
      /// <param name="productServiceUrl">Product service url</param>
      /// <param name="httpClient">Http client used to make api calls</param>
      /// <param name="logger">Logger for http errors</param>
      public ProductApiClient(string productServiceUrl, IApiHttpClient httpClient, ILogger<ProductApiClient> logger)
      {
         httpClient.SetBaseAddress(productServiceUrl);
         this.httpClient = httpClient;
         this.httpClient.AddClientCredentialAuthorizationToken();
         this.logger = logger;
      }

      /// <summary>
      /// Gets the product code details
      /// </summary>
      /// <param name="productCodeFilter">Product code filter values</param>
      /// <returns>Product code details</returns>
      public async Task<IEnumerable<ProductCodeViewModel>> GetProductCodes(ProductCodeFilterViewModel productCodeFilter)
      {
         string uri = "ProductData/ProductCodes";
         var payload = JsonConvert.SerializeObject(productCodeFilter);
         HttpResponseMessage response = await this.httpClient.PostAsync(uri, new StringContent(payload, Encoding.UTF8, "application/json"));
         if (response.IsSuccessStatusCode)
         {
            return await response.Content.ReadAsAsync<IEnumerable<ProductCodeViewModel>>();
         }
         else
         {
            this.logger.LogError($"In {nameof(this.GetProductCodes)}, POST against [{uri}] returned status code [{response.StatusCode}] reason [{response.ReasonPhrase}] instead of success status code.");
            return null;
         }
      }
   }
}
