﻿// <copyright file="JobsApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Collections.Generic;
   using System.Net.Http;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using Microsoft.Extensions.Logging;
   using TSMT.ApiClient;
   using TSMT.ApiClient.Services;

   /// <summary>
   /// Api Client for Job Service
   /// </summary>
   public class JobsApiClient : IJobsApiClient
   {
      private readonly IApiHttpClient httpClient;
      private readonly IOktaTokenService oktaTokenService;
      private readonly ILogger<JobsApiClient> logger;
      private bool hasEnsuredAuthorization = false;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobsApiClient"/> class.
      /// </summary>
      /// <param name="jobServiceUrl">Job service url</param>
      /// <param name="httpClient">httpClient used to make API calls</param>
      /// <param name="oktaTokenService">service that can provide valid application tokens for authentication against the API</param>
      /// <param name="logger">The class logger</param>
      public JobsApiClient(string jobServiceUrl, IApiHttpClient httpClient, IOktaTokenService oktaTokenService, ILogger<JobsApiClient> logger)
      {
         this.logger = logger;
         this.httpClient = httpClient;
         this.oktaTokenService = oktaTokenService;
         httpClient.SetBaseAddress(jobServiceUrl);
      }

      /// <inheritdoc/>
      public async Task EnsureAuthorization()
      {
         string authToken = await this.oktaTokenService.GetAccessToken();
         this.httpClient.AddAuthorization(authToken);

         this.hasEnsuredAuthorization = true;
      }

      /// <inheritdoc/>
      public async Task<Job> GetJob(int drAddressId, int jobId)
      {
         await this.AuthorizeIfNotAlreadyAuthorized();

         string uri = $"{drAddressId}/jobs/{jobId}";
         HttpResponseMessage response = await this.httpClient.GetAsync(uri);

         if (response.IsSuccessStatusCode)
         {
            return await response.Content.ReadAsAsync<Job>();
         }
         else
         {
            this.logger.LogError($"In {nameof(this.GetJob)}, GET against [{uri}] returned status code [{response.StatusCode}] instead of success status code.");
            return null;
         }
      }

      /// <inheritdoc/>
      public async Task<SalesOffice> GetSalesOffice(int salesOfficeId)
      {
         await this.AuthorizeIfNotAlreadyAuthorized();

         string uri = $"TraneSalesBusinessData/SalesOffice/{salesOfficeId}";
         HttpResponseMessage response = await this.httpClient.GetAsync(uri);

         if (response.IsSuccessStatusCode)
         {
            return await response.Content.ReadAsAsync<SalesOffice>();
         }
         else
         {
            this.logger.LogError($"In {nameof(this.GetSalesOffice)}, GET against [{uri}] returned status code [{response.StatusCode}] instead of success status code.");
            return null;
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<CommissionCode>> GetCommissionCodes(int salesOfficeId)
      {
         await this.AuthorizeIfNotAlreadyAuthorized();

         string uri = $"TraneSalesBusinessData/{salesOfficeId}/CommissionCodes";
         HttpResponseMessage response = await this.httpClient.GetAsync(uri);

         if (response.IsSuccessStatusCode && response.Content != null)
         {
            return await response.Content.ReadAsAsync<IEnumerable<CommissionCode>>();
         }
         else
         {
            this.logger.LogError($"In {nameof(this.GetCommissionCodes)}, GET against [{uri}] returned status code [{response.StatusCode}] instead of success status code.");
            return null;
         }
      }

      /// <summary>
      /// If we haven't yet ensured authorization, make sure the underlying HTTP client has a proper (non-expired) authorization header.
      /// </summary>
      /// <returns>Task</returns>
      private async Task AuthorizeIfNotAlreadyAuthorized()
      {
         if (!this.hasEnsuredAuthorization)
         {
            await this.EnsureAuthorization();
         }
      }
   }
}
