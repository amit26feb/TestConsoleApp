﻿// <copyright file="IJobGraderApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Api Client for Job Grader Service
   /// </summary>
   public interface IJobGraderApiClient
   {
      /// <summary>
      /// Grades job, given the request payload
      /// </summary>
      /// <param name="jobGraderRequest">Job grader request</param>
      /// <returns>Job grader response</returns>
      Task<JobGraderResponse> GradeJob(JobGraderRequest jobGraderRequest);
   }
}
