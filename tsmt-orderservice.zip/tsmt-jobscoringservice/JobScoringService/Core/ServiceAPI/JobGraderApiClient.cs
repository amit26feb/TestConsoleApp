﻿// <copyright file="JobGraderApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System;
   using System.Net.Http;
   using System.Text;
   using System.Threading.Tasks;
   using JobScoringService.Common.BasicAuthApiClient;
   using JobScoringService.Core.Models;
   using Microsoft.Extensions.Logging;
   using Newtonsoft.Json;

   /// <summary>
   /// Api Client for Job Grader Service
   /// </summary>
   public class JobGraderApiClient : IJobGraderApiClient
   {
      private readonly IBasicAuthApiHttpClient httpClient;
      private readonly ILogger<JobGraderApiClient> logger;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobGraderApiClient"/> class.
      /// </summary>
      /// <param name="jobGraderServiceUrl">The job grader API service base URL</param>
      /// <param name="basicAuthUsername">The job grader API basic auth username</param>
      /// <param name="basicAuthPassword">The job grader API basic auth password</param>
      /// <param name="httpClient">httpClient used to make API calls, utilizing basic auth</param>
      /// <param name="logger">The class logger</param>
      public JobGraderApiClient(string jobGraderServiceUrl, string basicAuthUsername, string basicAuthPassword, IBasicAuthApiHttpClient httpClient, ILogger<JobGraderApiClient> logger)
      {
         this.logger = logger;
         this.httpClient = httpClient;
         this.httpClient.BaseAddress = new Uri(jobGraderServiceUrl);
         this.httpClient.SetBasicAuthParameters(basicAuthUsername, basicAuthPassword);
      }

      /// <inheritdoc/>
      public async Task<JobGraderResponse> GradeJob(JobGraderRequest jobGraderRequest)
      {
         string uri = "score";
         HttpResponseMessage response = await this.httpClient.PostAsync(uri, new StringContent(JsonConvert.SerializeObject(jobGraderRequest), Encoding.UTF8, "application/json"));

         if (response.IsSuccessStatusCode)
         {
            return await response.Content.ReadAsAsync<JobGraderResponse>();
         }
         else
         {
            string error = $"In GradeJob, POST against base address '{this.httpClient.BaseAddress?.ToString() ?? "Null"}' and URI '{uri}' returned status code '{response.StatusCode}' instead of success status code.";

            // The response content may contain additional details about an error.
            try
            {
               string responseContent = await response.Content.ReadAsStringAsync();
               if (!string.IsNullOrEmpty(responseContent))
               {
                  error += " Response: " + responseContent;
               }
            }
            catch
            {
               // We don't want to raise a ruckus if an exception occurs while trying to gather more detail about an error.
            }

            this.logger.LogError(error);
            return null;
         }
      }
   }
}
