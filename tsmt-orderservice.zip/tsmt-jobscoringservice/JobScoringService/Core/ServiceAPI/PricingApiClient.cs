﻿// <copyright file="PricingApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System;
   using System.Net.Http;
   using System.Threading.Tasks;
   using System.Web;
   using JobScoringService.Core.Models;
   using TSMT.ApiClient;

   /// <summary>
   /// API client for pricing service
   /// </summary>
   public class PricingApiClient : IPricingApiClient
   {
      private readonly IApiHttpClient httpClient;

      /// <summary>
      /// Initializes a new instance of the <see cref="PricingApiClient"/> class.
      /// </summary>
      /// <param name="pricingServiceUrl">Pricing service url</param>
      /// <param name="httpClient">Http client used to make api calls</param>
      public PricingApiClient(string pricingServiceUrl, IApiHttpClient httpClient)
      {
         httpClient.SetBaseAddress(pricingServiceUrl);
         this.httpClient = httpClient;
         this.httpClient.AddClientCredentialAuthorizationToken();
      }

      /// <summary>
      /// Get job score quintile
      /// </summary>
      /// <param name="productCode">Product code</param>
      /// <param name="salesOfficeCode">Sales office code</param>
      /// <param name="jobSize">Job size</param>
      /// <returns>Job score quintile</returns>
      public async Task<JobScoreQuintile> GetJobScoreQuintile(string productCode, string salesOfficeCode, string jobSize)
      {
         string requestUrl = "ScoreQuintile";
         if (!string.IsNullOrWhiteSpace(productCode) && !string.IsNullOrWhiteSpace(salesOfficeCode) && !string.IsNullOrWhiteSpace(jobSize))
         {
            string productCodeUrl = Uri.EscapeDataString(productCode);
            string salesOfficeCodeUrl = Uri.EscapeDataString(salesOfficeCode);
            string jobSizeUrl = Uri.EscapeDataString(jobSize);
            requestUrl = requestUrl + $"?productCode={productCodeUrl}&salesOfficeCode={salesOfficeCodeUrl}&jobSize={jobSizeUrl}";
            HttpResponseMessage response = await this.httpClient.GetAsync(requestUrl);
            if (response.IsSuccessStatusCode && response.Content != null)
            {
               return await response.Content.ReadAsAsync<JobScoreQuintile>();
            }
         }

         return null;
      }
   }
}
