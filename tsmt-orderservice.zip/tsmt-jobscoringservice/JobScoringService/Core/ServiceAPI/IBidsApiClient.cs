﻿// <copyright file="IBidsApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Api Client for Bid Service
   /// </summary>
   public interface IBidsApiClient
   {
      /// <summary>
      /// Ensures underlying HTTP client has a proper (non-expired) authorization header.
      /// </summary>
      /// <returns>Task</returns>
      Task EnsureAuthorization();

      /// <summary>
      /// Get a bid by bid alternate id
      /// </summary>
      /// <param name="drAddressId">Dr Address id</param>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid Alternate id</param>
      /// <returns>bid</returns>
      Task<Bid> GetBidAsync(int drAddressId, int jobId, int bidAlternateId);
   }
}
