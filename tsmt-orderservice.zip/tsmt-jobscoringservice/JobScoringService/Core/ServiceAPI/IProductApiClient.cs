﻿// <copyright file="IProductApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.ViewModels;

   /// <summary>
   /// API client for product service
   /// </summary>
   public interface IProductApiClient
   {
      /// <summary>
      /// Gets the product code details
      /// </summary>
      /// <param name="productCodeFilter">Product code filter values</param>
      /// <returns>Product code details</returns>
      Task<IEnumerable<ProductCodeViewModel>> GetProductCodes(ProductCodeFilterViewModel productCodeFilter);
   }
}