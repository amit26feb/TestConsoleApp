﻿// <copyright file="SalesRollupApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System;
   using System.Net.Http;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;
   using Microsoft.Extensions.Logging;
   using TSMT.ApiClient;
   using TSMT.ApiClient.Services;

   /// <summary>
   /// Api Client for Sales Rollup Service
   /// </summary>
   public class SalesRollupApiClient : ISalesRollupApiClient
   {
      private readonly IApiHttpClient httpClient;
      private readonly IOktaTokenService oktaTokenService;
      private readonly ILogger<SalesRollupApiClient> logger;
      private bool hasEnsuredAuthorization = false;

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesRollupApiClient"/> class.
      /// </summary>
      /// <param name="salesRollupServiceUrl">The sales rollup service base URL</param>
      /// <param name="httpClient">httpClient used to make API calls</param>
      /// <param name="oktaTokenService">service that can provide valid application tokens for authentication against the API</param>
      /// <param name="logger">The class logger</param>
      public SalesRollupApiClient(string salesRollupServiceUrl, IApiHttpClient httpClient, IOktaTokenService oktaTokenService, ILogger<SalesRollupApiClient> logger)
      {
         this.logger = logger;
         this.httpClient = httpClient;
         this.oktaTokenService = oktaTokenService;
         this.httpClient.SetBaseAddress(salesRollupServiceUrl);
      }

      /// <inheritdoc/>
      public async Task EnsureAuthorization()
      {
         string authToken = await this.oktaTokenService.GetAccessToken();
         this.httpClient.AddAuthorization(authToken);

         this.hasEnsuredAuthorization = true;
      }

      /// <inheritdoc/>
      public async Task<SalesRollup> GetRollupData(int drAddressId, int jobId, int bidId, SalesRollupType rollupType)
      {
         await this.AuthorizeIfNotAlreadyAuthorized();

         string uri = $"{drAddressId}/Jobs/{jobId}/SalesRollup/{rollupType}?bidId={bidId}&calculatePricingPolicy=false";
         HttpResponseMessage response = await this.httpClient.GetAsync(uri);

         if (response.IsSuccessStatusCode)
         {
            return await response.Content.ReadAsAsync<SalesRollup>();
         }
         else
         {
            this.logger.LogError($"In {nameof(this.GetRollupData)}, GET against [{uri}] returned status code [{response.StatusCode}] reason [{response.ReasonPhrase}] instead of success status code.");
            return null;
         }
      }

      /// <summary>
      /// If we haven't yet ensured authorization, make sure the underlying HTTP client has a proper (non-expired) authorization header.
      /// </summary>
      /// <returns>Task</returns>
      private async Task AuthorizeIfNotAlreadyAuthorized()
      {
         if (!this.hasEnsuredAuthorization)
         {
            await this.EnsureAuthorization();
         }
      }
   }
}
