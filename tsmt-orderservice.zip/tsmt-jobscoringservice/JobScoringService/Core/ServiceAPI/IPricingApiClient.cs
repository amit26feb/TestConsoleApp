﻿// <copyright file="IPricingApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// API client for pricing service
   /// </summary>
   public interface IPricingApiClient
   {
      /// <summary>
      /// Get job score quintile
      /// </summary>
      /// <param name="productCode">Product code</param>
      /// <param name="salesOfficeCode">Sales office code</param>
      /// <param name="jobSize">Job size</param>
      /// <returns>Job score quintile</returns>
      Task<JobScoreQuintile> GetJobScoreQuintile(string productCode, string salesOfficeCode, string jobSize);
   }
}
