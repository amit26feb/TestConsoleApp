﻿// <copyright file="IJobsApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Api Client for Job Service
   /// </summary>
   public interface IJobsApiClient
   {
      /// <summary>
      /// Ensures underlying HTTP client has a proper (non-expired) authorization header.
      /// </summary>
      /// <returns>Task</returns>
      Task EnsureAuthorization();

      /// <summary>
      /// Get job
      /// </summary>
      /// <param name="drAddressId">Dr address id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Job</returns>
      Task<Job> GetJob(int drAddressId, int jobId);

      /// <summary>
      /// Get Sales Office
      /// </summary>
      /// <param name="salesOfficeId">SalesOfficeId</param>
      /// <returns>Sales Office</returns>
      Task<SalesOffice> GetSalesOffice(int salesOfficeId);

      /// <summary>
      /// Gets the commission codes for a sales office
      /// </summary>
      /// <param name="salesOfficeId">salesOfficeId</param>
      /// <returns>IEnumerable of commission codes</returns>
      Task<IEnumerable<CommissionCode>> GetCommissionCodes(int salesOfficeId);
   }
}
