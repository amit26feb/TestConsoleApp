﻿// <copyright file="ISalesRollupApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobScoringService.Core.ServiceAPI
{
   using System.Threading.Tasks;
   using JobScoringService.Core.Models;

   /// <summary>
   /// Api Client for Sales Rollup Service
   /// </summary>
   public interface ISalesRollupApiClient
   {
      /// <summary>
      /// Ensures underlying HTTP client has a proper (non-expired) authorization header.
      /// </summary>
      /// <returns>Task</returns>
      Task EnsureAuthorization();

      /// <summary>
      /// Gets sales rollup data for a job and bid
      /// </summary>
      /// <param name="drAddressId">The dr address ID</param>
      /// <param name="jobId">The job ID</param>
      /// <param name="bidId">The bid ID</param>
      /// <param name="rollupType">Type of rollup to return</param>
      /// <returns>Sales rollup data</returns>
      Task<SalesRollup> GetRollupData(int drAddressId, int jobId, int bidId, SalesRollupType rollupType);
   }
}
