// <copyright file="LoggerMiddlewareTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Common.Filters
{
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using JobService.Common.Middlewares;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// LoggerMiddlewareTest
    /// </summary>
    public class LoggerMiddlewareTest
    {
        private readonly Mock<LoggerMiddleware> loggerMock;
        private readonly Mock<HttpRequest> requestMock;
        private readonly Mock<ILogger<LoggerMiddleware>> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggerMiddlewareTest"/> class.
        /// LoggerMiddleware
        /// </summary>
        public LoggerMiddlewareTest()
        {
            this.loggerMock = new Mock<LoggerMiddleware>();
            this.requestMock = new Mock<HttpRequest>();
            this.logger = new Mock<ILogger<LoggerMiddleware>>();
        }

        /// <summary>
        /// It_Should_Log_Request
        /// </summary>
        [Fact]

        public async Task It_Should_Log_Request()
        {
            this.requestMock.Setup(x => x.Scheme).Returns("http");
            this.requestMock.Setup(x => x.Host).Returns(new HostString("localhost"));
            this.requestMock.Setup(x => x.Path).Returns(new PathString("/test"));
            this.requestMock.Setup(x => x.PathBase).Returns(new PathString("/"));
            this.requestMock.Setup(x => x.Method).Returns("GET");
            this.requestMock.Setup(x => x.Body).Returns(new MemoryStream());
            this.requestMock.Setup(x => x.QueryString).Returns(new QueryString("?param1=1"));
            var contextMock = new Mock<HttpContext>();
            contextMock.Setup(x => x.Response.Body).Returns(new MemoryStream());
            contextMock.Setup(x => x.Request).Returns(this.requestMock.Object);
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "user")
            };
            contextMock.Setup(x => x.User.Claims).Returns(claims);
            var loggerMiddlewar = new LoggerMiddleware(next: (innerHttpContext) => Task.FromResult(0), logger: this.logger.Object);
            await loggerMiddlewar.Invoke(contextMock.Object);

            Assert.NotNull(contextMock);
            this.requestMock.Verify();
        }
    }
}
