// <copyright file="StartupTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Common.Filters
{
    using System;
    using System.Diagnostics;
    using App.Metrics;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting.Internal;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.ObjectPool;
    using Moq;
    using Xunit;

    /// <summary>
    /// StartupTest
    /// </summary>
    public class StartupTest
    {
        private readonly Mock<IWebHostEnvironment> env;

        public StartupTest()
        {
            this.env = new Mock<IWebHostEnvironment>();
        }

        [Fact]
        public void ConfigureServices_RegistersDependenciesCorrectly()
        {
            // Arrange
            var mockEnvironment = new Mock<IWebHostEnvironment>();
            mockEnvironment
                .Setup(m => m.EnvironmentName)
                .Returns("Hosting:UnitTestEnvironment");
            Mock<ILoggerFactory> logger = new Mock<ILoggerFactory>();
            Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
            configurationStub.Setup(x => x[It.IsAny<string>()]).Returns("https://domain.account.com/");

            IServiceCollection services = new ServiceCollection();
            var target = new Startup(configurationStub.Object, mockEnvironment.Object, logger.Object);

            // Act
            target.ConfigureServices(services);

            // Mimic internal asp.net core logic.
            services.AddTransient<Controllers.JobsController>();

            // Assert
            var serviceProvider = services.BuildServiceProvider();
            Assert.NotNull(serviceProvider);
        }

        [Fact]
        public void Configure_Success()
        {
            // Arrange
            var mockEnvironment = new Mock<IWebHostEnvironment>();
            mockEnvironment
                .Setup(m => m.EnvironmentName)
                .Returns("Hosting:UnitTestEnvironment");
            Mock<ILoggerFactory> logger = new Mock<ILoggerFactory>();

            Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
            configurationStub.Setup(x => x["OktaDomain"]).Returns("https://domain.account.com/");
            IServiceCollection services = new ServiceCollection();
            var target = new Startup(configurationStub.Object, mockEnvironment.Object, logger.Object);

            // Mimic internal asp.net core logic.
            services.AddTransient<Controllers.JobsController>();
            services.AddMvc();
            services.AddLogging();
            services.AddRouting();
            services.AddSingleton<ObjectPoolProvider, DefaultObjectPoolProvider>();
            var diagnosticSource = new DiagnosticListener("Microsoft.AspNet");
            services.AddSingleton<DiagnosticSource>(diagnosticSource);
            var metrics = AppMetrics.CreateDefaultBuilder()

                                   .Configuration.Configure(
                                       options =>
                                       {
                                           options.AddEnvTag("DEV");
                                       })
                                     .Report.ToInfluxDb(options =>
                                     {
                                         options.InfluxDb.BaseUri = new Uri("https://trane.okta.com/");
                                         options.InfluxDb.Database = "testDb";
                                         options.InfluxDb.UserName = "testUser";
                                         options.InfluxDb.Password = "testPw";
                                         options.InfluxDb.CreateDataBaseIfNotExists = true;
                                     }).Build();
            services.AddMetrics(metrics);
            services.AddMetricsReportingHostedService();
            services.AddMetricsEndpoints();
            services.AddMetricsTrackingMiddleware();

            // Assert
            var serviceProvider = services.BuildServiceProvider();
            IApplicationBuilder app = new ApplicationBuilder(serviceProvider);

            // Act
            target.Configure(app, mockEnvironment.Object);

            Assert.NotNull(app);
        }
    }
}
