// <copyright file="HttpGlobalExceptionFilterTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Common.Filters
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using JobService.Common.Exceptions;
    using JobService.Common.Filters;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Abstractions;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.AspNetCore.Routing;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// HttpGlobalExceptionFilterTest
    /// </summary>
    public class HttpGlobalExceptionFilterTest
    {
        private readonly Mock<IWebHostEnvironment> env;
        private readonly Mock<ILogger<HttpGlobalExceptionFilter>> logger;
        private readonly Mock<List<IFilterMetadata>> filterMetadata;
        private HttpGlobalExceptionFilter httpGlobalFilter;

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpGlobalExceptionFilterTest"/> class.
        /// HttpGlobalExceptionFilterTest
        /// </summary>
        public HttpGlobalExceptionFilterTest()
        {
            this.env = new Mock<IWebHostEnvironment>();
            this.logger = new Mock<ILogger<HttpGlobalExceptionFilter>>();
            this.filterMetadata = new Mock<List<IFilterMetadata>>();
        }

        [Fact]
        public void OnException_InternalServerError_Success()
        {
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);

            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new Exception()
            };

            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.InternalServerError, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        [Fact]
        public void OnException_BadRequest_Success()
        {
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);

            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new JobMaintenanceDomainException("test validation", new FluentValidation.ValidationException("test"))
            };

            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        [Fact]
        public void OnException_ExceptionMessage_Success()
        {
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var httpContext = new DefaultHttpContext();
            var innerException = new ArgumentException("Invalid Argument");
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new JobMaintenanceDomainException("Exception", innerException)
            };

            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        [Fact]
        public void OnException_InnerException_Success()
        {
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var httpContext = new DefaultHttpContext();
            var innerException = new FluentValidation.ValidationException("message");
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new JobMaintenanceDomainException("InnerException", innerException)
            };

            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }
    }
}
