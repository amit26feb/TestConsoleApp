// <copyright file="Helper.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Common
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using JobService.Core.Models;
    using JobService.Core.ViewModels;

    /// <summary>
    /// Helper class includes the methods that can be commonly used across the test project
    /// </summary>
    public static class Helper
    {
        /// <summary>
        /// Gets job's data for coordination
        /// </summary>
        /// <returns>Job's data for coordination</returns>
        public static JobCoordinationAggregateViewModel GetJobDataForCoordination()
        {
            return new JobCoordinationAggregateViewModel
            {
                JobCoordinationGeneralInfo = new JobGeneralInfoViewModel()
                {
                    CommissionCode = "CM10",
                    IcsJobIndicator = "Y",
                    JobContact = "CCFGBHL",
                    QuickTurnaroundIndicator = "N",
                    RequestedDate = DateTime.Now.Date,
                    CrmOpportunityId = "1811024",
                    PricingSpaNumber = "12-345"
                },
                JobNotes = new JobNotesView()
                {
                    JobId = 555,
                    NoteString = "Checking Job Notes for Coordination"
                },
                CoordinationData = new JobCoordinationHistoryViewModel()
                {
                    CommissionCode = "CM10",
                    IcsJobIndicator = "Y",
                    RequestedDate = DateTime.Now.Date,
                    QuickTurnaroundIndicator = "Y",
                    JobContact = "CCFGBHL",
                    BillOfMaterials = new List<JobCoordinationBillOfMaterialViewModel>()
                    {
                        new JobCoordinationBillOfMaterialViewModel()
                        {
                            BidAlternateId = 123,
                            ProductFamilyId = 8764,
                            ShipQuarter = 2,
                            ShipYear = 2012,
                            Competitor = "abc",
                            SpecifiedUser = "def",
                            SelectionIds = new List<int> { 1, 2 },
                            Description = "test"
                        }
                    },
                    BidDetails = new List<JobCoordinationBidViewModel>()
                    {
                         new JobCoordinationBidViewModel()
                         {
                            BidAlternateId = 1234,
                            BidAlternateName = "abc"
                         }
                    },
                    SubmissionNotes = "This is submission notes",
                    Documents = new List<JobCoordinationDocumentViewModel>()
                    {
                        new JobCoordinationDocumentViewModel()
                        {
                            DocumentKey = "Jobs/78/27440/new 8.txt"
                        }
                    }
                }
            };
        }

        /// <summary>
        /// Gets job's general information for coordination
        /// </summary>
        /// <returns>Job's general information  for coordination</returns>
        public static JobGeneralInfoModel GetJobGeneralInfoForCoordination()
        {
            return new JobGeneralInfoModel()
            {
                COMM_CODE = "CM10",
                ICS_IND = "N",
                JOB_CONTACT = "CCFGBHL",
                QUICK_TURNAROUND_IND = "Y",
                CJ_DATE = Convert.ToDateTime("09/09/2200"),
                CRM_OPPORTUNITY_ID = "1811024",
                PRICING_SPA_NBR = "12-2345"
            };
        }

        /// <summary>
        /// Gets job's general information view model
        /// </summary>
        /// <returns>Job's general information view model</returns>
        public static JobGeneralInfoViewModel GetJobGeneralInfoViewModel()
        {
            return new JobGeneralInfoViewModel()
            {
                CommissionCode = "CM10",
                IcsJobIndicator = "Y",
                JobContact = "CCFGBHL",
                QuickTurnaroundIndicator = "N",
                RequestedDate = Convert.ToDateTime("09/09/2200"),
                CrmOpportunityId = "1811024",
                PricingSpaNumber = "12-2345"
            };
        }

        /// <summary>
        /// Gets job notes for coordination
        /// </summary>
        /// <returns>Job notes for coordination</returns>
        public static JobNotes GetJobNotes()
        {
            return new JobNotes()
            {
                JOB_ID = 555,
                NOTE_LINE = "Checking Job Notes for Coordination"
            };
        }

        /// <summary>
        /// Gets job info view model
        /// </summary>
        /// <param name="jobId">ID of the job</param>
        /// <returns>Job info view model</returns>
        public static JobInfoViewModel GetJobInfoViewModel(int jobId)
        {
            return new JobInfoViewModel
            {
                JobId = jobId,
                JobName = "Job",
                UserId = "cczpvr",
                DateCreated = DateTime.Now,
                InsertDate = DateTime.Now,
                Status = "ABC",
                LastUpdate = DateTime.Now,
                JobSource = "ghj",
                OriginatingDrAddress = 1,
                CheckedIn = "y",
                DomesticInternationlInd = "jkl",
                DistanceToJob = 25,
                CommCode = "bnm",
                SalesOfficeId = 2,
                LocationOffice = 1,
                CustChannelId = "1",
                Foe2CreatedOrdersInd = "6",
                CrmOpportunityId = "4",
                CoordinatedInd = 0
            };
        }

        /// <summary>
        /// Gets list of job classfications
        /// </summary>
        /// <param name="jobId">ID of the job</param>
        /// <returns>List of job classifications</returns>
        public static IEnumerable<JobClassificationView> GetAllJobClassificationViews(int jobId)
        {
            return new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = jobId,
                    JobClassId = 123,
                    DescriptionValues = "Purchaser Class",
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 111,
                            Description = "Controls Subcontractor"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 222,
                            Description = "Service Subcontractor"
                        }
                    }
                },
                new JobClassificationView()
                {
                    JobId = jobId,
                    JobClassId = 456,
                    DescriptionValues = "Building Class",
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 555,
                            Description = "Industrial"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 666,
                            Description = "Hospital"
                        }
                    }
                }
            };
        }

        /// <summary>
        /// Gets the job coordination history view model
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="coordinationId">Coordination id</param>
        /// <param name="coordinationStatus">Coordination status</param>
        /// <returns>Job coordination history view model</returns>
        public static JobCoordinationHistoryViewModel GetJobCoordinationHistoryViewModel(int jobId, int coordinationId, string coordinationStatus)
        {
            return new JobCoordinationHistoryViewModel()
            {
                JobId = jobId,
                CoordinationStatus = coordinationStatus,
                CoordinationId = coordinationId,
                BidDetails = Helper.GetJobDataForCoordination().CoordinationData.BidDetails
            };
        }

        /// <summary>
        /// Gets the job coordination history
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="coordinationId">Coordination id</param>
        /// <param name="coordinationStatus">Coordination status</param>
        /// <returns>Job coordination history</returns>
        public static JobCoordinationHistory GetJobCoordinationHistory(int jobId, int coordinationId, string coordinationStatus)
        {
            return new JobCoordinationHistory()
            {
                JOB_ID = jobId,
                COORDINATION_STATUS = coordinationStatus,
                COORDINATION_ID = coordinationId
            };
        }

        /// <summary>
        /// Gets the job coordination history
        /// </summary>
        /// <returns>Job coordination history</returns>
        public static JobCoordinationHistory GetJobCoordinationHistory()
        {
            return new JobCoordinationHistory()
            {
                COORDINATION_STATUS = "Not Submitted",
                REQUESTED_DATE = DateTime.Now.Date,
                ICS_JOB_INDICATOR = "N",
                QUICK_TURNAROUND_IND = "N",
                JOB_CONTACT = "CCFGBHL",
                COMMISSION_CODE = "CM10",
                CREATED_ON = DateTime.Now,
                COORDINATION_JOB_SUB_NOTES = Encoding.ASCII.GetBytes("This is submission notes"),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'JOB_ID': 12,
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PROD_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR': 2,
                                                                    'CJ_SHIP_YEAR': 2012,
                                                                    'CJ_COMPETITOR': 'abc',
                                                                    'CJ_SPECIFIED': 'def',
                                                                    'SELECTION_IDS': [1, 2, 3],
                                                                    'DESCRIPTION': 'test'
                                                                    }
                                                                 ]"),
                COORDINATION_JOB_BIDS = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID'     : 1234,
                                                                    'BID_ALTERNATE_NAME'   : 'abc'
                                                                    }
                                                                  ]"),
                COORDINATION_JOB_DOCUMENTS = Encoding.ASCII.GetBytes(@"[
                                                                        {
                                                                        'JOB_DOCUMENT_ID':123,
                                                                        'DOCUMENT_KEY':'Jobs/78/27440/new 8.txt',
                                                                        'DOCUMENT_NAME':'new 8.txt',
                                                                        'DOCUMENT_UPDATE_STATUS':'Insertion',
                                                                        'NOTES':'test document',
                                                                        'UPLOADED_USER_ID': 'abcd'
                                                                        }
                                                                       ]")
            };
        }

        /// <summary>
        /// Gets job coordination contact details
        /// </summary>
        /// <returns>Job coordination contact details</returns>
        public static JobCoordinationContactDetails GetJobCoordinationContactDetails()
        {
            return new JobCoordinationContactDetails()
            {
                COMM_CODE = "qwe",
                JOB_CONTACT = "rty"
            };
        }

        /// <summary>
        /// Gets job coordination general information view model
        /// </summary>
        /// <returns>Job coordination general information view model</returns>
        public static JobCoordinationGeneralInfoViewModel GetJobCoordinationGeneralInfoViewModel()
        {
            return new JobCoordinationGeneralInfoViewModel()
            {
                CommissionCode = "B10WER",
                IsIcsJob = true,
                IsQuickTurnaroundRequired = true,
                JobContact = "uyt",
                RequestedDate = DateTime.Now
            };
        }

        /// <summary>
        /// Gets job coordination request view model
        /// </summary>
        /// <returns>Job coordination request view model</returns>
        public static JobCoordinationRequestViewModel GetJobCoordinationRequestViewModel()
        {
            return new JobCoordinationRequestViewModel()
            {
                CoordinationId = 1,
                DrAddressId = 10,
                JobId = 12,
                MessageId = Guid.NewGuid().ToString(),
                UserId = "qwer",
                CreatedDateTime = "24/01/2020",
                StatusUpdatedDateTime = "24/01/2020",
                Signature = "wer-jrti",
                Status = MTopssMessages.Pending.ToString()
            };
        }

        /// <summary>
        /// Gets coordinated job message
        /// </summary>
        /// <returns>Coordinated job message</returns>
        public static CoordinatedJobMessage GetCoordinatedJobMessage()
        {
            return new CoordinatedJobMessage()
            {
                DrAddressId = 10,
                JobId = 12,
                MessageId = Guid.NewGuid().ToString(),
                UserId = "qwer",
                CreatedDateTime = "24/01/2020",
                StatusUpdatedDateTime = "24/01/2020",
                Signature = "wer-jrti",
                Status = MTopssMessages.Pending.ToString()
            };
        }

        /// <summary>
        /// Gets job coordination document message
        /// </summary>
        /// <returns>Job coordination document message</returns>
        public static JobCoordinationDocumentMessage GetJobCoordinationDocumentMessage()
        {
            return new JobCoordinationDocumentMessage()
            {
                DrAddressId = 101,
                JobId = 123,
                MessageId = Guid.NewGuid().ToString(),
                UserId = "qwer",
                CreatedDateTime = "24/01/2020",
                StatusUpdatedDateTime = "24/01/2020",
                Signature = "wer-jrti",
                Status = "Pending",
                DocumentKey = "abs/fewe/jirh.txt"
            };
        }

        /// <summary>
        /// Gets coordinated job document view model
        /// </summary>
        /// <returns>Coordinated job document view model</returns>
        public static CoordinatedJobDocumentViewModel GetCoordinatedJobDocumentViewModel()
        {
            return new CoordinatedJobDocumentViewModel()
            {
                JobId = 1234,
                DrAddressId = 101,
                DocumentKey = "Jobs/test1/test.txt",
                DocumentName = "test",
                IsForInsert = true,
                JobDocumentId = 12,
                Notes = "To test document update",
                UploadedDate = DateTime.Now
            };
        }

        /// <summary>
        /// Gets the job coordination document view model
        /// </summary>
        /// <param name="jobDocumentId">Job document id</param>
        /// <param name="documentKey">Document key</param>
        /// <param name="documentUpdateStatus">Document update status which indicates if the document has to be inserted/deleted</param>
        /// <returns>Job coordination document view model</returns>
        public static JobCoordinationDocumentViewModel GetJobCoordinationDocumentViewModel(int jobDocumentId, string documentKey, string documentUpdateStatus)
        {
            return new JobCoordinationDocumentViewModel()
            {
                JobDocumentId = jobDocumentId,
                DocumentKey = documentKey,
                DocumentName = "new 8.txt",
                DocumentUpdateStatus = documentUpdateStatus,
                Notes = "test doc",
                UploadedDate = DateTime.Now,
                UploadedUserId = "test"
            };
        }

        /// <summary>
        /// Get submission notes
        /// </summary>
        /// <returns>Submission notes</returns>
        public static byte[] GetSubmissionNotes()
        {
            return Encoding.UTF8.GetBytes("This is a test");
        }

        /// <summary>
        /// Gets selection price protection detail view model
        /// </summary>
        /// <param name="selectionId">Selection id</param>
        /// <param name="salesOrderId">Sales order id</param>
        /// <returns>Selection price protection detail view model</returns>
        public static SelectionPriceProtectionDetailViewModel GetSelectionPriceProtectionDetailViewModel(int selectionId, int? salesOrderId)
        {
            return new SelectionPriceProtectionDetailViewModel()
            {
                SelectionId = selectionId,
                SalesOrderId = salesOrderId
            };
        }

        /// <summary>
        /// Gets selection price protection detail
        /// </summary>
        /// <param name="selectionId">Selection id</param>
        /// <param name="salesOrderId">Sales order id</param>
        /// <returns>Selection price protection detail</returns>
        public static SelectionPriceProtectionDetail GetSelectionPriceProtectionDetail(int selectionId, int? salesOrderId)
        {
            return new SelectionPriceProtectionDetail()
            {
                SELECTION_ID = selectionId,
                SALES_ORD_ID = salesOrderId
            };
        }

        /// <summary>
        /// Gets favorite job record
        /// </summary>
        /// <returns>Favorite job record</returns>
        public static FavoriteJobViewModel GetFavoriteJobRecord()
        {
            return new FavoriteJobViewModel()
            {
                JobId = 12,
                UserId = "testuser",
                DrAddressId = 101
            };
        }

        /// <summary>
        /// Gets favorite job model record
        /// </summary>
        /// <returns>Favorite job model record</returns>
        public static FavoriteJob GetFavoriteJobModelRecord()
        {
            return new FavoriteJob()
            {
                JobId = 12,
                UserId = "testuser",
                DrAddressId = 101
            };
        }

        /// <summary>
        /// Gets the classification view model
        /// </summary>
        /// <returns>Classification view model</returns>
        public static ClassificationViewModel GetClassificationViewModel()
        {
            return new ClassificationViewModel()
            {
                JobClassId = 1,
                Description = "test a",
                Codes = new List<CodeViewModel>()
                {
                    new CodeViewModel()
                    {
                        JobCodeId = 10,
                        Description = "test 1"
                    }
                }
            };
        }

        /// <summary>
        /// Gets the classification
        /// </summary>
        /// <returns>Classification</returns>
        public static Classification GetClassification()
        {
            return new Classification()
            {
                JOB_CLASS_ID = 1,
                JOB_CLASS_DESCRIPTION = "test a",
                JOB_CODE_ID = 10,
                JOB_CODE_DESCRIPTION = "test 1"
            };
        }

        /// <summary>
        /// Gets the job system type
        /// </summary>
        /// <returns>Job system type</returns>
        public static JobSystemType GetJobSystemType()
        {
            return new JobSystemType()
            {
                SYS_TYPE_ID = 1,
                DESCRIPTION = "test",
                MULTI_SELECT = "Y",
                TOOL_TIP = "test data"
            };
        }

        /// <summary>
        /// Gets non oracle sales office
        /// </summary>
        /// <returns>Sales office</returns>
        public static SalesOffice NonOracleSalesOffice()
        {
            return new SalesOffice()
            {
                Sales_office_id = 77,
                Sales_office_code = "A7",
                Sales_office_name = "Test",
                Sales_district = "S1",
                Sales_office_id_parent = 0,
                STREET_ADDRESS_1 = "Address1",
                STREET_ADDRESS_2 = "Address2",
                CITY = "Dallas",
                STATE_CODE = "TX",
                PROVINCE = null,
                ZIP_CODE = "11111",
                ZIP_PLUS = null,
                Country = "USA",
                PHONE_NBR = "11111111",
                FAX_NBR = "111111111",
                NON_US_POSTAL_CODE = null,
                ORACLE_PROJECT_IND = null
            };
        }

        /// <summary>
        /// Gets oracle sales office
        /// </summary>
        /// <returns>Sales office</returns>
        public static SalesOffice OracleSalesOffice()
        {
            return new SalesOffice()
            {
                Sales_office_id = 77,
                Sales_office_code = "A7",
                Sales_office_name = "Test",
                Sales_district = "S1",
                Sales_office_id_parent = 0,
                STREET_ADDRESS_1 = "Address1",
                STREET_ADDRESS_2 = "Address2",
                CITY = "Dallas",
                STATE_CODE = "TX",
                PROVINCE = null,
                ZIP_CODE = "11111",
                ZIP_PLUS = null,
                Country = "USA",
                PHONE_NBR = "11111111",
                FAX_NBR = "111111111",
                NON_US_POSTAL_CODE = null,
                ORACLE_PROJECT_IND = 'Y'
            };
        }

        /// <summary>
        /// Gets the job system type view model
        /// </summary>
        /// <returns>Job system type view model</returns>
        public static JobSystemTypeViewModel GetJobSystemTypeViewModel()
        {
            return new JobSystemTypeViewModel()
            {
                SystemTypeId = 1,
                Description = "test",
                IsMultiSelectable = true,
                ToolTip = "test data"
            };
        }

        /// <summary>
        /// Gets the crm site details
        /// </summary>
        /// <returns>Crm site details</returns>
        public static CrmSiteModel GetCrmSiteModel()
        {
            return new CrmSiteModel()
            {
                SITE_NAME = "CRM Site",
                STREET_ADDRESS_1 = "Test Address 1",
                STREET_ADDRESS_2 = "Test Address 2",
                STREET_ADDRESS_3 = "Test Address 3",
                STREET_ADDRESS_4 = "Test Address 4",
                TOTAL_COUNT = 1,
                NAME = "Test Company Name",
                PHONE_NBR = "12345678"
            };
        }

        /// <summary>
        /// Gets the crm site details view model
        /// </summary>
        /// <returns>Crm site details view model</returns>
        public static CrmSiteViewModel GetCrmSiteViewModel()
        {
            return new CrmSiteViewModel()
            {
                SiteName = "CRM Site",
                StreetAddress1 = "Test Address 1",
                StreetAddress2 = "Test Address 2",
                StreetAddress3 = "Test Address 3",
                StreetAddress4 = "Test Address 4",
                TotalCount = 1,
                CompanyName = "Test Company Name",
                PhoneNumber = "12345678"
            };
        }

        /// <summary>
        /// Gets the sales customer with addresses
        /// </summary>
        /// <returns>Sales customer with addresses</returns>
        public static IEnumerable<SalesCustomerWithAddress> GetSalesCustomersWithAddresses()
        {
            return new List<SalesCustomerWithAddress>()
            {
                new SalesCustomerWithAddress()
                {
                    NAME = "Ircon",
                    CUST_ACCT_NBR = "S67BD",
                    CUST_CREDIT_CATG_CODE = "CT",
                    SALES_CUST_ID = 12,
                    STREET_ADDRESS_1 = "2639 VIKING WAY",
                    STREET_ADDRESS_2 = "SUITE 145",
                    PROVINCE = "QC",
                    COUNTRY = "CAN",
                    CITY = "CANADA",
                    NON_US_POSTAL_CODE = "A1A 0A1",
                    COUNTY_NAME = "DANE"
                },
                new SalesCustomerWithAddress()
                {
                    NAME = "Ircon",
                    CUST_ACCT_NBR = "S67BD",
                    CUST_CREDIT_CATG_CODE = "CT",
                    SALES_CUST_ID = 12,
                    STREET_ADDRESS_1 = "2639 VIKING WAY",
                    STREET_ADDRESS_2 = "SUITE 145",
                    STATE = "GSO",
                    COUNTRY = "USA",
                    CITY = "RICHMOND",
                    ZIP_CODE = "20850",
                    NON_US_POSTAL_CODE = "L4V 1H3",
                    COUNTY_NAME = "DANE"
                }
            };
        }

        /// <summary>
        /// Method to get custom senders using dr address id
        /// </summary>
        /// <param name="drAddressId">Dr address id</param>
        /// <returns>IEnumerable of custom sender view model</returns>
        public static IEnumerable<CustomSenderViewModel> GetCustomSenderViewModels(int drAddressId)
        {
            return new List<CustomSenderViewModel>()
            {
                new CustomSenderViewModel()
                {
                    CustomSenderId = "45LF",
                    CustomSenderNickName = "Jay",
                    SenderName = "JayRam",
                    Title = "EqvProposal",
                    CellPhoneNumber = "345897766",
                    EmailAddress = "Jay@Trane.com",
                    JobDrAddressId = drAddressId,
                    CustomSenderDrAddressId = 102,
                    OfficePhoneNumber = "9878987690",
                    OfficeFaxNumber = "45633",
                    CreatedBy = "ccghrn",
                    LastModifiedBy = "cccgth"
                },
                new CustomSenderViewModel()
                {
                    CustomSenderId = "46TY",
                    CustomSenderNickName = "Ravi",
                    SenderName = "RaviKrishna",
                    Title = "EqvProposal",
                    CellPhoneNumber = "903458977",
                    EmailAddress = "RaviKrishna@Trane.com",
                    JobDrAddressId = drAddressId,
                    CustomSenderDrAddressId = 102,
                    OfficePhoneNumber = "457898760",
                    OfficeFaxNumber = "21234",
                    CreatedBy = "ccghrn",
                    LastModifiedBy = "cccgth"
                }
            };
        }

        /// <summary>
        /// Method to get custom senders using dr address id
        /// </summary>
        /// <param name="drAddressId">Dr address id</param>
        /// <returns>IEnumerable of custom sender model</returns>
        public static IEnumerable<CustomSenderModel> GetCustomSenderModels(int drAddressId)
        {
            return new List<CustomSenderModel>()
            {
                new CustomSenderModel()
                {
                    CustomSenderId = "ER45",
                    CustomSenderNickName = "Jay",
                    SenderName = "JayRam",
                    Title = "EqvProposal",
                    CellPhoneNumber = "345897766",
                    EmailAddress = "Jay@Trane.com",
                    JobDrAddressId = drAddressId,
                    CustomSenderDrAddressId = 102,
                    CustomSenderSalesOfficeId = null,
                    OfficePhoneNumber = "9878987690",
                    OfficeFaxNumber = "45633",
                    CreatedBy = "ccghrn",
                    LastModifiedBy = "cccgth",
                    CreatedDate = DateTime.Now
                },
                new CustomSenderModel()
                {
                    CustomSenderId = "DF46",
                    CustomSenderNickName = "Ravi",
                    SenderName = "RaviKrishna",
                    Title = "EqvProposal",
                    CellPhoneNumber = "903458977",
                    EmailAddress = "RaviKrishna@Trane.com",
                    JobDrAddressId = drAddressId,
                    CustomSenderDrAddressId = 102,
                    CustomSenderSalesOfficeId = null,
                    OfficePhoneNumber = "457898760",
                    OfficeFaxNumber = "21234",
                    CreatedBy = "ccghrn",
                    LastModifiedBy = "cccgth",
                    CreatedDate = DateTime.Now
                },
                 new CustomSenderModel()
                {
                    CustomSenderId = "AF46",
                    CustomSenderNickName = "rico",
                    SenderName = "UncleRico",
                    Title = "EqvProposal",
                    CellPhoneNumber = "6088675309",
                    EmailAddress = "football@overthattharmountain.com",
                    JobDrAddressId = drAddressId,
                    CustomSenderDrAddressId = null,
                    CustomSenderSalesOfficeId = 155,
                    OfficePhoneNumber = "6088675310",
                    OfficeFaxNumber = "5555555555",
                    CreatedBy = "cczpvr",
                    LastModifiedBy = "cczpvr",
                    CreatedDate = DateTime.Now
                }
            };
        }

        /// <summary>
        /// Method to get custom sender detail using custom sender id
        /// </summary>
        /// <param name="customSenderId">Custom sender id in document db</param>
        /// <returns>Custom sender model</returns>
        public static CustomSenderModel GetCustomSenderModel(string customSenderId)
        {
            return new CustomSenderModel()
            {
                CustomSenderId = customSenderId,
                CustomSenderNickName = "Jay",
                SenderName = "JayRam",
                Title = "EqvProposal",
                CellPhoneNumber = "345897766",
                EmailAddress = "Jay@Trane.com",
                JobDrAddressId = 101,
                CustomSenderDrAddressId = 102,
                CustomSenderSalesOfficeId = 103,
                OfficePhoneNumber = "9878987690",
                OfficeFaxNumber = "45633",
                CreatedBy = "ccghrn",
                LastModifiedBy = "cccgth",
                CreatedDate = DateTime.Now
            };
        }

        /// <summary>
        /// Method to get custom sender detail using custom sender id
        /// </summary>
        /// <param name="customSenderId">Custom sender id in document db</param>
        /// <returns>Custom sender view model</returns>
        public static CustomSenderViewModel GetCustomSenderViewModel(string customSenderId)
        {
            return new CustomSenderViewModel()
            {
                CustomSenderId = customSenderId,
                CustomSenderNickName = "Jay",
                SenderName = "JayRam",
                Title = "EqvProposal",
                CellPhoneNumber = "345897766",
                EmailAddress = "Jay@Trane.com",
                JobDrAddressId = 101,
                CustomSenderDrAddressId = 102,
                CustomSenderSalesOfficeId = 103,
                OfficePhoneNumber = "9878987690",
                OfficeFaxNumber = "45633",
                CreatedBy = "ccghrn",
                LastModifiedBy = "cccgth",
                CreatedDate = DateTime.Now
            };
        }

        /// <summary>
        /// Gets custom sender view model
        /// </summary>
        /// <returns>Custom sender view model</returns>
        public static CustomSenderViewModel GetCustomSenderViewModel()
        {
            return new CustomSenderViewModel()
            {
                CustomSenderNickName = "Frost",
                SenderName = "Micheal Frost",
                Title = "Abc",
                CellPhoneNumber = "9876543210",
                EmailAddress = "michealfrost@xyz.com",
                JobDrAddressId = 101,
                CustomSenderDrAddressId = 102,
                CustomSenderSalesOfficeId = 103,
                OfficePhoneNumber = "6128617232",
                OfficeFaxNumber = "6128617827",
                CreatedBy = "ccghrn",
                LastModifiedBy = "cccgth",
                CreatedDate = DateTime.Now,
                LastModifiedDate = DateTime.Now
            };
        }

        /// <summary>
        /// Gets custom sender model
        /// </summary>
        /// <returns>Custom sender model</returns>
        public static CustomSenderModel GetCustomSenderModel()
        {
            return new CustomSenderModel()
            {
                CustomSenderNickName = "James",
                SenderName = "James Bond",
                Title = "Xyz",
                CellPhoneNumber = "9874563210",
                EmailAddress = "jamesbond@xyz.com",
                JobDrAddressId = 101,
                CustomSenderDrAddressId = 102,
                CustomSenderSalesOfficeId = 103,
                OfficePhoneNumber = "6128617232",
                OfficeFaxNumber = "6128617827",
                CreatedBy = "ccghrn",
                LastModifiedBy = "cccgth",
                CreatedDate = DateTime.Now,
                LastModifiedDate = DateTime.Now
            };
        }

        /// <summary>
        /// Gets customer list
        /// </summary>
        /// <returns>Customer list</returns>
        public static IEnumerable<CustomerViewModel> GetCustomerList()
        {
            return new List<CustomerViewModel>
            {
                new CustomerViewModel()
                {
                    SalesCustId = 124,
                    FirstName = "Jack",
                    CustomerName = "Air Controls Co. Inc.",
                    Address = "2115 2nd Ave North BILLINGS MT USA",
                    CommCode = "E72",
                    CustAcctNbr = null,
                    TotalCount = 1
                },
                new CustomerViewModel()
                {
                    SalesCustId = 124,
                    FirstName = "Tesla",
                    CustomerName = "Air Co. Inc.",
                    Address = "test Ave USA",
                    CommCode = "E70",
                    CustAcctNbr = "A1015C",
                    TotalCount = 1
                }
            };
        }

        /// <summary>
        /// Gets customer list with null customer account number
        /// </summary>
        /// <returns>Customer list with null customer account number</returns>
        public static IEnumerable<CustomerViewModel> GetCustomerListWithNullCustomerAccountNumber()
        {
            return new List<CustomerViewModel>
            {
                new CustomerViewModel()
                {
                    SalesCustId = 124,
                    FirstName = "Jack",
                    CustomerName = "Air Controls Co. Inc.",
                    Address = "2115 2nd Ave North BILLINGS MT USA",
                    CommCode = "E72",
                    CustAcctNbr = null,
                    TotalCount = 1,
                    CrmCompanyId = "10065"
                }
            };
        }

        /// <summary>
        /// Gets revenue stream model
        /// </summary>
        /// <returns>Revenue stream model</returns>
        public static RevenueStreamModel GetRevenueStreamModel()
        {
            return new RevenueStreamModel()
            {
                RevenueStreamFieldValue = "CSNG",
                Description = "Contracting - CS No Guarantee"
            };
        }

        /// <summary>
        /// Gets revenue stream view model
        /// </summary>
        /// <returns>Revenue stream view model</returns>
        public static RevenueStreamViewModel GetRevenueStreamViewModel()
        {
            return new RevenueStreamViewModel()
            {
                FieldValue = "CSNG",
                Description = "Contracting - CS No Guarantee"
            };
        }

        /// <summary>
        /// Gets the program view model
        /// </summary>
        /// <returns>Program view model</returns>
        public static ProgramViewModel GetProgram()
        {
            return new ProgramViewModel()
            {
                ProgramCode = "TECH",
                ProgramDescription = "Design Build",
            };
        }

        /// <summary>
        /// Gets the Program model
        /// </summary>
        /// <returns>Program model</returns>
        public static Program GetProgramModel()
        {
            return new Program()
            {
                ProgramCode = "TECH",
                ProgramDescription = "Design Build",
            };
        }

        /// <summary>
        /// Gets the site contact view model
        /// </summary>
        /// <returns>site contact view model</returns>
        public static SiteContactViewModel GetSiteContact()
        {
            return new SiteContactViewModel()
            {
                LastName = "Taylor",
                FirstName = "Lascone",
                PhoneNumber = "4135890515",
                EmailAddress = "Taylor.Iascone@newbury.edu",
                ContactId = 1,
                SalesOfficeName = "Billings",
                TotalCount = 1,
                CompanyName = "Test Company Name",
                StreetAddress1 = "Test Address 1",
                StreetAddress2 = "Test Address 2",
                CrmContactId = "12345",
            };
        }

        /// <summary>
        /// Gets the site contact model
        /// </summary>
        /// <returns>site contact model</returns>
        public static SiteContact GetSiteContactModel()
        {
            return new SiteContact()
            {
                LAST_NAME = "Taylor",
                FIRST_NAME = "Lascone",
                PHONE_NBR = "4135890515",
                EMAIL_ADDRESS = "Taylor.Iascone@newbury.edu",
                SITE_CONTACT_ID = 1,
                SALES_OFFICE_NAME = "Billings",
                TOTAL_COUNT = 1,
                NAME = "Test Company Name",
                STREET_ADDRESS_1 = "Test Address 1",
                STREET_ADDRESS_2 = "Test Address 2",
                CRM_CONTACT_ID = "12345",
            };
        }

        /// <summary>
        /// Gets the job basic info model
        /// </summary>
        /// <returns>job basic info model</returns>
        public static JobBasicInfo GetJobBasicInfoModel()
        {
            return new JobBasicInfo()
            {
                JOB_NAME = "UR Tacoma 9916853",
                SALES_OFFICE_NAME = "Billings",
                HQTR_JOB_ID = 89765,
                STREET_ADDRESS_1 = "2222 32nd Street South",
                STREET_ADDRESS_2 = "28",
                CITY = "BRAMPTON",
                PRICING_SPA_NBR = "15-49954",
                PROVINCE = "AB",
                DOMESTIC_INTERNATIONL_IND = "I",
                ORACLE_PROJECT_IND = "Y",
                JOB_CONTACT = "ctlsar",
                STATUS = "P",
                LOST_TO_COMPETITOR = null,
            };
        }

        /// <summary>
        /// Gets document folder view model
        /// </summary>
        /// <returns>Document folder view model</returns>
        public static DocumentFolderViewModel GetDocumentFolderViewModel()
        {
            return new DocumentFolderViewModel()
            {
                FolderName = "45678",
                JobFolderTypeId = JobFolderTypes.NonTrane,
                SectionName = "NonTrane",
                DocTypeId = 1,
            };
        }

        /// <summary>
        /// Gets document folder model
        /// </summary>
        /// <returns>Document folder model</returns>
        public static DocumentFolderModel GetDocumentFolderModel()
        {
            return new DocumentFolderModel()
            {
                FOLDER_ID = 1,
                FOLDER_NAME = "NonTrane",
                FOLDER_PARENT_ID = 2,
                JOB_FOLDER_TYPE_ID = JobFolderTypes.NonTrane,
                JOB_ID = 12345,
                CREATED_BY_USER = "Test",
                LAST_MODIFIED_DATE = DateTime.Now,
                CREATED_DATE = DateTime.Now,
                DOC_TYPE_ID = null,
                FOLDER_SOURCE = "Test",
                LAST_MODIFIED_USER = "Test"
            };
        }

        /// <summary>
        /// Gets document view model
        /// </summary>
        /// <returns>Document view model</returns>
        public static JobDocumentView GetDocumentViewModel()
        {
            return new JobDocumentView()
            {
                JobId = 1234,
                UploadedUserId = "Test",
            };
        }

        /// <summary>
        /// Gets the crm job create view
        /// </summary>
        /// <returns>Job create view</returns>
        public static CrmJobViewModel GetCrmJobViewModel()
        {
            return new CrmJobViewModel()
            {
                JobId = 0,
                OpportunityName = "TestCrmJob",
                CommCode = "DCO",
                CheckedIn = "y",
                UserId = "CCPLF",
                JobContact = "CCFBD",
                OpportunityId = "63912",
                SalesOfficeId = 122,
                LocationOfficeId = 122,
                PersonId = "H45",
                Company = "TC",
                RevenueStream = "TRS",
                ParentIndustryVerticalMarket = "1229",
                BoDOnControls = "1223",
                BoDOnEquipment = "1225",
                Currency = "TC",
                BusinessUnit = "TCS",
                Status = "TS",
                JobSeqNumber = "12121",
                PriorCodes = new List<SystemViewModel>()
                {
                    new SystemViewModel()
                    {
                        System = "2",
                    }
                },
                ClassificationList = new List<JobClassificationView>()
                {
                    new JobClassificationView()
                    {
                        JobCodeId = 54,
                        ClassificationDescription = "Service Contractor"
                    },
                    new JobClassificationView()
                    {
                        JobCodeId = 18,
                        ClassificationDescription = "Office/warehouses"
                    }
                },
                JobRoleAsn = new JobRoleAsnView()
                {
                    JobId = 123,
                    JobRoleAsnId = 234,
                    JobRoleTypeId = 1234,
                    CustAcctNbr = "test123",
                    SalesCustomerName = "Test Name",
                    SalesCustId = 3456,
                    JobRoleContactId = 7547,
                    HostUpdateInd = "Test",
                    InsertDate = DateTime.Now,
                    BidderInd = "testbid",
                    WinningBidderInd = "test",
                    Name = "TestUser",
                    PhoneNbr = "98765747",
                    PhoneExtension = "91",
                    FaxNbr = "testFax",
                    IsJobRoleSelected = true
                }
            };
        }

        /// <summary>
        /// Gets list of document view model
        /// </summary>
        /// <returns>List of DocumentViewModel</returns>
        public static List<DocumentViewModel> GetDocumentModelList()
        {
            List<DocumentViewModel> documentViewModelList = new List<DocumentViewModel>();
            documentViewModelList.Add(new DocumentViewModel() { DocumentKey = "Jobs/78/26613/upload.txt", DocumentVersion = "70gFGfCnD7hkZpavJ5y8QY0TPECq0k_P" });
            documentViewModelList.Add(new DocumentViewModel() { DocumentKey = "Jobs/78/26613/download.txt", DocumentVersion = "shFr6JXc_m.BHHuScf0126nEff.v9T4D" });

            return documentViewModelList;
        }
    }
}
