// <copyright file="FavoritesControllerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Controllers
{
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class FavoritesControllerTest
    {
        private readonly FavoritesController favoritesController;
        private readonly Mock<ILogger<FavoritesController>> loggerMock;
        private readonly Mock<IMediator> mediatorMock;
        private readonly Mock<IFavoriteService> favoriteServiceMock;

        public FavoritesControllerTest()
        {
            this.favoriteServiceMock = new Mock<IFavoriteService>();
            this.loggerMock = new Mock<ILogger<FavoritesController>>();
            this.mediatorMock = new Mock<IMediator>();
            this.favoritesController = new FavoritesController(this.loggerMock.Object, this.mediatorMock.Object, this.favoriteServiceMock.Object);
        }

        /// <summary>
        /// Test to update favorite job
        /// </summary>
        /// <returns>Bad request with error message</returns>
        [Fact]
        public async Task UpdateFavorite_InvalidInput_ReturnsBadRequest()
        {
            // Arrange
            int jobId = 0;
            string errorMessage = $"Invalid input parameter : JobId - {jobId}";

            // Act
            IActionResult actionResult = await this.favoritesController.UpdateFavorite(jobId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Equal(errorMessage, (string)((ObjectResult)actionResult).Value);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateFavoriteCommand>(), default), Times.Never);
        }

        /// <summary>
        /// Test to update favorite job
        /// </summary>
        /// <returns>Ok result</returns>
        [Fact]
        public async Task UpdateFavorite_ValidInput_ReturnsOkResult()
        {
            // Arrange
            int jobId = 1234;
            this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateFavoriteCommand>(), default(CancellationToken))).Returns(Task.FromResult(string.Empty));

            // Act
            IActionResult actionResult = await this.favoritesController.UpdateFavorite(jobId);

            // Assert
            Assert.IsType<OkResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(It.Is<UpdateFavoriteCommand>(x => x.JobId == jobId), default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Test to update favorite job
        /// </summary>
        /// <returns>Bad request with error message</returns>
        [Fact]
        public async Task UpdateFavorite_ValidInput_ReturnsBadRequestWithErrorMessage()
        {
            // Arrange
            int jobId = 1234;
            string errorMessage = "Unexpected error occurred while deleting favorite job";
            this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateFavoriteCommand>(), default(CancellationToken))).Returns(Task.FromResult(errorMessage));

            // Act
            IActionResult actionResult = await this.favoritesController.UpdateFavorite(jobId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Equal(errorMessage, (string)((ObjectResult)actionResult).Value);
            this.mediatorMock.Verify(x => x.Send(It.Is<UpdateFavoriteCommand>(x => x.JobId == jobId), default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Test to get favorite count - Ok result with favorite count
        /// </summary>
        [Fact]
        public void GetFavoriteCount_RetrievedSuccessfully_ReturnOk()
        {
            // Arrange
            long favoriteCount = 1;
            this.favoriteServiceMock.Setup(x => x.GetFavoriteCount()).Returns(favoriteCount);

            // Act
            IActionResult actionResult = this.favoritesController.GetFavoriteCount();

            // Assert
            this.favoriteServiceMock.Verify(x => x.GetFavoriteCount(), Times.Once);
            Assert.IsType<OkObjectResult>(actionResult);
            Assert.Equal(favoriteCount, (long)((ObjectResult)actionResult).Value);
        }
    }
}
