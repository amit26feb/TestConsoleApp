// <copyright file="CustomSenderControllerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Common.Constants;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Custom sender controller test
    /// </summary>
    public class CustomSenderControllerTest
    {
        private readonly Mock<ILogger<CustomSenderController>> loggerMock;
        private readonly Mock<ICustomSenderService> customSenderServiceMock;
        private readonly CustomSenderController customSenderController;
        private readonly Mock<IMediator> mediatorMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomSenderControllerTest"/> class.
        /// </summary>
        public CustomSenderControllerTest()
        {
            this.loggerMock = new Mock<ILogger<CustomSenderController>>();
            this.customSenderServiceMock = new Mock<ICustomSenderService>();
            this.mediatorMock = new Mock<IMediator>();
            this.customSenderController = new CustomSenderController(this.loggerMock.Object, this.customSenderServiceMock.Object, this.mediatorMock.Object);
        }

        /// <summary>
        /// Test to retrieve custom senders using dr address id
        /// </summary>
        /// <returns>Ok</returns>
        [Fact]
        public async Task GetCustomSenders_ValidRequest_ReturnsOk()
        {
            // Arrange
            int drAddressId = 256;
            IEnumerable<CustomSenderViewModel> customSenderList = Helper.GetCustomSenderViewModels(drAddressId);
            this.customSenderServiceMock.Setup(x => x.GetCustomSenders(It.IsAny<int>()))
                .Returns(Task.FromResult(customSenderList));

            // Act
            var actionResult = await this.customSenderController.GetCustomSenders(drAddressId);

            // Assert
            Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
            Assert.Equal(customSenderList.Count(), ((IEnumerable<CustomSenderViewModel>)((ObjectResult)actionResult).Value).Count());
            this.customSenderServiceMock.Verify(x => x.GetCustomSenders(drAddressId), Times.Once);
        }

        /// <summary>
        /// Test to retrieve custom senders using dr address id but no records
        /// </summary>
        /// <returns>No content</returns>
        [Fact]
        public async Task GetCustomSenders_ValidRequest_ReturnsNoContent()
        {
            // Arrange
            int drAddressId = 256;
            IEnumerable<CustomSenderViewModel> customSenderEmptyList = Enumerable.Empty<CustomSenderViewModel>();
            this.customSenderServiceMock.Setup(x => x.GetCustomSenders(It.IsAny<int>()))
                .Returns(Task.FromResult(customSenderEmptyList));

            // Act
            var actionResult = await this.customSenderController.GetCustomSenders(drAddressId);

            // Assert
            Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
            this.customSenderServiceMock.Verify(x => x.GetCustomSenders(drAddressId), Times.Once);
        }

        /// <summary>
        /// Test to retrieve custom senders using dr address id with invalid request
        /// </summary>
        /// <param name="drAddressId">Dr address id</param>
        /// <returns>Bad request</returns>
        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public async Task GetCustomSenders_InvalidRequest_ReturnsBadRequest(int drAddressId)
        {
            // Act
            var actionResult = await this.customSenderController.GetCustomSenders(drAddressId);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
            this.customSenderServiceMock.Verify(x => x.GetCustomSenders(It.IsAny<int>()), Times.Never);
        }

        /// <summary>
        /// Method to test Create Custom Sender inserted successfully
        /// </summary>
        /// <returns>Ok result</returns>
        [Fact]
        public async Task CreateCustomSender_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            CreateCustomSenderCommand request = new CreateCustomSenderCommand(Helper.GetCustomSenderViewModel());
            this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateCustomSenderCommand>(), default(CancellationToken))).Returns(Task.FromResult(string.Empty));

            // Act
            IActionResult actionResult = await this.customSenderController.Create(request);

            // Assert
            Assert.IsType<OkObjectResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(request, default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Method to test Create Custom Sender for invalid request returns bad request
        /// </summary>
        /// <returns>Bad request</returns>
        [Fact]
        public async Task CreateCustomSender_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            CreateCustomSenderCommand request = null;
            string errorMessage = "Invalid request - Request parameter can not be null.";

            // Act
            IActionResult actionResult = await this.customSenderController.Create(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Contains(errorMessage, ((BadRequestObjectResult)actionResult).Value.ToString());
            this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateCustomSenderCommand>(), default(CancellationToken)), Times.Never);
        }

        /// <summary>
        /// Method to test Create Custom Sender for valid request but duplicate of nickname returns conflict
        /// </summary>
        /// <returns>Conflict</returns>
        [Fact]
        public async Task CreateCustomSender_ValidRequestButInsertFailed_ReturnsConflict()
        {
            // Arrange
            CreateCustomSenderCommand request = new CreateCustomSenderCommand(Helper.GetCustomSenderViewModel());
            this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateCustomSenderCommand>(), default(CancellationToken))).Returns(Task.FromResult(request.CustomSender.CustomSenderNickName + CommonHelper.CustomSenderNickNameExists));

            // Act
            IActionResult actionResult = await this.customSenderController.Create(request);

            // Assert
            Assert.IsType<ConflictObjectResult>(actionResult);
            Assert.Contains(request.CustomSender.CustomSenderNickName + CommonHelper.CustomSenderNickNameExists, ((ConflictObjectResult)actionResult).Value.ToString());
            this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateCustomSenderCommand>(), default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Test to retrieve custom sender detail using custom sender id
        /// </summary>
        /// <returns>Ok</returns>
        [Fact]
        public async Task GetCustomSenderById_ValidRequest_ReturnsOk()
        {
            // Arrange
            string customSenderId = "45LY";
            CustomSenderViewModel customSenderViewModel = Helper.GetCustomSenderViewModel(customSenderId);
            this.customSenderServiceMock.Setup(x => x.GetCustomSenderById(It.IsAny<string>()))
                .Returns(Task.FromResult(customSenderViewModel));

            // Act
            var actionResult = await this.customSenderController.GetCustomSenderById(customSenderId);

            // Assert
            Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
            Assert.Equal(customSenderViewModel, (CustomSenderViewModel)((ObjectResult)actionResult).Value);
            this.customSenderServiceMock.Verify(x => x.GetCustomSenderById(customSenderId), Times.Once);
        }

        /// <summary>
        /// Test to retrieve custom sender detail using custom sender id but no record
        /// </summary>
        /// <returns>No content</returns>
        [Fact]
        public async Task GetCustomSenderById_ValidRequestHasNoData_ReturnsNoContent()
        {
            // Arrange
            string customSenderId = "45LY";
            CustomSenderViewModel customSenderEmpty = null;
            this.customSenderServiceMock.Setup(x => x.GetCustomSenderById(It.IsAny<string>()))
                .Returns(Task.FromResult(customSenderEmpty));

            // Act
            var actionResult = await this.customSenderController.GetCustomSenderById(customSenderId);

            // Assert
            Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
            this.customSenderServiceMock.Verify(x => x.GetCustomSenderById(customSenderId), Times.Once);
        }

        /// <summary>
        /// Test to retrieve custom sender detail using invalid request custom sender id
        /// </summary>
        /// <returns>Bad request</returns>
        [Fact]
        public async Task GetCustomSenderById_InvalidRequestCustomSenderId_ReturnsBadRequest()
        {
            // Arrange
            string customSenderId = null;

            // Act
            var actionResult = await this.customSenderController.GetCustomSenderById(customSenderId);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
            this.customSenderServiceMock.Verify(x => x.GetCustomSenderById(It.IsAny<string>()), Times.Never);
        }

        /// <summary>
        /// Method to test Delete Custom Sender for valid request
        /// </summary>
        /// <returns>Ok Result</returns>
        [Fact]
        public async Task DeleteCustomSender_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            string customSenderId = "xyz-5ab7-416d-qwe345-2345hjk";
            DeleteCustomSenderCommand request = new DeleteCustomSenderCommand(customSenderId);
            this.mediatorMock.Setup(x => x.Send(It.IsAny<DeleteCustomSenderCommand>(), default(CancellationToken))).Returns(Task.FromResult(true));

            // Act
            IActionResult actionResult = await this.customSenderController.DeleteCustomSender(customSenderId);

            // Assert
            Assert.IsType<OkResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<DeleteCustomSenderCommand>(), default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Method to test Delete Custom Sender for given id in request which does not exists
        /// </summary>
        /// <returns>Not Found Result</returns>
        [Fact]
        public async Task DeleteCustomSender_CustomSenderIdDoesNotExist_ReturnsNotFoundResult()
        {
            // Arrange
            string customSenderId = "xyz-s34e-a12b";
            DeleteCustomSenderCommand request = new DeleteCustomSenderCommand(customSenderId);
            this.mediatorMock.Setup(x => x.Send(It.IsAny<DeleteCustomSenderCommand>(), default(CancellationToken))).Returns(Task.FromResult(false));

            // Act
            IActionResult actionResult = await this.customSenderController.DeleteCustomSender(customSenderId);

            // Assert
            Assert.IsType<NotFoundResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<DeleteCustomSenderCommand>(), default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Method to test Delete Custom Sender for null request
        /// </summary>
        /// <returns>Bad Request</returns>
        [Fact]
        public async Task DeleteCustomSender_InvalidRequest_ReturnsBadRequestResult()
        {
            // Arrange
            string customSenderId = string.Empty;
            string errorMessage = "Invalid custom sender id, please provide the valid custom sender id";

            // Act
            IActionResult actionResult = await this.customSenderController.DeleteCustomSender(customSenderId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Equal(errorMessage, ((BadRequestObjectResult)actionResult).Value);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<DeleteCustomSenderCommand>(), default(CancellationToken)), Times.Never);
        }

        /// <summary>
        /// Method to test Update Custom Sender inserted successfully
        /// </summary>
        /// <returns>Ok result</returns>
        [Fact]
        public async Task UpdateCustomSender_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            UpdateCustomSenderCommand request = new UpdateCustomSenderCommand(Helper.GetCustomSenderViewModel("a1b-bre2-jkl23-iwoq1"));
            this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateCustomSenderCommand>(), default(CancellationToken))).Returns(Task.FromResult(string.Empty));

            // Act
            IActionResult actionResult = await this.customSenderController.UpdateCustomSender(request);

            // Assert
            Assert.IsType<OkObjectResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(request, default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Method to test Update Custom Sender inserted successfully with sender name already exists
        /// </summary>
        /// <returns>Ok result</returns>
        [Fact]
        public async Task UpdateCustomSender_ValidRequestWithSenderNameDuplicate_ReturnsOkResult()
        {
            // Arrange
            UpdateCustomSenderCommand request = new UpdateCustomSenderCommand(Helper.GetCustomSenderViewModel("a1b-bre2-jkl23-iwoq1"));
            this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateCustomSenderCommand>(), default(CancellationToken))).Returns(Task.FromResult(request.CustomSender.SenderName + CommonHelper.CustomSenderNameExists));

            // Act
            IActionResult actionResult = await this.customSenderController.UpdateCustomSender(request);

            // Assert
            Assert.IsType<OkObjectResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(request, default(CancellationToken)), Times.Once);
        }

        /// <summary>
        /// Method to test Update Custom Sender for invalid request returns bad request
        /// </summary>
        /// <returns>Bad request</returns>
        [Fact]
        public async Task UpdateCustomSender_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            UpdateCustomSenderCommand request = null;
            string errorMessage = "Invalid request for updating custom sender, please check the request parameter";

            // Act
            IActionResult actionResult = await this.customSenderController.UpdateCustomSender(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Contains(errorMessage, ((BadRequestObjectResult)actionResult).Value.ToString());
            this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateCustomSenderCommand>(), default(CancellationToken)), Times.Never);
        }

        /// <summary>
        /// Method to test Update Custom Sender for valid request but error in DB updation returns bad request
        /// </summary>
        /// <returns>Bad request</returns>
        [Fact]
        public async Task UpdateCustomSender_UnsuccessfulUpdate_ReturnsBadRequest()
        {
            // Arrange
            UpdateCustomSenderCommand request = new UpdateCustomSenderCommand(Helper.GetCustomSenderViewModel("xyz-5ab7-416d-qwe345-2345hjk"));
            string errorMessage = "Unexpected error occured while updating Custom sender - xyz-5ab7-416d-qwe345-2345hjk";
            this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateCustomSenderCommand>(), default(CancellationToken))).Returns(Task.FromResult(errorMessage));

            // Act
            IActionResult actionResult = await this.customSenderController.UpdateCustomSender(request);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Contains(errorMessage, ((BadRequestObjectResult)actionResult).Value.ToString());
            this.mediatorMock.Verify(x => x.Send(request, default(CancellationToken)), Times.Once);
        }
    }
}
