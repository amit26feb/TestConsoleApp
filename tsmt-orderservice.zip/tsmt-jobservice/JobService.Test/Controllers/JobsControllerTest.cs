// <copyright file="JobsControllerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using JobService.Common.Exceptions;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using MediatR;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class JobsControllerTest
    {
        private readonly Mock<IMediator> mediatorMock;
        private readonly Mock<IJobService> jobServiceMock;
        private readonly Mock<IMTopssJobService> mTopssJobServiceMock;
        private readonly Mock<ILogger<JobsController>> logger;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly Mock<IJobDocumentService> jobDocumentServiceMock;
        private readonly JobsController jobControllerUnderTest;

        public JobsControllerTest()
        {
            this.mediatorMock = new Mock<IMediator>();
            this.jobServiceMock = new Mock<IJobService>();
            this.mTopssJobServiceMock = new Mock<IMTopssJobService>();
            this.logger = new Mock<ILogger<JobsController>>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            this.jobDocumentServiceMock = new Mock<IJobDocumentService>();
            this.jobControllerUnderTest = new JobsController(
                this.mediatorMock.Object,
                this.jobServiceMock.Object,
                this.mTopssJobServiceMock.Object,
                this.logger.Object,
                this.contextAccessor.Object,
                this.jobDocumentServiceMock.Object);
        }

        [Fact]
        public async Task Search_GivenValidSearch_ReturnsHttpOk()
        {
            // Arrange
            JobSearch search = new JobSearch() { HqtrJobId = 1 };
            IEnumerable<JobReportView> data = new List<JobReportView> { new JobReportView() };
            this.jobServiceMock.Setup(x => x.SearchAsync(It.IsAny<JobSearch>()))
                  .Returns(Task.FromResult(data));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.Search(search);

            // Assert
            Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
            this.jobServiceMock.Verify(x => x.SearchAsync(It.IsAny<JobSearch>()), Times.Once);
        }

        [Fact]
        public async Task Search_GivenInvalidSearch_ReturnsHttpBadRequest()
        {
            // Arrange
            var search = new JobSearch();
            IEnumerable<JobReportView> data = new List<JobReportView> { new JobReportView() };
            this.jobServiceMock.Setup(x => x.SearchAsync(It.IsAny<JobSearch>()))
                  .Returns(Task.FromResult(data));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.Search(search);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
            this.jobServiceMock.Verify(x => x.SearchAsync(It.IsAny<JobSearch>()), Times.Never);
        }

        [Fact]
        public async Task GetJobBasicInformation_ValidRequest_ReturnsJobBasicInformation()
        {
            // Arrange
            int jobId = 560975;
            JobBasicInfoViewModel jobBasicInfoView = new JobBasicInfoViewModel
            {
                JobName = "UR Tacoma 9916853",
                SalesOfficeName = "Billings",
                HqtrJobId = 89765
            };
            this.jobServiceMock.Setup(x => x.GetJobBasicInformation(It.IsAny<int>()))
                .Returns(Task.FromResult(jobBasicInfoView));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetJobBasicInformation(jobId);

            // Assert
            Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
            this.jobServiceMock.Verify(x => x.GetJobBasicInformation(jobId), Times.Once);
        }

        [Fact]
        public async Task GetJobBasicInformation_ValidRequest_ReturnsNoContent()
        {
            // Arrange
            int jobId = 45621;
            JobBasicInfoViewModel jobBasicInfoView = null;
            this.jobServiceMock.Setup(x => x.GetJobBasicInformation(It.IsAny<int>()))
                .Returns(Task.FromResult(jobBasicInfoView));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetJobBasicInformation(jobId);

            // Assert
            Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
            this.jobServiceMock.Verify(x => x.GetJobBasicInformation(jobId), Times.Once);
        }

        [Fact]
        public async Task GetJobBasicInformation_InvalidJobId_ReturnsBadRequest()
        {
            // Arrange
            int jobId = 0;

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetJobBasicInformation(jobId);

            // Assert
            Assert.Equal("Invalid request, please check the get job basic info request parameter - job id: 0", ((BadRequestObjectResult)actionResult).Value);
            this.jobServiceMock.Verify(x => x.GetJobBasicInformation(jobId), Times.Never);
        }

        [Fact]
        public async Task GetReferenceUnits_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            int jobId = 560975;
            IEnumerable<ReferenceUnitViewModel> referenceUnits = new List<ReferenceUnitViewModel>()
            {
                new ReferenceUnitViewModel()
                {
                    ReferenceUnitId = 10449484,
                    JobId = 560975,
                    TagSequenceNbr = 1,
                    ReviseDate = DateTime.Now
                }
            };
            this.jobServiceMock.Setup(x => x.GetReferenceUnits(It.IsAny<int>()))
                .Returns(Task.FromResult(referenceUnits));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetReferenceUnits(jobId);

            // Assert
            Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
            Assert.Equal(((OkObjectResult)actionResult).Value, referenceUnits);
            this.jobServiceMock.Verify(x => x.GetReferenceUnits(jobId), Times.Once);
        }

        [Fact]
        public async Task GetReferenceUnits_ValidRequest_ReturnsNotFound()
        {
            // Arrange
            int jobId = 45621;
            IEnumerable<ReferenceUnitViewModel> referenceUnits = null;
            this.jobServiceMock.Setup(x => x.GetReferenceUnits(It.IsAny<int>()))
                .Returns(Task.FromResult(referenceUnits));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetReferenceUnits(jobId);

            // Assert
            Assert.Equal((int)HttpStatusCode.NotFound, ((NotFoundResult)actionResult).StatusCode);
            this.jobServiceMock.Verify(x => x.GetReferenceUnits(jobId), Times.Once);
        }

        [Fact]
        public async Task GetReferenceUnits_InvalidJobId_ReturnsBadRequest()
        {
            // Arrange
            int jobId = 0;

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetReferenceUnits(jobId);

            // Assert
            Assert.Equal("Invalid Request. Job Id '0' is not valid", ((BadRequestObjectResult)actionResult).Value);
            this.jobServiceMock.Verify(x => x.GetReferenceUnits(It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task GetPersonId_ValidRequest_ReturnsOkResultWithPersonId()
        {
            // Arrange
            string commCode = "H35";
            int salesOfficeId = 54;
            string personId = "234567";
            this.jobServiceMock.Setup(x => x.GetPersonId(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(personId));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetPersonId(commCode, salesOfficeId);

            // Assert
            Assert.IsType<OkObjectResult>(actionResult);
            Assert.Equal(((OkObjectResult)actionResult).Value, personId);
            this.jobServiceMock.Verify(x => x.GetPersonId(commCode, salesOfficeId), Times.Once);
        }

        [Fact]
        public async Task GetPersonId_ValidRequest_ReturnsNoContent()
        {
            // Arrange
            string commCode = "H35";
            int salesOfficeId = 5;
            string personId = string.Empty;
            this.jobServiceMock.Setup(x => x.GetPersonId(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(personId));

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetPersonId(commCode, salesOfficeId);

            // Assert
            Assert.IsType<NoContentResult>(actionResult);
            this.jobServiceMock.Verify(x => x.GetPersonId(commCode, salesOfficeId), Times.Once);
        }

        [Theory]
        [InlineData(null, 5)]
        [InlineData("H35", 0)]
        [InlineData(null, 0)]
        public async Task GetPersonId_InvalidRequest_ReturnsBadRequest(string commCode, int salesOfficeId)
        {
            // Arrange
            string errorMessage = $"Invalid request parameters commCode: {commCode} or salesOfficeId: {salesOfficeId}";

            // Act
            IActionResult actionResult = await this.jobControllerUnderTest.GetPersonId(commCode, salesOfficeId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Equal(errorMessage, ((JsonErrorResponse)((BadRequestObjectResult)actionResult).Value).Messages.First());
        }
    }
}
