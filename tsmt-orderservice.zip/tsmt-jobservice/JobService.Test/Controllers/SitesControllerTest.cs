// <copyright file="SitesControllerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using JobService.Common.Exceptions;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Sites controller test
    /// </summary>
    public class SitesControllerTest
    {
        private readonly Mock<ISiteService> siteServiceMock;
        private readonly SitesController sitesController;
        private readonly Mock<ILogger<SitesController>> logger;

        public SitesControllerTest()
        {
            this.siteServiceMock = new Mock<ISiteService>();
            this.logger = new Mock<ILogger<SitesController>>();
            this.sitesController = new SitesController(this.siteServiceMock.Object, this.logger.Object);
        }

        [Fact]
        public async Task GetCrmDetails_HasCrmDetails_ReturnsOkResponseWithCrmDetails()
        {
            // Arrange
            IEnumerable<CrmSiteViewModel> crmSitesViewModel = new List<CrmSiteViewModel>()
            {
                Helper.GetCrmSiteViewModel()
            };
            SitePagingResult sitePagingResult = new SitePagingResult()
            {
                PageCount = 1,
                PageNumber = 1,
                TotalItemCount = 1,
                Sites = crmSitesViewModel
            };
            int skip = 0;
            int take = 10;
            string searchText = "Test";
            string companyId = "123";
            this.siteServiceMock.Setup(x => x.GetCrmSiteDetails(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult(sitePagingResult));

            // Act
            IActionResult actionResult = await this.sitesController.GetCrmSiteDetails(skip, take, searchText, companyId);

            // Assert
            Assert.Equal(((OkObjectResult)actionResult).Value, sitePagingResult);
            this.siteServiceMock.Verify(x => x.GetCrmSiteDetails(skip, take, searchText, companyId), Times.Once);
        }

        [Fact]
        public async Task GetCrmDetails_HasNoCrmDetails_ReturnsNoContentResponse()
        {
            // Arrange
            int skip = 0;
            int take = 10;
            string searchText = "Test";
            string companyId = "123";
            SitePagingResult sitePagingResult = null;
            this.siteServiceMock.Setup(x => x.GetCrmSiteDetails(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult(sitePagingResult));

            // Act
            IActionResult actionResult = await this.sitesController.GetCrmSiteDetails(skip, take, searchText, companyId);

            // Assert
            Assert.IsType<NoContentResult>(actionResult);
            this.siteServiceMock.Verify(x => x.GetCrmSiteDetails(skip, take, searchText, companyId), Times.Once);
        }

        [Theory]
        [InlineData(1, "")]
        [InlineData(0, "test")]
        public async Task GetCrmDetails_InvalidRequest_ReturnsBadRequest(int take, string searchText)
        {
            // Arrange
            string errorMessage = "Invalid input parameters";
            int skip = 0;
            string companyId = "123";

            // Act
            IActionResult actionResult = await this.sitesController.GetCrmSiteDetails(skip, take, searchText, companyId);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            Assert.Contains((((ObjectResult)actionResult).Value as JsonErrorResponse).Messages, x => x == errorMessage);
            this.siteServiceMock.Verify(x => x.GetCrmSiteDetails(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }
    }
}
