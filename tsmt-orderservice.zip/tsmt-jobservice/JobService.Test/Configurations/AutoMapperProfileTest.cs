// <copyright file="AutoMapperProfileTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Configurations
{
    using System;
    using AutoFixture;
    using AutoMapper;
    using JobService.Configurations.AutoMapperConfiguration;
    using JobService.Core.Models;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using TSMT.CAM.Data.Core.Models;
    using Xunit;

    /// <summary>
    /// Class for auto mapper profile test
    /// </summary>
    public class AutoMapperProfileTest
    {
        private readonly MapperConfiguration config;
        private readonly IMapper mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperProfileTest"/> class.
        /// </summary>
        public AutoMapperProfileTest()
        {
            // Arrange
            this.config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<AutoMapperProfile>();
            });
            this.mapper = this.config.CreateMapper();
        }

        /// <summary>
        /// Ensure the mapping from sales customers with addresses model to sales customers with addresses view model.
        /// </summary>
        [Fact]
        public void Map_SalesCustomersWithAddressesViewModel_Success()
        {
            // Arrange
            Fixture fixture = new Fixture();

            SalesCustomerWithAddress source = fixture.Create<SalesCustomerWithAddress>();

            // Act
            SalesCustomerWithAddressViewModel destination = this.mapper.Map<SalesCustomerWithAddressViewModel>(source);

            // Assert
            Assert.Equal(destination.Name, source.NAME);
            Assert.Equal(destination.CustomerAccountNumber, source.CUST_ACCT_NBR);
            Assert.Equal(destination.SalesCustomerId, source.SALES_CUST_ID);
            Assert.Equal(destination.StreetAddress1, source.STREET_ADDRESS_1);
            Assert.Equal(destination.Province, source.PROVINCE);
            Assert.Equal(destination.CustomerChannelId, source.CUST_CHANNEL_ID);
            Assert.Equal(destination.PhoneNumber, source.PHONE_NBR);
        }

        /// <summary>
        /// Verifies if the job system type is mapped to job system type view model
        /// </summary>
        [Fact]
        public void Map_JobSystemTypeToJobSystemTypeViewModel_ReturnsJobSystemTypeViewModel()
        {
            // Arrange
            JobSystemType jobSystemType = Helper.GetJobSystemType();

            // Act
            JobSystemTypeViewModel jobSystemTypeViewModel = this.mapper.Map<JobSystemTypeViewModel>(jobSystemType);

            // Assert
            Assert.Equal(jobSystemType.SYS_TYPE_ID, jobSystemTypeViewModel.SystemTypeId);
            Assert.Equal(jobSystemType.DESCRIPTION, jobSystemTypeViewModel.Description);
            Assert.True(jobSystemTypeViewModel.IsMultiSelectable);
            Assert.Equal(jobSystemTypeViewModel.ToolTip, jobSystemType.TOOL_TIP);
        }

        /// <summary>
        /// Verifies if the job system type is mapped to job system type view model
        /// </summary>
        [Fact]
        public void Map_SalesOfficeToSalesOfficeDetailViewNonOracleOffice_ReturnsSalesOfficeDetailView()
        {
            // Arrange
            SalesOffice salesOffice = Helper.NonOracleSalesOffice();

            // Act
            SalesOfficeDetailView salesOfficeDetailView = this.mapper.Map<SalesOfficeDetailView>(salesOffice);

            // Assert
            Assert.False(salesOfficeDetailView.IsOracleProjectIndicator);
            Assert.Equal(salesOfficeDetailView.Id, salesOffice.Sales_office_id);
            Assert.Equal(salesOfficeDetailView.Code, salesOffice.Sales_office_code);
            Assert.Equal(salesOfficeDetailView.Zip, salesOffice.ZIP_CODE);
        }

        /// <summary>
        /// Verifies if the job system type is mapped to job system type view model
        /// </summary>
        [Fact]
        public void Map_SalesOfficeToSalesOfficeDetailViewOracleOffice_ReturnsSalesOfficeDetailView()
        {
            // Arrange
            SalesOffice salesOffice = Helper.OracleSalesOffice();

            // Act
            SalesOfficeDetailView salesOfficeDetailView = this.mapper.Map<SalesOfficeDetailView>(salesOffice);

            // Assert
            Assert.True(salesOfficeDetailView.IsOracleProjectIndicator);
            Assert.Equal(salesOfficeDetailView.Id, salesOffice.Sales_office_id);
            Assert.Equal(salesOfficeDetailView.Code, salesOffice.Sales_office_code);
            Assert.Equal(salesOfficeDetailView.Zip, salesOffice.ZIP_CODE);
        }

        /// <summary>
        /// Verifies mapping from crm site model to crm site view model
        /// </summary>
        [Fact]
        public void Map_CrmSiteToCrmSiteViewModel_ReturnsCrmSiteViewModel()
        {
            // Arrange
            CrmSiteModel crmSiteModel = Helper.GetCrmSiteModel();

            // Act
            CrmSiteViewModel crmSiteViewModel = this.mapper.Map<CrmSiteModel, CrmSiteViewModel>(crmSiteModel);

            // Assert
            Assert.Equal(crmSiteModel.SITE_NAME, crmSiteViewModel.SiteName);
            Assert.Equal(crmSiteModel.STREET_ADDRESS_1, crmSiteViewModel.StreetAddress1);
            Assert.Equal(crmSiteModel.STREET_ADDRESS_2, crmSiteViewModel.StreetAddress2);
            Assert.Equal(crmSiteModel.STREET_ADDRESS_3, crmSiteViewModel.StreetAddress3);
            Assert.Equal(crmSiteModel.STREET_ADDRESS_4, crmSiteViewModel.StreetAddress4);
            Assert.Equal(crmSiteModel.NAME, crmSiteViewModel.CompanyName);
            Assert.Equal(crmSiteModel.PHONE_NBR, crmSiteViewModel.PhoneNumber);
        }

        /// <summary>
        /// Verifies mapping from site contact model to site contact view model
        /// </summary>
        [Fact]
        public void Map_SiteContactToSiteContactViewModel_ReturnsSiteContactViewModel()
        {
            // Arrange
            SiteContact siteContactModel = Helper.GetSiteContactModel();

            // Act
            SiteContactViewModel siteContactViewModel = this.mapper.Map<SiteContact, SiteContactViewModel>(siteContactModel);

            // Assert
            Assert.Equal(siteContactModel.EMAIL_ADDRESS, siteContactViewModel.EmailAddress);
            Assert.Equal(siteContactModel.FIRST_NAME, siteContactViewModel.FirstName);
            Assert.Equal(siteContactModel.LAST_NAME, siteContactViewModel.LastName);
            Assert.Equal(siteContactModel.NAME, siteContactViewModel.CompanyName);
            Assert.Equal(siteContactModel.PHONE_NBR, siteContactViewModel.PhoneNumber);
            Assert.Equal(siteContactModel.SALES_OFFICE_NAME, siteContactViewModel.SalesOfficeName);
            Assert.Equal(siteContactModel.SITE_CONTACT_ID, siteContactViewModel.ContactId);
            Assert.Equal(siteContactModel.STREET_ADDRESS_1, siteContactViewModel.StreetAddress1);
            Assert.Equal(siteContactModel.STREET_ADDRESS_2, siteContactViewModel.StreetAddress2);
            Assert.Equal(siteContactModel.TOTAL_COUNT, siteContactViewModel.TotalCount);
        }

        /// <summary>
        /// Verifies mapping from revenue stream model to revenue stream view model
        /// </summary>
        [Fact]
        public void MapRevenueStreamToRevenueStreamViewModel_ReturnsRevenueStreamViewModel()
        {
            // Arrange
            RevenueStreamModel revenueStream = Helper.GetRevenueStreamModel();

            // Act
            RevenueStreamViewModel revenueStreamViewModel = this.mapper.Map<RevenueStreamModel, RevenueStreamViewModel>(revenueStream);

            // Assert
            Assert.Equal(revenueStream.RevenueStreamFieldValue, revenueStreamViewModel.FieldValue);
            Assert.Equal(revenueStream.Description, revenueStreamViewModel.Description);
        }

        [Fact]
        public void Map_ShippingInstructionToShippingInstructionViewModel_Works()
        {
            // Arrange
            Fixture fixture = new Fixture();
            ShippingInstruction source = fixture.Create<ShippingInstruction>();
            source.IN_USE_ON_LINE_ITEM_IND = 'N';
            source.FINAL_FINISHER_IND = 'Y';
            source.CHG_ALLOWED_IND = 'N';

            // Act
            ShippingInstructionViewModel destination = this.mapper.Map<ShippingInstructionViewModel>(source);

            // Assert
            Assert.False(destination.IsUsedOnLineItem);
            Assert.True(destination.IsFinalFinisher);
            Assert.False(destination.IsChangeAllowed);
            Assert.Equal(source.JOB_ID, destination.JobId);
            Assert.Equal(source.SHIP_INSTRUCT_DESCR, destination.ShippingInstructionDescription);
            Assert.Equal(source.MARK_BILL_LADING_TEXT, destination.MarkBillLadingText);
            Assert.Equal(source.PRIM_CONTACT_EMAIL, destination.DeliveryContactEmail);
            Assert.Equal(source.FIPS_CODE, destination.FipsCode);
            Assert.Equal(source.STATE_CODE, destination.StateCode);
        }

        /// <summary>
        /// Verifies mapping from job basic info model to job basic info view model
        /// </summary>
        [Fact]
        public void Map_MapsJobBasicInfoToJobBasicInfoViewModel_ReturnsJobBasicInfoViewModel()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = Helper.GetJobBasicInfoModel();

            // Act
            JobBasicInfoViewModel jobBasicInfoViewModel = this.mapper.Map<JobBasicInfo, JobBasicInfoViewModel>(jobBasicInfo);

            // Assert
            Assert.Equal(jobBasicInfo.JOB_NAME, jobBasicInfoViewModel.JobName);
            Assert.Equal(jobBasicInfo.HQTR_JOB_ID, jobBasicInfoViewModel.HqtrJobId);
            Assert.Equal(jobBasicInfo.JOB_CONTACT, jobBasicInfoViewModel.JobContact);
            Assert.Equal(jobBasicInfo.JOB_ID, jobBasicInfoViewModel.JobId);
            Assert.Equal(jobBasicInfo.LOST_TO_COMPETITOR, jobBasicInfoViewModel.LostToCompetitor);
            Assert.Equal(jobBasicInfo.LOCATION_OFFICE_NAME, jobBasicInfoViewModel.LocationOfficeName);
            Assert.Equal(jobBasicInfo.ORACLE_PROJECT_IND, jobBasicInfoViewModel.OracleProjectIndicator);
            Assert.Equal(jobBasicInfo.STATUS, jobBasicInfoViewModel.JobStatus);
            Assert.Equal(jobBasicInfo.PRICING_SPA_NBR, jobBasicInfoViewModel.PricingSpaNumber);
        }

        [Fact]
        public void Map_SalesOfficeViewModel_Works()
        {
            // Arrange
            Fixture fixture = new Fixture();
            SalesOffice source = fixture.Create<SalesOffice>();
            source.Sales_office_code = "CO";
            source.Sales_office_id = 110;
            source.Sales_office_name = "Billings";

            // Act
            SalesOfficeView destination = this.mapper.Map<SalesOfficeView>(source);

            // Assert
            Assert.Equal(source.Sales_office_code, destination.SalesOfficeCode);
            Assert.Equal(source.Sales_office_name, destination.SalesOfficeName);
            Assert.Equal(source.Sales_office_id, destination.SalesOfficeId);
        }

        /// <summary>
        /// Verifies mapping from job lock info model to cam model
        /// </summary>
        [Fact]
        public void Map_JobLockInfoModelToCamData_ReturnsCamData()
        {
            // Arrange
            Fixture fixture = new Fixture();
            JobLockInfoModel source = fixture.Create<JobLockInfoModel>();

            // Act
            LockData destination = this.mapper.Map<LockData>(source);

            // Assert
            Assert.Equal(source.JOB_ID, destination.JobId);
            Assert.Equal(source.USER_ID, destination.LockUserId);
            Assert.Equal(source.HQTR_JOB_ID, destination.HqtrJobId);
        }

        [Fact]
        public void Map_MapsJobDocumentViewToJobDocumentModel_ReturnsJobDocumentModel()
        {
            // Arrange
            Fixture fixture = new Fixture();
            JobDocumentView source = fixture.Create<JobDocumentView>();
            source.FolderId = 6;

            // Act
            JobDocument destination = this.mapper.Map<JobDocumentView, JobDocument>(source);

            // Assert
            Assert.Equal(destination.FOLDER_ID, source.FolderId);
        }

        [Fact]
        public void Map_MapsJobDocumentViewToJobDocumentModelWithFolderIdZero_ReturnsJobDocumentModel()
        {
            // Arrange
            Fixture fixture = new Fixture();
            JobDocumentView source = fixture.Create<JobDocumentView>();
            source.FolderId = 0;

            // Act
            JobDocument destination = this.mapper.Map<JobDocumentView, JobDocument>(source);

            // Assert
            Assert.Null(destination.FOLDER_ID);
        }

        [Fact]
        public void Map_FromCrmJobViewModelToJobModel_MapsCollections()
        {
            // Arrange
            CrmJobViewModel source = new CrmJobViewModel()
            {
                OpportunityName = "TestCrmJob",
                CommCode = "DCO",
                UserId = "CCPLF",
                JobContact = "CCFBD",
                OpportunityId = "63912",
                PersonId = "789190",
                Status = "P",
                Currency = "USD",
                BidDate = DateTime.Now,
            };

            // Act
            Job destination = this.mapper.Map<CrmJobViewModel, Job>(source);

            // Assert
            Assert.Equal(destination.JOB_NAME, source.OpportunityName);
            Assert.Equal(destination.LOCATION_OFFICE, source.LocationOfficeId);
            Assert.Equal(destination.CRM_SALES_REP_ID, source.PersonId);
            Assert.Equal(destination.STATUS, source.Status == "0" ? "P" : string.Empty);
            Assert.Equal(destination.BID_DATE, source.BidDate);
            Assert.Equal(destination.CUST_CHANNEL_ID, source.Currency == "USD" ? "COMMSALE" : "CANADA");
            Assert.Equal(destination.COMM_CODE, source.CommCode);
            Assert.Equal(destination.USER_ID, source.UserId);
            Assert.Equal(destination.JOB_CONTACT, source.JobContact);
            Assert.Equal(destination.CRM_OPPORTUNITY_ID, source.OpportunityId);
            Assert.Equal(destination.COUNTRY, source.Currency == "USD" ? "USA" : "CANADA");
        }

        [Fact]
        public void Map_FromSystemViewModelToJobSysIndXrefViewModel_MapsCollections()
        {
            // Arrange
            SystemViewModel source = new SystemViewModel()
            {
                System = "2",
            };

            // Act
            JobSysIndXrefView destination = this.mapper.Map<SystemViewModel, JobSysIndXrefView>(source);

            // Assert
            Assert.Equal(destination.SysTypeId, Convert.ToInt32(source.System));
        }
    }
}
