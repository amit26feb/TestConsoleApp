// <copyright file="AssignCustomerCommandValidatorTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Validators
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.Validators;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using Xunit;

    public class AssignCustomerCommandValidatorTest
    {
        /// <summary>
        /// Sales Repository
        /// </summary>
        private readonly Mock<ISalesCustomerService> salesService;
        private readonly IHttpContextAccessor contextAccessor = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="AssignCustomerCommandValidatorTest"/> class.
        /// AssignCustomerCommandValidatorTest
        /// </summary>
        public AssignCustomerCommandValidatorTest()
        {
            this.salesService = new Mock<ISalesCustomerService>();
        }

        /// <summary>
        /// Test Assign create validation with valid inputs
        /// </summary>
        [Fact]
        public void AssignCustomerCommandValidator_Success()
        {
            // Arrange
            var assignCustomer = new JobRoleAsnView()
            {
                JobRoleAsnId = 0,
                JobId = 4004,
                JobRoleTypeId = 1,
                SalesCustId = 1001,
                CustAcctNbr = "3042336",
                SalesCustomerName = "North Quincy High School",
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            this.salesService.Setup(x => x.ValidateSalesCustId(It.IsAny<int>()))
               .Returns(Task.FromResult(true));

            // Act
            var customer = new AssignCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new AssignCustomerCommand(assignCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.IsValid);
        }

        /// <summary>
        /// Test Assign Customer validation with invalid JobId
        /// </summary>
        [Fact]
        public void AssignCustomerCommandValidator_InvalidJobId()
        {
            // Arrange
            var assignCustomer = new JobRoleAsnView()
            {
                JobRoleAsnId = 1,
                JobId = 0,
                JobRoleTypeId = 1,
                CustAcctNbr = "3042336",
                SalesCustId = 1001,
                SalesCustomerName = "North Quincy High School",
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            this.salesService.Setup(x => x.ValidateSalesCustId(It.IsAny<int>()))
              .Returns(Task.FromResult(true));

            // Act
            var customer = new AssignCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new AssignCustomerCommand(assignCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.Errors.Select(a => a.ErrorMessage == "Job Id must not be 0").FirstOrDefault());
            Assert.False(customer.IsValid);
        }

        /// <summary>
        /// Test assign customer validation with invalid JobRoleAsnId
        /// </summary>
        [Fact]
        public void AssignCustomerCommandValidator_InvalidJobRoleAsnId()
        {
            // Arrange
            var assignCustomer = new JobRoleAsnView()
            {
                JobRoleAsnId = 1,
                JobId = 1,
                JobRoleTypeId = 1,
                CustAcctNbr = "3042336",
                SalesCustId = 0,
                SalesCustomerName = "North Quincy High School",
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            this.salesService.Setup(x => x.ValidateSalesCustId(It.IsAny<int>()))
              .Returns(Task.FromResult(true));

            // Act
            var customer = new AssignCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new AssignCustomerCommand(assignCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.Errors.Select(a => a.ErrorMessage == "JobRoleAsnId must be 0").FirstOrDefault());
            Assert.False(customer.IsValid);
        }

        /// <summary>
        /// Test Assign customer validation with invalid customername
        /// </summary>
        [Fact]
        public void AssignCustomerCommandValidator_InvalidCustomerName()
        {
            // Arrange
            var assignCustomer = new JobRoleAsnView()
            {
                JobRoleAsnId = 1,
                JobId = 1,
                JobRoleTypeId = 1,
                CustAcctNbr = "3042336",
                SalesCustId = 0,
                SalesCustomerName = string.Empty,
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            this.salesService.Setup(x => x.ValidateSalesCustId(It.IsAny<int>()))
              .Returns(Task.FromResult(true));

            // Act
            var customer = new AssignCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new AssignCustomerCommand(assignCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.Errors.Select(a => a.ErrorMessage == "Customer Name cannot be Empty").FirstOrDefault());
            Assert.False(customer.IsValid);
        }

        /// <summary>
        /// Test Assign customer validation with invalid JobRoleTypeId
        /// </summary>
        [Fact]
        public void AssignCustomerCommandValidator_InvalidJobRoleTypeId()
        {
            // Arrange
            var assignCustomer = new JobRoleAsnView()
            {
                JobRoleAsnId = 1,
                JobId = 1,
                JobRoleTypeId = 0,
                CustAcctNbr = "3042336",
                SalesCustId = 1001,
                SalesCustomerName = "North Quincy High School",
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            this.salesService.Setup(x => x.ValidateSalesCustId(It.IsAny<int>()))
              .Returns(Task.FromResult(true));

            // Act
            var customer = new AssignCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new AssignCustomerCommand(assignCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.Errors.Select(a => a.ErrorMessage == "JobRoleTypeId must not be 0").FirstOrDefault());
            Assert.False(customer.IsValid);
        }
    }
}
