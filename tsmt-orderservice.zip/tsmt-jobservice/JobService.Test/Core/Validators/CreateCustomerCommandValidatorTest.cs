// <copyright file="CreateCustomerCommandValidatorTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Validators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.Validators;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using Xunit;

    public class CreateCustomerCommandValidatorTest
    {
        /// <summary>
        /// Tests create customer validation with valid inputs
        /// </summary>
        private readonly Mock<ISalesCustomerService> salesService;
        private readonly IHttpContextAccessor contextAccessor = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCustomerCommandValidatorTest"/> class.
        /// CreateCustomerCommandValidatorTest
        /// </summary>
        public CreateCustomerCommandValidatorTest()
        {
            this.salesService = new Mock<ISalesCustomerService>();
        }

        /// <summary>
        /// Test create validation with valid inputs
        /// </summary>
        [Fact]
        public void CreateCustomerCommandValidator_Success()
        {
            // Arrange
            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 0,
                JobRoleContactId = 0,
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true
                },
            };
            var createCustomer = new SalesCustomerCreateView()
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8239899655",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            this.salesService.Setup(x => x.ValidateCommCode(It.IsAny<string>(), It.IsAny<int>()))
               .Returns(Task.FromResult(true));

            // Act
            var customer = new CreateCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new CreateCustomerCommand(createCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.IsValid);
        }

        /// <summary>
        /// Test create customer validation with invalid CustomerName
        /// </summary>
        [Fact]
        public void CreateCustomerCommandValidator_InvalidCustomerName()
        {
            // Arrange
            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 0,
                JobRoleContactId = 0,
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true
                },
            };
            var createCustomer = new SalesCustomerCreateView()
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = string.Empty,
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "2239899655",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            this.salesService.Setup(x => x.ValidateCommCode(It.IsAny<string>(), It.IsAny<int>()))
              .Returns(Task.FromResult(true));

            // Act
            var customer = new CreateCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new CreateCustomerCommand(createCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.Errors.Select(a => a.ErrorMessage == "Customer Name cannot be empty").FirstOrDefault());
            Assert.False(customer.IsValid);
        }

        /// <summary>
        /// Test assign customer validation with invalid JobRoleType
        /// </summary>
        [Fact]
        public void CreateCustomerCommandValidator_InvalidJobRoleType()
        {
            // Arrange
            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 0,
                JobRoleContactId = 0,
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true
                },
            };
            var createCustomer = new SalesCustomerCreateView()
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 0,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8643745050",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };
            this.salesService.Setup(x => x.ValidateCommCode(It.IsAny<string>(), It.IsAny<int>()))
                          .Returns(Task.FromResult(true));

            // Act
            var customer = new CreateCustomerCommandValidator(this.salesService.Object, this.contextAccessor).Validate(new CreateCustomerCommand(createCustomer));

            // Assert
            Assert.NotNull(customer);
            Assert.True(customer.Errors.Select(a => a.ErrorMessage == "A Job Role Type must be selected").FirstOrDefault());
            Assert.False(customer.IsValid);
        }
    }
}
