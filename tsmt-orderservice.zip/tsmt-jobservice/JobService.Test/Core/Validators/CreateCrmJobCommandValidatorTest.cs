// <copyright file="CreateCrmJobCommandValidatorTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace JobService.Core.Validators
{
    using System.Linq;
    using JobService.Core.Commands;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using Xunit;

    public class CreateCrmJobCommandValidatorTest
    {
        [Fact]
        public void CreateJobCommandValidator_ValidRequest_Success()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.True(result.IsValid);
        }

        [Fact]
        public void CreateJobCommandValidator_InvalidJobId_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.JobId = 98452;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "Job Id must be 0").First());
        }

        [Fact]
        public void CreateJobCommandValidator_EmptyOpportunityName_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.OpportunityName = string.Empty;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "Opportunity Name cannot be empty").First());
        }

        [Fact]
        public void CreateJobCommandValidator_InvalidSalesOfficeId_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.SalesOfficeId = 0;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "Sales Office should be greater than 0").First());
        }

        [Fact]
        public void CreateJobCommandValidator_InvalidLocationOfficeId_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.LocationOfficeId = 0;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "Location Office should be greater than 0").First());
        }

        [Fact]
        public void CreateJobCommandValidator_InvalidCrmOppyId_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.OpportunityId = string.Empty;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "Crm Opportunity Id cannot be empty").First());
        }

        [Fact]
        public void CreateJobCommandValidator_InvalidBoDOnControls_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.BoDOnControls = string.Empty;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "BOD on Controls cannot be empty").First());
        }

        [Fact]
        public void CreateJobCommandValidator_InvalidBoDOnEquipment_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.BoDOnEquipment = string.Empty;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "BOD on Equipment cannot be empty").First());
        }

        [Fact]
        public void CreateJobCommandValidator_InvalidParentIndustryVerticalMarket_ReturnFalse()
        {
            // Arrange
            CrmJobViewModel createCrmJob = Helper.GetCrmJobViewModel();
            createCrmJob.ParentIndustryVerticalMarket = string.Empty;

            // Act
            var result = new CreateCrmJobCommandValidator().Validate(new CreateCrmJobCommand(createCrmJob));

            // Assert
            Assert.False(result.IsValid);
            Assert.True(result.Errors.Select(a => a.ErrorMessage == "Parent Industry Vertical Market cannot be empty").First());
        }
    }
}
