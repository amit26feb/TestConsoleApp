// <copyright file="JobServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Text;
    using System.Threading.Tasks;
    using AutoFixture;
    using AutoMapper;
    using JobService.Common.Constants;
    using JobService.Common.Exceptions;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Options;
    using MongoDB.Bson;
    using Moq;
    using TraneSalesTools;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.DataAccess;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// Job Service Test Methods
    /// </summary>
    public class JobServiceTest
    {
        private readonly Mock<IRepository<global::JobService.Core.Models.JobDetails>> repository;
        private readonly Mock<IJobRepository> jobRepository;
        private readonly Mock<IJobCoordinationRepository> jobCoordinationRepository;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly IMapper mapper;
        private readonly Mock<IWebHostEnvironment> hostingEnvironment;
        private readonly Mock<ISalesOfficeService> salesOfficeService;
        private readonly Mock<IJobCoordinationService> jobCoordinationServiceMock;
        private readonly Mock<IJobsSnsNotifier> jobsSnsNotifierMock;
        private readonly Mock<IOptions<TSMTSettings>> tsmtSettingsMock;
        private readonly Mock<IFavoriteService> favoriteServiceMock;
        private readonly JobService jobServiceUnderTest;
        private readonly int drAddressId = 78;
        private readonly int jobId = 555;
        private readonly int invalidJobId = 0;
        private readonly string userId = "asdabc";
        private readonly DefaultHttpContext httpContext = new DefaultHttpContext();
        private readonly IEnumerable<int> favoriteJobIds = new List<int>();
        private readonly IEnumerable<BsonDocument> favoriteJobBsonDocuments = new List<BsonDocument>();
        private readonly Mock<IMapper> mockMapper;

        public JobServiceTest()
        {
            this.repository = new Mock<IRepository<JobDetails>>();
            this.jobRepository = new Mock<IJobRepository>();
            this.jobCoordinationRepository = new Mock<IJobCoordinationRepository>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.hostingEnvironment = new Mock<IWebHostEnvironment>();
            this.salesOfficeService = new Mock<ISalesOfficeService>();
            this.jobCoordinationServiceMock = new Mock<IJobCoordinationService>();
            this.jobsSnsNotifierMock = new Mock<IJobsSnsNotifier>();
            this.tsmtSettingsMock = new Mock<IOptions<TSMTSettings>>();
            this.favoriteServiceMock = new Mock<IFavoriteService>();
            this.httpContext.Items.Add("DR_ADDRESS_ID", 78);
            List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", this.userId),
                new Claim("firstname", "Cassie"),
                new Claim("lastname", "DeWaay")
            };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            ClaimsIdentity appIdentity = new ClaimsIdentity(claims);
            this.httpContext.User.AddIdentity(appIdentity);
            this.mockMapper = new Mock<IMapper>();
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobServiceUnderTest = new JobService(this.repository.Object, this.mapper, this.jobRepository.Object, this.contextAccessor.Object, this.hostingEnvironment.Object, this.salesOfficeService.Object, this.jobCoordinationRepository.Object, this.jobCoordinationServiceMock.Object, this.jobsSnsNotifierMock.Object, this.tsmtSettingsMock.Object, this.favoriteServiceMock.Object);
            this.jobRepository.Setup(x => x.GetFavorites(this.drAddressId, this.userId)).Returns(Task.FromResult(this.favoriteJobBsonDocuments));
        }

        [Fact]
        public async Task GetJobList_ValidRequest_ReturnsValidData()
        {
            // Arrange
            IEnumerable<global::JobService.Core.ViewModels.JobView> jobList = new List<global::JobService.Core.ViewModels.JobView>
            {
                    new global::JobService.Core.ViewModels.JobView()
                    {
                      JobId = 77574,
                      DrAddressId = 94,
                      JobName = "Gantt Fire Dept",
                      CommCode = "D35",
                      CheckedIn = "Y",
                      SalesOfficeId = 34,
                      CjWho = "Cassie DeWaay",
                      DistanceToJob = 5,
                      JobSource = "PS",
                      DomesticInternationlInd = "D",
                      JobContact = "lamsp",
                      TotalCount = 1
                    }
             };
            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort()
                {
                    SortBy = "JOB_NAME",
                    SortDirection = global::JobService.Core.ViewModels.SortDirection.Ascending
                }
            };

            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "DR_ADDRESS_ID",
                    Operator = "Eq",
                    Value = "94"
                },
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "JOB_NAME",
                    Operator = "Eq",
                    Value = "Trane"
                }
            };

            List<global::JobService.Core.ViewModels.FilterCollection> filterCollection = new List<global::JobService.Core.ViewModels.FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection()
                {
                    ColumnFilters = filters,
                    Logic = "and"
                }
            };

            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 1,
                Take = 20,
                Sort = sortOrder,
                Filters = filterCollection
            };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobList));

            // Act
            var result = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(result);
            Assert.NotNull(result);
            Assert.Equal(jobList.Count(), result.JobList.Count());
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidRequest_ReturnsNull()
        {
            // Arrange
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions();
            IEnumerable<global::JobService.Core.ViewModels.JobView> jobList = new List<global::JobService.Core.ViewModels.JobView>();

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
           .Returns(Task.FromResult(jobList));

            // Act
            var jobResult = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.Null(jobResult);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetSelectionListPaging_ValidRequest_ReturnsValidData()
        {
            // Arrange
            var fixture = new Fixture();
            var fakeSelectionListModel = fixture.CreateMany<global::JobService.Core.Models.SelectionListItem>(15);
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions();

            this.jobRepository.Setup(x => x.GetSelectionListAsync<global::JobService.Core.Models.SelectionListItem>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), jobId))
               .Returns(Task.FromResult(fakeSelectionListModel)).Verifiable();

            // Act
            var selectionList = await this.jobServiceUnderTest.GetSelectionList(fakeRequest, this.jobId);

            // Assert
            Assert.NotNull(selectionList);
            Assert.Equal(fakeSelectionListModel.Count(), selectionList.Count());
            this.jobRepository.Verify(x => x.GetSelectionListAsync<global::JobService.Core.Models.SelectionListItem>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), jobId), Times.Once);
        }

        [Fact]
        public async Task GetSelectionList_InvalidRequest_ReturnEmptyResult()
        {
            // Arrange
            var fixture = new Fixture();
            var fakeSelectionListModel = fixture.CreateMany<global::JobService.Core.Models.SelectionListItem>(0);
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions();

            this.jobRepository.Setup(x => x.GetSelectionListAsync<global::JobService.Core.Models.SelectionListItem>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), jobId))
               .Returns(Task.FromResult(fakeSelectionListModel)).Verifiable();

            // Act
            var selectionList = await this.jobServiceUnderTest.GetSelectionList(fakeRequest, this.jobId);

            // Assert
            Assert.NotNull(selectionList);
            Assert.Equal(fakeSelectionListModel.Count(), selectionList.Count());
            this.jobRepository.Verify(x => x.GetSelectionListAsync<global::JobService.Core.Models.SelectionListItem>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), jobId), Times.Once);
        }

        [Fact]
        public async Task LockJob_ValidRequest_ReturnUserId()
        {
            // Arrange
            JobLock lockRequest = new JobLock()
            {
                JobId = 123456,
                UserId = "ccfasd",
            };

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "ccfasd")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            this.jobRepository.Setup(x => x.LockJobAsync(lockRequest.JobId, lockRequest.UserId))
                .Returns(Task.FromResult(lockRequest.UserId));

            string currentUserId = await this.jobServiceUnderTest.LockJob(lockRequest);

            // Assert
            Assert.IsType<string>(currentUserId);
            Assert.NotNull(currentUserId);
            Assert.Equal(lockRequest.UserId, currentUserId);
            this.jobRepository.Verify(x => x.LockJobAsync(lockRequest.JobId, lockRequest.UserId), Times.Once);
        }

        [Fact]
        public async Task LockJob_Conflict_Existing()
        {
            // Arrange
            string invalidId = "lmnop";
            JobLock lockRequest = new JobLock()
            {
                JobId = 123456,
                UserId = "dummy user"
            };

            this.jobRepository.Setup(x => x.LockJobAsync(lockRequest.JobId, lockRequest.UserId))
                .Returns(Task.FromResult(invalidId)).Verifiable();

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            string currentUserId = await this.jobServiceUnderTest.LockJob(lockRequest);

            // Assert
            Assert.IsType<string>(currentUserId);
            Assert.NotNull(currentUserId);
            Assert.NotEqual(lockRequest.UserId, currentUserId);
            this.jobRepository.Verify(x => x.LockJobAsync(lockRequest.JobId, lockRequest.UserId), Times.Once);
        }

        [Fact]
        public async Task UnLockJob_Executes_ReturnEmptyString()
        {
            // Arrange
            UnLockJobView unlockView = new UnLockJobView()
            {
                JobId = 123456,
                AllowLockOverride = false,
                UserId = "Den"
            };

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "XXXABC")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            this.jobRepository.Setup(x => x.UnlockJobAsync(It.IsAny<int>(), It.IsAny<string>(), false))
                .Returns(Task.FromResult(string.Empty));

            // Act
            var result = await this.jobServiceUnderTest.UnLockJob(unlockView);

            // Assert
            Assert.IsType<string>(result);
            Assert.Empty(result);
            this.jobRepository.Verify(x => x.UnlockJobAsync(unlockView.JobId, "xxxabc", unlockView.AllowLockOverride), Times.Once);
        }

        [Fact]
        public async Task GetJob_ValidRequest_ReuturnJobDetails()
        {
            // Assign
            JobDetailView jobDetailView = new JobDetailView()
            {
                JobId = 100,
                UserId = "lalcj",
                NameFirst = "David",
                NameLast = "Harper"
            };

            IEnumerable<JobClassificationView> jobClassifications = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    ClassificationDescription = "GOVERNMENT - STATE",
                    DescriptionValues = "Vertical Market",
                    JobCodeId = 1566,
                    JobCode = "BC"
                },
                new JobClassificationView()
                {
                    ClassificationDescription = "Transitional Job",
                    DescriptionValues = "Transitional Job details",
                    JobCodeId = 1567,
                    JobCode = "AB"
                }
            };
            this.jobRepository.Setup(x => x.GetJobAsync(jobDetailView.JobId)).Returns(Task.FromResult(jobDetailView));
            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(jobDetailView.JobId)).Returns(Task.FromResult(jobClassifications));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJob(jobDetailView.JobId);

            // Assert
            Assert.IsType<JobDetailView>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(jobDetails, jobDetailView);
            this.jobRepository.Verify(x => x.GetJobAsync(jobDetailView.JobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(jobDetailView.JobId), Times.Once);
        }

        [Fact]
        public async Task GetJob_InvalidRequest_ReturnEmpty()
        {
            // Assign
            JobDetailView jobReportView = null;

            this.jobRepository.Setup(x => x.GetJobAsync(It.IsAny<int>())).Returns(Task.FromResult(jobReportView)).Verifiable();

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJob(this.jobId);

            // Assert
            Assert.Null(jobDetails);
            this.jobRepository.Verify(x => x.GetJobAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(this.jobId), Times.Never);
        }

        public IEnumerable<global::JobService.Core.ViewModels.JobView> GetActualModelsJobList()
        {
            var jobList = new List<JobView>(5)
            {
                new global::JobService.Core.ViewModels.JobView() { JobId = 1, DrAddressId = 100, JobName = "Trane", LastUpdate = DateTime.Today.AddHours(20.0), CrmOpportunityId = "105", CustChannelId = "105", SellingPrice = 105, CommCode = "D21", UserId = "xyz", NameFirst = "Pam", NameLast = "Test" },
                new global::JobService.Core.ViewModels.JobView() { JobId = 2, DrAddressId = 101, JobName = "Cooler", LastUpdate = DateTime.Today.AddHours(16.0), CrmOpportunityId = "105", CustChannelId = "105", SellingPrice = 105, CommCode = "D21", UserId = "xyz", NameFirst = "Pam", NameLast = "Test" },
                new global::JobService.Core.ViewModels.JobView() { JobId = 3, DrAddressId = 102, JobName = "Chiller", LastUpdate = DateTime.Today.AddHours(10.0), CrmOpportunityId = "105", CustChannelId = "105", SellingPrice = 105, CommCode = "D21", UserId = "xyz", NameFirst = "Pam", NameLast = "Test" },
                new global::JobService.Core.ViewModels.JobView() { JobId = 4, DrAddressId = 103, JobName = "Heater", LastUpdate = DateTime.Today.AddHours(5.0), CrmOpportunityId = "105", CustChannelId = "105", SellingPrice = 105, CommCode = "D21", UserId = "xyz", NameFirst = "Pam", NameLast = "Test" },
                new global::JobService.Core.ViewModels.JobView() { JobId = 5, DrAddressId = 104, JobName = "AirConditioner", LastUpdate = DateTime.Today.AddHours(16.0), CrmOpportunityId = "105", CustChannelId = "105", SellingPrice = 105, CommCode = "D21", UserId = "xyz", NameFirst = "Pam", NameLast = "Test" },
            };
            return jobList;
        }

        [Fact]
        public async Task GetJobList_ValidRequest_ReturnResultInAscending()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.JobName ascending
                                                 select s).ToList();

            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort()
                {
                    SortBy = "JOB_NAME",
                    SortDirection = global::JobService.Core.ViewModels.SortDirection.Ascending
                },
            };

            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "DR_ADDRESS_ID",
                    Operator = "Eq",
                    Value = "94"
                },
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "JOB_NAME",
                    Operator = "Neq",
                    Value = "Trane"
                }
            };

            List<FilterCollection> filterscollection = new List<FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection()
                {
                    ColumnFilters = filters,
                    Logic = "and"
                },
            };
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 20,
                Filters = filterscollection,
                Sort = sortOrder,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
               .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.True(jobListModel.SequenceEqual(jobDetails.JobList));
            Assert.Equal(jobListModel, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_ValidRequest_ReturnResultInDecending()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.LastUpdate descending
                                                 select s).ToList();

            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort()
                {
                    SortBy = "LAST_UPDATE",
                    SortDirection = global::JobService.Core.ViewModels.SortDirection.Descending
                },
            };

            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "DR_ADDRESS_ID",
                    Operator = "Eq",
                    Value = "94"
                },
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "JOB_NAME",
                    Operator = "Neq",
                    Value = "Trane"
                }
            };

            List<FilterCollection> filterCollection = new List<FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection()
                {
                    ColumnFilters = filters,
                    Logic = "and"
                },
            };
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 20,
                Filters = filterCollection,
                Sort = sortOrder,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.True(jobListModel.SequenceEqual(jobDetails.JobList));
            Assert.Equal(jobListModel, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidSort_ReturnJobList()
        {
            var jobList = this.GetActualModelsJobList();

            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "DR_ADDRESS_ID",
                    Operator = "Eq",
                    Value = "94"
                },
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "JOB_NAME",
                    Operator = "Neq",
                    Value = "Trane"
                }
            };

            List<FilterCollection> filtersCollection = new List<FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection() { ColumnFilters = filters, Logic = "and" },
            };
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 20,
                Filters = filtersCollection,
                Sort = null,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
               .Returns(Task.FromResult(jobList));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(jobList, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidSkipTakeRequest_ReturnJobDetails()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.CommCode descending
                                                 select s).ToList();

            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort()
                {
                    SortBy = "COMM_CODE",
                    SortDirection = global::JobService.Core.ViewModels.SortDirection.Descending
                },
            };

            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "DR_ADDRESS_ID",
                    Operator = "Eq",
                    Value = "94"
                },
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "JOB_NAME",
                    Operator = "Neq",
                    Value = "Trane"
                }
            };

            List<FilterCollection> filterscollection = new List<FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection()
                {
                    ColumnFilters = filters,
                    Logic = "or"
                },
            };
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 0,
                Filters = filterscollection,
                Sort = sortOrder,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(jobListModel, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidFilterRequest_ReturnJobDetails()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.CrmOpportunityId descending
                                                 select s).ToList();

            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort() { SortBy = "CRM_OPPORTUNITY_ID", SortDirection = global::JobService.Core.ViewModels.SortDirection.Descending },
            };

            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 0,
                Filters = null,
                Sort = sortOrder,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(jobListModel, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidFilterOperator_ReturnJobDetails()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.CustChannelId descending
                                                 select s).ToList();

            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort()
                {
                    SortBy = "CUST_CHANNEL_ID",
                    SortDirection = global::JobService.Core.ViewModels.SortDirection.Descending
                },
            };

            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "DR_ADDRESS_ID",
                    Operator = "Eqfd",
                    Value = "94"
                },
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "JOB_NAME",
                    Operator = "Neqfdg",
                    Value = "Trane"
                }
            };

            List<FilterCollection> filterscollection = new List<FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection()
                {
                    ColumnFilters = filters,
                    Logic = "or"
                },
            };
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 0,
                Filters = filterscollection,
                Sort = sortOrder,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(jobListModel, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidFilterField_ReturnJobDetails()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.CustChannelId descending
                                                 select s).ToList();

            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort()
                {
                    SortBy = "CUST_CHANNEL_ID",
                    SortDirection = global::JobService.Core.ViewModels.SortDirection.Descending
                },
            };
            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "DR_ADDRESS_ID",
                    Operator = "Eqfd",
                    Value = "94"
                },
                new global::JobService.Core.ViewModels.Filter()
                {
                    Field = "JOB_NAME_VAL",
                    Operator = "Neqfdg",
                    Value = "Trane"
                }
            };

            List<FilterCollection> filterscollection = new List<FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection()
                {
                    ColumnFilters = filters,
                    Logic = "or"
                },
            };
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 0,
                Filters = filterscollection,
                Sort = sortOrder,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(jobListModel, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidSortByRequest_ReturnJobDetails()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.CustChannelId descending
                                                 select s).ToList();

            List<global::JobService.Core.ViewModels.Sort> sortOrder = new List<global::JobService.Core.ViewModels.Sort>
            {
                new global::JobService.Core.ViewModels.Sort() { SortBy = "CUST_CHANNEL_ID_VALUE", SortDirection = global::JobService.Core.ViewModels.SortDirection.Descending },
            };

            List<global::JobService.Core.ViewModels.Filter> filters = new List<global::JobService.Core.ViewModels.Filter>
            {
                new global::JobService.Core.ViewModels.Filter() { Field = "DR_ADDRESS_ID", Operator = "Eqfd", Value = "94" },
                new global::JobService.Core.ViewModels.Filter() { Field = "JOB_NAME_VAL", Operator = "Neqfdg", Value = "Trane" }
            };

            List<FilterCollection> filterscollection = new List<FilterCollection>
            {
                new global::JobService.Core.ViewModels.FilterCollection() { ColumnFilters = filters, Logic = "or" },
            };
            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 0,
                Filters = filterscollection,
                Sort = sortOrder,
            };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(jobListModel, jobDetails.JobList);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetJobList_InvalidRequest_ReturnZeroPage()
        {
            var jobList = this.GetActualModelsJobList();

            IEnumerable<JobView> jobListModel = (from s in jobList
                                                 orderby s.CustChannelId descending
                                                 select s).ToList();

            var fakeRequest = new global::JobService.Core.ViewModels.JobPagingOptions
            {
                Skip = 0,
                Take = 0,
                Filters = null,
                Sort = null,
            };

            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.jobRepository.Setup(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds))
            .Returns(Task.FromResult(jobListModel));

            // Act
            var jobDetails = await this.jobServiceUnderTest.GetJobList(fakeRequest);

            // Assert
            Assert.IsType<JobListPagingResults>(jobDetails);
            Assert.NotNull(jobDetails);
            Assert.Equal(0, jobDetails.PageSize);
            this.jobRepository.Verify(x => x.GetJobListAsync<global::JobService.Core.Models.JobDetails>(It.IsAny<global::JobService.Core.Models.PagingOptions>(), this.favoriteJobIds), Times.Once);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task GetOfficeSelector_ValidRequest_ReturnsValidData()
        {
            // Arrange
            List<TraneSalesTools.SalesOfficeView> salesOfficeList = new List<TraneSalesTools.SalesOfficeView>
            {
                new TraneSalesTools.SalesOfficeView()
                {
                    SalesOfficeName = "Portland ME",
                    DrAddressId = 94,
                    Country = "USA"
                },

                new TraneSalesTools.SalesOfficeView()
                {
                    SalesOfficeName = "Springfield MA",
                    DrAddressId = 34,
                    Country = "USA"
                },
            };

            this.salesOfficeService.Setup(x => x.GetSalesOffice(It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()))
                 .Returns(Task.FromResult(salesOfficeList.AsEnumerable()));

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            // Act
            var returnSalesOffices = await this.jobServiceUnderTest.GetOfficeSelector();

            // Assert
            Assert.IsType<List<TraneSalesTools.SalesOfficeView>>(returnSalesOffices);
            Assert.NotNull(returnSalesOffices);
            Assert.Equal(returnSalesOffices.Count(), salesOfficeList.Count);
            Assert.Equal(returnSalesOffices, salesOfficeList);
            this.salesOfficeService.Verify(x => x.GetSalesOffice(It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetOfficeSelector_InvalidRequest_ReturnsEmptyList()
        {
            // Arrange
            List<TraneSalesTools.SalesOfficeView> salesOfficeList = new List<TraneSalesTools.SalesOfficeView>();

            this.salesOfficeService.Setup(x => x.GetSalesOffice(It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()))
                 .Returns(Task.FromResult(salesOfficeList.AsEnumerable()));

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            // Act
            var returnSalesOffices = await this.jobServiceUnderTest.GetOfficeSelector();

            // Assert
            Assert.IsType<List<TraneSalesTools.SalesOfficeView>>(returnSalesOffices);
            Assert.Empty(returnSalesOffices);
            Assert.Equal(returnSalesOffices, salesOfficeList);
            this.salesOfficeService.Verify(x => x.GetSalesOffice(It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task CreateJob_ValidRequest_ReturnsValidData()
        {
            // Arrange
            int jobReportId = 44;
            int bidAlternateId = 20;
            var jobList = new global::JobService.Core.ViewModels.JobCreateView()
            {
                JobId = 0,
                DrAddressId = 94,
                JobName = "Trane",
                LocationOffice = 100,
                DateCreated = DateTime.Now,
                CommCode = "DCO",
                CustChannelId = "COMMSALE",
                State = "P",
                CheckedIn = "y",
                LastUpdate = DateTime.Now,
                CplpafLocked = 1,
                SalesOfficeId = 119,
                CjWho = string.Empty,
                HqtrJobId = 0,
                WatcomJobId = 0,
                Province = string.Empty,
                NonUsPostalCode = string.Empty,
                PriceAuthId = 0,
                CjDate = DateTime.Now,
                CjTime = string.Empty,
                BidDate = DateTime.Now,
                LostToCompetitor = string.Empty,
                PricingSpaNbr = string.Empty,
                ReadOnlyPassword = string.Empty,
                ReadWritePassword = string.Empty,
                StreetAddress1 = string.Empty,
                StreetAddress2 = string.Empty,
                ZipCode = string.Empty,
                ZipPlus = string.Empty,
                UserId = "CCPLF",
                JobSource = string.Empty,
                OriginatingDrAddress = 0,
                Country = string.Empty,
                CjSubmitDate = DateTime.Now,
                DomesticInternationlInd = string.Empty,
                StandaloneInd = string.Empty,
                JobPath = string.Empty,
                StatusChangeDate = DateTime.Now,
                HostUserId = string.Empty,
                PriceProtectionPeriod = 0,
                InsertDate = DateTime.Now,
                JobContact = "CCFBD",
                Foe2CreatedOrdersInd = "y",
                TcsJobInd = string.Empty,
                CoordinatedYesNoInd = 0,
                CrmOpportunityId = string.Empty,
                IncludeCjperfInd = 0,
                JobNameAddOn = string.Empty,
                CrmSalesRepId = string.Empty
            };

            this.jobRepository.Setup(x => x.GetSequenceNumber("job"))
                .Returns(Task.FromResult(this.jobId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("JOB_REPORT"))
                .Returns(Task.FromResult(jobReportId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
                .Returns(Task.FromResult(bidAlternateId));

            this.jobRepository.Setup(x => x.InsertJobAsync(It.IsAny<global::JobService.Core.Models.Job>(), jobReportId, bidAlternateId))
                .Returns(Task.FromResult(this.jobId));

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            // Act
            var returnJobId = await this.jobServiceUnderTest.CreateJob(jobList);

            // Assert
            Assert.IsType<int>(returnJobId);
            Assert.True(returnJobId > 0);
            Assert.Equal(returnJobId, this.jobId);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(3));
            this.jobRepository.Verify(x => x.InsertJobAsync(It.IsAny<global::JobService.Core.Models.Job>(), jobReportId, bidAlternateId), Times.Once);
        }

        [Fact]
        public async Task CreateJob_InvalidRequest_ReturnInvalidJobID()
        {
            // Arrange
            int jobReportId = 0;
            int bidAlternateId = 0;
            var jobList = new global::JobService.Core.ViewModels.JobCreateView()
            {
                JobId = 55,
                DrAddressId = 94,
                JobName = "Trane",
                LocationOffice = 100,
                DateCreated = DateTime.Now,
                CommCode = "DCO",
                CustChannelId = "COMMSALE",
                State = "P",
                CheckedIn = "y",
                LastUpdate = DateTime.Now,
                CplpafLocked = 1,
                SalesOfficeId = 119,
                CjWho = string.Empty,
                HqtrJobId = 0,
                WatcomJobId = 0,
                Province = string.Empty,
                NonUsPostalCode = string.Empty,
                PriceAuthId = 0,
                CjDate = DateTime.Now,
                CjTime = string.Empty,
                BidDate = DateTime.Now,
                LostToCompetitor = string.Empty,
                PricingSpaNbr = string.Empty,
                ReadOnlyPassword = string.Empty,
                ReadWritePassword = string.Empty,
                StreetAddress1 = string.Empty,
                StreetAddress2 = string.Empty,
                ZipCode = string.Empty,
                ZipPlus = string.Empty,
                UserId = "CCPLF",
                JobSource = string.Empty,
                OriginatingDrAddress = 0,
                Country = string.Empty,
                CjSubmitDate = DateTime.Now,
                DomesticInternationlInd = string.Empty,
                StandaloneInd = string.Empty,
                JobPath = string.Empty,
                StatusChangeDate = DateTime.Now,
                HostUserId = string.Empty,
                PriceProtectionPeriod = 0,
                InsertDate = DateTime.Now,
                JobContact = "CCFBD",
                Foe2CreatedOrdersInd = "y",
                TcsJobInd = string.Empty,
                CoordinatedYesNoInd = 0,
                CrmOpportunityId = string.Empty,
                IncludeCjperfInd = 0,
                JobNameAddOn = string.Empty,
                CrmSalesRepId = string.Empty
            };

            this.jobRepository.Setup(x => x.GetSequenceNumber("job"))
                .Returns(Task.FromResult(this.invalidJobId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("job_report"))
                .Returns(Task.FromResult(jobReportId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
                .Returns(Task.FromResult(bidAlternateId));

            this.jobRepository.Setup(x => x.InsertJobAsync(It.IsAny<global::JobService.Core.Models.Job>(), jobReportId, bidAlternateId))
                .Returns(Task.FromResult(this.invalidJobId));

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            // Act
            var returnJobId = await this.jobServiceUnderTest.CreateJob(jobList);

            // Assert
            Assert.IsType<int>(returnJobId);
            Assert.False(returnJobId > 0);
            Assert.Equal(returnJobId, this.invalidJobId);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(3));
            this.jobRepository.Verify(x => x.InsertJobAsync(It.IsAny<global::JobService.Core.Models.Job>(), jobReportId, bidAlternateId), Times.Once);
        }

        [Fact]
        public async Task UpdateJobGeneral_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobGeneral = new global::JobService.Core.ViewModels.JobGeneralView()
            {
                JobId = 178456,
                JobReportId = 40382,
                JobName = "Trane",
                DrAddressId = 94,
                Status = "P"
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobGeneral>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobGeneral(jobGeneral);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobGeneral>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobGeneral_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobGeneral = new global::JobService.Core.ViewModels.JobGeneralView();
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobGeneral>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobGeneral(jobGeneral);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobGeneral>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobReportGeneral_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobList = new global::JobService.Core.ViewModels.JobGeneralView()
            {
                JobId = 4004,
                DrAddressId = 94,
                JobName = "Trane",
                QualitySpecDescr = string.Empty
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportGeneral>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobReportGeneral(jobList);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportGeneral>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobReportGeneral_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobList = new global::JobService.Core.ViewModels.JobGeneralView()
            {
                JobId = 0,
                DrAddressId = 0,
                JobName = string.Empty,
                QualitySpecDescr = string.Empty
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportGeneral>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobReportGeneral(jobList);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportGeneral>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobAddress_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobList = new global::JobService.Core.ViewModels.JobAddressView()
            {
                JobId = 178456,
                DrAddressId = 94,
                DomesticInternationlInd = "I",
                Province = "FL",
                NonUsPostalCode = "33311",
                StreetAddress1 = "5100 Old Pearman Dairy Road",
                StreetAddress2 = "5100 Old Pearman Dairy Road",
                ZipCode = "29625",
                ZipPlus = string.Empty,
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobAddress>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobAddress(jobList);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobAddress>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobAddress_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobList = new global::JobService.Core.ViewModels.JobAddressView()
            {
                JobId = 0,
                DrAddressId = 0,
                DomesticInternationlInd = string.Empty,
                Province = string.Empty,
                NonUsPostalCode = string.Empty,
                StreetAddress1 = string.Empty,
                StreetAddress2 = string.Empty,
                ZipCode = string.Empty,
                ZipPlus = string.Empty,
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobAddress>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobAddress(jobList);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobAddress>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobIndicators_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobIndicator = new JobIndicatorView()
            {
                JobId = 10,
                DrAddressId = 94,
                AcousticsInd = "Y",
                HieffInd = "Y",
                LowTempAirInd = "Y",
                NationalAcctInd = "Y",
                PactInd = "Y",
                PenaltyJobInd = "Y",
                ServiceContractInd = "Y",
                StackedInd = "Y",
                TargetJobInd = "Y"
            };

            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportIndicator>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            bool result = await this.jobServiceUnderTest.UpdateJobIndicators(jobIndicator);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportIndicator>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobIndicators_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobIndicator = new JobIndicatorView()
            {
                JobId = 0,
                DrAddressId = 0,
                AcousticsInd = "N",
                HieffInd = "N",
                LowTempAirInd = "N",
                NationalAcctInd = "N",
                PactInd = "N",
                PenaltyJobInd = "N",
                ServiceContractInd = "N",
                StackedInd = "N",
                TargetJobInd = "N"
            };

            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportIndicator>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobIndicators(jobIndicator);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportIndicator>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobDates_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobdates = new JobDatesView()
            {
                JobId = 10,
                DrAddressId = 94,
                BidDate = DateTime.Now,
                SubmittalDateApproved = DateTime.Now,
                ReqProjectCompletionDate = DateTime.Now,
                StartUpDate = DateTime.Now
            };

            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportDates>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobDates(jobdates);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportDates>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobDates_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobdates = new JobDatesView()
            {
                JobId = 0,
                DrAddressId = 0,
                BidDate = DateTime.Now,
                SubmittalDateApproved = DateTime.Now,
                ReqProjectCompletionDate = DateTime.Now,
                StartUpDate = DateTime.Now
            };

            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportDates>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobDates(jobdates);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportDates>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobModifiedDate_ValidInput_ReturnsTrue()
        {
            // Arrange
            this.jobRepository.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobModifiedDate(this.jobId);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(this.jobId), Times.Once);
        }

        [Fact]
        public async Task UpdateJobModifiedDate_InvalidInput_ReturnsFalse()
        {
            // Arrange
            this.jobRepository.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobModifiedDate(this.jobId);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobFinancial_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobList = new global::JobService.Core.ViewModels.JobFinancialView()
            {
                JobId = 178456,
                DrAddressId = 94,
                EstEquipmentPrice = 3434,
                ContractTraneEquipDlrs = 3424,
                EstControlsPrice = 23455,
                ContractNonTraneEquipDlrs = 54654,
                ContractMargin = 6756,
                ContractTaxes = 5767,
                ContractSubContractDlrs = 768,
                ContractDirectJobExpenses = 56787
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobFinancial>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobFinancial(jobList);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobFinancial>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobFinancial_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobList = new global::JobService.Core.ViewModels.JobFinancialView()
            {
                JobId = 0,
                DrAddressId = 0,
                EstEquipmentPrice = 0,
                ContractTraneEquipDlrs = 0,
                EstControlsPrice = 0,
                ContractNonTraneEquipDlrs = 0,
                ContractMargin = 0,
                ContractTaxes = 0,
                ContractSubContractDlrs = 0,
                ContractDirectJobExpenses = 0
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobFinancial>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobFinancial(jobList);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobFinancial>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task DeleteNotes_ValidRequest_ReturnsDeletedCount()
        {
            // Arrange
            int deleteCount = 1;

            var notes = new global::JobService.Core.ViewModels.JobNotesView()
            {
                JobId = 178456,
                NoteString = "abc",
                DrAddressId = 94
            };
            this.jobRepository.Setup(x => x.DeleteNotes<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()))
                .Returns(Task.FromResult(deleteCount)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.DeleteNotes(notes);

            // Assert
            Assert.IsType<int>(result);
            Assert.True(result > 0);
            Assert.Equal(deleteCount, result);
            this.jobRepository.Verify(x => x.DeleteNotes<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()), Times.Once);
        }

        [Fact]
        public async Task DeleteNotes_InvalidRequest_ReturnsZero()
        {
            // Arrange
            int deleteCount = 0;

            var notes = new global::JobService.Core.ViewModels.JobNotesView()
            {
                JobId = 0,
                NoteString = "abc",
                DrAddressId = 0
            };
            this.jobRepository.Setup(x => x.DeleteNotes<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()))
                .Returns(Task.FromResult(deleteCount)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.DeleteNotes(notes);

            // Assert
            Assert.IsType<int>(result);
            Assert.False(result > 0);
            Assert.Equal(deleteCount, result);
            this.jobRepository.Verify(x => x.DeleteNotes<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()), Times.Once);
        }

        [Fact]
        public async Task InsertNotes_ValidInput_ReturnsTrue()
        {
            // Arrange
            var notes = new global::JobService.Core.ViewModels.JobNotesView()
            {
                JobId = 178456,
                NoteString = "Trane Test",
                DrAddressId = 94,
            };
            this.repository.Setup(x => x.InsertWithoutKeyAsync<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.InsertNotes(notes);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.InsertWithoutKeyAsync<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()), Times.Once);
        }

        [Fact]
        public async Task InsertNotes_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var notes = new global::JobService.Core.ViewModels.JobNotesView()
            {
                JobId = 0,
                NoteString = string.Empty,
                DrAddressId = 0,
            };
            this.repository.Setup(x => x.InsertWithoutKeyAsync<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()))
                .Returns(Task.FromResult(false));
            this.jobRepository.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.InsertNotes(notes);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.InsertWithoutKeyAsync<global::JobService.Core.Models.JobNotes>(It.IsAny<global::JobService.Core.Models.JobNotes>()), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task UpdateJobOfficeAndPeople_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobOfficeAndPeople = new JobOfficeAndPeopleView()
            {
                JobId = 123,
                JobReportId = 234,
                DrAddressId = 34,
                SalesOfficeId = 123,
                LocationOffice = 2,
                CommCode = "yuo",
                ControlsCommCode = "wer",
                TakeoffCommCode = "ypl",
                CrmOpportunityId = "bnm",
                JobContact = "ert"
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobOfficeAndPeople>(), It.IsAny<int>()))
                 .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobOfficeAndPeople(jobOfficeAndPeople);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobOfficeAndPeople>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobOfficeAndPeople_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobOfficeAndPeople = new JobOfficeAndPeopleView()
            {
                JobId = 0,
                JobReportId = 0,
                DrAddressId = 0,
                SalesOfficeId = 0,
                LocationOffice = 0,
                CommCode = string.Empty,
                ControlsCommCode = string.Empty,
                TakeoffCommCode = string.Empty,
                CrmOpportunityId = string.Empty,
                JobContact = string.Empty
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobOfficeAndPeople>(), It.IsAny<int>()))
                 .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobOfficeAndPeople(jobOfficeAndPeople);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobOfficeAndPeople>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobReportOfficeAndPeople_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobOfficeAndPeople = new JobOfficeAndPeopleView()
            {
                JobReportId = 234,
                DrAddressId = 34,
                ControlsCommCode = "wer",
                TakeoffCommCode = "ypl"
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportOfficeAndPeople>(), It.IsAny<int>()))
                 .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobReportOfficeAndPeople(jobOfficeAndPeople);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportOfficeAndPeople>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobReportOfficeAndPeople_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobOfficeAndPeople = new JobOfficeAndPeopleView()
            {
                JobReportId = 0,
                DrAddressId = 0,
                ControlsCommCode = string.Empty,
                TakeoffCommCode = string.Empty
            };
            this.jobRepository.Setup(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportOfficeAndPeople>(), It.IsAny<int>()))
                 .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateJobReportOfficeAndPeople(jobOfficeAndPeople);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobInfo(It.IsAny<global::JobService.Core.Models.JobReportOfficeAndPeople>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task InsertClassification_ValidInput_ReturnsTrue()
        {
            // Arrange
            int jobid = 178456;
            List<global::JobService.Core.ViewModels.JobClassificationView> jobClassificationView = new List<global::JobService.Core.ViewModels.JobClassificationView>
            {
                new global::JobService.Core.ViewModels.JobClassificationView()
                {
                    JobId = 178456,
                    DrAddressId = 94,
                },
            };
            this.jobRepository.Setup(x => x.BulkInsertQueryAsync(It.IsAny<IEnumerable<JobClassification>>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.InsertClassification(jobClassificationView, jobid);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.BulkInsertQueryAsync(It.IsAny<IEnumerable<JobClassification>>()), Times.Once);
        }

        [Fact]
        public async Task InsertClassification_InvalidInput_ReturnsFalse()
        {
            // Arrange
            List<global::JobService.Core.ViewModels.JobClassificationView> jobClassificationView = new List<global::JobService.Core.ViewModels.JobClassificationView>
            {
                new global::JobService.Core.ViewModels.JobClassificationView()
                {
                    JobId = this.invalidJobId,
                    DrAddressId = 0,
                },
            };
            this.jobRepository.Setup(x => x.BulkInsertQueryAsync(It.IsAny<IEnumerable<JobClassification>>()))
                .Returns(Task.FromResult(false));
            this.jobRepository.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.InsertClassification(jobClassificationView, this.invalidJobId);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.BulkInsertQueryAsync(It.IsAny<IEnumerable<JobClassification>>()), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task GetClassificationsbyJobId_ValidRequest_ReturnsValidData()
        {
            IEnumerable<JobClassificationView> jobClassification = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = 178456,
                    DrAddressId = 94,
                    ClassificationDescription = "Purchase Class",
                    DescriptionValues = "Test",
                    JobCodeId = 1,
                    JobClassId = 1
                },
                new JobClassificationView()
                {
                    JobId = 178457,
                    DrAddressId = 34,
                    ClassificationDescription = "Bidding Class",
                    DescriptionValues = "Test",
                    JobCodeId = 2,
                    JobClassId = 2
                }
            };

            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(It.IsAny<int>())).Returns(Task.FromResult(jobClassification)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetClassificationsByJobId(178456);

            // Assert
            Assert.Equal(2, result.Count());
            Assert.True(result.Select(a => a.JobId == 178456).Any());
            Assert.True(result.Select(a => a.ClassificationDescription == "Bidding Class").Any());
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetClassificationsbyJobId_InvalidRequest_ReturnsEmptyList()
        {
            IEnumerable<JobClassificationView> jobClassification = new List<JobClassificationView>();

            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(It.IsAny<int>())).Returns(Task.FromResult(jobClassification)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetClassificationsByJobId(10);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task DeleteClassifications_ValidRequest_ReturnsDeletedCount()
        {
            int deleteCount = 10;
            this.jobRepository.Setup(x => x.DeleteClassification(10)).Returns(Task.FromResult(deleteCount)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.DeleteClassification(10);

            // Assert
            Assert.True(result > 0);
            Assert.Equal(deleteCount, result);
            this.jobRepository.Verify(x => x.DeleteClassification(10), Times.Once);
        }

        [Fact]
        public async Task DeleteClassifications_InvalidRequest_ReturnsDeletedCount()
        {
            int deleteCount = 0;
            this.jobRepository.Setup(x => x.DeleteClassification(10)).Returns(Task.FromResult(deleteCount)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.DeleteClassification(10);

            // Assert
            Assert.False(result > 0);
            Assert.Equal(deleteCount, result);
            this.jobRepository.Verify(x => x.DeleteClassification(10), Times.Once);
        }

        [Fact]
        public async Task GetJobClassifications_ValidRequest_ReturnsValidData()
        {
            IEnumerable<JobClassificationView> jobClassification = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    DrAddressId = 94,
                    ClassificationDescription = "Purchase Class",
                    DescriptionValues = "Test",
                    JobCodeId = 1,
                    JobClassId = 1
                },
                new JobClassificationView()
                {
                    JobId = 178457,
                    DrAddressId = 34,
                    ClassificationDescription = "Bidding Class",
                    DescriptionValues = "Test",
                    JobCodeId = 2,
                    JobClassId = 2
                }
            };

            this.jobRepository.Setup(x => x.GetJobClassificationsAsync(It.IsAny<int>()))
                .Returns(Task.FromResult(jobClassification))
                .Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetJobClassifications(this.jobId);

            // Assert
            Assert.Equal(2, result.Count());
            Assert.Contains(result, a => a.JobId == this.jobId);
            Assert.Contains(result, a => a.DescriptionValues == "Test");
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetJobClassifications_InvalidRequest_ReturnsEmptyList()
        {
            IEnumerable<JobClassificationView> jobClassification = new List<JobClassificationView>();

            this.jobRepository.Setup(x => x.GetJobClassificationsAsync(It.IsAny<int>())).Returns(Task.FromResult(jobClassification)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetJobClassifications(10);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task InsertJobSysIndXref_ValidInput_ReturnsTrue()
        {
            // Arrange
            IEnumerable<JobSysIndXrefView> jobSysIndXrefView = new List<JobSysIndXrefView>()
            {
                new JobSysIndXrefView()
                {
                    JobId = this.jobId,
                    DrAddressId = this.drAddressId,
                }
            };
            this.jobRepository.Setup(x => x.BulkJobSysIndXrefInsertQueryAsync(It.IsAny<IEnumerable<JobSysIndXref>>()))
                .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.InsertJobSysIndXref(jobSysIndXrefView, this.jobId);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.BulkJobSysIndXrefInsertQueryAsync(It.IsAny<IEnumerable<JobSysIndXref>>()), Times.Once);
        }

        [Fact]
        public async Task InsertJobSysIndXref_InvalidInput_ReturnsFalse()
        {
            // Arrange
            IEnumerable<JobSysIndXrefView> jobSysIndXrefView = new List<JobSysIndXrefView>()
            {
                new JobSysIndXrefView()
                {
                    JobId = this.jobId,
                    DrAddressId = this.drAddressId,
                }
            };

            this.jobRepository.Setup(x => x.BulkJobSysIndXrefInsertQueryAsync(It.IsAny<IEnumerable<JobSysIndXref>>()))
                .Returns(Task.FromResult(false));
            this.jobRepository.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.InsertJobSysIndXref(jobSysIndXrefView, this.jobId);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.BulkJobSysIndXrefInsertQueryAsync(It.IsAny<IEnumerable<JobSysIndXref>>()), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task DeleteJobSysIndXref_ValidRequest_ReturnDeletedRows()
        {
            int? deleteCount = 10;
            this.jobRepository.Setup(x => x.DeleteJobSysIndXref(10)).Returns(Task.FromResult(deleteCount)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.DeleteJobSysIndXref(10);

            // Assert
            Assert.True(result > 0);
            Assert.Equal(deleteCount, result);
            this.jobRepository.Verify(x => x.DeleteJobSysIndXref(10), Times.Once);
        }

        [Fact]
        public async Task DeleteJobSysIndXref_InvalidRequest_ReturnZero()
        {
            int? deleteCount = 0;
            this.jobRepository.Setup(x => x.DeleteJobSysIndXref(10)).Returns(Task.FromResult(deleteCount)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.DeleteJobSysIndXref(10);

            // Assert
            Assert.False(result > 0);
            Assert.Equal(deleteCount, result);
            this.jobRepository.Verify(x => x.DeleteJobSysIndXref(10), Times.Once);
        }

        [Fact]
        public async Task GetJobSystemTypeList_ValidRequest_ReturnsValidData()
        {
            IEnumerable<SystemTypeViewModel> systemType = new List<SystemTypeViewModel>()
            {
                new SystemTypeViewModel()
                {
                SysTypeId = 8,
                Description = "Intelligent Variable Air System -Chilled water AHU"
                }
            };
            this.jobRepository.Setup(x => x.GetJobSystemTypeListAsync(It.IsAny<int>())).Returns(Task.FromResult(systemType)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetJobSystemTypeList(10);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.SysTypeId == 8).Any());
            Assert.True(result.Select(a => a.Description == "Intelligent Variable Air System -Chilled water AHU").Any());
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetJobSystemTypeList_InvalidRequest_ReturnsEmptyList()
        {
            IEnumerable<SystemTypeViewModel> systemType = new List<SystemTypeViewModel>();
            this.jobRepository.Setup(x => x.GetJobSystemTypeListAsync(It.IsAny<int>())).Returns(Task.FromResult(systemType)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetJobSystemTypeList(0);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetJobAllInfo_ValidRequest_ReturnsValidData()
        {
            // Arrange
            JobInfoViewModel jobInfo = Helper.GetJobInfoViewModel(this.jobId);
            IEnumerable<BidAlternateViewModel> bidAlternate = new List<BidAlternateViewModel>()
            {
                new BidAlternateViewModel()
                {
                    BidAlternateId = 166420,
                    JobId = 165009,
                    BaseBidYesNo = 1
                }
            };
            IEnumerable<ReferenceUnitViewModel> referenceUnit = new List<ReferenceUnitViewModel>()
            {
                new ReferenceUnitViewModel()
                {
                    ReferenceUnitId = 10449484,
                    JobId = 668341,
                    TagSequenceNbr = 1
                }
            };
            IEnumerable<JobProdXrefViewModel> jobProdXrefs = new List<JobProdXrefViewModel>()
            {
                new JobProdXrefViewModel()
                {
                    JobId = 1870831,
                    ProdFamilyId = 2006347,
                    CjShipQtr = 3
                }
            };
            IEnumerable<JobNoteViewModel> jobNotes = new List<JobNoteViewModel>()
            {
                new JobNoteViewModel()
                {
                    JobId = 251076,
                    NoteLine = "Testing",
                    SequenceNbr = 54362
                }
            };
            IEnumerable<ProdSelFamilyViewModel> prodSelFamily = new List<ProdSelFamilyViewModel>()
            {
                new ProdSelFamilyViewModel()
                {
                    JobId = this.jobId,
                    ProdFamilyId = 2000541
                }
            };
            IEnumerable<SelectionViewModel> selectionView = new List<SelectionViewModel>()
            {
                new SelectionViewModel()
                {
                    JobId = 251076,
                    SelectionId = 2737486
                }
            };
            IEnumerable<DocCompViewModel> docComp = new List<DocCompViewModel>()
            {
                new DocCompViewModel()
                {
                    SelectionId = 34,
                    DocCompId = 56
                }
            };
            IEnumerable<ProdSelModuleViewModel> prodSelModule = new List<ProdSelModuleViewModel>()
            {
                new ProdSelModuleViewModel()
                {
                    ProdSelUnitId = 2124276,
                    ProdSelModuleId = 8374922
                }
            };
            IEnumerable<ProdSelUnitViewModel> prodSelUnits = new List<ProdSelUnitViewModel>()
            {
                new ProdSelUnitViewModel()
                {
                    ProdSelUnitId = 2124276,
                    JobId = 25107
                }
            };
            IEnumerable<SelectionXrefViewModel> selectionXrefs = new List<SelectionXrefViewModel>()
            {
                new SelectionXrefViewModel()
                {
                    SelectionId = 3407640,
                    SelectionXrefId = 45465
                }
            };
            IEnumerable<SelectedModuleViewModel> selectedModule = new List<SelectedModuleViewModel>()
            {
                new SelectedModuleViewModel()
                {
                    SelectionId = 3407640,
                    SelectedModuleId = 35323
                }
            };
            IEnumerable<SelectedItemViewModel> selectedItem = new List<SelectedItemViewModel>()
            {
                new SelectedItemViewModel()
                {
                    SelectedItemId = 635476,
                    SelectedModuleId = 35323
                }
            };
            IEnumerable<SelectedPerfViewModel> selectedPerf = new List<SelectedPerfViewModel>()
            {
                new SelectedPerfViewModel()
                {
                    SelectedModuleId = 11287309,
                    VpfcId = 2020532
                }
            };
            IEnumerable<BidAlternateXrefViewModel> bidAlternateXrefs = new List<BidAlternateXrefViewModel>()
            {
                new BidAlternateXrefViewModel()
                {
                    SelectionId = 5984493,
                    BidAlternateXrefId = 20257059
                }
            };
            IEnumerable<ProdSelResultViewModel> prodSelResults = new List<ProdSelResultViewModel>()
            {
                new ProdSelResultViewModel()
                {
                    ProdSelResultId = 15816497,
                    ProdSelCriteriaId = 12349314
                }
            };
            IEnumerable<ProdSelCriteriaViewModel> prodSelCriteria = new List<ProdSelCriteriaViewModel>()
            {
                new ProdSelCriteriaViewModel()
                {
                    ProdSelModuleId = 8052,
                    ProdSelCriteriaId = 14580
                }
            };
            IEnumerable<ProdSelCriteriaItemViewModel> prodSelCriteriaItem = new List<ProdSelCriteriaItemViewModel>()
            {
                new ProdSelCriteriaItemViewModel()
                {
                    ProdSelCriteriaId = 15651618,
                    ProdSelFieldId = 7989
                }
            };
            IEnumerable<ProdSelMessageViewModel> prodSelMessage = new List<ProdSelMessageViewModel>()
            {
                new ProdSelMessageViewModel()
                {
                    ProdSelCriteriaId = 15652146,
                    ProdSelMessageId = 1198717
                }
            };
            IEnumerable<JobVariationViewModel> variations = new List<JobVariationViewModel>()
            {
                new JobVariationViewModel()
                {
                    VariationId = 3616,
                    NetPrice = 4860,
                    VariationType = "L",
                    ShortDesc = "ATSC",
                    VariationProdCode = 5119,
                    JobId = 17899,
                    LbrTaxExempt = "A",
                    LbrTaxExemptApproval = "Y",
                    LbrTaxExemptDolAmt = 6832,
                    LbrLocalWarrantyDescr = "N",
                    MatlQty = 673,
                    MatlExtendedCost = 6722,
                    MatlMarkupMultiplier = 5869,
                    VariationStatusDate = DateTime.Now,
                    ProviderName = "STBY",
                    SelectionId = 477,
                    VariationBillingMethodCode = "BY",
                    LegacyOrdNbr = "ASC",
                    HqtrVariationId = 578,
                    SalesOrdId = 7689,
                    SelectionInvcWithId = 4677,
                    ReviseDate = DateTime.Now,
                    HostUpdateInd = "GH",
                    InsertDate = DateTime.Now,
                    ProdCode = "AST",
                    LanVariationId = 689,
                    PendingOrderInd = "DES",
                    ProductId = 5776,
                    VendorId = 473
                }
            };
            IEnumerable<SelectionDesignAuthViewModel> designAuths = new List<SelectionDesignAuthViewModel>()
            {
                new SelectionDesignAuthViewModel()
                {
                    DesignAuthId = 701,
                    SeparateCreditJob = "0",
                    SelectionId = 20205,
                    ShortDesignDescr = "Provide Baldor Inverter Duty Motors clas",
                    SpecialSubmittalReqr = 575,
                    OneTimeDesignCharge = 4667,
                    NetPriceAdd = 6767,
                    StandardCostAdd = 4635,
                    QtyPerUnit = 656,
                    SiId = 434,
                    UnadjustedBasePriceAdd = 3278,
                    VpcId = 343,
                    ReqsDate = DateTime.Now,
                    ApproveBy = "GET",
                    ApproveDate = DateTime.Now,
                    ExpireDate = DateTime.Now,
                    ReleaseDateReqd = DateTime.Now,
                    SiSub = 124,
                    OpRuleId = 345,
                    CycleAdd = "TRE",
                    OrdLineType = "ASC",
                    DesignSpaNbr = "DES",
                    ReviseDate = DateTime.Now,
                    HqtrDesignAuthId = 435,
                    HostUpdateInd = "ATV",
                    SelectedModuleId = 466,
                    InsertDate = DateTime.Now,
                    LanDesignAuthId = 299
                }
            };
            IEnumerable<DesignAuthNoteViewModel> designAuthNotes = new List<DesignAuthNoteViewModel>()
            {
                new DesignAuthNoteViewModel()
                {
                    DesignAuthId = 701,
                    HostUpdateInd = null,
                    SequenceNbr = 1,
                    InsertDate = DateTime.Now
                }
            };
            IEnumerable<SelectionNoteViewModel> selectionNotes = new List<SelectionNoteViewModel>()
            {
                new SelectionNoteViewModel()
                {
                    SelectionId = 1470,
                    SequenceNbr = 1,
                    NoteLine = "THE COVER TAGGED TYPE A MUST HAVE THE RETURN LINE HANGER WELDED INSIDE",
                    HostUpdateInd = "Y",
                    InsertDate = DateTime.Now
                }
            };
            this.jobRepository.Setup(x => x.GetJobInfoAsync(It.IsAny<int>())).Returns(Task.FromResult(jobInfo));
            this.jobRepository.Setup(x => x.GetJobBidAlternateListAsync(It.IsAny<int>())).Returns(Task.FromResult(bidAlternate));
            this.jobRepository.Setup(x => x.GetReferenceUnitListAsync(It.IsAny<int>())).Returns(Task.FromResult(referenceUnit));
            this.jobRepository.Setup(x => x.GetJobProdXrefListAsync(It.IsAny<int>())).Returns(Task.FromResult(jobProdXrefs));
            this.jobRepository.Setup(x => x.GetJobNoteListAsync(It.IsAny<int>())).Returns(Task.FromResult(jobNotes));
            this.jobRepository.Setup(x => x.GetProdSelFamilyListAsync(It.IsAny<int>())).Returns(Task.FromResult(prodSelFamily));
            this.jobRepository.Setup(x => x.GetJobSelectionListAsync(It.IsAny<int>())).Returns(Task.FromResult(selectionView));
            this.jobRepository.Setup(x => x.GetJobSelectionDocCompListAsync(It.IsAny<int>())).Returns(Task.FromResult(docComp));
            this.jobRepository.Setup(x => x.GetJobProdSelUnitListAsync(It.IsAny<int>())).Returns(Task.FromResult(prodSelUnits));
            this.jobRepository.Setup(x => x.GetJobProdSelUnitModuleListAsync(It.IsAny<int>())).Returns(Task.FromResult(prodSelModule));
            this.jobRepository.Setup(x => x.GetJobSelectionXrefListAsync(It.IsAny<int>())).Returns(Task.FromResult(selectionXrefs));
            this.jobRepository.Setup(x => x.GetJobSelectedModuleListAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedModule));
            this.jobRepository.Setup(x => x.GetJobSelectedModuleItemListAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedItem));
            this.jobRepository.Setup(x => x.GetJobSelectedPerfListAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedPerf));
            this.jobRepository.Setup(x => x.GetJobBidAlternateXrefListAsync(It.IsAny<int>())).Returns(Task.FromResult(bidAlternateXrefs));
            this.jobRepository.Setup(x => x.GetProdSelResultListAsync(It.IsAny<int>())).Returns(Task.FromResult(prodSelResults));
            this.jobRepository.Setup(x => x.GetJobProdSelCriteriaListAsync(It.IsAny<int>())).Returns(Task.FromResult(prodSelCriteria));
            this.jobRepository.Setup(x => x.GetJobProdSelCriteriaItemListAsync(It.IsAny<int>())).Returns(Task.FromResult(prodSelCriteriaItem));
            this.jobRepository.Setup(x => x.GetProdSelMessageListAsync(It.IsAny<int>())).Returns(Task.FromResult(prodSelMessage));
            this.jobRepository.Setup(x => x.GetVariationListAsync(It.IsAny<int>())).Returns(Task.FromResult(variations));
            this.jobRepository.Setup(x => x.GetDesignAuthListAsync(It.IsAny<int>())).Returns(Task.FromResult(designAuths));
            this.jobRepository.Setup(x => x.GetDesignAuthNoteListAsync(It.IsAny<int>())).Returns(Task.FromResult(designAuthNotes));
            this.jobRepository.Setup(x => x.GetSelectionNoteListAsync(It.IsAny<int>())).Returns(Task.FromResult(selectionNotes));

            // Act
            var result = await this.jobServiceUnderTest.GetJobAllInfo(this.jobId);

            // Assert
            Assert.NotNull(result);
            this.jobRepository.Verify(x => x.GetJobInfoAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobBidAlternateListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetReferenceUnitListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobProdXrefListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobNoteListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetProdSelFamilyListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSelectionListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSelectionDocCompListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobProdSelUnitListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobProdSelUnitModuleListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSelectionXrefListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSelectedModuleListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSelectedModuleItemListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSelectedPerfListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobBidAlternateXrefListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetProdSelResultListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobProdSelCriteriaListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobProdSelCriteriaItemListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetProdSelMessageListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetVariationListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetDesignAuthListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetDesignAuthNoteListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSelectionNoteListAsync(this.jobId), Times.Once);
        }

        [Fact]
        public async Task GetJobAllInfo_InvalidRequest_ReturnsEmptyData()
        {
            // Arrange
            JobInfoViewModel jobInfo = null;
            this.jobRepository.Setup(x => x.GetJobInfoAsync(It.IsAny<int>())).Returns(Task.FromResult(jobInfo));

            // Act
            var result = await this.jobServiceUnderTest.GetJobAllInfo(this.jobId);

            // Assert
            Assert.Null(result);
            this.jobRepository.Verify(x => x.GetJobInfoAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobBidAlternateListAsync(It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task GetRoleType_ReturnsValidData()
        {
            // Arrange
            IEnumerable<RoleTypeViewModel> roleTypeList = new List<RoleTypeViewModel>
            {
                new RoleTypeViewModel()
                {
                    RoleTypeId = "1",
                    RoleTypeName = "Owner"
                },
                new RoleTypeViewModel()
                {
                    RoleTypeId = "2",
                    RoleTypeName = "Architect"
                }
            };

            this.jobRepository.Setup(x => x.GetRoleTypeListAsync())
                .Returns(Task.FromResult(roleTypeList)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetRoleTypeList();

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 2);
            Assert.True(result.Any(a => a.RoleTypeId == "1"));
            Assert.True(result.Any(a => a.RoleTypeName == "Owner"));
            this.jobRepository.Verify(x => x.GetRoleTypeListAsync(), Times.Once);
        }

        /// <summary>
        ///  Get Role Type List
        /// </summary>
        /// <returns>Empty result</returns>
        [Fact]
        public async Task GetRoleType_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<RoleTypeViewModel> roleTypeList = new List<RoleTypeViewModel>();

            this.jobRepository.Setup(x => x.GetRoleTypeListAsync())
                .Returns(Task.FromResult(roleTypeList));

            // Act
            var result = await this.jobServiceUnderTest.GetRoleTypeList();

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify(x => x.GetRoleTypeListAsync(), Times.Once);
        }

        /// <summary>
        /// Get price auth info using valid input returns price auth id
        /// </summary>
        /// <returns>Price auth id</returns>
        [Fact]
        public async Task GetPriceAuthInfo_ValidInput_ReturnsPriceAuthId()
        {
            // Arrange
            int priceAuthId = 1082226;

            this.jobRepository.Setup(x => x.GetPriceAuthInfo(It.IsAny<int>())).Returns(Task.FromResult(priceAuthId));

            // Act
            var result = await this.jobServiceUnderTest.GetPriceAuthInfo(this.jobId);

            // Assert
            Assert.IsType<int>(result);
            Assert.Equal(result, priceAuthId);
            this.jobRepository.Verify(x => x.GetPriceAuthInfo(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get price auth info using valid input returns price auth id as 0
        /// </summary>
        /// <returns>Price auth id</returns>
        [Fact]
        public async Task GetPriceAuthInfo_ValidInput_ReturnsZero()
        {
            // Arrange
            int priceAuthId = 0;

            this.jobRepository.Setup(x => x.GetPriceAuthInfo(It.IsAny<int>())).Returns(Task.FromResult(priceAuthId));

            // Act
            var result = await this.jobServiceUnderTest.GetPriceAuthInfo(this.jobId);

            // Assert
            Assert.IsType<int>(result);
            Assert.Equal(result, priceAuthId);
            this.jobRepository.Verify(x => x.GetPriceAuthInfo(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get SPA deadline using valid request - returns SPA deadline
        /// </summary>
        /// <returns>SPA deadline</returns>
        [Fact]
        public async Task GetSPADealine_ValidRequest_ReuturnSPADeadline()
        {
            // Assign
            var spaDeadlineView = new SpaDeadline()
            {
                ShipQtr = 4,
                ShipYear = 2020
            };

            this.jobRepository.Setup(x => x.GetSPADeadline(It.IsAny<int>())).Returns(Task.FromResult(spaDeadlineView));

            // Act
            var spaDeadline = await this.jobServiceUnderTest.GetSPADeadline(this.jobId);

            // Assert
            Assert.IsType<SpaDeadlineViewModel>(spaDeadline);
            Assert.NotNull(spaDeadline);
            Assert.Equal(spaDeadline.ShipQtr, spaDeadlineView.ShipQtr);
            Assert.Equal(spaDeadline.ShipYear, spaDeadlineView.ShipYear);
            this.jobRepository.Verify(x => x.GetSPADeadline(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get SPA deadline using invalid request - returns empty
        /// </summary>
        /// <returns>No records</returns>
        [Fact]
        public async Task GetSPADeadline_InvalidRequest_ReturnEmpty()
        {
            // Assign
            SpaDeadline spaDeadline = null;

            this.jobRepository.Setup(x => x.GetSPADeadline(It.IsAny<int>())).Returns(Task.FromResult(spaDeadline));

            // Act
            var spaDeadlineResult = await this.jobServiceUnderTest.GetSPADeadline(this.invalidJobId);

            // Assert
            Assert.Null(spaDeadlineResult);
            this.jobRepository.Verify(x => x.GetSPADeadline(this.invalidJobId), Times.Once);
        }

        /// <summary>
        /// Get SPA using valid job id - returns SPA
        /// </summary>
        /// <returns>SPA</returns>
        [Fact]
        public async Task GetSPAByJobId_ValidRequest_ReuturnSPA()
        {
            // Assign
            var spa = "10-00359";

            this.jobRepository.Setup(x => x.GetSPAQuery(It.IsAny<int>())).Returns(Task.FromResult(spa));

            // Act
            var result = await this.jobServiceUnderTest.GetSPAByJobId(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(spa, result);
            this.jobRepository.Verify(x => x.GetSPAQuery(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get job locked user details based on valid job Id
        /// </summary>
        /// <returns>Locked user details</returns>
        [Fact]
        public async Task GetJobLockedUserDetails_ValidRequest_ReuturnUserDetails()
        {
            // Assign
            var userView = new global::JobService.Core.ViewModels.JobLockedUserView()
            {
                UserId = "lalcj",
                FirstName = "David",
                LastName = "Harper",
                UserName = "Harper, David",
            };

            this.jobRepository.Setup(x => x.GetJobLockedUserDetailsAsync(It.IsAny<int>())).Returns(Task.FromResult(userView));

            // Act
            var result = await this.jobServiceUnderTest.GetJobLockedUserDetails(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(userView, result);
            this.jobRepository.Verify(x => x.GetJobLockedUserDetailsAsync(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get job locked user details using invalid request - returns empty
        /// </summary>
        /// <returns>No records</returns>
        [Fact]
        public async Task GetJobLockedUserDetails_InvalidRequest_ReturnEmpty()
        {
            // Assign
            JobLockedUserView userView = null;

            this.jobRepository.Setup(x => x.GetJobLockedUserDetailsAsync(It.IsAny<int>())).Returns(Task.FromResult(userView));

            // Act
            var result = await this.jobServiceUnderTest.GetJobLockedUserDetails(this.invalidJobId);

            // Assert
            Assert.Null(result);
            this.jobRepository.Verify(x => x.GetJobLockedUserDetailsAsync(this.invalidJobId), Times.Once);
        }

        [Fact]
        public async Task GetCommercialLaborRate_Request_ReturnsDecimal()
        {
            // Assign
            decimal laborRate = 12.34M;

            this.jobRepository.Setup(x => x.GetCommercialLaborRateAsync(It.IsAny<int>())).Returns(Task.FromResult(laborRate));

            // Act
            decimal result = await this.jobServiceUnderTest.GetCommercialLaborRate(this.jobId);

            // Assert
            Assert.Equal(laborRate, result);
            this.jobRepository.Verify(x => x.GetCommercialLaborRateAsync(this.jobId), Times.Once);
        }

        [Fact]
        public async Task GetDesignAuths_NullResult_ReturnsEmpty()
        {
            // Arrange
            this.jobRepository.Setup(x => x.GetDesignAuths(It.IsAny<int>())).Returns(Task.FromResult<IEnumerable<DesignAuth>>(null)).Verifiable();

            // Act
            IEnumerable<DesignAuthViewModel> result = await this.jobServiceUnderTest.GetDesignAuths(this.jobId);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetDesignAuths_EmptyResult_ReturnsEmpty()
        {
            // Arrange
            this.jobRepository.Setup(x => x.GetDesignAuths(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<DesignAuth>())).Verifiable();

            // Act
            IEnumerable<DesignAuthViewModel> result = await this.jobServiceUnderTest.GetDesignAuths(this.jobId);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetDesignAuths_ListResult_ReturnsList()
        {
            // Arrange
            DesignAuth designAuth = new DesignAuth()
            {
                DESIGN_AUTH_ID = 2,
                SELECTION_ID = 1,
                SHORT_DESIGN_DESCR = "test",
                VPC_ID = 2,
                DESIGN_SPA_NBR = "XYZ-123",
                HQTR_DESIGN_AUTH_ID = 212,
                PROD_FAMILY_ID = 001,
                REVISE_DATE = new DateTime(2015, 01, 01),
                SI_ID = 123
            };
            this.jobRepository.Setup(x => x.GetDesignAuths(It.IsAny<int>())).Returns(
                Task.FromResult(new List<DesignAuth>() { designAuth }.AsEnumerable())).Verifiable();

            // Act
            IEnumerable<DesignAuthViewModel> result = await this.jobServiceUnderTest.GetDesignAuths(this.jobId);

            // Assert
            Assert.Single(result);
            DesignAuthViewModel firstResult = result.First();
            Assert.Equal(designAuth.DESIGN_AUTH_ID, firstResult.DesignAuthId);
            Assert.Equal(designAuth.SELECTION_ID, firstResult.SelectionId);
            Assert.Equal(designAuth.SHORT_DESIGN_DESCR, firstResult.Description);
            Assert.Equal(designAuth.VPC_ID, firstResult.VpcId);
            Assert.Equal(designAuth.DESIGN_SPA_NBR, firstResult.DesignSpaNumber);
            Assert.Equal(designAuth.HQTR_DESIGN_AUTH_ID, firstResult.HqtrDesignAuthId);
            Assert.Equal(designAuth.PROD_FAMILY_ID, firstResult.ProdFamilyId);
            Assert.Equal(designAuth.REVISE_DATE, firstResult.ReviseDate);
            Assert.Equal(designAuth.SI_ID, firstResult.SIId);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetVariations_NoVariations_ReturnsEmptyList()
        {
            // Arrange
            this.jobRepository.Setup(r => r.GetVariationsAsync(It.IsAny<int>()))
                .Returns(Task.FromResult(Enumerable.Empty<Variation>()));

            // Act
            IEnumerable<VariationViewModel> result = await this.jobServiceUnderTest.GetVariations(this.jobId);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify(r => r.GetVariationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(r => r.GetVariationReferenceUnitsAsync(It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task GetVariations_HasVariationsNoTags_ReturnsVariations()
        {
            // Arrange
            Variation sampleVariation = new Variation()
            {
                DESCRIPTION = "JobLevelExample",
                VARIATION_TYPE = "M",
                SELECTION_ID = null,
                VARIATION_ID = 1,
                REVISE_DATE = new DateTime(2010, 01, 01),
                VENDOR_ID = 900,
                PRODUCT_ID = 0986,
                PROD_CODE = "778",
                SALES_ORD_ID = 1
            };
            IEnumerable<Variation> sampleVariations = new Variation[] { sampleVariation };
            this.jobRepository.Setup(r => r.GetVariationsAsync(It.IsAny<int>()))
                .Returns(Task.FromResult(sampleVariations));

            // Act
            IEnumerable<VariationViewModel> result = await this.jobServiceUnderTest.GetVariations(this.jobId);

            // Assert
            Assert.NotEmpty(result);
            VariationViewModel firstResult = result.First();
            Assert.Equal(sampleVariation.VARIATION_ID, firstResult.VariationId);
            Assert.Equal(sampleVariation.VARIATION_TYPE, firstResult.VariationType);
            Assert.Equal(sampleVariation.SELECTION_ID, firstResult.SelectionId);
            Assert.Equal(sampleVariation.DESCRIPTION, firstResult.Description);
            Assert.Equal(sampleVariation.REVISE_DATE, firstResult.ReviseDate);
            Assert.Equal(sampleVariation.VENDOR_ID, firstResult.VendorId);
            Assert.Equal(sampleVariation.PROD_CODE, firstResult.ProdCode);
            Assert.Equal(sampleVariation.PRODUCT_ID, firstResult.ProductId);
            Assert.Empty(firstResult.Tags);
            Assert.Equal(sampleVariation.SALES_ORD_ID, firstResult.SalesOrderId);
            this.jobRepository.Verify(r => r.GetVariationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(r => r.GetVariationReferenceUnitsAsync(this.jobId), Times.Once);
        }

        [Fact]
        public async Task GetVariations_HasVariationsAndTags_ReturnsBoth()
        {
            // Arrange
            Variation sampleVariation1 = new Variation()
            {
                DESCRIPTION = "JobLevelExample",
                SELECTION_ID = null,
                VARIATION_ID = 1,
                QUANTITY = 5,
                REVISE_DATE = new DateTime(2010, 01, 01),
                VENDOR_ID = 900,
                PRODUCT_ID = 0986,
                PROD_CODE = "778"
            };
            Variation sampleVariation2 = new Variation()
            {
                DESCRIPTION = "JobLevelExample",
                SELECTION_ID = 333,
                VARIATION_ID = 2,
                QUANTITY = 8675309,
                REVISE_DATE = new DateTime(2010, 05, 06),
                VENDOR_ID = 901,
                PRODUCT_ID = 0987,
                PROD_CODE = "009"
            };
            IEnumerable<Variation> sampleVariations = new Variation[] { sampleVariation1, sampleVariation2 };
            this.jobRepository.Setup(r => r.GetVariationsAsync(It.IsAny<int>()))
                .Returns(Task.FromResult(sampleVariations));
            VariationReferenceUnit sampleTag1 = new VariationReferenceUnit() { TAG = "Tag1", VARIATION_ID = 2, TAG_SEQUENCE_NBR = 3 };
            VariationReferenceUnit sampleTag2 = new VariationReferenceUnit() { TAG = "Tag2", VARIATION_ID = 1, TAG_SEQUENCE_NBR = 4 };
            VariationReferenceUnit sampleTag3 = new VariationReferenceUnit() { TAG = "Tag3", VARIATION_ID = 1, TAG_SEQUENCE_NBR = 5 };
            IEnumerable<VariationReferenceUnit> sampleTags = new VariationReferenceUnit[] { sampleTag1, sampleTag2, sampleTag3 };
            this.jobRepository.Setup(r => r.GetVariationReferenceUnitsAsync(It.IsAny<int>()))
                .Returns(Task.FromResult(sampleTags));

            // Act
            IEnumerable<VariationViewModel> result = await this.jobServiceUnderTest.GetVariations(this.jobId);

            // Assert
            Assert.NotEmpty(result);
            VariationViewModel firstResult = result.First();
            Assert.Equal(sampleVariation1.VARIATION_ID, firstResult.VariationId);
            Assert.Equal(sampleVariation1.SELECTION_ID, firstResult.SelectionId);
            Assert.Equal(sampleVariation1.DESCRIPTION, firstResult.Description);
            Assert.Equal(sampleVariation1.QUANTITY, firstResult.Quantity);
            Assert.Equal(sampleVariation1.REVISE_DATE, firstResult.ReviseDate);
            Assert.Equal(sampleVariation1.VENDOR_ID, firstResult.VendorId);
            Assert.Equal(sampleVariation1.PROD_CODE, firstResult.ProdCode);
            Assert.Equal(sampleVariation1.PRODUCT_ID, firstResult.ProductId);
            Assert.Equal(2, firstResult.Tags.Count());
            Assert.Equal(sampleTag2.TAG, firstResult.Tags.First().Name);
            Assert.Equal(sampleTag2.TAG_SEQUENCE_NBR, firstResult.Tags.First().SequenceNumber);
            Assert.Equal(sampleTag3.TAG, firstResult.Tags.Last().Name);
            Assert.Equal(sampleTag3.TAG_SEQUENCE_NBR, firstResult.Tags.Last().SequenceNumber);
            VariationViewModel lastResult = result.Last();
            Assert.Equal(sampleVariation2.VARIATION_ID, lastResult.VariationId);
            Assert.Equal(sampleVariation2.SELECTION_ID, lastResult.SelectionId);
            Assert.Equal(sampleVariation2.DESCRIPTION, lastResult.Description);
            Assert.Equal(sampleVariation2.QUANTITY, lastResult.Quantity);
            Assert.Equal(sampleVariation2.REVISE_DATE, lastResult.ReviseDate);
            Assert.Equal(sampleVariation2.VENDOR_ID, lastResult.VendorId);
            Assert.Equal(sampleVariation2.PROD_CODE, lastResult.ProdCode);
            Assert.Equal(sampleVariation2.PRODUCT_ID, lastResult.ProductId);
            Assert.Single(lastResult.Tags);
            Assert.Equal(sampleTag1.TAG, lastResult.Tags.First().Name);
            Assert.Equal(sampleTag1.TAG_SEQUENCE_NBR, lastResult.Tags.First().SequenceNumber);

            this.jobRepository.Verify(r => r.GetVariationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(r => r.GetVariationReferenceUnitsAsync(this.jobId), Times.Once);
        }

        /// <summary>
        /// Gets the job coordination data for valid job id and coordination id
        /// </summary>
        /// <returns>Job coordination details</returns>
        [Fact]
        public async Task GetJobDataForCoordination_HasJobDetails_ReturnsJobCoordinationData()
        {
            // Arrange
            int coordinationId = 12;
            JobGeneralInfoModel jobDetails = Helper.GetJobGeneralInfoForCoordination();
            JobNotes jobNotes = Helper.GetJobNotes();
            JobCoordinationHistory jobCoordinationHistory = Helper.GetJobCoordinationHistory();
            JobCoordinationAggregateViewModel jobCoordinationAggregate = Helper.GetJobDataForCoordination();
            byte[] submissionNotes = Helper.GetSubmissionNotes();

            this.jobRepository.Setup(x => x.GetJobGeneralInfoForCoordination(It.IsAny<int>())).Returns(Task.FromResult(jobDetails));
            this.jobRepository.Setup(x => x.GetJobNotesForCoordination(It.IsAny<int>())).Returns(Task.FromResult(jobNotes));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(submissionNotes));
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(jobCoordinationHistory));

            // Act
            var result = await this.jobServiceUnderTest.GetJobDataForCoordination(this.jobId, coordinationId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result.JobCoordinationGeneralInfo.JobContact, jobDetails.JOB_CONTACT);
            Assert.Equal(result.JobCoordinationGeneralInfo.CommissionCode, jobDetails.COMM_CODE);
            Assert.Equal(result.JobNotes.NoteString, jobNotes.NOTE_LINE);
            Assert.Equal(result.SubmissionNotes.NoteLine, Encoding.UTF8.GetString(submissionNotes));
            Assert.Equal(result.CoordinationData.RequestedDate, jobCoordinationAggregate.JobCoordinationGeneralInfo.RequestedDate);
            Assert.Equal(result.CoordinationData.BidDetails.First().BidAlternateId, jobCoordinationAggregate.CoordinationData.BidDetails.First().BidAlternateId);
            Assert.Equal(result.CoordinationData.CommissionCode, jobCoordinationAggregate.JobCoordinationGeneralInfo.CommissionCode);
            Assert.Equal(result.CoordinationData.SubmissionNotes, jobCoordinationAggregate.CoordinationData.SubmissionNotes);
            Assert.Equal(result.CoordinationData.BillOfMaterials.First().SpecifiedUser, jobCoordinationAggregate.CoordinationData.BillOfMaterials.First().SpecifiedUser);
            Assert.Equal(result.CoordinationData.Documents.First().DocumentKey, jobCoordinationAggregate.CoordinationData.Documents.First().DocumentKey);
            this.jobRepository.Verify(x => x.GetJobGeneralInfoForCoordination(It.IsAny<int>()), Times.Once);
            this.jobRepository.Verify(x => x.GetJobNotesForCoordination(It.IsAny<int>()), Times.Once);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// Gets the job coordination data for job id and coordination id
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetJobDataForCoordination_ValidInput_ReturnsNull()
        {
            // Arrange
            int coordinationId = 12;
            JobGeneralInfoModel jobDetails = null;
            this.jobRepository.Setup(x => x.GetJobGeneralInfoForCoordination(It.IsAny<int>())).Returns(Task.FromResult(jobDetails));

            // Act
            var result = await this.jobServiceUnderTest.GetJobDataForCoordination(this.jobId, coordinationId);

            // Assert
            Assert.Null(result);
            this.jobRepository.Verify(x => x.GetJobGeneralInfoForCoordination(It.IsAny<int>()), Times.Once);
            this.jobRepository.Verify(x => x.GetJobNotesForCoordination(It.IsAny<int>()), Times.Never);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>()), Times.Never);
            this.jobRepository.Verify(x => x.GetCoordinationData(It.IsAny<int>()), Times.Never);
        }

        /// <summary>
        /// Gets the default job validation data for coordination
        /// </summary>
        /// <returns>Default job validation data for coordination</returns>
        [Fact]
        public async Task GetCoordinationValidation_EmptySetup_ReturnsDefaults()
        {
            // Arrange
            IEnumerable<string> excludedCoordinationStatuses = new List<string>() { JobsUpdateStatus.NotSubmittedStatus };

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.HasAllDefinedClassifications);
            Assert.False(result.HasAnyEarthwiseSystems);
            Assert.False(result.HasCoordinatedRecords);
            this.jobRepository.Verify(x => x.GetJobClassificationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSystemTypeListAsync(this.jobId), Times.Once);
            this.jobCoordinationRepository.Verify(x => x.DoesJobCoordinatedRecordExist(this.jobId, excludedCoordinationStatuses), Times.Once);
        }

        /// <summary>
        /// Gets the job validation data for coordination (no coordinated records)
        /// </summary>
        /// <returns>Job validation data for coordination (no coordinated records)</returns>
        [Fact]
        public async Task GetCoordinationValidation_HasNoCoordinatedRecords_ReturnsFalseForHasCoordinatedRecords()
        {
            // Arrange
            IEnumerable<string> coordinationStatuses = new List<string>() { "Not Submitted" };
            this.jobCoordinationRepository.Setup(x => x.DoesJobCoordinatedRecordExist(It.IsAny<int>(), coordinationStatuses)).Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.False(result.HasCoordinatedRecords);
            this.jobCoordinationRepository.Verify(x => x.DoesJobCoordinatedRecordExist(this.jobId, coordinationStatuses), Times.Once);
        }

        /// <summary>
        /// Gets the job validation data for coordination (has all defined classifications)
        /// </summary>
        /// <returns>Job validation data for coordination (has all defined classifications)</returns>
        [Fact]
        public async Task GetCoordinationValidation_AllSelectedClassifications_ReturnsAllDefinedClassifications()
        {
            // Arrange
            IEnumerable<JobClassificationView> allJobClassificationViews = Helper.GetAllJobClassificationViews(this.jobId);
            IEnumerable<JobClassificationView> selectedClassificationViews = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 123,
                    DescriptionValues = "Purchaser Class",
                    JobCodeId = 111,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 111,
                            Description = "Controls Subcontractor"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 222,
                            Description = "Service Subcontractor"
                        }
                    }
                },
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 456,
                    DescriptionValues = "Building Class",
                    JobCodeId = 555,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 555,
                            Description = "Industrial"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 666,
                            Description = "Hospital"
                        }
                    }
                }
            };
            this.jobRepository.Setup(x => x.GetJobClassificationsAsync(It.IsAny<int>())).Returns(Task.FromResult(allJobClassificationViews));
            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedClassificationViews));

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.HasAllDefinedClassifications);
            this.jobRepository.Verify(x => x.GetJobClassificationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(this.jobId), Times.Once);
        }

        /// <summary>
        /// Gets the job validation data for coordination (missing subset of classifications)
        /// </summary>
        /// <returns>Job validation data for coordination (missing subset of classifications)</returns>
        [Fact]
        public async Task GetCoordinationValidation_SubsetSelectedClassification_ReturnsMissingClassifications()
        {
            // Arrange
            IEnumerable<JobClassificationView> allJobClassificationViews = Helper.GetAllJobClassificationViews(this.jobId);
            IEnumerable<JobClassificationView> selectedClassificationViews = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 123,
                    DescriptionValues = "Purchaser Class",
                    JobCodeId = 111,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 111,
                            Description = "Controls Subcontractor"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 222,
                            Description = "Service Subcontractor"
                        }
                    }
                }
            };
            this.jobRepository.Setup(x => x.GetJobClassificationsAsync(It.IsAny<int>())).Returns(Task.FromResult(allJobClassificationViews));
            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedClassificationViews));

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.HasAllDefinedClassifications);
            this.jobRepository.Verify(x => x.GetJobClassificationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(this.jobId), Times.Once);
        }

        /// <summary>
        /// Gets the job validation data for coordination (has earthwise system)
        /// </summary>
        /// <returns>Job validation data for coordination (has earthwise system)</returns>
        [Fact]
        public async Task GetCoordinationValidation_JobHasEarthwiseSystem_ReturnsHasAnyEarthwiseSystem()
        {
            // Arrange
            IEnumerable<SystemTypeViewModel> systemTypes = new List<SystemTypeViewModel>()
            {
                new SystemTypeViewModel()
                {
                    IsChecked = false,
                    Description = "Trane Ice-enhanced Air-cooled Chiller Plant"
                },
                new SystemTypeViewModel()
                {
                    IsChecked = true,
                    Description = "Trane Central Geo-thermal Chilled Water System"
                },
            };
            this.jobRepository.Setup(x => x.GetJobSystemTypeListAsync(It.IsAny<int>())).Returns(Task.FromResult(systemTypes));

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.HasAnyEarthwiseSystems);
            this.jobRepository.Verify(x => x.GetJobSystemTypeListAsync(this.jobId), Times.Once);
        }

        /// <summary>
        /// Gets the job validation data for coordination (no earthwise system)
        /// </summary>
        /// <returns>Job validation data for coordination (no earthwise system)</returns>
        [Fact]
        public async Task GetCoordinationValidation_JobHasNoEarthwiseSystem_ReturnsNoEarthwiseSystem()
        {
            // Arrange
            IEnumerable<SystemTypeViewModel> systemTypes = new List<SystemTypeViewModel>()
            {
                new SystemTypeViewModel()
                {
                    IsChecked = false,
                    Description = "Trane Ice-enhanced Air-cooled Chiller Plant"
                },
                new SystemTypeViewModel()
                {
                    IsChecked = false,
                    Description = "Trane Central Geo-thermal Chilled Water System"
                },
            };
            this.jobRepository.Setup(x => x.GetJobSystemTypeListAsync(It.IsAny<int>())).Returns(Task.FromResult(systemTypes));

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.HasAnyEarthwiseSystems);
            this.jobRepository.Verify(x => x.GetJobSystemTypeListAsync(this.jobId), Times.Once);
        }

        /// <summary>
        /// Gets the job validation data for coordination (has selections which are not price protected)
        /// </summary>
        /// <returns>Job validation data for coordination (has selections which are not price protected)</returns>
        [Fact]
        public async Task GetCoordinationValidation_HasNotPriceProtectedSelections_ReturnsNotPriceProtectedSelection()
        {
            // Arrange
            IEnumerable<int> jobSelectionIds = new List<int>() { 1, 2, 3 };
            this.jobRepository.Setup(x => x.GetJobSelectionIds(It.IsAny<int>())).Returns(Task.FromResult(jobSelectionIds));
            this.jobRepository.Setup(x => x.GetSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<SelectionPriceProtectionDetail>()));
            this.jobRepository.Setup(x => x.GetNonSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<SelectionPriceProtectionDetail>()));

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.False(result.SelectionPriceProtectionDetails.All(x => x.IsSelectionPriceProtected));
            this.jobRepository.Verify(x => x.GetJobSelectionIds(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
        }

        /// <summary>
        /// Gets the job validation data for coordination (all valid)
        /// </summary>
        /// <returns>Job validation data for coordination (all valid)</returns>
        [Fact]
        public async Task GetCoordinationValidation_AllDataDefined_ReturnsAllValid()
        {
            // Arrange
            IEnumerable<string> excludedCoordinationStatuses = new List<string>() { JobsUpdateStatus.NotSubmittedStatus };
            this.jobRepository.Setup(x => x.GetSPAQuery(It.IsAny<int>())).Returns(Task.FromResult(string.Empty));
            IEnumerable<JobClassificationView> allJobClassificationViews = Helper.GetAllJobClassificationViews(It.IsAny<int>());
            IEnumerable<JobClassificationView> selectedClassificationViews = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 123,
                    DescriptionValues = "Purchaser Class",
                    JobCodeId = 111,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 111,
                            Description = "Controls Subcontractor"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 222,
                            Description = "Service Subcontractor"
                        }
                    }
                },
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 456,
                    DescriptionValues = "Building Class",
                    JobCodeId = 555,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 555,
                            Description = "Industrial"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 666,
                            Description = "Hospital"
                        }
                    }
                }
            };
            IEnumerable<SystemTypeViewModel> systemTypes = new List<SystemTypeViewModel>()
            {
                new SystemTypeViewModel()
                {
                    IsChecked = false,
                    Description = "Trane Ice-enhanced Air-cooled Chiller Plant"
                },
                new SystemTypeViewModel()
                {
                    IsChecked = true,
                    Description = "Trane Central Geo-thermal Chilled Water System"
                },
            };
            IEnumerable<SelectionPriceProtectionDetail> spaSelectionPriceProtectionDetails = new List<SelectionPriceProtectionDetail>()
            {
                Helper.GetSelectionPriceProtectionDetail(1, 1234),
                Helper.GetSelectionPriceProtectionDetail(2, 2345)
            };
            IEnumerable<SelectionPriceProtectionDetail> nonSpaSelectionPriceProtectionDetails = new List<SelectionPriceProtectionDetail>()
            {
                Helper.GetSelectionPriceProtectionDetail(3, 8742)
            };
            IEnumerable<int> jobSelectionIds = new List<int>() { 1, 2, 3 };

            this.jobCoordinationRepository.Setup(x => x.DoesJobCoordinatedRecordExist(It.IsAny<int>(), excludedCoordinationStatuses)).Returns(Task.FromResult(true));
            this.jobRepository.Setup(x => x.GetJobClassificationsAsync(It.IsAny<int>())).Returns(Task.FromResult(allJobClassificationViews));
            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedClassificationViews));
            this.jobRepository.Setup(x => x.GetJobSystemTypeListAsync(It.IsAny<int>())).Returns(Task.FromResult(systemTypes));
            this.jobRepository.Setup(x => x.GetJobSelectionIds(It.IsAny<int>())).Returns(Task.FromResult(jobSelectionIds));
            this.jobRepository.Setup(x => x.GetSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(spaSelectionPriceProtectionDetails));
            this.jobRepository.Setup(x => x.GetNonSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(nonSpaSelectionPriceProtectionDetails));

            // Act
            var result = await this.jobServiceUnderTest.GetCoordinationValidation(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.HasAllDefinedClassifications);
            Assert.True(result.HasAnyEarthwiseSystems);
            Assert.True(result.SelectionPriceProtectionDetails.All(x => x.IsSelectionPriceProtected));
            Assert.True(result.HasCoordinatedRecords);
            this.jobCoordinationRepository.Verify(x => x.DoesJobCoordinatedRecordExist(this.jobId, excludedCoordinationStatuses), Times.Once);
            this.jobRepository.Verify(x => x.GetJobClassificationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSelectionIds(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetNonSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
        }

        /// <summary>
        /// Split submission notes with more than 80 characters  - Success
        /// </summary>
        [Fact]
        public void SplitSubmissionNote_ValidInputWithMoreThan80Characters_ReturnsSubmissionNotes()
        {
            // Arrange
            var submissionNotes = new SubmissionNotesViewModel()
            {
                JobId = 178456,
                NoteLine = "$28,100 is the magic number for this unit.\n\n10/29/2019 02:45AM CDT\nTest message\n\n\n10/29/2019 02:46AM CDT\nTest2",
                DrAddressId = 94,
            };
            string note1 = "$28,100 is the magic number for this unit.\n\n10/29/2019 02:45AM CDT\nTest message\n";
            string note2 = "\n\n10/29/2019 02:46AM CDT\nTest2";

            // Act
            var result = this.jobServiceUnderTest.SplitSubmissionNote(submissionNotes);

            // Assert
            Assert.Equal(2, result.Count());
            Assert.Contains(result, x => x.NOTE_LINE == note1);
            Assert.Contains(result, x => x.NOTE_LINE == note2);
        }

        /// <summary>
        /// Split submission notes with less than 80 characters - Success
        /// </summary>
        [Fact]
        public void SplitSubmissionNote_ValidInputWithLessThan80Characters_ReturnsSubmissionNotes()
        {
            // Arrange
            var submissionNotes = new SubmissionNotesViewModel()
            {
                JobId = 178456,
                NoteLine = "Test",
                DrAddressId = 94,
            };
            string note1 = "Test";

            // Act
            var result = this.jobServiceUnderTest.SplitSubmissionNote(submissionNotes);

            // Assert
            Assert.Single(result);
            Assert.Contains(result, x => x.NOTE_LINE == note1);
        }

        /// <summary>
        /// Split submission notes - Failure
        /// </summary>
        [Fact]
        public void SplitSubmissionNote_InvalidInput_ReturnsEmpty()
        {
            // Arrange
            var submissionNotes = new SubmissionNotesViewModel()
            {
                JobId = 0,
                NoteLine = string.Empty,
                DrAddressId = 0,
            };

            // Act
            var result = this.jobServiceUnderTest.SplitSubmissionNote(submissionNotes);

            // Assert
            Assert.Empty(result);
        }

        /// <summary>
        /// Method to test GetJobCrmOpportunityIds for valid data
        /// </summary>
        /// <returns>Job and Opportunity ids</returns>
        [Fact]
        public async Task GetJobCrmOpportunityIds_ValidInput_ReturnsJobOpportunities()
        {
            // Arrange
            List<int> jobIds = new List<int>() { 6392 };
            IEnumerable<JobOpportunity> jobCrmOpportunityIdsList = new List<JobOpportunity>()
            {
                new JobOpportunity()
                {
                  JOB_ID = 6392,
                  CRM_OPPORTUNITY_ID = string.Empty
                }
            };
            this.jobRepository.Setup(x => x.GetJobCrmOpportunityIds(It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(jobCrmOpportunityIdsList));

            // Act
            IEnumerable<JobOpportunityViewModel> jobResult = await this.jobServiceUnderTest.GetJobCrmOpportunityIds(jobIds);

            // Assert
            Assert.Equal(jobCrmOpportunityIdsList.Count(), jobResult.Count());
            this.jobRepository.Verify(x => x.GetJobCrmOpportunityIds(It.IsAny<IEnumerable<int>>()), Times.Once);
        }

        /// <summary>
        /// Method to test GetJobCrmOpportunityIds for invalid data
        /// </summary>
        /// <returns>Empty result</returns>
        [Fact]
        public async Task GetJobCrmOpportunityIds_InvalidInput_ReturnsEmptyResult()
        {
            // Arrange
            var fixture = new Fixture();
            var jobIds = fixture.CreateMany<int>(2000);
            this.jobRepository.Setup(r => r.GetJobCrmOpportunityIds(It.IsAny<IEnumerable<int>>()))
                .Returns(Task.FromResult(Enumerable.Empty<JobOpportunity>()));

            // Act
            IEnumerable<JobOpportunityViewModel> result = await this.jobServiceUnderTest.GetJobCrmOpportunityIds(jobIds);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify(x => x.GetJobCrmOpportunityIds(It.IsAny<IEnumerable<int>>()), Times.Once);
        }

        /// <summary>
        /// GetJobsByNameOrOppyId is called for a given search text and jobs exist
        /// </summary>
        /// <returns>IEnumerable of JobOpportunityViewModels</returns>
        [Fact]
        public async Task GetJobsByNameOrOppyId_JobsExist_ReturnsJobs()
        {
            // Arrange
            string jobName = "Calgary_";
            string jobNameWithEscapeSequence = "Calgary\\_";
            bool isEscapeSequence = true;
            IEnumerable<JobOpportunity> jobOpportunity = new List<JobOpportunity>()
            {
             new JobOpportunity()
            {
                JOB_NAME = "Calgary_"
            }
            };
            this.jobRepository.Setup(x => x.GetJobsByNameOrOppyId(jobNameWithEscapeSequence, isEscapeSequence))
                .Returns(Task.FromResult(jobOpportunity));

            // Act
            IEnumerable<JobOpportunityViewModel> jobOpportunityviewmodel = await this.jobServiceUnderTest.GetJobsByNameOrOppyId(jobName);

            // Assert
            Assert.NotEmpty(jobOpportunityviewmodel);
            Assert.Equal(jobName, jobOpportunityviewmodel.First().JobName);
            this.jobRepository.Verify(x => x.GetJobsByNameOrOppyId(jobNameWithEscapeSequence, isEscapeSequence), Times.Once);
        }

        /// <summary>
        /// GetJobsByNameOrOppyId is called for a given search text and jobs do not exist
        /// </summary>
        /// <returns>Empty IEnumerable</returns>
        [Fact]
        public async Task GetJobsByNameOrOppyId_NoJobsExist_ReturnsEmptyCollection()
        {
            // Arrange
            string jobName = "Houston%";
            string jobNameWithEscapeSequence = "Houston\\%";
            bool isEscapeSequence = true;
            this.jobRepository.Setup(x => x.GetJobsByNameOrOppyId(jobNameWithEscapeSequence, isEscapeSequence))
                .Returns(Task.FromResult(Enumerable.Empty<JobOpportunity>()));

            // Act
            IEnumerable<JobOpportunityViewModel> jobOpportunity = await this.jobServiceUnderTest.GetJobsByNameOrOppyId(jobName);

            // Assert
            Assert.Empty(jobOpportunity);
            this.jobRepository.Verify(x => x.GetJobsByNameOrOppyId(jobNameWithEscapeSequence, isEscapeSequence), Times.Once);
        }

        /// <summary>
        /// Verifies for the job coordination history when the coordination history table has empty records and dr address id is
        /// honored through http context
        /// </summary>
        /// <returns>Job coordination history with "Not Submitted" status record</returns>
        [Fact]
        public async Task GetJobCoordinationHistory_ValidInputHasEmptyJobCoordinationHistory_ReturnsNotSubmittedJobCoordinationData()
        {
            // Arrange
            int coordinationId = 1;
            var drAddressIdFromHttpContext = new Dictionary<object, object>();
            drAddressIdFromHttpContext.Add("DR_ADDRESS_ID", this.drAddressId);
            IEnumerable<JobCoordinationHistoryViewModel> expectedJobCoordinationHistory = new List<JobCoordinationHistoryViewModel>()
            {
                Helper.GetJobCoordinationHistoryViewModel(this.jobId, coordinationId, "Not Submitted")
            };
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            byte[] submissionNotes = Helper.GetSubmissionNotes();
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.contextAccessor.Setup(x => x.HttpContext.Items).Returns(drAddressIdFromHttpContext);
            this.jobRepository.Setup(x => x.GetJobCoordinationHistory(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<JobCoordinationHistory>()));
            this.jobRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>())).Returns(Task.FromResult(coordinationId));
            this.jobRepository.Setup(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>())).Returns(Task.FromResult(true));
            this.jobRepository.Setup(x => x.GetSubmissionNotesForLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(submissionNotes));

            var serviceUnderTest = new JobService(this.repository.Object, this.mapper, this.jobRepository.Object, this.contextAccessor.Object, this.hostingEnvironment.Object, this.salesOfficeService.Object, this.jobCoordinationRepository.Object, this.jobCoordinationServiceMock.Object, this.jobsSnsNotifierMock.Object, this.tsmtSettingsMock.Object, this.favoriteServiceMock.Object);

            // Act
            var result = await serviceUnderTest.GetJobCoordinationHistory(this.jobId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(expectedJobCoordinationHistory.First().CoordinationStatus, result.First().CoordinationStatus);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.Items, Times.AtLeastOnce);
            this.jobRepository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
            this.jobCoordinationRepository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
            this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId));
            this.jobRepository.Verify(x => x.GetJobCoordinationHistory(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Once);
            this.jobRepository.Verify(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>()), Times.Once);
            this.jobRepository.Verify(x => x.GetSubmissionNotesForLastSubmission(this.jobId), Times.Once);
        }

        /// <summary>
        /// Verifies for the job coordination history when coordination history table has "Not Submitted" status record
        /// </summary>
        /// <returns>Existing job coordination history</returns>
        [Fact]
        public async Task GetJobCoordinationHistory_ValidInputHasNotSubmittedRecord_ReturnsJobCoordinationHistory()
        {
            // Arrange
            int coordinationId = 1;
            IEnumerable<JobCoordinationHistoryViewModel> expectedJobCoordinationHistory = new List<JobCoordinationHistoryViewModel>()
            {
                Helper.GetJobCoordinationHistoryViewModel(this.jobId, coordinationId, "Not Submitted")
            };
            IEnumerable<JobCoordinationHistory> expectedJobCoordinationHistoryData = new List<JobCoordinationHistory>()
            {
                Helper.GetJobCoordinationHistory(this.jobId, coordinationId, "Not Submitted")
            };
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetJobCoordinationHistory(It.IsAny<int>())).Returns(Task.FromResult(expectedJobCoordinationHistoryData));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationHistory(this.jobId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(expectedJobCoordinationHistory.First().CoordinationStatus, result.First().CoordinationStatus);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Never);
            this.jobRepository.Verify(x => x.GetJobCoordinationHistory(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Never);
            this.jobRepository.Verify(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>()), Times.Never);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>()), Times.Never);
        }

        /// <summary>
        /// Verifies for the job coordination history if the coordination history table has no "Not Submitted" status record
        /// </summary>
        /// <returns>Job coordination history with "Not Submitted" status record</returns>
        [Fact]
        public async Task GetJobCoordinationHistory_ValidInputHasNoNotSubmittedRecord_ReturnsJobCoordinationHistory()
        {
            // Arrange
            int coordinationId = 1;
            IEnumerable<JobCoordinationHistoryViewModel> expectedJobCoordinationHistory = new List<JobCoordinationHistoryViewModel>()
            {
                Helper.GetJobCoordinationHistoryViewModel(this.jobId, coordinationId, "Not Submitted"),
                Helper.GetJobCoordinationHistoryViewModel(this.jobId, coordinationId, "Submitted"),
                Helper.GetJobCoordinationHistoryViewModel(this.jobId, coordinationId, "ReCoordinated")
            };

            IEnumerable<JobCoordinationHistory> expectedJobCoordinationHistoryData = new List<JobCoordinationHistory>()
            {
                Helper.GetJobCoordinationHistory(this.jobId, coordinationId, "Submitted"),
                Helper.GetJobCoordinationHistory(this.jobId, coordinationId, "ReCoordinated")
            };
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            byte[] submissionNotes = Helper.GetSubmissionNotes();
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetJobCoordinationHistory(It.IsAny<int>())).Returns(Task.FromResult(expectedJobCoordinationHistoryData));
            this.jobRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>())).Returns(Task.FromResult(coordinationId));
            this.jobRepository.Setup(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>())).Returns(Task.FromResult(true));
            this.jobRepository.Setup(x => x.GetSubmissionNotesForLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(submissionNotes));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationHistory(this.jobId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(expectedJobCoordinationHistory.First().CoordinationStatus, result.First().CoordinationStatus);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetJobCoordinationHistory(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Once);
            this.jobRepository.Verify(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>()), Times.Once);
            this.jobRepository.Verify(x => x.GetSubmissionNotesForLastSubmission(this.jobId), Times.Once);
        }

        /// <summary>
        /// Verifies for the job coordination history if the coordination history table has coordinated records
        /// </summary>
        /// <returns>Job coordination history with "Not Submitted" status record</returns>
        [Fact]
        public async Task GetJobCoordinationHistory_ValidInputHasCoordinatedRecords_ReturnsJobCoordinationHistory()
        {
            // Arrange
            int coordinationId = 1;
            IEnumerable<JobCoordinationHistoryViewModel> expectedJobCoordinationHistory = new List<JobCoordinationHistoryViewModel>()
            {
                Helper.GetJobCoordinationHistoryViewModel(this.jobId, coordinationId, "Not Submitted"),
                Helper.GetJobCoordinationHistoryViewModel(this.jobId, coordinationId, "Pending Pricing")
            };

            IEnumerable<JobCoordinationHistory> expectedJobCoordinationHistoryData = new List<JobCoordinationHistory>()
            {
                Helper.GetJobCoordinationHistory(this.jobId, coordinationId, "Pending Pricing")
            };
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            byte[] submissionNotes = Helper.GetSubmissionNotes();
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetJobCoordinationHistory(It.IsAny<int>())).Returns(Task.FromResult(expectedJobCoordinationHistoryData));
            this.jobRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>())).Returns(Task.FromResult(coordinationId));
            this.jobRepository.Setup(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>())).Returns(Task.FromResult(true));
            this.jobRepository.Setup(x => x.GetSubmissionNotesForLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(submissionNotes));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationHistory(this.jobId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(expectedJobCoordinationHistory.First().CoordinationStatus, result.First().CoordinationStatus);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetJobCoordinationHistory(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Once);
            this.jobRepository.Verify(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>()), Times.Once);
            this.jobRepository.Verify(x => x.GetSubmissionNotesForLastSubmission(this.jobId), Times.Once);
        }

        /// <summary>
        /// Verifies for the job coordination history if the coordination history table has coordinated job bids
        /// </summary>
        /// <returns>Job coordination history</returns>
        [Fact]
        public async Task GetJobCoordinationHistory_ValidInputWithCooordinatedJobHavingBids_ReturnsJobCoordinationHistory()
        {
            // Arrange
            IEnumerable<JobCoordinationHistoryViewModel> expectedJobCoordinationHistory = new List<JobCoordinationHistoryViewModel>()
            {
                new JobCoordinationHistoryViewModel()
                {
                    CoordinationStatus = "Not Submitted",
                    BidDetails = Helper.GetJobDataForCoordination().CoordinationData.BidDetails
                }
            };

            IEnumerable<JobCoordinationHistory> expectedJobCoordinationHistoryData = new List<JobCoordinationHistory>()
            {
                Helper.GetJobCoordinationHistory()
            };

            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            List<string> bids = new List<string>()
            {
                "abc", "def"
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetJobCoordinationHistory(It.IsAny<int>())).Returns(Task.FromResult(expectedJobCoordinationHistoryData));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationHistory(this.jobId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(expectedJobCoordinationHistory.First().CoordinationStatus, result.First().CoordinationStatus);
            Assert.Equal(bids.First(), result.First().Bids.First());
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Never);
            this.jobRepository.Verify(x => x.GetJobCoordinationHistory(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Never);
            this.jobRepository.Verify(x => x.InsertDraftRecord(It.IsAny<JobCoordinationHistory>()), Times.Never);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>()), Times.Never);
        }

        /// <summary>
        /// Update job coordination values - Success
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationId = 100,
                SubmissionNotes = "Hi Team"
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update job coordination values - Valid input with submission notes as null
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithSubmissionNotesAsNull_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationId = 100,
                CoordinationStatus = "Not Submitted",
                SubmissionNotes = null,
                Documents = new List<JobCoordinationDocumentViewModel>()
                {
                    new JobCoordinationDocumentViewModel()
                    {
                        JobDocumentId = 123,
                        DocumentKey = "Jobs/78/27440/new 8.txt",
                        DocumentName = "new 8.txt",
                        DocumentUpdateStatus = "Insertion",
                        Notes = "test doc",
                        UploadedDate = DateTime.Now,
                        UploadedUserId = "test"
                    }
                }
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update job coordination values - Valid input with submission notes and documents as null
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithSubmissionNotesAndDocumentsAsNull_ReturnTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationId = 100,
                SubmissionNotes = null,
                Documents = null,
                BillOfMaterials = new List<JobCoordinationBillOfMaterialViewModel>()
                {
                    new JobCoordinationBillOfMaterialViewModel()
                    {
                        ProductFamilyId = 8764,
                        ShipQuarter = decimal.ToInt32(Math.Ceiling(DateTime.Today.Month / 3m)),
                        ShipYear = DateTime.Now.Year,
                        Competitor = "abc",
                        SpecifiedUser = "def",
                        SelectionSource = "C"
                    }
                }
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationBillOfMaterials(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), It.IsAny<int>()), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBillOfMaterials(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
        }

        /// <summary>
        /// Update job coordination values - Failure if the auto save sections has null value
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidInputWillNullAutoSaveWidgetPayloads_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                CoordinationId = 1,
                JobId = 12,
                DrAddressId = 101
            };

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBillOfMaterials(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact and commission code are null and update is not triggered when submit button is clicked
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithJobGeneralInfoAndNotForSubmit_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = false,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now
                }
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact and commission code are not null and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithJobGeneralInfoAndForSubmit_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now,
                    CommissionCode = "B12",
                    JobContact = "dummy"
                }
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact and commission code are empty and requested date is in future
        /// and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidJobGeneralInfoAndForSubmit_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now
                }
            };

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact is empty and requested date is past and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidInputEmptyJobContactPastRequestedDateAndForSubmit_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now.AddDays(-1),
                    CommissionCode = "B12"
                }
            };

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact is empty and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidInputEmptyJobContactAndForSubmit_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now.AddDays(1),
                    CommissionCode = "B12"
                }
            };

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where commission code is empty and requested date is past and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidInputEmptyCommCodePastRequestedDateAndForSubmit_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now.AddDays(-1),
                    JobContact = "abcd"
                }
            };

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where commission code is empty and requested date is in future and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidInputEmptyCommCodeAndForSubmit_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now.AddDays(2),
                    JobContact = "abcd"
                }
            };

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where requested date is in past and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidInputPastRequestedDateAndForSubmit_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now.AddDays(-2),
                    JobContact = "abcd",
                    CommissionCode = "B12"
                }
            };
            this.jobRepository.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetDbDate(), Times.Once);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact and commission code are empty and requested date is past
        /// and update is triggered when submit button is clicked
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_InvalidInputPastRequestedDateEmptyContactsAndForSubmit_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = true,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now.AddDays(-1)
                }
            };

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact having value and commission code is null and update is not triggered when submit button is clicked
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithCommCodeAsNullAndNotForSubmit_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = false,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now,
                    JobContact = "abcs"
                }
            };
            JobCoordinationContactDetails jobCoordinationContactDetails = Helper.GetJobCoordinationContactDetails();
            this.jobRepository.Setup(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId)).Returns(Task.FromResult(jobCoordinationContactDetails));
            this.jobRepository.Setup(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact is null and commission code is having value and update is not triggered when submit button is clicked
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithJobContactAsNullAndNotForSubmit_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now,
                    CommissionCode = "abc"
                }
            };
            JobCoordinationContactDetails jobCoordinationContactDetails = Helper.GetJobCoordinationContactDetails();
            this.jobRepository.Setup(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId)).Returns(Task.FromResult(jobCoordinationContactDetails));
            this.jobRepository.Setup(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact and commission code are having value and update is not triggered when submit button is clicked
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithJobContactAndCommCodeAndNotForSubmit_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = false,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now,
                    JobContact = "abcs",
                    CommissionCode = "abc"
                }
            };
            JobCoordinationContactDetails jobCoordinationContactDetails = Helper.GetJobCoordinationContactDetails();
            this.jobRepository.Setup(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId)).Returns(Task.FromResult(jobCoordinationContactDetails));
            this.jobRepository.Setup(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with job general information alone
        /// where job contact and commission code are having value same as job coordination
        /// contact details obtained from table and update is not triggered when submit button is clicked
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithSameJobContactAndCommCodeAsFromTable_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                IsForSubmit = false,
                JobGeneralInformation = new JobCoordinationGeneralInfoViewModel()
                {
                    IsIcsJob = true,
                    IsQuickTurnaroundRequired = false,
                    RequestedDate = DateTime.Now,
                    JobContact = "ccfbsr",
                    CommissionCode = "ccfbol"
                }
            };
            JobCoordinationContactDetails jobCoordinationContactDetails = Helper.GetJobCoordinationContactDetails();
            this.jobRepository.Setup(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId)).Returns(Task.FromResult(jobCoordinationContactDetails));
            this.jobRepository.Setup(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.GetJobCoordinationContactDetails(jobCoordination.JobId), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with bids alone
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithBids_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                Bids = new List<JobCoordinationBidViewModel>()
                {
                    new JobCoordinationBidViewModel()
                    {
                        BidAlternateId = 123,
                        BidAlternateName = "b bid"
                    }
                }
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Update coordination job values - valid input with empty job coordination bids
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_ValidInputWithEmptyJobCoordinationBids_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 19862,
                DrAddressId = 101,
                CoordinationId = 11,
                Bids = Enumerable.Empty<JobCoordinationBidViewModel>()
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationGeneralInformation(It.IsAny<JobGeneralInfoModel>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationSubmissionNotesDraft(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), It.IsAny<string>(), jobCoordination.CoordinationId), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationBids(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - all validation scenarios passed
        /// </summary>
        /// <returns>Job coordination submission validation data having true for all validations</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_ValidInputWithSubmissionValidationsPassed_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 2;
            var userView = new JobLockedUserView
            {
                UserId = "lalcj",
                FirstName = "David",
                LastName = "Harper",
                UserName = "Harper, David",
            };
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "lalcj")
            };
            int currentShipQuarter = (DateTime.Now.Month + 2) / 3;
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(1),
                COORDINATION_STATUS = "Not Submitted",
                COORDINATION_JOB_BIDS = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID'     : 1234,
                                                                    'BID_ALTERNATE_NAME'   : 'abc',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    }
                                                                  ]"),
                COORDINATION_JOB_SUB_NOTES = Encoding.ASCII.GetBytes("This is submission notes"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PROD_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR': " + $"{currentShipQuarter}" + @",
                                                                    'CJ_SHIP_YEAR': " + $"{DateTime.Now.Year}" + @",
                                                                    'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    }
                                                                 ]")
            };
            IEnumerable<JobClassificationView> allJobClassifications = Helper.GetAllJobClassificationViews(this.jobId);
            IEnumerable<JobClassificationView> selectedClassifications = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 123,
                    DescriptionValues = "Purchaser Class",
                    JobCodeId = 111,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 111,
                            Description = "Controls Subcontractor"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 222,
                            Description = "Service Subcontractor"
                        }
                    }
                },
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 456,
                    DescriptionValues = "Building Class",
                    JobCodeId = 555,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 555,
                            Description = "Industrial"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 666,
                            Description = "Hospital"
                        }
                    }
                }
            };
            IEnumerable<SystemTypeViewModel> systemTypes = new List<SystemTypeViewModel>()
            {
                new SystemTypeViewModel()
                {
                    IsChecked = false,
                    Description = "Trane Ice-enhanced Air-cooled Chiller Plant"
                },
                new SystemTypeViewModel()
                {
                    IsChecked = true,
                    Description = "Trane Central Geo-thermal Chilled Water System"
                }
            };
            IEnumerable<string> excludedCoordinationStatuses = new List<string>() { JobsUpdateStatus.NotSubmittedStatus, JobsUpdateStatus.ErrorInSubmissionStatus };
            this.jobRepository.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.jobRepository.Setup(x => x.GetJobSystemTypeListAsync(It.IsAny<int>())).Returns(Task.FromResult(systemTypes));
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetJobLockedUserDetailsAsync(It.IsAny<int>())).Returns(Task.FromResult(userView));
            this.jobRepository.Setup(x => x.GetCoordinationData(coordinationId)).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.HasNoActiveCoordination(It.IsAny<int>())).Returns(Task.FromResult(true));
            this.jobRepository.Setup(x => x.GetJobClassificationsAsync(It.IsAny<int>())).Returns(Task.FromResult(allJobClassifications));
            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedClassifications));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Encoding.UTF8.GetBytes("This is submission notes text")));
            this.jobCoordinationRepository.Setup(x => x.DoesJobCoordinatedRecordExist(It.IsAny<int>(), excludedCoordinationStatuses)).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.True(result.IsJobLockedByLoggedInUser);
            Assert.True(result.IsRequestedDateFuture);
            Assert.True(result.IsCoordinationStatusNotSubmitted);
            Assert.True(result.IsBidsSelectedForCoordination);
            Assert.True(result.HasNoActiveCoordination);
            Assert.True(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            Assert.True(result.HasAllDefinedClassifications);
            Assert.True(result.HasAnyEarthwiseSystems);
            Assert.True(result.HasValidShipQuartersAndShipYears);
            Assert.True(result.HasCoordinatedRecords);
            this.jobRepository.Verify(x => x.GetDbDate(), Times.Once);
            this.jobCoordinationRepository.Verify(x => x.DoesJobCoordinatedRecordExist(this.jobId, excludedCoordinationStatuses), Times.Once);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSystemTypeListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobClassificationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetJobLockedUserDetailsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
            this.jobRepository.Verify(x => x.HasNoActiveCoordination(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - all validation scenarios failed
        /// </summary>
        /// <returns>Job coordination submission validation data having false for all validations</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_ValidInputWithSubmissionValidationsFailed_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var userView = new JobLockedUserView
            {
                UserId = "lalcj",
                FirstName = "David",
                LastName = "Harper",
                UserName = "Harper, David",
            };
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Array.Empty<byte>(),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            IEnumerable<JobClassificationView> allJobClassifications = Helper.GetAllJobClassificationViews(this.jobId);
            IEnumerable<JobClassificationView> selectedClassifications = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                    JobId = this.jobId,
                    JobClassId = 123,
                    DescriptionValues = "Purchaser Class",
                    JobCodeId = 111,
                    JobClassificationList = new List<ClassificationItemView>()
                    {
                        new ClassificationItemView()
                        {
                            JobCodeId = 111,
                            Description = "Controls Subcontractor"
                        },
                        new ClassificationItemView()
                        {
                            JobCodeId = 222,
                            Description = "Service Subcontractor"
                        }
                    }
                }
            };
            IEnumerable<SystemTypeViewModel> systemTypes = new List<SystemTypeViewModel>()
            {
                new SystemTypeViewModel()
                {
                    IsChecked = false,
                    Description = "Trane Ice-enhanced Air-cooled Chiller Plant"
                },
                new SystemTypeViewModel()
                {
                    IsChecked = false,
                    Description = "Trane Central Geo-thermal Chilled Water System"
                }
            };
            this.jobRepository.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.jobRepository.Setup(x => x.GetJobSystemTypeListAsync(It.IsAny<int>())).Returns(Task.FromResult(systemTypes));
            this.jobRepository.Setup(x => x.GetJobClassificationsAsync(It.IsAny<int>())).Returns(Task.FromResult(allJobClassifications));
            this.jobRepository.Setup(x => x.GetClassificationsByJobIdAsync(It.IsAny<int>())).Returns(Task.FromResult(selectedClassifications));
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetJobLockedUserDetailsAsync(It.IsAny<int>())).Returns(Task.FromResult(userView));
            this.jobRepository.Setup(x => x.GetCoordinationData(coordinationId)).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.HasNoActiveCoordination(It.IsAny<int>())).Returns(Task.FromResult(false));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.IsJobLockedByLoggedInUser);
            Assert.False(result.IsRequestedDateFuture);
            Assert.False(result.IsCoordinationStatusNotSubmitted);
            Assert.False(result.IsBidsSelectedForCoordination);
            Assert.False(result.HasNoActiveCoordination);
            Assert.False(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            Assert.False(result.HasAllDefinedClassifications);
            Assert.False(result.HasAnyEarthwiseSystems);
            this.jobRepository.Verify(x => x.GetDbDate(), Times.Once);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobSystemTypeListAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetJobClassificationsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetClassificationsByJobIdAsync(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetJobLockedUserDetailsAsync(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
            this.jobRepository.Verify(x => x.HasNoActiveCoordination(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - past ship quarter and ship year
        /// </summary>
        /// <returns>Job coordination submission validation data having false for ship quarter and ship year validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_ValidInputWithPastShipQuarterAndShipYear_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PRODUCT_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR': 2,
                                                                    'CJ_SHIP_YEAR': 2012,
                                                                    'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    }
                                                                  ]"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.HasValidShipQuartersAndShipYears);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - past ship quarter and current ship year
        /// Skip non configured selection for validation
        /// </summary>
        /// <returns>Job coordination submission validation data having false for ship quarter and ship year validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_PastShipQuarterPresentShipYear_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            DateTime presentDate = DateTime.Parse("04/21/2020");
            int currentShipYear = presentDate.Year;
            int pastShipQuarter = 1;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PRODUCT_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR':" + $"{pastShipQuarter}" + @",
                                                                    'CJ_SHIP_YEAR':" + $"{currentShipYear}" + @",
                                                                    'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    },
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PRODUCT_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR': 2,
                                                                    'CJ_SHIP_YEAR': 2012,
                                                                    'SELECTION_SOURCE': 'N',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    }
                                                                  ]"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.HasValidShipQuartersAndShipYears);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - current and future ship quarters and ship years
        /// Skip non configured selection for validation
        /// </summary>
        /// <returns>Job coordination submission validation data having true for ship quarter and ship year validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_CurrentAndFutureShipQuartersAndShipYears_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            DateTime presentDate = DateTime.Now;
            int currentShipYear = presentDate.Year;
            int currentShipQuarter = (presentDate.Month + 2) / 3;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PRODUCT_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR':" + $"{currentShipQuarter}" + @",
                                                                    'CJ_SHIP_YEAR':" + $"{currentShipYear}" + @",
                                                                    'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    },
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PRODUCT_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR': 2,
                                                                    'CJ_SHIP_YEAR': 2012,
                                                                    'SELECTION_SOURCE': 'N',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    }
                                                                  ]"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.True(result.HasValidShipQuartersAndShipYears);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation
        /// When separately bidaable selection exist
        /// </summary>
        /// <returns>Job coordination submission validation data having true for ship quarter and ship year validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_HasSeparatelyBiddableSelection_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PRODUCT_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR': 2,
                                                                    'CJ_SHIP_YEAR': 2012,
                                                                    'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : true
                                                                    }
                                                                  ]"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.True(result.HasValidShipQuartersAndShipYears);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation
        /// When separately bidaable selection doesn't exist
        /// </summary>
        /// <returns>Job coordination submission validation data having false for ship quarter and ship year validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_HasNoSeparatelyBiddableSelection_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                    {
                                                                    'BID_ALTERNATE_ID' : 1234,
                                                                    'PRODUCT_FAMILY_ID': 8764,
                                                                    'CJ_SHIP_QTR': 2,
                                                                    'CJ_SHIP_YEAR': 2012,
                                                                    'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                    }
                                                                  ]"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.HasValidShipQuartersAndShipYears);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - null value for ship quarter, ship year and submission notes until
        /// last submission
        /// Skip non configured selection for validation
        /// </summary>
        /// <returns>Job coordination submission validation data having false for ship quarter, ship year and
        /// submission notes validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_ValidInputWithNullShipQuarterAndShipYearAndSubmissionNotes_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PRODUCT_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  },
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PRODUCT_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'N',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  }
                                                                 ]"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.HasValidShipQuartersAndShipYears);
            Assert.False(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - null value for current submission notes
        /// </summary>
        /// <returns>Job coordination submission validation data having false for submission notes validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_CurrentSubmissionNotesIsNull_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                COORDINATION_STATUS = "Not Submitted",
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PROD_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  }
                                                                 ]")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Encoding.UTF8.GetBytes("This is test data")));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - current submission notes exist and it is same as submission notes until last submission
        /// </summary>
        /// <returns>Job coordination submission validation data having false for submission notes validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_CurrentSubmissionNotesEqualsLastSubmittedNotes_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                COORDINATION_STATUS = "Not Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Encoding.ASCII.GetBytes("This is test data"),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PROD_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  }
                                                                 ]")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Encoding.UTF8.GetBytes("This is test data")));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - current submission notes exist and submission notes until last submission differs
        /// </summary>
        /// <returns>Job coordination submission validation data having true for submission notes validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_CurrentSubmissionNotesNotEqualsLastSubmittedNotes_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                COORDINATION_STATUS = "Not Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Encoding.ASCII.GetBytes("This is test data today"),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PROD_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  }
                                                                 ]")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Encoding.UTF8.GetBytes("This is test data")));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.True(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - current submission notes exist and submission notes until last submission is null
        /// </summary>
        /// <returns>Job coordination submission validation data having true for submission notes validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_CurrentSubmissionNotesExist_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                COORDINATION_STATUS = "Not Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Encoding.ASCII.GetBytes("This is test data today"),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PROD_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  }
                                                                 ]")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.True(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation - current submission notes and submission notes until last submission is empty
        /// </summary>
        /// <returns>Job coordination submission validation data having false for submission notes validation</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_CurrentSubmissionNotesIsEmpty_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                COORDINATION_STATUS = "Not Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PROD_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'C',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  }
                                                                 ]")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.False(result.DoesSubmissionNotesDifferFromLastSubmittedUserEntry);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        /// <summary>
        /// Get job coordination submission validation
        /// Skip non configured selection for validation
        /// </summary>
        /// <returns>Job coordination submission validation data</returns>
        [Fact]
        public async Task GetJobCoordinationSubmissionValidation_HasNonConfiguredSelectionsOnly_ReturnsSubmissionValidationData()
        {
            // Arrange
            int coordinationId = 12;
            var claims = new List<Claim>
            {
                new Claim("samAccountName", "ccfbol")
            };
            var coordinationData = new JobCoordinationHistory
            {
                REQUESTED_DATE = DateTime.Now.AddDays(-1),
                COORDINATION_STATUS = "Submitted",
                COORDINATION_JOB_BIDS = Array.Empty<byte>(),
                COORDINATION_JOB_SUB_NOTES = Array.Empty<byte>(),
                COORDINATION_JOB_BOM = Encoding.ASCII.GetBytes(@"[
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PRODUCT_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'N',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  },
                                                                  {
                                                                  'BID_ALTERNATE_ID' : 1234,
                                                                  'PRODUCT_FAMILY_ID': 8764,
                                                                  'SELECTION_SOURCE': 'N',
                                                                    'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false
                                                                  }
                                                                 ]"),
                COORDINATION_JOB_DOCUMENTS = Array.Empty<byte>()
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepository.Setup(x => x.GetCoordinationData(It.IsAny<int>())).Returns(Task.FromResult(coordinationData));
            this.jobRepository.Setup(x => x.GetSubmissionNotesUntilLastSubmission(It.IsAny<int>())).Returns(Task.FromResult(Array.Empty<byte>()));

            // Act
            var result = await this.jobServiceUnderTest.GetJobCoordinationSubmissionValidation(this.jobId, coordinationId);

            // Assert
            Assert.True(result.HasValidShipQuartersAndShipYears);
            this.jobRepository.Verify(x => x.GetSubmissionNotesUntilLastSubmission(this.jobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobRepository.Verify(x => x.GetCoordinationData(coordinationId), Times.Once);
        }

        [Fact]
        public async Task GetJobIds_ValidRequest_ReuturnJobIds()
        {
            // Assign
            string crmOppyId = "56789";
            IEnumerable<int> jobIds = new List<int>()
            {
                { 67 }, { 90 }
            };

            this.jobRepository.Setup(x => x.GetJobIds(It.IsAny<string>())).Returns(Task.FromResult(jobIds)).Verifiable();

            // Act
            var result = await this.jobServiceUnderTest.GetJobIds(crmOppyId);

            // Assert
            Assert.Equal(jobIds, result);
            this.jobRepository.Verify();
        }

        /// <summary>
        /// Get the submitted bids - Success
        /// </summary>
        /// <returns>Bids</returns>
        [Fact]
        public async Task GetSubmittedBids_ValidInput_ReturnsBids()
        {
            // Arrange
            IEnumerable<byte[]> submittedBids = new List<byte[]>
            {
               Encoding.ASCII.GetBytes(@"[
                                          {
                                            'BID_ALTERNATE_ID'     : 1234,
                                            'BID_ALTERNATE_NAME'   : 'abc'
                                          }]")
            };
            IEnumerable<int> bids = new List<int>
            {
                1234
            };
            this.jobRepository.Setup(x => x.GetSubmittedBids(It.IsAny<int>())).Returns(Task.FromResult(submittedBids));

            // Act
            var result = await this.jobServiceUnderTest.GetSubmittedBids(this.jobId);

            // Assert
            Assert.Equal(result, bids);
            this.jobRepository.Verify(x => x.GetSubmittedBids(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get the submitted bids - No content
        /// </summary>
        /// <returns>No content</returns>
        [Fact]
        public async Task GetSubmittedBids_ValidInput_ReturnsNull()
        {
            // Arrange
            IEnumerable<byte[]> submittedBids = Enumerable.Empty<byte[]>();
            this.jobRepository.Setup(x => x.GetSubmittedBids(It.IsAny<int>())).Returns(Task.FromResult(submittedBids));

            // Act
            var result = await this.jobServiceUnderTest.GetSubmittedBids(this.jobId);

            // Assert
            Assert.Null(result);
            this.jobRepository.Verify(x => x.GetSubmittedBids(this.jobId), Times.Once);
        }

        /// <summary>
        /// Tests if update CPLAF lock calls through to the repository
        /// </summary>
        /// <returns>A Task</returns>
        [Fact]
        public async Task UpdateCPLPAFLock_CallsThroughToTheRepository()
        {
            // Assign
            CplpafLock lockModel = new CplpafLock(20067, true);

            this.jobRepository.Setup(x => x.UpdateCplpafLock(lockModel.JobId, lockModel.LockValue))
                .Returns(Task.FromResult(true));

            // Act
            bool rowsWereModified = await this.jobServiceUnderTest.UpdateCplpafLock(lockModel);

            // Assert
            Assert.True(rowsWereModified);
            this.jobRepository.Verify(x => x.UpdateCplpafLock(lockModel.JobId, lockModel.LockValue), Times.Once);
        }

        /// <summary>
        /// Verifies if the job coordination documents is updated and if the coordinated job document update request is not sent since the job has not been submitted
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_JobCoordinationDocumentsUpdated_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationStatus = "Not Submitted",
                CoordinationId = 100,
                Documents = new List<JobCoordinationDocumentViewModel>()
                {
                    Helper.GetJobCoordinationDocumentViewModel(123, "Jobs/78/27440/new 8.txt", string.Empty),
                    Helper.GetJobCoordinationDocumentViewModel(124, "Jobs/78/27441/new 8.txt", string.Empty)
                }
            };
            this.jobRepository.Setup(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);

            // Since the update of job coordination documents happen for "Not Submitted" record, the coordinated job document update request is not sent to COJO
            this.jobCoordinationServiceMock.Verify(
                x => x.SendCoordinatedJobDocumentUpdateRequest(
                    It.IsAny<JobCoordinationDocumentViewModel>(),
                    jobCoordination.DrAddressId,
                    jobCoordination.JobId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Verifies if the job coordination documents is updated and if the coordinated job document update request is sent for insertion since the job has submitted records
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_CoordinatedJobDocumentUpdateRequestSentForInsertion_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationStatus = "Submitted",
                CoordinationId = 100,
                Documents = new List<JobCoordinationDocumentViewModel>()
                {
                    Helper.GetJobCoordinationDocumentViewModel(123, "Jobs/78/27440/new 8.txt", string.Empty),
                    Helper.GetJobCoordinationDocumentViewModel(124, "Jobs/78/27441/new 8.txt", string.Empty),
                    Helper.GetJobCoordinationDocumentViewModel(125, "Jobs/78/27442/new 8.txt", "Insertion")
                }
            };

            // Coordinated job document that to be sent to COJO for processing
            this.jobRepository.Setup(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Setup for coordinated job document update request being sent for insertion
            this.jobCoordinationServiceMock.Setup(x => x.SendCoordinatedJobDocumentUpdateRequest(It.IsAny<JobCoordinationDocumentViewModel>(), jobCoordination.DrAddressId, jobCoordination.JobId))
                                           .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);

            // Since the update of job coordination documents happen for "Submitted" record, the coordinated job document update request is sent to COJO
            this.jobCoordinationServiceMock.Verify(
                x => x.SendCoordinatedJobDocumentUpdateRequest(
                    It.IsAny<JobCoordinationDocumentViewModel>(),
                    jobCoordination.DrAddressId,
                    jobCoordination.JobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Verifies if the job coordination documents is updated and if the coordinated job document update request is sent for deletion since the job has submitted record
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJob_CoordinatedJobDocumentUpdateRequestSentForDeletion_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationStatus = "Submitted",
                CoordinationId = 100,
                Documents = new List<JobCoordinationDocumentViewModel>()
                {
                    Helper.GetJobCoordinationDocumentViewModel(123, "Jobs/78/27440/new 8.txt", "Deletion"),
                    Helper.GetJobCoordinationDocumentViewModel(124, "Jobs/78/27441/new 8.txt", string.Empty)
                }
            };

            // Coordinated job document that to be sent to COJO for processing
            this.jobRepository.Setup(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Setup for coordinated job document update request being sent for deletion
            this.jobCoordinationServiceMock.Setup(x => x.SendCoordinatedJobDocumentUpdateRequest(It.IsAny<JobCoordinationDocumentViewModel>(), jobCoordination.DrAddressId, jobCoordination.JobId))
                                           .Returns(Task.FromResult(true));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.True(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.jobCoordinationServiceMock.Verify(
                x => x.SendCoordinatedJobDocumentUpdateRequest(
                    It.IsAny<JobCoordinationDocumentViewModel>(),
                    jobCoordination.DrAddressId,
                    jobCoordination.JobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Verifies for false if the coordinated job document update request is not sent
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_CoordinatedJobDocumentUpdateRequestNotSent_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationStatus = "Submitted",
                CoordinationId = 100,
                Documents = new List<JobCoordinationDocumentViewModel>()
                {
                    Helper.GetJobCoordinationDocumentViewModel(123, "Jobs/78/27440/new 8.txt", "Deletion"),
                    Helper.GetJobCoordinationDocumentViewModel(124, "Jobs/78/27441/new 8.txt", string.Empty)
                }
            };

            // Coordinated job document that to be sent to COJO for processing
            this.jobRepository.Setup(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(true);

            // Setup for coordinated job document update request not being sent
            this.jobCoordinationServiceMock.Setup(x => x.SendCoordinatedJobDocumentUpdateRequest(It.IsAny<JobCoordinationDocumentViewModel>(), jobCoordination.DrAddressId, jobCoordination.JobId))
                                           .Returns(Task.FromResult(false));

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.jobCoordinationServiceMock.Verify(
                x => x.SendCoordinatedJobDocumentUpdateRequest(
                    It.IsAny<JobCoordinationDocumentViewModel>(),
                    jobCoordination.DrAddressId,
                    jobCoordination.JobId), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        /// <summary>
        /// Verifies for false if the job coordination document updation fails
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJob_JobCoordinationDocumentNotUpdated_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationStatus = "Submitted",
                CoordinationId = 100,
                Documents = new List<JobCoordinationDocumentViewModel>()
                {
                    Helper.GetJobCoordinationDocumentViewModel(123, "Jobs/78/27440/new 8.txt", "Deletion"),
                    Helper.GetJobCoordinationDocumentViewModel(124, "Jobs/78/27441/new 8.txt", string.Empty)
                }
            };

            // Coordinated job document that to be sent to COJO for processing
            this.jobRepository.Setup(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId)).Returns(false);

            // Act
            var result = await this.jobServiceUnderTest.UpdateCoordinationJob(jobCoordination);

            // Assert
            Assert.False(result);
            this.jobRepository.Verify(x => x.UpdateJobCoordinationDocuments(It.IsAny<string>(), this.userId, jobCoordination.CoordinationId), Times.Once);
            this.jobCoordinationServiceMock.Verify(
                x => x.SendCoordinatedJobDocumentUpdateRequest(
                    It.IsAny<JobCoordinationDocumentViewModel>(),
                    jobCoordination.DrAddressId,
                    jobCoordination.JobId), Times.Never);
            this.contextAccessor.Verify(x => x.HttpContext.User.Claims, Times.Once);
        }

        [Fact]
        public async Task SearchAsync_CallsJobRepositoryWithSearch()
        {
            // Arrange
            var expectedSearch = new JobSearch() { HqtrJobId = 1 };
            IEnumerable<JobReportView> results = new[] { new JobReportView() };
            this.jobRepository.Setup(r => r.GetJobsAsync(It.IsAny<JobSearch>())).Returns(Task.FromResult(results));

            // Act
            await this.jobServiceUnderTest.SearchAsync(expectedSearch);

            // Assert
            this.jobRepository.Verify(r => r.GetJobsAsync(expectedSearch), Times.Once);
        }

        /// <summary>
        /// Verifies for the price protected selection details
        /// </summary>
        /// <returns>Selection price protection details</returns>
        [Fact]
        public async Task GetSelectionPriceProtectionDetails_HasPriceProtectedSelections_ReturnsSelectionPriceProtectionDetails()
        {
            // Arrange
            IEnumerable<int> jobSelectionIds = new List<int>() { 1, 2, 3 };
            IEnumerable<SelectionPriceProtectionDetail> spaSelectionPriceProtectionDetails = new List<SelectionPriceProtectionDetail>()
            {
                Helper.GetSelectionPriceProtectionDetail(1, 1234),
                Helper.GetSelectionPriceProtectionDetail(2, 2345)
            };
            IEnumerable<SelectionPriceProtectionDetail> nonSpaSelectionPriceProtectionDetails = new List<SelectionPriceProtectionDetail>()
            {
                Helper.GetSelectionPriceProtectionDetail(3, 8742)
            };
            this.jobRepository.Setup(x => x.GetJobSelectionIds(It.IsAny<int>())).Returns(Task.FromResult(jobSelectionIds));
            this.jobRepository.Setup(x => x.GetSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(spaSelectionPriceProtectionDetails));
            this.jobRepository.Setup(x => x.GetNonSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(nonSpaSelectionPriceProtectionDetails));
            var expectedResult = new List<SelectionPriceProtectionDetailViewModel>()
            {
                Helper.GetSelectionPriceProtectionDetailViewModel(1, 1234),
                Helper.GetSelectionPriceProtectionDetailViewModel(2, 2345),
                Helper.GetSelectionPriceProtectionDetailViewModel(3, 8742)
            };

            // Act
            var result = await this.jobServiceUnderTest.GetJobSelectionPriceProtectionDetails(this.jobId);

            // Assert
            Assert.Equal(expectedResult.First().SalesOrderId, result.First().SalesOrderId);
            Assert.True(result.All(x => x.IsSelectionPriceProtected));
            this.jobRepository.Verify(x => x.GetJobSelectionIds(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
        }

        /// <summary>
        /// Verifies if all selections are not price protected since spa and non spa selection details does not exist
        /// </summary>
        /// <returns>Selection with not price protected details</returns>
        [Fact]
        public async Task GetSelectionPriceProtectionDetails_AllSelectionsNotPriceProtected_ReturnsSelectionPriceProtectionDetails()
        {
            // Arrange
            IEnumerable<int> jobSelectionIds = new List<int>() { 1, 2, 3 };
            this.jobRepository.Setup(x => x.GetJobSelectionIds(It.IsAny<int>())).Returns(Task.FromResult(jobSelectionIds));
            this.jobRepository.Setup(x => x.GetSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<SelectionPriceProtectionDetail>()));
            this.jobRepository.Setup(x => x.GetNonSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<SelectionPriceProtectionDetail>()));
            var expectedResult = new List<SelectionPriceProtectionDetailViewModel>()
            {
                Helper.GetSelectionPriceProtectionDetailViewModel(1, null),
                Helper.GetSelectionPriceProtectionDetailViewModel(2, null),
                Helper.GetSelectionPriceProtectionDetailViewModel(3, null)
            };

            // Act
            var result = await this.jobServiceUnderTest.GetJobSelectionPriceProtectionDetails(this.jobId);

            // Assert
            Assert.Equal(result.First().SelectionId, expectedResult.First().SelectionId);
            Assert.False(result.All(x => x.IsSelectionPriceProtected));
            this.jobRepository.Verify(x => x.GetJobSelectionIds(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
        }

        /// <summary>
        /// Verifies if the selection is not price protected since spa selection details does not exist
        /// </summary>
        /// <returns>Selection with not price protection details</returns>
        [Fact]
        public async Task GetSelectionPriceProtectionDetails_SomeSelectionsNotPriceProtected_ReturnsSelectionPriceProtectionDetails()
        {
            // Arrange
            IEnumerable<int> jobSelectionIds = new List<int>() { 1, 2, 3 };
            IEnumerable<SelectionPriceProtectionDetail> nonSpaSelectionPriceProtectionDetails = new List<SelectionPriceProtectionDetail>()
            {
                Helper.GetSelectionPriceProtectionDetail(3, 8742)
            };
            this.jobRepository.Setup(x => x.GetJobSelectionIds(It.IsAny<int>())).Returns(Task.FromResult(jobSelectionIds));
            this.jobRepository.Setup(x => x.GetSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<SelectionPriceProtectionDetail>()));
            this.jobRepository.Setup(x => x.GetNonSpaSelectionPriceProtectionDetails(It.IsAny<int>())).Returns(Task.FromResult(nonSpaSelectionPriceProtectionDetails));
            var expectedResult = new List<SelectionPriceProtectionDetailViewModel>()
            {
                Helper.GetSelectionPriceProtectionDetailViewModel(3, 8742),
                Helper.GetSelectionPriceProtectionDetailViewModel(1, null),
                Helper.GetSelectionPriceProtectionDetailViewModel(2, null)
            };

            // Act
            var result = await this.jobServiceUnderTest.GetJobSelectionPriceProtectionDetails(this.jobId);

            // Assert
            Assert.Equal(result.First().SelectionId, expectedResult.First().SelectionId);
            Assert.False(result.All(x => x.IsSelectionPriceProtected));
            this.jobRepository.Verify(x => x.GetJobSelectionIds(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
            this.jobRepository.Verify(x => x.GetSpaSelectionPriceProtectionDetails(this.jobId), Times.Once);
        }

        /// <summary>
        /// Verifies get job basic information
        /// </summary>
        /// <returns>Job basic Information</returns>
        [Fact]
        public async Task GetJobBasicInformation_ValidInput_ReturnsJobBasicInformation()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo
            {
                JOB_NAME = "UR Tacoma 9916853",
                SALES_OFFICE_NAME = "Billings",
                HQTR_JOB_ID = 89765,
                STREET_ADDRESS_1 = "2222 32nd Street South",
                STREET_ADDRESS_2 = "28",
                CITY = "BRAMPTON",
                PRICING_SPA_NBR = "15-49954",
                PROVINCE = "AB",
                DOMESTIC_INTERNATIONL_IND = "I",
                ORACLE_PROJECT_IND = "Y",
                JOB_CONTACT = "ctlsar",
                STATUS = "P",
                LOST_TO_COMPETITOR = null
            };

            JobBasicInfoViewModel jobBasicInfoView = new JobBasicInfoViewModel
            {
                JobName = "UR Tacoma 9916853",
                SalesOfficeName = "Billings",
                HqtrJobId = 89765,
                PricingSpaNumber = "15-49954",
                OracleProjectIndicator = "Y",
                JobContact = "ctlsar",
                JobAddress = new JobAddressView
                {
                    StreetAddress1 = "2222 32nd Street South",
                    StreetAddress2 = "28",
                    City = "BRAMPTON",
                    Province = "AB",
                    DomesticInternationlInd = "I"
                },
                JobStatus = "P",
                LostToCompetitor = null,
            };

            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));

            // Act
            var result = await this.jobServiceUnderTest.GetJobBasicInformation(this.jobId);

            // Assert
            Assert.Equal(result.JobName, jobBasicInfoView.JobName);
            Assert.Equal(result.SalesOfficeName, jobBasicInfoView.SalesOfficeName);
            Assert.Equal(result.JobAddress.StreetAddress1, jobBasicInfoView.JobAddress.StreetAddress1);
            Assert.Equal(result.JobAddress.StreetAddress2, jobBasicInfoView.JobAddress.StreetAddress2);
            Assert.Equal(result.JobAddress.DomesticInternationlInd, jobBasicInfoView.JobAddress.DomesticInternationlInd);
            Assert.Equal(result.JobAddress.Province, jobBasicInfoView.JobAddress.Province);
            Assert.Equal(result.OracleProjectIndicator, jobBasicInfoView.OracleProjectIndicator);
            Assert.Equal(result.JobContact, jobBasicInfoView.JobContact);
            Assert.Equal(result.JobStatus, jobBasicInfoView.JobStatus);
            Assert.Equal(result.LostToCompetitor, jobBasicInfoView.LostToCompetitor);
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
        }

        /// <summary>
        /// Verifies get job basic information
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetJobBasicInformation_ValidInput_ReturnsNull()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = null;
            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));

            // Act
            var result = await this.jobServiceUnderTest.GetJobBasicInformation(this.jobId);

            // Assert
            Assert.Null(result);
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
        }

        /// <summary>
        ///  Verifies for favorites response
        /// </summary>
        /// <returns>List of favorite</returns>
        [Fact]
        public async Task GetFavorites_ValidInput_ReturnsFavorites()
        {
            // Arrange
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            FavoriteJobViewModel favoriteView = Helper.GetFavoriteJobRecord();
            FavoriteJob favorite = Helper.GetFavoriteJobModelRecord();
            IEnumerable<BsonDocument> favoritesBsonDocument = new List<BsonDocument>() { favorite.ToBsonDocument() };
            this.jobRepository.Setup(x => x.GetFavorites(It.IsAny<int>(), this.userId)).Returns(Task.FromResult(favoritesBsonDocument));

            // Act
            IEnumerable<FavoriteJobViewModel> results = await this.jobServiceUnderTest.GetFavorites();

            // Assert
            Assert.NotEmpty(results);
            Assert.Equal(results.Count(), favoritesBsonDocument.Count());
            Assert.True(results.All(result => result.UserId == favoriteView.UserId && result.JobId == favoriteView.JobId));
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        /// <summary>
        ///  Verifies for empty list response with valid input
        /// </summary>
        /// <returns>Empty favorite list</returns>
        [Fact]
        public async Task GetFavorites_ValidInput_ReturnsEmptyList()
        {
            // Arrange
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            IEnumerable<BsonDocument> favoritesBsonDocument = Enumerable.Empty<BsonDocument>();
            this.jobRepository.Setup(x => x.GetFavorites(It.IsAny<int>(), this.userId)).Returns(Task.FromResult(favoritesBsonDocument));

            // Act
            IEnumerable<FavoriteJobViewModel> results = await this.jobServiceUnderTest.GetFavorites();

            // Assert
            Assert.Empty(results);
            this.jobRepository.Verify(x => x.GetFavorites(this.drAddressId, this.userId), Times.Once);
        }

        [Fact]
        public async Task SendNotificationMessage_ForGivenJobIdAndType_MessageSentSuccessfullyAndReturnsTrue()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo()
            {
                JOB_NAME = "Test Job",
                JOB_CONTACT = "cstdl"
            };
            BuildNotificationView buildNotificationView = new BuildNotificationView()
            {
                JobId = this.jobId,
                NotificationType = NotificationType.Address
            };
            TSMTSettings tsmtSettings = new TSMTSettings { SnsServiceUrlForNotifications = "fake-url" };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.tsmtSettingsMock.Setup(x => x.Value).Returns(tsmtSettings);
            IEnumerable<string> followingUsers = new List<string> { };
            this.favoriteServiceMock.Setup(x => x.GetFollowingUsers(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(followingUsers));
            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));
            this.jobsSnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(It.IsAny<string>()));

            // Act
            bool result = await this.jobServiceUnderTest.SendNotificationMessage(buildNotificationView);

            // Assert
            Assert.True(result);
            this.tsmtSettingsMock.Verify(x => x.Value, Times.Once);
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
            this.favoriteServiceMock.Verify(x => x.GetFollowingUsers(this.drAddressId, this.jobId), Times.Once);
            this.jobsSnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), "fake-url", null), Times.Once);
        }

        [Fact]
        public async Task SendNotificationMessage_ForGivenJobIdAndType_ExceptionOccuredWhileSendingMessageAndReturnsFalse()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo()
            {
                JOB_NAME = "Test Job",
                JOB_CONTACT = "cstdl"
            };
            BuildNotificationView buildNotificationView = new BuildNotificationView()
            {
                JobId = this.jobId,
                NotificationType = NotificationType.Address
            };
            IEnumerable<string> followingUsers = new List<string> { };
            TSMTSettings tsmtSettings = new TSMTSettings { SnsServiceUrlForNotifications = "fake-url" };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.tsmtSettingsMock.Setup(x => x.Value).Returns(tsmtSettings);
            this.favoriteServiceMock.Setup(x => x.GetFollowingUsers(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(followingUsers));
            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));
            this.jobsSnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Throws(new Exception("BadRequest"));

            // Act
            bool result = await this.jobServiceUnderTest.SendNotificationMessage(buildNotificationView);

            // Assert
            Assert.False(result);
            this.tsmtSettingsMock.Verify(x => x.Value, Times.Once);
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
            this.favoriteServiceMock.Verify(x => x.GetFollowingUsers(this.drAddressId, this.jobId), Times.Once);
            this.jobsSnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), "fake-url", null), Times.Once);
        }

        [Fact]
        public async Task BuildMessagesAsync_ForGivenJobIdAndType_ReturnsNotificationMessage()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo()
            {
                JOB_NAME = "Test Job",
                JOB_CONTACT = "user1"
            };
            BuildNotificationView buildNotificationView = new BuildNotificationView()
            {
                JobId = this.jobId,
                NotificationType = NotificationType.Address,
                DrAddressId = 122,
                UserId = "user1"
            };
            IEnumerable<string> followingUsers = new List<string> { "user1", "user2" };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.favoriteServiceMock.Setup(x => x.GetFollowingUsers(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(followingUsers));
            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));

            // Act
            var result = await this.jobServiceUnderTest.BuildMessagesAsync(buildNotificationView);

            // Assert
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
            this.favoriteServiceMock.Verify(x => x.GetFollowingUsers(buildNotificationView.DrAddressId, this.jobId), Times.Once);
            Assert.Single(result);
            Assert.Equal("user2", result.ElementAt(0).UserId);
            Assert.Contains(result, x => x.ShortMessage == "Success");
            Assert.Contains(result, x => x.IsNotificationRead == false);
            Assert.Contains(result, x => x.LongMessage == "Address section on the job Test Job has been updated by Cassie DeWaay");
            Assert.Contains(result, x => x.Application == "SalesWeb");
            Assert.Contains(result, x => x.UrlPath == "/jobs-list/555/122/details");
        }

        [Fact]
        public async Task BuildMessagesAsync_RequestForBidCreateNotification_ReturnsNotificationMessage()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo()
            {
                JOB_NAME = "Test Job",
                JOB_CONTACT = "user1"
            };
            BuildNotificationView buildNotificationView = new BuildNotificationView()
            {
                JobId = this.jobId,
                NotificationType = NotificationType.Bid,
                DrAddressId = 122,
                BidName = "Base Bid",
                UserName = "First, Last",
                Action = BidNotificationType.Create
            };
            IEnumerable<string> followingUsers = Enumerable.Empty<string>();
            this.favoriteServiceMock.Setup(x => x.GetFollowingUsers(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(followingUsers));
            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));

            // Act
            var result = await this.jobServiceUnderTest.BuildMessagesAsync(buildNotificationView);

            // Assert
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
            this.favoriteServiceMock.Verify(x => x.GetFollowingUsers(buildNotificationView.DrAddressId, this.jobId), Times.Once);
            Assert.Contains(result, x => x.LongMessage == "Base Bid has been created on the job Test Job by First, Last");
        }

        [Fact]
        public async Task BuildMessagesAsync_RequestForBidUpdateNotification_ReturnsNotificationMessage()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo()
            {
                JOB_NAME = "Test Job",
                JOB_CONTACT = "user1"
            };
            BuildNotificationView buildNotificationView = new BuildNotificationView()
            {
                JobId = this.jobId,
                NotificationType = NotificationType.Bid,
                DrAddressId = 122,
                BidName = "Base Bid",
                UserName = "First, Last",
                Action = BidNotificationType.Edit
            };
            IEnumerable<string> followingUsers = Enumerable.Empty<string>();
            this.favoriteServiceMock.Setup(x => x.GetFollowingUsers(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(followingUsers));
            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));

            // Act
            var result = await this.jobServiceUnderTest.BuildMessagesAsync(buildNotificationView);

            // Assert
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
            this.favoriteServiceMock.Verify(x => x.GetFollowingUsers(buildNotificationView.DrAddressId, this.jobId), Times.Once);
            Assert.Contains(result, x => x.LongMessage == "Base Bid on the job Test Job has been updated by First, Last");
        }

        [Fact]
        public async Task BuildMessagesAsync_RequestForBidDeleteNotification_ReturnsNotificationMessage()
        {
            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo()
            {
                JOB_NAME = "Test Job",
                JOB_CONTACT = "user1"
            };
            BuildNotificationView buildNotificationView = new BuildNotificationView()
            {
                JobId = this.jobId,
                NotificationType = NotificationType.Bid,
                DrAddressId = 122,
                BidName = "Base Bid",
                UserName = "First, Last",
                Action = BidNotificationType.Delete
            };
            IEnumerable<string> followingUsers = Enumerable.Empty<string>();
            this.favoriteServiceMock.Setup(x => x.GetFollowingUsers(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(followingUsers));
            this.jobRepository.Setup(x => x.GetJobBasicInformation(It.IsAny<int>())).Returns(Task.FromResult(jobBasicInfo));

            // Act
            var result = await this.jobServiceUnderTest.BuildMessagesAsync(buildNotificationView);

            // Assert
            this.jobRepository.Verify(x => x.GetJobBasicInformation(this.jobId), Times.Once);
            this.favoriteServiceMock.Verify(x => x.GetFollowingUsers(buildNotificationView.DrAddressId, this.jobId), Times.Once);
            Assert.Contains(result, x => x.LongMessage == "Base Bid on the job Test Job has been deleted by First, Last");
        }

        [Fact]
        public async Task GetReferenceUnits_HasData_ReturnsReferenceUnits()
        {
            // Arrange
            IEnumerable<ReferenceUnitViewModel> referenceUnits = new List<ReferenceUnitViewModel>()
            {
                new ReferenceUnitViewModel()
                {
                    ReferenceUnitId = 10449484,
                    JobId = 668341,
                    TagSequenceNbr = 1,
                    ReviseDate = DateTime.Now
                }
            };

            this.jobRepository.Setup(x => x.GetReferenceUnitListAsync(It.IsAny<int>())).Returns(Task.FromResult(referenceUnits));

            // Act
            IEnumerable<ReferenceUnitViewModel> result = await this.jobServiceUnderTest.GetReferenceUnits(this.jobId);

            // Assert
            Assert.Equal(result, referenceUnits);
            this.jobRepository.Verify(x => x.GetReferenceUnitListAsync(this.jobId), Times.Once);
        }

        /// <summary>
        ///  Get reference unit list
        /// </summary>
        /// <returns>Empty result</returns>
        [Fact]
        public async Task GetReferenceUnits_HasNoData_ReturnsEmpty()
        {
            // Arrange
            IEnumerable<ReferenceUnitViewModel> referenceUnitList = new List<ReferenceUnitViewModel>();

            this.jobRepository.Setup(x => x.GetReferenceUnitListAsync(It.IsAny<int>()))
                .Returns(Task.FromResult(referenceUnitList));

            // Act
            var result = await this.jobServiceUnderTest.GetReferenceUnits(this.jobId);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify(x => x.GetReferenceUnitListAsync(this.jobId), Times.Once);
        }

        /// <summary>
        /// Get job lock information based on valid hqtr job id
        /// </summary>
        /// <returns>Cam data</returns>
        [Fact]
        public async Task GetCamInfo_ValidRequest_ReuturnCamData()
        {
            // Assign
            var jobLockInfo = new JobLockInfoModel()
            {
                USER_ID = "lalcj",
                HQTR_JOB_ID = 123456,
                JOB_ID = 1234,
            };
            LockData lockData = new LockData
            {
                LockUserId = "lalcj",
                JobId = 123456,
                HqtrJobId = 1234,
            };
            CamInput camInput = new CamInput();
            camInput.LocalData = new CamInputMetaData() { JobId = 10234 };
            this.jobRepository.Setup(x => x.GetJobLockInformation(It.IsAny<int>())).Returns(Task.FromResult(jobLockInfo));

            // Act
            var result = await this.jobServiceUnderTest.GetCamInfo(camInput);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(jobLockInfo.USER_ID, result.LocalLock.LockUserId);
            Assert.Equal(jobLockInfo.JOB_ID, result.LocalLock.JobId);
            Assert.Equal(jobLockInfo.HQTR_JOB_ID, result.LocalLock.HqtrJobId);
            this.jobRepository.Verify(x => x.GetJobLockInformation(camInput.LocalData.JobId), Times.Once);
        }

        /// <summary>
        /// Get job lock information has no data - returns empty
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetCamInfo_HasNoData_ReturnEmpty()
        {
            // Assign
            JobLockInfoModel jobLockInfo = null;
            CamInput camInput = new CamInput();
            camInput.LocalData = new CamInputMetaData() { JobId = 10234 };
            this.jobRepository.Setup(x => x.GetJobLockInformation(It.IsAny<int>())).Returns(Task.FromResult(jobLockInfo));

            // Act
            var result = await this.jobServiceUnderTest.GetCamInfo(camInput);

            // Assert
            Assert.Null(result);
            this.jobRepository.Verify(x => x.GetJobLockInformation(camInput.LocalData.JobId), Times.Once);
        }

        [Fact]
        public async Task GetPersonId_RetrivedSuccessfully_ReturnsPersonId()
        {
            // Assign
            string commCode = "H35";
            int salesOfficeId = 54;
            string personId = "234567";
            this.jobRepository.Setup(x => x.GetPersonId(It.IsAny<string>(), It.IsAny<int>()))
                .Returns(Task.FromResult(personId));

            // Act
            var result = await this.jobServiceUnderTest.GetPersonId(commCode, salesOfficeId);

            // Assert
            Assert.Equal(personId, result);
            this.jobRepository.Verify(x => x.GetPersonId(commCode, salesOfficeId), Times.Once);
        }
    }
}
