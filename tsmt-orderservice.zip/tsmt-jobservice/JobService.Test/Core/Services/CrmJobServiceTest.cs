// <copyright file="CrmJobServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.Services
{
    using System.Collections.Generic;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using AutoMapper;
    using global::JobService.Common.Exceptions;
    using global::JobService.Core.Models;
    using global::JobService.Core.ViewModels;
    using global::JobService.Repository;
    using global::JobService.Test.Common;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    /// <summary>
    /// Crm Job Service Test Methods
    /// </summary>
    public class CrmJobServiceTest
    {
        private readonly Mock<IRepository<global::JobService.Core.Models.JobDetails>> repository;
        private readonly Mock<IJobRepository> jobRepository;
        private readonly Mock<IJobService> jobService;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly IMapper mapper;
        private readonly CrmJobService crmJobServiceUnderTest;
        private readonly string userId = "asdabc";
        private readonly DefaultHttpContext httpContext = new DefaultHttpContext();
        private readonly Mock<ISalesCustomerService> salesCustomerService;

        public CrmJobServiceTest()
        {
            this.repository = new Mock<IRepository<JobDetails>>();
            this.jobRepository = new Mock<IJobRepository>();
            this.jobService = new Mock<IJobService>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            this.salesCustomerService = new Mock<ISalesCustomerService>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.httpContext.Items.Add("DR_ADDRESS_ID", 78);
            List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", this.userId),
                new Claim("firstname", "Cassie"),
                new Claim("lastname", "DeWaay")
            };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            ClaimsIdentity appIdentity = new ClaimsIdentity(claims);
            this.httpContext.User.AddIdentity(appIdentity);
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.crmJobServiceUnderTest = new CrmJobService(this.repository.Object, this.mapper, this.jobRepository.Object, this.jobService.Object, this.contextAccessor.Object, this.salesCustomerService.Object);
        }

        [Fact]
        public async Task CreateCrmJob_ValidCrmJobViewModel_ReturnsJobId()
        {
            // Arrange
            int jobId = 4004;
            int jobReportId = 44;
            int bidAlternateId = 20;
            int isAssigned = 1;
            CrmJobViewModel crmJob = Helper.GetCrmJobViewModel();
            IEnumerable<RoleTypeViewModel> roleTypeViewModels = new List<RoleTypeViewModel>() { new RoleTypeViewModel() { RoleTypeId = "1", RoleTypeName = "Unknown" } };

            this.jobRepository.Setup(x => x.GetSequenceNumber("job"))
                .Returns(Task.FromResult(jobId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("JOB_REPORT"))
                .Returns(Task.FromResult(jobReportId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
                .Returns(Task.FromResult(bidAlternateId));
            this.jobService.Setup(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            this.jobService.Setup(x => x.GetRoleTypeList()).ReturnsAsync(roleTypeViewModels);
            this.salesCustomerService.Setup(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>())).Returns(Task.FromResult(isAssigned));
            this.jobService.Setup(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            this.jobRepository.Setup(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId))
                .Returns(Task.FromResult(jobId));

            List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            // Act
            int returnJobId = await this.crmJobServiceUnderTest.CreateCrmJob(crmJob);

            // Assert
            Assert.Equal(returnJobId, jobId);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(3));
            this.jobRepository.Verify(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId), Times.Once);
            this.jobService.Verify(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()), Times.Once);
            this.jobService.Verify(x => x.GetRoleTypeList(), Times.Once);
            this.salesCustomerService.Verify(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>()), Times.Once);
            this.jobService.Verify(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task CreateCrmJob_InvalidRequest_ReturnInvalidJobId()
        {
            // Arrange
            var jobId = 0;
            int jobReportId = 540;
            int bidAlternateId = 654;
            CrmJobViewModel crmJob = Helper.GetCrmJobViewModel();
            this.jobRepository.Setup(x => x.GetSequenceNumber("job"))
                .Returns(Task.FromResult(jobId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("JOB_REPORT"))
                .Returns(Task.FromResult(jobReportId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
                .Returns(Task.FromResult(bidAlternateId));
            this.jobRepository.Setup(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId))
                .Returns(Task.FromResult(jobId));

            // Act
            JobMaintenanceDomainException result = await Assert.ThrowsAsync<JobMaintenanceDomainException>(async () => await this.crmJobServiceUnderTest.CreateCrmJob(crmJob));

            // Assert
            Assert.IsType<JobMaintenanceDomainException>(result);
            Assert.Equal("Error occurred while creating the crm job -: TestCrmJob", result.Message);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(3));
            this.jobRepository.Verify(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId), Times.Once);
        }

        [Fact]
        public async Task CreateCrmJob_NullRequest_ReturnsJobId()
        {
            // Arrange
            var jobId = 1889;
            int jobReportId = 540;
            int bidAlternateId = 654;
            int isAssigned = 1;
            CrmJobViewModel crmJob = Helper.GetCrmJobViewModel();
            crmJob.PriorCodes = null;
            IEnumerable<RoleTypeViewModel> roleTypeViewModels = new List<RoleTypeViewModel>() { new RoleTypeViewModel() { RoleTypeId = "1", RoleTypeName = "Unknown" } };

            this.jobRepository.Setup(x => x.GetSequenceNumber("job"))
                .Returns(Task.FromResult(jobId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("JOB_REPORT"))
                .Returns(Task.FromResult(jobReportId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
                .Returns(Task.FromResult(bidAlternateId));

            this.jobRepository.Setup(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId))
                .Returns(Task.FromResult(jobId));
            this.jobService.Setup(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            this.jobService.Setup(x => x.GetRoleTypeList()).ReturnsAsync(roleTypeViewModels);
            this.salesCustomerService.Setup(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>())).Returns(Task.FromResult(isAssigned));

            List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            // Act
            int returnJobId = await this.crmJobServiceUnderTest.CreateCrmJob(crmJob);

            // Assert
            Assert.Equal(returnJobId, jobId);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(3));
            this.jobRepository.Verify(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId), Times.Once);
            this.jobService.Verify(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()), Times.Once);
            this.salesCustomerService.Verify(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>()), Times.Once);
            this.jobService.Verify(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()), Times.Never);
            this.jobService.Verify(x => x.GetRoleTypeList(), Times.Once);
        }

        [Fact]
        public async Task CreateCrmJob_NullClassificationRequest_ReturnsJobId()
        {
            // Arrange
            int jobId = 1889;
            int jobReportId = 540;
            int bidAlternateId = 654;
            int isAssigned = 1;
            CrmJobViewModel crmJob = Helper.GetCrmJobViewModel();
            crmJob.ClassificationList = null;
            IEnumerable<RoleTypeViewModel> roleTypeViewModels = new List<RoleTypeViewModel>() { new RoleTypeViewModel() { RoleTypeId = "1", RoleTypeName = "Unknown" } };

            this.jobRepository.Setup(x => x.GetSequenceNumber("job"))
                .Returns(Task.FromResult(jobId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("JOB_REPORT"))
                .Returns(Task.FromResult(jobReportId));
            this.jobRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
                .Returns(Task.FromResult(bidAlternateId));

            this.jobRepository.Setup(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId))
                .Returns(Task.FromResult(jobId));
            this.jobService.Setup(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            this.jobService.Setup(x => x.GetRoleTypeList()).ReturnsAsync(roleTypeViewModels);
            this.salesCustomerService.Setup(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>())).Returns(Task.FromResult(isAssigned));

            List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
            this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

            // Act
            int returnJobId = await this.crmJobServiceUnderTest.CreateCrmJob(crmJob);

            // Assert
            Assert.Equal(returnJobId, jobId);
            this.jobRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(3));
            this.jobRepository.Verify(x => x.InsertJobAsync(It.IsAny<Job>(), jobReportId, bidAlternateId), Times.Once);
            this.jobService.Verify(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()), Times.Once);
            this.jobService.Verify(x => x.GetRoleTypeList(), Times.Once);
            this.salesCustomerService.Verify(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>()), Times.Once);
            this.jobService.Verify(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()), Times.Once);
        }
    }
}
