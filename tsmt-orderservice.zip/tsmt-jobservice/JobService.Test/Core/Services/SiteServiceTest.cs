// <copyright file="SiteServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace JobService.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using Xunit;

    /// <summary>
    /// Site service test
    /// </summary>
    public class SiteServiceTest
    {
        private readonly Mock<ISiteRepository> siteRepository;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly IMapper mapper;
        private readonly SiteService siteService;

        public SiteServiceTest()
        {
            this.siteRepository = new Mock<ISiteRepository>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.siteService = new SiteService(this.mapper, this.siteRepository.Object, this.contextAccessor.Object);
        }

        [Fact]
        public async Task GetCrmSiteDetails_HasCrmDetails_ReturnsCrmDetails()
        {
            // Arrange
            IEnumerable<CrmSiteViewModel> expectedCrmSitesViewModel = new List<CrmSiteViewModel>()
            {
                Helper.GetCrmSiteViewModel()
            };
            IEnumerable<CrmSiteModel> expectedCrmSitesModel = new List<CrmSiteModel>()
            {
                Helper.GetCrmSiteModel()
            };
            int skip = 0;
            int take = 10;
            string searchText = "Test";
            int drAddressId = 101;
            string companyId = "123";
            var drAddressIdFromHttpContext = new Dictionary<object, object>();
            drAddressIdFromHttpContext.Add("DR_ADDRESS_ID", drAddressId);
            this.contextAccessor.Setup(x => x.HttpContext.Items).Returns(drAddressIdFromHttpContext);
            this.siteRepository.Setup(x => x.GetCrmSiteDetails(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult(expectedCrmSitesModel));

            // Dr address id is honored through http context accessor, so creating seperate instance for job document service
            var siteService = new SiteService(this.mapper, this.siteRepository.Object, this.contextAccessor.Object);

            // Act
            SitePagingResult result = await this.siteService.GetCrmSiteDetails(skip, take, searchText, companyId);

            // Assert
            Assert.IsType<SitePagingResult>(result);
            Assert.Equal(expectedCrmSitesViewModel.Count(), result.Sites.Count());
            Assert.True(result.Sites.Select(a => a.SiteName == expectedCrmSitesViewModel.Single().SiteName).Any());
            Assert.True(result.Sites.Select(a => a.StreetAddress1 == expectedCrmSitesViewModel.Single().StreetAddress1).Any());
            Assert.True(result.Sites.Select(a => a.StreetAddress2 == expectedCrmSitesViewModel.Single().StreetAddress2).Any());
            Assert.True(result.Sites.Select(a => a.StreetAddress3 == expectedCrmSitesViewModel.Single().StreetAddress3).Any());
            Assert.True(result.Sites.Select(a => a.StreetAddress4 == expectedCrmSitesViewModel.Single().StreetAddress4).Any());
            Assert.True(result.Sites.Select(a => a.TotalCount == 1).Any());
            Assert.True(result.PageNumber == 1);
            Assert.True(result.PageSize == take);
            Assert.True(result.PageCount == 1);
            this.contextAccessor.Verify(x => x.HttpContext.Items, Times.AtLeastOnce);
            this.siteRepository.Verify(x => x.GetCrmSiteDetails(skip, take, searchText, companyId), Times.Once);
        }

        [Fact]
        public async Task GetCrmDetails_HasNoData_ReturnsNull()
        {
            // Arrange
            IEnumerable<CrmSiteModel> sites = new List<CrmSiteModel>();
            int skip = 0;
            int take = 10;
            string searchText = "Test";
            string companyId = "123";

            this.siteRepository.Setup(x => x.GetCrmSiteDetails(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult(sites));

            // Act
            SitePagingResult result = await this.siteService.GetCrmSiteDetails(skip, take, searchText, companyId);

            // Assert
            Assert.Null(result);
            this.siteRepository.Verify(x => x.GetCrmSiteDetails(skip, take, searchText, companyId), Times.Once);
        }

        /// <summary>
        /// Test to honor a drAddressId
        /// </summary>
        [Fact]
        public void HonorDrAddressId_ValidDrAddressId_DrAddressIdHonored()
        {
            // Arrange
            int drAddressId = 12;
            DefaultHttpContext context = new DefaultHttpContext();
            context.Items.Add("DR_ADDRESS_ID", drAddressId);
            this.contextAccessor.Setup(contextAccessorMock => contextAccessorMock.HttpContext).Returns(context);

            // Act
            SiteService service = new SiteService(this.mapper, this.siteRepository.Object, this.contextAccessor.Object);

            // Assert
            this.siteRepository.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
        }
    }
}
