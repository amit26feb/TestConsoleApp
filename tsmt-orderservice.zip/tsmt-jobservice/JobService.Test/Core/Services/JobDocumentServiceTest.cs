// <copyright file="JobDocumentServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using Amazon.S3.Model;
    using Amazon.SQS.Model;
    using AutoMapper;
    using AWS.MessagingWrapper.Contracts;
    using JobService.Common.Constants;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using Newtonsoft.Json;
    using S3Wrapper;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// Job Document Service Test Methods
    /// </summary>
    public class JobDocumentServiceTest
    {
        private readonly Mock<IJobDocumentRepository> jobDocumentRepository;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly IMapper mapper;
        private readonly Mock<IWebHostEnvironment> hostingEnvironment;
        private readonly Mock<IS3Repository> s3Repository;
        private readonly Mock<IOptions<TSMTSettings>> appSettings;
        private readonly int skip = 10;
        private readonly int take = 20;
        private readonly Mock<ILogger<JobDocumentService>> logger;
        private readonly Mock<IMessageReceiver> messageReceiver;
        private readonly Mock<IJobRepository> jobRepository;
        private readonly Mock<IJobCoordinationService> jobCoordinationServiceMock;
        private readonly JobDocumentService jobDocumentService;
        private readonly List<string> folderNames = new List<string>() { JobAction.UploadNonTraneDocument, Helper.GetDocumentFolderViewModel().FolderName };

        private readonly int jobId = 12334;
        private readonly int variationId = 63520;

        public JobDocumentServiceTest()
        {
            this.jobDocumentRepository = new Mock<IJobDocumentRepository>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.hostingEnvironment = new Mock<IWebHostEnvironment>();
            this.s3Repository = new Mock<IS3Repository>();
            this.appSettings = new Mock<IOptions<TSMTSettings>>();
            this.logger = new Mock<ILogger<JobDocumentService>>();
            this.messageReceiver = new Mock<IMessageReceiver>();
            this.jobRepository = new Mock<IJobRepository>();
            this.jobCoordinationServiceMock = new Mock<IJobCoordinationService>();
            this.jobDocumentService = new JobDocumentService(this.mapper, this.jobDocumentRepository.Object, this.contextAccessor.Object, this.s3Repository.Object, this.appSettings.Object, this.logger.Object, this.messageReceiver.Object, this.jobRepository.Object, this.jobCoordinationServiceMock.Object);
        }

        [Fact]
        public async Task InsertJobDocument_ValidInput_ReturnsTrue()
        {
            // Arrange
            global::JobService.Core.ViewModels.JobDocumentView jobDocumentView = new global::JobService.Core.ViewModels.JobDocumentView
            {
                JobId = 178456,
                DrAddressId = 94,
                DocumentName = "Test"
            };
            Stream documentStream = new MemoryStream();
            PutObjectResponse putResponse = new PutObjectResponse();
            putResponse.VersionId = "1";
            var httpContext = new DefaultHttpContext();
            httpContext.Items.Add("DR_ADDRESS_ID", 78);
            TSMTSettings appSetting = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };
            this.appSettings.Setup(ap => ap.Value).Returns(appSetting);
            DocumentFolderViewModel documentFolderViewModel = null;

            this.jobDocumentRepository.Setup(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            this.jobDocumentRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>()))
               .Returns(Task.FromResult(It.IsAny<int>()));
            this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);
            this.s3Repository.Setup(x => x.PutObjectAsync(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<MemoryStream>(), null)).Returns(Task.FromResult(putResponse));

            // Act
            var result = await this.jobDocumentService.UploadJobDocument(jobDocumentView, documentStream, documentFolderViewModel);

            // Assert
            Assert.True(result);
            this.s3Repository.Verify(x => x.PutObjectAsync(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<MemoryStream>(), null), Times.Once);
            this.jobDocumentRepository.Verify(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()), Times.Once);
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Once);
            documentStream.Dispose();
        }

        [Fact]
        public async Task InsertJobDocument_ValidInput_ReturnsFalse()
        {
            // Arrange
            int drAddressId = 101;
            var drAddressIdFromHttpContext = new Dictionary<object, object>();
            drAddressIdFromHttpContext.Add("DR_ADDRESS_ID", drAddressId);
            this.contextAccessor.Setup(x => x.HttpContext.Items).Returns(drAddressIdFromHttpContext);
            global::JobService.Core.ViewModels.JobDocumentView jobDocumentView = new global::JobService.Core.ViewModels.JobDocumentView
            {
                JobId = 178456,
                DrAddressId = drAddressId,
                DocumentName = "Test"
            };
            PutObjectResponse putResponse = new PutObjectResponse();
            TSMTSettings appSetting = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };

            DocumentFolderViewModel documentFolderViewModel = null;

            Stream documentStream = new MemoryStream();
            this.appSettings.Setup(ap => ap.Value).Returns(appSetting);

            this.jobDocumentRepository.Setup(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            this.jobDocumentRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>()))
                .Returns(Task.FromResult(It.IsAny<int>()));
            this.s3Repository.Setup(x => x.PutObjectAsync(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<MemoryStream>(), null)).Returns(Task.FromResult(putResponse));

            // Dr address id is honored through http context accessor, so creating seperate instance for job document service
            var serviceUnderTest = new JobDocumentService(this.mapper, this.jobDocumentRepository.Object, this.contextAccessor.Object, this.s3Repository.Object, this.appSettings.Object, this.logger.Object, this.messageReceiver.Object, this.jobRepository.Object, this.jobCoordinationServiceMock.Object);

            // Act
            var result = await serviceUnderTest.UploadJobDocument(jobDocumentView, documentStream, documentFolderViewModel);

            // Assert
            Assert.False(result);
            this.contextAccessor.Verify(x => x.HttpContext.Items, Times.AtLeastOnce);
            this.jobDocumentRepository.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
            this.jobRepository.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
            this.s3Repository.Verify(x => x.PutObjectAsync(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<MemoryStream>(), null), Times.Once);
            this.jobDocumentRepository.Verify(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()), Times.Never);
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Never);
            documentStream.Dispose();
        }

        [Fact]
        public async Task GetDocumentHistory_ValidInput_ReturnsDocumentHistoryDetails()
        {
            // Arrange
            int jobId = 27397;
            string documentKey = "Jobs/78/27397/UploadFile.txt";
            IEnumerable<JobDocument> documentHistory = new List<JobDocument>()
            {
                new JobDocument()
                {
                    DOCUMENT_KEY = documentKey,
                    DOCUMENT_NAME = "UploadFile.txt",
                    DOCUMENT_SOURCE = null,
                    DOCUMENT_VERSION = "27uXDVc_9nVrd4.r..Q3JIdmc.SBLeoU",
                    UPLOADED_USER_ID = "ccfbok"
                }
            };
            this.jobDocumentRepository.Setup(x => x.GetDocumentHistoryAsync(It.IsAny<int>(), It.IsAny<string>())).Returns(Task.FromResult(documentHistory));

            // Act
            var result = await this.jobDocumentService.GetDocumentHistory(jobId, documentKey);

            // Assert
            Assert.True(result.Select(a => a.DocumentKey == "Jobs/78/27397/UploadFile.txt").Any());
            Assert.True(result.Select(a => a.DocumentName == "UploadFile.txt").Any());
            Assert.True(result.Select(a => a.DocumentVersion == "27uXDVc_9nVrd4.r..Q3JIdmc.SBLeoU").Any());
            this.jobDocumentRepository.Verify(x => x.GetDocumentHistoryAsync(It.IsAny<int>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetDocumentHistory_InValidInput_ReturnsEmptyDocumentHistoryDetails()
        {
            // Arrange
            int jobId = 27397;
            string documentKey = "Jobs/78/27397/UploadFile.txt";
            IEnumerable<JobDocument> documentHistory = new List<JobDocument>();
            this.jobDocumentRepository.Setup(x => x.GetDocumentHistoryAsync(It.IsAny<int>(), It.IsAny<string>())).Returns(Task.FromResult(documentHistory));

            // Act
            var result = await this.jobDocumentService.GetDocumentHistory(jobId, documentKey);

            // Assert
            Assert.Empty(result);
            this.jobDocumentRepository.Verify(x => x.GetDocumentHistoryAsync(It.IsAny<int>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetDocumentList_ValidRequest_ReturnsDocumentList()
        {
            // Arrange
            IEnumerable<JobDocument> jobDocument = new List<JobDocument>()
            {
                new JobDocument()
                {
                    JOB_DOCUMENT_ID = 123,
                    DOCUMENT_KEY = "AB",
                    DOCUMENT_NAME = "PersonalDocument",
                    JOB_ID = 1234,
                    TOTAL_COUNT = 1,
                }
            };
            int jobId = 1233;
            int folderId = 123;
            this.jobDocumentRepository.Setup(x => x.GetDocumentList(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
           .Returns(Task.FromResult(jobDocument)).Verifiable();

            // Act
            DocumentListPagingResults viewResult = await this.jobDocumentService.GetDocumentList(jobId, folderId, this.skip, this.take);

            // Assert
            Assert.NotNull(viewResult);
            Assert.IsType<DocumentListPagingResults>(viewResult);
            this.jobDocumentRepository.Verify();
        }

        [Fact]
        public async Task GetDocumentList_InvalidRequest_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobDocument> jobDocument = new List<JobDocument>();
            int jobId = 1248;
            int folderId = 123;
            this.jobDocumentRepository.Setup(x => x.GetDocumentList(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
           .Returns(Task.FromResult(jobDocument)).Verifiable();

            // Act
            DocumentListPagingResults viewResult = await this.jobDocumentService.GetDocumentList(jobId, folderId, this.skip, this.take);

            // Assert
            Assert.Null(viewResult);
            this.jobDocumentRepository.Verify();
        }

        [Fact]
        public async Task DeleteDocument_ValidRequest_ReturnsDeletedStatusAsTrue()
        {
            // Arrange
            string documentKey = "Jobs/78/26613/upload.txt";
            DeleteObjectResponse deleteResponse = new DeleteObjectResponse()
            {
                DeleteMarker = "true"
            };
            TSMTSettings appSetting = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };
            int jobId = 12334;
            this.appSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.jobDocumentRepository.Setup(x => x.DeleteDocumentAsync(It.IsAny<string>())).Returns(Task.FromResult(true));
            this.s3Repository.Setup(x => x.DeleteObjectAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(deleteResponse));
            this.jobCoordinationServiceMock.Setup(x => x.SendJobCoordinationDocumentUpdateRequest(documentKey, jobId)).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobDocumentService.DeleteDocument(documentKey, jobId);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentAsync(It.IsAny<string>()), Times.Once);
            this.jobCoordinationServiceMock.Verify(x => x.SendJobCoordinationDocumentUpdateRequest(documentKey, jobId), Times.Once);
            this.s3Repository.Verify(x => x.DeleteObjectAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task DeleteDocument_LegacyRequestAndDeletes_ReturnsDeletedStatusAsTrue()
        {
            // Arrange
            DeleteObjectResponse deleteResponse = new DeleteObjectResponse()
            {
                DeleteMarker = "true"
            };
            string documentKey = "jobs-legacy-files/upload.txt";
            string bucketName = "blah";
            int jobId = 1234;
            this.appSettings.Setup(ap => ap.Value).Returns(new TSMTSettings { Bucket = bucketName });
            this.s3Repository.Setup(x => x.DeleteObjectAsync(bucketName, documentKey)).Returns(Task.FromResult(deleteResponse));

            // Act
            var result = await this.jobDocumentService.DeleteDocument(documentKey, jobId);

            // Assert
            Assert.True(result);
            this.s3Repository.Verify(x => x.DeleteObjectAsync(bucketName, documentKey), Times.Once);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentAsync(It.IsAny<string>()), Times.Never);
            this.jobCoordinationServiceMock.Verify(x => x.SendJobCoordinationDocumentUpdateRequest(It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task DeleteDocument_LegacyRequestAndCannotDelete_ReturnsDeletedStatusAsFalse()
        {
            // Arrange
            DeleteObjectResponse deleteResponse = new DeleteObjectResponse()
            {
                DeleteMarker = "false"
            };
            string documentKey = "jobs-legacy-files/upload.txt";
            string bucketName = "blah";
            int jobId = 1234;
            this.appSettings.Setup(ap => ap.Value).Returns(new TSMTSettings { Bucket = bucketName });
            this.s3Repository.Setup(x => x.DeleteObjectAsync(bucketName, documentKey)).Returns(Task.FromResult(deleteResponse));

            // Act
            var result = await this.jobDocumentService.DeleteDocument(documentKey, jobId);

            // Assert
            Assert.False(result);
            this.s3Repository.Verify(x => x.DeleteObjectAsync(bucketName, documentKey), Times.Once);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentAsync(It.IsAny<string>()), Times.Never);
            this.jobCoordinationServiceMock.Verify(x => x.SendJobCoordinationDocumentUpdateRequest(It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task DeleteDocument_InValidRequest_ReturnsDeletedStatusAsFalse()
        {
            // Arrange
            string documentKey = "Jobs/upload.txt";
            int jobId = 1234;
            this.jobDocumentRepository.Setup(x => x.DeleteDocumentAsync(It.IsAny<string>())).Returns(Task.FromResult(false));

            // Act
            var result = await this.jobDocumentService.DeleteDocument(documentKey, jobId);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentAsync(It.IsAny<string>()), Times.Once);
            this.s3Repository.Verify(x => x.DeleteObjectAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public async Task DeleteDocuments_ValidRequest_ReturnsDeletedStatusAsTrue()
        {
            // Arrange
            var documentViewModelList = Helper.GetDocumentModelList();

            DeletedObject deleteResponse = new DeletedObject()
            {
                DeleteMarker = true
            };

            DeleteObjectsResponse deleteObjectsResponse = new DeleteObjectsResponse()
            {
                DeletedObjects = new List<DeletedObject>() { deleteResponse }
            };

            TSMTSettings appSetting = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };
            int jobId = 12334;
            this.appSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.jobDocumentRepository.Setup(x => x.DeleteDocumentsAsync(It.IsAny<IEnumerable<string>>())).Returns(Task.FromResult(true));
            this.jobDocumentRepository.Setup(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));
            this.s3Repository.Setup(x => x.DeleteObjectsAsync(It.IsAny<string>(), It.IsAny<List<KeyValuePair<string, string>>>())).Returns(Task.FromResult(deleteObjectsResponse));
            this.jobCoordinationServiceMock.Setup(x => x.SendJobCoordinationDocumentUpdateRequest(documentViewModelList.FirstOrDefault().DocumentKey, jobId)).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobDocumentService.DeleteDocuments(documentViewModelList, jobId, this.variationId);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsAsync(It.IsAny<IEnumerable<string>>()), Times.Once);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
            this.jobCoordinationServiceMock.Verify(x => x.SendJobCoordinationDocumentUpdateRequest(documentViewModelList.FirstOrDefault().DocumentKey, jobId), Times.Once);
            this.s3Repository.Verify(x => x.DeleteObjectsAsync(It.IsAny<string>(), It.IsAny<List<KeyValuePair<string, string>>>()), Times.Exactly(1));
        }

        [Fact]
        public async Task DeleteDocuments_EmptyFolder_ReturnsStatusAsTrue()
        {
            // Arrange
            List<DocumentViewModel> documentViewModelList = new List<DocumentViewModel>
            {
                new DocumentViewModel() { DocumentKey = null, DocumentName = null, DocumentVersion = null, JobDocumentTypeId = null }
            };

            IEnumerable<string> documentKeyList = documentViewModelList.Select(x => x.DocumentKey);

            this.jobDocumentRepository.Setup(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobDocumentService.DeleteDocuments(documentViewModelList, this.jobId, this.variationId);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsAsync(documentKeyList), Times.Never);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsFolderAsync(this.jobId, this.variationId), Times.Once);
            this.jobCoordinationServiceMock.Verify(x => x.SendJobCoordinationDocumentUpdateRequest(It.IsAny<string>(), It.IsAny<int>()), Times.Never);
            this.s3Repository.Verify(x => x.DeleteObjectsAsync(It.IsAny<string>(), It.IsAny<List<KeyValuePair<string, string>>>()), Times.Never);
        }

        [Fact]
        public async Task DeleteDocuments_InValidRequest_ReturnsDeletedStatusAsFalse()
        {
            // Arrange
            var documentViewModelList = Helper.GetDocumentModelList();
            IEnumerable<string> documentKeyList = documentViewModelList.Select(x => x.DocumentKey);

            this.jobDocumentRepository.Setup(x => x.DeleteDocumentAsync(It.IsAny<string>())).Returns(Task.FromResult(false));
            this.jobDocumentRepository.Setup(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(false));

            // Act
            var result = await this.jobDocumentService.DeleteDocuments(documentViewModelList, this.jobId, this.variationId);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsAsync(documentKeyList), Times.Once);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsFolderAsync(this.jobId, this.variationId), Times.Once);
            this.s3Repository.Verify(x => x.DeleteObjectAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            this.jobCoordinationServiceMock.Verify(x => x.SendJobCoordinationDocumentUpdateRequest(It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task DeleteDocumentsFolder_ValidRequest_ReturnsDeletedStatusAsTrue()
        {
            // Arrange
            TSMTSettings appSetting = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };

            this.appSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.jobDocumentRepository.Setup(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobDocumentService.DeleteDocumentsFolder(this.jobId, this.variationId);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task DeleteDocumentsFolder_InValidRequest_ReturnsDeletedStatusAsFalse()
        {
            // Arrange
            TSMTSettings appSetting = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };

            this.appSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.jobDocumentRepository.Setup(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(false));

            // Act
            var result = await this.jobDocumentService.DeleteDocumentsFolder(this.jobId, this.variationId);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.DeleteDocumentsFolderAsync(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task DownloadDocument_ValidDocumentKeyAndVersion_ReturnsValidResponse()
        {
            // Arrange
            string documentKey = "Jobs/78/26613/upload.txt";
            string documentVersion = "jI9eTNWgMHDdfqjYF4luqFld_qC7UfzY";
            GetObjectResponse response = new GetObjectResponse() { ResponseStream = new MemoryStream() };
            TSMTSettings tsmtAppSettings = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };
            this.appSettings.Setup(ap => ap.Value).Returns(tsmtAppSettings);
            this.s3Repository.Setup(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(response));

            // Act
            var result = await this.jobDocumentService.DownloadDocument(documentKey, documentVersion);

            // Assert
            Assert.IsType<MemoryStream>(result);
            this.s3Repository.Verify(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task DownloadDocument_InValidDocumentKeyOrVersion_ReturnsNullResponse()
        {
            // Arrange
            string documentKey = "invalidKey";
            string documentVersion = "jI9eTNWgMHDdfqjYF4luqFld_qC7UfzY";
            GetObjectResponse response = null;
            TSMTSettings tsmtAppSettings = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };
            this.appSettings.Setup(ap => ap.Value).Returns(tsmtAppSettings);
            this.s3Repository.Setup(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(response));

            // Act
            var result = await this.jobDocumentService.DownloadDocument(documentKey, documentVersion);

            // Assert
            Assert.Null(result);
            this.s3Repository.Verify(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task ProcessSelectionSummaryReportCompletionMessage_ValidInput_Success()
        {
            // Arrange
            string snsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob";
            var visRequest = new ChangeMessageVisibilityRequest
            {
                QueueUrl = It.IsAny<string>(),
                ReceiptHandle = "008245c2-b535-52a3-9e4b-110a1b231615",
                VisibilityTimeout = It.IsAny<int>()
            };
            dynamic body = new System.Dynamic.ExpandoObject();
            var notes = new List<DocumentNotes>()
            {
                new DocumentNotes()
                {
                    FileName = "Document.txt",
                    S3Key = "122/46546/Document.txt",
                    Status = "Complete"
                }
            };
            body.Message = new SelectionSummaryMessage()
            {
                DrAddressId = 122,
                JobId = 67545,
                Status = "Complete",
                UserId = "ccfbok",
                Notes = notes
            };
            Message message = new Message
            {
                MessageId = "008245c2-b535-52a3-9e4b-110a1b231615",
                Body = JsonConvert.SerializeObject(body),
                ReceiptHandle = visRequest.ReceiptHandle
            };
            this.jobDocumentRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>())).Returns(Task.FromResult(It.IsAny<int>()));
            this.jobDocumentRepository.Setup(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>())).Returns(Task.FromResult(true));
            this.messageReceiver.Setup(x => x.DeleteMessageAsync(It.IsAny<string>(), message.ReceiptHandle)).Returns(Task.FromResult(It.IsAny<string>()));

            // Act
            await this.jobDocumentService.ProcessSelectionSummaryReportCompletionMessage(message, snsServiceUrl);

            // Assert
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            this.jobDocumentRepository.Verify(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()), Times.Once);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.AtLeastOnce);
        }

        [Fact]
        public async Task ProcessSelectionSummaryReportCompletionMessage_InValidInput_Failure()
        {
            // Arrange
            string snsServiceUrl = string.Empty;
            Message message = new Message();

            // Act
            await this.jobDocumentService.ProcessSelectionSummaryReportCompletionMessage(message, snsServiceUrl);

            // Assert
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Never);
            this.jobDocumentRepository.Verify(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()), Times.Never);
        }

        /// <summary>
        /// Verifies download document without version
        /// </summary>
        /// <returns>File stream</returns>
        [Fact]
        public async Task DownloadDocumentWithoutVersion_ValidDocumentKey_ReturnsFilestream()
        {
            // Arrange
            string documentKey = "Jobs/78/26613/upload.json";
            GetObjectResponse response = new GetObjectResponse() { ResponseStream = new MemoryStream() };
            TSMTSettings tsmtSettings = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };

            this.appSettings.Setup(ap => ap.Value).Returns(tsmtSettings);
            this.s3Repository.Setup(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(response));

            // Act
            var result = await this.jobDocumentService.DownloadDocumentWithoutVersion(documentKey);

            // Assert
            Assert.IsType<MemoryStream>(result);
            this.s3Repository.Verify(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.appSettings.Verify(ap => ap.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Verifies download document returns null
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task DownloadDocumentWithoutVersion_InValidDocument_ReturnsNull()
        {
            // Arrange
            string documentKey = "InvalidKey";
            GetObjectResponse response = null;
            TSMTSettings tsmtSettings = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };

            this.appSettings.Setup(ap => ap.Value).Returns(tsmtSettings);
            this.s3Repository.Setup(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(response));

            // Act
            var result = await this.jobDocumentService.DownloadDocumentWithoutVersion(documentKey);

            // Assert
            Assert.Null(result);
            this.s3Repository.Verify(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.appSettings.Verify(ap => ap.Value, Times.AtLeastOnce);
        }

        [Fact]
        public async Task CheckAndCreateJobDocumentFolders_HasNoFolders_ReturnsParentIdAndFolderIdInDocumentFolderModel()
        {
            // Arrange
            IEnumerable<DocumentFolderModel> documentFolderModel = new List<DocumentFolderModel>();

            this.jobDocumentRepository.SetupSequence(x => x.GetSequenceNumber(It.IsAny<string>())).Returns(Task.FromResult(1)).Returns(Task.FromResult(2));
            this.jobDocumentRepository.Setup(x => x.GetFolderDetails(It.IsAny<int>(), It.IsAny<JobFolderTypes>(), It.IsAny<List<string>>(), It.IsAny<int>())).Returns(Task.FromResult(documentFolderModel));
            this.jobDocumentRepository.SetupSequence(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>())).Returns(Task.FromResult(1)).Returns(Task.FromResult(2));

            // Act
            DocumentFolderModel result = await this.jobDocumentService.CheckAndCreateJobDocumentFolders(Helper.GetDocumentFolderViewModel(), Helper.GetDocumentViewModel());

            // Assert
            Assert.Equal(1, result.FOLDER_PARENT_ID);
            Assert.Equal(2, result.FOLDER_ID);
            Assert.Equal(1234, result.JOB_ID);
            Assert.Equal("Test", result.CREATED_BY_USER);
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber("JOB_DOCUMENT_FOLDER"), Times.Exactly(2));
            this.jobDocumentRepository.Verify(x => x.GetFolderDetails(1234, JobFolderTypes.NonTrane, this.folderNames, 1), Times.Once);
            this.jobDocumentRepository.Verify(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()), Times.Exactly(2));
        }

        [Fact]
        public async Task CheckAndCreateJobDocumentFolders_HasParentFolderAndNoSubFolder_ReturnsParentIdAndFolderIdInDocumentFolderModel()
        {
            // Arrange
            IEnumerable<DocumentFolderModel> documentFolderModel = new List<DocumentFolderModel>() { new DocumentFolderModel() { FOLDER_ID = 1, FOLDER_NAME = "NonTrane" } };

            this.jobDocumentRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>())).Returns(Task.FromResult(3));
            this.jobDocumentRepository.Setup(x => x.GetFolderDetails(It.IsAny<int>(), It.IsAny<JobFolderTypes>(), It.IsAny<List<string>>(), It.IsAny<int>())).Returns(Task.FromResult(documentFolderModel));
            this.jobDocumentRepository.Setup(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>())).Returns(Task.FromResult(3));

            // Act
            DocumentFolderModel result = await this.jobDocumentService.CheckAndCreateJobDocumentFolders(Helper.GetDocumentFolderViewModel(), Helper.GetDocumentViewModel());

            // Assert
            Assert.Equal(1, result.FOLDER_PARENT_ID);
            Assert.Equal(3, result.FOLDER_ID);
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber("JOB_DOCUMENT_FOLDER"), Times.Once);
            this.jobDocumentRepository.Verify(x => x.GetFolderDetails(1234, JobFolderTypes.NonTrane, this.folderNames, 1), Times.Once);
            this.jobDocumentRepository.Verify(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()), Times.Once);
        }

        [Fact]
        public async Task CheckAndCreateJobDocumentFolders_HasParentAndSubFolders_ReturnsParentIdAndFolderIdInDocumentFolderModel()
        {
            // Arrange
            IEnumerable<DocumentFolderModel> documentFolderModel = new List<DocumentFolderModel>()
            {
                new DocumentFolderModel() { FOLDER_ID = 1, FOLDER_NAME = "NonTrane" },
                new DocumentFolderModel() { FOLDER_ID = 2, FOLDER_NAME = "45678", FOLDER_PARENT_ID = 1 }
            };

            this.jobDocumentRepository.Setup(x => x.GetFolderDetails(It.IsAny<int>(), It.IsAny<JobFolderTypes>(), It.IsAny<List<string>>(), It.IsAny<int>())).Returns(Task.FromResult(documentFolderModel));

            // Act
            DocumentFolderModel result = await this.jobDocumentService.CheckAndCreateJobDocumentFolders(Helper.GetDocumentFolderViewModel(), Helper.GetDocumentViewModel());

            // Assert
            Assert.Equal(1, result.FOLDER_PARENT_ID);
            Assert.Equal(2, result.FOLDER_ID);
            this.jobDocumentRepository.Verify(x => x.GetFolderDetails(1234, JobFolderTypes.NonTrane, this.folderNames, 1), Times.Once);
        }

        [Fact]
        public async Task UploadJobDocument_HasDocumentFolderDetails_ReturnsTrue()
        {
            // Arrange
            string s3Key = "Jobs/78/178456/1/2/Test";
            JobDocumentView jobDocumentView = new JobDocumentView
            {
                JobId = 178456,
                DocumentName = "Test",
                UploadedBy = "Test",
                DrAddressId = 78,
            };
            Stream documentStream = new MemoryStream();
            PutObjectResponse putResponse = new PutObjectResponse();
            putResponse.VersionId = "1";
            DefaultHttpContext httpContext = new DefaultHttpContext();
            httpContext.Items.Add("DR_ADDRESS_ID", 78);
            TSMTSettings appSetting = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt"
            };

            IEnumerable<DocumentFolderModel> documentFolderModel = new List<DocumentFolderModel>()
            {
                new DocumentFolderModel() { FOLDER_ID = 1, FOLDER_NAME = "NonTrane" },
                new DocumentFolderModel() { FOLDER_ID = 2, FOLDER_NAME = "45678", FOLDER_PARENT_ID = 1 }
            };

            this.jobDocumentRepository.Setup(x => x.GetFolderDetails(It.IsAny<int>(), It.IsAny<JobFolderTypes>(), It.IsAny<List<string>>(), It.IsAny<int>())).Returns(Task.FromResult(documentFolderModel));
            this.appSettings.Setup(ap => ap.Value).Returns(appSetting);

            this.jobDocumentRepository.Setup(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            this.jobDocumentRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>()))
               .Returns(Task.FromResult(1));
            this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);
            this.s3Repository.Setup(x => x.PutObjectAsync(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<MemoryStream>(), null)).Returns(Task.FromResult(putResponse));

            // Act
            bool result = await this.jobDocumentService.UploadJobDocument(jobDocumentView, documentStream, Helper.GetDocumentFolderViewModel());

            // Assert
            Assert.True(result);
            this.s3Repository.Verify(x => x.PutObjectAsync("tsmt", s3Key, null, It.IsAny<MemoryStream>(), null), Times.Once);
            this.jobDocumentRepository.Verify(x => x.InsertJobDocument(It.IsAny<JobDocument>(), 1), Times.Once);
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber("JOB_DOCUMENT"), Times.Once);
            this.jobDocumentRepository.Verify(x => x.GetFolderDetails(178456, JobFolderTypes.NonTrane, this.folderNames, 1), Times.Once);
            documentStream.Dispose();
        }

        /// <summary>
        /// Validate insert document with document key and document version which is already uploaded file in document package service
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task InsertJobDocument_ValidInputWithDocumentKeyAndDocumentVersion_ReturnsTrue()
        {
            // Arrange
            JobDocumentView jobDocumentView = new JobDocumentView
            {
                JobId = 178456,
                DrAddressId = 94,
                DocumentName = "Test",
                DocumentKey = "generated-files/324/45/12",
                DocumentVersion = "versionJiggy"
            };
            var httpContext = new DefaultHttpContext();
            httpContext.Items.Add("DR_ADDRESS_ID", 78);

            this.jobDocumentRepository.Setup(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            this.jobDocumentRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>()))
               .Returns(Task.FromResult(It.IsAny<int>()));
            this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

            // Act
            var result = await this.jobDocumentService.UploadDocumentFromDocumentPackageFileUploaded(jobDocumentView);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()), Times.Once);
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext, Times.Once);
        }

        /// <summary>
        /// Validate insert document with document key and document version which is already uploaded file in document package service but insert fails in job document table
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task InsertJobDocument_ValidInputWithDocumentKeyAndDocumentVersion_ReturnsFalse()
        {
            // Arrange
            JobDocumentView jobDocumentView = new JobDocumentView
            {
                JobId = 178456,
                DrAddressId = 94,
                DocumentName = "Test",
                DocumentKey = "generated-files/324/45/12",
                DocumentVersion = "versionJiggy"
            };
            var httpContext = new DefaultHttpContext();
            httpContext.Items.Add("DR_ADDRESS_ID", 78);

            this.jobDocumentRepository.Setup(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));
            this.jobDocumentRepository.Setup(x => x.GetSequenceNumber(It.IsAny<string>()))
                .Returns(Task.FromResult(It.IsAny<int>()));
            this.contextAccessor.Setup(x => x.HttpContext).Returns(httpContext);

            // Act
            var result = await this.jobDocumentService.UploadDocumentFromDocumentPackageFileUploaded(jobDocumentView);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.InsertJobDocument(It.IsAny<JobDocument>(), It.IsAny<int>()), Times.Once);
            this.jobDocumentRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext, Times.Once);
        }

        /// <summary>
        /// Validate download document with document key and document version from guidespec bucket
        /// </summary>
        /// <returns>File stream</returns>
        [Fact]
        public async Task DownloadDocument_ValidDocumentKeyAndVersionOfGuideSpecBucket_ReturnsValidResponse()
        {
            // Arrange
            string documentKey = "generated-files/324/45/12";
            string documentVersion = "versionI9eTNWgMHDdfqjYF4luqFld_qC7UfzY";
            GetObjectResponse response = new GetObjectResponse() { ResponseStream = new MemoryStream() };
            TSMTSettings tsmtAppSettings = new TSMTSettings()
            {
                MaxNoOfMessages = 1,
                QueueWaitTimeInSeconds = 2,
                MessageHidingTimeInMinutes = 3,
                Bucket = "tsmt",
                JobsBucket = "tsmt-guidespec"
            };
            this.appSettings.Setup(ap => ap.Value).Returns(tsmtAppSettings);
            this.s3Repository.Setup(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(response));

            // Act
            var result = await this.jobDocumentService.DownloadDocument(documentKey, documentVersion);

            // Assert
            Assert.IsType<MemoryStream>(result);
            this.s3Repository.Verify(x => x.GetObjectAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.appSettings.Verify(ap => ap.Value, Times.Once);
        }
    }
}
