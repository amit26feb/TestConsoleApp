// <copyright file="FavoriteServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using global::JobService.Core.Models;
    using global::JobService.Repository;
    using Microsoft.AspNetCore.Http;
    using MongoDB.Bson;
    using Moq;
    using Xunit;

    public class FavoriteServiceTest
    {
        private readonly Mock<IFavoriteRepository> favoriteRepository;
        private readonly FavoriteService favoriteService;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly string userId = "TestUser";
        private readonly DefaultHttpContext httpContext = new DefaultHttpContext();

        public FavoriteServiceTest()
        {
            this.favoriteRepository = new Mock<IFavoriteRepository>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            this.httpContext.Items.Add("DR_ADDRESS_ID", 78);
            List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", this.userId)
            };
            ClaimsIdentity appIdentity = new ClaimsIdentity(claims);
            this.httpContext.User.AddIdentity(appIdentity);
            this.favoriteService = new FavoriteService(this.favoriteRepository.Object, this.contextAccessor.Object);
        }

        /// <summary>
        /// Test to update favorite job when there is favorite job count
        /// </summary>
        /// <returns>Empty string</returns>
        [Fact]
        public async Task UpdateFavorite_HasFavoriteJobCount_DeleteSuccessfulAndReturnsEmptyString()
        {
            // Arrange
            int jobId = 1234;
            long favoriteJobCount = 1;
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.favoriteRepository.Setup(x => x.DeleteFavorite(It.IsAny<FavoriteJob>())).Returns(Task.FromResult(true));
            this.favoriteRepository.Setup(x => x.GetFavoriteJobCount(It.IsAny<FavoriteJob>())).Returns(favoriteJobCount);

            // Act
            string result = await this.favoriteService.UpdateFavorite(jobId);

            // Assert
            Assert.Empty(result);
            this.favoriteRepository.Verify(
                x => x.DeleteFavorite(It.Is<FavoriteJob>(x => x.JobId == jobId
                && x.UserId == this.contextAccessor.Object.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "samAccountName").Value.ToLower())), Times.Once);
            this.favoriteRepository.Verify(
                x => x.GetFavoriteJobCount(It.Is<FavoriteJob>(x => x.JobId == jobId
                && x.UserId == this.contextAccessor.Object.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "samAccountName").Value.ToLower())), Times.Once);
        }

        /// <summary>
        /// Test to update favorite job
        /// </summary>
        /// <returns>Error message</returns>
        [Fact]
        public async Task UpdateFavorite_DeleteUnsuccessful_ReturnsErrorMessage()
        {
            // Arrange
            int jobId = 1234;
            long favoriteJobCount = 1;
            string errorMessage = "Unexpected error occurred while deleting favorite job";
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.favoriteRepository.Setup(x => x.DeleteFavorite(It.IsAny<FavoriteJob>())).Returns(Task.FromResult(false));
            this.favoriteRepository.Setup(x => x.GetFavoriteJobCount(It.IsAny<FavoriteJob>())).Returns(favoriteJobCount);

            // Act
            string result = await this.favoriteService.UpdateFavorite(jobId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(result, errorMessage);
            this.favoriteRepository.Verify(
                x => x.DeleteFavorite(It.Is<FavoriteJob>(x => x.JobId == jobId
                && x.UserId == this.contextAccessor.Object.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "samAccountName").Value.ToLower())), Times.Once);
        }

        /// <summary>
        /// Test to update favorite job when there is no favorite job count
        /// </summary>
        /// <returns>Empty string</returns>
        [Fact]
        public async Task UpdateFavorite_HasNoFavoriteJobCount_CreateFavoriteJobSuccessfulAndReturnsEmptyString()
        {
            // Arrange
            int jobId = 1234;
            long favoriteJobCount = 0;
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.favoriteRepository.Setup(x => x.CreateFavoriteJob(It.IsAny<FavoriteJob>())).Returns(Task.FromResult(Task.CompletedTask));
            this.favoriteRepository.Setup(x => x.GetFavoriteJobCount(It.IsAny<FavoriteJob>())).Returns(favoriteJobCount);

            // Act
            string result = await this.favoriteService.UpdateFavorite(jobId);

            // Assert
            Assert.Empty(result);
            this.favoriteRepository.Verify(
                x => x.CreateFavoriteJob(It.Is<FavoriteJob>(x => x.JobId == jobId
                && x.UserId == this.contextAccessor.Object.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "samAccountName").Value.ToLower())), Times.Once);
            this.favoriteRepository.Verify(
                x => x.GetFavoriteJobCount(It.Is<FavoriteJob>(x => x.JobId == jobId
                && x.UserId == this.contextAccessor.Object.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "samAccountName").Value.ToLower())), Times.Once);
        }

        /// <summary>
        /// Test to get favorite count
        /// </summary>
        [Fact]
        public void GetFavoriteCount_RetrievedSuccessfully_ReturnsFavoriteCount()
        {
            // Arrange
            long count = 7;
            this.contextAccessor.Setup(x => x.HttpContext).Returns(this.httpContext);
            this.favoriteRepository.Setup(x => x.GetFavoriteCount(It.IsAny<string>(), It.IsAny<int>())).Returns(count);

            // Act
            long result = this.favoriteService.GetFavoriteCount();

            // Assert
            Assert.Equal(count, result);
            this.favoriteRepository.Verify(
                x => x.GetFavoriteCount(
                It.Is<string>(x => x == this.contextAccessor.Object.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "samAccountName").Value.ToLower()),
                It.Is<int>(x => x == (int)this.contextAccessor.Object.HttpContext.Items["DR_ADDRESS_ID"])), Times.Once);
        }

        [Fact]
        public async Task GetFollowingUsers_ForGivenJobId_ReturnsUserIds()
        {
            // Arrange
            int jobId = 26987;
            int drAddressId = 147;
            IEnumerable<string> expectedResult = new List<string> { "user1", "user2" };
            IEnumerable<BsonDocument> userIds = new List<BsonDocument>()
            {
                new BsonDocument()
                {
                    { "UserId", "user1" },
                },
                new BsonDocument()
                {
                    { "UserId", "user2" },
                },
                new BsonDocument()
                {
                    { "UserId", "user1" },
                }
            };
            this.favoriteRepository.Setup(x => x.GetFollowingUsers(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(userIds));

            // Act
            IEnumerable<string> result = await this.favoriteService.GetFollowingUsers(drAddressId, jobId);

            // Assert
            Assert.Equal(expectedResult, result);
            this.favoriteRepository.Verify(
               x => x.GetFollowingUsers(drAddressId, jobId), Times.Once);
        }
    }
}
