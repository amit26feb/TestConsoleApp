// <copyright file="MTopssJobServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading.Tasks;
    using Amazon.S3.Model;
    using Amazon.SQS;
    using AWS.MessagingWrapper.Contracts;
    using DynamoDBWrapper;
    using global::JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using S3Wrapper;
    using TSMT.DataAccess;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// MTopssJobServiceTest Test Methods
    /// </summary>
    public class MTopssJobServiceTest
    {
        private readonly Mock<IRepository<global::JobService.Core.Models.JobDetails>> repository;
        private readonly Mock<ILogger<DynamoDBRepository>> logger;
        private readonly Mock<IMTopssJobDynamoDbRepository> mTopssDynamoRepository;
        private readonly Mock<IJobsSnsNotifier> mTopssJobsNotifier;
        private readonly Mock<IMessagePublisher> snsPublisher;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly Mock<IOptions<TSMTSettings>> mock;
        private readonly Mock<IAmazonSQS> amazonSQSClient;
        private readonly Mock<IMessageReceiver> messageReceiver;
        private readonly Mock<IS3Repository> s3Repository;
        private readonly Mock<IServiceProvider> serviceProvider;
        private readonly Mock<IJobRepository> jobRepository;
        private readonly IMTopssJobService mTopssJobService;

        public MTopssJobServiceTest()
        {
            this.repository = new Mock<IRepository<JobDetails>>();
            this.mTopssDynamoRepository = new Mock<IMTopssJobDynamoDbRepository>();
            this.snsPublisher = new Mock<IMessagePublisher>();
            this.mTopssJobsNotifier = new Mock<IJobsSnsNotifier>();
            this.logger = new Mock<ILogger<DynamoDBRepository>>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            this.mock = new Mock<IOptions<TSMTSettings>>();
            this.amazonSQSClient = new Mock<IAmazonSQS>();
            this.messageReceiver = new Mock<IMessageReceiver>();
            this.s3Repository = new Mock<IS3Repository>();
            this.serviceProvider = new Mock<IServiceProvider>();
            this.jobRepository = new Mock<IJobRepository>();

            this.mTopssJobService = new MTopssJobService(
                this.mTopssDynamoRepository.Object,
                this.mTopssJobsNotifier.Object,
                this.logger.Object,
                this.contextAccessor.Object,
                this.mock.Object,
                this.amazonSQSClient.Object,
                this.s3Repository.Object,
                this.serviceProvider.Object,
                this.jobRepository.Object);
        }

        [Fact]
        public async Task SaveJob_ValidRequest_ReturnRequestId()
        {
            // Arrange
            var messageId = "67890-2b9d-5488-9d28-45a5d2f59876";
            var jsonPatchMessage = "[{ \"op\": \"remove\", \"path\": \"/ProdSelUnits/5467845/ProdSelModules/768761\"}]";

            MTopssMessage dynamoValues = new MTopssMessage()
            {
                MessageId = "67890-2b9d-5488-9d28-45a5d2f59876",
                JobId = 4004,
                DrAddressId = 34,
                UserId = "ccgyfb",
                CreatedDateTime = DateTime.UtcNow.ToString(),
                StatusUpdatedDateTime = DateTime.UtcNow.ToString(),
                Status = MTopssMessages.Pending.ToString(),
                Signature = "fgtgrthhjjtyujfg56456fgdfgdfgdfg"
            };

            TSMTSettings app = new TSMTSettings() { SecretKeyJob = "67dsf-2b9d-5488-9d28-45a5d2f59876", SnsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsSaveToLynx" };
            this.mock.Setup(ap => ap.Value).Returns(app);

            var context = new DefaultHttpContext
            {
                TraceIdentifier = "67890-2b9d-5488-9d28-45a5d2f59876"
            };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(context);

            this.mTopssDynamoRepository.Setup(x => x.SaveJob(It.IsAny<MTopssMessage>()))
               .Returns(Task.FromResult(true));
            this.mTopssJobsNotifier.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
              .Returns(Task.FromResult(messageId));

            // Act
            var result = await this.mTopssJobService.SaveJobAsync(jsonPatchMessage, dynamoValues.JobId, dynamoValues.DrAddressId);

            // Assert
            Assert.Equal(messageId, result);
            this.mTopssDynamoRepository.Verify(x => x.SaveJob(It.IsAny<global::JobService.Core.Models.MTopssMessage>()), Times.Once);
            this.mTopssJobsNotifier.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task SaveJob_InValidRequest_ReturnEmptyRequestId()
        {
            // Arrange
            var messageId = string.Empty;
            var jsonPatchMessage = string.Empty;

            TSMTSettings app = new TSMTSettings() { SecretKeyJob = "67dsf-2b9d-5488-9d28-45a5d2f59876", SnsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsSaveToLynx" };
            this.mock.Setup(ap => ap.Value).Returns(app);

            var context = new DefaultHttpContext
            {
                TraceIdentifier = string.Empty
            };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(context);

            this.mTopssDynamoRepository.Setup(x => x.SaveJob(It.IsAny<MTopssMessage>()))
               .Returns(Task.FromResult(true));
            this.mTopssJobsNotifier.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
              .Returns(Task.FromResult(messageId));

            // Act
            var result = await this.mTopssJobService.SaveJobAsync(jsonPatchMessage, 0, 0);

            // Assert
            Assert.Equal(messageId, result);
            this.mTopssDynamoRepository.Verify(x => x.SaveJob(It.IsAny<MTopssMessage>()), Times.Once);
            this.mTopssJobsNotifier.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSaveStatus_ValidSaveRequestId_ReturnsJobSaveStatus()
        {
            // Arrange
            MTopssMessage dynamoValues = new MTopssMessage()
            {
                MessageId = "67890-2b9d-5488-9d28-45a5d2f59876",
                JobId = 4004,
                DrAddressId = 34,
                UserId = "iibxa",
                CreatedDateTime = DateTime.UtcNow.ToString(),
                StatusUpdatedDateTime = DateTime.UtcNow.ToString(),
                Status = MTopssMessages.Pending.ToString(),
                Signature = "fgtgrthhjjtyujfg56456fgdfgdfgdfg",
                ErrorMessage = string.Empty,
            };

            this.mTopssDynamoRepository.Setup(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()))
               .Returns(Task.FromResult(dynamoValues));

            // Act
            var result = await this.mTopssJobService.GetJobSaveStatusAsync(dynamoValues.MessageId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(dynamoValues.Status, result.Status);
            Assert.Equal(dynamoValues.StatusUpdatedDateTime, result.StatusUpdatedDateTime);
            Assert.Equal(dynamoValues.ErrorMessage, result.ErrorMessage);
            this.mTopssDynamoRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSaveStatus_InvalidSaveRequestId_ReturnsNullSaveStatus()
        {
            // Arrange
            MTopssMessage dynamoValues = null;
            this.mTopssDynamoRepository.Setup(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()))
               .Returns(Task.FromResult(dynamoValues));

            // Act
            var result = await this.mTopssJobService.GetJobSaveStatusAsync("JUNK ID");

            // Assert
            Assert.Null(result);
            this.mTopssDynamoRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Once);
        }

        [Fact]
        public async Task SaveTransmitJobRequest_ValidTransmitJobRequestAndValidFileStream_ReturnsMessageId()
        {
            // Arrange
            TransmitJobViewModel transmitJobViewModel = new TransmitJobViewModel()
            {
                Action = "Copy",
                SourceDrAddressId = 122,
                SourceJobId = 5489,
                DestinationDrAddressId = 122,
            };
            Stream fileStream = new MemoryStream();
            PutObjectResponse putResponse = new PutObjectResponse()
            {
                VersionId = "1"
            };
            TSMTSettings app = new TSMTSettings() { SecretKeyJob = "67dsf-2b9d-5488-9d28-45a5d2f59876", SnsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsSaveToLynx" };
            this.mock.Setup(ap => ap.Value).Returns(app);
            var context = new DefaultHttpContext
            {
                TraceIdentifier = "67890-2b9d-5488-9d28-45a5d2f59876"
            };
            this.contextAccessor.Setup(x => x.HttpContext).Returns(context);
            DateTime dateTime = DateTime.Parse("12/05/2019");
            this.jobRepository.Setup(x => x.GetDbDate()).Returns(Task.FromResult(dateTime));
            this.jobRepository.Setup(x => x.HonorDrAddressId(122));
            this.mTopssDynamoRepository.Setup(x => x.SaveJob(It.IsAny<MTopssMessage>())).Returns(Task.FromResult(true));
            this.mTopssJobsNotifier.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(It.IsAny<string>()));
            this.s3Repository.Setup(x => x.PutObjectAsync(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<MemoryStream>(), null)).Returns(Task.FromResult(putResponse));

            // Act
            var result = await this.mTopssJobService.SaveTransmitJobRequestAsync(transmitJobViewModel, fileStream);

            // Assert
            Assert.NotNull(result);
            this.jobRepository.Verify(x => x.HonorDrAddressId(122), Times.Once);
            this.mTopssDynamoRepository.Verify(x => x.SaveJob(It.IsAny<MTopssMessage>()), Times.Once);
            this.mTopssJobsNotifier.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.s3Repository.Verify(x => x.PutObjectAsync(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<MemoryStream>(), null), Times.Once);
            fileStream.Dispose();
        }
    }
}
