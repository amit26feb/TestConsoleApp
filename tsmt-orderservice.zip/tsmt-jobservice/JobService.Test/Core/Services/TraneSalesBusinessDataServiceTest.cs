// <copyright file="TraneSalesBusinessDataServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace JobService.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoFixture;
    using AutoMapper;
    using JobService.Common.Filters;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.AspNetCore.Http;
    using MongoDB.Bson;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    /// <summary>
    /// Trane Sales Business Data Service Test
    /// </summary>
    public class TraneSalesBusinessDataServiceTest
    {
        private readonly Mock<IRepository<global::JobService.Core.Models.JobDetails>> repository;
        private readonly Mock<IJobRepository> jobRepository;
        private readonly Mock<ICompetitorRepository> competitorRepository;
        private readonly Mock<ITraneSalesBusinessDataRepository> traneSalesBusinessDataRepository;
        private readonly Mock<IRevenueStreamRepository> revenueStreamRepository;
        private readonly Mock<IJobProgramRepository> jobProgramRepository;
        private readonly Mock<ICrmJobMasterRepository> crmJobMasterRepository;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly IMapper mapper;
        private readonly TraneSalesBusinessDataService traneSalesBusinessDataService;

        public TraneSalesBusinessDataServiceTest()
        {
            this.repository = new Mock<IRepository<JobDetails>>();
            this.jobRepository = new Mock<IJobRepository>();
            this.competitorRepository = new Mock<ICompetitorRepository>();
            this.traneSalesBusinessDataRepository = new Mock<ITraneSalesBusinessDataRepository>();
            this.revenueStreamRepository = new Mock<IRevenueStreamRepository>();
            this.jobProgramRepository = new Mock<IJobProgramRepository>();
            this.crmJobMasterRepository = new Mock<ICrmJobMasterRepository>();
            this.crmJobMasterRepository.SetupGet(x => x.RevenueStreamRepository).Returns(this.revenueStreamRepository.Object);
            this.crmJobMasterRepository.SetupGet(x => x.JobProgramRepository).Returns(this.jobProgramRepository.Object);
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            int drAddressId = 101;
            var drAddressIdFromHttpContext = new Dictionary<object, object>();
            drAddressIdFromHttpContext.Add("DR_ADDRESS_ID", drAddressId);
            this.contextAccessor.Setup(x => x.HttpContext.Items).Returns(drAddressIdFromHttpContext);
            this.traneSalesBusinessDataService = new TraneSalesBusinessDataService(
                                                                                   this.repository.Object,
                                                                                   this.mapper,
                                                                                   this.jobRepository.Object,
                                                                                   this.competitorRepository.Object,
                                                                                   this.traneSalesBusinessDataRepository.Object,
                                                                                   this.contextAccessor.Object,
                                                                                   this.crmJobMasterRepository.Object);
        }

        [Fact]
        public async Task GetCompetitorList_ReturnsValidData()
        {
            IEnumerable<Competitor> list = new List<Competitor>()
            {
                    new Competitor()
                    {
                       CompetitorId = "3",
                       CompetitorName = "McQuay/AAF/Blazer",
                       CompetitorStatus = "C",
                       CrmCompanyId = "178900"
                    },
                    new Competitor()
                    {
                       CompetitorId = "117",
                       CompetitorName = "Baltimore Air Coil",
                       CompetitorStatus = "C",
                       CrmCompanyId = "156071"
                    }
            };

            this.competitorRepository.Setup(x => x.GetCompetitorListAsync<Competitor>()).Returns(Task.FromResult(list)).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetCompetitorList();

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 2);
            Assert.True(result.Select(a => a.CompetitorId == "3").Any());
            Assert.True(result.Select(a => a.CompetitorName == "McQuay/AAF/Blazer").Any());
            Assert.True(result.Select(a => a.CrmCompanyId == "156071").Any());
            this.competitorRepository.Verify(x => x.GetCompetitorListAsync<Competitor>(), Times.Once);
        }

        [Fact]
        public async Task GetCompetitorList_ReturnsEmptyList()
        {
            IEnumerable<Competitor> list = new List<Competitor>();
            this.competitorRepository.Setup(x => x.GetCompetitorListAsync<Competitor>()).Returns(Task.FromResult(list)).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetCompetitorList();

            // Assert
            Assert.Empty(result);
            this.competitorRepository.Verify(x => x.GetCompetitorListAsync<Competitor>(), Times.Once);
        }

        [Fact]
        public async Task GetSalesOfficeList_ReturnsValidData()
        {
            // Arrange
            IEnumerable<SalesOffice> salesOfficeList = new List<SalesOffice>()
            {
                new SalesOffice()
                {
                    Sales_office_id = 2075,
                    Sales_office_name = "Portland ME",
                    Sales_office_id_parent = 1,
                    Sales_district = "34",
                    Country = "USA"
                }
            };

            this.repository.Setup(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>(It.IsAny<string>()))
                    .Returns(Task.FromResult(salesOfficeList)).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeList();

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.SalesOfficeId == 2075).Any());
            Assert.True(result.Select(a => a.SalesOfficeName == "Portland ME").Any());
            this.repository.Verify(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetSalesOfficeList_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<SalesOffice> salesOfficeList = new List<SalesOffice>();

            this.repository.Setup(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>(It.IsAny<string>()))
                    .Returns(Task.FromResult(salesOfficeList)).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeList();

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetSalesOffice_NoSalesOffice_ReturnsNull()
        {
            // Arrange
            var officeId = 1;
            this.repository.Setup(x => x.GetAsync<SalesOffice>(officeId))
                    .Returns(Task.FromResult<SalesOffice>(null));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOffice(officeId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetAsync<SalesOffice>(1), Times.Once);
        }

        [Fact]
        public async Task GetSalesOffice_HasSalesOffice_US_ReturnsSalesOfficeDetailView()
        {
            // Arrange
            var officeId = 1;
            var salesOffice = new SalesOffice()
            {
                Sales_office_id = 123,
                Sales_office_code = "BC",
                Sales_office_name = "Some Office",
                Sales_office_id_parent = 345,
                STREET_ADDRESS_1 = "123 Address Way",
                STREET_ADDRESS_2 = "Box 24",
                CITY = "New York",
                Sales_district = "The west side",
                Country = "USA",
                FAX_NBR = "555-555-5555",
                PHONE_NBR = "666-666-6666",
                PROVINCE = "Derp",
                STATE_CODE = "NY",
                ZIP_CODE = "54545",
                ZIP_PLUS = "9999",
                NON_US_POSTAL_CODE = "N2B 3S4"
            };

            this.repository.Setup(x => x.GetAsync<SalesOffice>(officeId))
                    .Returns(Task.FromResult(salesOffice));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOffice(officeId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(salesOffice.Sales_office_id, result.Id);
            Assert.Equal(salesOffice.Sales_office_code, result.Code);
            Assert.Equal(salesOffice.Sales_office_name, result.Name);
            Assert.Equal(salesOffice.STREET_ADDRESS_1, result.Address1);
            Assert.Equal(salesOffice.STREET_ADDRESS_2, result.Address2);
            Assert.Equal(salesOffice.CITY, result.City);
            Assert.Equal(salesOffice.STATE_CODE, result.State);
            Assert.Equal(salesOffice.ZIP_CODE, result.Zip);
            Assert.Equal(salesOffice.ZIP_PLUS, result.ZipPlus);
            Assert.Equal(salesOffice.PROVINCE, result.Province);
            Assert.Equal(salesOffice.PHONE_NBR, result.Phone);
            Assert.Equal(salesOffice.FAX_NBR, result.Fax);
            this.repository.Verify(x => x.GetAsync<SalesOffice>(1), Times.Once);
        }

        [Fact]
        public async Task GetSalesOffice_HasSalesOffice_Non_US_ReturnsSalesOfficeDetailView()
        {
            // Arrange
            var officeId = 1;
            var salesOffice = new SalesOffice()
            {
                Sales_office_id = 123,
                Sales_office_code = "XY",
                Sales_office_name = "Some Office",
                Sales_office_id_parent = 345,
                STREET_ADDRESS_1 = "123 Address Way",
                STREET_ADDRESS_2 = "Box 24",
                CITY = "New York",
                Sales_district = "The west side",
                Country = "CAN",
                FAX_NBR = "555-555-5555",
                PHONE_NBR = "666-666-6666",
                PROVINCE = "Derp",
                STATE_CODE = "NY",
                ZIP_CODE = "54545",
                ZIP_PLUS = "9999",
                NON_US_POSTAL_CODE = "N2B 3S4"
            };

            this.repository.Setup(x => x.GetAsync<SalesOffice>(officeId))
                    .Returns(Task.FromResult(salesOffice));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOffice(officeId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(salesOffice.Sales_office_id, result.Id);
            Assert.Equal(salesOffice.Sales_office_code, result.Code);
            Assert.Equal(salesOffice.Sales_office_name, result.Name);
            Assert.Equal(salesOffice.STREET_ADDRESS_1, result.Address1);
            Assert.Equal(salesOffice.STREET_ADDRESS_2, result.Address2);
            Assert.Equal(salesOffice.CITY, result.City);
            Assert.Equal(salesOffice.STATE_CODE, result.State);
            Assert.Equal(salesOffice.NON_US_POSTAL_CODE, result.Zip);
            Assert.Equal(salesOffice.ZIP_PLUS, result.ZipPlus);
            Assert.Equal(salesOffice.PROVINCE, result.Province);
            Assert.Equal(salesOffice.PHONE_NBR, result.Phone);
            Assert.Equal(salesOffice.FAX_NBR, result.Fax);
            this.repository.Verify(x => x.GetAsync<SalesOffice>(1), Times.Once);
        }

        [Fact]
        public async Task GetSalesOfficeByDrAddressId_DrAddressNotFound_ReturnsNull()
        {
            // Arrange
            var drAddressId = 1;
            this.repository.Setup(x => x.GetAsync<DrAddress>(drAddressId))
                    .Returns(Task.FromResult<DrAddress>(null));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeByDrAddressId(drAddressId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetAsync<DrAddress>(drAddressId), Times.Once);
            this.repository.Verify(x => x.GetAsync<SalesOffice>(It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task GetSalesOfficeByDrAddressId_SalesOfficeNotFound_ReturnsNull()
        {
            // Arrange
            var drAddressId = 1;
            var salesOfficeId = 99;
            this.repository.Setup(x => x.GetAsync<DrAddress>(drAddressId))
                    .Returns(Task.FromResult<DrAddress>(new DrAddress()
                    {
                        DR_ADDRESS_ID = drAddressId,
                        SALES_OFFICE_ID = salesOfficeId
                    }));
            this.repository.Setup(x => x.GetAsync<SalesOffice>(salesOfficeId))
                    .Returns(Task.FromResult<SalesOffice>(null));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeByDrAddressId(drAddressId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetAsync<DrAddress>(drAddressId), Times.Once);
            this.repository.Verify(x => x.GetAsync<SalesOffice>(salesOfficeId), Times.Once);
        }

        [Fact]
        public async Task GetSalesOfficeByDrAddressId_LookupBySalesOfficeId_ReturnsSalesOffice()
        {
            // Arrange
            var drAddressId = 1;
            var salesOfficeId = 99;
            this.repository.Setup(x => x.GetAsync<DrAddress>(drAddressId))
                    .Returns(Task.FromResult<DrAddress>(new DrAddress()
                    {
                        DR_ADDRESS_ID = drAddressId,
                        SALES_OFFICE_ID = salesOfficeId
                    }));
            this.repository.Setup(x => x.GetAsync<SalesOffice>(salesOfficeId))
                    .Returns(Task.FromResult<SalesOffice>(new SalesOffice()));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeByDrAddressId(drAddressId);

            // Assert
            Assert.NotNull(result);
            this.repository.Verify(x => x.GetAsync<DrAddress>(drAddressId), Times.Once);
            this.repository.Verify(x => x.GetAsync<SalesOffice>(salesOfficeId), Times.Once);
        }

        [Fact]
        public async Task GetSalesOfficeByDrAddressId_LookupByDrAddressId_ReturnsSalesOffice()
        {
            // Arrange
            var drAddressId = 1;
            this.repository.Setup(x => x.GetAsync<DrAddress>(drAddressId))
                    .Returns(Task.FromResult<DrAddress>(new DrAddress()
                    {
                        DR_ADDRESS_ID = drAddressId,
                        SALES_OFFICE_ID = null
                    }));
            this.repository.Setup(x => x.GetAsync<SalesOffice>(drAddressId))
                    .Returns(Task.FromResult<SalesOffice>(new SalesOffice()));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeByDrAddressId(drAddressId);

            // Assert
            Assert.NotNull(result);
            this.repository.Verify(x => x.GetAsync<DrAddress>(drAddressId), Times.Once);
            this.repository.Verify(x => x.GetAsync<SalesOffice>(drAddressId), Times.Once);
        }

        [Fact]
        public async Task GetCommCode_ValidInput_ReturnsValidData()
        {
            // Arrange
            int salesOfficeId = 94;
            IEnumerable<CommCodeView> commCodeList = new List<CommCodeView>
            {
                    new CommCodeView()
                    {
                      Name = "SO1",
                      SalesOfficeId = 94
                    },
                };
            this.jobRepository.Setup(x => x.GetCommCodeListAsync<global::JobService.Core.ViewModels.CommCodeView>(It.IsAny<int>()))
                 .Returns(Task.FromResult(commCodeList)).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetCommCodeList(salesOfficeId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.SalesOfficeId == 94).Any());
            Assert.True(result.Select(a => a.Name == "SO1").Any());
            Assert.Equal(result, commCodeList);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetCommCode_InvalidInput_ReturnsEmptyList()
        {
            // Arrange
            int salesOfficeId = 0;
            List<CommCodeView> commCodeList = new List<CommCodeView>();

            this.jobRepository.Setup(x => x.GetCommCodeListAsync<global::JobService.Core.ViewModels.CommCodeView>(It.IsAny<int>()))
                 .Returns(Task.FromResult(commCodeList.AsEnumerable())).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetCommCodeList(salesOfficeId);

            // Assert
            Assert.Empty(result);
            Assert.Equal(result, commCodeList);
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetJobContactList_ValidRequest_ReturnsValidData()
        {
            // Arrange
            int salesOfficeId = 94;
            List<JobContactView> jobContactList = new List<JobContactView>
            {
                new JobContactView()
                    {
                      UserId = "ts16h325",
                      UserName = "Dee, Patrick"
                    },
                    new JobContactView()
                    {
                      UserId = "lblqh",
                      UserName = "Lavoie, Daniel",
                    }
            };

            this.jobRepository.Setup(x => x.GetJobContactListAsync<global::JobService.Core.ViewModels.JobContactView>(It.IsAny<int>()))
                 .Returns(Task.FromResult(jobContactList.AsEnumerable())).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetJobContactList(salesOfficeId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result, jobContactList);
            Assert.True(result.Count() == 2);
            Assert.True(result.Select(a => a.UserId == "ts16h325").Any());
            Assert.True(result.Select(a => a.UserName == "Lavoie, Daniel").Any());
            this.jobRepository.Verify();
        }

        [Fact]
        public async Task GetJobContactList_InvalidInput_ReturnsEmptyList()
        {
            // Arrange
            int salesOfficeId = 0;
            List<JobContactView> jobContactList = new List<JobContactView>();

            this.jobRepository.Setup(x => x.GetJobContactListAsync<global::JobService.Core.ViewModels.JobContactView>(It.IsAny<int>()))
                 .Returns(Task.FromResult(jobContactList.AsEnumerable())).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetJobContactList(salesOfficeId);

            // Assert
            Assert.Empty(result);
            this.jobRepository.Verify();
        }

        /// <summary>
        /// Test to get sales offices using a valid filter
        /// </summary>
        /// <returns>List of sales office view models</returns>
        [Fact]
        public async Task GetSalesOfficeList_ValidFilter_ReturnsSalesOffices()
        {
            // Arrange
            var salesOfficeFilter = new SalesOfficeFilter() { DrAddressId = 101, ExcludeParts = true, FilterCriteria = "district" };
            var fixture = new Fixture();
            var salesOffices = fixture.CreateMany<SalesOffice>(3);
            var salesOfficeCount = salesOffices.Count();
            this.traneSalesBusinessDataRepository.Setup(x => x.GetSalesOfficeByDistrict(salesOfficeFilter))
                .Returns(Task.FromResult(salesOffices));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeList(salesOfficeFilter);

            // Assert
            Assert.Equal(salesOffices.FirstOrDefault().Country, result.FirstOrDefault().Country);
            Assert.Equal(salesOfficeCount, result.Count());
            this.traneSalesBusinessDataRepository.Verify(x => x.GetSalesOfficeByDistrict(salesOfficeFilter), Times.Once);
        }

        /// <summary>
        /// Test to get all sales offices using a valid filter
        /// </summary>
        /// <returns>List of all sales offices</returns>
        [Fact]
        public async Task GetAllSalesOfficeList_ValidFilter_ReturnsAllSalesOffices()
        {
            // Arrange
            var salesOfficeFilter = new SalesOfficeFilter() { DrAddressId = 101, ExcludeParts = false, FilterCriteria = "AllSalesOffices" };
            IEnumerable<SalesOffice> salesOffices = new List<SalesOffice>()
            {
                new SalesOffice()
                {
                    Sales_office_id = 2075,
                    Sales_office_name = "Portland ME",
                    Sales_office_id_parent = 1,
                    Sales_district = "34",
                    Country = "USA"
                },
                new SalesOffice()
                {
                    Sales_office_id = 59,
                    Sales_office_name = "Shreveport TCS Ind SO LA",
                    Sales_office_id_parent = 57,
                    Sales_district = "57",
                    Country = "USA"
                }
            };
            this.repository.Setup(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>(It.IsAny<string>()))
                    .Returns(Task.FromResult(salesOffices));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeList(salesOfficeFilter);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Select(a => a.SalesOfficeName == "Shreveport TCS Ind SO LA").Any());
            this.repository.Verify(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>(" order by 2,1"), Times.Once);
        }

        /// <summary>
        /// GetCommCodes is called for a given drAddressId and filter search criteria
        /// </summary>
        /// <returns>IEnumerable of comm code view models</returns>
        [Fact]
        public async Task GetCommCodes_ValidRequest_ReturnsCommCodes()
        {
            // Arrange
            var fixture = new Fixture();
            var commCodes = fixture.CreateMany<CommCodeModel>();
            this.traneSalesBusinessDataRepository.Setup(x => x.GetCommCodesByDistrict(It.IsAny<CommCodeFilter>()))
                .Returns(Task.FromResult(commCodes));
            var commCodeFilter = new CommCodeFilter
            {
                DraddressId = 63
            };

            // Act
            IEnumerable<CommCodeView> commCodeViewModel = await this.traneSalesBusinessDataService.GetCommCodes(commCodeFilter);

            // Assert
            Assert.NotEmpty(commCodeViewModel);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetCommCodesByDistrict(It.IsAny<CommCodeFilter>()), Times.Once);
        }

        /// <summary>
        /// GetCommCodes is called for a given drAddressId and filter search criteria do not exist
        /// </summary>
        /// <returns>Empty IEnumerable</returns>
        [Fact]
        public async Task GetCommCodes_InvalidInput_ReturnsEmptyCollection()
        {
            // Arrange
            this.traneSalesBusinessDataRepository.Setup(x => x.GetCommCodesByDistrict(It.IsAny<CommCodeFilter>()))
                .Returns(Task.FromResult(Enumerable.Empty<CommCodeModel>()));
            var commCodeFilter = new CommCodeFilter
            {
                DraddressId = 9890
            };

            // Act
            IEnumerable<CommCodeView> commCodeViewModel = await this.traneSalesBusinessDataService.GetCommCodes(commCodeFilter);

            // Assert
            Assert.Empty(commCodeViewModel);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetCommCodesByDistrict(It.IsAny<CommCodeFilter>()), Times.Once);
        }

        [Fact]
        public async Task GetAllCommCodes_CommCodesExists_ReturnsCommCodes()
        {
            // Arrange
            var fixture = new Fixture();
            var commCodes = fixture.CreateMany<CommCodeModel>();
            this.traneSalesBusinessDataRepository.Setup(x => x.GetAllCommCodes())
                .Returns(Task.FromResult(commCodes));

            // Act
            IEnumerable<CommCodeView> commCodeViewModel = await this.traneSalesBusinessDataService.GetAllCommCodes();

            // Assert
            Assert.NotEmpty(commCodeViewModel);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetAllCommCodes(), Times.Once);
        }

        [Fact]
        public async Task GetAllCommCodes_NoCommCodesAvailable_ReturnsEmptyList()
        {
            // Arrange
            this.traneSalesBusinessDataRepository.Setup(x => x.GetAllCommCodes())
                .Returns(Task.FromResult(Enumerable.Empty<CommCodeModel>()));

            // Act
            IEnumerable<CommCodeView> commCodeViewModel = await this.traneSalesBusinessDataService.GetAllCommCodes();

            // Assert
            Assert.Empty(commCodeViewModel);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetAllCommCodes(), Times.Once);
        }

        /// <summary>
        /// Test to get sales offices with dr address id, including child offices, using a valid filter
        /// </summary>
        /// <returns>List of sales offices</returns>
        [Fact]
        public async Task GetSalesOfficeList_FilterCallingForOfficesWithDrAddressIdIncludingChildren_ReturnsSalesOffices()
        {
            // Arrange
            var salesOfficeFilter = new SalesOfficeFilter() { DrAddressId = 0, ExcludeParts = false, FilterCriteria = "salesofficewithdraddressidincludingchildren" };
            IEnumerable<AllSalesOffice> salesOffices = new List<AllSalesOffice>
            {
                new AllSalesOffice()
                {
                    SalesOfficeId = 123,
                    SalesOfficeName = "Billings",
                    DrAddressId = 122,
                    CrmIntegrationInd = "N",
                    SalesDistrict = "12",
                    SalesOfficeIdParent = 13
                },
            };
            this.traneSalesBusinessDataRepository.Setup(x => x.GetSalesOfficeWithDrAddressIdIncludingChildOffices(salesOfficeFilter)).Returns(Task.FromResult(salesOffices)).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeList(salesOfficeFilter);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SalesOfficeName == "Billings");
            this.traneSalesBusinessDataRepository.Verify();
        }

        /// <summary>
        /// Test to get sales offices and dr address id using a valid filter
        /// </summary>
        /// <returns>List of sales offices</returns>
        [Fact]
        public async Task GetSalesOfficeWithDrAddressId_ValidRequest_ReturnsSalesOfficesWithDrAddressId()
        {
            // Arrange
            int drAddressId = 101;
            var salesOfficeFilter = new SalesOfficeFilter() { DrAddressId = 0, ExcludeParts = false, FilterCriteria = "salesofficewithdraddressid" };
            IEnumerable<AllSalesOffice> salesOffices = new List<AllSalesOffice>
            {
                new AllSalesOffice()
                {
                    SalesOfficeId = 123,
                    SalesOfficeName = "Billings",
                    DrAddressId = drAddressId,
                    CrmIntegrationInd = "N",
                    SalesDistrict = "12",
                    SalesOfficeIdParent = 13
                },
            };
            this.traneSalesBusinessDataRepository.Setup(x => x.GetSalesOfficeWithDrAddressId(salesOfficeFilter)).Returns(Task.FromResult(salesOffices)).Verifiable();

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeList(salesOfficeFilter);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SalesOfficeName == "Billings");
            this.traneSalesBusinessDataRepository.Verify();
            this.contextAccessor.Verify(x => x.HttpContext.Items, Times.AtLeastOnce);
            this.competitorRepository.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
        }

        /// <summary>
        /// Verifies get provider method returns valid provider details
        /// </summary>
        /// <returns>Provider details</returns>
        [Fact]
        public async Task GetProviders_HasProviderDetails_ReturnsProviderDetails()
        {
            // Arrange
            IEnumerable<Provider> providers = new List<Provider>
            {
                new Provider()
                {
                   VENDOR_ID = 100,
                   VENDOR_NAME = "Kentuckiana Curb Company",
                   STATUS = "C"
                },
                new Provider()
                {
                   VENDOR_ID = 200,
                   VENDOR_NAME = "Thybar",
                   STATUS = "C"
                }
            };
            this.traneSalesBusinessDataRepository.Setup(x => x.GetProviders()).Returns(Task.FromResult(providers));

            // Act
            var result = await this.traneSalesBusinessDataService.GetProviders();

            // Assert
            Assert.Equal(100, result.First().VendorId);
            Assert.Equal("Kentuckiana Curb Company", result.First().VendorName);
            Assert.Equal("C", result.First().Status);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetProviders(), Times.Once);
        }

        [Fact]
        public async Task GetEquipments_ReturnsEquipmentList()
        {
            // Arrange
            IEnumerable<Equipment> equipments = new List<Equipment>
            {
                new Equipment()
                {
                   PRODUCT_ID = 55,
                   PRODUCT_NAME = "Acoustics",
                   STATUS = "C",
                   VENDOR_ID = 85
                },
                new Equipment()
                {
                   PRODUCT_ID = 58,
                   PRODUCT_NAME = "Computer room units",
                   STATUS = "C",
                   VENDOR_ID = 108
                }
            };
            this.traneSalesBusinessDataRepository.Setup(x => x.GetEquipments()).Returns(Task.FromResult(equipments));

            // Act
            var result = await this.traneSalesBusinessDataService.GetEquipments();

            // Assert
            Assert.Equal(55, result.First().ProductId);
            Assert.Equal("Acoustics", result.First().ProductName);
            Assert.Equal("C", result.First().Status);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetEquipments(), Times.Once);
        }

        [Fact]
        public async Task GetClassifications_HasClassifications_ReturnsClassifications()
        {
            // Arrange
            IEnumerable<Classification> classifications = new List<Classification>()
            {
                Helper.GetClassification()
            };
            IEnumerable<ClassificationViewModel> expectedClassificationsViewModel = new List<ClassificationViewModel>()
            {
                Helper.GetClassificationViewModel()
            };
            this.traneSalesBusinessDataRepository.Setup(x => x.GetClassifications())
                .Returns(Task.FromResult(classifications));

            // Act
            IEnumerable<ClassificationViewModel> classificationsViewModel = await this.traneSalesBusinessDataService.GetClassifications();

            // Assert
            Assert.Equal(expectedClassificationsViewModel.Single().JobClassId, classificationsViewModel.Single().JobClassId);
            Assert.Equal(expectedClassificationsViewModel.Single().Description, classificationsViewModel.Single().Description);
            Assert.Equal(expectedClassificationsViewModel.Single().Codes, classificationsViewModel.Single().Codes);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetClassifications(), Times.Once);
        }

        [Fact]
        public async Task GetSystemTypes_HasSystemTypes_ReturnsSystemTypes()
        {
            // Arrange
            IEnumerable<JobSystemTypeViewModel> expectedSystemTypesViewModel = new List<JobSystemTypeViewModel>()
            {
                Helper.GetJobSystemTypeViewModel()
            };
            IEnumerable<JobSystemType> expectedSystemTypes = new List<JobSystemType>()
            {
                Helper.GetJobSystemType()
            };
            this.traneSalesBusinessDataRepository.Setup(x => x.GetSystemTypes())
                .Returns(Task.FromResult(expectedSystemTypes));

            // Act
            IEnumerable<JobSystemTypeViewModel> actualSystemTypesViewModel = await this.traneSalesBusinessDataService.GetSystemTypes();

            // Assert
            Assert.Equal(expectedSystemTypesViewModel.Single(), actualSystemTypesViewModel.Single());
            this.traneSalesBusinessDataRepository.Verify(x => x.GetSystemTypes(), Times.Once);
        }

        /// <summary>
        /// Test to get all sales offices in ascending order
        /// </summary>
        /// <returns>List of all sales offices in ascending order</returns>
        [Fact]
        public async Task GetSalesOfficeList_SortBySalesOfficeName_ReturnsSalesOfficesInAscendingOrder()
        {
            // Arrange
            IEnumerable<SalesOffice> salesOffices = new List<SalesOffice>()
            {
                new SalesOffice()
                {
                    Sales_office_id = 2075,
                    Sales_office_name = "Australia",
                    Sales_office_id_parent = 1,
                    Sales_district = "34",
                    Country = "USA"
                },
                new SalesOffice()
                {
                    Sales_office_id = 59,
                    Sales_office_name = "Shreveport TCS Ind SO LA",
                    Sales_office_id_parent = 57,
                    Sales_district = "57",
                    Country = "USA"
                }
            };
            this.repository.Setup(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>(It.IsAny<string>()))
                .Returns(Task.FromResult(salesOffices));

            // Act
            var result = await this.traneSalesBusinessDataService.GetSalesOfficeList();

            // Assert
            Assert.True(result.ElementAt(0).SalesOfficeName == "Australia" && result.ElementAt(1).SalesOfficeName == "Shreveport TCS Ind SO LA");
            this.repository.Verify(x => x.GetListAsync<global::JobService.Core.Models.SalesOffice>("where status='C' order by Sales_office_name"), Times.Once);
        }

        [Fact]
        public async Task GetRevenueStream_HasRecords_ReturnsRevenueStream()
        {
            // Arrange
            RevenueStreamModel revenueStreamModel = Helper.GetRevenueStreamModel();
            RevenueStreamViewModel revenueStreamViewModel = Helper.GetRevenueStreamViewModel();
            IEnumerable<BsonDocument> revenueStreamBsonDocument = new List<BsonDocument>() { revenueStreamModel.ToBsonDocument() };
            IEnumerable<RevenueStreamViewModel> revenueStreamViewList = new List<RevenueStreamViewModel>() { revenueStreamViewModel };
            this.revenueStreamRepository.Setup(x => x.GetRevenueDetails()).Returns(Task.FromResult(revenueStreamBsonDocument));

            // Act
            IEnumerable<RevenueStreamViewModel> result = await this.traneSalesBusinessDataService.GetRevenueDetails();

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(revenueStreamViewList.Count(), result.Count());
            this.revenueStreamRepository.Verify(x => x.GetRevenueDetails(), Times.Once);
        }

        [Fact]
        public async Task GetSiteContactList_HasSiteContactList_ReturnsSiteContactList()
        {
            // Arrange
            IEnumerable<SiteContactViewModel> siteContactList = new List<SiteContactViewModel>()
            {
                Helper.GetSiteContact()
            };
            IEnumerable<SiteContact> siteContacts = new List<SiteContact>()
            {
                Helper.GetSiteContactModel()
            };
            this.traneSalesBusinessDataRepository.Setup(x => x.GetSiteContactList())
                .Returns(Task.FromResult(siteContacts));

            // Act
            IEnumerable<SiteContactViewModel> result = await this.traneSalesBusinessDataService.GetSiteContactList();

            // Assert
            Assert.Equal(siteContactList.Single().EmailAddress, result.Single().EmailAddress);
            Assert.Equal(siteContactList.Single().FirstName, result.Single().FirstName);
            Assert.Equal(siteContactList.Single().LastName, result.Single().LastName);
            Assert.Equal(siteContactList.Single().PhoneNumber, result.Single().PhoneNumber);
            this.traneSalesBusinessDataRepository.Verify(x => x.GetSiteContactList(), Times.Once);
        }

        [Fact]
        public async Task GetPrograms_HasPrograms_ReturnsPrograms()
        {
            // Assert
            IEnumerable<BsonDocument> jobProgramBsonDocument = new List<BsonDocument>() { Helper.GetProgramModel().ToBsonDocument() };
            IEnumerable<ProgramViewModel> jobPrograms = new List<ProgramViewModel>() { Helper.GetProgram() };
            this.jobProgramRepository.Setup(x => x.GetJobPrograms()).Returns(Task.FromResult(jobProgramBsonDocument));

            // Act
            IEnumerable<ProgramViewModel> result = await this.traneSalesBusinessDataService.GetPrograms();

            // Assert
            Assert.Equal(jobPrograms.Single().ProgramCode, result.Single().ProgramCode);
            Assert.Equal(jobPrograms.Single().ProgramDescription, result.Single().ProgramDescription);
            this.jobProgramRepository.Verify(x => x.GetJobPrograms(), Times.Once);
        }
    }
}
