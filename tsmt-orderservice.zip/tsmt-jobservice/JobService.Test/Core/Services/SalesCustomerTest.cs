// <copyright file="SalesCustomerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoFixture;
    using AutoMapper;
    using JobService.Common.Exceptions;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    /// <summary>
    /// SalesCustomerTest Methods
    /// </summary>
    public class SalesCustomerTest
    {
        private readonly Mock<IRepository<global::JobService.Core.Models.JobDetails>> repository;
        private readonly Mock<ISalesCustomerRepository> salesCustomerRepository;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly IMapper mapper;
        private readonly SalesCustomerService salesCustomerService;

        public SalesCustomerTest()
        {
            this.repository = new Mock<IRepository<JobDetails>>();
            this.salesCustomerRepository = new Mock<ISalesCustomerRepository>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
        }

        [Fact]
        public async Task GetCustomerNameList_ValidRequest_ReturnsValidData()
        {
            // Arrange
            int drAddressId = 101;
            var drAddressIdFromHttpContext = new Dictionary<object, object>();
            drAddressIdFromHttpContext.Add("DR_ADDRESS_ID", drAddressId);
            this.contextAccessor.Setup(x => x.HttpContext.Items).Returns(drAddressIdFromHttpContext);
            var customerName = "North Quincy High School";
            List<SalesCustomerView> customerNameList = new List<SalesCustomerView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerView() { CustomerName = "North Quincy High School" },
            };
            this.salesCustomerRepository.Setup(x => x.GetCustomerNameListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(customerNameList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetCustomerNameList(customerName);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(customerNameList, result);
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.CustomerName == "North Quincy High School").Any());
            this.salesCustomerRepository.Verify(x => x.GetCustomerNameListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
            this.contextAccessor.Verify(x => x.HttpContext.Items, Times.AtLeastOnce);
            this.salesCustomerRepository.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
            this.repository.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
        }

        [Fact]
        public async Task GetCustomerNameList_InvalidRequest_ReturnsEmptyList()
        {
            // Arrange
            List<SalesCustomerView> customerNameList = new List<SalesCustomerView>();
            this.salesCustomerRepository.Setup(x => x.GetCustomerNameListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(customerNameList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetCustomerNameList(string.Empty);

            // Assert
            Assert.IsType<List<SalesCustomerView>>(result);
            Assert.Empty(result);
            this.salesCustomerRepository.Verify(x => x.GetCustomerNameListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetCustomerAndContactList_ValidRequest_ReturnsValidData()
        {
            // Arrange
            var fixture = new Fixture();
            var customerContactView = fixture.Create<SalesCustomerCreateView>();
            this.salesCustomerRepository.Setup(x => x.GetCustomerAndContactsAsync(1)).Returns(Task.FromResult(customerContactView)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetCustomerAndContactList(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(customerContactView.JobId, result.JobId);
            this.salesCustomerRepository.Verify(x => x.GetCustomerAndContactsAsync(It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task GetCustomerAndContactList_ValidRequest_ReturnsInValidData()
        {
            // Arrange
            var fixture = new Fixture();
            SalesCustomerCreateView salesCustomerCreateView = null;
            this.salesCustomerRepository.Setup(x => x.GetCustomerAndContactsAsync(1)).Returns(Task.FromResult(salesCustomerCreateView)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetCustomerAndContactList(1);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetAccountNumberList_ValidRequest_ReturnsValidData()
        {
            // Arrange
            var accountNumber = "3042336";
            List<SalesCustomerView> accountNumberList = new List<SalesCustomerView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerView() { AccountNumber = "3042336" },
            };
            this.salesCustomerRepository.Setup(x => x.GetAccountNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(accountNumberList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetAccountNumberList(accountNumber);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(accountNumberList, result);
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.AccountNumber == "3042336").Any());
            this.salesCustomerRepository.Verify(x => x.GetAccountNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetAccountNumberList_InvalidRequest_ReturnsEmptyList()
        {
            // Arrange
            List<SalesCustomerView> accountNumberList = new List<SalesCustomerView>();
            this.salesCustomerRepository.Setup(x => x.GetAccountNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(accountNumberList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetAccountNumberList(string.Empty);

            // Assert
            Assert.IsType<List<SalesCustomerView>>(result);
            Assert.Empty(result);
            this.salesCustomerRepository.Verify(x => x.GetAccountNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetPhoneNumberList_ValidRequest_ReturnsValidData()
        {
            // Arrange
            var phoneNumber = "-301/545-0750";
            List<SalesCustomerView> phoneNumberList = new List<SalesCustomerView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerView() { PhoneNumber = "-301/545-0750" },
            };
            this.salesCustomerRepository.Setup(x => x.GetPhoneNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(phoneNumberList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetPhoneNumberList(phoneNumber);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(phoneNumberList, result);
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.PhoneNumber == "-301/545-0750").Any());
            this.salesCustomerRepository.Verify(x => x.GetPhoneNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetPhoneNumberList_InvalidRequest_ReturnsEmptyList()
        {
            // Arrange
            List<SalesCustomerView> phoneNumberList = new List<SalesCustomerView>();
            this.salesCustomerRepository.Setup(x => x.GetPhoneNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(phoneNumberList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetPhoneNumberList(string.Empty);

            // Assert
            Assert.IsType<List<SalesCustomerView>>(result);
            Assert.Empty(result);
            this.salesCustomerRepository.Verify(x => x.GetPhoneNumberListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetPostalCodeList_ValidRequest_ReturnsValidData()
        {
            // Arrange
            var postalCode = "02171";
            List<SalesCustomerView> postalCodeList = new List<SalesCustomerView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerView() { ZipCode = "02171" },
            };
            this.salesCustomerRepository.Setup(x => x.GetPostalCodeListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(postalCodeList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetPostalCodeList(postalCode);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(postalCodeList, result);
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.ZipCode == "02171").Any());
            this.salesCustomerRepository.Verify(x => x.GetPostalCodeListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetPostalCodeList_InvalidRequest_ReturnsEmptyList()
        {
            // Arrange
            List<SalesCustomerView> postalCodeList = new List<SalesCustomerView>();
            this.salesCustomerRepository.Setup(x => x.GetPostalCodeListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()))
                 .Returns(Task.FromResult(postalCodeList.AsEnumerable())).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetPostalCodeList(string.Empty);

            // Assert
            Assert.IsType<List<SalesCustomerView>>(result);
            Assert.Empty(result);
            this.salesCustomerRepository.Verify(x => x.GetPostalCodeListAsync<global::JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetStateList_ReturnsValidData()
        {
            string search = "WI";
            IEnumerable<StateView> states = new List<StateView>
            {
                    new StateView()
                    {
                      StateProvinceCode = "WI"
                    }
            };

            this.salesCustomerRepository.Setup(x => x.GetStatesListAsync<StateView>(search)).Returns(Task.FromResult(states)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetStateList(search);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.Country == "WI").Any());
            this.salesCustomerRepository.Verify(x => x.GetStatesListAsync<StateView>(search), Times.Once);
        }

        [Fact]
        public async Task GetStateList_ReturnsEmptyList()
        {
            string search = "WI";
            IEnumerable<StateView> states = new List<StateView>();
            this.salesCustomerRepository.Setup(x => x.GetStatesListAsync<StateView>(search)).Returns(Task.FromResult(states)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetStateList(search);

            // Assert
            Assert.Empty(result);
            this.salesCustomerRepository.Verify(x => x.GetStatesListAsync<StateView>(search), Times.Once);
        }

        [Fact]
        public async Task DeleteCustomerContact_ValidInput_ReturnsValidData()
        {
            int salesCustomerId = 11;
            int customerContactId = 1;
            int recordsDeleted = 1;
            int availableContacts = 4;

            this.salesCustomerRepository.Setup(x => x.GetCustomerContactCount(salesCustomerId)).Returns(Task.FromResult(availableContacts)).Verifiable();
            this.salesCustomerRepository.Setup(x => x.DeleteCustomerContactAsync(salesCustomerId, customerContactId)).Returns(Task.FromResult(recordsDeleted)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.DeleteCustomerContact(salesCustomerId, customerContactId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.salesCustomerRepository.Verify();
        }

        [Fact]
        public async Task DeleteCustomerContact_InvalidRequest_ReturnsZero()
        {
            int salesCustomerId = 11;
            int customerContactId = 1;
            int recordsDeleted = 0;
            int availableContacts = 1;

            this.salesCustomerRepository.Setup(x => x.GetCustomerContactCount(salesCustomerId)).Returns(Task.FromResult(availableContacts)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.DeleteCustomerContact(salesCustomerId, customerContactId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.salesCustomerRepository.Verify();
        }

        [Fact]
        public async Task CreateCustomer_ValidRequest_ReturnsSalesCustId()
        {
            // Arrange
            string customerTable = "Sales_Cust";
            string contactTable = "Sales_Cust_Contact";
            string jobRoleAsnTable = "Job_Role_Asn";
            string jobRoleContactTable = "Job_Role_Contact";
            var salesCustId = 1006;
            var salesCustContactId = 1;
            var jobRoleAsnId = 667;
            var jobRoleContactId = 998;
            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 0,
                JobRoleContactId = 0,
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true
                },
            };
            var customer = new global::JobService.Core.ViewModels.SalesCustomerCreateView()
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8643745050",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber(customerTable))
                .Returns(Task.FromResult(salesCustId)).Verifiable();
            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber(contactTable))
                .Returns(Task.FromResult(salesCustContactId)).Verifiable();
            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber(jobRoleAsnTable))
                .Returns(Task.FromResult(jobRoleAsnId)).Verifiable();
            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber(jobRoleContactTable))
                .Returns(Task.FromResult(jobRoleContactId)).Verifiable();

            this.salesCustomerRepository.Setup(x => x.InsertCustomerAsync(It.IsAny<global::JobService.Core.Models.SalesCustomerCreate>(), It.IsAny<IEnumerable<SalesCustomerContact>>(), It.IsAny<List<AssignCustomerModel>>(), It.IsAny<IEnumerable<CustomerContact>>()))
                .Returns(Task.FromResult(salesCustId)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.CreateCustomer(customer);

            // Assert
            Assert.IsType<int>(result);
            Assert.True(result > 0);
            Assert.Equal(result, salesCustId);
            this.salesCustomerRepository.Verify();
        }

        [Fact]
        public async Task CreateCustomer_DuplicateContactName_ThrowsException()
        {
            // Arrange
            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 0,
                JobRoleContactId = 0,
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true
                },
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 0,
                JobRoleContactId = 0,
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true,
                },
            };
            var customer = new global::JobService.Core.ViewModels.SalesCustomerCreateView()
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8239899655",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await Assert.ThrowsAsync<JobMaintenanceDomainException>(async () => await salesCustomerService.CreateCustomer(customer));

            // Assert
            Assert.IsType<JobMaintenanceDomainException>(result);
            Assert.Contains(result.Message, "The following contacts are duplicates: Jack Dill");
        }

        [Fact]
        public async Task ValidateCommCode_ValidRequest_ReturnsTrue()
        {
            // Arrange
            var chkValue = true;
            var commCode = "RC01";
            var saleOfficeId = 122;

            this.salesCustomerRepository.Setup(x => x.ValidateCommCode(commCode, saleOfficeId))
                 .Returns(Task.FromResult(chkValue)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.ValidateCommCode(commCode, saleOfficeId);

            // Assert
            Assert.True(result);
            this.salesCustomerRepository.Verify(x => x.ValidateCommCode(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task ValidateCommCode_InvalidRequest_ReturnsFalse()
        {
            // Arrange
            var chkValue = false;
            var commCode = string.Empty;
            var saleOfficeId = 0;

            this.salesCustomerRepository.Setup(x => x.ValidateCommCode(commCode, saleOfficeId))
                 .Returns(Task.FromResult(chkValue)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.ValidateCommCode(commCode, saleOfficeId);

            // Assert
            Assert.False(result);
            this.salesCustomerRepository.Verify(x => x.ValidateCommCode(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task ValidateSalesOffice_ValidRequest_ReturnsTrue()
        {
            // Arrange
            var chkValue = true;
            var saleOfficeId = 122;

            this.salesCustomerRepository.Setup(x => x.ValidateSalesCustId(saleOfficeId))
                 .Returns(Task.FromResult(chkValue)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.ValidateSalesCustId(saleOfficeId);

            // Assert
            Assert.True(result);
            this.salesCustomerRepository.Verify(x => x.ValidateSalesCustId(It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task ValidateSalesOffice_InvalidRequest_ReturnsFalse()
        {
            // Arrange
            var chkValue = false;
            var saleOfficeId = 0;

            this.salesCustomerRepository.Setup(x => x.ValidateSalesCustId(saleOfficeId))
                .Returns(Task.FromResult(chkValue)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.ValidateSalesCustId(saleOfficeId);

            // Assert
            Assert.False(result);
            this.salesCustomerRepository.Verify(x => x.ValidateSalesCustId(It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task GetCustomerList_ValidRequest_ReturnsData()
        {
            // Arrange
            IEnumerable<CustomerViewModel> customerList = new List<CustomerViewModel>
            {
                new global::JobService.Core.ViewModels.CustomerViewModel()
                {
                    SalesCustId = 124,
                    FirstName = "Jack",
                    CustomerName = "Air Controls Co. Inc.",
                    Address = "2115 2nd Ave North BILLINGS MT USA",
                    CommCode = "A01",
                    TotalCount = 1,
                    LastName = "Rick",
                    StreetAddress1 = "3rd Ave MT",
                    StreetAddress2 = "USA",
                    State = "MT",
                    ZipCode = "29904",
                    NonUsPostalCode = "53732",
                    City = "WT",
                    CustAcctNbr = "63832",
                    JobRoleTypeId = 536,
                    Region = "NORTH",
                    PhoneNumber = "629399033",
                    FaxNumber = "36782",
                    ContactPhoneNumber = "523920023",
                    ContactFaxNumber = "583838",
                    ContactPhoneExtension = "439"
                },
            };
            int skip = 0;
            int take = 10;
            string searchText = "Jack";
            bool isNullCustomerAccountNumberRequired = false;

            this.salesCustomerRepository.Setup(x => x.GetCustomerListAsync(skip, take, searchText, isNullCustomerAccountNumberRequired))
                .Returns(Task.FromResult(customerList)).Verifiable();

            // Act
            CustomerListPagingResults result = await this.salesCustomerService.GetCustomerList(skip, take, searchText, isNullCustomerAccountNumberRequired);

            // Assert
            Assert.IsType<CustomerListPagingResults>(result);
            Assert.Equal(customerList.Count(), result.CustomerList.Count());
            Assert.True(result.CustomerList.Select(a => a.FirstName == "Jack").Any());
            Assert.True(result.CustomerList.Select(a => a.SalesCustId == 124).Any());
            Assert.True(result.CustomerList.Select(a => a.CustomerName == "Air Controls Co. Inc.").Any());
            Assert.True(result.CustomerList.Select(a => a.Address == "2115 2nd Ave North BILLINGS MT USA").Any());
            Assert.True(result.CustomerList.Select(a => a.CommCode == "A01").Any());
            Assert.True(result.CustomerList.Select(a => a.TotalCount == 1).Any());
            this.salesCustomerRepository.Verify();
        }

        [Fact]
        public async Task GetCustomerList_InvalidRequest_ReturnsNoData()
        {
            // Arrange
            IEnumerable<CustomerViewModel> customerList = new List<CustomerViewModel>();
            int skip = 0;
            int take = 10;
            string searchText = "Jack";
            bool isNullCustomerAccountNumberRequired = false;

            this.salesCustomerRepository.Setup(x => x.GetCustomerListAsync(skip, take, searchText, isNullCustomerAccountNumberRequired))
                .Returns(Task.FromResult(customerList)).Verifiable();

            // Act
            CustomerListPagingResults result = await this.salesCustomerService.GetCustomerList(skip, take, searchText, isNullCustomerAccountNumberRequired);

            // Assert
            Assert.Null(result);
            this.salesCustomerRepository.Verify();
        }

        [Fact]
        public async Task AssignCustomer_ValidRequest_Insertion_Success()
        {
            // Arrange
            int jobRoleAsnId = 1;
            var jobRoleContactId = 1;
            int isInserted = 1;
            var jobRoleList = new global::JobService.Core.ViewModels.JobRoleAsnView()
            {
                JobRoleAsnId = 1,
                JobId = 4004,
                JobRoleTypeId = 1,
                CustAcctNbr = "3042336",
                SalesCustomerName = "North Quincy High School",
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber("Job_Role_Asn"))
                .Returns(Task.FromResult(jobRoleAsnId));
            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber("job_role_contact"))
               .Returns(Task.FromResult(jobRoleContactId));

            this.salesCustomerRepository.Setup(x => x.InsertJobRoleAndContactAsync(It.IsAny<global::JobService.Core.Models.JobRoleAsn>(), It.IsAny<global::JobService.Core.Models.CustomerContact>()))
                .Returns(Task.FromResult(isInserted));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.AssignCustomer(jobRoleList);

            // Assert
            Assert.IsType<int>(result);
            this.salesCustomerRepository.Verify(x => x.GetSequenceNumber("Job_Role_Asn"), Times.Once);
            this.salesCustomerRepository.Verify(x => x.GetSequenceNumber("Job_Role_Contact"), Times.Once);
            this.salesCustomerRepository.Verify(x => x.InsertJobRoleAndContactAsync(It.IsAny<global::JobService.Core.Models.JobRoleAsn>(), It.IsAny<global::JobService.Core.Models.CustomerContact>()), Times.Once);
        }

        [Fact]
        public async Task AssignCustomer_InvalidRequest_Insertion_Failed()
        {
            // Arrange
            int jobRoleAsnId = 0;
            var jobRoleContactId = 0;
            int isInserted = 0;
            var jobRoleList = new global::JobService.Core.ViewModels.JobRoleAsnView()
            {
                JobRoleAsnId = 1,
                JobId = 4004,
                JobRoleTypeId = 1,
                CustAcctNbr = "3042336",
                SalesCustomerName = "North Quincy High School",
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber("Job_Role_Asn"))
                .Returns(Task.FromResult(jobRoleAsnId));
            this.salesCustomerRepository.Setup(x => x.GetSequenceNumber("Job_Role_Contact"))
                .Returns(Task.FromResult(jobRoleContactId));

            this.salesCustomerRepository.Setup(x => x.InsertJobRoleAndContactAsync(It.IsAny<global::JobService.Core.Models.JobRoleAsn>(), It.IsAny<global::JobService.Core.Models.CustomerContact>()))
                .Returns(Task.FromResult(isInserted));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.AssignCustomer(jobRoleList);

            // Assert
            Assert.IsType<int>(result);
            this.salesCustomerRepository.Verify(x => x.GetSequenceNumber("Job_Role_Asn"), Times.Once);
            this.salesCustomerRepository.Verify(x => x.GetSequenceNumber("Job_Role_Contact"), Times.Once);
            this.salesCustomerRepository.Verify(x => x.InsertJobRoleAndContactAsync(It.IsAny<global::JobService.Core.Models.JobRoleAsn>(), It.IsAny<global::JobService.Core.Models.CustomerContact>()), Times.Once);
        }

        [Fact]
        public async Task GetAssignedCustomerList_ValidRequest_ReturnsListOfData()
        {
            // Arrange
            IEnumerable<global::JobService.Core.ViewModels.AssignCustomerViewModel> customerList = new List<global::JobService.Core.ViewModels.AssignCustomerViewModel>
            {
                    new global::JobService.Core.ViewModels.AssignCustomerViewModel()
                    {
                        SalesCustId = 10117,
                        CustomerName = "Ulliman Schutte Construction LLC",
                        Address = "7615 Standish Place",
                        PhoneNbr = "-301/545-0750",
                        CustAcctNbr = "3800876",
                        JobRoleTypeId = 0,
                        CommCode = "U98",
                        BidderInd = "Y",
                        WinningBidderInd = "Y",
                        TotalCount = 1
                    }
            };

            int skip = 0;
            int take = 20;
            int jobId = 59297;
            this.salesCustomerRepository.Setup(x => x.GetAssignedCustomerListByIdAsync(skip, take, jobId, false))
               .Returns(Task.FromResult(customerList)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetAssignedCustomerListById(skip, take, jobId, false);

            // Assert
            Assert.IsType<AssignCustomerListPagingResults>(result);
            Assert.NotNull(result);
            Assert.Equal(customerList.Count(), result.CustomerList.Count());
            this.salesCustomerRepository.Verify();
        }

        [Fact]
        public async Task GetAssignedCustomerList_InvalidRequest_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<AssignCustomerViewModel> customerList = new List<AssignCustomerViewModel>();
            int skip = 0;
            int take = 20;
            int jobId = 59297;

            this.salesCustomerRepository.Setup(x => x.GetAssignedCustomerListByIdAsync(skip, take, jobId, false))
                .Returns(Task.FromResult(customerList));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetAssignedCustomerListById(skip, take, jobId, false);

            // Assert
            Assert.Null(result);
            this.salesCustomerRepository.Verify(x => x.GetAssignedCustomerListByIdAsync(skip, take, jobId, false), Times.Once);
        }

        [Fact]
        public async Task UnassignCustomer_ValidInput_DeletionSuccess()
        {
            int jobRoleAsnId = 1;
            int recordsDeleted = 1;

            this.salesCustomerRepository.Setup(x => x.UnassignCustomer(jobRoleAsnId)).Returns(Task.FromResult(recordsDeleted)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.UnassignCustomer(jobRoleAsnId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.salesCustomerRepository.Verify(x => x.UnassignCustomer(jobRoleAsnId), Times.Once);
        }

        [Fact]
        public async Task UnassignCustomer_InvalidInput_DeletionFailure()
        {
            int jobRoleAsnId = 0;
            int recordsDeleted = 0;

            this.salesCustomerRepository.Setup(x => x.UnassignCustomer(jobRoleAsnId)).Returns(Task.FromResult(recordsDeleted)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.UnassignCustomer(jobRoleAsnId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.salesCustomerRepository.Verify(x => x.UnassignCustomer(jobRoleAsnId), Times.Once);
        }

        [Fact]
        public async Task UpdateCustomer_ValidInput_ReturnValidSalesCustId()
        {
            // Assert
            int salesCustId = 100;

            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 90,
                JobRoleContactId = 1,
                CustomerContactId = 1,
                SalesCustId = 100,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true
                },
            };

            SalesCustomerCreateView salesCustomerCreateView = new SalesCustomerCreateView()
            {
                SalesCustId = 100,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8643745050",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            var customer = new global::JobService.Core.ViewModels.SalesCustomerCreateView()
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8643745050",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            this.salesCustomerRepository.Setup(x => x.UpdateCustomerAsync(
                It.IsAny<SalesCustomerCreate>(),
                It.IsAny<IEnumerable<SalesCustomerContact>>(),
                It.IsAny<IEnumerable<SalesCustomerContact>>(),
                It.IsAny<IEnumerable<JobRoleAsn>>(),
                It.IsAny<IEnumerable<CustomerContact>>(),
                It.IsAny<List<AssignCustomerModel>>(),
                It.IsAny<IEnumerable<CustomerContact>>()))
                .Returns(Task.FromResult(salesCustId));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.UpdateCustomer(salesCustomerCreateView);

            // Assert
            Assert.IsType<int>(result);
            Assert.Equal(result, salesCustId);
        }

        [Fact]
        public async Task UpdateCustomer_InValidInput_ReturnZeroSalesCustId()
        {
            // Assert
            int salesCustId = 0;

            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                JobRoleAsnId = 90,
                JobRoleContactId = 0,
                CustomerContactId = 0,
                SalesCustId = 100,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655",
                FaxNbr = "88977654",
                AssignContact = true
                },
            };

            SalesCustomerCreateView salesCustomerCreateView = new SalesCustomerCreateView()
            {
                SalesCustId = 100,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8643745050",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            var customer = new global::JobService.Core.ViewModels.SalesCustomerCreateView()
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "8643745050",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                JobId = 44567,
                JobRoleAsnId = 0,
                SalesCustomerContactView = contactList
            };

            this.salesCustomerRepository.Setup(x => x.UpdateCustomerAsync(
                It.IsAny<SalesCustomerCreate>(),
                It.IsAny<IEnumerable<SalesCustomerContact>>(),
                It.IsAny<IEnumerable<SalesCustomerContact>>(),
                It.IsAny<IEnumerable<JobRoleAsn>>(),
                It.IsAny<IEnumerable<CustomerContact>>(),
                It.IsAny<List<AssignCustomerModel>>(),
                It.IsAny<IEnumerable<CustomerContact>>()))
                .Returns(Task.FromResult(salesCustId));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.UpdateCustomer(salesCustomerCreateView);

            // Assert
            Assert.IsType<int>(result);
            Assert.Equal(result, salesCustId);
        }

        [Fact]
        public async Task UpdateAssignCustomer_ValidInput_ReturnValidJobRoleAsnId()
        {
            // Arrange
            bool updateStatus = true;

            JobRoleAsnView jobRoleAsnView = new JobRoleAsnView
            {
                JobRoleAsnId = 2711,
                JobId = 27144,
                JobRoleTypeId = 2,
                CustAcctNbr = "5678904",
                BidderInd = "Y",
                FaxNbr = "4575745677",
                HostUpdateInd = null,
                Name = "Jack Prill",
                PhoneNbr = "2344344323",
                SalesCustId = 211,
                SalesCustomerName = "Nano Brothers Inc.",
                WinningBidderInd = null,
                IsJobRoleSelected = false,
            };

            this.salesCustomerRepository.Setup(x => x.UpdateAssignCustomerAsync(
                It.IsAny<JobRoleAsn>())).Returns(Task.FromResult(updateStatus));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.UpdateAssignCustomer(jobRoleAsnView);

            // Assert
            Assert.IsType<bool>(result);
            Assert.Equal(result, updateStatus);
        }

        [Fact]
        public async Task UpdateAssignCustomer_InValidInput_ReturnZeroJobRoleAsnId()
        {
            // Arrange
            bool updateStatus = false;

            JobRoleAsnView jobRoleAsnView = new JobRoleAsnView
            {
                JobRoleAsnId = 0,
                JobId = 27144,
                JobRoleTypeId = 2,
                CustAcctNbr = "5678904",
                BidderInd = "Y",
                FaxNbr = "4575745677",
                HostUpdateInd = null,
                Name = "Jack Prill",
                PhoneNbr = "2344344323",
                SalesCustId = 211,
                SalesCustomerName = "Nano Brothers Inc.",
                WinningBidderInd = null,
                IsJobRoleSelected = false,
            };

            this.salesCustomerRepository.Setup(x => x.UpdateAssignCustomerAsync(
                It.IsAny<JobRoleAsn>()))
                .Returns(Task.FromResult(updateStatus));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.UpdateAssignCustomer(jobRoleAsnView);

            // Assert
            Assert.IsType<bool>(result);
            Assert.Equal(result, updateStatus);
        }

        [Fact]
        public async Task ValidateJobRole_InvalidRequest_ReturnsFalse()
        {
            // Arrange
            var chkValue = false;
            var jobRoleTypeId = 0;
            var salesCustId = 211;
            var jobId = 27355;
            var isJobRoleSelected = true;

            this.salesCustomerRepository.Setup(x => x.ValidateJobRole(jobRoleTypeId, salesCustId, jobId))
                 .Returns(Task.FromResult(chkValue));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.ValidateJobRole(jobRoleTypeId, salesCustId, jobId, isJobRoleSelected);

            // Assert
            Assert.False(result);
            this.salesCustomerRepository.Verify(x => x.ValidateJobRole(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task ValidateJobRole_ValidRequest_ReturnsTrue()
        {
            // Arrange
            var chkValue = true;
            var jobRoleTypeId = 2;
            var salesCustId = 2;
            var jobId = 27355;
            var isJobRoleSelected = true;

            this.salesCustomerRepository.Setup(x => x.ValidateJobRole(jobRoleTypeId, salesCustId, jobId))
                 .Returns(Task.FromResult(chkValue));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.ValidateJobRole(jobRoleTypeId, salesCustId, jobId, isJobRoleSelected);

            // Assert
            Assert.True(result);
            this.salesCustomerRepository.Verify(x => x.ValidateJobRole(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.Once);
        }

        [Fact]
        public async Task DeleteCustomer_ValidInput_ReturnsTrue()
        {
            int salesCustomerId = 11;
            bool recordsDeleted = true;

            this.salesCustomerRepository.Setup(x => x.DeleteCustomerAsync(salesCustomerId)).Returns(Task.FromResult(recordsDeleted)).Verifiable();

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.DeleteCustomer(salesCustomerId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.salesCustomerRepository.Verify();
        }

        [Fact]
        public async Task DeleteCustomer_InvalidRequest_ReturnsFalse()
        {
            int salesCustomerId = 11;
            bool recordsDeleted = false;

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.DeleteCustomer(salesCustomerId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.salesCustomerRepository.Verify();
        }

        /// <summary>
        /// customer contact details based on job role assignment - valid input
        /// </summary>
        /// <returns>Customer contact details</returns>
        [Fact]
        public async Task GetAssignedCustomerByJobAsnId_ValidRequest_ReturnsResult()
        {
            // Arrange
            AssignCustomerViewModel viewAssignedCustomer = new AssignCustomerViewModel
            {
                SalesCustId = 10117,
                CustomerName = "Ulliman Schutte Construction LLC",
                Address = "7615 Standish Place",
                PhoneNbr = "-301/545-0750",
                CustAcctNbr = "3800876",
                JobRoleTypeId = 0,
                CommCode = "U98",
                BidderInd = "Y",
                WinningBidderInd = "Y",
                JobRoleAsnId = "109"
            };
            int jobRoleAsnId = 109;
            int jobId = 59297;

            this.salesCustomerRepository.Setup(x => x.GetAssignedCustomerByJobRoleAsnId(jobRoleAsnId, jobId))
               .Returns(Task.FromResult(viewAssignedCustomer));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetAssignedCustomerByJobRoleAsnId(jobRoleAsnId, jobId);

            // Assert
            Assert.IsType<AssignCustomerViewModel>(result);
            Assert.NotNull(result);
            Assert.Equal(viewAssignedCustomer.JobRoleAsnId, result.JobRoleAsnId);
            this.salesCustomerRepository.Verify();
        }

        /// <summary>
        /// customer contact details based on job role assignment - invalid input
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetAssignedCustomerList_InvalidRequest_ReturnsNull()
        {
            // Arrange
            AssignCustomerViewModel viewAssignedCustomer = null;
            int jobId = 1090;
            int jobRoleAsnId = 59297;

            this.salesCustomerRepository.Setup(x => x.GetAssignedCustomerByJobRoleAsnId(jobRoleAsnId, jobId))
                .Returns(Task.FromResult(viewAssignedCustomer));

            // Act
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);
            var result = await salesCustomerService.GetAssignedCustomerByJobRoleAsnId(jobRoleAsnId, jobId);

            // Assert
            Assert.Null(result);
            this.salesCustomerRepository.Verify(x => x.GetAssignedCustomerByJobRoleAsnId(jobRoleAsnId, jobId), Times.Once);
        }

        /// <summary>
        /// Get sales customers called and customers exist
        /// </summary>
        /// <returns>IEnumerable of sales customer view model</returns>
        [Fact]
        public async Task GetSalesCustomers_SalesCustomersExists_ReturnSalesCustomers()
        {
            // Arrange
            int jobId = 45;
            var fixture = new Fixture();
            var salesCustomers = fixture.CreateMany<SalesCustomer>(3);
            this.salesCustomerRepository.Setup(x => x.GetSalesCustomers(jobId)).Returns(Task.FromResult(salesCustomers));
            var salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);

            // Act
            var salesCustomerViewModels = await salesCustomerService.GetSalesCustomers(jobId);

            // Assert
            Assert.Equal(salesCustomerViewModels.Count(), salesCustomers.Count());
            this.salesCustomerRepository.Verify(x => x.GetSalesCustomers(jobId), Times.Once);
        }

        /// <summary>
        ///  Get sales customers with addresses - Success
        /// </summary>
        /// <returns>Sales customers with addresses</returns>
        [Fact]
        public async Task GetSalesCustomersWithAddresses_SalesCustomersExistsForJobId_ReturnsSalesCustomersWithAddress()
        {
            // Arrange
            int jobId = 56065;

            IEnumerable<SalesCustomerWithAddress> salesCustomerWithAddresses = Helper.GetSalesCustomersWithAddresses();

            this.salesCustomerRepository.Setup(x => x.GetSalesCustomersWithAddresses(jobId)).Returns(Task.FromResult(salesCustomerWithAddresses)).Verifiable();
            SalesCustomerService salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);

            // Act
            IEnumerable<SalesCustomerWithAddressViewModel> result = await salesCustomerService.GetSalesCustomersWithAddresses(jobId);

            // Assert
            Assert.True(salesCustomerWithAddresses.First().NAME == result.First().Name && salesCustomerWithAddresses.First().CUST_ACCT_NBR == result.First().CustomerAccountNumber);
            Assert.True(salesCustomerWithAddresses.First().COUNTY_NAME == result.First().County);
            Assert.True(salesCustomerWithAddresses.First().PHONE_NBR == result.First().PhoneNumber);
            this.salesCustomerRepository.Verify(x => x.GetSalesCustomersWithAddresses(jobId), Times.Once);
        }

        /// <summary>
        ///  Get sales customers with addresses - null
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetSalesCustomersWithAddresses_SalesCustomersNotExistsForJobId_ReturnsEmptySalesCustomersDetails()
        {
            // Arrange
            int jobId = 56;

            IEnumerable<SalesCustomerWithAddress> salesCustomerWithAddresses = new List<SalesCustomerWithAddress>();

            this.salesCustomerRepository.Setup(x => x.GetSalesCustomersWithAddresses(jobId)).Returns(Task.FromResult(salesCustomerWithAddresses)).Verifiable();
            SalesCustomerService salesCustomerService = new SalesCustomerService(this.repository.Object, this.mapper, this.salesCustomerRepository.Object, this.contextAccessor.Object);

            // Act
            IEnumerable<SalesCustomerWithAddressViewModel> result = await salesCustomerService.GetSalesCustomersWithAddresses(jobId);

            // Assert
            Assert.Empty(result);
            this.salesCustomerRepository.Verify(x => x.GetSalesCustomersWithAddresses(jobId), Times.Once);
        }

        [Fact]
        public async Task GetContacts_HasData_ReturnsContacts()
        {
            // Arrange
            IEnumerable<SiteContactViewModel> contactDetails = new List<SiteContactViewModel>()
            {
                Helper.GetSiteContact()
            };
            IEnumerable<SiteContact> contacts = new List<SiteContact>()
            {
                Helper.GetSiteContactModel()
            };

            int skip = 0;
            int take = 10;
            string searchText = "Taylor";

            this.salesCustomerRepository.Setup(x => x.GetContacts(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
                .Returns(Task.FromResult(contacts));

            // Act
            ContactPagingResult result = await this.salesCustomerService.GetContacts(skip, take, searchText);

            // Assert
            Assert.IsType<ContactPagingResult>(result);
            Assert.Equal(contactDetails.Count(), result.Contacts.Count());
            Assert.True(result.Contacts.Select(a => a.LastName == contactDetails.Single().LastName).Any());
            Assert.True(result.Contacts.Select(a => a.FirstName == contactDetails.Single().FirstName).Any());
            Assert.True(result.Contacts.Select(a => a.PhoneNumber == contactDetails.Single().PhoneNumber).Any());
            Assert.True(result.Contacts.Select(a => a.EmailAddress == contactDetails.Single().EmailAddress).Any());
            Assert.True(result.Contacts.Select(a => a.ContactId == contactDetails.Single().ContactId).Any());
            Assert.True(result.Contacts.Select(a => a.SalesOfficeName == contactDetails.Single().SalesOfficeName).Any());
            Assert.True(result.Contacts.Select(a => a.TotalCount == 1).Any());
            Assert.True(result.PageNumber == 1);
            Assert.True(result.PageSize == take);
            Assert.True(result.PageCount == 1);
            this.salesCustomerRepository.Verify(x => x.GetContacts(skip, take, searchText), Times.Once);
        }

        [Fact]
        public async Task GetContacts_HasNoData_ReturnsNull()
        {
            // Arrange
            IEnumerable<SiteContact> contacts = new List<SiteContact>();
            int skip = 0;
            int take = 10;
            string searchText = "Taylor";

            this.salesCustomerRepository.Setup(x => x.GetContacts(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
                .Returns(Task.FromResult(contacts));

            // Act
            ContactPagingResult result = await this.salesCustomerService.GetContacts(skip, take, searchText);

            // Assert
            Assert.Null(result);
            this.salesCustomerRepository.Verify(x => x.GetContacts(skip, take, searchText), Times.Once);
        }

        /// <summary>
        /// Get sales customers called with filter criteria as crm company id and sales customer id and customers exist
        /// </summary>
        /// <returns>IEnumerable of sales customer view model</returns>
        [Fact]
        public async Task GetSalesCustomers_SalesCustomersExistsForCrmCompanyId_ReturnSalesCustomers()
        {
            // Arrange
            int salesCustomerId = 100;
            SalesCustomerFilter salesCustomerFilter = new SalesCustomerFilter()
            {
                SalesCustomerId = salesCustomerId,
                FilterCriteria = "crmcompanyid"
            };
            var fixture = new Fixture();
            var salesCustomers = fixture.CreateMany<SalesCustomerWithAddress>(3);
            this.salesCustomerRepository.Setup(x => x.GetSalesCustomersByCrmCompany(salesCustomerId)).Returns(Task.FromResult(salesCustomers));

            // Act
            IEnumerable<SalesCustomerWithAddressViewModel> salesCustomerViewModels = await this.salesCustomerService.GetSalesCustomers(salesCustomerFilter);

            // Assert
            Assert.Equal(salesCustomerViewModels.Count(), salesCustomers.Count());
            this.salesCustomerRepository.Verify(x => x.GetSalesCustomersByCrmCompany(salesCustomerId), Times.Once);
        }

        /// <summary>
        /// Get sales customers called with filter criteria as empty and sales customer id and returns empty
        /// </summary>
        /// <returns>IEnumerable of empty sales customer view model</returns>
        [Fact]
        public async Task GetSalesCustomers_WithFilterContainingSalesCustomerIdAndFilterCriteriaAsEmpty_ReturnsNull()
        {
            // Arrange
            int salesCustomerId = 100;
            SalesCustomerFilter salesCustomerFilter = new SalesCustomerFilter()
            {
                SalesCustomerId = salesCustomerId,
                FilterCriteria = string.Empty
            };
            this.salesCustomerRepository.Setup(x => x.GetSalesCustomersByCrmCompany(salesCustomerId)).Returns(Task.FromResult(It.IsAny<IEnumerable<SalesCustomerWithAddress>>()));

            // Act
            IEnumerable<SalesCustomerWithAddressViewModel> salesCustomerViewModels = await this.salesCustomerService.GetSalesCustomers(salesCustomerFilter);

            // Assert
            Assert.Null(salesCustomerViewModels);
            this.salesCustomerRepository.Verify(x => x.GetSalesCustomersByCrmCompany(salesCustomerId), Times.Never);
        }

        /// <summary>
        /// Get sales customers called with filter criteria as crm company id and sales customer id as zero and returns empty
        /// </summary>
        /// <returns>IEnumerable of empty sales customer view model</returns>
        [Fact]
        public async Task GetSalesCustomers_WithFilterContainingSalesCustomerIdAsZeroAndFilterCriteriaAsCrmCompanyId_ReturnsNull()
        {
            // Arrange
            int salesCustomerId = 0;
            SalesCustomerFilter salesCustomerFilter = new SalesCustomerFilter()
            {
                SalesCustomerId = salesCustomerId,
                FilterCriteria = "crmcompanyid"
            };
            this.salesCustomerRepository.Setup(x => x.GetSalesCustomersByCrmCompany(salesCustomerId)).Returns(Task.FromResult(It.IsAny<IEnumerable<SalesCustomerWithAddress>>()));

            // Act
            IEnumerable<SalesCustomerWithAddressViewModel> salesCustomerViewModels = await this.salesCustomerService.GetSalesCustomers(salesCustomerFilter);

            // Assert
            Assert.Null(salesCustomerViewModels);
            this.salesCustomerRepository.Verify(x => x.GetSalesCustomersByCrmCompany(salesCustomerId), Times.Never);
        }
    }
}
