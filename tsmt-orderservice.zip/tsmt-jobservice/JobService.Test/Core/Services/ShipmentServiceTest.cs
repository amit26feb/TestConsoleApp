// <copyright file="ShipmentServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoMapper;
    using global::JobService.Core.Models;
    using global::JobService.Core.ViewModels;
    using global::JobService.Repository;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    /// <summary>
    /// Shipment service test
    /// </summary>
    public class ShipmentServiceTest
    {
        private readonly Mock<IRepository<global::JobService.Core.Models.JobDetails>> repository;
        private readonly Mock<IShipmentRepository> shipmentRepository;
        private readonly Mock<IHttpContextAccessor> contextAccessor;
        private readonly IMapper mapper;
        private ShipmentService shipmentService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentServiceTest"/> class.
        /// </summary>
        public ShipmentServiceTest()
        {
            this.repository = new Mock<IRepository<JobDetails>>();
            this.shipmentRepository = new Mock<IShipmentRepository>();
            this.contextAccessor = new Mock<IHttpContextAccessor>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.shipmentService = new ShipmentService(this.repository.Object, this.mapper, this.shipmentRepository.Object, this.contextAccessor.Object);
        }

        /// <summary>
        /// Get shipping instruction by job id - Success
        /// </summary>
        /// <returns>Shipping instruction</returns>
        [Fact]
        public async Task GetShippingInstructionByJobId_ValidInput_ReturnsShippingInstruction()
        {
            // Arrange
            int jobId = 56065;
            var drAddressIdFromHttpContext = new Dictionary<object, object>();
            drAddressIdFromHttpContext.Add("DR_ADDRESS_ID", 78);
            this.contextAccessor.Setup(x => x.HttpContext.Items).Returns(drAddressIdFromHttpContext);
            ShippingInstruction shippingInstruction = new ShippingInstruction()
            {
                JOB_ID = 56065,
                SHIPPING_INSTRUCTION_ID = 101,
                COUNTRY = "USA"
            };

            this.shipmentRepository.Setup(x => x.GetShippingInstructionByJobId(jobId)).Returns(Task.FromResult(shippingInstruction));

            // Act
            ShippingInstructionViewModel result = await this.shipmentService.GetShippingInstructionByJobId(jobId);

            // Assert
            Assert.True(shippingInstruction.SHIPPING_INSTRUCTION_ID == result.ShippingInstructionId);
            Assert.Null(result.CreditJobId);
            this.shipmentRepository.Verify(x => x.GetShippingInstructionByJobId(jobId), Times.Once);
        }

        /// <summary>
        /// Get the maximum shipping instruction id by using job id
        /// </summary>
        /// <returns>Shipping instruction id</returns>
        [Fact]
        public async Task GetMaximumShippingInstructionId_Request_ReturnsShippingInstructionId()
        {
            // Arrange
            int jobId = 2094643;

            int shippingInstructionId = 4;

            this.shipmentRepository.Setup(x => x.GetMaximumShippingInstructionId(jobId)).Returns(Task.FromResult(shippingInstructionId));

            // Act
            int result = await this.shipmentService.GetMaximumShippingInstructionId(jobId);

            // Assert
            Assert.True(result == shippingInstructionId);
            this.shipmentRepository.Verify(x => x.GetMaximumShippingInstructionId(jobId), Times.Once);
        }
    }
}
