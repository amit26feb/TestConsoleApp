// <copyright file="JobsSnsNotifierTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Amazon.SimpleNotificationService.Model;
    using AWS.MessagingWrapper.Contracts;
    using JobService.Common.Constants;
    using JobService.Core.Services;
    using Moq;
    using Xunit;

    /// <summary>
    /// MTopssJobsNotifierTest Test Methods
    /// </summary>
    public class JobsSnsNotifierTest
    {
        private readonly Mock<IMessagePublisher> snsPublisher;

        public JobsSnsNotifierTest() => this.snsPublisher = new Mock<IMessagePublisher>();

        [Fact]
        public async Task SendMessageToSns_ValidRequest_ReturnSnsMessageId()
        {
            // Arrange
            var snsMessageId = "67890-2b9d-5488-9d28-45a5d2f59876";
            var snsArn = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsSaveToLynx";
            var recepient = SnsFilterRecipients.LynxJob;

            this.snsPublisher.Setup(x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()))
               .Returns(Task.FromResult(snsMessageId));

            // Act
            var mTopssJobNotifier = new JobsSnsNotifier(this.snsPublisher.Object);
            var result = await mTopssJobNotifier.SendMessageToSNS(snsMessageId, snsArn, recepient);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(snsMessageId, result);
            this.snsPublisher.Verify(x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
        }

        [Fact]
        public async Task SendMessageToSns_InValidRequest_ReturnEmptyMessageId()
        {
            // Arrange
            var snsmessageId = string.Empty;
            var snsArn = string.Empty;
            var recepient = SnsFilterRecipients.LynxJob;

            this.snsPublisher.Setup(x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()))
               .Returns(Task.FromResult(snsmessageId)).Verifiable();

            // Act
            var mTopssJobNotifier = new JobsSnsNotifier(this.snsPublisher.Object);
            var result = await mTopssJobNotifier.SendMessageToSNS(snsmessageId, snsArn, recepient);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(snsmessageId, result);
            this.snsPublisher.Verify(x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
        }

        [Fact]
        public async Task SendMessageToSns_ReceipientIsNull_ReturnsMessageId()
        {
            // Arrange
            string snsMessageId = "67890-2b9d-5488-9d28-45a5d2f59876";
            string snsArn = "arn:JobsSaveToLynx-Test";
            string recepient = null;

            this.snsPublisher.Setup(x => x.PublishToTopicAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()))
               .Returns(Task.FromResult(snsMessageId));

            // Act
            var mTopssJobNotifier = new JobsSnsNotifier(this.snsPublisher.Object);
            var result = await mTopssJobNotifier.SendMessageToSNS(snsMessageId, snsArn, recepient);

            // Assert
            Assert.Equal(snsMessageId, result);
            this.snsPublisher.Verify(x => x.PublishToTopicAsync(snsMessageId, snsArn, 3, null), Times.Once);
        }
    }
}
