// <copyright file="JobsUpdateHostedServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Amazon.SQS;
    using Amazon.SQS.Model;
    using AWS.MessagingWrapper.Contracts;
    using JobService.Core.Services;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// Provides the methods to verify the business logic in SQS queue
    /// </summary>
    public class JobsUpdateHostedServiceTest
    {
        private readonly Mock<ILogger<JobsUpdateHostedService>> logger;
        private readonly Mock<IMessageReceiver> messageReceiver;
        private readonly Mock<AmazonSQSClient> amazonSQSClient;
        private readonly Mock<IOptions<TSMTSettings>> appSettings;
        private readonly Mock<IJobsUpdateService> jobsUpdateService;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsUpdateHostedServiceTest"/> class.
        /// </summary>
        public JobsUpdateHostedServiceTest()
        {
            this.messageReceiver = new Mock<IMessageReceiver>();
            this.logger = new Mock<ILogger<JobsUpdateHostedService>>();
            this.appSettings = new Mock<IOptions<TSMTSettings>>();
            this.amazonSQSClient = new Mock<AmazonSQSClient>();
            this.jobsUpdateService = new Mock<IJobsUpdateService>();
        }

        /// <summary>
        /// Verify for getting message from SQS queue
        /// </summary>
        [Fact]
        public void ConcurrentProcess_Execute_Successfully()
        {
            // Arrange
            object obj = new object();
            IEnumerable<Message> messages = new List<Message>()
            {
                   new Message
                   {
                       MessageId = "008245c2-b535-52a3-9e4b-110a1b231615",
                       Body = "{Message : '0HLKN0ROA7EKL:00000002'}",
                   }
             };

            IEnumerable<Message> emptyMessages = null;
            TSMTSettings appSetting = new TSMTSettings() { SqsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob", MessageHidingTimeInMinutes = 2, MaxNoOfMessages = 2 };
            var appSettings = new Mock<IOptions<TSMTSettings>>();
            appSettings.Setup(ap => ap.Value).Returns(appSetting);

            this.messageReceiver.SetupSequence(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
              .Returns(Task.FromResult(messages)).Returns(Task.FromResult(emptyMessages));
            this.jobsUpdateService.Setup(x => x.ProcessJobsUpdateMessageAsync(It.IsAny<Message>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            var jobsUpdateHostedService = new JobsUpdateHostedService(this.logger.Object, appSettings.Object, this.messageReceiver.Object, this.amazonSQSClient.Object, this.jobsUpdateService.Object);

            // Act
            var result = Task.Run(() => jobsUpdateHostedService.ConcurrentProcess(obj));
            result.Wait();

            // Assert
            Assert.True(result.IsCompleted);
            this.jobsUpdateService.Verify(x => x.ProcessJobsUpdateMessageAsync(It.IsAny<Message>(), It.IsAny<string>()), Times.Once);
            this.messageReceiver.Verify(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.AtLeastOnce);
        }
    }
}
