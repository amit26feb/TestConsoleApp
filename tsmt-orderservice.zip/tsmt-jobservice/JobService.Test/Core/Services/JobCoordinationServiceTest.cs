// <copyright file="JobCoordinationServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using Amazon.SimpleNotificationService.Model;
    using AWS.MessagingWrapper.Contracts;
    using DynamoDBWrapper;
    using JobService.Configurations;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using Xunit;

    public class JobCoordinationServiceTest
    {
        private const int RetryAttemptCount = 3;
        private readonly Mock<IHttpContextAccessor> httpContextAccessorMock;
        private readonly Mock<IJobCoordinationRepository> jobCoordinationRepositoryMock;
        private readonly Mock<IMessagePublisher> messagePublisherMock;
        private readonly Mock<IOptions<JobServiceSettings>> settingsMock;
        private readonly Mock<ILogger<DynamoDBRepository>> loggerDynamoDBRepositoryMock;
        private readonly JobCoordinationService jobCoordinationService;
        private readonly Mock<IJobRepository> jobRepositoryMock;
        private readonly JobServiceSettings jobServiceSettings;
        private string userId = "asdabc";

        public JobCoordinationServiceTest()
        {
            this.httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            this.jobCoordinationRepositoryMock = new Mock<IJobCoordinationRepository>();
            this.messagePublisherMock = new Mock<IMessagePublisher>();
            this.settingsMock = new Mock<IOptions<JobServiceSettings>>();
            this.jobServiceSettings = new JobServiceSettings()
            {
                SnsServiceUrlForJobCoordination = "arn:asdf",
                SecretKeyJob = "asdf-ghjk",
                JobCoordinationRequestRecipient = "JobCoordinationFilter",
                DynamoJobCoordinationTableName = "JobCoordination",
                DynamoJobCoordinationKeyName = "Id",
                CoordinatedJobFilterRecipient = "CoordinatedJobFilter",
                DynamoCoordinatedJobHistoryTableName = "CoordinatedJobHistory",
                DynamoCoordinatedJobHistoryKeyName = "Id",
                JobCoordinationDocumentRecipient = "JobCoordinationDocumentFilter",
                DynamoJobCoordinationDocumentUpdateTableName = "JobCoordinationDocUpdate",
                DynamoJobCoordinationDocumentUpdateKeyName = "Id",
                DynamoCoordinatedJobDocumentUpdateTableName = "CoordinatedJobDocUpdate",
                DynamoCoordinatedJobDocumentUpdateKeyName = "Id",
                CoordinatedJobDocumentUpdateFilterRecipient = "CoordinatedJobDocFilter"
            };
            this.settingsMock.Setup(x => x.Value).Returns(this.jobServiceSettings);
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", this.userId)
            };
            this.httpContextAccessorMock.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.loggerDynamoDBRepositoryMock = new Mock<ILogger<DynamoDBRepository>>();
            this.jobRepositoryMock = new Mock<IJobRepository>();
            this.jobCoordinationService = new JobCoordinationService(this.loggerDynamoDBRepositoryMock.Object, this.jobCoordinationRepositoryMock.Object, this.settingsMock.Object, this.httpContextAccessorMock.Object, this.jobRepositoryMock.Object, this.messagePublisherMock.Object);
        }

        /// <summary>
        /// Save job coordination request - job coordination request saved
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task SaveJobCoordinationRequest_ValidInputJobCoordinationRequestSaved_ReturnsTrue()
        {
            // Arrange
            int drAddressId = 101;
            int jobId = 1234;
            int coordinationId = 1;
            JobCoordinationRequestViewModel jobCoordinationRequestViewModel = Helper.GetJobCoordinationRequestViewModel();
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>())).Returns(Task.FromResult(jobCoordinationRequestViewModel.MessageId));

            // Act
            var result = await this.jobCoordinationService.SaveJobCoordinationRequest(drAddressId, jobId, coordinationId);

            // Assert
            Assert.True(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobCoordinationRepositoryMock.Verify(x => x.SaveMessage(It.IsAny<JobCoordinationRequestViewModel>(), this.jobServiceSettings.DynamoJobCoordinationTableName, this.jobServiceSettings.DynamoJobCoordinationKeyName), Times.Once);
            this.messagePublisherMock.Verify(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Save job coordination request - job coordination request not saved
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task SaveJobCoordinationRequest_JobCoordinationRequestNotSaved_ReturnsFalse()
        {
            // Arrange
            int drAddressId = 11;
            int jobId = 124;
            int coordinationId = 13;
            JobCoordinationRequestViewModel jobCoordinationRequestViewModel = Helper.GetJobCoordinationRequestViewModel();
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "asdabc")
            };
            this.httpContextAccessorMock.Setup(x => x.HttpContext.User.Claims).Returns(claims);
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>())).Returns(Task.FromResult(string.Empty));

            // Act
            var result = await this.jobCoordinationService.SaveJobCoordinationRequest(drAddressId, jobId, coordinationId);

            // Assert
            Assert.False(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobCoordinationRepositoryMock.Verify(x => x.SaveMessage(It.IsAny<JobCoordinationRequestViewModel>(), this.jobServiceSettings.DynamoJobCoordinationTableName, this.jobServiceSettings.DynamoJobCoordinationKeyName), Times.Once);
            this.messagePublisherMock.Verify(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Save job coordination request - job coordination request saved and dr address id honored through http context
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task SaveJobCoordinationRequest_DrAddressIdHonoredThroughHttpContext_ReturnsTrue()
        {
            // Arrange
            int drAddressId = 101;
            int jobId = 1234;
            int coordinationId = 1;
            var drAddressIdFromHttpContext = new Dictionary<object, object>();
            drAddressIdFromHttpContext.Add("DR_ADDRESS_ID", drAddressId);
            this.httpContextAccessorMock.Setup(x => x.HttpContext.Items).Returns(drAddressIdFromHttpContext);
            JobCoordinationRequestViewModel jobCoordinationRequestViewModel = Helper.GetJobCoordinationRequestViewModel();
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>())).Returns(Task.FromResult(jobCoordinationRequestViewModel.MessageId));

            // Act
            var jobCoordinationService = new JobCoordinationService(this.loggerDynamoDBRepositoryMock.Object, this.jobCoordinationRepositoryMock.Object, this.settingsMock.Object, this.httpContextAccessorMock.Object, this.jobRepositoryMock.Object, this.messagePublisherMock.Object);
            var result = await jobCoordinationService.SaveJobCoordinationRequest(drAddressId, jobId, coordinationId);

            // Assert
            Assert.True(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobCoordinationRepositoryMock.Verify(x => x.SaveMessage(It.IsAny<JobCoordinationRequestViewModel>(), this.jobServiceSettings.DynamoJobCoordinationTableName, this.jobServiceSettings.DynamoJobCoordinationKeyName), Times.Once);
            this.messagePublisherMock.Verify(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.Items, Times.AtLeastOnce);
            this.jobRepositoryMock.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
            this.jobCoordinationRepositoryMock.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
        }

        /// <summary>
        /// Update job coordination request - job coordination request saved
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobCoordinationHistoryJobCoordinationStatus_ValidInput_ReturnsTrue()
        {
            // Arrange
            int coordinationId = 2;
            int submittedCoordinationId = 1;
            int jobId = 567;
            string coordinationStatus = "Recoordinated";
            this.jobRepositoryMock.Setup(x => x.GetSubmittedJobCoordinationId(jobId)).Returns(Task.FromResult(submittedCoordinationId));
            this.jobRepositoryMock.Setup(x => x.UpdateJobCoordinationStatus(submittedCoordinationId, coordinationStatus)).Returns(Task.FromResult(true));
            this.jobRepositoryMock.Setup(x => x.UpdateJobCoordinationHistory(coordinationId, this.userId)).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobCoordinationService.UpdateJobCoordinationHistory(coordinationId, jobId);

            // Assert
            Assert.True(result);
            this.jobRepositoryMock.Verify(x => x.GetSubmittedJobCoordinationId(jobId), Times.Once);
            this.jobRepositoryMock.Verify(x => x.UpdateJobCoordinationStatus(submittedCoordinationId, coordinationStatus), Times.Once);
            this.jobRepositoryMock.Verify(x => x.UpdateJobCoordinationHistory(coordinationId, this.userId), Times.Once);
        }

        /// <summary>
        /// Update job coordination request - job coordination request not saved
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobCoordinationHistory_InValidInput_ReturnsFalse()
        {
            // Arrange
            int coordinationId = 10000;
            int jobId = 5689;
            this.jobRepositoryMock.Setup(x => x.UpdateJobCoordinationHistory(coordinationId, this.userId)).Returns(Task.FromResult(false));

            // Act
            var result = await this.jobCoordinationService.UpdateJobCoordinationHistory(coordinationId, jobId);

            // Assert
            Assert.False(result);
            this.jobRepositoryMock.Verify(x => x.UpdateJobCoordinationHistory(coordinationId, this.userId), Times.Once);
        }

        /// <summary>
        /// Update job coordination request - job coordination request saved without submitted coordination request
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobCoordinationHistory_ValidInput_ReturnsTrue()
        {
            // Arrange
            int coordinationId = 2;
            int submittedCoordinationId = 0;
            int jobId = 987;
            string coordinationStatus = "Recoordinated";
            this.jobRepositoryMock.Setup(x => x.GetSubmittedJobCoordinationId(jobId)).Returns(Task.FromResult(submittedCoordinationId));
            this.jobRepositoryMock.Setup(x => x.UpdateJobCoordinationHistory(coordinationId, this.userId)).Returns(Task.FromResult(true));

            // Act
            var result = await this.jobCoordinationService.UpdateJobCoordinationHistory(coordinationId, jobId);

            // Assert
            Assert.True(result);
            this.jobRepositoryMock.Verify(x => x.GetSubmittedJobCoordinationId(jobId), Times.Once);
            this.jobRepositoryMock.Verify(x => x.UpdateJobCoordinationStatus(submittedCoordinationId, coordinationStatus), Times.Never);
            this.jobRepositoryMock.Verify(x => x.UpdateJobCoordinationHistory(coordinationId, this.userId), Times.Once);
        }

        /// <summary>
        /// Sends coordinated job history request - coordinated job history request sent
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task SendCoordinatedJobHistoryRequest_CoordinatedJobHistoryRequestSent_ReturnsTrue()
        {
            // Arrange
            int jobId = 1234;
            CoordinatedJobMessage coordinatedJobMessage = Helper.GetCoordinatedJobMessage();
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>())).Returns(Task.FromResult(coordinatedJobMessage.MessageId));

            // Act
            var result = await this.jobCoordinationService.SendCoordinatedJobHistoryRequest(jobId);

            // Assert
            Assert.True(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobCoordinationRepositoryMock.Verify(x => x.SaveMessage(It.IsAny<CoordinatedJobMessage>(), this.jobServiceSettings.DynamoCoordinatedJobHistoryTableName, this.jobServiceSettings.DynamoCoordinatedJobHistoryKeyName), Times.Once);
            this.messagePublisherMock.Verify(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Send coordinated job history request - coordinated job history request not sent
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task SendCoordinatedJobHistoryRequest_CoordinatedJobHistoryRequestNotSent_ReturnsFalse()
        {
            // Arrange
            int jobId = 134;
            CoordinatedJobMessage coordinatedJobMessage = Helper.GetCoordinatedJobMessage();
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>())).Returns(Task.FromResult(string.Empty));

            // Act
            var result = await this.jobCoordinationService.SendCoordinatedJobHistoryRequest(jobId);

            // Assert
            Assert.False(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobCoordinationRepositoryMock.Verify(x => x.SaveMessage(It.IsAny<CoordinatedJobMessage>(), this.jobServiceSettings.DynamoCoordinatedJobHistoryTableName, this.jobServiceSettings.DynamoCoordinatedJobHistoryKeyName), Times.Once);
            this.messagePublisherMock.Verify(x => x.PublishToTopicAsync(It.IsAny<string>(), this.jobServiceSettings.SnsServiceUrlForJobCoordination, RetryAttemptCount, It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Sends job coordination document update request - job coordination document update request sent
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task SendJobCoordinationDocumentUpdateRequest_JobCoordinationDocumentUpdateRequestSent_ReturnsTrue()
        {
            // Arrange
            int jobId = 1234;
            JobCoordinationDocumentMessage jobCoordinationDocumentMessage = Helper.GetJobCoordinationDocumentMessage();
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(
                                                    It.IsAny<string>(),
                                                    this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                                                    RetryAttemptCount,
                                                    It.IsAny<Dictionary<string, MessageAttributeValue>>()))
                                     .Returns(Task.FromResult(jobCoordinationDocumentMessage.MessageId));

            // Act
            var result = await this.jobCoordinationService.SendJobCoordinationDocumentUpdateRequest(jobCoordinationDocumentMessage.DocumentKey, jobId);

            // Assert
            Assert.True(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobCoordinationRepositoryMock.Verify(
                x => x.SaveMessage(
                It.IsAny<JobCoordinationDocumentMessage>(),
                this.jobServiceSettings.DynamoJobCoordinationDocumentUpdateTableName,
                this.jobServiceSettings.DynamoJobCoordinationDocumentUpdateKeyName), Times.Once);
            this.messagePublisherMock.Verify(
                x => x.PublishToTopicAsync(
                    It.IsAny<string>(),
                    this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                    RetryAttemptCount,
                    It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Sends job coordination document update request - job coordination document update request not sent
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task SendJobCoordinationDocumentUpdateRequest_JobCoordinationDocumentUpdateRequestNotSent_ReturnsFalse()
        {
            // Arrange
            int jobId = 134;
            JobCoordinationDocumentMessage jobCoordinationDocumentMessage = Helper.GetJobCoordinationDocumentMessage();
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(
                It.IsAny<string>(),
                this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                RetryAttemptCount,
                It.IsAny<Dictionary<string, MessageAttributeValue>>())).Returns(Task.FromResult(string.Empty));

            // Act
            var result = await this.jobCoordinationService.SendJobCoordinationDocumentUpdateRequest(jobCoordinationDocumentMessage.DocumentKey, jobId);

            // Assert
            Assert.False(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.httpContextAccessorMock.Verify(x => x.HttpContext.User.Claims, Times.Once);
            this.jobCoordinationRepositoryMock.Verify(
                x => x.SaveMessage(
                It.IsAny<JobCoordinationDocumentMessage>(),
                this.jobServiceSettings.DynamoJobCoordinationDocumentUpdateTableName,
                this.jobServiceSettings.DynamoJobCoordinationDocumentUpdateKeyName), Times.Once);
            this.messagePublisherMock.Verify(
                x => x.PublishToTopicAsync(
                    It.IsAny<string>(),
                    this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                    RetryAttemptCount,
                    It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Sends coordinated job document update request - coordinated job document update request sent
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task SendCoordinatedJobDocumentUpdateRequest_CoordinatedJobDocumentUpdateRequestSent_ReturnsTrue()
        {
            // Arrange
            int jobId = 12345;
            int drAddressId = 101;
            JobCoordinationDocumentViewModel jobCoordinationDocumentViewModel = Helper.GetJobCoordinationDocumentViewModel(12, "Jobs/123/test.txt", "Insertion");
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(
                                                    It.IsAny<string>(),
                                                    this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                                                    RetryAttemptCount,
                                                    It.IsAny<Dictionary<string, MessageAttributeValue>>()))
                                     .Returns(Task.FromResult("abcd-qwefd"));

            // Act
            var result = await this.jobCoordinationService.SendCoordinatedJobDocumentUpdateRequest(jobCoordinationDocumentViewModel, drAddressId, jobId);

            // Assert
            Assert.True(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.jobCoordinationRepositoryMock.Verify(
                x => x.SaveMessage(
                It.IsAny<CoordinatedJobDocumentMessage>(),
                this.jobServiceSettings.DynamoCoordinatedJobDocumentUpdateTableName,
                this.jobServiceSettings.DynamoCoordinatedJobDocumentUpdateKeyName), Times.Once);
            this.messagePublisherMock.Verify(
                x => x.PublishToTopicAsync(
                    It.IsAny<string>(),
                    this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                    RetryAttemptCount,
                    It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Sends coordinated job document update request - coordinated job document update request not sent
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task SendCoordinatedJobDocumentUpdateRequest_CoordinatedJobDocumentUpdateRequestNotSent_ReturnsFalse()
        {
            // Arrange
            int jobId = 123;
            int drAddressId = 12;
            JobCoordinationDocumentViewModel jobCoordinationDocumentViewModel = Helper.GetJobCoordinationDocumentViewModel(12, "Jobs/123/test.txt", "Deletion");
            this.jobRepositoryMock.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Now));
            this.messagePublisherMock.Setup(x => x.PublishToTopicAsync(
                It.IsAny<string>(),
                this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                RetryAttemptCount,
                It.IsAny<Dictionary<string, MessageAttributeValue>>())).Returns(Task.FromResult(string.Empty));

            // Act
            var result = await this.jobCoordinationService.SendCoordinatedJobDocumentUpdateRequest(jobCoordinationDocumentViewModel, drAddressId, jobId);

            // Assert
            Assert.False(result);
            this.jobRepositoryMock.Verify(x => x.GetDbDate(), Times.Once);
            this.jobCoordinationRepositoryMock.Verify(
                x => x.SaveMessage(
                It.IsAny<CoordinatedJobDocumentMessage>(),
                this.jobServiceSettings.DynamoCoordinatedJobDocumentUpdateTableName,
                this.jobServiceSettings.DynamoCoordinatedJobDocumentUpdateKeyName), Times.Once);
            this.messagePublisherMock.Verify(
                x => x.PublishToTopicAsync(
                    It.IsAny<string>(),
                    this.jobServiceSettings.SnsServiceUrlForJobCoordination,
                    RetryAttemptCount,
                    It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
            this.settingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }
    }
}
