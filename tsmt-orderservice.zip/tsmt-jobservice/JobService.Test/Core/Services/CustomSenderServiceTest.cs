// <copyright file="CustomSenderServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using JobService.Common.Constants;
    using JobService.Configurations.AutoMapperConfiguration;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Moq;
    using Xunit;

    /// <summary>
    /// Custom sender service test
    /// </summary>
    public class CustomSenderServiceTest
    {
        private readonly IMapper mapper;
        private readonly Mock<ICustomSenderRepository> customSenderRepository;
        private readonly CustomSenderService customSenderService;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomSenderServiceTest"/> class.
        /// </summary>
        public CustomSenderServiceTest()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.customSenderRepository = new Mock<ICustomSenderRepository>();
            this.customSenderService = new CustomSenderService(this.customSenderRepository.Object, this.mapper);
        }

        /// <summary>
        /// Test to retrieve custom senders using dr address id
        /// </summary>
        /// <returns>IEnumerable of custom sender view model</returns>
        [Fact]
        public async Task GetCustomSenders_HasData_ReturnsCustomSenders()
        {
            // Arrange
            int drAddressId = 256;
            IEnumerable<CustomSenderModel> customSenderList = Helper.GetCustomSenderModels(drAddressId);
            this.customSenderRepository.Setup(x => x.GetCustomSenders(It.IsAny<int>()))
                .Returns(Task.FromResult(customSenderList));

            // Act
            IEnumerable<CustomSenderViewModel> result = await this.customSenderService.GetCustomSenders(drAddressId);

            // Assert
            Assert.Equal(customSenderList.Count(), result.Count());
            Assert.True(this.CompareCustomSenderModels(customSenderList.First(), result.First()));
            this.customSenderRepository.Verify(x => x.GetCustomSenders(drAddressId), Times.Once);
        }

        /// <summary>
        /// Test to retrieve custom senders using dr address id with no records
        /// </summary>
        /// <returns>Empty IEnumerable</returns>
        [Fact]
        public async Task GetCustomSenders_HasNoData_ReturnsEmptyList()
        {
            // Arrange
            int drAddressId = 256;
            this.customSenderRepository.Setup(x => x.GetCustomSenders(It.IsAny<int>()))
                .Returns(Task.FromResult(Enumerable.Empty<CustomSenderModel>()));

            // Act
            IEnumerable<CustomSenderViewModel> result = await this.customSenderService.GetCustomSenders(drAddressId);

            // Assert
            Assert.Empty(result);
            this.customSenderRepository.Verify(x => x.GetCustomSenders(drAddressId), Times.Once);
        }

        /// <summary>
        /// Method to test Create Custom Sender inserted successfully
        /// </summary>
        /// <returns>empty string</returns>
        [Fact]
        public async Task CreateCustomSender_ValidCustomSenderDetail_InsertedSuccessfully()
        {
            // Arrange
            CustomSenderViewModel customSenderViewModel = Helper.GetCustomSenderViewModel();
            this.customSenderRepository.Setup(x => x.CreateCustomSender(It.IsAny<CustomSenderModel>())).Returns(Task.CompletedTask);

            // Act
            string errorMessage = await this.customSenderService.CreateCustomSender(customSenderViewModel);

            // Assert
            Assert.Empty(errorMessage);
            this.customSenderRepository.Verify(x => x.CreateCustomSender(It.IsAny<CustomSenderModel>()), Times.Once);
        }

        /// <summary>
        /// Method to test Create Custom Sender inserted unsuccessfully with duplicate
        /// </summary>
        /// <returns>Custom sender nick name error message</returns>
        [Fact]
        public async Task CreateCustomSender_HasDuplicate_ReturnsErrorMessage()
        {
            // Arrange
            CustomSenderViewModel customSenderViewModel = Helper.GetCustomSenderViewModel();
            long count = 1;
            this.customSenderRepository.Setup(x => x.GetCustomSenderNickNameCount(customSenderViewModel.JobDrAddressId, customSenderViewModel.CustomSenderNickName))
                .Returns(count);

            // Act
            string result = await this.customSenderService.CreateCustomSender(customSenderViewModel);

            // Assert
            Assert.Equal(result, customSenderViewModel.CustomSenderNickName + CommonHelper.CustomSenderNickNameExists);
            this.customSenderRepository.Verify(x => x.GetCustomSenderNickNameCount(customSenderViewModel.JobDrAddressId, customSenderViewModel.CustomSenderNickName), Times.Once);
            this.customSenderRepository.Verify(x => x.CreateCustomSender(It.IsAny<CustomSenderModel>()), Times.Never());
        }

        /// <summary>
        /// Test to retrieve custom sender detail using custom sender id
        /// </summary>
        /// <returns>Custom sender view model</returns>
        [Fact]
        public async Task GetCustomSenderById_HasData_ReturnsCustomSender()
        {
            // Arrange
            string customSenderId = "45LY";
            CustomSenderModel customSenderModel = Helper.GetCustomSenderModel(customSenderId);
            this.customSenderRepository.Setup(x => x.GetCustomSenderById(It.IsAny<string>()))
                .Returns(Task.FromResult(customSenderModel));

            // Act
            CustomSenderViewModel result = await this.customSenderService.GetCustomSenderById(customSenderId);

            // Assert
            Assert.True(this.CompareCustomSenderModels(customSenderModel, result));
            this.customSenderRepository.Verify(x => x.GetCustomSenderById(customSenderId), Times.Once);
        }

        /// <summary>
        /// Method to test Delete custom sender for a given custom sender id
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task DeleteCustomSender_DeletedSuccessfully_ReturnsTrue()
        {
            // Arrange
            string customSenderId = "f49fd5e5-ca4e-4a6d-b922-758f9510ca47";
            this.customSenderRepository.Setup(x => x.DeleteCustomSender(customSenderId)).Returns(Task.FromResult(true));

            // Act
            bool result = await this.customSenderService.DeleteCustomSender(customSenderId);

            // Assert
            Assert.True(result);
            this.customSenderRepository.Verify(x => x.DeleteCustomSender(customSenderId), Times.Once);
        }

        /// <summary>
        /// Method to test Update Custom Sender inserted successfully
        /// </summary>
        /// <returns>empty string</returns>
        [Fact]
        public async Task UpdateCustomSender_UpdatedSuccessfully_ReturnsEmptyString()
        {
            // Arrange
            string customSenderId = "xyz-12rt-fg568-jk78";
            CustomSenderViewModel customSenderViewModel = Helper.GetCustomSenderViewModel(customSenderId);
            this.customSenderRepository.Setup(x => x.UpdateCustomSender(It.IsAny<CustomSenderModel>())).Returns(Task.FromResult(true));

            // Act
            string errorMessage = await this.customSenderService.UpdateCustomSender(customSenderViewModel);

            // Assert
            Assert.Empty(errorMessage);
            this.customSenderRepository.Verify(x => x.UpdateCustomSender(It.IsAny<CustomSenderModel>()), Times.Once);
        }

        /// <summary>
        /// Method to test Update Custom Sender unsuccessful update
        /// </summary>
        /// <returns>Error message</returns>
        [Fact]
        public async Task UpdateCustomSender_UnsuccessfulUpdate_ReturnsErrorMessage()
        {
            // Arrange
            string customSenderId = "f2e-23pt-n5ew-tw56r";
            CustomSenderViewModel customSenderViewModel = Helper.GetCustomSenderViewModel(customSenderId);
            this.customSenderRepository.Setup(x => x.UpdateCustomSender(It.IsAny<CustomSenderModel>())).Returns(Task.FromResult(false));

            // Act
            string errorMessage = await this.customSenderService.UpdateCustomSender(customSenderViewModel);

            // Assert
            Assert.Equal(customSenderViewModel.SenderName + CommonHelper.CustomSenderNameExists, errorMessage);
            this.customSenderRepository.Verify(x => x.UpdateCustomSender(It.IsAny<CustomSenderModel>()), Times.Once);
        }

        /// <summary>
        ///  Verifies for true response if custom sender nick name already exists
        /// </summary>
        [Fact]
        public void CheckDuplicateCustomSenderNickName_ValidInput_ReturnsTrue()
        {
            // Arrange
            string customSenderNickName = "ccwmtu";
            int jobDrAddressId = 101;
            int count = 1;
            this.customSenderRepository.Setup(x => x.GetCustomSenderNickNameCount(It.IsAny<int>(), It.IsAny<string>()))
                .Returns(count);

            // Act
            var result = this.customSenderService.IsDuplicateCustomSenderNickNameExists(jobDrAddressId, customSenderNickName);

            // Assert
            Assert.True(result);
            this.customSenderRepository.Verify(x => x.GetCustomSenderNickNameCount(jobDrAddressId, customSenderNickName), Times.Once);
        }

        /// <summary>
        ///  Verifies for false response if the custom sender nick name does not exist already
        /// </summary>
        [Fact]
        public void CheckDuplicateCustomSenderNickName_ValidInput_ReturnsFalse()
        {
            // Arrange
            string customSenderNickName = "ccwmtu";
            int jobDrAddressId = 101;
            int count = 0;
            this.customSenderRepository.Setup(x => x.GetCustomSenderNickNameCount(It.IsAny<int>(), It.IsAny<string>()))
                .Returns(count);

            // Act
            var result = this.customSenderService.IsDuplicateCustomSenderNickNameExists(jobDrAddressId, customSenderNickName);

            // Assert
            Assert.False(result);
            this.customSenderRepository.Verify(x => x.GetCustomSenderNickNameCount(jobDrAddressId, customSenderNickName), Times.Once);
        }

        /// <summary>
        ///  Verifies for true response if sender name already exists
        /// </summary>
        [Fact]
        public void CheckDuplicateSenderName_SenderNameCountGreaterThanOne_ReturnsTrue()
        {
            // Arrange
            string senderName = "ccwmtu";
            int jobDrAddressId = 101;
            int count = 2;
            this.customSenderRepository.Setup(x => x.GetSenderNameCount(It.IsAny<int>(), It.IsAny<string>()))
                .Returns(count);

            // Act
            var result = this.customSenderService.DoesDuplicateSenderNameExist(jobDrAddressId, senderName);

            // Assert
            Assert.True(result);
            this.customSenderRepository.Verify(x => x.GetSenderNameCount(jobDrAddressId, senderName), Times.Once);
        }

        /// <summary>
        ///  Verifies for false response if the sender name does not exist already
        /// </summary>
        [Fact]
        public void CheckDuplicateSenderName_SenderNameCountEqualsToOne_ReturnsFalse()
        {
            // Arrange
            string senderName = "ccwmtu";
            int jobDrAddressId = 101;
            int count = 1;
            this.customSenderRepository.Setup(x => x.GetSenderNameCount(It.IsAny<int>(), It.IsAny<string>()))
                .Returns(count);

            // Act
            var result = this.customSenderService.DoesDuplicateSenderNameExist(jobDrAddressId, senderName);

            // Assert
            Assert.False(result);
            this.customSenderRepository.Verify(x => x.GetSenderNameCount(jobDrAddressId, senderName), Times.Once);
        }

        /// <summary>
        /// Function to check mapping of CustomSenderModel to CustomSenderViewModel
        /// </summary>
        /// <param name="customSenderModel">Custom sender model</param>
        /// <param name="customSenderViewModel">Custom sender view model</param>
        /// <returns>True if validated successfully else false</returns>
        private bool CompareCustomSenderModels(CustomSenderModel customSenderModel, CustomSenderViewModel customSenderViewModel) => customSenderModel.CustomSenderId == customSenderViewModel.CustomSenderId
                                                   && customSenderModel.CustomSenderNickName == customSenderViewModel.CustomSenderNickName
                                                   && customSenderModel.SenderName == customSenderViewModel.SenderName
                                                   && customSenderModel.Title == customSenderViewModel.Title
                                                   && customSenderModel.CellPhoneNumber == customSenderViewModel.CellPhoneNumber
                                                   && customSenderModel.EmailAddress == customSenderViewModel.EmailAddress
                                                   && customSenderModel.JobDrAddressId == customSenderViewModel.JobDrAddressId
                                                   && customSenderModel.OfficePhoneNumber == customSenderViewModel.OfficePhoneNumber
                                                   && customSenderModel.CustomSenderDrAddressId == customSenderViewModel.CustomSenderDrAddressId
                                                   && customSenderModel.CustomSenderSalesOfficeId == customSenderViewModel.CustomSenderSalesOfficeId
                                                   && customSenderModel.CreatedBy == customSenderViewModel.CreatedBy
                                                   && customSenderModel.CreatedDate == customSenderViewModel.CreatedDate
                                                   && customSenderModel.LastModifiedBy == customSenderViewModel.LastModifiedBy
                                                   && customSenderModel.LastModifiedDate == customSenderViewModel.LastModifiedDate
                                                   && customSenderModel.OfficeFaxNumber == customSenderViewModel.OfficeFaxNumber;
    }
}
