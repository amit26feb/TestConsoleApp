// <copyright file="JobsUpdateServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Amazon.DynamoDBv2.DocumentModel;
    using Amazon.SQS.Model;
    using AWS.MessagingWrapper.Contracts;
    using DynamoDBWrapper;
    using JobService.Core.Models;
    using JobService.Core.Repository;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// Provides the methods to save the jobs update request message to SQS Queue
    /// </summary>
    public class JobsUpdateServiceTest
    {
        private readonly Mock<ILogger<JobsUpdateService>> logger;
        private readonly Mock<IJobRepository> jobRepository;
        private readonly Mock<IOptions<TSMTSettings>> tsmtSettings;
        private readonly Mock<IJobsUpdateDynamoDBRepository> jobsUpdateDynamoDBRepository;
        private readonly Mock<IMessageReceiver> messageReceiver;
        private readonly Mock<IJobService> jobService;
        private readonly JobsUpdateService jobsUpdateService;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsUpdateServiceTest"/> class.
        /// </summary>
        public JobsUpdateServiceTest()
        {
            this.jobRepository = new Mock<IJobRepository>();
            this.logger = new Mock<ILogger<JobsUpdateService>>();
            this.tsmtSettings = new Mock<IOptions<TSMTSettings>>();
            this.jobsUpdateDynamoDBRepository = new Mock<IJobsUpdateDynamoDBRepository>();
            this.messageReceiver = new Mock<IMessageReceiver>();
            this.jobService = new Mock<IJobService>();
            this.jobsUpdateService = new JobsUpdateService(this.jobRepository.Object, this.logger.Object, this.jobsUpdateDynamoDBRepository.Object, this.messageReceiver.Object, this.jobService.Object);
        }

        /// <summary>
        /// Verifying the parallel process of sqs message for success
        /// </summary>
        /// <returns>A <see cref="Task"/> Representing the asynchronous unit test.</returns>
        [Fact]
        public async Task ProcessMessage_ValidInput_Success()
        {
            // Arrange
            string snsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob";
            var visRequest = new ChangeMessageVisibilityRequest
            {
                QueueUrl = It.IsAny<string>(),
                ReceiptHandle = "008245c2-b535-52a3-9e4b-110a1b231615",
                VisibilityTimeout = It.IsAny<int>()
            };
            Message message = new Message
            {
                MessageId = "008245c2-b535-52a3-9e4b-110a1b231615",
                Body = "{Message : '10042019/0HLKN0ROA7EKL:00000002'}",
                ReceiptHandle = visRequest.ReceiptHandle
            };
            JobsUpdateDynamoDBMessage jobsUpdateDynamoDBMessage = new JobsUpdateDynamoDBMessage()
            {
                MessageId = "0HLOS4DJOJV93:00000006",
                Status = "Pending",
                StatusUpdatedDateTime = "3/13/2019 7:39:15 AM",
                Message = "{\"DR_ADDRESS_ID\":78,\"LAST_UPDATE\":\"2019 - 03 - 13T08:32:19.5979268Z\",\"JOB_ID\":106274}"
            };

            Document document = jobsUpdateDynamoDBMessage.ToDocument();
            this.jobsUpdateDynamoDBRepository.Setup(x => x.GetMessage(It.IsAny<string>(), null)).Returns(Task.FromResult(jobsUpdateDynamoDBMessage));
            this.jobsUpdateDynamoDBRepository.Setup(x => x.UpdateJobsUpdateProcessStatus(jobsUpdateDynamoDBMessage)).Returns(Task.FromResult(document));
            this.jobRepository.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>())).Returns(Task.FromResult(true));
            this.messageReceiver.Setup(x => x.DeleteMessageAsync(It.IsAny<string>(), message.ReceiptHandle)).Returns(Task.FromResult(It.IsAny<string>()));
            TSMTSettings tsmtSettings = new TSMTSettings() { SecretKeyJob = "67dsf-2b9d-5488-9d28-45a5d2f59876" };
            this.tsmtSettings.Setup(ap => ap.Value).Returns(tsmtSettings);
            this.jobService.Setup(x => x.SendNotificationMessage(It.IsAny<BuildNotificationView>())).Returns(Task.FromResult(true));

            // Act
            await this.jobsUpdateService.ProcessJobsUpdateMessageAsync(message, snsServiceUrl);

            // Assert
            this.jobsUpdateDynamoDBRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Once);
            this.jobsUpdateDynamoDBRepository.Verify(x => x.UpdateJobsUpdateProcessStatus(jobsUpdateDynamoDBMessage), Times.AtLeastOnce);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>()), Times.Once);
            this.jobService.Verify(x => x.SendNotificationMessage(It.IsAny<BuildNotificationView>()), Times.Once);
        }

        [Fact]
        public async Task ProcessMessage_SendingNotificationMessageToSQSFailed_LogsInformationAndTaskCompletedSuccessfully()
        {
            // Arrange
            string snsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob";
            var visRequest = new ChangeMessageVisibilityRequest
            {
                QueueUrl = It.IsAny<string>(),
                ReceiptHandle = "008245c2-b535-52a3-9e4b-110a1b231615",
                VisibilityTimeout = It.IsAny<int>()
            };
            Message message = new Message
            {
                MessageId = "008245c2-b535-52a3-9e4b-110a1b231615",
                Body = "{Message : '10042019/0HLKN0ROA7EKL:00000002'}",
                ReceiptHandle = visRequest.ReceiptHandle
            };
            JobsUpdateDynamoDBMessage jobsUpdateDynamoDBMessage = new JobsUpdateDynamoDBMessage()
            {
                MessageId = "0HLOS4DJOJV93:00000006",
                Status = "Pending",
                StatusUpdatedDateTime = "3/13/2019 7:39:15 AM",
                Message = "{\"DR_ADDRESS_ID\":78,\"LAST_UPDATE\":\"2019 - 03 - 13T08:32:19.5979268Z\",\"JOB_ID\":106274}"
            };

            Document document = jobsUpdateDynamoDBMessage.ToDocument();
            this.jobsUpdateDynamoDBRepository.Setup(x => x.GetMessage(It.IsAny<string>(), null)).Returns(Task.FromResult(jobsUpdateDynamoDBMessage));
            this.jobsUpdateDynamoDBRepository.Setup(x => x.UpdateJobsUpdateProcessStatus(jobsUpdateDynamoDBMessage)).Returns(Task.FromResult(document));
            this.jobRepository.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>())).Returns(Task.FromResult(true));
            this.messageReceiver.Setup(x => x.DeleteMessageAsync(It.IsAny<string>(), message.ReceiptHandle)).Returns(Task.FromResult(It.IsAny<string>()));
            TSMTSettings tsmtSettings = new TSMTSettings() { SecretKeyJob = "67dsf-2b9d-5488-9d28-45a5d2f59876" };
            this.tsmtSettings.Setup(ap => ap.Value).Returns(tsmtSettings);
            this.jobService.Setup(x => x.SendNotificationMessage(It.IsAny<BuildNotificationView>())).Returns(Task.FromResult(false));

            // Act
            await this.jobsUpdateService.ProcessJobsUpdateMessageAsync(message, snsServiceUrl);

            // Assert
            this.jobsUpdateDynamoDBRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Once);
            this.jobsUpdateDynamoDBRepository.Verify(x => x.UpdateJobsUpdateProcessStatus(jobsUpdateDynamoDBMessage), Times.AtLeastOnce);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>()), Times.Once);
            this.jobService.Verify(x => x.SendNotificationMessage(It.IsAny<BuildNotificationView>()), Times.Once);
        }

        /// <summary>
        /// Verifying the parallel process by empty product pricing cache message
        /// </summary>
        /// <returns>A <see cref="Task"/> Representing the asynchronous unit test.</returns>
        [Fact]
        public async Task ProcessMessage_EmptyDynamoDBMessage_Failure()
        {
            // Arrange
            string snsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob";
            var visRequest = new ChangeMessageVisibilityRequest
            {
                QueueUrl = It.IsAny<string>(),
                ReceiptHandle = "008245c2-b535-52a3-9e4b-110a1b231615",
                VisibilityTimeout = It.IsAny<int>()
            };
            Message message = new Message
            {
                MessageId = "008245c2-b535-52a3-9e4b-110a1b231615",
                Body = "{Message : '10042019/0HLKN0ROA7EKL:00000002'}",
                ReceiptHandle = visRequest.ReceiptHandle
            };

            JobsUpdateDynamoDBMessage jobsUpdateDynamoDBMessage = new JobsUpdateDynamoDBMessage();
            Document document = jobsUpdateDynamoDBMessage.ToDocument();
            this.jobsUpdateDynamoDBRepository.Setup(x => x.GetMessage(It.IsAny<string>(), null)).Returns(Task.FromResult(jobsUpdateDynamoDBMessage));
            this.jobsUpdateDynamoDBRepository.Setup(x => x.UpdateJobsUpdateProcessStatus(jobsUpdateDynamoDBMessage)).Returns(Task.FromResult(document));
            this.messageReceiver.Setup(x => x.DeleteMessageAsync(It.IsAny<string>(), message.ReceiptHandle)).Returns(Task.FromResult(It.IsAny<string>()));
            this.jobService.Setup(x => x.SendNotificationMessage(It.IsAny<BuildNotificationView>())).Returns(Task.FromResult(false));

            TSMTSettings tsmtSettings = new TSMTSettings();
            this.tsmtSettings.Setup(ap => ap.Value).Returns(tsmtSettings);

            // Act
            await this.jobsUpdateService.ProcessJobsUpdateMessageAsync(message, snsServiceUrl);

            // Assert
            this.jobsUpdateDynamoDBRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Once);
            this.jobsUpdateDynamoDBRepository.Verify(x => x.UpdateJobsUpdateProcessStatus(jobsUpdateDynamoDBMessage), Times.AtLeastOnce);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>()), Times.Never);
            this.jobService.Verify(x => x.SendNotificationMessage(It.IsAny<BuildNotificationView>()), Times.Never);
        }

        /// <summary>
        /// Verifying the parallel process by empty sqs message
        /// </summary>
        /// <returns>A <see cref="Task"/> Representing the asynchronous unit test.</returns>
        [Fact]
        public async Task ProcessMessage_EmptySqsMessage_Failure()
        {
            // Arrange
            string snsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob";
            Message message = null;

            // Act
            await this.jobsUpdateService.ProcessJobsUpdateMessageAsync(message, snsServiceUrl);

            // Assert
            this.jobsUpdateDynamoDBRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Never);
            this.jobsUpdateDynamoDBRepository.Verify(x => x.UpdateJobsUpdateProcessStatus(It.IsAny<JobsUpdateDynamoDBMessage>()), Times.Never);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>()), Times.Never);
        }

        /// <summary>
        /// Verifying the parallel process by empty sns service url
        /// </summary>
        /// <returns>A <see cref="Task"/> Representing the asynchronous unit test.</returns>
        [Fact]
        public async Task ProcessMessage_EmptySnsURL_Failure()
        {
            // Arrange
            string snsServiceUrl = string.Empty;
            Message message = new Message();

            // Act
            await this.jobsUpdateService.ProcessJobsUpdateMessageAsync(message, snsServiceUrl);

            // Assert
            this.jobsUpdateDynamoDBRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Never);
            this.jobsUpdateDynamoDBRepository.Verify(x => x.UpdateJobsUpdateProcessStatus(It.IsAny<JobsUpdateDynamoDBMessage>()), Times.Never);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>()), Times.Never);
        }

        /// <summary>
        /// Verifying the parallel process by empty sqs message body
        /// </summary>
        /// <returns>A <see cref="Task"/> Representing the asynchronous unit test.</returns>
        [Fact]
        public async Task ProcessMessage_EmptySqsMessageBody_Failure()
        {
            // Arrange
            string snsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob";
            Message message = new Message();

            // Act
            await this.jobsUpdateService.ProcessJobsUpdateMessageAsync(message, snsServiceUrl);

            // Assert
            this.jobsUpdateDynamoDBRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Never);
            this.jobsUpdateDynamoDBRepository.Verify(x => x.UpdateJobsUpdateProcessStatus(It.IsAny<JobsUpdateDynamoDBMessage>()), Times.Never);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>()), Times.Never);
        }

        /// <summary>
        /// Verifying the parallel process by empty sqs message id
        /// </summary>
        /// <returns>A <see cref="Task"/> Representing the asynchronous unit test.</returns>
        [Fact]
        public async Task ProcessMessage_EmptySqsMessageId_Failure()
        {
            // Arrange
            string snsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-LynxJob";
            Message message = new Message
            {
                Body = "{Message : ''}"
            };

            // Act
            await this.jobsUpdateService.ProcessJobsUpdateMessageAsync(message, snsServiceUrl);

            // Assert
            this.jobsUpdateDynamoDBRepository.Verify(x => x.GetMessage(It.IsAny<string>(), It.IsAny<List<string>>()), Times.Never);
            this.jobsUpdateDynamoDBRepository.Verify(x => x.UpdateJobsUpdateProcessStatus(It.IsAny<JobsUpdateDynamoDBMessage>()), Times.Never);
            this.messageReceiver.Verify(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            this.jobRepository.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>(), It.IsAny<DateTime>()), Times.Never);
        }
    }
}
