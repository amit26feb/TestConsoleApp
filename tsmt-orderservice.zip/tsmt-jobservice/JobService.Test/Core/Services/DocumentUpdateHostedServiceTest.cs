// <copyright file="DocumentUpdateHostedServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Amazon.SQS;
    using Amazon.SQS.Model;
    using AWS.MessagingWrapper.Contracts;
    using JobService.Core.Models;
    using JobService.Core.Services;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using Newtonsoft.Json;
    using TSMT.Settings;
    using Xunit;

    public class DocumentUpdateHostedServiceTest
    {
        private readonly Mock<ILogger<DocumentUpdateHostedService>> logger;
        private readonly Mock<IMessageReceiver> messageReceiver;
        private readonly Mock<AmazonSQSClient> amazonSQSClient;
        private readonly Mock<IOptions<TSMTSettings>> appSettings;
        private readonly Mock<IJobDocumentService> jobDocumentService;

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentUpdateHostedServiceTest"/> class.
        /// </summary>
        public DocumentUpdateHostedServiceTest()
        {
            this.messageReceiver = new Mock<IMessageReceiver>();
            this.logger = new Mock<ILogger<DocumentUpdateHostedService>>();
            this.appSettings = new Mock<IOptions<TSMTSettings>>();
            this.amazonSQSClient = new Mock<AmazonSQSClient>();
            this.jobDocumentService = new Mock<IJobDocumentService>();
        }

        /// <summary>
        /// Verify for getting message from SQS queue
        /// </summary>
        [Fact]
        public void ProcessSelectionSummaryReportCompletionMessage_Execute_Successfully()
        {
            // Arrange
            object obj = new object();
            dynamic body = new System.Dynamic.ExpandoObject();
            body.Message = new List<JobDocument>()
            {
                new JobDocument()
                {
                    JOB_ID = 5647,
                    DR_ADDRESS_ID = 122,
                    UPLOADED_USER_ID = "ccfbok"
                }
            };
            IEnumerable<Message> messages = new List<Message>()
            {
                   new Message
                   {
                       MessageId = "008245c2-b535-52a3-9e4b-110a1b231615",
                       Body = JsonConvert.SerializeObject(body),
                   }
             };

            IEnumerable<Message> emptyMessages = null;
            TSMTSettings appSetting = new TSMTSettings() { SqsServiceUrlForDocumentUpdate = "arn:aws:sns:us-east-1:611998158124:TSMT-Job", MessageHidingTimeInMinutes = 2, MaxNoOfMessages = 2 };
            var appSettings = new Mock<IOptions<TSMTSettings>>();
            appSettings.Setup(ap => ap.Value).Returns(appSetting);

            this.messageReceiver.SetupSequence(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
              .Returns(Task.FromResult(messages)).Returns(Task.FromResult(emptyMessages));
            this.jobDocumentService.Setup(x => x.ProcessSelectionSummaryReportCompletionMessage(It.IsAny<Message>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            var documentUpdateHostedService = new DocumentUpdateHostedService(this.logger.Object, appSettings.Object, this.messageReceiver.Object, this.amazonSQSClient.Object, this.jobDocumentService.Object);

            // Act
            var result = Task.Run(() => documentUpdateHostedService.ConcurrentProcessForSelectionSummaryReportMessage(obj));
            result.Wait();

            // Assert
            Assert.True(result.IsCompleted);
            this.jobDocumentService.Verify(x => x.ProcessSelectionSummaryReportCompletionMessage(It.IsAny<Message>(), It.IsAny<string>()), Times.Once);
            this.messageReceiver.Verify(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.AtLeastOnce);
        }
    }
}
