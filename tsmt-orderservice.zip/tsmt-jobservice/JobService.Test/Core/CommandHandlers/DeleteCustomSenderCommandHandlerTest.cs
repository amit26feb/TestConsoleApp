// <copyright file="DeleteCustomSenderCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Delete custom sender command handler test
    /// </summary>
    public class DeleteCustomSenderCommandHandlerTest
    {
        private readonly Mock<ILogger<DeleteCustomSenderCommand>> loggerMock;
        private readonly Mock<ICustomSenderService> customSenderServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteCustomSenderCommandHandlerTest"/> class.
        /// </summary>
        public DeleteCustomSenderCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<DeleteCustomSenderCommand>>();
            this.customSenderServiceMock = new Mock<ICustomSenderService>();
        }

        [Fact]
        public async Task Handle_DeleteCustomSenderSuccess_ReturnsTrue()
        {
            // Arrange
            string customSenderId = "f49fd5e5-ca4e-4a6d-b922-758f9510ca47";
            this.customSenderServiceMock.Setup(x => x.DeleteCustomSender(customSenderId))
                .Returns(Task.FromResult(true));
            var fakeDeleteCustomSenderCommand = new DeleteCustomSenderCommand(customSenderId);

            // Act
            var handler = new DeleteCustomSenderCommandHandler(this.loggerMock.Object, this.customSenderServiceMock.Object);
            var cltToken = default(CancellationToken);
            bool result = await handler.Handle(fakeDeleteCustomSenderCommand, cltToken);

            // Assert
            Assert.True(result);
            this.customSenderServiceMock.Verify(x => x.DeleteCustomSender(customSenderId), Times.Once);
        }
    }
}
