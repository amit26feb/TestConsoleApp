// <copyright file="UpdateJobOfficeAndPeopleCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobOfficeAndPeopleCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobOfficeAndPeopleCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobOfficeAndPeopleCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobOfficeAndPeopleCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation of job office and people
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateOfficeandPeople_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobOfficeandPeople = new JobOfficeAndPeopleView()
            {
                JobId = 100
            };

            var updateJobCommand = new UpdateJobOfficeAndPeopleCommand(jobOfficeandPeople);

            bool isUpdated = true;

            this.jobServiceMock.Setup(x => x.UpdateJobOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()))
                .Returns(Task.FromResult(isUpdated));

            // Act
            var handler = new UpdateJobOfficeAndPeopleCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of job office and people
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateOfficeandPeople_InvalidInput_RetrunsFalse()
        {
            // Arrange
            var jobOfficeandPeople = new JobOfficeAndPeopleView()
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobOfficeAndPeopleCommand(jobOfficeandPeople);

            this.jobServiceMock.Setup(x => x.UpdateJobOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()))
                .Returns(Task.FromResult(false));

            // Act
            // Act
            var handler = new UpdateJobOfficeAndPeopleCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()), Times.Once);
        }
    }
}
