// <copyright file="UpdateCoordinationJobCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateCoordinationJobCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateCoordinationJobCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateCoordinationJobCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateCoordinationJobCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Update Coordination job - Success
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCoordinationJobCommandHandler_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 60324,
                DrAddressId = 101,
                CoordinationId = 100,
                SubmissionNotes = "Hi Team",
                Documents = new List<JobCoordinationDocumentViewModel>()
                {
                    new JobCoordinationDocumentViewModel()
                    {
                        DocumentKey = "Jobs/78/27440/new 8.txt"
                    }
                },
            };
            var updateCoordinationJobCommand = new UpdateCoordinationJobCommand(jobCoordination);

            this.jobServiceMock.Setup(x => x.UpdateCoordinationJob(It.IsAny<JobCoordinationViewModel>()))
                .Returns(Task.FromResult(true));
            var handler = new UpdateCoordinationJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);

            // Act
            var result = await handler.Handle(updateCoordinationJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateCoordinationJob(It.IsAny<JobCoordinationViewModel>()), Times.Once);
        }

        /// <summary>
        /// Update coordination job - Failure
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateCoordinationJobCommandHandler_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobCoordination = new JobCoordinationViewModel()
            {
                JobId = 0
            };

            var updateCoordinationJobCommand = new UpdateCoordinationJobCommand(jobCoordination);

            this.jobServiceMock.Setup(x => x.UpdateCoordinationJob(It.IsAny<JobCoordinationViewModel>()))
                .Returns(Task.FromResult(false));
            var handler = new UpdateCoordinationJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);

            // Act
            var result = await handler.Handle(updateCoordinationJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateCoordinationJob(It.IsAny<JobCoordinationViewModel>()), Times.Once);
        }
    }
}
