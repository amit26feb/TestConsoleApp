// <copyright file="SendNotificationCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Common.Constants;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class SendNotificationCommandHandlerTest
    {
        private readonly Mock<IJobService> jobServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="SendNotificationCommandHandlerTest"/> class.
        /// </summary>
        public SendNotificationCommandHandlerTest()
        {
            this.jobServiceMock = new Mock<IJobService>();
        }

        [Fact]
        public async Task Handle_SendNotificationMessageSuccessfully_ReturnsTrue()
        {
            // Arrange
            int jobId = 57668;
            SendNotificationCommand insertNotificationCommand = new SendNotificationCommand(jobId, NotificationType.Address);
            var cltToken = default(System.Threading.CancellationToken);
            this.jobServiceMock.Setup(x => x.SendNotificationMessage(It.IsAny<BuildNotificationView>())).Returns(Task.FromResult(true));
            SendNotificationCommandHandler handler = new SendNotificationCommandHandler(this.jobServiceMock.Object);

            // Act
            bool result = await handler.Handle(insertNotificationCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.SendNotificationMessage(It.Is<BuildNotificationView>(x=>x.JobId == 57668 && x.NotificationType == NotificationType.Address)), Times.Once());
        }
    }
}
