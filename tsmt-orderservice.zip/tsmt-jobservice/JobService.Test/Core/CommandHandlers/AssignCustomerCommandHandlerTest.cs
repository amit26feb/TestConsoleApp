// <copyright file="AssignCustomerCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class AssignCustomerCommandHandlerTest
    {
        private readonly Mock<ILogger<AssignCustomerCommand>> loggerMock;
        private readonly Mock<ISalesCustomerService> salesCustomerServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="AssignCustomerCommandHandlerTest"/> class.
        /// </summary>
        public AssignCustomerCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<AssignCustomerCommand>>();
            this.salesCustomerServiceMock = new Mock<ISalesCustomerService>();
        }

        /// <summary>
        /// Test successful Assign Customer
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_AssignCustomer_Success()
        {
            // Arrange
            var jobRoleAsn = new JobRoleAsnView
            {
                JobRoleAsnId = 1,
                JobId = 4004,
                JobRoleTypeId = 1,
                CustAcctNbr = "3042336",
                SalesCustomerName = "North Quincy High School",
                HostUpdateInd = string.Empty,
                InsertDate = DateTime.Now,
                BidderInd = string.Empty,
                WinningBidderInd = string.Empty
            };

            var fakeCommand = new AssignCustomerCommand(jobRoleAsn);

            int isAssigned = 1;

            this.salesCustomerServiceMock.Setup(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>()))
                .Returns(Task.FromResult(isAssigned)).Verifiable();

            // Act
            var handler = new AssignCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeCommand, cltToken);

            // Assert
            Assert.Equal(isAssigned, result);
            this.salesCustomerServiceMock.Verify(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>()), Times.Once);
        }

        /// <summary>
        /// Test unsuccessful assigning a customer of job for invalid jobid
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_AssignCustomer_Invalid_Input()
        {
            // Arrange
            var jobRoleAsn = new JobRoleAsnView
            {
                JobRoleAsnId = 0
            };

            var fakeCommand = new AssignCustomerCommand(jobRoleAsn);

            int isAssigned = 1;

            this.salesCustomerServiceMock.Setup(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>()))
                .Returns(Task.FromResult(isAssigned)).Verifiable();

            // Act
            var handler = new AssignCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeCommand, cltToken);

            // Assert
            Assert.Equal(isAssigned, result);
            this.salesCustomerServiceMock.Verify(x => x.AssignCustomer(It.IsAny<JobRoleAsnView>()), Times.Once);
        }
    }
}
