// <copyright file="LockJobCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class LockJobCommandHandlerTest
    {
        private readonly Mock<ILogger<LockJobCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public LockJobCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<LockJobCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successfull locking of job for valid input
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task Handle_LockJob_Success()
        {
            // Arrange
            JobLock lockRequest = new JobLock
            {
                JobId = 123456,
                UserId = "abcde"
            };

            LockJobCommand fakeLockJobCommand = new LockJobCommand(lockRequest);

            string validResponse = lockRequest.UserId;

            this.jobServiceMock.Setup(x => x.LockJob(It.IsAny<JobLock>()))
                .Returns(Task.FromResult(validResponse)).Verifiable();

            // Act
            LockJobCommandHandler handler = new LockJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            System.Threading.CancellationToken token = default(System.Threading.CancellationToken);
            string result = await handler.Handle(fakeLockJobCommand, token);

            // Assert
            Assert.Equal(validResponse, result);
            this.jobServiceMock.Verify(x => x.LockJob(It.IsAny<JobLock>()), Times.Once);
        }

        /// <summary>
        /// Tests failure of locking the job for invalid userid
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task Handle_LockJob_InvalidUserId()
        {
            // Arrange
            string invalidUserId = "lmnop";
            JobLock lockRequest = new JobLock
            {
                JobId = 123456,
                UserId = "abcde"
            };

            LockJobCommand fakeLockJobCommand = new LockJobCommand(lockRequest);

            this.jobServiceMock.Setup(x => x.LockJob(It.IsAny<JobLock>()))
                .Returns(Task.FromResult(invalidUserId)).Verifiable();

            // Act
            LockJobCommandHandler handler = new LockJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            System.Threading.CancellationToken token = default(System.Threading.CancellationToken);
            string result = await handler.Handle(fakeLockJobCommand, token);

            // Assert
            Assert.NotEqual(lockRequest.UserId, result);
            this.jobServiceMock.Verify(x => x.LockJob(It.IsAny<JobLock>()), Times.Once);
        }

        /// <summary>
        /// Test method for lock failure (not locked)
        /// </summary>
        /// <returns>Assertion</returns>
        [Fact]
        public async Task Lock_Failure()
        {
            // Arrange
            string invalidUserId = string.Empty;
            JobLock lockRequest = new JobLock
            {
                JobId = 123456,
                UserId = "abcde"
            };

            LockJobCommand fakeLockJobCommand = new LockJobCommand(lockRequest);

            this.jobServiceMock.Setup(x => x.LockJob(It.IsAny<JobLock>()))
                .Returns(Task.FromResult(invalidUserId));

            // Act
            LockJobCommandHandler handler = new LockJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            System.Threading.CancellationToken token = default(System.Threading.CancellationToken);
            string result = await handler.Handle(fakeLockJobCommand, token);

            // Assert
            Assert.NotEqual(lockRequest.UserId, result);
            this.jobServiceMock.Verify();
        }
    }
}
