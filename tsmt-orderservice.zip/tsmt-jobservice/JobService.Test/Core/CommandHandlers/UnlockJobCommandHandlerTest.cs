// <copyright file="UnlockJobCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UnlockJobCommandHandlerTest
    {
        private readonly Mock<ILogger<UnLockJobCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UnlockJobCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UnLockJobCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// CommandHandler
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_ExecutesService_ReturnsString()
        {
            // Arrange
            var jobList = new UnLockJobView()
            {
                JobId = 100,
            };

            var fakeUnlockJobCommand = new UnLockJobCommand(jobList);

            this.jobServiceMock.Setup(x => x.UnLockJob(It.IsAny<UnLockJobView>()))
                .Returns(Task.FromResult(string.Empty));

            // Act
            var handler = new UnLockJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeUnlockJobCommand, cltToken);

            // Assert
            Assert.IsType<string>(result);
            Assert.Equal(string.Empty, result);
            this.jobServiceMock.Verify(x => x.UnLockJob(It.IsAny<UnLockJobView>()), Times.Once);
        }
    }
}
