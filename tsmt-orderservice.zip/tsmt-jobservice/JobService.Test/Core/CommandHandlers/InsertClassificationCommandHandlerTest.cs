// <copyright file="InsertClassificationCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class InsertClassificationCommandHandlerTest
    {
        private readonly Mock<ILogger<InsertClassificationCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public InsertClassificationCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<InsertClassificationCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful insertion of classification details
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task InsertClassification_ValidInput_ReturnsTrue()
        {
            // Arrange
            IEnumerable<JobClassificationView> jobClassifications = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                JobId = 178456,
                DrAddressId = 94,
                }
            };
            int jobId = 178456;
            var insertJobCommand = new InsertClassificationCommand(jobClassifications, jobId);

            this.jobServiceMock.Setup(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new InsertClassificationCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(insertJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful insertion of classification details for invalid id
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task InsertClassification_InvalidInput_ReturnsFalse()
        {
            // Arrange
            IEnumerable<JobClassificationView> jobClassifications = new List<JobClassificationView>()
            {
                new JobClassificationView()
                {
                JobId = 0,
                DrAddressId = 0,
                }
            };
            int jobId = 0;
            var insertJobCommand = new InsertClassificationCommand(jobClassifications, jobId);

            this.jobServiceMock.Setup(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            //// Act
            var handler = new InsertClassificationCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(insertJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.InsertClassification(It.IsAny<IEnumerable<JobClassificationView>>(), It.IsAny<int>()), Times.Once);
        }
    }
}
