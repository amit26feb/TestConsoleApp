// <copyright file="UpdateJobDatesCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobDatesCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobDatesCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobDatesCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobDatesCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation of date
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobDates_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobDate = new JobDatesView()
            {
                JobId = 100,
                BidDate = DateTime.Now,
                SubmittalDateApproved = DateTime.Now,
                DateCreated = DateTime.Now,
                ReqProjectCompletionDate = DateTime.Now,
                LastUpdate = DateTime.Now,
                StartUpDate = DateTime.Now
            };

            var updateJobCommand = new UpdateJobDatesCommand(jobDate);

            this.jobServiceMock.Setup(x => x.UpdateJobDates(It.IsAny<JobDatesView>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UpdateJobDatesCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobDates(It.IsAny<JobDatesView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of date for invalid jobid
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobDates_InvalidInput_RetrunsFalse()
        {
            // Arrange
            var jobDate = new JobDatesView
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobDatesCommand(jobDate);

            this.jobServiceMock.Setup(x => x.UpdateJobDates(It.IsAny<JobDatesView>()))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new UpdateJobDatesCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobDates(It.IsAny<JobDatesView>()), Times.Once);
        }
    }
}
