// <copyright file="UpdateJobModifiedDateCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobModifiedDateCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobModifiedDateCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobModifiedDateCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobModifiedDateCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation of date
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobModifiedDate_ValidInput_ReturnsTrue()
        {
            // Arrange
            var updateJobCommand = new UpdateJobModifiedDateCommand(It.IsAny<int>());
            this.jobServiceMock.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>()))
                .Returns(Task.FromResult(true));
            var handler = new UpdateJobModifiedDateCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);

            // Act
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of date for invalid jobid
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobDates_InvalidInput_RetrunsFalse()
        {
            // Arrange
            var updateJobCommand = new UpdateJobModifiedDateCommand(It.IsAny<int>());
            this.jobServiceMock.Setup(x => x.UpdateJobModifiedDate(It.IsAny<int>()))
                .Returns(Task.FromResult(false));
            var handler = new UpdateJobModifiedDateCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);

            // Act
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobModifiedDate(It.IsAny<int>()), Times.Once);
        }
    }
}
