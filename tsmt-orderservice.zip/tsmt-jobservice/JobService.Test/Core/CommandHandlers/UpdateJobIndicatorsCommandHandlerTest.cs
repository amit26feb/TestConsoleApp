// <copyright file="UpdateJobIndicatorsCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobIndicatorsCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobIndicatorsCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobIndicatorsCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobIndicatorsCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation indicator details
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobIndicator_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobIndicator = new JobIndicatorView()
            {
                JobId = 100,
                JobReportId = 100,
                DrAddressId = 100,
                AcousticsInd = "Y",
                LlwtInd = "Y",
                NationalAcctInd = "Y",
                HieffInd = "Y",
                ServiceContractInd = "Y",
                PactInd = "Y",
                PenaltyJobInd = "Y",
                LowTempAirInd = "Y",
                StackedInd = "Y",
                TargetJobInd = "Y",
                IcsInd = "Y"
            };

            var updateJobCommand = new UpdateJobIndicatorsCommand(jobIndicator);

            this.jobServiceMock.Setup(x => x.UpdateJobIndicators(It.IsAny<JobIndicatorView>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UpdateJobIndicatorsCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobIndicators(It.IsAny<JobIndicatorView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of indicator details for invalid jobid
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobIndicator_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobIndicator = new JobIndicatorView()
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobIndicatorsCommand(jobIndicator);

            this.jobServiceMock.Setup(x => x.UpdateJobIndicators(It.IsAny<JobIndicatorView>()))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new UpdateJobIndicatorsCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobIndicators(It.IsAny<JobIndicatorView>()), Times.Once);
        }
    }
}
