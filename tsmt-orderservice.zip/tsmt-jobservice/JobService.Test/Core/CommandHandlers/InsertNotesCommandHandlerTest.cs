// <copyright file="InsertNotesCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class InsertNotesCommandHandlerTest
    {
        private readonly Mock<ILogger<InsertNotesCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public InsertNotesCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<InsertNotesCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests notes are successfully inserted for valid input
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task InsertNotes_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobNote = new JobNotesView()
            {
                JobId = 59297,
                NoteString = "xyz",
                DrAddressId = 34
            };

            var insertJobCommand = new InsertNotesCommand(jobNote);

            this.jobServiceMock.Setup(x => x.InsertNotes(jobNote))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new InsertNotesCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(insertJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.InsertNotes(jobNote), Times.Once);
        }

        /// <summary>
        /// Tests notes are not inserted for invalid input
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task InsertNotes_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobNote = new JobNotesView
            {
                JobId = 0
            };

            var insertJobCommand = new InsertNotesCommand(jobNote);

            this.jobServiceMock.Setup(x => x.InsertNotes(jobNote))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new InsertNotesCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(insertJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.InsertNotes(jobNote), Times.Once);
        }
    }
}
