// <copyright file="UploadJobDocumentCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace JobService.Test.Core.CommandHandlers
{
    using System.IO;
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UploadJobDocumentCommandHandlerTest
    {
        private readonly Mock<ILogger<UploadJobDocumentCommand>> loggerMock;
        private readonly Mock<IJobDocumentService> jobDocumentServiceMock;

        public UploadJobDocumentCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UploadJobDocumentCommand>>();
            this.jobDocumentServiceMock = new Mock<IJobDocumentService>();
        }

        /// <summary>
        /// Tests successful upload of job document in jobdocument table
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UploadJobDocument_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobDocument = new JobDocumentView()
            {
                JobId = 100
            };
            Stream documentStream = new MemoryStream();
            DocumentFolderViewModel documentFolderViewModel = Helper.GetDocumentFolderViewModel();

            var uploadJobCommand = new UploadJobDocumentCommand(jobDocument, documentStream, documentFolderViewModel);

            this.jobDocumentServiceMock.Setup(x => x.UploadJobDocument(It.IsAny<JobDocumentView>(), It.IsAny<Stream>(), It.IsAny<DocumentFolderViewModel>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UploadJobDocumentCommandHandler(this.loggerMock.Object, this.jobDocumentServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(uploadJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobDocumentServiceMock.Verify(x => x.UploadJobDocument(It.IsAny<JobDocumentView>(), It.IsAny<Stream>(), documentFolderViewModel), Times.Once);
            documentStream.Dispose();
        }

        /// <summary>
        /// Tests successful upload of job document with having document key and document version in job document table
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UploadJobDocument_ValidInputWithDocumentKeyAndDocumentVersion_ReturnsTrue()
        {
            // Arrange
            JobDocumentView jobDocument = new JobDocumentView()
            {
                JobId = 100,
                DocumentKey = "generated-files/324/453/123",
                DocumentVersion = "versionJiggy"
            };
            Stream documentStream = new MemoryStream();
            DocumentFolderViewModel documentFolderViewModel = Helper.GetDocumentFolderViewModel();

            UploadJobDocumentCommand uploadJobCommand = new UploadJobDocumentCommand(jobDocument, documentStream, documentFolderViewModel);

            this.jobDocumentServiceMock.Setup(x => x.UploadDocumentFromDocumentPackageFileUploaded(It.IsAny<JobDocumentView>()))
                .Returns(Task.FromResult(true));

            // Act
            UploadJobDocumentCommandHandler handler = new UploadJobDocumentCommandHandler(this.loggerMock.Object, this.jobDocumentServiceMock.Object);
            CancellationToken cltToken = default(CancellationToken);
            bool result = await handler.Handle(uploadJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobDocumentServiceMock.Verify(x => x.UploadDocumentFromDocumentPackageFileUploaded(It.IsAny<JobDocumentView>()), Times.Once);
            documentStream.Dispose();
        }
    }
}
