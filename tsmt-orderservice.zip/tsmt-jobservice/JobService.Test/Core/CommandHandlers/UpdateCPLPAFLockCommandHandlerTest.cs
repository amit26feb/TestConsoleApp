// <copyright file="UpdateCplpafLockCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using AutoFixture;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateCplpafLockCommandHandlerTest
    {
        private readonly UpdateCplpafLockCommandHandler commandHandlerUnderTest;
        private readonly Mock<ILogger<UpdateCplpafLockCommandHandler>> mockLogger;
        private readonly Mock<IJobService> mockJobService;

        public UpdateCplpafLockCommandHandlerTest()
        {
            this.mockLogger = new Mock<ILogger<UpdateCplpafLockCommandHandler>>();
            this.mockJobService = new Mock<IJobService>();
            this.commandHandlerUnderTest = new UpdateCplpafLockCommandHandler(this.mockJobService.Object);
        }

        /// <summary>
        /// Tests if the handler calls through to the service
        /// </summary>
        /// <returns>A Task</returns>
        [Fact]
        public async Task Handle_CallsThroughToTheService()
        {
            // Setup
            var lockModel = new CplpafLock(20067, true);
            var command = new UpdateCplpafLockCommand(lockModel);
            var serviceRowsWereModified = true;

            this.mockJobService.Setup(x => x.UpdateCplpafLock(lockModel))
               .Returns(Task.FromResult(serviceRowsWereModified));

            // Act
            var handlerRowsWereModified = await this.commandHandlerUnderTest.Handle(command, default(System.Threading.CancellationToken));

            // Assert
            Assert.Equal(serviceRowsWereModified, handlerRowsWereModified);
            this.mockJobService.Verify(x => x.UpdateCplpafLock(lockModel), Times.Once);
        }
    }
}
