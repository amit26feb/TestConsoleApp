// <copyright file="CreateCrmJobCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class CreateCrmJobCommandHandlerTest
    {
        private readonly Mock<ILogger<CreateCrmJobCommand>> loggerMock;
        private readonly Mock<ICrmJobService> crmJobServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCrmJobCommandHandlerTest"/> class.
        /// </summary>
        public CreateCrmJobCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<CreateCrmJobCommand>>();
            this.crmJobServiceMock = new Mock<ICrmJobService>();
        }

        [Fact]
        public async Task Handle_HasCrmJobDetails_ReturnsJobId()
        {
            // Arrange
            int jobId = 10;
            CrmJobViewModel crmJob = Helper.GetCrmJobViewModel();
            CreateCrmJobCommand crmJobCreateCommand = new CreateCrmJobCommand(crmJob);

            this.crmJobServiceMock.Setup(x => x.CreateCrmJob(It.IsAny<CrmJobViewModel>()))
                .Returns(Task.FromResult(jobId));
            CreateCrmJobCommandHandler handler = new CreateCrmJobCommandHandler(this.loggerMock.Object, this.crmJobServiceMock.Object);
            CancellationToken cltToken = default(CancellationToken);

            // Act
            int result = await handler.Handle(crmJobCreateCommand, cltToken);

            // Assert
            Assert.Equal(jobId, result);
            this.crmJobServiceMock.Verify(x => x.CreateCrmJob(crmJob), Times.Once);
        }
    }
}
