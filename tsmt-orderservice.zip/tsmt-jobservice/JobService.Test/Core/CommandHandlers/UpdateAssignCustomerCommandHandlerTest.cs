// <copyright file="UpdateAssignCustomerCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;
    using AutoFixture;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateAssignCustomerCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateAssignCustomerCommand>> loggerMock;
        private readonly Mock<ISalesCustomerService> salesCustomerService;

        public UpdateAssignCustomerCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateAssignCustomerCommand>>();
            this.salesCustomerService = new Mock<ISalesCustomerService>();
        }

        [Fact]
        public async Task Handle_UpdateAssignCustomer_Success()
        {
            // Setup
            var fixture = new Fixture();
            var jobRoleAsnView = fixture.Create<JobRoleAsnView>();
            var fakeUpdateAssignCustomerCommand = new UpdateAssignCustomerCommand(jobRoleAsnView);
            bool updateStatus = true;
            this.salesCustomerService.Setup(x => x.UpdateAssignCustomer(It.IsAny<JobRoleAsnView>()))
               .Returns(Task.FromResult(updateStatus));

            // Act
            var handler = new UpdateAssignCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerService.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeUpdateAssignCustomerCommand, cltToken);

            // Assert
            Assert.Equal(updateStatus, result);
            this.salesCustomerService.Verify(x => x.UpdateAssignCustomer(It.IsAny<JobRoleAsnView>()), Times.Once);
        }

        [Fact]
        public async Task Handle_UpdateAssignCustomer_Failure()
        {
            // Setup
            var fixture = new Fixture();
            var jobRoleAsnView = fixture.Create<JobRoleAsnView>();
            var fakeUpdateAssignCustomerCommand = new UpdateAssignCustomerCommand(jobRoleAsnView);
            bool updateStatus = false;
            this.salesCustomerService.Setup(x => x.UpdateAssignCustomer(It.IsAny<JobRoleAsnView>()))
               .Returns(Task.FromResult(updateStatus));

            // Act
            var handler = new UpdateAssignCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerService.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeUpdateAssignCustomerCommand, cltToken);

            // Assert
            Assert.Equal(updateStatus, result);
            this.salesCustomerService.Verify(x => x.UpdateAssignCustomer(It.IsAny<JobRoleAsnView>()), Times.Once);
        }
    }
}
