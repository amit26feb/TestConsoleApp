// <copyright file="UpdateJobReportOfficeAndPeopleCommandTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobReportOfficeAndPeopleCommandTest
    {
        private readonly Mock<ILogger<UpdateJobReportOfficeAndPeopleCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobReportOfficeAndPeopleCommandTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobReportOfficeAndPeopleCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation of office and people details
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobReportOfficeandPeople_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobView = new JobOfficeAndPeopleView()
            {
                JobId = 100
            };

            var updateJobCommand = new UpdateJobReportOfficeAndPeopleCommand(jobView);

            this.jobServiceMock.Setup(x => x.UpdateJobReportOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UpdateJobReportOfficeAndPeopleCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobReportOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of office and people details for invalid jobId
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobReportOfficeandPeople_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobView = new JobOfficeAndPeopleView()
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobReportOfficeAndPeopleCommand(jobView);

            this.jobServiceMock.Setup(x => x.UpdateJobReportOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new UpdateJobReportOfficeAndPeopleCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobReportOfficeAndPeople(It.IsAny<JobOfficeAndPeopleView>()), Times.Once);
        }
    }
}
