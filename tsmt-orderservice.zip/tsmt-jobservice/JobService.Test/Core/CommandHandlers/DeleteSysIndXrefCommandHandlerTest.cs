// <copyright file="DeleteSysIndXrefCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Tests both valid and invalid parameters in deleting earthwise system informations
    /// </summary>
    public class DeleteSysIndXrefCommandHandlerTest
    {
        private readonly Mock<ILogger<DeleteSysIndXrefCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteSysIndXrefCommandHandlerTest"/> class.
        /// </summary>
        public DeleteSysIndXrefCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<DeleteSysIndXrefCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful deletion of classification details
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task HandleSuccess()
        {
            // Arrange
            int jobId = 100;

            var fakeDeleteJobSysIndXrefCommand = new DeleteSysIndXrefCommand(jobId);

            int? deletedStatus = 1;

            this.jobServiceMock.Setup(x => x.DeleteJobSysIndXref(It.IsAny<int>()))
                .Returns(Task.FromResult(deletedStatus)).Verifiable();

            // Act
            var handler = new DeleteSysIndXrefCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeDeleteJobSysIndXrefCommand, cltToken);

            //// Assert
            Assert.Equal(deletedStatus, result);
            this.jobServiceMock.Verify(x => x.DeleteJobSysIndXref(It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful deletion of classification details
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task HandleInvalidId()
        {
            // Arrange
            int jobId = 0;

            var fakeDeleteJobSysIndXrefCommand = new DeleteSysIndXrefCommand(jobId);

            int? deletedStatus = 0;

            this.jobServiceMock.Setup(x => x.DeleteJobSysIndXref(It.IsAny<int>()))
                .Returns(Task.FromResult(deletedStatus));

            // Act
            var handler = new DeleteSysIndXrefCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeDeleteJobSysIndXrefCommand, cltToken);

            //// Assert
            Assert.Equal(deletedStatus, result);
            this.jobServiceMock.Verify(x => x.DeleteJobSysIndXref(It.IsAny<int>()), Times.Once);
        }
    }
}
