// <copyright file="UpdateJobGeneralCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobGeneralCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobGeneralCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobGeneralCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobGeneralCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation of general details
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobGeneral_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobGeneral = new JobGeneralView()
            {
                JobId = 100
            };

            var updateJobCommand = new UpdateJobGeneralCommand(jobGeneral);

            this.jobServiceMock.Setup(x => x.UpdateJobGeneral(It.IsAny<JobGeneralView>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UpdateJobGeneralCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobGeneral(It.IsAny<JobGeneralView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of general section details for invalid jobid
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobGeneral_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobGeneral = new JobGeneralView()
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobGeneralCommand(jobGeneral);

            this.jobServiceMock.Setup(x => x.UpdateJobGeneral(It.IsAny<JobGeneralView>()))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new UpdateJobGeneralCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobGeneral(It.IsAny<JobGeneralView>()), Times.Once);
        }
    }
}
