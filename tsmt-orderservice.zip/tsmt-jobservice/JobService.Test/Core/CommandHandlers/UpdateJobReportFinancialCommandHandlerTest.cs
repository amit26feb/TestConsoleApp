// <copyright file="UpdateJobReportFinancialCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobReportFinancialCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobReportFinancialCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobReportFinancialCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobReportFinancialCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation of job financial
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobReportFinancial_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobFinancial = new JobFinancialView()
            {
                JobId = 100
            };

            var updateJobCommand = new UpdateJobReportFinancialCommand(jobFinancial);

            this.jobServiceMock.Setup(x => x.UpdateJobFinancial(It.IsAny<JobFinancialView>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UpdateJobReportFinancialCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobFinancial(It.IsAny<JobFinancialView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of job financial
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobReportFinancial_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobFinancial = new JobFinancialView()
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobReportFinancialCommand(jobFinancial);

            this.jobServiceMock.Setup(x => x.UpdateJobFinancial(It.IsAny<JobFinancialView>()))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new UpdateJobReportFinancialCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobFinancial(It.IsAny<JobFinancialView>()), Times.Once);
        }
    }
}
