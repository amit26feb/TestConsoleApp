// <copyright file="UpdateCustomerCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;
    using AutoFixture;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateCustomerCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateCustomerCommand>> loggerMock;
        private readonly Mock<ISalesCustomerService> salesCustomerService;

        public UpdateCustomerCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateCustomerCommand>>();
            this.salesCustomerService = new Mock<ISalesCustomerService>();
        }

        [Fact]
        public async Task Handle_UpdateCustomer_Success()
        {
            // Setup
            var fixture = new Fixture();
            var customerList = fixture.Create<SalesCustomerCreateView>();
            var fakeUpdateCustomerCommand = new UpdateCustomerCommand(customerList);
            var updateStatus = 1;
            this.salesCustomerService.Setup(x => x.UpdateCustomer(It.IsAny<SalesCustomerCreateView>()))
               .Returns(Task.FromResult(updateStatus)).Verifiable();

            // Act
            var handler = new UpdateCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerService.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeUpdateCustomerCommand, cltToken);

            // Assert
            Assert.Equal(updateStatus, result);
            this.salesCustomerService.Verify(x => x.UpdateCustomer(It.IsAny<SalesCustomerCreateView>()), Times.Once);
        }

        [Fact]
        public async Task Handle_UpdateCustomer_Failure()
        {
            // Setup
            var fixture = new Fixture();
            var customerList = fixture.Create<SalesCustomerCreateView>();
            var fakeUpdateCustomerCommand = new UpdateCustomerCommand(customerList);
            var updateStatus = 0;
            this.salesCustomerService.Setup(x => x.UpdateCustomer(It.IsAny<SalesCustomerCreateView>()))
               .Returns(Task.FromResult(updateStatus)).Verifiable();

            // Act
            var handler = new UpdateCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerService.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeUpdateCustomerCommand, cltToken);

            // Assert
            Assert.Equal(updateStatus, result);
            this.salesCustomerService.Verify(x => x.UpdateCustomer(It.IsAny<SalesCustomerCreateView>()), Times.Once);
        }
    }
}
