// <copyright file="CreateCustomerCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class CreateCustomerCommandHandlerTest
    {
        private readonly Mock<ILogger<CreateCustomerCommand>> loggerMock;
        private readonly Mock<ISalesCustomerService> salesCustomerServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCustomerCommandHandlerTest"/> class.
        /// </summary>
        public CreateCustomerCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<CreateCustomerCommand>>();
            this.salesCustomerServiceMock = new Mock<ISalesCustomerService>();
        }

        /// <summary>
        /// Test successful Create a Customer
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_CreateCustomer_Success()
        {
            // Arrange
            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655"
                },
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Zack",
                LastName = "Henson",
                PhoneNbr = "8839899655"
                },
            };
            var createCustomer = new SalesCustomerCreateView
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "2239899655",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                SalesCustomerContactView = contactList
            };

            var fakeCommand = new CreateCustomerCommand(createCustomer);

            int salesCustId = 10;

            this.salesCustomerServiceMock.Setup(x => x.CreateCustomer(It.IsAny<SalesCustomerCreateView>()))
                .Returns(Task.FromResult(salesCustId)).Verifiable();

            // Act
            var handler = new CreateCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeCommand, cltToken);

            // Assert
            Assert.Equal(salesCustId, result);
            this.salesCustomerServiceMock.Verify();
        }

        /// <summary>
        /// Test unsuccessful create a customer
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_CreateCustomer_Invalid_SalesCustId()
        {
            // Arrange
            List<SalesCustomerContactView> contactList = new List<SalesCustomerContactView>
            {
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Jack",
                LastName = "Dill",
                PhoneNbr = "2239899655"
                },
                new global::JobService.Core.ViewModels.SalesCustomerContactView()
                {
                CustomerContactId = 0,
                SalesCustId = 0,
                FirstName = "Zack",
                LastName = "Henson",
                PhoneNbr = "8839899655"
                },
            };
            var createCustomer = new SalesCustomerCreateView
            {
                SalesCustId = 0,
                CustChannelId = "COMMSALE",
                CustomerName = "ALL BIDDERS",
                SalesOfficeId = 125,
                JobRoleType = 1,
                CommCode = "R72",
                AccountNumber = "3042336",
                AddressLine1 = "221 Johnson Blvd. ",
                AddressLine2 = "4105 Inwood Dr",
                State = "WI",
                ZipPlus = string.Empty,
                Country = "USA",
                PhoneNumber = "2239899655",
                FaxNumber = string.Empty,
                ParentCustId = 0,
                ZipCode = string.Empty,
                Province = string.Empty,
                NonUSPostalCode = string.Empty,
                City = string.Empty,
                UsedForOrderEntryInd = "Y",
                FipsCode = string.Empty,
                StatusFlag = "C",
                LastEcSyncChangeId = 0,
                SalesCustomerContactView = contactList
            };

            var fakeCommand = new CreateCustomerCommand(createCustomer);

            int salesCustId = 0;

            this.salesCustomerServiceMock.Setup(x => x.CreateCustomer(It.IsAny<SalesCustomerCreateView>()))
                .Returns(Task.FromResult(salesCustId)).Verifiable();

            // Act
            var handler = new CreateCustomerCommandHandler(this.loggerMock.Object, this.salesCustomerServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeCommand, cltToken);

            // Assert
            Assert.Equal(salesCustId, result);
            this.salesCustomerServiceMock.Verify();
        }
    }
}
