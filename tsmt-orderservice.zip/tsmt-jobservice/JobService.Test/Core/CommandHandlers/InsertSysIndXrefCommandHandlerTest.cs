// <copyright file="InsertSysIndXrefCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class InsertSysIndXrefCommandHandlerTest
    {
        private readonly Mock<ILogger<InsertSysIndXrefCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public InsertSysIndXrefCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<InsertSysIndXrefCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests Earthwisesystem details are successfully inserted for valid input
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task InsertSysIndXref_ValidInput_ReturnsTrue()
        {
            // Arrange
            IEnumerable<JobSysIndXrefView> jobSysIndXrefs = new List<JobSysIndXrefView>()
            {
                new JobSysIndXrefView()
                {
                JobId = 178456,
                DrAddressId = 94,
                }
            };
            int jobId = 178456;
            var insertSysIndXrefCommand = new InsertSysIndXrefCommand(jobSysIndXrefs, jobId);

            this.jobServiceMock.Setup(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new InsertSysIndXrefCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(insertSysIndXrefCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// Tests Earthwisesystem details are failed to insert for invalid input
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task InsertSysIndXref_InvalidInput_ReturnsFalse()
        {
            // Arrange
            IEnumerable<JobSysIndXrefView> jobSysIndXrefs = new List<JobSysIndXrefView>()
            {
                new JobSysIndXrefView()
                {
                JobId = 0,
                DrAddressId = 0,
                }
            };
            int jobId = 0;

            var insertSysIndXrefCommand = new InsertSysIndXrefCommand(jobSysIndXrefs, jobId);

            this.jobServiceMock.Setup(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()))
                .Returns(Task.FromResult(false));

            //// Act
            var handler = new InsertSysIndXrefCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(insertSysIndXrefCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.InsertJobSysIndXref(It.IsAny<IEnumerable<JobSysIndXrefView>>(), It.IsAny<int>()), Times.Once);
        }
    }
}
