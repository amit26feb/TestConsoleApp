// <copyright file="UpdateJobAddressCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobAddressCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobAddressCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobAddressCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobAddressCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful updation of job addresss
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobAddress_ValidInput_ReturnsTrue()
        {
            // Arrange
            var jobAddress = new JobAddressView()
            {
                JobId = 100
            };

            var updateJobCommand = new UpdateJobAddressCommand(jobAddress);

            this.jobServiceMock.Setup(x => x.UpdateJobAddress(It.IsAny<JobAddressView>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UpdateJobAddressCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobAddress(It.IsAny<JobAddressView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of address for invalid jobid
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobAddress_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobAddress = new JobAddressView
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobAddressCommand(jobAddress);

            this.jobServiceMock.Setup(x => x.UpdateJobAddress(It.IsAny<JobAddressView>()))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new UpdateJobAddressCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobAddress(It.IsAny<JobAddressView>()), Times.Once);
        }
    }
}
