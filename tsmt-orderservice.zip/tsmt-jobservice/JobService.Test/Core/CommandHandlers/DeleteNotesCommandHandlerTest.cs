// <copyright file="DeleteNotesCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class DeleteNotesCommandHandlerTest
    {
        private readonly Mock<ILogger<DeleteNotesCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public DeleteNotesCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<DeleteNotesCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful deletion of notes details
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_DeleteNotes_Success()
        {
            // Arrange
            var noteView = new JobNotesView()
            {
                JobId = 100,
                NoteString = "xyz",
                DrAddressId = 94
            };

            var fakeDeleteJobCommand = new DeleteNotesCommand(noteView);

            int? deletedStatus = 1;

            this.jobServiceMock.Setup(x => x.DeleteNotes(It.IsAny<JobNotesView>()))
                .Returns(Task.FromResult(deletedStatus)).Verifiable();

            // Act
            var handler = new DeleteNotesCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeDeleteJobCommand, cltToken);

            // Assert
            Assert.Equal(deletedStatus, result);
            this.jobServiceMock.Verify(x => x.DeleteNotes(It.IsAny<JobNotesView>()), Times.Once);
        }

        /// <summary>
        /// Unsuccessful deletion of notes details for invalid jobid
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task Handle_DeleteNotes_InvalidJobId()
        {
            // Arrange
            var jobNotes = new JobNotesView
            {
                JobId = 0
            };

            var fakeDeleteJobCommand = new DeleteNotesCommand(jobNotes);

            int? deletedStatus = 0;

            this.jobServiceMock.Setup(x => x.DeleteNotes(It.IsAny<JobNotesView>()))
                .Returns(Task.FromResult(deletedStatus)).Verifiable();

           // Act
            var handler = new DeleteNotesCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeDeleteJobCommand, cltToken);

            // Assert
            Assert.Equal(deletedStatus, result);
            this.jobServiceMock.Verify(x => x.DeleteNotes(It.IsAny<JobNotesView>()), Times.Once);
        }
    }
}
