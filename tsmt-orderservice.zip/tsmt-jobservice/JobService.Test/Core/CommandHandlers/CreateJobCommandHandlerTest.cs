// <copyright file="CreateJobCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System;
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class CreateJobCommandHandlerTest
    {
        private readonly Mock<ILogger<CreateJobCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateJobCommandHandlerTest"/> class.
        /// </summary>
        public CreateJobCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<CreateJobCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful creation of job
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_CreateJob_Success()
        {
            // Arrange
            var jobDetails = new JobCreateView
            {
                JobId = 178456,
                DrAddressId = 94,
                JobName = "Cytec GP2 Replace Coil",
                LocationOffice = 100,
                DateCreated = DateTime.Now,
                CommCode = "D23",
                CustChannelId = "COMMSALE",
                Status = "L",
                State = "SC",
                CheckedIn = "y",
                LastUpdate = DateTime.Now,
                CplpafLocked = 1,
                SalesOfficeId = 119,
                CjWho = string.Empty,
                HqtrJobId = 0,
                WatcomJobId = 0,
                Province = string.Empty,
                NonUsPostalCode = string.Empty,
                PriceAuthId = 0,
                CjDate = DateTime.Now,
                CjTime = string.Empty,
                BidDate = DateTime.Now,
                LostToCompetitor = string.Empty,
                PricingSpaNbr = string.Empty,
                ReadOnlyPassword = string.Empty,
                ReadWritePassword = string.Empty,
                StreetAddress1 = string.Empty,
                StreetAddress2 = string.Empty,
                ZipCode = string.Empty,
                ZipPlus = string.Empty,
                UserId = "CCPLF",
                JobSource = string.Empty,
                OriginatingDrAddress = 0,
                Country = string.Empty,
                CjSubmitDate = DateTime.Now,
                DomesticInternationlInd = string.Empty,
                StandaloneInd = string.Empty,
                JobPath = string.Empty,
                StatusChangeDate = DateTime.Now,
                HostUserId = string.Empty,
                PriceProtectionPeriod = 0,
                InsertDate = DateTime.Now,
                JobContact = "CCFBD",
                Foe2CreatedOrdersInd = "y",
                TcsJobInd = string.Empty,
                CoordinatedYesNoInd = 0,
                CrmOpportunityId = string.Empty,
                IncludeCjperfInd = 0,
                JobNameAddOn = string.Empty,
                CrmSalesRepId = string.Empty
            };

            var fakeJobCreateCommand = new CreateJobCommand(jobDetails);

            int returnedJobId = 10;

            this.jobServiceMock.Setup(x => x.CreateJob(It.IsAny<JobCreateView>()))
                .Returns(Task.FromResult(returnedJobId)).Verifiable();

            // Act
            var handler = new CreateJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeJobCreateCommand, cltToken);

            // Assert
            Assert.Equal(returnedJobId, result);
            this.jobServiceMock.Verify(x => x.CreateJob(It.IsAny<JobCreateView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful creation of job for invalid jobid
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_CreateJob_Invalid_JobId()
        {
            // Arrange
            var jobDetails = new JobCreateView
            {
                JobId = 0
            };

            var fakecCreateJobCommand = new CreateJobCommand(jobDetails);

            int returnedJobId = 0;

            this.jobServiceMock.Setup(x => x.CreateJob(It.IsAny<JobCreateView>()))
                .Returns(Task.FromResult(returnedJobId)).Verifiable();

            // Act
            var handler = new CreateJobCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakecCreateJobCommand, cltToken);

            // Assert
            Assert.Equal(returnedJobId, result);
            this.jobServiceMock.Verify(x => x.CreateJob(It.IsAny<JobCreateView>()), Times.Once);
        }
    }
}
