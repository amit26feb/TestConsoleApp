// <copyright file="UpdateFavoriteCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using Moq;
    using Xunit;

    public class UpdateFavoriteCommandHandlerTest
    {
        private readonly Mock<IFavoriteService> favoriteServiceMock;
        private readonly UpdateFavoriteCommandHandler updateFavoriteCommandHandler;
        private readonly CancellationToken cancellationToken = default;

        public UpdateFavoriteCommandHandlerTest()
        {
            this.favoriteServiceMock = new Mock<IFavoriteService>();
            this.updateFavoriteCommandHandler = new UpdateFavoriteCommandHandler(this.favoriteServiceMock.Object);
        }

        /// <summary>
        /// Test to update favorite - success
        /// </summary>
        /// <returns>Empty string</returns>
        [Fact]
        public async Task Handle_UpdateFavoriteSuccess_ReturnsEmptyString()
        {
            // Arrange
            int jobId = 12345;
            UpdateFavoriteCommand updateFavoriteCommand = new UpdateFavoriteCommand(jobId);
            this.favoriteServiceMock.Setup(x => x.UpdateFavorite(jobId)).Returns(Task.FromResult(string.Empty));

            // Act
            string result = await this.updateFavoriteCommandHandler.Handle(updateFavoriteCommand, this.cancellationToken);

            // Assert
            Assert.Equal(result, string.Empty);
            this.favoriteServiceMock.Verify(x => x.UpdateFavorite(jobId), Times.Once);
        }

        /// <summary>
        /// Test to update favorite - Failure
        /// </summary>
        /// <returns>Error message</returns>
        [Fact]
        public async Task Handle_UpdateFavoriteUnsuccessful_ReturnsErrorMessage()
        {
            // Arrange
            int jobId = 60101;
            string errorMessage = "Unexpected error occurred while deleting favorite job";
            UpdateFavoriteCommand updateFavoriteCommand = new UpdateFavoriteCommand(jobId);
            this.favoriteServiceMock.Setup(x => x.UpdateFavorite(jobId)).Returns(Task.FromResult(errorMessage));

            // Act
            string result = await this.updateFavoriteCommandHandler.Handle(updateFavoriteCommand, this.cancellationToken);

            // Assert
            Assert.Equal(result, errorMessage);
            this.favoriteServiceMock.Verify(x => x.UpdateFavorite(jobId), Times.Once);
        }
    }
}
