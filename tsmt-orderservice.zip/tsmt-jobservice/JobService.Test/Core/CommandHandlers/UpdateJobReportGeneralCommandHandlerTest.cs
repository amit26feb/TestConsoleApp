// <copyright file="UpdateJobReportGeneralCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobReportGeneralCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobReportGeneralCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public UpdateJobReportGeneralCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobReportGeneralCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successfull updation of general section details in jobreport table
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobReportGeneral_ValidInput_RetrunsTrue()
        {
            // Arrange
            var jobGeneral = new JobGeneralView()
            {
                JobId = 100
            };

            var updateJobCommand = new UpdateJobReportGeneralCommand(jobGeneral);

            this.jobServiceMock.Setup(x => x.UpdateJobReportGeneral(It.IsAny<JobGeneralView>()))
                .Returns(Task.FromResult(true));

            // Act
            var handler = new UpdateJobReportGeneralCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.True(result);
            this.jobServiceMock.Verify(x => x.UpdateJobReportGeneral(It.IsAny<JobGeneralView>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of general details for invalid id
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobReportGeneral_InvalidInput_ReturnsFalse()
        {
            // Arrange
            var jobGeneral = new JobGeneralView()
            {
                JobId = 0
            };

            var updateJobCommand = new UpdateJobReportGeneralCommand(jobGeneral);

            this.jobServiceMock.Setup(x => x.UpdateJobReportGeneral(It.IsAny<JobGeneralView>()))
                .Returns(Task.FromResult(false));

            // Act
            var handler = new UpdateJobReportGeneralCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(updateJobCommand, cltToken);

            // Assert
            Assert.False(result);
            this.jobServiceMock.Verify(x => x.UpdateJobReportGeneral(It.IsAny<JobGeneralView>()), Times.Once);
        }
    }
}
