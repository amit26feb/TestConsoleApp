// <copyright file="UpdateCustomSenderCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using Moq;
    using Xunit;

    /// <summary>
    /// Update custom sender command handler test
    /// </summary>
    public class UpdateCustomSenderCommandHandlerTest
    {
        private readonly Mock<ICustomSenderService> customSenderServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateCustomSenderCommandHandlerTest"/> class.
        /// </summary>
        public UpdateCustomSenderCommandHandlerTest()
        {
            this.customSenderServiceMock = new Mock<ICustomSenderService>();
        }

        /// <summary>
        /// Method to Test successful custom sender updated
        /// </summary>
        /// <returns>Empty string</returns>
        [Fact]
        public async Task Handle_UpdateCustomSender_Success()
        {
            // Arrange
            var handler = new UpdateCustomSenderCommandHandler(this.customSenderServiceMock.Object);
            var cltToken = default(CancellationToken);
            string customSenderId = "xyz-hj23k-34jkk2";
            CustomSenderViewModel request = Helper.GetCustomSenderViewModel(customSenderId);
            string response = string.Empty;
            this.customSenderServiceMock.Setup(x => x.UpdateCustomSender(It.IsAny<CustomSenderViewModel>()))
                .Returns(Task.FromResult(response));

            var fakeUpdateCustomSenderCommand = new UpdateCustomSenderCommand(request);

            // Act
            var result = await handler.Handle(fakeUpdateCustomSenderCommand, cltToken);

            // Assert
            Assert.Empty(result);
            this.customSenderServiceMock.Verify(x => x.UpdateCustomSender(request), Times.Once);
        }
    }
}
