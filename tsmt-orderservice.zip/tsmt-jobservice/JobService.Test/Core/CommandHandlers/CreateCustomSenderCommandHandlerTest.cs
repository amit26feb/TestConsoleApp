// <copyright file="CreateCustomSenderCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using JobService.Core.ViewModels;
    using JobService.Test.Common;
    using Moq;
    using Xunit;

    /// <summary>
    /// Create custom sender command handler test
    /// </summary>
    public class CreateCustomSenderCommandHandlerTest
    {
        private readonly Mock<ICustomSenderService> customSenderServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCustomSenderCommandHandlerTest"/> class.
        /// </summary>
        public CreateCustomSenderCommandHandlerTest()
        {
            this.customSenderServiceMock = new Mock<ICustomSenderService>();
        }

        /// <summary>
        /// Method to Test successful custom sender created
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Fact]
        public async Task Handle_CreateCustomSender_Success()
        {
            // Arrange
            var handler = new CreateCustomSenderCommandHandler(this.customSenderServiceMock.Object);
            var cltToken = default(CancellationToken);
            CustomSenderViewModel request = Helper.GetCustomSenderViewModel();
            string response = string.Empty;
            this.customSenderServiceMock.Setup(x => x.CreateCustomSender(request))
                .Returns(Task.FromResult(response));

            var fakeCreateCustomSenderCommand = new CreateCustomSenderCommand(request);

            // Act
            var result = await handler.Handle(fakeCreateCustomSenderCommand, cltToken);

            // Assert
            Assert.Empty(result);
            this.customSenderServiceMock.Verify(x => x.CreateCustomSender(It.IsAny<CustomSenderViewModel>()), Times.Once);
        }
    }
}
