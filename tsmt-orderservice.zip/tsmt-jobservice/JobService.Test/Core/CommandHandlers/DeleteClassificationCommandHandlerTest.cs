// <copyright file="DeleteClassificationCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.CommandHandlers
{
    using System.Threading.Tasks;
    using JobService.Core.CommandHandlers;
    using JobService.Core.Commands;
    using JobService.Core.Services;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Tests both valid and invalid parameters in deleting classification informations
    /// </summary>
    public class DeleteClassificationCommandHandlerTest
    {
        private readonly Mock<ILogger<DeleteClassificationCommand>> loggerMock;
        private readonly Mock<IJobService> jobServiceMock;

        public DeleteClassificationCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<DeleteClassificationCommand>>();
            this.jobServiceMock = new Mock<IJobService>();
        }

        /// <summary>
        /// Tests successful deletion of classification details
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_Delete_Classification_Success()
        {
            // Arrange
            int jobId = 100;
            int? deletedRows = 1;

            var fakeDeleteJobClassificationCommand = new DeleteClassificationCommand(jobId);

            this.jobServiceMock.Setup(x => x.DeleteClassification(It.IsAny<int>()))
                .Returns(Task.FromResult(deletedRows)).Verifiable();

            // Act
            var handler = new DeleteClassificationCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeDeleteJobClassificationCommand, cltToken);

            //// Assert
            Assert.Equal(deletedRows, result);
            this.jobServiceMock.Verify(x => x.DeleteClassification(It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful deletion of classification informations for invalid id
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_DeleteClassification_InvalidId()
        {
            // Arrange
            int jobId = 0;
            int? deletedRows = 0;

            var fakeDeleteJobClassificationCommand = new DeleteClassificationCommand(jobId);

            this.jobServiceMock.Setup(x => x.DeleteClassification(It.IsAny<int>()))
                .Returns(Task.FromResult(deletedRows)).Verifiable();

            // Act
            var handler = new DeleteClassificationCommandHandler(this.loggerMock.Object, this.jobServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeDeleteJobClassificationCommand, cltToken);

            //// Assert
            Assert.Equal(deletedRows, result);
            this.jobServiceMock.Verify(x => x.DeleteClassification(It.IsAny<int>()), Times.Once);
        }
    }
}
