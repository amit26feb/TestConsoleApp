// <copyright file="LoggingBehaviorTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Behavior
{
    using System.Threading;
    using System.Threading.Tasks;
    using JobService.Core.Behaviors;
    using MediatR;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class LoggingBehaviorTest
    {
        private readonly Mock<ILogger<LoggingBehavior<Request, Response>>> mockLogger;

        public LoggingBehaviorTest()
        {
            this.mockLogger = new Mock<ILogger<LoggingBehavior<Request, Response>>>();
        }

        [Fact]
        public async Task Success()
        {
            LoggingBehavior<Request, Response> loggingBehavior = new LoggingBehavior<Request, Response>(this.mockLogger.Object);

            Request ping = new Request
            {
                Message = "test request"
            };
            Response pong = new Response
            {
                Message = "test response"
            };
            CancellationToken cancellationToken = default(CancellationToken);
            var response = await loggingBehavior.Handle(ping, cancellationToken, next: () => Task.FromResult(pong));

            Assert.NotNull(response);
            Assert.Equal(response.Message, pong.Message);
        }
    }

#pragma warning disable SA1402 // File may only contain a single class
    public class Request : IRequest<Response>
#pragma warning restore SA1402 // File may only contain a single class
    {
        public string Message { get; set; }
    }

#pragma warning disable SA1402 // File may only contain a single class
    public class Response
#pragma warning restore SA1402 // File may only contain a single class
    {
        public string Message { get; set; }
    }
}
