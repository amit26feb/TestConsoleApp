// <copyright file="ValidatorBehaviorTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Behaviors
{
    using System.Threading;
    using System.Threading.Tasks;
    using FluentValidation;
    using JobService.Core.Behaviors;
    using JobService.Test.Core.Behavior;
    using Xunit;

    /// <summary>
    /// Validator Behavior Test
    /// </summary>
    public class ValidatorBehaviorTest
    {
        /// <summary>
        /// Logging Behavior Request Response
        /// </summary>
        private readonly IValidator<Request>[] validators;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatorBehaviorTest"/> class.
        /// ValidatorBehaviorTest
        /// </summary>
        public ValidatorBehaviorTest()
        {
            this.validators = new IValidator<Request>[0];
        }

        /// <summary>
        /// Success validator Behavior
        /// </summary>
        /// <returns>Success</returns>
        [Fact]
        public async Task Success()
        {
            ValidatorBehavior<Request, Response> validatorBehavior = new ValidatorBehavior<Request, Response>(this.validators);

            Request ping = new Request
            {
                Message = "test request"
            };
            Response pong = new Response
            {
                Message = "test response"
            };

            CancellationToken cancellationToken = default(CancellationToken);

            var response = await validatorBehavior.Handle(ping, cancellationToken, next: () => Task.FromResult(pong));

            Assert.NotNull(response);
            Assert.Equal(response.Message, pong.Message);
        }
    }
}
