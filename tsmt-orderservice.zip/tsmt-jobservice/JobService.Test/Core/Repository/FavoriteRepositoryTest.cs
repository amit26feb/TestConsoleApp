// <copyright file="FavoriteRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using DocumentDBWrapper;
    using JobService.Configurations;
    using JobService.Core.Models;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.Extensions.Options;
    using MongoDB.Bson;
    using MongoDB.Driver;
    using Moq;
    using Xunit;

    public class FavoriteRepositoryTest
    {
        private readonly Mock<IDocumentDBProvider> documentDBProviderMock;
        private readonly Mock<IDocumentDBConnectionFactory> documentDBConnectionFactory;
        private readonly Mock<IOptions<JobServiceSettings>> jobServiceSettings;
        private readonly FavoriteRepository favoriteRepository;

        public FavoriteRepositoryTest()
        {
            this.documentDBProviderMock = new Mock<IDocumentDBProvider>();
            this.jobServiceSettings = new Mock<IOptions<JobServiceSettings>>();
            JobServiceSettings appSetting = new JobServiceSettings() { DocumentDBFavoriteJobConnectionString = "DummyConnectionString", DocumentDBFavoriteCollectionName = "TSMT-FavoriteJob" };
            this.jobServiceSettings.Setup(app => app.Value).Returns(appSetting);

            this.documentDBConnectionFactory = new Mock<IDocumentDBConnectionFactory>();
            this.documentDBConnectionFactory.Setup(x => x.GetConnection(appSetting.DocumentDBFavoriteJobConnectionString, appSetting.DocumentDBFavoriteCollectionName)).Returns(this.documentDBProviderMock.Object);
            this.favoriteRepository = new FavoriteRepository(this.documentDBConnectionFactory.Object, this.jobServiceSettings.Object);
        }

        /// <summary>
        /// Test to delete favorite job
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task DeleteFavorite_DeleteUnsuccessful_ReturnsFalse()
        {
            // Arrange
            FavoriteJob favoriteJob = new FavoriteJob()
            {
                DrAddressId = 105,
                JobId = 60712,
                UserId = "testuser"
            };
            this.documentDBProviderMock.Setup(x => x.DeleteOneAsync(It.IsAny<FilterDefinition<BsonDocument>>())).Returns(Task.FromResult(false));

            // Act
            bool isDeleted = await this.favoriteRepository.DeleteFavorite(favoriteJob);

            // Assert
            Assert.False(isDeleted);
            this.documentDBProviderMock.Verify(x => x.DeleteOneAsync(It.IsAny<FilterDefinition<BsonDocument>>()), Times.Once);
        }

        /// <summary>
        /// Test to delete favorite job
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task DeleteFavorite_DeleteSuccessful_ReturnsTrue()
        {
            // Arrange
            FavoriteJob favoriteJob = new FavoriteJob()
            {
                DrAddressId = 101,
                JobId = 60621,
                UserId = "testuser"
            };
            this.documentDBProviderMock.Setup(x => x.DeleteOneAsync(It.IsAny<FilterDefinition<BsonDocument>>())).Returns(Task.FromResult(true));

            // Act
            bool isDeleted = await this.favoriteRepository.DeleteFavorite(favoriteJob);

            // Assert
            Assert.True(isDeleted);
            this.documentDBProviderMock.Verify(x => x.DeleteOneAsync(It.IsAny<FilterDefinition<BsonDocument>>()), Times.Once);
        }

        [Fact]
        public async Task CreateFavoriteJob_ValidFavoriteJobDetail_InsertedSuccessfully()
        {
            // Arrange
            FavoriteJob favoriteJob = new FavoriteJob()
            {
                DrAddressId = 122,
                UserId = "cvfds",
                JobId = 6829,
            };

            this.documentDBProviderMock.Setup(x => x.InsertOneAsync(It.IsAny<BsonDocument>())).Returns(Task.CompletedTask);

            // Act
            await this.favoriteRepository.CreateFavoriteJob(favoriteJob);

            // Assert
            this.documentDBProviderMock.Verify(x => x.InsertOneAsync(It.IsAny<BsonDocument>()), Times.Once);
        }

        [Fact]
        public void GetFavoriteJobCount_ValidFavoriteJobDetail_ReturnsFavoriteJobCount()
        {
            // Arrange
            FavoriteJob favoriteJob = new FavoriteJob()
            {
                DrAddressId = 98,
                UserId = "cvfdsf",
                JobId = 6829,
            };
            int count = 5;
            this.documentDBProviderMock.Setup(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<BsonDocument>>())).Returns(count);

            // Act
            var result = this.favoriteRepository.GetFavoriteJobCount(favoriteJob);

            // Assert
            Assert.Equal(result, count);
            this.documentDBProviderMock.Verify(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<BsonDocument>>()), Times.Once);
        }

        /// <summary>
        /// Test to get favorite job count
        /// </summary>
        [Fact]
        public void GetFavoriteCount_RetrievedSuccessfully_ReturnsFavoriteCount()
        {
            // Arrange
            int drAddressId = 101;
            string userId = "testuser";
            long favoriteCount = 10;
            this.documentDBProviderMock.Setup(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<BsonDocument>>())).Returns(favoriteCount);

            // Act
            long result = this.favoriteRepository.GetFavoriteCount(userId, drAddressId);

            // Assert
            Assert.Equal(result, favoriteCount);
            this.documentDBProviderMock.Verify(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<BsonDocument>>()), Times.Once);
        }

        [Fact]
        public async Task GetFollowingUsers_ForGivenJobIdAndDrAddressId_ReturnsFollowingUsers()
        {
            // Arrange
            int drAddressId = 101;
            int jobId = 15546;
            IEnumerable<BsonDocument> userIds = new List<BsonDocument>()
            {
                new BsonDocument()
                {
                    { "UserId", "user1" }
                }
            };
            this.documentDBProviderMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<FindOptions<BsonDocument>>())).Returns(Task.FromResult(userIds));

            // Act
            IEnumerable<BsonDocument> result = await this.favoriteRepository.GetFollowingUsers(drAddressId, jobId);

            // Assert
            Assert.Equal(userIds, result);
            this.documentDBProviderMock.Verify(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<FindOptions<BsonDocument>>()), Times.Once);
        }
    }
}
