// <copyright file="CompetitorRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using global::DataAccess.Core.Abstractions;
    using JobService.Repository;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    public class CompetitorRepositoryTest
    {
        private readonly Mock<IConnectionFactory> connectionFactory;
        private readonly Mock<IRepository<JobService.Core.Models.JobDetails>> repository;

        /// <summary>
        /// Initializes a new instance of the <see cref="CompetitorRepositoryTest"/> class.
        /// CompetitorRepositoryTest
        /// </summary>
        public CompetitorRepositoryTest()
        {
            this.connectionFactory = new Mock<IConnectionFactory>();
            this.repository = new Mock<IRepository<JobService.Core.Models.JobDetails>>();
        }

        [Fact]
        public async Task GetCompetitorListAsync_ReturnsValidData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.Competitor> competitorList = new List<JobService.Core.ViewModels.Competitor>
            {
                new JobService.Core.ViewModels.Competitor()
                {
                    CompetitorId = "3",
                    CompetitorName = "McQuay/AAF/Blazer",
                    CompetitorStatus = "C",
                    CrmCompanyId = "178900"
                },
                new JobService.Core.ViewModels.Competitor()
                {
                     CompetitorId = "117",
                     CompetitorName = "Baltimore Air Coil",
                     CompetitorStatus = "C",
                     CrmCompanyId = "156071"
                }
            };

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()))
             .Returns(Task.FromResult(competitorList)).Verifiable();

            // Act
            var repo = new CompetitorRepository(this.repository.Object);
            var result = await repo.GetCompetitorListAsync<JobService.Core.ViewModels.Competitor>();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
            Assert.True(result.Select(a => a.CompetitorId == "3").Any());
            Assert.True(result.Select(a => a.CrmCompanyId == "156071").Any());
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetCompetitorListAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.Competitor> competitorList = new List<JobService.Core.ViewModels.Competitor>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()))
             .Returns(Task.FromResult(competitorList));

            // Act
            var repo = new CompetitorRepository(this.repository.Object);
            var result = await repo.GetCompetitorListAsync<JobService.Core.ViewModels.Competitor>();

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public void HonorDrAddressId_Execution()
        {
            // Arrange
            var drAddressId = 14;
            this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

            // Act
            var repo = new CompetitorRepository(this.repository.Object);
            repo.HonorDrAddressId(drAddressId);

            // Assert
            this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
        }
    }
}
