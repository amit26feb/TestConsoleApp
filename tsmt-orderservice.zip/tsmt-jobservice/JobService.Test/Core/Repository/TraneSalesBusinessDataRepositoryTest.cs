// <copyright file="TraneSalesBusinessDataRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoFixture;
    using JobService.Common.Constants;
    using JobService.Common.Filters;
    using JobService.Core.Models;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    /// <summary>
    /// Test class for trane sales business data repository
    /// </summary>
    public class TraneSalesBusinessDataRepositoryTest
    {
        private readonly Mock<IRepository<SalesOffice>> repository;
        private readonly TraneSalesBusinessDataRepository traneSalesBusinessDataRepository;

        public TraneSalesBusinessDataRepositoryTest()
        {
            this.repository = new Mock<IRepository<SalesOffice>>();
            this.traneSalesBusinessDataRepository = new TraneSalesBusinessDataRepository(this.repository.Object);
        }

        /// <summary>
        /// HonorDrAddressId called
        /// </summary>
        [Fact]
        public void HonorDrAddressId_Execution()
        {
            // Arrange
            var drAddressId = 12;
            this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

            // Act
            this.traneSalesBusinessDataRepository.HonorDrAddressId(drAddressId);

            // Assert
            this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
        }

        /// <summary>
        /// Test to get sales offices by district with filters
        /// </summary>
        /// <returns>List of sales office models</returns>
        [Fact]
        public async Task GetSalesOfficeByDistrict_ReturnSalesOffices()
        {
            // Arrange
            var salesOfficeFilter = new SalesOfficeFilter() { DrAddressId = 101, ExcludeParts = true, FilterCriteria = "district" };
            var fixture = new Fixture();
            var salesOffices = fixture.CreateMany<SalesOffice>(2);
            var salesOfficeCount = salesOffices.Count();
            this.repository.Setup(x => x.ExecuteListQuery<SalesOffice>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(salesOffices));

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetSalesOfficeByDistrict(salesOfficeFilter);

            // Assert
            Assert.Equal(salesOffices.FirstOrDefault().CITY, result.FirstOrDefault().CITY);
            Assert.Equal(salesOfficeCount, result.Count());
            this.repository.Verify(x => x.ExecuteListQuery<SalesOffice>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Method to test get comm codes
        /// </summary>
        /// <returns>Comm Codes</returns>
        [Fact]
        public async Task GetCommCodesByDistrict_DrAddressIdHasRecords_ReturnsCommCodes()
        {
            // Arrange
            var fixture = new Fixture();
            var commCodes = fixture.CreateMany<CommCodeModel>(2);
            this.repository.Setup(x => x.ExecuteListQuery<CommCodeModel>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(commCodes));
            var request = new CommCodeFilter
            {
                DraddressId = 63
            };

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetCommCodesByDistrict(request);

            // Assert
            Assert.Equal(result, commCodes);
            this.repository.Verify(x => x.ExecuteListQuery<CommCodeModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Method to test get comm codes
        /// </summary>
        /// <returns>Empty list</returns>
        [Fact]
        public async Task GetCommCodesByDistrict_DrAddressIdHasNoRecords_ReturnsEmptyList()
        {
            // Arrange
            this.repository.Setup(x => x.ExecuteListQuery<CommCodeModel>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(Enumerable.Empty<CommCodeModel>()));
            var request = new CommCodeFilter
            {
                DraddressId = 1378
            };

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetCommCodesByDistrict(request);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<CommCodeModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetAllCommCodes_HasRecords_ReturnsCommCodes()
        {
            // Arrange
            var fixture = new Fixture();
            var commCodes = fixture.CreateMany<CommCodeModel>(2);
            this.repository.Setup(x => x.ExecuteListQuery<CommCodeModel>(It.IsAny<string>())).Returns(Task.FromResult(commCodes));

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetAllCommCodes();

            // Assert
            Assert.Equal(result, commCodes);
            this.repository.Verify(x => x.ExecuteListQuery<CommCodeModel>(TraneSalesBusinessDataRepositoryQueries.GetAllCommCodesQuery), Times.Once);
        }

        [Fact]
        public async Task GetAllCommCodes_HasNoRecords_ReturnsEmptyList()
        {
            // Arrange
            this.repository.Setup(x => x.ExecuteListQuery<CommCodeModel>(It.IsAny<string>())).Returns(Task.FromResult(Enumerable.Empty<CommCodeModel>()));

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetAllCommCodes();

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<CommCodeModel>(TraneSalesBusinessDataRepositoryQueries.GetAllCommCodesQuery), Times.Once);
        }

        /// <summary>
        /// Test to get all sales offices with a reportable dr address id, including child offices
        /// </summary>
        /// <returns>List of sales office models</returns>
        [Fact]
        public async Task GetSalesOfficeWithDrAddressIdIncludingChildOffices_ReturnSalesOfficesWithDrAddressId()
        {
            // Arrange
            var salesOfficeFilter = new SalesOfficeFilter() { DrAddressId = 0, ExcludeParts = false, FilterCriteria = "salesofficewithdraddressidincludingchildren" };
            IEnumerable<AllSalesOffice> salesOffices = new List<AllSalesOffice>
            {
                new AllSalesOffice()
                {
                    SalesOfficeId = 145,
                    SalesOfficeName = "Appleton",
                    SalesOfficeCode = "CJ",
                    DrAddressId = 105,
                    CrmIntegrationInd = "N",
                    SalesDistrict = "14",
                    SalesOfficeIdParent = 64
                },
            };

            this.repository.Setup(x => x.ExecuteListQuery<AllSalesOffice>(It.IsAny<string>()))
             .Returns(Task.FromResult(salesOffices));

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetSalesOfficeWithDrAddressIdIncludingChildOffices(salesOfficeFilter);

            // Assert
            Assert.Equal(salesOffices, result);
            this.repository.Verify(x => x.ExecuteListQuery<AllSalesOffice>(TraneSalesBusinessDataRepositoryQueries.SalesOfficesWithDrAddressIdIncludingChildrenSelectQuery(salesOfficeFilter.ExcludeParts)), Times.Once);
        }

        /// <summary>
        /// Test to get all sales offices and dr address id
        /// </summary>
        /// <returns>List of sales office models</returns>
        [Fact]
        public async Task GetSalesOfficeWithDrAddressId_ReturnSalesOfficesWithDrAddressId()
        {
            // Arrange
            var salesOfficeFilter = new SalesOfficeFilter() { DrAddressId = 0, ExcludeParts = false, FilterCriteria = "salesofficewithdraddressid" };
            IEnumerable<AllSalesOffice> salesOffices = new List<AllSalesOffice>
            {
                new AllSalesOffice()
                {
                    SalesOfficeId = 145,
                    SalesOfficeName = "Appleton",
                    SalesOfficeCode = "CJ",
                    DrAddressId = 105,
                    CrmIntegrationInd = "N",
                    SalesDistrict = "14",
                    SalesOfficeIdParent = 64
                },
            };

            this.repository.Setup(x => x.ExecuteListQuery<AllSalesOffice>(It.IsAny<string>()))
             .Returns(Task.FromResult(salesOffices));

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetSalesOfficeWithDrAddressId(salesOfficeFilter);

            // Assert
            Assert.Equal(salesOffices, result);
            this.repository.Verify(x => x.ExecuteListQuery<AllSalesOffice>(TraneSalesBusinessDataRepositoryQueries.SalesOfficesWithDrAddressIdSelectQuery), Times.Once);
        }

        /// <summary>
        /// Verifies get provider method returns valid provider details
        /// </summary>
        /// <returns>Provider details</returns>
        [Fact]
        public async Task GetProviders_HasProviderDetails_ReturnsProviderDetails()
        {
            // Arrange
            IEnumerable<Provider> providers = new List<Provider>
            {
                new Provider()
                {
                   VENDOR_ID = 100,
                   VENDOR_NAME = "Kentuckiana Curb Company",
                   STATUS = "C"
                },
                new Provider()
                {
                   VENDOR_ID = 200,
                   VENDOR_NAME = "Thybar",
                   STATUS = "C"
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<Provider>(TraneSalesBusinessDataRepositoryQueries.ProviderGetQuery))
                .Returns(Task.FromResult(providers));

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetProviders();

            // Assert
            Assert.Equal(100, result.First().VENDOR_ID);
            Assert.Equal("Kentuckiana Curb Company", result.First().VENDOR_NAME);
            Assert.Equal("C", result.First().STATUS);
            this.repository.Verify(x => x.ExecuteListQuery<Provider>(TraneSalesBusinessDataRepositoryQueries.ProviderGetQuery), Times.Once);
        }

        [Fact]
        public async Task GetEquipments_ReturnsEquipmentList()
        {
            // Arrange
            IEnumerable<Equipment> equipments = new List<Equipment>
            {
                new Equipment()
                {
                   PRODUCT_ID = 55,
                   PRODUCT_NAME = "Acoustics",
                   STATUS = "C",
                   VENDOR_ID = 85
                },
                new Equipment()
                {
                   PRODUCT_ID = 58,
                   PRODUCT_NAME = "Computer room units",
                   STATUS = "C",
                   VENDOR_ID = 108
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<Equipment>(It.IsAny<string>()))
              .Returns(Task.FromResult(equipments));

            // Act
            var result = await this.traneSalesBusinessDataRepository.GetEquipments();

            // Assert
            Assert.Equal(55, result.First().PRODUCT_ID);
            Assert.Equal("Acoustics", result.First().PRODUCT_NAME);
            Assert.Equal("C", result.First().STATUS);
            this.repository.Verify(x => x.ExecuteListQuery<Equipment>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetClassifications_HasClassifications_ReturnsClassifications()
        {
            // Arrange
            IEnumerable<Classification> expectedClassifications = new List<Classification>()
            {
                Helper.GetClassification()
            };
            this.repository.Setup(x => x.ExecuteListQuery<Classification>(It.IsAny<string>()))
                .Returns(Task.FromResult(expectedClassifications));

            // Act
            IEnumerable<Classification> actualClassifications = await this.traneSalesBusinessDataRepository.GetClassifications();

            // Assert
            Assert.Equal(expectedClassifications, actualClassifications);
            this.repository.Verify(x => x.ExecuteListQuery<Classification>(TraneSalesBusinessDataRepositoryQueries.ClassificationsSelectQuery), Times.Once);
        }

        [Fact]
        public async Task GetSystemTypes_HasSystemTypes_ReturnsSystemTypes()
        {
            // Arrange
            IEnumerable<JobSystemType> expectedSystemTypes = new List<JobSystemType>()
            {
                Helper.GetJobSystemType()
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobSystemType>(It.IsAny<string>()))
                .Returns(Task.FromResult(expectedSystemTypes));

            // Act
            IEnumerable<JobSystemType> actualSystemTypes = await this.traneSalesBusinessDataRepository.GetSystemTypes();

            // Assert
            Assert.Equal(expectedSystemTypes, actualSystemTypes);
            this.repository.Verify(x => x.ExecuteListQuery<JobSystemType>(TraneSalesBusinessDataRepositoryQueries.SystemTypesSelectQuery), Times.Once);
        }

        [Fact]
        public async Task GetSiteContactList_HasNoSiteContact_ReturnsEmptyList()
        {
            // Act
            IEnumerable<SiteContact> siteContacts = await this.traneSalesBusinessDataRepository.GetSiteContactList();

            // Assert
            Assert.Empty(siteContacts);
        }
    }
}
