// <copyright file="JobsUpdateDynamoDBRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace JobService.Test.Core.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Amazon.DynamoDBv2.DocumentModel;
    using DynamoDBWrapper;
    using JobService.Common.Constants;
    using JobService.Core.Models;
    using JobService.Core.Repository;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// Provides various methods to access the data from dynamo db
    /// </summary>
    public class JobsUpdateDynamoDBRepositoryTest
    {
        private readonly Mock<ILogger<DynamoDBRepository>> logger;
        private readonly Mock<IDynamoDBRepository> dynamoDBRepository;
        private IDynamoTableConfig dynamoTableConfig;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsUpdateDynamoDBRepositoryTest"/> class.
        /// </summary>
        public JobsUpdateDynamoDBRepositoryTest()
        {
            this.logger = new Mock<ILogger<DynamoDBRepository>>();
            this.dynamoDBRepository = new Mock<IDynamoDBRepository>();
        }

        /// <summary>
        /// Verify the jobs update process in dynamo db
        /// </summary>
        /// <returns>Document which contains collection of attribute key-value pairs for update process status</returns>
        [Fact]
        public async Task UpdateJobsUpdateProcessStatus_Execute()
        {
            // Arrange
            JobsUpdateDynamoDBMessage jobsUpdateDynamoDBMessage = new JobsUpdateDynamoDBMessage()
            {
                CreatedDateTime = "3/13/2019 7:39:15 AM",
                Status = "Success",
                ErrorMessage = string.Empty,
                MessageId = "0HLLDPLUFAJ2N:00000001",
                StatusUpdatedDateTime = DateTime.UtcNow.ToString()
            };
            Document document = jobsUpdateDynamoDBMessage.ToDocument();
            this.dynamoTableConfig = new DynamoTableConfig
            {
                TableName = "TSMT-JobsUpdateData",
                ReadCapacityUnits = 3,
                WriteCapacityUnits = 1,
                KeyName = "MessageId",
                KeyType = typeof(string)
            };

            TSMTSettings appSetting = new TSMTSettings()
            {
                SqsServiceUrlForJobsUpdate = "arn: aws: sns: us - east - 1:611998158124:TSMT-JobsUpdateNotifier",
                MessageHidingTimeInMinutes = 2,
                DynamoRegion = "US-East-1",
                DynamoJobUpdateTableName = "TSMT-JobsUpdateData",
                DynamoJobKeyName = "MessageId"
            };

            var appSettings = new Mock<IOptions<TSMTSettings>>();
            appSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.dynamoDBRepository.Setup(x => x.PartialUpdateCommandAsync(It.IsAny<JobsUpdateDynamoDBMessage>(), It.IsAny<ReturnValues>())).Returns(Task.FromResult(document));
            var jobsUpdateDynamoDBRepository = new JobsUpdateDynamoDBRepository(this.logger.Object, appSettings.Object, this.dynamoTableConfig)
            {
                DynamoDBRepository = this.dynamoDBRepository.Object
            };

            // Act
            var result = await jobsUpdateDynamoDBRepository.UpdateJobsUpdateProcessStatus(jobsUpdateDynamoDBMessage);

            // Assert
            Assert.IsType<Document>(result);
            Assert.Equal(document, result);
            this.dynamoDBRepository.Verify(x => x.PartialUpdateCommandAsync(It.IsAny<JobsUpdateDynamoDBMessage>(), It.IsAny<ReturnValues>()), Times.Once);
        }

        /// <summary>
        /// Verifies getting message from dynamo db
        /// </summary>
        /// <returns>List of jobs update message</returns>
        [Fact]
        public async Task GetMessage_ValidRequest_ReturnsData()
        {
            // Arrange
            string messageId = "0HLLDPLUFAJ2N:00000001";
            JobsUpdateDynamoDBMessage jobsUpdateDynamoDBMessage = new JobsUpdateDynamoDBMessage()
            {
                CreatedDateTime = "3/13/2019 7:39:15 AM",
                Status = JobsUpdateStatus.Pending.ToString(),
                ErrorMessage = string.Empty,
                MessageId = messageId,
                StatusUpdatedDateTime = DateTime.UtcNow.ToString(),
                Message = "[{\"DR_ADDRESS_ID\":78,\"LAST_UPDATE\":\"2019 - 03 - 13T08:32:19.5979268Z\",\"JOB_ID\":106274}]"
            };

            this.dynamoTableConfig = new DynamoTableConfig
            {
                TableName = "TSMT-JobsUpdateData",
                ReadCapacityUnits = 3,
                WriteCapacityUnits = 1,
                KeyName = "MessageId",
                KeyType = typeof(string)
            };

            TSMTSettings appSetting = new TSMTSettings()
            {
                SqsServiceUrlForJobsUpdate = "arn: aws: sns: us - east - 1:611998158124:TSMT-JobsUpdateNotifier",
                MessageHidingTimeInMinutes = 2,
                DynamoRegion = "US-East-1",
                DynamoJobUpdateTableName = "TSMT-JobsUpdateData",
                DynamoJobKeyName = "MessageId"
            };

            var appSettings = new Mock<IOptions<TSMTSettings>>();
            appSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.dynamoDBRepository.Setup(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()))
 .Returns(Task.FromResult(jobsUpdateDynamoDBMessage));
            var jobsUpdateDynamoDBRepository = new JobsUpdateDynamoDBRepository(this.logger.Object, appSettings.Object, this.dynamoTableConfig)
            {
                DynamoDBRepository = this.dynamoDBRepository.Object
            };

            // Act
            var result = await jobsUpdateDynamoDBRepository.GetMessage(messageId);

            // Assert
            Assert.Equal(result.MessageId, jobsUpdateDynamoDBMessage.MessageId);
            Assert.Equal(result.Message, jobsUpdateDynamoDBMessage.Message);
            this.dynamoDBRepository.Verify(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()), Times.Once);
        }

        /// <summary>
        /// Verifies returning empty message from dynamo db
        /// </summary>
        /// <returns>Empty message</returns>
        [Fact]
        public async Task GetMessage_InValidRequest_ReturnsEmpty()
        {
            // Arrange
            string messageId = string.Empty;
            JobsUpdateDynamoDBMessage jobsUpdateDynamoDBMessage = new JobsUpdateDynamoDBMessage();

            this.dynamoTableConfig = new DynamoTableConfig
            {
                TableName = "TSMT-JobsUpdateData",
                ReadCapacityUnits = 3,
                WriteCapacityUnits = 1,
                KeyName = "MessageId",
                KeyType = typeof(string)
            };

            TSMTSettings appSetting = new TSMTSettings()
            {
                SqsServiceUrlForJobsUpdate = "arn: aws: sns: us - east - 1:611998158124:TSMT-JobsUpdateNotifier",
                MessageHidingTimeInMinutes = 2,
                DynamoRegion = "US-East-1",
                DynamoJobUpdateTableName = "TSMT-JobsUpdateData",
                DynamoJobKeyName = "MessageId"
            };

            var appSettingMock = new Mock<IOptions<TSMTSettings>>();
            appSettingMock.Setup(ap => ap.Value).Returns(appSetting);

            this.dynamoDBRepository.Setup(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()))
                .Returns(Task.FromResult(jobsUpdateDynamoDBMessage));
            var jobsUpdateDynamoDBRepository = new JobsUpdateDynamoDBRepository(this.logger.Object, appSettingMock.Object, this.dynamoTableConfig)
            {
                DynamoDBRepository = this.dynamoDBRepository.Object
            };

            // Act
            var result = await jobsUpdateDynamoDBRepository.GetMessage(messageId);

            // Assert
            Assert.Equal(result, jobsUpdateDynamoDBMessage);
            this.dynamoDBRepository.Verify(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()), Times.Once);
        }
    }
}
