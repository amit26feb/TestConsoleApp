// <copyright file="SiteRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using JobService.Common.Constants;
    using JobService.Core.Models;
    using JobService.Repository;
    using JobService.Test.Common;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    /// <summary>
    /// Site repository test
    /// </summary>
    public class SiteRepositoryTest
    {
        private readonly Mock<IRepository<SalesOffice>> repository;
        private readonly SiteRepository siteRepository;

        public SiteRepositoryTest()
        {
            this.repository = new Mock<IRepository<SalesOffice>>();
            this.siteRepository = new SiteRepository(this.repository.Object);
        }

        /// <summary>
        /// HonorDrAddressId called
        /// </summary>
        [Fact]
        public void HonorDrAddressId_Execution()
        {
            // Arrange
            var drAddressId = 12;
            this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

            // Act
            this.siteRepository.HonorDrAddressId(drAddressId);

            // Assert
            this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
        }

        [Fact]
        public async Task GetSiteDetails_HasSites_ReturnsSites()
        {
            // Arrange
            int skip = 0;
            int take = 10;
            string searchText = "Test";
            string companyId = "123";
            IEnumerable<CrmSiteModel> site = new List<CrmSiteModel>()
            {
                Helper.GetCrmSiteModel()
            };
            this.repository.Setup(x => x.ExecuteListQuery<CrmSiteModel>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(site));

            // Act
            IEnumerable<CrmSiteModel> result = await this.siteRepository.GetCrmSiteDetails(skip, take, searchText,companyId);

            // Assert
            Assert.Equal(result, site);
            this.repository.Verify(x => x.ExecuteListQuery<CrmSiteModel>(SiteRepositoryQueries.CrmsiteDetailsGetQuery, this.VerifyContactParameters(skip, take, searchText)), Times.Once);
        }

        private object VerifyContactParameters(int skip, int take, string searchText)
        {
            return It.Is<object>(param => (int)param.GetType().GetProperty("SKIP").GetValue(param) == skip + 1
            && (int)param.GetType().GetProperty("TAKE").GetValue(param) == take + skip
            && (string)param.GetType().GetProperty("SEARCH_TEXT").GetValue(param) == "%" + searchText.ToLower() + "%");
        }
    }
}
