// <copyright file="JobRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoFixture;
    using AutoMapper;
    using Dapper;
    using DataAccess.Core.Abstractions;
    using DataAccess.Paging;
    using DocumentDBWrapper;
    using JobService.Common.Constants;
    using JobService.Common.Exceptions;
    using JobService.Configurations;
    using JobService.Core.Models;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using MongoDB.Bson;
    using MongoDB.Driver;
    using Moq;
    using Moq.Dapper;
    using TSMT.DataAccess;
    using TSMT.DataAccess.Models;
    using Xunit;

    public class JobRepositoryTest
    {
        private readonly Mock<IRepository<JobService.Core.Models.JobDetails>> repository;
        private readonly IMapper mapper;
        private readonly Mock<IConnectionFactory> connectionFactory;
        private readonly JobRepository repositoryUnderTest;
        private readonly Mock<ILogger<JobRepository>> logger;
        private readonly Mock<IDocumentDBProvider> documentDBProviderMock;
        private readonly Mock<IDocumentDBConnectionFactory> documentDBConnectionFactory;
        private readonly Mock<IOptions<JobServiceSettings>> jobServiceSettings;
        private readonly int jobId = 1234;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobRepositoryTest"/> class.
        /// JobRepositoryTest
        /// </summary>
        public JobRepositoryTest()
        {
            this.documentDBProviderMock = new Mock<IDocumentDBProvider>();
            this.jobServiceSettings = new Mock<IOptions<JobServiceSettings>>();
            JobServiceSettings appSetting = new JobServiceSettings() { DocumentDBFavoriteJobConnectionString = "DummyConnectionString", DocumentDBFavoriteCollectionName = "TSMT-FavoriteJob" };
            this.jobServiceSettings.Setup(app => app.Value).Returns(appSetting);

            this.documentDBConnectionFactory = new Mock<IDocumentDBConnectionFactory>();
            this.documentDBConnectionFactory.Setup(x => x.GetConnection(appSetting.DocumentDBFavoriteJobConnectionString, appSetting.DocumentDBFavoriteCollectionName)).Returns(this.documentDBProviderMock.Object);

            this.connectionFactory = new Mock<IConnectionFactory>();
            this.repository = new Mock<IRepository<JobDetails>>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.logger = new Mock<ILogger<JobRepository>>();
            this.mapper = config.CreateMapper();
            this.repositoryUnderTest = new JobRepository(this.connectionFactory.Object, this.mapper, this.repository.Object, this.logger.Object, this.documentDBConnectionFactory.Object, this.jobServiceSettings.Object);
        }

        [Fact]
        public async Task GetJobListAsync_ReturnsValidData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.JobView> jobList = new List<JobService.Core.ViewModels.JobView>
            {
                    new JobService.Core.ViewModels.JobView()
                    {
                      JobId = 77574,
                      DrAddressId = 34,
                      JobName = "Gantt Fire Dept",
                      CommCode = "D35",
                      CheckedIn = "Y",
                      SalesOfficeId = 34,
                      CjWho = "Cassie DeWaay",
                      DistanceToJob = 5,
                      JobSource = "PS",
                      DomesticInternationlInd = "D",
                      JobContact = "lamsp",
                    }
             };

            DynamicParameters dParam = new DynamicParameters();
            dParam.Add("Field0", ":78");

            QueryResult queryResult = new QueryResult
            {
                Query = "where  drAddressId = :Field0",
                Parameters = dParam
            };

            List<JobService.Core.Models.Sort> sortOrder = new List<JobService.Core.Models.Sort>
            {
                new JobService.Core.Models.Sort() { SortBy = "JOB_NAME", SortDirection = JobService.Core.Models.SortDirection.Ascending },
            };

            List<Filter> filters = new List<Filter>
            {
                new Filter() { Field = "DR_ADDRESS_ID", Operator = "Eq", Value = "94" },
                new Filter() { Field = "JOB_NAME", Operator = "Eq", Value = "test" },
                new Filter() { Field = "isFavorites", Operator = "Eq", Value = "TRUE" }
            };

            List<FilterCollection> filterCollection = new List<FilterCollection>
            {
                new FilterCollection() { Filters = filters, Logic = "and" },
            };

            var fakeRequest = new JobService.Core.Models.PagingOptions
            {
                Skip = 1,
                Take = 20,
                Sort = sortOrder,
                Filters = filterCollection
            };
            IEnumerable<int> favoriteJobIds = new List<int>()
            {
                1234,
                60621,
                60606
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobList));
            this.repository.Setup(x => x.BuildFilterClause<JobService.Core.ViewModels.JobView>(filterCollection, string.Empty)).Returns(queryResult);

            // Act
            var result = await this.repositoryUnderTest.GetJobListAsync<JobDetails>(fakeRequest, favoriteJobIds);

            // Assert
            Assert.Single(result);
            Assert.True(result.Select(a => a.JobId == 77574).Any());
            Assert.True(result.Select(a => a.CommCode == "D35").Any());
            Assert.True(result.Select(a => a.DrAddressId == 34).Any());
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.BuildFilterClause<JobService.Core.ViewModels.JobView>(filterCollection, string.Empty), Times.Once);
        }

        [Fact]
        public async Task GetJobListAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.JobView> jobList = new List<JobService.Core.ViewModels.JobView>();

            List<JobService.Core.Models.Sort> sortOrder = new List<JobService.Core.Models.Sort>
            {
                new JobService.Core.Models.Sort() { SortBy = "JobName", SortDirection = JobService.Core.Models.SortDirection.Ascending },
            };

            DynamicParameters dParam = new DynamicParameters();
            dParam.Add("Field0", ":78");

            QueryResult queryResult = new QueryResult
            {
                Query = "where  drAddressId = :Field0",
                Parameters = dParam
            };

            List<Filter> filters = new List<Filter>
            {
                new Filter() { Field = "DrAddressId", Operator = "Eq", Value = "94" },
                new Filter() { Field = "JobName", Operator = "Neq", Value = "Trane" }
            };

            List<FilterCollection> filterCollection = new List<FilterCollection>
            {
                new FilterCollection() { Filters = filters, Logic = "and" },
            };
            IEnumerable<int> favoriteJobIds = new List<int>()
            {
                1234,
                60621,
                60606
            };
            var fakeRequest = new JobService.Core.Models.PagingOptions
            {
                Skip = 20,
                Take = 20,
                Sort = sortOrder,
                Filters = filterCollection
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobList));
            this.repository.Setup(x => x.BuildFilterClause<JobService.Core.ViewModels.JobView>(filterCollection, string.Empty)).Returns(queryResult);

            // Act
            var result = await this.repositoryUnderTest.GetJobListAsync<JobDetails>(fakeRequest, favoriteJobIds);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.BuildFilterClause<JobService.Core.ViewModels.JobView>(filterCollection, string.Empty), Times.Once);
        }

        [Fact]
        public async Task GetJobListAsync_FavoriteJobCountIsZero_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.JobView> jobs = new List<JobService.Core.ViewModels.JobView>();

            List<JobService.Core.Models.Sort> sortOrder = new List<JobService.Core.Models.Sort>
            {
                new JobService.Core.Models.Sort() { SortBy = "JobName", SortDirection = JobService.Core.Models.SortDirection.Ascending },
            };

            DynamicParameters dParam = new DynamicParameters();
            dParam.Add("Field0", ":78");

            QueryResult queryResult = new QueryResult
            {
                Query = "where  drAddressId = :Field0",
                Parameters = dParam
            };

            List<Filter> filters = new List<Filter>
            {
                new Filter() { Field = "DrAddressId", Operator = "Eq", Value = "94" },
                new Filter() { Field = "JobName", Operator = "Neq", Value = "Trane" },
                new Filter() { Field = "isFavorites", Operator = "Eq", Value = "TRUE" }
            };

            List<FilterCollection> filterCollection = new List<FilterCollection>
            {
                new FilterCollection() { Filters = filters, Logic = "and" },
            };
            IEnumerable<int> favoriteJobIds = new List<int>();
            var fakeRequest = new JobService.Core.Models.PagingOptions
            {
                Skip = 20,
                Take = 20,
                Sort = sortOrder,
                Filters = filterCollection
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobs));
            this.repository.Setup(x => x.BuildFilterClause<JobService.Core.ViewModels.JobView>(filterCollection, string.Empty)).Returns(queryResult);

            // Act
            var result = await this.repositoryUnderTest.GetJobListAsync<JobDetails>(fakeRequest, favoriteJobIds);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobView>(It.IsAny<string>(), It.IsAny<object>()), Times.Never);
        }

        [Fact]
        public async Task GetSelectionListAsync_ReturnsValidData()
        {
            // Arrange
            var jobId = 4356;
            IEnumerable<SelectionListItem> selectionListItem = new List<SelectionListItem>
            {
                    new SelectionListItem()
                    {
                        Dr_Address_Id = 91,
                        Selection_Id = 794430,
                        Priced_Indicator_Enum = 2,
                        Status_Indicator_Enum = 1,
                        Tag = "ACCU-1",
                        Prod_Family = "SSC",
                        Description = "1 - 6 Ton Unitary Split Systems",
                        Qty = 1,
                        Revised = null,
                        List_Price = 1954
                    }
            };

            List<JobService.Core.Models.Sort> sortOrder = new List<JobService.Core.Models.Sort>
            {
                new JobService.Core.Models.Sort() { SortBy = "DrAddressId", SortDirection = JobService.Core.Models.SortDirection.Ascending },
            };

            var fakeRequest = new JobService.Core.Models.PagingOptions
            {
                Skip = 20,
                Take = 20,
                Sort = sortOrder
            };
            this.repository.Setup(x => x.ExecuteListQuery<SelectionListItem>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(selectionListItem));

            // Act
            var result = await this.repositoryUnderTest.GetSelectionListAsync<SelectionListItem>(fakeRequest, jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.True(result.Select(a => a.Dr_Address_Id == 91).Any());
            Assert.True(result.Select(a => a.Selection_Id == 794430).Any());
            Assert.True(result.Select(a => a.Revised == null).Any());
            this.repository.Verify(x => x.ExecuteListQuery<SelectionListItem>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSelectionListAsync_ReturnsEmptyList()
        {
            // Arrange
            var jobId = 4356;
            IEnumerable<SelectionListItem> selectionListItem = new List<SelectionListItem>();

            List<JobService.Core.Models.Sort> sortOrder = new List<JobService.Core.Models.Sort>
            {
                new JobService.Core.Models.Sort() { SortBy = "DrAddressId", SortDirection = JobService.Core.Models.SortDirection.Ascending },
            };

            var fakeRequest = new JobService.Core.Models.PagingOptions
            {
                Skip = 20,
                Take = 20,
                Sort = sortOrder
            };
            this.repository.Setup(x => x.ExecuteListQuery<SelectionListItem>(It.IsAny<string>()))
             .Returns(Task.FromResult(selectionListItem)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetSelectionListAsync<SelectionListItem>(fakeRequest, jobId);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<SelectionListItem>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetCompetitorListAsync_ReturnsValidData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.Competitor> competitor = new List<JobService.Core.ViewModels.Competitor>
            {
                new JobService.Core.ViewModels.Competitor()
                {
                       CompetitorId = "3",
                       CompetitorName = "McQuay/AAF/Blazer",
                       CompetitorStatus = "C",
                       CrmCompanyId = "178900"
                },
                new JobService.Core.ViewModels.Competitor()
                {
                       CompetitorId = "117",
                       CompetitorName = "Baltimore Air Coil",
                       CompetitorStatus = "C",
                       CrmCompanyId = "156071"
                }
            };

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()))
             .Returns(Task.FromResult(competitor)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetCompetitorListAsync();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
            Assert.True(result.Select(a => a.CompetitorId == "3").Any());
            Assert.True(result.Select(a => a.CompetitorName == "McQuay/AAF/Blazer").Any());
            Assert.True(result.Select(a => a.CompetitorStatus == "C").Any());
            Assert.True(result.Select(a => a.CrmCompanyId == "156071").Any());
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetCompetitorListAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.Competitor> competitor = new List<JobService.Core.ViewModels.Competitor>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()))
             .Returns(Task.FromResult(competitor)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetCompetitorListAsync();

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.Competitor>(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetOfficeSelectorAsync_ReturnsValidData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.OfficeSelectorView> salesofficeList = new List<JobService.Core.ViewModels.OfficeSelectorView>
            {
                new JobService.Core.ViewModels.OfficeSelectorView()
                {
                    SalesOfficeName = "Portland ME",
                    DrAddressId = 94,
                    Country = "USA",
                    CrmIntegrationInd = "Y",
                    GroupName = "La Crosse"
                },

                new JobService.Core.ViewModels.OfficeSelectorView()
                {
                    SalesOfficeName = "Springfield MA",
                    DrAddressId = 94,
                    Country = "USA",
                    CrmIntegrationInd = "Y",
                    GroupName = "La Crosse"
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.OfficeSelectorView>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(salesofficeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetOfficeSelectorAsync<JobService.Core.ViewModels.OfficeSelectorView>("ccfbds");

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
            Assert.True(result.Select(a => a.SalesOfficeName == "Portland ME").Any());
            Assert.True(result.Select(a => a.Country == "USA").Any());
            Assert.True(result.Select(a => a.DrAddressId == 34).Any());
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.OfficeSelectorView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetOfficeSelectorAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.OfficeSelectorView> salesofficeList = new List<JobService.Core.ViewModels.OfficeSelectorView>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.OfficeSelectorView>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(salesofficeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetOfficeSelectorAsync<JobService.Core.ViewModels.OfficeSelectorView>(string.Empty);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.OfficeSelectorView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetCommCodeListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.CommCodeView> commCodeList = new List<JobService.Core.ViewModels.CommCodeView>
            {
                    new JobService.Core.ViewModels.CommCodeView()
                    {
                      CommCode = "R05",
                      Name = "Bradd Robison",
                      CommCodeDisplay = "Bradd Robison [R05]",
                      SalesOfficeId = 117
                    },
                    new JobService.Core.ViewModels.CommCodeView()
                    {
                      CommCode = "R08",
                      Name = "Clarence Young",
                      CommCodeDisplay = "Clarence Young [R08]",
                      SalesOfficeId = 32
                    }
            };

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.CommCodeView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(commCodeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetCommCodeListAsync<JobService.Core.ViewModels.CommCodeView>(125);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
            Assert.True(result.Select(a => a.CommCode == "R05").Any());
            Assert.True(result.Select(a => a.Name == "Bradd Robison").Any());
            Assert.True(result.Select(a => a.CommCodeDisplay == "Clarence Young [R08]").Any());
            Assert.True(result.Select(a => a.SalesOfficeId == 32).Any());
            this.repository.Verify();
        }

        [Fact]
        public async Task GetCommCodeListAsync_InvalidInput_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.CommCodeView> commCodeList = new List<JobService.Core.ViewModels.CommCodeView>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.CommCodeView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(commCodeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetCommCodeListAsync<JobService.Core.ViewModels.CommCodeView>(125);

            // Assert
            Assert.Empty(result);
            this.repository.Verify();
        }

        [Fact]
        public async Task GetJobContactListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.JobContactView> contactList = new List<JobService.Core.ViewModels.JobContactView>
            {
                    new JobService.Core.ViewModels.JobContactView()
                    {
                      UserId = "ts16h325",
                      UserName = "Dee, Patrick"
                    },
                    new JobService.Core.ViewModels.JobContactView()
                    {
                      UserId = "lblqh",
                      UserName = "Lavoie, Daniel",
                    }
             };

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobContactView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(contactList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobContactListAsync<JobService.Core.ViewModels.JobContactView>(125);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
            Assert.True(result.Select(a => a.UserId == "ts16h325").Any());
            Assert.True(result.Select(a => a.UserName == "Dee, Patrick").Any());
            this.repository.Verify();
        }

        [Fact]
        public async Task GetJobContactListAsync_InvalidInput_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.JobContactView> contactList = new List<JobService.Core.ViewModels.JobContactView>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobContactView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(contactList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobContactListAsync<JobService.Core.ViewModels.JobContactView>(125);

            // Assert
            Assert.Empty(result);
            this.repository.Verify();
        }

        [Fact]
        public async Task GetSequenceNumber_ReturnsValidId()
        {
            // Arrange
            int id = 34;
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(id)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetSequenceNumber("job");

            // Assert
            Assert.Equal(result, id);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSequenceNumber_ReturnsInvalidId()
        {
            // Arrange
            int id = 0;
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(id)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetSequenceNumber("job");

            // Assert
            Assert.Equal(result, id);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteNotes_ReturnsValidValue()
        {
            // Arrange
            int val = 1;
            var jobNotes = new JobNotes()
            {
                JOB_ID = 1,
                NOTE_LINE = "abc",
                SEQUENCE_NBR = 1,
                DR_ADDRESS_ID = 1
            };
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(val)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.DeleteNotes<JobNotes>(jobNotes);

            // Assert
            Assert.Equal(result, val);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteNotes_InvalidRequest_ReturnsZeroValue()
        {
            // Arrange
            int val = 0;
            var jobNotes = new JobNotes()
            {
                JOB_ID = 0,
                NOTE_LINE = string.Empty,
                SEQUENCE_NBR = 0,
                DR_ADDRESS_ID = 0
            };
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(val)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.DeleteNotes<JobNotes>(jobNotes);

            // Assert
            Assert.Equal(result, val);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task BulkInsertQueryAsync_ReturnsFalse()
        {
            // Arrange
            int val = 0;
            IEnumerable<JobClassification> fakeRequest = new List<JobClassification>()
            {
                new JobClassification()
                {
                    JOB_ID = 77574,
                    DR_ADDRESS_ID = 94,
                    JOB_CODE_ID = 1
                },
                new JobClassification()
                {
                    JOB_ID = 77575,
                    DR_ADDRESS_ID = 94,
                    JOB_CODE_ID = 2
                }
            };

            this.repository.Setup(x => x.ExecuteAsync<JobClassification>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(val)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.BulkInsertQueryAsync(fakeRequest);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteAsync<JobClassification>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task BulkInsertQueryAsync_ReturnsTrue()
        {
            // Arrange
            int val = 2;
            IEnumerable<JobClassification> fakeRequest = new List<JobClassification>()
            {
                new JobClassification()
                {
                    JOB_ID = 77574,
                    DR_ADDRESS_ID = 94,
                    JOB_CODE_ID = 1
                },
                new JobClassification()
                {
                    JOB_ID = 77575,
                    DR_ADDRESS_ID = 94,
                    JOB_CODE_ID = 2
                }
            };
            this.repository.Setup(x => x.ExecuteAsync<JobClassification>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(val)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.BulkInsertQueryAsync(fakeRequest);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<JobClassification>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task BulkInsertQueryAsync_InvalidRequest_ReturnsException()
        {
            // Arrange
            IEnumerable<JobClassification> fakeRequest = null;

            this.repository.Setup(x => x.ExecuteAsync<JobClassification>(It.IsAny<string>(), It.IsAny<object>()))
             .Throws(new JobMaintenanceDomainException("error occurred")).Verifiable();

            // Act
            var exception = await Assert.ThrowsAsync<JobMaintenanceDomainException>(async () => { await this.repositoryUnderTest.BulkInsertQueryAsync(fakeRequest); });

            // Assert
            Assert.IsType<JobMaintenanceDomainException>(exception);
            Assert.Contains(exception.Message, "error occurred");
            this.repository.Verify(x => x.ExecuteAsync<JobClassification>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteClassification_ValidInput_ReturnsValidValue()
        {
            // Arrange
            int val = 10;

            var connection = new Mock<IDbConnection>();
            connection.SetupDapper(x => x.Execute(
                It.IsAny<string>(),
                It.IsAny<object>(),
                null,
                null,
                null)).Returns(val);
            this.connectionFactory.Setup(c => c.GetConnection).Returns(connection.Object).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.DeleteClassification(100);

            // Assert
            Assert.Equal(val, result);
            this.connectionFactory.Verify(c => c.GetConnection, Times.Once);
        }

        [Fact]
        public async Task DeleteClassification_ValidInput_ReturnsZeroValue()
        {
            // Arrange
            int val = 0;

            var connection = new Mock<IDbConnection>();
            connection.SetupDapper(x => x.Execute(
                It.IsAny<string>(),
                It.IsAny<object>(),
                null,
                null,
                null)).Returns(val).Verifiable();
            this.connectionFactory.Setup(c => c.GetConnection).Returns(connection.Object).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.DeleteClassification(100);

            // Assert
            Assert.Equal(val, result);
            this.connectionFactory.Verify(c => c.GetConnection, Times.Once);
        }

        [Fact]
        public async Task DeleteClassification_InvalidInput_ReturnsException()
        {
            // Arrange
            int val = 0;

            var connection = new Mock<IDbConnection>();
            connection.SetupDapper(x => x.Execute(
                It.IsAny<string>(),
                It.IsAny<object>(),
                null,
                null,
                null)).Returns(val).Verifiable();
            this.connectionFactory.Setup(c => c.GetConnection).Throws(new JobMaintenanceDomainException("error occurred")).Verifiable();

            // Act
            var exception = await Assert.ThrowsAsync<JobMaintenanceDomainException>(async () => { await this.repositoryUnderTest.DeleteClassification(val); });

            // Assert
            Assert.IsType<JobMaintenanceDomainException>(exception);
            Assert.Contains(exception.Message, "error occurred");
            this.connectionFactory.Verify(c => c.GetConnection, Times.Once);
        }

        [Fact]
        public async Task GetJobClassificationsAsync_ValidRequest_ReturnsValidData()
        {
            // Arrange
            int jobId = 100;
            IEnumerable<JobService.Core.ViewModels.JobClassificationView> jobClassification = new List<JobService.Core.ViewModels.JobClassificationView>()
            {
                new JobService.Core.ViewModels.JobClassificationView()
                {
                    JobCodeId = 77574,
                    JobId = 100,
                },
                new JobService.Core.ViewModels.JobClassificationView()
                {
                    JobCodeId = 77575,
                    JobId = 100,
                }
            };

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobClassificationView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobClassification)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobClassificationsAsync(jobId);

            // Assert
            Assert.True(result.Select(a => a.JobId == 100).Any());
            Assert.True(result.Select(a => a.JobCodeId == 77574).Any());
            Assert.Equal(jobClassification.Count(), result.FirstOrDefault().JobClassificationList.Count);
            this.repository.Verify();
        }

        [Fact]
        public async Task GetJobClassificationsAsync_ValidRequest_ReturnsEmptyList()
        {
            // Arrange
            int jobId = 10;
            IEnumerable<JobService.Core.ViewModels.JobClassificationView> jobClassification = new List<JobService.Core.ViewModels.JobClassificationView>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobClassificationView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobClassification)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobClassificationsAsync(jobId);

            // Assert
            Assert.Empty(result);
            this.repository.Verify();
        }

        [Fact]
        public async Task GetJobClassificationsAsync_InvalidInput_ReturnsException()
        {
            // Arrange
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobClassificationView>(It.IsAny<string>(), It.IsAny<object>()))
             .Throws(new JobMaintenanceDomainException("error occurred")).Verifiable();

            // Act
            var exception = await Assert.ThrowsAsync<JobMaintenanceDomainException>(async () => { await this.repositoryUnderTest.GetJobClassificationsAsync(9); });

            // Assert
            Assert.IsType<JobMaintenanceDomainException>(exception);
            Assert.Contains(exception.Message, "error occurred");
            this.repository.Verify();
        }

        [Fact]
        public async Task GetClassificationsByJobIdAsync_ValidRequest_ReturnsValidData()
        {
            // Arrange
            int jobId = 94;
            IEnumerable<JobService.Core.ViewModels.JobClassificationView> jobClassification = new List<JobService.Core.ViewModels.JobClassificationView>()
            {
                new JobService.Core.ViewModels.JobClassificationView()
                {
                    JobCodeId = 77574,
                    JobId = 94,
                },
                new JobService.Core.ViewModels.JobClassificationView()
                {
                    JobCodeId = 77575,
                    JobId = 94,
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobClassificationView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobClassification)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetClassificationsByJobIdAsync(jobId);

            // Assert
            Assert.True(result.Count() == 2);
            Assert.True(result.Select(a => a.JobId == 94).Any());
            Assert.True(result.Select(a => a.JobCodeId == 77574).Any());
            this.repository.Verify();
        }

        [Fact]
        public async Task GetClassificationsByJobIdAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.JobClassificationView> jobClassification = new List<JobService.Core.ViewModels.JobClassificationView>();
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobClassificationView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobClassification)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetClassificationsByJobIdAsync(100);

            // Assert
            Assert.Empty(result);
            this.repository.Verify();
        }

        [Fact]
        public async Task GetClassificationsByJobIdAsync_InvalidInput_ReturnsException()
        {
            // Arrange
            int jobId = 0;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobClassificationView>(It.IsAny<string>(), It.IsAny<object>()))
             .Throws(new JobMaintenanceDomainException("error occurred")).Verifiable();

            // Act
            var exception = await Assert.ThrowsAsync<JobMaintenanceDomainException>(async () => { await this.repositoryUnderTest.GetClassificationsByJobIdAsync(jobId); });

            // Assert
            Assert.IsType<JobMaintenanceDomainException>(exception);
            Assert.Contains(exception.Message, "error occurred");
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobClassificationView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSystemTypeListAsync_ReturnsValidData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.SystemTypeViewModel> systemTypeList = new List<JobService.Core.ViewModels.SystemTypeViewModel>()
            {
                new JobService.Core.ViewModels.SystemTypeViewModel()
                {
                   SysTypeId = 1,
                   MultiSelect = "N",
                   Description = "No System",
                   ToolTip = "No System"
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SystemTypeViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(systemTypeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSystemTypeListAsync(10);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.True(result.Select(a => a.SysTypeId == 1).Any());
            Assert.True(result.Select(a => a.MultiSelect == "N").Any());
            this.repository.Verify();
        }

        [Fact]
        public async Task GetJobSystemTypeListAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.SystemTypeViewModel> systemTypeList = new List<JobService.Core.ViewModels.SystemTypeViewModel>();
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SystemTypeViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(systemTypeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSystemTypeListAsync(10);

            // Assert
            Assert.Empty(result);
            this.repository.Verify();
        }

        [Fact]
        public async Task BulkJobSysIndXrefInsertQueryAsync_ValidInput_ReturnsTrue()
        {
            // Arrange
            int val = 1;
            IEnumerable<JobSysIndXref> fakeRequest = new List<JobSysIndXref>()
            {
                new JobSysIndXref()
                {
                    JOB_ID = 77574,
                    DR_ADDRESS_ID = 94,
                }
            };

            this.repository.Setup(x => x.ExecuteAsync<JobSysIndXref>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(val)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.BulkJobSysIndXrefInsertQueryAsync(fakeRequest);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<JobSysIndXref>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task BulkJobSysIndXrefInsertQueryAsync_ValidInput_ReturnsFalse()
        {
            // Arrange
            int val = 0;
            IEnumerable<JobSysIndXref> jobSysIndXref = new List<JobSysIndXref>()
            {
                new JobSysIndXref()
                {
                    JOB_ID = 77574,
                    DR_ADDRESS_ID = 94,
                }
            };

            this.repository.Setup(x => x.ExecuteAsync<JobSysIndXref>(It.IsAny<string>(), It.IsAny<object>()))
              .Returns(Task.FromResult(val)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.BulkJobSysIndXrefInsertQueryAsync(jobSysIndXref);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteAsync<JobSysIndXref>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task BulkJobSysIndXrefInsertQueryAsync_InvalidInput_ReturnsException()
        {
            // Arrange
            IEnumerable<JobSysIndXref> jobSysIndXref = null;

            this.repository.Setup(x => x.ExecuteAsync<JobSysIndXref>(It.IsAny<string>(), It.IsAny<object>()))
              .Throws(new JobMaintenanceDomainException("error occurred")).Verifiable();

            // Act
            var exception = await Assert.ThrowsAsync<JobMaintenanceDomainException>(async () => { await this.repositoryUnderTest.BulkJobSysIndXrefInsertQueryAsync(jobSysIndXref); });

            // Assert
            Assert.IsType<JobMaintenanceDomainException>(exception);
            Assert.Contains(exception.Message, "error occurred");
            this.repository.Verify(x => x.ExecuteAsync<JobSysIndXref>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteJobSysIndXref_ReturnsValidCount()
        {
            // Arrange
            int count = 10;
            var connection = new Mock<IDbConnection>();
            connection.SetupDapper(x => x.Execute(
                It.IsAny<string>(),
                It.IsAny<object>(),
                null,
                null,
                null)).Returns(count).Verifiable();
            this.connectionFactory.Setup(c => c.GetConnection).Returns(connection.Object).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.DeleteJobSysIndXref(100);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(count, result);
            this.connectionFactory.Verify(c => c.GetConnection, Times.Once);
        }

        [Fact]
        public async Task DeleteJobSysIndXref_ReturnsZeroCount()
        {
            // Arrange
            int count = 0;

            var connection = new Mock<IDbConnection>();
            connection.SetupDapper(x => x.Execute(
                It.IsAny<string>(),
                It.IsAny<object>(),
                null,
                null,
                null)).Returns(count).Verifiable();
            this.connectionFactory.Setup(c => c.GetConnection).Returns(connection.Object).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.DeleteJobSysIndXref(100);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(count, result);
            this.connectionFactory.Verify(c => c.GetConnection, Times.Once);
        }

        [Fact]
        public async Task GetJobInfoAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            JobService.Core.ViewModels.JobInfoViewModel jobInfo = new JobService.Core.ViewModels.JobInfoViewModel()
            {
                JobId = 25107,
                JobName = "Job1"
            };
            this.repository.Setup(x => x.ExecuteQuery<JobService.Core.ViewModels.JobInfoViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobInfo)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobInfoAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.JobId == 25107);
            Assert.True(result.JobName == "Job1");
            this.repository.Verify(x => x.ExecuteQuery<JobService.Core.ViewModels.JobInfoViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobInfoAsync_InvalidJobId_ReturnsNoData()
        {
            // Arrange
            JobService.Core.ViewModels.JobInfoViewModel jobInfo = null;
            this.repository.Setup(x => x.ExecuteQuery<JobService.Core.ViewModels.JobInfoViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobInfo));

            // Act
            var result = await this.repositoryUnderTest.GetJobInfoAsync(this.jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteQuery<JobService.Core.ViewModels.JobInfoViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobBidAlternateListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.BidAlternateViewModel> bidAlternateList = new List<JobService.Core.ViewModels.BidAlternateViewModel>()
            {
                new JobService.Core.ViewModels.BidAlternateViewModel()
                {
                  BidAlternateId = 166420,
                  JobId = 165009,
                  BaseBidYesNo = 1,
                  IncludeInCj = 0,
                  Descr = string.Empty,
                  SellingPrice = 77899,
                  BidName = "Base Bid",
                  DiscountExpireDate = DateTime.Now,
                  CurrentBidInd = "Y",
                  LegacyJobNbr = "F509898",
                  HqtrBidAlternateId = 11,
                  LanBidAlternateId = 88989,
                  CjConfirmationDiscInd = "N",
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.BidAlternateViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(bidAlternateList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobBidAlternateListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.BidAlternateId == 166420);
            Assert.Contains(result, a => a.JobId == 165009);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.BidAlternateViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobBidAlternateListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 165009;
            IEnumerable<JobService.Core.ViewModels.BidAlternateViewModel> bidAlternateList = null;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.BidAlternateViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(bidAlternateList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobBidAlternateListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.BidAlternateViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetReferenceUnitListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            int jobId = 668341;
            IEnumerable<JobService.Core.ViewModels.ReferenceUnitViewModel> referenceUnitList = new List<JobService.Core.ViewModels.ReferenceUnitViewModel>()
            {
                new JobService.Core.ViewModels.ReferenceUnitViewModel()
                {
                  ReferenceUnitId = 10449484,
                  JobId = 668341,
                  TagSequenceNbr = 1,
                  VariationId = 1,
                  Tag = "lkm",
                  FloorNbr = 1,
                  RoomNbr = 1,
                  ZoneNbr = 1,
                  ReqsShipDate = DateTime.Now,
                  Remarks = "remark",
                  HostUpdateInd = "y",
                  SalesOrdId = 1,
                  OrdLineNbr = 2,
                  CurrBillLetter = "xyz",
                  MfgOrderPlannedShipmentNbr = "abc",
                  UnitSerialNbr = "sr",
                  InsertDate = DateTime.Now,
                  MfgOrderBillLetter = "A",
                  ReviseDate = DateTime.Now
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ReferenceUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(referenceUnitList)).Verifiable();

            // Act
            IEnumerable<JobService.Core.ViewModels.ReferenceUnitViewModel> result = await this.repositoryUnderTest.GetReferenceUnitListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ReferenceUnitId == 10449484);
            Assert.Contains(result, a => a.JobId == 668341);
            Assert.Equal(result.ElementAt(0).ReviseDate, referenceUnitList.ElementAt(0).ReviseDate);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ReferenceUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetReferenceUnitListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ReferenceUnitViewModel> referenceUnitList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ReferenceUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(referenceUnitList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetReferenceUnitListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ReferenceUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdXrefListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 1870831;
            IEnumerable<JobService.Core.ViewModels.JobProdXrefViewModel> jobProdXrefList = new List<JobService.Core.ViewModels.JobProdXrefViewModel>()
            {
                new JobService.Core.ViewModels.JobProdXrefViewModel()
                {
                  JobId = 1870831,
                  ProdFamilyId = 2006347,
                  CjShipQtr = 3,
                  BenchmarkUnits = string.Empty,
                  CjShipYear = 1222,
                  CjCompetitor = string.Empty,
                  CjSpecified = string.Empty,
                  BenchmarkValue = 200,
                  PriceControlId = 667,
                  PriceProtectionDate = DateTime.Now,
                  ProductAddDate = DateTime.Now,
                  UomSchemeId = 9
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.JobProdXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdXrefList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdXrefListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdFamilyId == 2006347);
            Assert.Contains(result, a => a.JobId == 1870831);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.JobProdXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdXrefListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.JobProdXrefViewModel> jobProdXrefList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.JobProdXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdXrefList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdXrefListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.JobProdXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobNoteListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.JobNoteViewModel> jobNoteList = new List<JobService.Core.ViewModels.JobNoteViewModel>()
            {
                new JobService.Core.ViewModels.JobNoteViewModel()
                {
                  JobId = 251076,
                  NoteLine = "Test"
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.JobNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobNoteList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobNoteListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.NoteLine == "Test");
            Assert.Contains(result, a => a.JobId == 251076);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.JobNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobNoteListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.JobNoteViewModel> jobNoteList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.JobNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobNoteList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobNoteListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.JobNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Method to test GetJobCrmOpportunityIds for valid data
        /// </summary>
        /// <returns>JobOpportunity model with records</returns>
        [Fact]
        public async Task GetJobCrmOpportunityIds_ValidInput_ReturnsResult()
        {
            // Arrange
            List<int> jobIds = new List<int>
            { 6392, 1234 };
            IEnumerable<JobOpportunity> jobCrmOpportunityIds = new List<JobOpportunity>()
            {
                new JobOpportunity()
                {
                  JOB_ID = 6392,
                  CRM_OPPORTUNITY_ID = string.Empty
                },
                new JobOpportunity()
                {
                    JOB_ID = 1234,
                    CRM_OPPORTUNITY_ID = string.Empty
                }
            };
            this.repository.Setup(r => r.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(jobCrmOpportunityIds));

            // Act
            IEnumerable<JobOpportunity> result = await this.repositoryUnderTest.GetJobCrmOpportunityIds(jobIds);

            // Assert
            Assert.Equal(result, jobCrmOpportunityIds);
            this.repository.Verify(r => r.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Method to test GetJobCrmOpportunityIds for invalid data
        /// </summary>
        /// <returns>Empty Result</returns>
        [Fact]
        public async Task GetJobCrmOpportunityIds_InvalidInput_ReturnsEmptyResult()
        {
            // Arrange
            var fixture = new Fixture();
            var jobIds = fixture.CreateMany<int>(4);
            this.repository.Setup(r => r.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>()))
                  .Returns(Task.FromResult(Enumerable.Empty<JobOpportunity>()));

            // Act
            IEnumerable<JobOpportunity> result = await this.repositoryUnderTest.GetJobCrmOpportunityIds(jobIds);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(r => r.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetProdSelFamilyListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelFamilyViewModel> jobNoteList = new List<JobService.Core.ViewModels.ProdSelFamilyViewModel>()
            {
                new JobService.Core.ViewModels.ProdSelFamilyViewModel()
                {
                  JobId = 25107,
                  ProdFamilyId = 2000541,
                  HqtrJobId = 22,
                  UomSchemeId = 1,
                  TemplatePath = "C:\\Program Files\\Trane Company\\TOPSS\\RTAC\\RTACDefault.pst",
                  CustomUomSchemeId = 334
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelFamilyViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobNoteList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetProdSelFamilyListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdFamilyId == 2000541);
            Assert.Contains(result, a => a.JobId == 25107);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelFamilyViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetProdSelFamilyListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelFamilyViewModel> jobNoteList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelFamilyViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobNoteList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetProdSelFamilyListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelFamilyViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectionListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectionViewModel> jobSelectionList = new List<JobService.Core.ViewModels.SelectionViewModel>()
            {
                new JobService.Core.ViewModels.SelectionViewModel()
                {
                  JobId = 251076,
                  SelectionId = 2737486,
                  ActiveInJobYesnoFlag = 1,
                  SelectionSource = "abcd",
                  SalesmanDescr = "cdef",
                  UnitQty = 1,
                  UseOnSubmittalFlag = 1,
                  ProdFamilyId = 2,
                  PriceControlId = 3,
                  SelectionStatusDate = DateTime.Now,
                  CopiedFrom = 1,
                  SalesOrdId = 2,
                  EngSpecificationNbr = "xyz",
                  QuickShipBpaf = 1,
                  TotalNetDollars = 1,
                  TotalUnadjustedBasePrice = 1,
                  LegacyOrdNbr = "abc",
                  HqtrSelectionId = 1,
                  Source = "acd",
                  ValidationDate = DateTime.Now,
                  ChgAllowedInd = "abc",
                  UnitQtyWas = 1,
                  OutOfDateInd = "anc",
                  InsertDate = DateTime.Now,
                  SequenceNbr = 123,
                  SalesOfficeSelectionId = 2,
                  LanSelectionId = 3,
                  SourceDate = DateTime.Now,
                  PendingOrderInd = "123",
                  BomReviseDate = DateTime.Now,
                  NonBomReviseDate = DateTime.Now,
                  LastUpdate = DateTime.Now,
                  ReviseDate = DateTime.Now,
                  ActivePriceControlId = 2,
                  SelPriceComplete = "12"
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SelectionViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectionList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectionListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectionId == 2737486);
            Assert.Contains(result, a => a.JobId == 251076);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SelectionViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectionListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectionViewModel> jobSelectionList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SelectionViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectionList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectionListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SelectionViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectionDocCompListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.DocCompViewModel> jobSelectionDocCompList = new List<JobService.Core.ViewModels.DocCompViewModel>()
            {
                new JobService.Core.ViewModels.DocCompViewModel()
                {
                 SelectionId = 34,
                 DocCompId = 56,
                 SubDataDate = DateTime.Now,
                 DocFilename = "00006B25.EMF",
                 DocPath = "\\EXPT",
                 DocTypeId = "PDDX"
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.DocCompViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectionDocCompList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectionDocCompListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectionId == 34);
            Assert.Contains(result, a => a.DocCompId == 56);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.DocCompViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectionDocCompListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.DocCompViewModel> jobSelectionDocCompList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.DocCompViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectionDocCompList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectionDocCompListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.DocCompViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelUnitListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelUnitViewModel> jobProdSelUnitList = new List<JobService.Core.ViewModels.ProdSelUnitViewModel>()
            {
                new JobService.Core.ViewModels.ProdSelUnitViewModel()
                {
                 ProdSelUnitId = 2124276,
                 JobId = 25107,
                 UnitSequence = 4,
                 Description = "Force-Flo Fan",
                 HqtrProdSelUnitId = 445
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdSelUnitList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelUnitListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdSelUnitId == 2124276);
            Assert.Contains(result, a => a.JobId == 25107);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelUnitListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelUnitViewModel> jobProdSelUnitList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdSelUnitList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelUnitListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelUnitViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelUnitModuleListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelModuleViewModel> jobProdSelUnitList = new List<JobService.Core.ViewModels.ProdSelModuleViewModel>()
            {
                new JobService.Core.ViewModels.ProdSelModuleViewModel()
                {
                     ProdSelUnitId = 1932640,
                     ProdSelModuleId = 8374922,
                     ModuleSequence = 1,
                     HostUpdateInd = "Y",
                     HqtrProdSelModuleId = 78996,
                     ProdModuleId = 778
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdSelUnitList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelUnitModuleListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdSelUnitId == 1932640);
            Assert.Contains(result, a => a.ProdSelModuleId == 8374922);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelUnitModuleListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelModuleViewModel> jobProdSelUnitList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdSelUnitList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelUnitModuleListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedPricingParmListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedPricingParmViewModel> jobSelectedPricingParmList = new List<JobService.Core.ViewModels.SelectedPricingParmViewModel>()
            {
                new JobService.Core.ViewModels.SelectedPricingParmViewModel()
                {
                     SelectedPricingParmId = 599215,
                     SelectionId = 373082,
                     ProdPricingGrpId = 61
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPricingParmViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedPricingParmList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedPricingParmListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectedPricingParmId == 599215);
            Assert.Contains(result, a => a.SelectionId == 373082);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPricingParmViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedPricingParmListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedPricingParmViewModel> jobSelectedPricingParmList = null;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPricingParmViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedPricingParmList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedPricingParmListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPricingParmViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectionXrefListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectionXrefViewModel> jobSelectionXrefList = new List<JobService.Core.ViewModels.SelectionXrefViewModel>()
            {
                new JobService.Core.ViewModels.SelectionXrefViewModel()
                {
                     SelectionXrefId = 15798526,
                     SelectionId = 6648933,
                     HostUpdateInd = "Y",
                     InsertDate = DateTime.Now,
                     ReferenceUnitId = 990,
                     ReviseDate = DateTime.Today,
                     Source = "PS",
                     UnitNbrId = 9
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SelectionXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectionXrefList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectionXrefListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectionXrefId == 15798526);
            Assert.Contains(result, a => a.SelectionId == 6648933);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SelectionXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectionXrefListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectionXrefViewModel> jobSelectionXrefList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SelectionXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectionXrefList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectionXrefListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SelectionXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedModuleListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedModuleViewModel> jobSelectedModuleList = new List<JobService.Core.ViewModels.SelectedModuleViewModel>()
            {
                new JobService.Core.ViewModels.SelectedModuleViewModel()
                {
                     SelectedModuleId = 14271639,
                     SelectionId = 4647407,
                     ProdModuleId = 2011145,
                     Height = 90,
                     Weight = 879,
                     XPosition = 98,
                     YPosition = 0,
                     ZPosition = 0,
                     SalesmanDescr = string.Empty,
                     SequenceNbr = 78,
                     InsertDate = DateTime.Now,
                     HostUpdateInd = "Y",
                     HqtrSelectedModuleId = 9989,
                     Length = 89,
                     Width = 54
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedModuleList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedModuleListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectedModuleId == 14271639);
            Assert.Contains(result, a => a.SelectionId == 4647407);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedModuleListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedModuleViewModel> jobSelectedModuleList = null;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedModuleList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedModuleListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedModuleViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedModuleItemListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedItemViewModel> jobSelectedModuleItemList = new List<JobService.Core.ViewModels.SelectedItemViewModel>()
            {
                new JobService.Core.ViewModels.SelectedItemViewModel()
                {
                 SelectedModuleId = 14822834,
                 VpcId = 2036185,
                 OptionalAddSelectedItem = 1,
                 IncludeOnSubmittal = 1,
                 SiId = 2,
                 SelectedPricingParmId = 1,
                 NetPrice = 5,
                 StdCost = 1,
                 UnadjustedBasePrice = 1,
                 Source = "xyz",
                 SelectableItemPriceId = 1,
                 HostUpdateInd = "y",
                 InsertDate = DateTime.Now,
                 SequenceNbr = 1,
                 HqtrSelectedItemId = 1,
                 Plane = "lkmn",
                 XDim = 2,
                 YDim = 2,
                 ZDim = 1,
                 XOffset = 3,
                 YOffset = 1,
                 ZOffset = 2,
                 OrderingNbr = "xyt",
                 InputValue = 2
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedItemViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedModuleItemList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedModuleItemListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectedModuleId == 14822834);
            Assert.Contains(result, a => a.VpcId == 2036185);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedItemViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedModuleItemListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedItemViewModel> jobSelectedModuleItemList = null;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedItemViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedModuleItemList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedModuleItemListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedItemViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedPerfListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedPerfViewModel> jobSelectedPerfList = new List<JobService.Core.ViewModels.SelectedPerfViewModel>()
            {
                new JobService.Core.ViewModels.SelectedPerfViewModel()
                {
                 SelectedModuleId = 11287309,
                 VpfcId = 2020532,
                 SelectedPerfId = 1,
                 SelectionXrefId = 2,
                 Value = "abc",
                 Source = "xyz",
                 VpfcProdOptionId = 2,
                 HostUpdateInd = "abc",
                 InsertDate = DateTime.Now,
                 UomId = 1,
                 StringValue = "jkl"
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPerfViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedPerfList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedPerfListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectedModuleId == 11287309);
            Assert.Contains(result, a => a.VpfcId == 2020532);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPerfViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobSelectedPerfListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectedPerfViewModel> jobSelectedPerfList = null;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPerfViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobSelectedPerfList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectedPerfListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectedPerfViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobBidAlternateXrefListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.BidAlternateXrefViewModel> jobBidAlternateXrefList = new List<JobService.Core.ViewModels.BidAlternateXrefViewModel>()
            {
                new JobService.Core.ViewModels.BidAlternateXrefViewModel()
                {
                 SelectionId = 5984493,
                 BidAlternateXrefId = 20257059,
                 VariationId = 11234,
                 SelectedPricingParmId = 45
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.BidAlternateXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobBidAlternateXrefList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobBidAlternateXrefListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectionId == 5984493);
            Assert.Contains(result, a => a.BidAlternateXrefId == 20257059);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.BidAlternateXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobBidAlternateXrefListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.BidAlternateXrefViewModel> jobBidAlternateXrefList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.BidAlternateXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobBidAlternateXrefList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobBidAlternateXrefListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.BidAlternateXrefViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetProdSelResultListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelResultViewModel> prodSelResultList = new List<JobService.Core.ViewModels.ProdSelResultViewModel>()
            {
                new JobService.Core.ViewModels.ProdSelResultViewModel()
                {
                 ProdSelResultId = 15816497,
                 ProdSelCriteriaId = 12349314,
                 SelectionXrefId = 610231,
                 ResultSequence = 1,
                 RunResult = 1,
                 SelectedModuleId = 722231,
                 BankIndex = -1,
                 Tag = string.Empty,
                 HqtrProdSelResultId = 17162978,
                 HostUpdateInd = "Y"
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelResultViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(prodSelResultList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetProdSelResultListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdSelResultId == 15816497);
            Assert.Contains(result, a => a.ProdSelCriteriaId == 12349314);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelResultViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetProdSelResultListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelResultViewModel> prodSelResultList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelResultViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(prodSelResultList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetProdSelResultListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelResultViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelCriteriaListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelCriteriaViewModel> prodSelResultList = new List<JobService.Core.ViewModels.ProdSelCriteriaViewModel>()
            {
                new JobService.Core.ViewModels.ProdSelCriteriaViewModel()
                {
                 ProdSelModuleId = 8052,
                 ProdSelCriteriaId = 14580,
                 CriteriaSequence = 5,
                 Description = "AC-1",
                 HqtrProdSelCriteriaId = 223,
                 HostUpdateInd = string.Empty,
                 Parameters = string.Empty
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(prodSelResultList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelCriteriaListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdSelModuleId == 8052);
            Assert.Contains(result, a => a.ProdSelCriteriaId == 14580);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelCriteriaListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelCriteriaViewModel> prodSelResultList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(prodSelResultList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelCriteriaListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelCriteriaItemListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelCriteriaItemViewModel> jobProdSelCriteriaItemList = new List<JobService.Core.ViewModels.ProdSelCriteriaItemViewModel>()
            {
                new JobService.Core.ViewModels.ProdSelCriteriaItemViewModel()
                {
                 ProdSelCriteriaId = 15651618,
                 ProdSelFieldId = 7989,
                 Value = 1,
                 StringValue = "S1;M4;S1;C7;S2;C5;S1;FN1"
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaItemViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdSelCriteriaItemList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelCriteriaItemListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdSelCriteriaId == 15651618);
            Assert.Contains(result, a => a.ProdSelFieldId == 7989);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaItemViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobProdSelCriteriaItemListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelCriteriaItemViewModel> jobProdSelCriteriaItemList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaItemViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobProdSelCriteriaItemList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobProdSelCriteriaItemListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelCriteriaItemViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetProdSelMessageListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelMessageViewModel> prodSelMessageList = new List<JobService.Core.ViewModels.ProdSelMessageViewModel>()
            {
                new JobService.Core.ViewModels.ProdSelMessageViewModel()
                {
                 ProdSelCriteriaId = 15652146,
                 ProdSelMessageId = 1198717,
                 ProdSelResultId = 123,
                 ProdSelFieldId = 234,
                 LongMessage = "dfgh",
                 ShortMessage = "ab",
                 ResourceDescription = "abc",
                 MessageType = 1,
                 HqtrProdSelMessageId = 321,
                 HostUpdateInd = "y"
                }
            };
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelMessageViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(prodSelMessageList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetProdSelMessageListAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.ProdSelCriteriaId == 15652146);
            Assert.Contains(result, a => a.ProdSelMessageId == 1198717);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelMessageViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetProdSelMessageListAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.ProdSelMessageViewModel> prodSelMessageList = null;
            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelMessageViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(prodSelMessageList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetProdSelMessageListAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.ProdSelMessageViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var fixture = new Fixture();
            fixture.Customize<JobService.Core.ViewModels.JobReportView>(x => x
            .With(prop => prop.JobId, 11)
            .With(prop => prop.BuMfgLocationId, 94));

            fixture.Customize<JobService.Core.ViewModels.JobNotesView>(x => x
            .With(prop => prop.JobId, 11));

            IEnumerable<JobService.Core.ViewModels.JobReportView> jrList = fixture.CreateMany<JobService.Core.ViewModels.JobReportView>(1);
            IEnumerable<JobService.Core.ViewModels.JobNotesView> jnList = fixture.CreateMany<JobService.Core.ViewModels.JobNotesView>(1);
            JobCoordinationHistory jobCoordinationHistory = new JobCoordinationHistory()
            {
                COORDINATION_STATUS = "Submitted"
            };

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobReportView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jrList)).Verifiable();
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobNotesView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jnList)).Verifiable();
            this.repository.Setup(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>()))
             .Returns(Task.FromResult(jobCoordinationHistory));

            // Act
            var result = await this.repositoryUnderTest.GetJobAsync(11);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(jrList.First().BuMfgLocationId, result.JobOfficeAndPeople.BuMfgLocationId);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobReportView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobNotesView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobAsync_WhenJobIsCPLPAFLocked_ReturnsIsCPLPAFLocked()
        {
            // Arrange
            var fixture = new Fixture();
            fixture.Customize<JobService.Core.ViewModels.JobReportView>(x => x
            .With(prop => prop.JobId, 11)
            .With(prop => prop.IsCplpafLocked, 1));

            JobCoordinationHistory jobCoordinationHistory = null;

            IEnumerable<JobService.Core.ViewModels.JobReportView> jrList = fixture.CreateMany<JobService.Core.ViewModels.JobReportView>(1);

            this.repository.Setup(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>()))
             .Returns(Task.FromResult(jobCoordinationHistory));

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobReportView>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(jrList));

            // Act
            var result = await this.repositoryUnderTest.GetJobAsync(11);

            // Assert
            Assert.True(result.JobGeneral.IsCplpafLocked);
            Assert.Equal("Not Submitted", result.CoordinationStatus);
            this.repository.Verify(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobAsync_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var fixture = new Fixture();
            fixture.Customize<JobService.Core.ViewModels.JobReportView>(x => x
            .With(prop => prop.JobId, 11));
            IEnumerable<JobService.Core.ViewModels.JobReportView> jrList = null;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobReportView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jrList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobAsync(11);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobReportView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task LockJobAsync_ValidLockLookup_ReturnsValidData()
        {
            // Arrange
            var jobId = 12;
            string userId = "dbo";
            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(1));
            this.repository.Setup(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(userId));

            // Act
            var result = await this.repositoryUnderTest.LockJobAsync(jobId, userId);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<string>(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task LockJobAsync_LockingFailure_ReturnsEmpty()
        {
            // Arrange
            var jobId = 0;
            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(0));
            this.repository.Setup(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(string.Empty));

            // Act
            var result = await this.repositoryUnderTest.LockJobAsync(jobId, string.Empty);

            // Assert
            Assert.Empty(result);
            Assert.IsType<string>(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task UnlockJobAsync_ValidUnlock_ReturnsEmptyString()
        {
            // Arrange
            int jobId = 12;
            string userId = "xxxabc";
            bool allowLockOverride = true;

            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(0));
            this.repository.Setup(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(string.Empty));

            // Act
            var result = await this.repositoryUnderTest.UnlockJobAsync(jobId, userId, allowLockOverride);

            // Assert
            Assert.IsType<string>(result);
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task UnlockJobAsync_FailedUnlock_ReturnsEmptyString()
        {
            // Arrange
            var jobId = 12;
            string userId = "xxxabc";
            bool allowLockOverride = false;

            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(0));
            this.repository.Setup(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult("xxxzzz"));

            // Act
            var result = await this.repositoryUnderTest.UnlockJobAsync(jobId, userId, allowLockOverride);

            // Assert
            Assert.IsType<string>(result);
            Assert.Equal("xxxzzz", result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
            this.repository.Verify(x => x.GetAsync<string>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task InsertJobAsyn_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobReportId = 12;
            var bidAlternateId = 20;
            var jobList = new Job()
            {
                JOB_ID = 1,
                JOB_NAME = "Gantt Fire Dept",
                DR_ADDRESS_ID = 34,
                LOCATION_OFFICE = 100,
                DATE_CREATED = DateTime.Now,
                COMM_CODE = "DCO",
                CHECKED_IN = "y"
            };
            this.repository.Setup(x => x.ExecuteAsync<Job>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(1));

            // Act
            var result = await this.repositoryUnderTest.InsertJobAsync(jobList, jobReportId, bidAlternateId);

            // Assert
            Assert.Equal(1, result);
            this.repository.Verify(x => x.ExecuteAsync<Job>(It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(3));
        }

        [Fact]
        public async Task InsertJobAsyn_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobReportId = 0;
            var bidAlternateId = 0;
            var jobList = new Job()
            {
                JOB_ID = 1,
                JOB_NAME = "Gantt Fire Dept",
                DR_ADDRESS_ID = 34,
                LOCATION_OFFICE = 100,
                DATE_CREATED = DateTime.Now,
                COMM_CODE = "DCO",
                CHECKED_IN = "y"
            };
            this.repository.Setup(x => x.ExecuteAsync<Job>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(0));

            // Act
            var result = await this.repositoryUnderTest.InsertJobAsync(jobList, jobReportId, bidAlternateId);

            // Assert
            Assert.Equal(0, result);
            this.repository.Verify(x => x.ExecuteAsync<JobService.Core.Models.Job>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public void HonorDrAddressId_Execution()
        {
            // Arrange
            var drAddressId = 12;
            this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

            // Act
            this.repositoryUnderTest.HonorDrAddressId(drAddressId);

            // Assert
            this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
        }

        [Fact]
        public async void GetRoleTypeListAsync_ReturnsValidata()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.RoleTypeViewModel> roleTypeList = new List<JobService.Core.ViewModels.RoleTypeViewModel>
                {
                        new JobService.Core.ViewModels.RoleTypeViewModel()
                        {
                          RoleTypeId = "1",
                          RoleTypeName = "Owner"
                        },
                        new JobService.Core.ViewModels.RoleTypeViewModel()
                        {
                          RoleTypeId = "2",
                          RoleTypeName = "Architect"
                        }
                    };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.RoleTypeViewModel>(It.IsAny<string>()))
                .Returns(Task.FromResult(roleTypeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetRoleTypeListAsync();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
            Assert.True(result.Where(a => a.RoleTypeId == "1").Count() > 0);
            Assert.True(result.Where(a => a.RoleTypeName == "Architect").Count() > 0);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.RoleTypeViewModel>(It.IsAny<string>()), Times.Once);
        }

        /// <summary>
        /// Get Role Type List - EmptyList
        /// </summary>
        [Fact]
        public async void GetRoleTypeListAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.RoleTypeViewModel> roleTypeList = new List<JobService.Core.ViewModels.RoleTypeViewModel>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.RoleTypeViewModel>(It.IsAny<string>()))
             .Returns(Task.FromResult(roleTypeList)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetRoleTypeListAsync();

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.RoleTypeViewModel>(It.IsAny<string>()), Times.Once);
        }

        /// <summary>
        /// Get price auth information using valid input returns price auth id
        /// </summary>
        [Fact]
        public async void GetPriceAuthInfo_ValidInput_ReturnsPriceAuthInfo()
        {
            // Arrange
            int jobId = 15094;
            int priceAuthId = 1082226;

            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(priceAuthId));

            // Act
            var result = await this.repositoryUnderTest.GetPriceAuthInfo(jobId);

            // Assert
            Assert.IsType<int>(result);
            Assert.Equal(priceAuthId, result);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get price auth information using valid input returns no data
        /// </summary>
        [Fact]
        public async void GetPriceAuthInfo_ValidInput_ReturnsNoData()
        {
            // Arrange
            int jobId = 1;
            int priceAuthId = 0;
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(priceAuthId));

            // Act
            var result = await this.repositoryUnderTest.GetPriceAuthInfo(jobId);

            // Assert
            Assert.IsType<int>(result);
            Assert.Equal(priceAuthId, result);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get SPA dead line using valid input -  returns the valid SPA deadline data
        /// </summary>
        /// <returns>SPA deadline</returns>
        [Fact]
        public async Task GetSPADeadline_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 139575;

            SpaDeadline spaDeadline = new SpaDeadline { ShipQtr = 4, ShipYear = 2020 };

            this.repository.Setup(x => x.ExecuteQuery<SpaDeadline>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(spaDeadline));

            // Act
            var result = await this.repositoryUnderTest.GetSPADeadline(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(spaDeadline.ShipYear, result.ShipYear);
            Assert.Equal(spaDeadline.ShipQtr, result.ShipQtr);
            this.repository.Verify(x => x.ExecuteQuery<JobService.Core.Models.SpaDeadline>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get SPA dead line using invalid input -  returns the no data
        /// </summary>
        /// <returns>SPA deadline</returns>
        [Fact]
        public async Task GetSPADeadline_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 0;
            SpaDeadline spaDeadline = null;

            this.repository.Setup(x => x.ExecuteQuery<SpaDeadline>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(spaDeadline));

            // Act
            var result = await this.repositoryUnderTest.GetSPADeadline(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteQuery<SpaDeadline>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSPAQuery_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 11466;
            string spaNumber = "11_111";
            this.repository.Setup(x => x.ExecuteQuery<string>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(spaNumber));

            // Act
            var result = await this.repositoryUnderTest.GetSPAQuery(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result, spaNumber);
            this.repository.Verify(x => x.ExecuteQuery<string>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get locked user details using invalid input -  returns the no data
        /// </summary>
        /// <returns>No records</returns>
        [Fact]
        public async Task GetJobLockedUserDetails_InvalidInput_ReturnsNoData()
        {
            // Arrange
            var jobId = 25107;
            JobService.Core.ViewModels.JobLockedUserView userView = null;
            this.repository.Setup(x => x.ExecuteQuery<JobService.Core.ViewModels.JobLockedUserView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(userView)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobLockedUserDetailsAsync(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteQuery<JobService.Core.ViewModels.JobLockedUserView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get locked user details using valid input -  returns job locked user details
        /// </summary>
        /// <returns>Job locked user details</returns>
        [Fact]
        public async Task GetJobLockedUserDetails_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 1830;
            JobService.Core.ViewModels.JobLockedUserView userView = new JobService.Core.ViewModels.JobLockedUserView()
            {
                UserId = "lalcj",
                FirstName = "David",
                LastName = "Harper",
                UserName = "Harper, David",
            };
            this.repository.Setup(x => x.ExecuteQuery<JobService.Core.ViewModels.JobLockedUserView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(userView)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobLockedUserDetailsAsync(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.UserId == "lalcj");
            Assert.True(result.UserName == "Harper, David");
            this.repository.Verify(x => x.ExecuteQuery<JobService.Core.ViewModels.JobLockedUserView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetCommercialLaborRate_Input_ReturnsDecimalRate()
        {
            // Arrange
            int jobId = 100;
            decimal laborRate = 12.34M;

            this.repository.Setup(x => x.ExecuteQuery<decimal>(It.IsAny<string>(), It.IsAny<object>()))
                            .Returns(Task.FromResult(laborRate));

            // Act
            decimal result = await this.repositoryUnderTest.GetCommercialLaborRateAsync(jobId);

            // Assert
            Assert.Equal(laborRate, result);
            this.repository.Verify(x => x.ExecuteQuery<decimal>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDesignAuths_AnyJobId_ReturnsDesignAuthRecords()
        {
            // Arrange
            IEnumerable<DesignAuth> designAuths =
                new List<DesignAuth>()
                {
                    new DesignAuth()
                    {
                         SELECTION_ID = 1, SHORT_DESIGN_DESCR = "Derp", VPC_ID = 2, HQTR_DESIGN_AUTH_ID = 200, PROD_FAMILY_ID = 28
                    }
                };
            this.repository.Setup(r => r.ExecuteListQuery<DesignAuth>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(designAuths));

            // Act
            IEnumerable<DesignAuth> result = await this.repositoryUnderTest.GetDesignAuths(this.jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal(designAuths, result);
        }

        [Fact]
        public async Task UpdateJobInfo()
        {
            // Arrange
            int updated = 1;
            var jobGeneral = new JobService.Core.ViewModels.JobGeneralView()
            {
                JobId = 178456,
                JobReportId = 40382,
                JobName = "Trane",
                DrAddressId = 94,
                Status = "P"
            };
            int jobId = 178456;
            this.repository.Setup(x => x.UpdateAsync(It.IsAny<JobService.Core.ViewModels.JobGeneralView>()))
                .Returns(Task.FromResult(updated));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobInfo(jobGeneral, jobId);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.UpdateAsync(It.IsAny<JobService.Core.ViewModels.JobGeneralView>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobModifiedDate()
        {
            // Arrange
            int updated = 1;
            int jobId = 178456;
            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(updated));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobModifiedDate(jobId);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobModifiedDate_ValidInput_ReturnsTrue()
        {
            // Arrange
            int updatedRowCount = 1;
            int jobId = 178456;
            DateTime lastUpdate = DateTime.UtcNow;

            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(updatedRowCount));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobModifiedDate(jobId, lastUpdate);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task UpdateJobModifiedDate_JobIdNotExist_ReturnsFalse()
        {
            // Arrange
            int updatedRowCount = 0;
            int jobId = 178456;
            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(updatedRowCount));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobModifiedDate(jobId);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetVariations_RepoHasNoVariations_ReturnsEmptyList()
        {
            this.repository.Setup(r => r.ExecuteListQuery<Variation>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(Enumerable.Empty<Variation>()));

            IEnumerable<Variation> result = await this.repositoryUnderTest.GetVariationsAsync(this.jobId);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetVariations_RepoHasVariations_ReturnsThem()
        {
            IEnumerable<Variation> sampleVariations = new Variation[]
            {
                new Variation() { DESCRIPTION = "JobLevelExample", SELECTION_ID = null, VARIATION_ID = 1, PRODUCT_ID = 01, VENDOR_ID = 100, PROD_CODE = "600", SALES_ORD_ID = 1 },
                new Variation() { DESCRIPTION = "SelectionLevelExample", SELECTION_ID = 2, VARIATION_ID = 3, PRODUCT_ID = 02, VENDOR_ID = 101, PROD_CODE = "601", SALES_ORD_ID = null }
            };

            this.repository.Setup(r => r.ExecuteListQuery<Variation>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(sampleVariations));

            IEnumerable<Variation> result = await this.repositoryUnderTest.GetVariationsAsync(this.jobId);

            Assert.NotNull(result);
            Assert.Equal(sampleVariations, result);
        }

        [Fact]
        public async Task GetVariationReferenceUnits_RepoDoesntHaveRefUnits_ReturnsEmptyList()
        {
            this.repository.Setup(r => r.ExecuteListQuery<VariationReferenceUnit>(It.IsAny<string>(), It.IsAny<object>()))
               .Returns(Task.FromResult(Enumerable.Empty<VariationReferenceUnit>()));

            IEnumerable<VariationReferenceUnit> result = await this.repositoryUnderTest.GetVariationReferenceUnitsAsync(this.jobId);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetVariationReferenceUnits_RepoDoesHaveRefUnits_ReturnsThem()
        {
            IEnumerable<VariationReferenceUnit> sampleRefUnits = new VariationReferenceUnit[]
            {
                new VariationReferenceUnit() { TAG = "SomeTag", VARIATION_ID = 1 }
            };

            this.repository.Setup(r => r.ExecuteListQuery<VariationReferenceUnit>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(sampleRefUnits));

            IEnumerable<VariationReferenceUnit> result = await this.repositoryUnderTest.GetVariationReferenceUnitsAsync(this.jobId);

            Assert.NotNull(result);
            Assert.Equal(sampleRefUnits, result);
        }

        /// <summary>
        /// Gets the job coordination general information for job id
        /// </summary>
        /// <returns>Job coordination general information</returns>
        [Fact]
        public async Task GetJobGeneralInfoForCoordination_RepoHasJobDetails_ReturnsJobCoordinationData()
        {
            // Arrange
            JobGeneralInfoModel jobDetails = Helper.GetJobGeneralInfoForCoordination();

            this.repository.Setup(x => x.ExecuteQuery<JobGeneralInfoModel>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobDetails));

            // Act
            var result = await this.repositoryUnderTest.GetJobGeneralInfoForCoordination(this.jobId);

            // Assert
            Assert.Equal(result, jobDetails);
            this.repository.Verify(x => x.ExecuteQuery<JobGeneralInfoModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Gets the job coordination general information for job id - Returns null
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetJobGeneralInfoForCoordination_RepoDoesNotHaveJobDetails_ReturnsNull()
        {
            // Arrange
            JobGeneralInfoModel jobDetails = null;
            this.repository.Setup(x => x.ExecuteQuery<JobGeneralInfoModel>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobDetails));

            // Act
            var result = await this.repositoryUnderTest.GetJobGeneralInfoForCoordination(this.jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteQuery<JobGeneralInfoModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Gets the job notes for job id
        /// </summary>
        /// <returns>Job notes</returns>
        [Fact]
        public async Task GetJobNotesForCoordination_RepoHasJobNotes_ReturnsJobNotes()
        {
            // Arrange
            JobNotes jobNotes = Helper.GetJobNotes();
            this.repository.Setup(x => x.ExecuteQuery<JobNotes>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobNotes));

            // Act
            var result = await this.repositoryUnderTest.GetJobNotesForCoordination(this.jobId);

            // Assert
            Assert.Equal(result, jobNotes);
            this.repository.Verify(x => x.ExecuteQuery<JobNotes>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Gets the job notes for job id - Returns null
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetJobNotesForCoordination_RepoDoesNotHaveJobNotes_ReturnsNull()
        {
            // Arrange
            JobNotes jobNotes = null;
            this.repository.Setup(x => x.ExecuteQuery<JobNotes>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobNotes));

            // Act
            var result = await this.repositoryUnderTest.GetJobNotesForCoordination(this.jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteQuery<JobNotes>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetVariationListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.JobVariationViewModel> variations = new List<JobService.Core.ViewModels.JobVariationViewModel>()
            {
                new JobService.Core.ViewModels.JobVariationViewModel()
                {
                    VariationId = 3616,
                    NetPrice = 4860,
                    VariationType = "L",
                    ShortDesc = "ATSC",
                    VariationProdCode = 5119
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobVariationViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(variations)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetVariationListAsync(jobId);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.VariationId == 3616);
            Assert.Contains(result, a => a.ShortDesc == "ATSC");
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobVariationViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetVariationListAsync_HasNoDataForJobId_ReturnsEmptyResult()
        {
            // Arrange
            var jobId = 165009;
            IEnumerable<JobService.Core.ViewModels.JobVariationViewModel> variations = new List<JobService.Core.ViewModels.JobVariationViewModel>();
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobVariationViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(variations)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetVariationListAsync(jobId);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobVariationViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDesignAuthListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.SelectionDesignAuthViewModel> designAuths = new List<JobService.Core.ViewModels.SelectionDesignAuthViewModel>()
            {
                new JobService.Core.ViewModels.SelectionDesignAuthViewModel()
                {
                    DesignAuthId = 701,
                    SeparateCreditJob = "0",
                    SelectionId = 20205,
                    ShortDesignDescr = "Provide Baldor Inverter Duty Motors clas"
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionDesignAuthViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(designAuths)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetDesignAuthListAsync(jobId);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.DesignAuthId == 701);
            Assert.Contains(result, a => a.SelectionId == 20205);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionDesignAuthViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDesignAuthListAsync_HasNoDataForJobId_ReturnsEmptyResult()
        {
            // Arrange
            var jobId = 165009;
            IEnumerable<JobService.Core.ViewModels.SelectionDesignAuthViewModel> designAuths = new List<JobService.Core.ViewModels.SelectionDesignAuthViewModel>();
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionDesignAuthViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(designAuths)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetDesignAuthListAsync(jobId);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionDesignAuthViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDesignAuthNoteListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 25107;
            IEnumerable<JobService.Core.ViewModels.DesignAuthNoteViewModel> designAuthNotes = new List<JobService.Core.ViewModels.DesignAuthNoteViewModel>()
            {
                new JobService.Core.ViewModels.DesignAuthNoteViewModel()
                {
                    DesignAuthId = 701,
                    HostUpdateInd = null,
                    SequenceNbr = 1,
                    NoteLine = @"Provide Baldor Inverter Duty Motors class H insulation motors 
                                 > 20.0 HP: IDNM"
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.DesignAuthNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(designAuthNotes)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetDesignAuthNoteListAsync(jobId);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.DesignAuthId == 701);
            Assert.Contains(result, a => a.SequenceNbr == 1);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.DesignAuthNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDesignAuthNoteListAsync_HasNoDataForJobId_ReturnsEmptyResult()
        {
            // Arrange
            var jobId = 165009;
            IEnumerable<JobService.Core.ViewModels.DesignAuthNoteViewModel> designAuthNotes = new List<JobService.Core.ViewModels.DesignAuthNoteViewModel>();
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.DesignAuthNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(designAuthNotes)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetDesignAuthNoteListAsync(jobId);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.DesignAuthNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// GetJobsByNameOrOppyId called with valid search text and jobs exist
        /// </summary>
        /// <returns>IEnumerable of JobOpportunity models</returns>
        [Fact]
        public async Task GetJobsByNameOrOppyId_JobsExist_ReturnsJobs()
        {
            // Arrange
            var fixture = new Fixture();
            var jobs = fixture.CreateMany<JobOpportunity>(2);
            this.repository.Setup(x => x.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(jobs));

            // Act
            var result = await this.repositoryUnderTest.GetJobsByNameOrOppyId("Dallas", false);

            // Assert
            Assert.Equal(result, jobs);
            this.repository.Verify(x => x.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// GetJobsByNameOrOppyId called with valid search text and jobs do not exist
        /// </summary>
        /// <returns>Empty list</returns>
        [Fact]
        public async Task GetJobsByNameOrOppyId_NoJobsExist_ReturnsEmptyCollection()
        {
            // Arrange
            this.repository.Setup(x => x.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(Enumerable.Empty<JobOpportunity>()));

            // Act
            var result = await this.repositoryUnderTest.GetJobsByNameOrOppyId("Houston_", true);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobOpportunity>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSelectionNoteListAsync_ValidInput_ReturnsValidData()
        {
            // Arrange
            var jobId = 217;
            IEnumerable<JobService.Core.ViewModels.SelectionNoteViewModel> selectionNotes = new List<JobService.Core.ViewModels.SelectionNoteViewModel>()
            {
                new JobService.Core.ViewModels.SelectionNoteViewModel()
                {
                    SelectionId = 1470,
                    SequenceNbr = 1,
                    NoteLine = "THE COVER TAGGED TYPE A MUST HAVE THE RETURN LINE HANGER WELDED INSIDE"
                }
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(selectionNotes)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetSelectionNoteListAsync(jobId);

            // Assert
            Assert.True(result.Count() == 1);
            Assert.Contains(result, a => a.SelectionId == 1470);
            Assert.Contains(result, a => a.SequenceNbr == 1);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSelectionNoteListAsync_HasNoDataForJobId_ReturnsEmptyResult()
        {
            // Arrange
            var jobId = 9745;
            IEnumerable<JobService.Core.ViewModels.SelectionNoteViewModel> selectionNotes = new List<JobService.Core.ViewModels.SelectionNoteViewModel>();
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(selectionNotes)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetSelectionNoteListAsync(jobId);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.SelectionNoteViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Verifies for the job coordination history - success
        /// </summary>
        /// <returns>Job coordination history</returns>
        [Fact]
        public async Task GetJobCoordinationHistory_ValidInputHasJobCoordinationHistory_ReturnsJobCoordinationHistory()
        {
            // Arrange
            int jobId = 1011;
            IEnumerable<JobCoordinationHistory> expectedJobCoordinationHistory = new List<JobCoordinationHistory>()
            {
                Helper.GetJobCoordinationHistory(jobId, 1, "Not Submitted")
            };
            this.repository.Setup(x => x.ExecuteListQuery<JobCoordinationHistory>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(expectedJobCoordinationHistory));

            // Act
            var result = await this.repositoryUnderTest.GetJobCoordinationHistory(jobId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(result.First().COORDINATION_STATUS, expectedJobCoordinationHistory.First().COORDINATION_STATUS);
            this.repository.Verify(x => x.ExecuteListQuery<JobCoordinationHistory>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Verifies for the true result if the draft record is inserted successfully
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task InsertDraftRecord_ValidInput_ReturnsTrue()
        {
            // Arrange
            int jobId = 1;
            int coordinationId = 1;
            string coordinationStatus = "Not Submitted";
            JobCoordinationHistory jobCoordinationHistory = Helper.GetJobCoordinationHistory(jobId, coordinationId, coordinationStatus);
            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(1));

            // Act
            var result = await this.repositoryUnderTest.InsertDraftRecord(jobCoordinationHistory);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Verifies for the false result if the draft record is not inserted
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task InsertDraftRecord_InvalidInput_ReturnsFalse()
        {
            // Arrange
            int jobId = 10;
            int coordinationId = 12;
            string coordinationStatus = "Not Coordinated";
            JobCoordinationHistory jobCoordinationHistory = Helper.GetJobCoordinationHistory(jobId, coordinationId, coordinationStatus);
            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(0));

            // Act
            var result = await this.repositoryUnderTest.InsertDraftRecord(jobCoordinationHistory);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Verifies getting date from database
        /// </summary>
        /// <returns>Database date</returns>
        [Fact]
        public async Task GetDbDate_ReturnsDBDate()
        {
            // Arrange
            DateTime dateTime = DateTime.Parse("09/30/2019");
            this.repository.Setup(x => x.ExecuteQuery<DateTime>(It.IsAny<string>())).Returns(Task.FromResult(dateTime));

            // Act
            var result = await this.repositoryUnderTest.GetDbDate();

            // Assert
            Assert.Equal(result, dateTime);
            this.repository.Verify(x => x.ExecuteQuery<DateTime>(It.IsAny<string>()), Times.Once);
        }

        /// <summary>
        /// Gets the coordination data for coordination id
        /// </summary>
        /// <returns>Coordination data</returns>
        [Fact]
        public async Task GetCoordinationData_ValidCoordinationId_ReturnsCoordinationData()
        {
            // Arrange
            int coordinationId = 100;
            JobCoordinationHistory coordinationData = Helper.GetJobCoordinationHistory();
            this.repository.Setup(x => x.ExecuteQuery<JobCoordinationHistory>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(coordinationData));

            // Act
            var result = await this.repositoryUnderTest.GetCoordinationData(coordinationId);

            // Assert
            Assert.Equal(result.COMMISSION_CODE, coordinationData.COMMISSION_CODE);
            Assert.Equal(result.ICS_JOB_INDICATOR, coordinationData.ICS_JOB_INDICATOR);
            Assert.Equal(result.QUICK_TURNAROUND_IND, coordinationData.QUICK_TURNAROUND_IND);
            Assert.Equal(result.COORDINATION_JOB_SUB_NOTES, coordinationData.COORDINATION_JOB_SUB_NOTES);
            this.repository.Verify(x => x.ExecuteQuery<JobCoordinationHistory>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get job coordination contact details - success
        /// </summary>
        /// <returns>Job coordination contact details</returns>
        [Fact]
        public async Task GetJobCoordinationContactDetails_ValidInputHasContactDetails_ReturnsJobCoordinationContactDetails()
        {
            // Arrange
            int jobId = 10;
            JobCoordinationContactDetails jobCoordinationContactDetails = Helper.GetJobCoordinationContactDetails();
            this.repository.Setup(x => x.ExecuteQuery<JobCoordinationContactDetails>(JobRepositoryQueries.JobCoordinationContactDetailsSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(jobCoordinationContactDetails));

            // Act
            var result = await this.repositoryUnderTest.GetJobCoordinationContactDetails(jobId);

            // Assert
            Assert.Equal(result, jobCoordinationContactDetails);
            this.repository.Verify(x => x.ExecuteQuery<JobCoordinationContactDetails>(JobRepositoryQueries.JobCoordinationContactDetailsSelectQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Updates job coordination general information - success
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobCoordinationGeneralInformation_ValidInput_ReturnsTrue()
        {
            // Arrange
            int coordinationId = 1;
            string modifiedByUserId = "dummy";
            JobGeneralInfoModel jobGeneralInfoModel = Helper.GetJobGeneralInfoForCoordination();
            this.repository.Setup(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationGeneralInfoUpdateQuery, It.IsAny<object>())).Returns(Task.FromResult(1));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobCoordinationGeneralInformation(jobGeneralInfoModel, modifiedByUserId, coordinationId);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationGeneralInfoUpdateQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Updates job coordination general information - failure
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobCoordinationGeneralInformation_InvalidInput_ReturnsFalse()
        {
            // Arrange
            int coordinationId = 1000;
            string modifiedByUserId = "dummy";
            JobGeneralInfoModel jobGeneralInfoModel = Helper.GetJobGeneralInfoForCoordination();
            this.repository.Setup(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationGeneralInfoUpdateQuery, It.IsAny<object>())).Returns(Task.FromResult(0));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobCoordinationGeneralInformation(jobGeneralInfoModel, modifiedByUserId, coordinationId);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationGeneralInfoUpdateQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Has no active coordination - coordination status is in "Pending Pricing/Escalated/Escalation Complete"
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task HasNoActiveCoordination_InvalidCoordinationStatus_ReturnsFalse()
        {
            // Arrange
            int jobId = 123;
            this.repository.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.ActiveJobCoordinationRequestCountSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(1));

            // Act
            var hasActiveCoordination = await this.repositoryUnderTest.HasNoActiveCoordination(jobId);

            // Assert
            Assert.False(hasActiveCoordination);
            this.repository.Verify(x => x.ExecuteQuery<int>(JobRepositoryQueries.ActiveJobCoordinationRequestCountSelectQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Has no active coordination request - coordination status is not in "Pending Pricing/Escalated/Escalation Complete"
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task HasNoActiveCoordination_ValidCoordinationStatus_ReturnsTrue()
        {
            // Arrange
            int jobId = 1234;
            this.repository.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.ActiveJobCoordinationRequestCountSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(0));

            // Act
            var hasActiveCoordination = await this.repositoryUnderTest.HasNoActiveCoordination(jobId);

            // Assert
            Assert.True(hasActiveCoordination);
            this.repository.Verify(x => x.ExecuteQuery<int>(JobRepositoryQueries.ActiveJobCoordinationRequestCountSelectQuery, It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobIds_ValidRequest_ReuturnJobIds()
        {
            // Arrange
            string crmOppyId = "34";
            IEnumerable<int> jobIds = new List<int>()
            {
                { 67 }, { 90 }
            };
            this.repository.Setup(x => x.ExecuteListQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobIds)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobIds(crmOppyId);

            // Assert
            Assert.Equal(result, jobIds);
            this.repository.Verify();
        }

        /// <summary>
        /// Get submission notes until last submission - success
        /// </summary>
        /// <returns>Submission notes</returns>
        [Fact]
        public async Task GetSubmissionNotesUntilLastSubmission_ValidJobId_ReturnsSubmissionNotes()
        {
            // Arrange
            int jobId = 123;
            JobCoordinationHistory jobCoordinationHistory = new JobCoordinationHistory()
            {
                COORDINATION_JOB_SUB_NOTES = Encoding.UTF8.GetBytes("This is a test"),
            };
            this.repository.Setup(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>())).Returns(Task.FromResult(jobCoordinationHistory));

            // Act
            var result = await this.repositoryUnderTest.GetSubmissionNotesUntilLastSubmission(jobId);

            // Assert
            Assert.Equal(result, jobCoordinationHistory.COORDINATION_JOB_SUB_NOTES);
            this.repository.Verify(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get submission notes until last submission - success - null submission notes
        /// </summary>
        /// <returns>Empty submission notes</returns>
        [Fact]
        public async Task GetSubmissionNotesUntilLastSubmission_ValidJobIdHasNullSubmissionNotes_ReturnsSubmissionNotes()
        {
            // Arrange
            int jobId = 123;
            JobCoordinationHistory jobCoordinationHistory = new JobCoordinationHistory()
            {
                COORDINATION_JOB_SUB_NOTES = Encoding.UTF8.GetBytes(string.Empty),
            };
            this.repository.Setup(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>())).Returns(Task.FromResult(jobCoordinationHistory));

            // Act
            var result = await this.repositoryUnderTest.GetSubmissionNotesUntilLastSubmission(jobId);

            // Assert
            Assert.Equal(result, Array.Empty<byte>());
            this.repository.Verify(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get submission notes until last submission - success - null job coordination history
        /// </summary>
        /// <returns>Empty submission notes</returns>
        [Fact]
        public async Task GetSubmissionNotesUntilLastSubmission_ValidJobIdHasNullJobCoordinationHistory_ReturnsEmptySubmissionNotes()
        {
            // Arrange
            int jobId = 123;
            JobCoordinationHistory jobCoordinationHistory = null;
            this.repository.Setup(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>())).Returns(Task.FromResult(jobCoordinationHistory));

            // Act
            var result = await this.repositoryUnderTest.GetSubmissionNotesUntilLastSubmission(jobId);

            // Assert
            Assert.Equal(result, Array.Empty<byte>());
            this.repository.Verify(x => x.ExecuteQuery<JobCoordinationHistory>(JobRepositoryQueries.JobCoordinationHistoryUntilLastSubmission, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Tests if update to CPLPAF lock returns true when rows modified
        /// </summary>
        /// <returns>A task</returns>
        [Fact]
        public async Task UpdateCplpafLock_WithConditionsForRowsToBeModified_ReturnsRowsModifiedSuccess()
        {
            // Arrange
            int jobId = 123;
            bool lockValue = true;

            this.repository.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.UpdateCplpafLockQuery, It.IsAny<object>()))
                .Returns(Task.FromResult<int>(1));

            // Act
            var rowsWereModified = await this.repositoryUnderTest.UpdateCplpafLock(jobId, lockValue);

            // Assert
            Assert.True(rowsWereModified);
            this.repository.Verify(x => x.ExecuteQuery<int>(JobRepositoryQueries.UpdateCplpafLockQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Tests if update to CPLPAF lock returns false when rows not modified
        /// </summary>
        /// <returns>A task</returns>
        [Fact]
        public async Task UpdateCplpafLock_WithConditionsForRowsNotToBeModified_ReturnsRowsModifiedFailure()
        {
            // Arrange
            int jobId = 123;
            bool lockValue = true;

            this.repository.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.UpdateCplpafLockQuery, It.IsAny<object>()))
                .Returns(Task.FromResult<int>(0));

            // Act
            var rowsWereModified = await this.repositoryUnderTest.UpdateCplpafLock(jobId, lockValue);

            // Assert
            Assert.False(rowsWereModified);
            this.repository.Verify(x => x.ExecuteQuery<int>(JobRepositoryQueries.UpdateCplpafLockQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get the submitted bids - Success
        /// </summary>
        /// <returns>Bids</returns>
        [Fact]
        public async Task GetSubmittedBids_ValidInput_ReturnsBids()
        {
            // Arrange
            int jobId = 123;
            IEnumerable<byte[]> submittedBids = new List<byte[]>
            {
               Encoding.ASCII.GetBytes(@"[
                                          {
                                            'BID_ALTERNATE_ID'     : 1234,
                                            'BID_ALTERNATE_NAME'   : 'abc'
                                          }]")
            };
            this.repository.Setup(x => x.ExecuteListQuery<byte[]>(JobRepositoryQueries.BidsUntilLastSubmissionSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(submittedBids));

            // Act
            var result = await this.repositoryUnderTest.GetSubmittedBids(jobId);

            // Assert
            Assert.Equal(result.ToList(), submittedBids);
            this.repository.Verify(x => x.ExecuteListQuery<byte[]>(JobRepositoryQueries.BidsUntilLastSubmissionSelectQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get the submitted bids - No content
        /// </summary>
        /// <returns>No content</returns>
        [Fact]
        public async Task GetSubmittedBids_ValidInput_ReturnsNull()
        {
            // Arrange
            int jobId = 123;
            IEnumerable<byte[]> submittedBids = null;
            this.repository.Setup(x => x.ExecuteListQuery<byte[]>(JobRepositoryQueries.BidsUntilLastSubmissionSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(submittedBids));

            // Act
            var result = await this.repositoryUnderTest.GetSubmittedBids(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteListQuery<byte[]>(JobRepositoryQueries.BidsUntilLastSubmissionSelectQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Updates job coordination history information - success
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobCoordinationHistory_ValidInput_ReturnsTrue()
        {
            // Arrange
            int coordinationId = 1;
            string modifiedByUserId = "abcd";
            this.repository.Setup(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationHistoryUpdateQuery, It.IsAny<object>())).Returns(Task.FromResult(1));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobCoordinationHistory(coordinationId, modifiedByUserId);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationHistoryUpdateQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Updates job coordination history information - failure
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobCoordinationHistory_InValidInput_ReturnsFalse()
        {
            // Arrange
            int coordinationId = 10000;
            string modifiedByUserId = "abcd";
            this.repository.Setup(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationHistoryUpdateQuery, It.IsAny<object>())).Returns(Task.FromResult(0));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobCoordinationHistory(coordinationId, modifiedByUserId);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationHistoryUpdateQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Updates job coordination status - success
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobCoordinationStatus_ValidInput_ReturnsTrue()
        {
            // Arrange
            int coordinationId = 1;
            string coordinationStatus = "Recoordinated";
            this.repository.Setup(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationStatusUpdateQuery, It.IsAny<object>())).Returns(Task.FromResult(1));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobCoordinationStatus(coordinationId, coordinationStatus);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationStatusUpdateQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Updates job coordination status - failure
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobCoordinationStatus_InValidInput_ReturnsFalse()
        {
            // Arrange
            int coordinationId = 10000;
            string coordinationStatus = "Recoordinated";
            this.repository.Setup(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationStatusUpdateQuery, It.IsAny<object>())).Returns(Task.FromResult(0));

            // Act
            var result = await this.repositoryUnderTest.UpdateJobCoordinationStatus(coordinationId, coordinationStatus);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteAsync<int>(JobRepositoryQueries.JobCoordinationStatusUpdateQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get the submitted job coordination id - Success
        /// </summary>
        /// <returns>Coordination id</returns>
        [Fact]
        public async Task GetSubmittedJobCoordinationId_ValidInput_ReturnsCoordinationId()
        {
            // Arrange
            int submittedCoordinationId = 1;
            int jobId = 1234;
            this.repository.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.SubmittedJobCoordinationIdSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(submittedCoordinationId));

            // Act
            var result = await this.repositoryUnderTest.GetSubmittedJobCoordinationId(jobId);

            // Assert
            Assert.Equal(result, submittedCoordinationId);
            this.repository.Verify(x => x.ExecuteQuery<int>(JobRepositoryQueries.SubmittedJobCoordinationIdSelectQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get the submitted job coordination id - Failure
        /// </summary>
        /// <returns>Coordination id</returns>
        [Fact]
        public async Task GetSubmittedJobCoordinationId_ValidInput_ReturnsZero()
        {
            // Arrange
            int submittedCoordinationId = 0;
            int jobId = 567;
            this.repository.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.SubmittedJobCoordinationIdSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(submittedCoordinationId));

            // Act
            var result = await this.repositoryUnderTest.GetSubmittedJobCoordinationId(jobId);

            // Assert
            Assert.Equal(result, submittedCoordinationId);
            this.repository.Verify(x => x.ExecuteQuery<int>(JobRepositoryQueries.SubmittedJobCoordinationIdSelectQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get submission notes for last submission - success
        /// </summary>
        /// <returns>Submission notes</returns>
        [Fact]
        public async Task GetSubmissionNotesForLastSubmission_ValidJobId_ReturnsSubmissionNotes()
        {
            // Arrange
            int jobId = 123;
            string submissionNotes = "This is a test";
            this.repository.Setup(x => x.ExecuteQuery<byte[]>(JobRepositoryQueries.SubmissionNotesForLastSubmission, It.IsAny<object>())).Returns(Task.FromResult(Encoding.UTF8.GetBytes(submissionNotes)));

            // Act
            var result = await this.repositoryUnderTest.GetSubmissionNotesForLastSubmission(jobId);

            // Assert
            Assert.Equal(result, Encoding.UTF8.GetBytes(submissionNotes));
            this.repository.Verify(x => x.ExecuteQuery<byte[]>(JobRepositoryQueries.SubmissionNotesForLastSubmission, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get submission notes until for submission - success - returns null
        /// </summary>
        /// <returns>Empty submission notes</returns>
        [Fact]
        public async Task GetSubmissionNotesForLastSubmission_ValidJobIdHasNullSubmissionNotes_ReturnsSubmissionNotes()
        {
            // Arrange
            int jobId = 123;
            this.repository.Setup(x => x.ExecuteQuery<byte[]>(JobRepositoryQueries.SubmissionNotesForLastSubmission, It.IsAny<object>())).Returns(Task.FromResult<byte[]>(null));

            // Act
            var result = await this.repositoryUnderTest.GetSubmissionNotesForLastSubmission(jobId);

            // Assert
            Assert.Equal(result, Array.Empty<byte>());
            this.repository.Verify(x => x.ExecuteQuery<byte[]>(JobRepositoryQueries.SubmissionNotesForLastSubmission, It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetJobsAsync_GivenSearch_CallsExecuteListQueryWithParameters()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.JobReportView> contactList = new List<JobService.Core.ViewModels.JobReportView>();
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.JobReportView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(contactList)).Verifiable();
            var filter = new JobSearch() { HqtrJobId = 1 };

            // Act
            var result = await this.repositoryUnderTest.GetJobsAsync(filter);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(r => r.ExecuteListQuery<JobService.Core.ViewModels.JobReportView>(It.IsAny<string>(), filter), Times.Once);
        }

        /// <summary>
        /// Verifies for the spa price protected selection details
        /// </summary>
        /// <returns>Spa price protected selection details</returns>
        [Fact]
        public async Task GetSpaSelectionPriceProtectionDetails_HasSpaPriceProtectedSelections_ReturnsSpaSelectedPriceProtectionDetails()
        {
            // Arrange
            IEnumerable<SelectionPriceProtectionDetail> selectionPriceProtectionDetails = new List<SelectionPriceProtectionDetail>()
            {
                Helper.GetSelectionPriceProtectionDetail(1, 43216)
            };
            this.repository.Setup(x => x.ExecuteListQuery<SelectionPriceProtectionDetail>(JobRepositoryQueries.SpaSelectionPriceProtectionDetailSelectQuery, It.IsAny<object>()))
                           .Returns(Task.FromResult(selectionPriceProtectionDetails));

            // Act
            var result = await this.repositoryUnderTest.GetSpaSelectionPriceProtectionDetails(this.jobId);

            // Assert
            Assert.Equal(result, selectionPriceProtectionDetails);
            this.repository.Verify(
                x => x.ExecuteListQuery<SelectionPriceProtectionDetail>(
                    JobRepositoryQueries.SpaSelectionPriceProtectionDetailSelectQuery,
                    It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == this.jobId)),
                Times.Once);
        }

        /// <summary>
        /// Verifies for the non spa price protected selection details
        /// </summary>
        /// <returns>Non spa price protected selection details</returns>
        [Fact]
        public async Task GetNonSpaSelectionPriceProtectionDetails_HasNonSpaPriceProtectedSelections_ReturnsNonSpaSelectedPriceProtectionDetails()
        {
            // Arrange
            IEnumerable<SelectionPriceProtectionDetail> selectionPriceProtectionDetails = new List<SelectionPriceProtectionDetail>()
            {
                Helper.GetSelectionPriceProtectionDetail(1, 43216)
            };
            this.repository.Setup(x => x.ExecuteListQuery<SelectionPriceProtectionDetail>(JobRepositoryQueries.NonSpaSelectionPriceProtectionDetailSelectQuery, It.IsAny<object>()))
                           .Returns(Task.FromResult(selectionPriceProtectionDetails));

            // Act
            var result = await this.repositoryUnderTest.GetNonSpaSelectionPriceProtectionDetails(this.jobId);

            // Assert
            Assert.Equal(result, selectionPriceProtectionDetails);
            this.repository.Verify(
                x => x.ExecuteListQuery<SelectionPriceProtectionDetail>(
                    JobRepositoryQueries.NonSpaSelectionPriceProtectionDetailSelectQuery,
                    It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == this.jobId)),
                Times.Once);
        }

        /// <summary>
        /// Verifies for the job selection ids
        /// </summary>
        /// <returns>Job selection ids</returns>
        [Fact]
        public async Task GetJobSelectionIds_JobHasSelectionIds_ReturnsJobSelectionIds()
        {
            // Arrange
            IEnumerable<int> jobSelectionIds = new List<int>()
            {
                1, 2, 3
            };
            this.repository.Setup(x => x.ExecuteListQuery<int>(JobRepositoryQueries.JobSelectionIdsSelectQuery, It.IsAny<object>()))
                           .Returns(Task.FromResult(jobSelectionIds));

            // Act
            var result = await this.repositoryUnderTest.GetJobSelectionIds(this.jobId);

            // Assert
            Assert.Equal(jobSelectionIds, result);
            this.repository.Verify(
                x => x.ExecuteListQuery<int>(
                    JobRepositoryQueries.JobSelectionIdsSelectQuery,
                    It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == this.jobId)), Times.Once);
        }

        /// <summary>
        /// Verifies get job basic information
        /// </summary>
        /// <returns>Job basic Information</returns>
        [Fact]
        public async Task GetJobBasicInformation_ValidInput_ReturnsJobBasicInformation()
        {
            // Arrange
            int jobId = 560975;

            // Arrange
            JobBasicInfo jobBasicInfo = new JobBasicInfo
            {
                JOB_NAME = "UR Tacoma 9916853",
                SALES_OFFICE_NAME = "Billings",
                HQTR_JOB_ID = 89765,
                STREET_ADDRESS_1 = "2222 32nd Street South",
                STREET_ADDRESS_2 = "28",
                CITY = "BRAMPTON",
                PRICING_SPA_NBR = "15-49954",
                SALES_DISTRICT = "144",
                ORACLE_PROJECT_IND = "Y",
                STATUS = "P",
                LOST_TO_COMPETITOR = null,
            };

            this.repository.Setup(x => x.ExecuteQuery<JobBasicInfo>(JobRepositoryQueries.GetJobBasicInfoQuery, It.IsAny<object>()))
                           .Returns(Task.FromResult(jobBasicInfo));

            // Act
            var result = await this.repositoryUnderTest.GetJobBasicInformation(jobId);

            // Assert
            Assert.Equal(jobBasicInfo, result);
            this.repository.Verify(x => x.ExecuteQuery<JobBasicInfo>(JobRepositoryQueries.GetJobBasicInfoQuery, It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        ///  Verifies for favorites response
        /// </summary>
        /// <returns>List of favorite</returns>
        [Fact]
        public async Task GetFavorites_ValidInput_ReturnsListOfFavorites()
        {
            // Arrange
            int drAddressId = 101;
            string userId = "ccwmtu";
            FavoriteJob favoriteJob = Helper.GetFavoriteJobModelRecord();
            IEnumerable<BsonDocument> favoritesBsonDocument = new List<BsonDocument>() { favoriteJob.ToBsonDocument() };
            this.documentDBProviderMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), null, 0)).Returns(Task.FromResult(favoritesBsonDocument));

            // Act
            IEnumerable<BsonDocument> result = await this.repositoryUnderTest.GetFavorites(drAddressId, userId);

            // Assert
            Assert.NotEmpty(result);
            Assert.Equal(favoritesBsonDocument, result);
            this.documentDBProviderMock.Verify(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), null, 0), Times.Once);
        }

        /// <summary>
        /// Get job lock information using valid input -  returns the no data
        /// </summary>
        /// <returns>No records</returns>
        [Fact]
        public async Task GetJobLockInformation_HasNoData_ReturnsNull()
        {
            // Arrange
            int jobId = 4672;
            JobLockInfoModel jobLockInfoModel = null;
            this.repository.Setup(x => x.ExecuteQuery<JobLockInfoModel>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(jobLockInfoModel)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobLockInformation(jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteQuery<JobLockInfoModel>(JobRepositoryQueries.JobLockInfoGetQuery, It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)), Times.Once);
        }

        /// <summary>
        /// Get locked user details using valid input -  returns job locked user details
        /// </summary>
        /// <returns>Job locked user details</returns>
        [Fact]
        public async Task GetJobLockInformation_HasData_ReturnsValidData()
        {
            // Arrange
            int jobId = 1830;
            JobLockInfoModel lockInfoModel = new JobLockInfoModel()
            {
                USER_ID = "lalcj",
                JOB_ID = 123456,
                HQTR_JOB_ID = 1830,
            };
            this.repository.Setup(x => x.ExecuteQuery<JobLockInfoModel>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(lockInfoModel)).Verifiable();

            // Act
            var result = await this.repositoryUnderTest.GetJobLockInformation(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result, lockInfoModel);
            this.repository.Verify(
                x => x.ExecuteQuery<JobLockInfoModel>(
                JobRepositoryQueries.JobLockInfoGetQuery,
                It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)),
                Times.Once);
        }

        [Fact]
        public async Task GetPersonId_HasData_ReturnsPersonId()
        {
            // Arrange
            string commCode = "H35";
            int salesOfficeId = 54;
            string personId = "234567";
            this.repository.Setup(x => x.ExecuteQuery<string>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(personId));

            // Act
            string result = await this.repositoryUnderTest.GetPersonId(commCode, salesOfficeId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result, personId);
            this.repository.Verify(
                x => x.ExecuteQuery<string>(
                JobRepositoryQueries.GetPersonIdQuery,
                It.Is<object>(y => (string)y.GetType().GetProperty("COMM_CODE").GetValue(y) == commCode && (int)y.GetType().GetProperty("SALES_OFFICE_ID").GetValue(y) == salesOfficeId)),
                Times.Once);
        }
    }
}
