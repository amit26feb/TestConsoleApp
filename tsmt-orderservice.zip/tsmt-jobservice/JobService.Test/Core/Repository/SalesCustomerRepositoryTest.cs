// <copyright file="SalesCustomerRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoFixture;
    using AutoMapper;
    using DataAccess.Core.Abstractions;
    using JobService.Common.Constants;
    using JobService.Core.Models;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    public class SalesCustomerRepositoryTest
    {
        private readonly Mock<IRepository<JobService.Core.Models.JobDetails>> repository;
        private readonly IMapper mapper;
        private readonly Mock<IConnectionFactory> connectionFactory;
        private readonly SalesCustomerRepository salesCustomerRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="SalesCustomerRepositoryTest"/> class.
        /// SalesCustomerRepositoryTest
        /// </summary>
        public SalesCustomerRepositoryTest()
        {
            this.connectionFactory = new Mock<IConnectionFactory>();
            this.repository = new Mock<IRepository<JobService.Core.Models.JobDetails>>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });
            this.mapper = config.CreateMapper();
            this.salesCustomerRepository = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
        }

        [Fact]
        public async Task GetCustomerNameAsync_ReturnsValidata()
        {
            // Arrange
            IEnumerable<SalesCustomerView> customerNameList = new List<SalesCustomerView>
            {
                new SalesCustomerView()
                {
                   CustomerName = "North Quincy High School"
                },
            };

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(customerNameList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetCustomerNameListAsync<JobService.Core.ViewModels.SalesCustomerView>("Nor");

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.True(result.Select(a => a.CustomerName == "North Quincy High School").Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetCustomerNameAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.SalesCustomerView> customerNameList = new List<SalesCustomerView>();

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(customerNameList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetCustomerNameListAsync<JobService.Core.ViewModels.SalesCustomerView>(string.Empty);

            // Assert
            Assert.False(result.Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetAccountNumberAsync_ReturnsValidata()
        {
            // Arrange
            IEnumerable<SalesCustomerView> accountNumberList = new List<SalesCustomerView>
            {
                new SalesCustomerView()
                {
                   AccountNumber = "3042336"
                },
            };

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(accountNumberList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAccountNumberListAsync<JobService.Core.ViewModels.SalesCustomerView>("304");

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.True(result.Select(a => a.AccountNumber == "3042336").Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetAccountNumberAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.SalesCustomerView> accountNumberList = new List<SalesCustomerView>();

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(accountNumberList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAccountNumberListAsync<JobService.Core.ViewModels.SalesCustomerView>(string.Empty);

            // Assert
            Assert.False(result.Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetPhoneNumberAsync_ReturnsValidata()
        {
            // Arrange
            IEnumerable<SalesCustomerView> phoneNumberList = new List<SalesCustomerView>
            {
                new SalesCustomerView()
                {
                   PhoneNumber = "301/545-0750"
                },
            };

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(phoneNumberList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetPhoneNumberListAsync<JobService.Core.ViewModels.SalesCustomerView>("301");

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.True(result.Select(a => a.PhoneNumber == "301/545-0750").Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetPhoneNumberAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.SalesCustomerView> phoneNumberList = new List<SalesCustomerView>();

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(phoneNumberList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetPhoneNumberListAsync<JobService.Core.ViewModels.SalesCustomerView>(string.Empty);

            // Assert
            Assert.False(result.Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetPostalCodeAsync_ReturnsValidata()
        {
            // Arrange
            IEnumerable<SalesCustomerView> postalCodeList = new List<SalesCustomerView>
            {
                new SalesCustomerView()
                {
                   ZipCode = "02171"
                },
            };

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(postalCodeList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetPhoneNumberListAsync<JobService.Core.ViewModels.SalesCustomerView>("021");

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.True(result.Select(a => a.ZipCode == "02171").Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetPostalCodeAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.SalesCustomerView> postalCodeList = new List<SalesCustomerView>();

            this.repository.Setup(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(postalCodeList)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetPostalCodeListAsync<JobService.Core.ViewModels.SalesCustomerView>(string.Empty);

            // Assert
            Assert.False(result.Any());
            this.repository.Verify(x => x.GetListAsync<JobService.Core.ViewModels.SalesCustomerView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetStatesListAsync_ReturnsValidData()
        {
            // Arrange
            string search = "WI";
            IEnumerable<StateView> states = new List<StateView>
            {
                    new StateView()
                    {
                      StateProvinceCode = "WI"
                    }
            };

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.StateView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(states)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetStatesListAsync<JobService.Core.ViewModels.StateView>(search);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.True(result.Select(a => a.StateProvinceCode == "WI").Any());
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.StateView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetStatesListAsync_ReturnsEmptyList()
        {
            // Arrange
            string search = "WI";
            IEnumerable<StateView> states = new List<StateView>();

            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.StateView>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(states)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetStatesListAsync<JobService.Core.ViewModels.StateView>(search);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.StateView>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteCustomerContactQuery_ReturnsValidData()
        {
            // Arrange
            int salesCustomerId = 11;
            int customerContactId = 1;
            int recordsDeleted = 1;

            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(recordsDeleted)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.DeleteCustomerContactAsync(salesCustomerId, customerContactId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.repository.Verify();
        }

        [Fact]
        public async Task DeleteCustomerContactQuery_ReturnsZero()
        {
            // Arrange
            int salesCustomerId = 11;
            int customerContactId = 1;
            int recordsDeleted = 0;

            this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(recordsDeleted)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.DeleteCustomerContactAsync(salesCustomerId, customerContactId);

            // Assert
            Assert.Equal(recordsDeleted, result);
            this.repository.Verify();
        }

        [Fact]
        public async Task ValidateCommCode_ReturnsTrue()
        {
            // Arrange
            int commCodeCount = 1;
            var commCode = "RC01";
            var saleOfficeId = 122;

            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(commCodeCount)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.ValidateCommCode(commCode, saleOfficeId);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task ValidateCommCode_ReturnsInvalidFalse()
        {
            // Arrange
            int commCodeCount = 0;
            var commCode = "RC01";
            var saleOfficeId = 122;

            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(commCodeCount)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.ValidateCommCode(commCode, saleOfficeId);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task ValidateSalesOffice_ReturnsTrue()
        {
            // Arrange
            int count = 1;
            var saleOfficeId = 122;

            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(count)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.ValidateSalesCustId(saleOfficeId);

            // Assert
            Assert.True(result);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task ValidateSalesOffice_ReturnsFalse()
        {
            // Arrange
            int count = 0;
            var saleOfficeId = 122;

            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(count)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.ValidateSalesCustId(saleOfficeId);

            // Assert
            Assert.False(result);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public void HonorDrAddressId_Execution()
        {
            // Arrange
            var drAddressId = 13;
            this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            repo.HonorDrAddressId(drAddressId);

            // Assert
            this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
        }

        [Fact]
        public async Task GetSequenceNumber_ReturnsValidId()
        {
            // Arrange
            int id = 34;
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(id)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetSequenceNumber("job");

            // Assert
            Assert.Equal(result, id);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSequenceNumber_ReturnsInvalidId()
        {
            // Arrange
            int id = 0;
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(id)).Verifiable();

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetSequenceNumber("job");

            // Assert
            Assert.Equal(result, id);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetCustomerListAsync_IsNullCustomerAccountNumberRequiredSetToFalse_ReturnsCustomerList()
        {
            // Arrange
            IEnumerable<CustomerViewModel> customerList = Helper.GetCustomerList();

            int skip = 0;
            int take = 20;
            string searchText = "Jack";
            bool isNullCustomerAccountNumberRequired = false;
            StringBuilder stringBuilder = new StringBuilder();
            string customerSearchFilter = @" OR 
                                                 lower(firstname) LIKE :SEARCH_TEXT_LOWER 
                                             OR 
                                                 lower(commcode) LIKE :SEARCH_TEXT_LOWER 
                                             OR 
                                                 lower(lastname) LIKE :SEARCH_TEXT_LOWER 
                                             OR 
                                                 lower(custacctnbr) LIKE :SEARCH_TEXT_LOWER))
                                             WHERE
                                                 rownumber BETWEEN :SKIP AND :TAKE";

            stringBuilder.Append(SalesCustomerRepositoryQueries.GetCustomerListQuery + customerSearchFilter);

            this.repository.Setup(x => x.ExecuteListQuery<CustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(customerList));

            // Act
            IEnumerable<CustomerViewModel> result = await this.salesCustomerRepository.GetCustomerListAsync(skip, take, searchText, isNullCustomerAccountNumberRequired);

            // Assert
            this.repository.Verify(x => x.ExecuteListQuery<CustomerViewModel>(stringBuilder.ToString(), this.VerifyCustomerListMapping(skip, take, searchText)), Times.Once);
        }

        [Fact]
        public async Task GetCustomerListAsync_IsNullCustomerAccountNumberRequiredSetToTrue_ReturnsCustomerListOnlyWithCustomerAccountNumberAsNull()
        {
            // Arrange
            IEnumerable<CustomerViewModel> customerList = Helper.GetCustomerListWithNullCustomerAccountNumber();

            int skip = 0;
            int take = 20;
            string searchText = "Jack";
            bool isNullCustomerAccountNumberRequired = true;
            StringBuilder stringBuilder = new StringBuilder();
            string companySearchFilter = @" OR 
                                                phonenumber LIKE :SEARCH_TEXT 
                                            OR 
                                                crmcompanyid LIKE :SEARCH_TEXT) 
                                            AND 
                                                custacctnbr IS NULL
                                            AND 
                                                crmcompanyid IS NOT NULL)
                                            WHERE
                                                rownumber BETWEEN :SKIP AND :TAKE";

            stringBuilder.Append(SalesCustomerRepositoryQueries.GetCustomerListQuery + companySearchFilter);

            this.repository.Setup(x => x.ExecuteListQuery<CustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(customerList));

            // Act
            IEnumerable<CustomerViewModel> result = await this.salesCustomerRepository.GetCustomerListAsync(skip, take, searchText, isNullCustomerAccountNumberRequired);

            // Assert
            this.repository.Verify(x => x.ExecuteListQuery<CustomerViewModel>(stringBuilder.ToString(), this.VerifyCustomerListMapping(skip, take, searchText)), Times.Once);
        }

        [Fact]
        public async Task GetCustomerListAsync_InvalidRequest_ReturnsNoData()
        {
            // Arrange
            IEnumerable<CustomerViewModel> customerList = new List<CustomerViewModel>();
            int skip = 0;
            int take = 20;
            string searchText = "ab";
            bool isNullCustomerAccountNumberRequired = true;
            this.repository.Setup(x => x.ExecuteListQuery<CustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(customerList)).Verifiable();

            // Act
            IEnumerable<CustomerViewModel> result = await this.salesCustomerRepository.GetCustomerListAsync(skip, take, searchText, isNullCustomerAccountNumberRequired);

            // Assert
            Assert.Empty(result);
            this.repository.Verify();
        }

        [Fact]
        public async Task GetAssignedCustomerListByIdAsync_ReturnsListOfData()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.AssignCustomerViewModel> customerListItem = new List<JobService.Core.ViewModels.AssignCustomerViewModel>
            {
                    new JobService.Core.ViewModels.AssignCustomerViewModel()
                    {
                        SalesCustId = 10117,
                        CustomerName = "Ulliman Schutte Construction LLC",
                        Address = "7615 Standish Place",
                        PhoneNbr = "-301/545-0750",
                        CustAcctNbr = "3800876",
                        StreetAddress1 = "7615 Standish ",
                        StreetAddress2 = "Place",
                        JobRoleTypeId = 0,
                        CommCode = "U98",
                        BidderInd = "Y",
                        WinningBidderInd = "Y",
                        CustomerChannelId = "Y1",
                        CustomerCreditCategoryCode = "COMMSALE"
                    }
            };
            int skip = 0;
            int take = 20;
            int jobId = 59297;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(customerListItem));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAssignedCustomerListByIdAsync(skip, take, jobId, false);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Contains(result, a => a.SalesCustId == 10117);
            Assert.Contains(result, a => a.CommCode == "U98");
            Assert.Contains(result, a => a.BidderInd == "Y");
            Assert.Contains(result, a => a.CustomerChannelId == "Y1");
            Assert.Contains(result, a => a.CustomerCreditCategoryCode == "COMMSALE");
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetAssignedCustomerListByIdAsync_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<JobService.Core.ViewModels.AssignCustomerViewModel> customerListItem = new List<JobService.Core.ViewModels.AssignCustomerViewModel>();

            int skip = 20;
            int take = 20;
            int jobId = 59297;
            this.repository.Setup(x => x.ExecuteListQuery<JobService.Core.ViewModels.AssignCustomerViewModel>(It.IsAny<string>()))
             .Returns(Task.FromResult(customerListItem));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAssignedCustomerListByIdAsync(skip, take, jobId, false);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<JobService.Core.ViewModels.AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get assigned customer list by job id
        /// </summary>
        /// <returns>List of data with valid customer account number</returns>
        [Fact]

        public async Task GetAssignedCustomerListByIdAsync_CustAccNbrRequiredHasData_ReturnsListOfData()
        {
            // Arrange
            IEnumerable<AssignCustomerViewModel> customerListItem = new List<AssignCustomerViewModel>
            {
                new AssignCustomerViewModel()
                {
                    SalesCustId = 10121,
                    CustomerName = "Ulliman Schutte Construction LLC",
                    Address = "7615 Standish Place",
                    PhoneNbr = "-301/545-0750",
                    CustAcctNbr = "3800876",
                    StreetAddress1 = "7615 Standish ",
                    StreetAddress2 = "Place",
                    JobRoleTypeId = 0,
                    CommCode = "U98",
                    BidderInd = "Y",
                    WinningBidderInd = "Y"
                }
            };
            int skip = 0;
            int take = 20;
            int jobId = 59297;
            this.repository.Setup(x => x.ExecuteListQuery<AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(customerListItem));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAssignedCustomerListByIdAsync(skip, take, jobId, true);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result, customerListItem);
            this.repository.Verify(x => x.ExecuteListQuery<AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get assigned customer list by job id
        /// </summary>
        /// <returns>Returns empty list when customer account number is null</returns>
        [Fact]
        public async Task GetAssignedCustomerListByIdAsync_CustAccNbrRequiredHasNoData_ReturnsEmptyList()
        {
            // Arrange
            IEnumerable<AssignCustomerViewModel> customerListItem = Enumerable.Empty<AssignCustomerViewModel>();
            int skip = 20;
            int take = 20;
            int jobId = 59297;
            this.repository.Setup(x => x.ExecuteListQuery<AssignCustomerViewModel>(It.IsAny<string>()))
                .Returns(Task.FromResult(customerListItem));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAssignedCustomerListByIdAsync(skip, take, jobId, true);

            // Assert
            Assert.Empty(result);
            this.repository.Verify(x => x.ExecuteListQuery<AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetCustomerAndContactsAsync_ValidRequest_ReturnsInvalid()
        {
            // Arrange
            var fixture = new Fixture();
            var customerContactView = fixture.CreateMany<SalesCustomerCreateView>(1);
            this.repository.Setup(x => x.ExecuteListQuery<SalesCustomerCreateView>(It.IsAny<string>())).Returns(Task.FromResult(customerContactView));

            // Act
            var repository = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repository.GetCustomerAndContactsAsync(1);

            // Assert
            Assert.Equal(0, result.SalesCustId);
        }

        [Fact]
        public async Task ValidateAssignCustomer_ValidRequest_ReturnsCustomerCount()
        {
            // Arrange
            int jobId = 59297;
            int salesCustId = 2443;
            int jobRoleTypeId = 2;
            int customerCount = 1;
            string name = "Bruce  Henson";
            this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(customerCount));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAssignedCustomerCount(jobId, salesCustId, jobRoleTypeId, name);

            // Assert
            Assert.Equal(result, customerCount);
            this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get customer contact details based on job role assignment - invalid input
        /// </summary>
        /// <returns>Null</returns>
        [Fact]
        public async Task GetAssignedCustomerByJobAsnId_InvalidInput_ReturnsNull()
        {
            // Arrange
            AssignCustomerViewModel viewAssignedCustomer = null;
            int jobRoleAsnId = 59297;
            int jobId = 59297;
            this.repository.Setup(x => x.ExecuteQuery<AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(viewAssignedCustomer));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAssignedCustomerByJobRoleAsnId(jobRoleAsnId, jobId);

            // Assert
            Assert.Null(result);
            this.repository.Verify(x => x.ExecuteQuery<AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get customer contact details based on job role assignment - valid input
        /// </summary>
        /// <returns>Customer Contact details based on the job role assignment id</returns>
        [Fact]
        public async Task GetAssignedCustomerByJobAsnId_ValidInput_ReturnsResult()
        {
            // Arrange
           AssignCustomerViewModel viewAssignedCustomer = new AssignCustomerViewModel
            {
                        SalesCustId = 10117,
                        CustomerName = "Ulliman Schutte Construction LLC",
                        Address = "7615 Standish Place",
                        PhoneNbr = "-301/545-0750",
                        CustAcctNbr = "3800876",
                        StreetAddress1 = "7615 Standish ",
                        StreetAddress2 = "Place",
                        JobRoleTypeId = 0,
                        CommCode = "U98",
                        BidderInd = "Y",
                        JobRoleAsnId = "109"
            };

            int jobRoleAsnId = 109;
            int jobId = 59297;
            this.repository.Setup(x => x.ExecuteQuery<AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(viewAssignedCustomer));

            // Act
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);
            var result = await repo.GetAssignedCustomerByJobRoleAsnId(jobRoleAsnId, jobId);

            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<AssignCustomerViewModel>(result);
            Assert.Equal(viewAssignedCustomer.JobRoleAsnId, result.JobRoleAsnId);
            this.repository.Verify(x => x.ExecuteQuery<AssignCustomerViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get sales customers called and customers exist
        /// </summary>
        /// <returns>Sales customer data model</returns>
        [Fact]
        public async Task GetSalesCustomers_SalesCustomersExists_ReturnsSalesCustomers()
        {
            // Arrange
            int jobId = 46;
            var fixture = new Fixture();
            var salesCustomers = fixture.CreateMany<SalesCustomer>(2);
            this.repository.Setup(x => x.ExecuteListQuery<SalesCustomer>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(salesCustomers));
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);

            // Act
            var result = await repo.GetSalesCustomers(jobId);

            // Assert
            Assert.Equal(result, salesCustomers);
            this.repository.Verify(x => x.ExecuteListQuery<SalesCustomer>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        /// <summary>
        /// Get sales customers with addresses - get inactive CRM customers
        /// </summary>
        /// <returns>Sales customers with addresses</returns>
        [Fact]
        public async Task GetSalesCustomersWithAddresses_SalesCustomersExistsForJobId_ReturnsSalesCustomersWithAddresses()
        {
            // Arrange
            int jobId = 60693;
            char connectedWithCRM = 'N';
            IEnumerable<SalesCustomerWithAddress> salesCustomersWithAddresses = Helper.GetSalesCustomersWithAddresses();
            this.repository.Setup(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery))
                .Returns(Task.FromResult(connectedWithCRM));
            this.repository.Setup(x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForInActiveCRMGetQuery, It.IsAny<object>()))
                .Returns(Task.FromResult(salesCustomersWithAddresses));
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);

            // Act
            var result = await repo.GetSalesCustomersWithAddresses(jobId);

            // Assert
            Assert.Equal(result, salesCustomersWithAddresses);
            Assert.True(result.First().COUNTRY == salesCustomersWithAddresses.First().COUNTRY && result.First().PROVINCE == salesCustomersWithAddresses.First().PROVINCE);
            this.repository.Verify(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery), Times.Once);
            this.repository.Verify(
                x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForInActiveCRMGetQuery, It.Is<object>(y =>
                ((int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId) && (y.GetType().GetProperties().Length == 1))), Times.Once);
        }

        /// <summary>
        /// Get sales customers with addresses - get inactive CRM customers
        /// </summary>
        /// <returns>Empty sales customers with addresses</returns>
        [Fact]
        public async Task GetSalesCustomersWithAddresses_SalesCustomersNotExistsForJobId_ReturnsEmptySalesCustomerDetails()
        {
            // Arrange
            int jobId = 65;
            char connectedWithCRM = 'N';
            IEnumerable<SalesCustomerWithAddress> salesCustomersWithAddresses = new List<SalesCustomerWithAddress>();
            this.repository.Setup(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery))
                .Returns(Task.FromResult(connectedWithCRM));
            this.repository.Setup(x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForInActiveCRMGetQuery, It.IsAny<object>()))
                .Returns(Task.FromResult(salesCustomersWithAddresses));
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);

            // Act
            var result = await repo.GetSalesCustomersWithAddresses(jobId);

            // Assert
            Assert.Equal(result, salesCustomersWithAddresses);
            this.repository.Verify(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery), Times.Once);
            this.repository.Verify(
                x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForInActiveCRMGetQuery, It.Is<object>(y =>
                ((int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId) && (y.GetType().GetProperties().Length == 1))), Times.Once);
        }

        /// <summary>
        /// Get sales customers with addresses - get active CRM customers
        /// </summary>
        /// <returns>Sales customers with addresses</returns>
        [Fact]
        public async Task GetActiveCRMSalesCustomersWithAddresses_SalesCustomersExistsForJobId_ReturnsSalesCustomersWithAddresses()
        {
            // Arrange
            int jobId = 60791;
            char connectedWithCRM = 'Y';
            IEnumerable<SalesCustomerWithAddress> salesCustomersWithAddresses = Helper.GetSalesCustomersWithAddresses();
            this.repository.Setup(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery))
                .Returns(Task.FromResult(connectedWithCRM));
            this.repository.Setup(x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForActiveCRMGetQuery))
                .Returns(Task.FromResult(salesCustomersWithAddresses));
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);

            // Act
            var result = await repo.GetSalesCustomersWithAddresses(jobId);

            // Assert
            Assert.Equal(result, salesCustomersWithAddresses);
            Assert.True(result.First().COUNTRY == salesCustomersWithAddresses.First().COUNTRY && result.First().PROVINCE == salesCustomersWithAddresses.First().PROVINCE);
            this.repository.Verify(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery), Times.Once);
            this.repository.Verify(
                x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForActiveCRMGetQuery), Times.Once);
        }

        /// <summary>
        /// Get sales customers with addresses - get active CRM customers
        /// </summary>
        /// <returns>Empty sales customers with addresses</returns>
        [Fact]
        public async Task GetActiveCRMSalesCustomersWithAddresses_SalesCustomersNotExistsForJobId_ReturnsEmptySalesCustomerDetails()
        {
            // Arrange
            int jobId = 60;
            char connectedWithCRM = 'Y';
            IEnumerable<SalesCustomerWithAddress> salesCustomersWithAddresses = new List<SalesCustomerWithAddress>();
            this.repository.Setup(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery))
                .Returns(Task.FromResult(connectedWithCRM));
            this.repository.Setup(x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForActiveCRMGetQuery))
                .Returns(Task.FromResult(salesCustomersWithAddresses));
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);

            // Act
            var result = await repo.GetSalesCustomersWithAddresses(jobId);

            // Assert
            Assert.Equal(result, salesCustomersWithAddresses);
            this.repository.Verify(x => x.ExecuteQuery<char>(SalesCustomerRepositoryQueries.CustomerMainteanceDataBaseConnectionDetailsGetQuery), Times.Once);
            this.repository.Verify(
                x => x.ExecuteListQuery<SalesCustomerWithAddress>(SalesCustomerRepositoryQueries.SalesCustomerDetailsForActiveCRMGetQuery), Times.Once);
        }

        [Fact]
        public async Task GetContacts_HasContacts_ReturnsContacts()
        {
            // Arrange
            int skip = 0;
            int take = 10;
            string searchText = "Taylor";
            IEnumerable<SiteContact> siteContacts = new List<SiteContact>()
            {
                Helper.GetSiteContactModel()
            };
            this.repository.Setup(x => x.ExecuteListQuery<SiteContact>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(siteContacts));

            // Act
            IEnumerable<SiteContact> result = await this.salesCustomerRepository.GetContacts(skip, take, searchText);

            // Assert
            Assert.Equal(result, siteContacts);
            this.repository.Verify(x => x.ExecuteListQuery<SiteContact>(SalesCustomerRepositoryQueries.ContactDetailsGetQuery, this.VerifyContactParameters(skip, take, searchText)), Times.Once);
        }

        /// <summary>
        /// Get sales customers called and customers exist
        /// </summary>
        /// <returns>Sales customer data model</returns>
        [Fact]
        public async Task GetSalesCustomersByCrmCompany_SalesCustomersExists_ReturnsSalesCustomers()
        {
            // Arrange
            int salesCustomerId = 46;
            var fixture = new Fixture();
            var salesCustomers = fixture.CreateMany<SalesCustomerWithAddress>(2);
            this.repository.Setup(x => x.ExecuteListQuery<SalesCustomerWithAddress>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(salesCustomers));
            var repo = new SalesCustomerRepository(this.connectionFactory.Object, this.repository.Object);

            // Act
            var result = await repo.GetSalesCustomersByCrmCompany(salesCustomerId);

            // Assert
            Assert.Equal(result, salesCustomers);
            this.repository.Verify(x => x.ExecuteListQuery<SalesCustomerWithAddress>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        private object VerifyContactParameters(int skip, int take, string searchText)
        {
            return It.Is<object>(param => (int)param.GetType().GetProperty("SKIP").GetValue(param) == skip + 1
            && (int)param.GetType().GetProperty("TAKE").GetValue(param) == take + skip
            && (string)param.GetType().GetProperty("SEARCH_TEXT").GetValue(param) == "%" + searchText.ToLower() + "%");
        }

        private object VerifyCustomerListMapping(int skip, int take, string searchText)
        {
            return It.Is<object>(param => (int)param.GetType().GetProperty("SKIP").GetValue(param) == skip + 1
            && (int)param.GetType().GetProperty("TAKE").GetValue(param) == take + skip
            && (string)param.GetType().GetProperty("SEARCH_TEXT_LOWER").GetValue(param) == "%" + searchText.ToLower() + "%"
            && (string)param.GetType().GetProperty("SEARCH_TEXT").GetValue(param) == "%" + searchText + "%");
        }
    }
}
