// <copyright file="MTopssJobDynamoDbRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace JobService.Test.Core.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using Amazon.DynamoDBv2.DocumentModel;
    using AutoFixture;
    using AutoMapper;
    using Dapper;
    using DataAccess.Core.Abstractions;
    using DataAccess.Paging;
    using DynamoDBWrapper;
    using JobService.Common.Exceptions;
    using JobService.Core.Models;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using Moq.Dapper;
    using TSMT.DataAccess;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// Test Methods for MTopss Job DynamoDb Repository Test
    /// </summary>
    public class MTopssJobDynamoDbRepositoryTest
    {
        private readonly Mock<ILogger<DynamoDBRepository>> logger;
        private readonly Mock<IDynamoDBRepository> dynamoDBRepository;
        private IDynamoTableConfig dynamoTableConfig;

        /// <summary>
        /// Initializes a new instance of the <see cref="MTopssJobDynamoDbRepositoryTest"/> class.
        /// </summary>
        public MTopssJobDynamoDbRepositoryTest()
        {
            this.logger = new Mock<ILogger<DynamoDBRepository>>();
            this.dynamoDBRepository = new Mock<IDynamoDBRepository>();
        }

        [Fact]
        public async Task UpdatePatchProcessStatus_Execute()
        {
            // Arrange
            MTopssMessage mTopssMessage = new MTopssMessage()
            {
                JobId = 4004,
                UserId = "ccfhsd",
                CreatedDateTime = "3/13/2019 7:39:15 AM",
                Signature = "RdkUovhipvHOHdMIMAFby1tQBBo=",
                Status = "Success",
                ErrorMessage = string.Empty,
                MessageId = "0HLLDPLUFAJ2N:00000001",
                StatusUpdatedDateTime = DateTime.UtcNow.ToString()
            };
            Document doc = mTopssMessage.ToDocument();

            // Act
            this.dynamoTableConfig = new DynamoTableConfig { TableName = "TSMT-LynxJobMessage", ReadCapacityUnits = 3, WriteCapacityUnits = 1, KeyName = "MessageId", KeyType = typeof(string) };
            TSMTSettings appSetting = new TSMTSettings() { SqsServiceUrl = "arn: aws: sns: us - east - 1:611998158124:TSMT - JobsSaveToLynx", MessageHidingTimeInMinutes = 2, DynamoRegion = "US-East-1", DynamoJobTableName = "TSMT-LynxJobMessage", DynamoJobKeyName = "MessageId" };

            var mockappSetting = new Mock<IOptions<TSMTSettings>>();
            mockappSetting.Setup(ap => ap.Value).Returns(appSetting);

            this.dynamoDBRepository.Setup(x => x.PartialUpdateCommandAsync(It.IsAny<MTopssMessage>(), It.IsAny<ReturnValues>())).Returns(Task.FromResult(doc));
            var mtopssJobRepository = new MTopssJobDynamoDbRepository(this.logger.Object, mockappSetting.Object, this.dynamoTableConfig);

            mtopssJobRepository.DynamoDBRepository = this.dynamoDBRepository.Object;
            var result = await mtopssJobRepository.UpdatePatchProcessStatus(mTopssMessage);

            // Assert
            Assert.IsType<Document>(result);
            Assert.Equal(doc, result);
            this.dynamoDBRepository.Verify(x => x.PartialUpdateCommandAsync(It.IsAny<MTopssMessage>(), It.IsAny<ReturnValues>()), Times.Once);
        }
    }
}
