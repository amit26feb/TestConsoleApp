// <copyright file="ShipmentRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.Repository
{
    using System.Threading.Tasks;
    using JobService.Common.Constants;
    using JobService.Core.Models;
    using JobService.Repository;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

    /// <summary>
    /// Test class for shipment repository
    /// </summary>
    public class ShipmentRepositoryTest
    {
        private readonly Mock<IRepository<JobDetails>> repository;
        private ShipmentRepository repo;

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentRepositoryTest"/> class.
        /// </summary>
        public ShipmentRepositoryTest()
        {
            this.repository = new Mock<IRepository<JobDetails>>();
            this.repo = new ShipmentRepository(this.repository.Object);
        }

        [Fact]
        public async Task GetShippingInstructionByJobId_ValidInput_ReturnsShipmentInstruction()
        {
            // Arrange
            int jobId = 2094643;

            ShippingInstruction shippingInstruction = new ShippingInstruction()
            {
                SHIPPING_INSTRUCTION_ID = 101,
                COUNTRY = "U.S.A",
                CREDIT_JOB_ID = null
            };

            this.repository.Setup(x => x.ExecuteQuery<ShippingInstruction>(ShipmentRepositoryQueries.ShippingInstructionByJobIdGetQuery, It.IsAny<object>()))
                .Returns(Task.FromResult(shippingInstruction));

            // Act
            var result = await this.repo.GetShippingInstructionByJobId(jobId);

            // Assert
            Assert.NotNull(result);
            Assert.Null(result.CREDIT_JOB_ID);
            this.repository.Verify(x => x.ExecuteQuery<ShippingInstruction>(ShipmentRepositoryQueries.ShippingInstructionByJobIdGetQuery, It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)), Times.Once);
        }

        /// <summary>
        /// Get the maximum shipping instruction id by using job id
        /// </summary>
        /// <returns>Shipping instruction id</returns>
        [Fact]
        public async Task GetMaximumShippingInstructionId_ValidInput_ReturnsShippingInstructionId()
        {
            // Arrange
            int jobId = 2094643;

            int shippingInstructionId = 4;

            this.repository.Setup(x => x.ExecuteQuery<int>(ShipmentRepositoryQueries.MaximumShippingInstructionIdGetQuery, It.IsAny<object>()))
                .Returns(Task.FromResult(shippingInstructionId));

            // Act
            int result = await this.repo.GetMaximumShippingInstructionId(jobId);

            // Assert
            Assert.True(result == shippingInstructionId);
            this.repository.Verify(x => x.ExecuteQuery<int>(ShipmentRepositoryQueries.MaximumShippingInstructionIdGetQuery, It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)), Times.Once);
        }
    }
}
