// <copyright file="JobDocumentRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoFixture;
    using AutoMapper;
    using Dapper;
    using DataAccess.Core.Abstractions;
    using DataAccess.Paging;
    using JobService.Common.Constants;
    using JobService.Common.Exceptions;
    using JobService.Core.Models;
    using JobService.Repository;
    using JobService.Test.Common;
    using Moq;
    using Moq.Dapper;
    using TSMT.DataAccess;
    using TSMT.DataAccess.Models;
    using Xunit;

    public class JobDocumentRepositoryTest
    {
        private readonly Mock<IRepository<JobService.Core.Models.JobDocument>> jobDocumentRepository;
        private readonly Mock<IConnectionFactory> connectionFactory;
        private readonly JobDocumentRepository documentRepository;

        private readonly int jobId = 54343;
        private readonly int variationId = 53650;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobDocumentRepositoryTest"/> class.
        /// JobDocumentRepositoryTest
        /// </summary>
        public JobDocumentRepositoryTest()
        {
            this.connectionFactory = new Mock<IConnectionFactory>();
            this.jobDocumentRepository = new Mock<IRepository<JobService.Core.Models.JobDocument>>();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Configurations.AutoMapperConfiguration.AutoMapperProfile>();
            });

            this.documentRepository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);
        }

        [Fact]
        public async Task UploadJobDocumentInfo_ReturnsTrue()
        {
            // Arrange
            int isInserted = 1;
            int jobDocumentId = 2;
            var jobDocument = new JobService.Core.Models.JobDocument()
            {
                JOB_ID = 178456,
                DR_ADDRESS_ID = 94,
                DOCUMENT_VERSION = "1"
            };

            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<JobService.Core.Models.JobDocument>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(isInserted));
            JobDocumentRepository jobDocumentRepository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);

            // Act
            var result = await jobDocumentRepository.InsertJobDocument(jobDocument, jobDocumentId);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<JobService.Core.Models.JobDocument>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task UploadJobDocumentInfo_ReturnsFalse()
        {
            // Arrange
            int recordsInserted = 0;
            int jobDocumentId = 2;
            var jobDocument = new JobService.Core.Models.JobDocument()
            {
                JOB_ID = 178456,
                DR_ADDRESS_ID = 94,
                DOCUMENT_VERSION = "1"
            };

            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<JobService.Core.Models.JobDocument>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(recordsInserted));
            JobDocumentRepository jobDocumentRepository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);

            // Act
            var result = await jobDocumentRepository.InsertJobDocument(jobDocument, jobDocumentId);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<JobService.Core.Models.JobDocument>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSequenceNumber_ValidInput_ReturnsValidId()
        {
            // Arrange
            int id = 34;
            this.jobDocumentRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(id));

            // Act
            var repo = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);
            var result = await repo.GetSequenceNumber("JOB_DOCUMENT");

            // Assert
            Assert.Equal(result, id);
            this.jobDocumentRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSequenceNumber_InvalidInput_ReturnsInvalidId()
        {
            // Arrange
            int id = 0;
            this.jobDocumentRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(id));

            // Act
            var repo = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);
            var result = await repo.GetSequenceNumber("JOB_DOCUMENT");

            // Assert
            Assert.Equal(result, id);
            this.jobDocumentRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDocumentHistoryAsync_ValidInput_ReturnsDocumentHistoryDetails()
        {
            // Arrange
            int jobId = 27397;
            string documentKey = "Jobs/78/27397/UploadFile.txt";
            IEnumerable<JobDocument> documentHistory = new List<JobDocument>()
            {
                new JobDocument()
                {
                    DOCUMENT_KEY = documentKey,
                    DOCUMENT_NAME = "UploadFile.txt",
                    DOCUMENT_SOURCE = null,
                    DOCUMENT_VERSION = "27uXDVc_9nVrd4.r..Q3JIdmc.SBLeoU",
                    UPLOADED_USER_ID = "ccfbok"
                }
            };
            this.jobDocumentRepository.Setup(x => x.ExecuteListQuery<JobDocument>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(documentHistory));
            var repository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);

            // Act
            var result = await repository.GetDocumentHistoryAsync(jobId, documentKey);

            // Assert
            Assert.Contains(result, a => a.DOCUMENT_KEY == "Jobs/78/27397/UploadFile.txt");
            Assert.Contains(result, a => a.DOCUMENT_NAME == "UploadFile.txt");
            Assert.Contains(result, a => a.DOCUMENT_SOURCE == null);
            Assert.Contains(result, a => a.DOCUMENT_VERSION == "27uXDVc_9nVrd4.r..Q3JIdmc.SBLeoU");
            this.jobDocumentRepository.Verify(x => x.ExecuteListQuery<JobDocument>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDocumentHistoryAsync_InValidInput_ReturnsEmptyDocumentHistoryDetails()
        {
            // Arrange
            int jobId = 27397;
            string documentKey = "Jobs/78/27397";
            IEnumerable<JobDocument> documentHistory = new List<JobDocument>();
            this.jobDocumentRepository.Setup(x => x.ExecuteListQuery<JobDocument>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(documentHistory));
            var repository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);

            // Act
            var result = await repository.GetDocumentHistoryAsync(jobId, documentKey);

            // Assert
            Assert.Empty(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteListQuery<JobDocument>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetDocumentList_ValidInput_ReturnsDocumentList()
        {
            // Arrange
            IEnumerable<JobDocument> jobDocumentList = new List<JobDocument>()
            {
                new JobService.Core.Models.JobDocument()
                {
                    JOB_DOCUMENT_ID = 123,
                    JOB_ID = 1234,
                    TOTAL_COUNT = 1,
                    DOCUMENT_NAME = "Doc1"
                },
            };
            int skip = 10;
            int take = 20;
            int jobId = 1234;
            int folderId = 123;
            this.jobDocumentRepository.Setup(x => x.ExecuteListQuery<JobService.Core.Models.JobDocument>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(jobDocumentList)).Verifiable();

            // Act
            JobDocumentRepository repository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);
            IEnumerable<JobDocument> result = await repository.GetDocumentList(jobId, folderId, skip, take);

            // Assert
            Assert.NotNull(result);
            this.jobDocumentRepository.Verify();
        }

        [Fact]
        public async Task DeleteDocumentAsync_RecordDeleted_ReturnsTrue()
        {
            // Arrange
            string documentKey = "Jobs/78/26613/upload.txt";
            int recordsDeleted = 1;
            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(recordsDeleted));
            var repository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);

            // Act
            var result = await repository.DeleteDocumentAsync(documentKey);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteDocumentAsync_NoRecordDeleted_ReturnsFalse()
        {
            // Arrange
            string documentKey = "Jobs/upload.txt";
            int recordsDeleted = 0;
            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(recordsDeleted));
            var repository = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);

            // Act
            var result = await repository.DeleteDocumentAsync(documentKey);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteDocumentsAsync_RecordDeleted_ReturnsTrue()
        {
            // Arrange
            IEnumerable<string> documentKeys = new List<string>() { "Jobs/78/26613/upload.txt", "Jobs/78/26613/download.txt" };
            int recordsDeleted = 1;
            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(recordsDeleted));

            // Act
            var result = await this.documentRepository.DeleteDocumentsAsync(documentKeys);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteDocumentsFolderAsync_RecordDeleted_ReturnsTrue()
        {
            // Arrange
            int recordsDeleted = 1;
            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(recordsDeleted));

            // Act
            var result = await this.documentRepository.DeleteDocumentsFolderAsync(this.jobId, this.variationId);

            // Assert
            Assert.True(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteDocumentsAsync_NoRecordDeleted_ReturnsFalse()
        {
            // Arrange
            IEnumerable<string> documentKeys = new List<string>() { "Jobs/78/26613/upload.txt", "Jobs/78/26613/download.txt" };
            int recordsDeleted = 0;
            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(recordsDeleted));

            // Act
            var result = await this.documentRepository.DeleteDocumentsAsync(documentKeys);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task DeleteDocumentsFolderAsync_NoRecordDeleted_ReturnsFalse()
        {
            // Arrange
            int recordsDeleted = 0;
            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(recordsDeleted));

            // Act
            var result = await this.documentRepository.DeleteDocumentsFolderAsync(this.jobId, this.variationId);

            // Assert
            Assert.False(result);
            this.jobDocumentRepository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetSequenceNumber_ValidInput_ReturnsValidSequenceNumber()
        {
            // Arrange
            int documentId = 34;
            this.jobDocumentRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(documentId));

            // Act
            var repo = new JobDocumentRepository(this.connectionFactory.Object, this.jobDocumentRepository.Object);
            var result = await repo.GetSequenceNumber("JOB_DOCUMENT", It.IsAny<int>());

            // Assert
            Assert.Equal(result, documentId);
            this.jobDocumentRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
        }

        [Fact]
        public async Task GetFolderDetails_HasFolderdetails_ReturnsFolderDetails()
        {
            // Arrange
            int jobId = 5;
            int? docTypeId = 1;
            List<string> folderNames = new List<string>() { "NonTrane", "1234" };
            IEnumerable<DocumentFolderModel> documentFolderDetails = new List<DocumentFolderModel>()
            {
                Helper.GetDocumentFolderModel()
            };
            this.jobDocumentRepository.Setup(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(documentFolderDetails));

            // Act
            IEnumerable<DocumentFolderModel> result = await this.documentRepository.GetFolderDetails(jobId, JobFolderTypes.NonTrane, folderNames, docTypeId);

            // Assert
            Assert.Equal(result, documentFolderDetails);
            this.jobDocumentRepository.Verify(
                x => x.ExecuteListQuery<DocumentFolderModel>(
                JobDocumentRepositoryQueries.GetFolderDetailsQuery,
                It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId
                && (JobFolderTypes)y.GetType().GetProperty("JOB_FOLDER_TYPE_ID").GetValue(y) == JobFolderTypes.NonTrane
                && (List<string>)y.GetType().GetProperty("FOLDER_NAMES").GetValue(y) == folderNames
                && (int?)y.GetType().GetProperty("DOC_TYPE_ID").GetValue(y) == 1
                && (int?)y.GetType().GetProperty("DOC_TYPE_FOLDER_ID").GetValue(y) == 2)), Times.Once);
        }

        [Fact]
        public async Task CreateDocumentFolder_HasValidFolderDetailsToInsert_ReturnsFolderId()
        {
            // Arrange
            this.jobDocumentRepository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
                .Returns(Task.FromResult(1));

            // Act
            int result = await this.documentRepository.CreateDocumentFolder(Helper.GetDocumentFolderModel());

            // Assert
            Assert.Equal(1, result);
            this.jobDocumentRepository.Verify(
                x => x.ExecuteAsync<int>(
                JobDocumentRepositoryQueries.InsertDocumentFolderQuery,
                It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == 12345
                && (JobFolderTypes)y.GetType().GetProperty("JOB_FOLDER_TYPE_ID").GetValue(y) == JobFolderTypes.NonTrane
                && (string)y.GetType().GetProperty("FOLDER_NAME").GetValue(y) == "NonTrane"
                && (int?)y.GetType().GetProperty("FOLDER_ID").GetValue(y) == 1)), Times.Once);
        }
    }
}
