// <copyright file="RevenueStreamRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using DocumentDBWrapper;
    using JobService.Configurations;
    using JobService.Core.Models;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.Extensions.Options;
    using MongoDB.Bson;
    using MongoDB.Driver;
    using Moq;
    using Xunit;

    /// <summary>
    /// Revenue stream repository test
    /// </summary>
    public class RevenueStreamRepositoryTest
    {
        private readonly RevenueStreamRepository revenueStreamRepository;
        private readonly Mock<IDocumentDBConnectionFactory> documentDbConnectionFactoryMock;
        private readonly Mock<IOptions<JobServiceSettings>> settings;
        private readonly Mock<IDocumentDBProvider> documentDbProviderMock;

        public RevenueStreamRepositoryTest()
        {
            this.documentDbProviderMock = new Mock<IDocumentDBProvider>();
            this.settings = new Mock<IOptions<JobServiceSettings>>();
            JobServiceSettings appSetting = new JobServiceSettings() { DocumentDBFavoriteJobConnectionString = "DummyConnectionString", DocumentDBRevenueCollectionName = "RevenueStream" };
            this.settings.Setup(app => app.Value).Returns(appSetting);
            this.documentDbConnectionFactoryMock = new Mock<IDocumentDBConnectionFactory>();
            this.documentDbConnectionFactoryMock.Setup(x => x.GetConnection(appSetting.DocumentDBFavoriteJobConnectionString, appSetting.DocumentDBRevenueCollectionName)).Returns(this.documentDbProviderMock.Object);
            this.revenueStreamRepository = new RevenueStreamRepository(this.documentDbConnectionFactoryMock.Object, this.settings.Object);
        }

        [Fact]
        public async Task GetRevenueStream_HasRecords_ReturnsRevenueStream()
        {
            // Arrange
            RevenueStreamModel revenueStreamModel = Helper.GetRevenueStreamModel();
            IEnumerable<BsonDocument> revenueStreamList = new List<BsonDocument>() { revenueStreamModel.ToBsonDocument() };
            this.documentDbProviderMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<SortDefinition<BsonDocument>>(), 0)).Returns(Task.FromResult(revenueStreamList));

            // Act
            IEnumerable<BsonDocument> result = await this.revenueStreamRepository.GetRevenueDetails();

            // Assert
            Assert.Equal(revenueStreamList, result);
            this.documentDbProviderMock.Verify(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<SortDefinition<BsonDocument>>(), 0), Times.Once);
        }
    }
}
