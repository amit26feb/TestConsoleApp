// <copyright file="JobProgramRepositoyTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using DocumentDBWrapper;
    using JobService.Configurations;
    using JobService.Core.Models;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.Extensions.Options;
    using MongoDB.Bson;
    using MongoDB.Driver;
    using Moq;
    using Xunit;

    /// <summary>
    /// Job program repository test
    /// </summary>
    public class JobProgramRepositoyTest
    {
        private readonly JobProgramRepository jobProgramRepository;
        private readonly Mock<IDocumentDBConnectionFactory> documentDbConnectionFactoryMock;
        private readonly Mock<IOptions<JobServiceSettings>> settings;
        private readonly Mock<IDocumentDBProvider> documentDbProviderMock;

        public JobProgramRepositoyTest()
        {
            this.documentDbProviderMock = new Mock<IDocumentDBProvider>();
            this.settings = new Mock<IOptions<JobServiceSettings>>();
            JobServiceSettings appSetting = new JobServiceSettings() { DocumentDBFavoriteJobConnectionString = "DummyConnectionString", DocumentJobProgramCollectionName = "JobProgram" };
            this.settings.Setup(app => app.Value).Returns(appSetting);
            this.documentDbConnectionFactoryMock = new Mock<IDocumentDBConnectionFactory>();
            this.documentDbConnectionFactoryMock.Setup(x => x.GetConnection(appSetting.DocumentDBFavoriteJobConnectionString, appSetting.DocumentJobProgramCollectionName)).Returns(this.documentDbProviderMock.Object);
            this.jobProgramRepository = new JobProgramRepository(this.documentDbConnectionFactoryMock.Object, this.settings.Object);
        }

        [Fact]
        public async Task GetJobprograms_HasRecords_ReturnsJobPrograms()
        {
            // Arrange
            Program program = Helper.GetProgramModel();
            IEnumerable<BsonDocument> programs = new List<BsonDocument>() { program.ToBsonDocument() };
            this.documentDbProviderMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<SortDefinition<BsonDocument>>(), 0)).Returns(Task.FromResult(programs));

            // Act
            IEnumerable<BsonDocument> result = await this.jobProgramRepository.GetJobPrograms();

            // Assert
            Assert.Equal(programs, result);
            this.documentDbProviderMock.Verify(x => x.FindAsync(It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<SortDefinition<BsonDocument>>(), 0), Times.Once);
        }
    }
}
