// <copyright file="JobCoordinationRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using DynamoDBWrapper;
    using JobService.Common.Constants;
    using JobService.Core.Models;
    using JobService.Core.ViewModels;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using TSMT.DataAccess;
    using TSMT.Settings;
    using Xunit;

    public class JobCoordinationRepositoryTest
    {
        private readonly Mock<ILogger<DynamoDBRepository>> loggerMock;
        private readonly Mock<IDynamoDBRepository> dynamoDBRepositoryMock;
        private readonly Mock<IOptions<TSMTSettings>> appSettingsMock;
        private readonly Mock<IRepository<CoordinatedJobMessage>> repositoryMock;
        private readonly IDynamoTableConfig dynamoTableConfiguration;
        private readonly JobCoordinationRepository jobCoordinationRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobCoordinationRepositoryTest"/> class.
        /// </summary>
        public JobCoordinationRepositoryTest()
        {
            this.loggerMock = new Mock<ILogger<DynamoDBRepository>>();
            this.dynamoDBRepositoryMock = new Mock<IDynamoDBRepository>();
            this.appSettingsMock = new Mock<IOptions<TSMTSettings>>();
            this.repositoryMock = new Mock<IRepository<CoordinatedJobMessage>>();
            this.dynamoTableConfiguration = new DynamoTableConfig { TableName = "TSMT-JobCoordination", ReadCapacityUnits = 3, WriteCapacityUnits = 1, KeyName = "MessageId", KeyType = typeof(string) };
            TSMTSettings appSetting = new TSMTSettings() { DynamoRegion = "US-East-1" };
            this.appSettingsMock.Setup(x => x.Value).Returns(appSetting);
            this.jobCoordinationRepository = new JobCoordinationRepository(this.loggerMock.Object, this.dynamoTableConfiguration, this.appSettingsMock.Object, this.repositoryMock.Object);
        }

        /// <summary>
        /// Save job coordination request - valid input
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Fact]
        public async Task SaveJobCoordinationRequest_ValidInput_JobCoordinationRequestSaved()
        {
            // Arrange
            JobCoordinationRequestViewModel jobCoordinationRequestViewModel = Helper.GetJobCoordinationRequestViewModel();

            // Act
            await this.jobCoordinationRepository.SaveMessage<JobCoordinationRequestViewModel>(jobCoordinationRequestViewModel, this.dynamoTableConfiguration.TableName, this.dynamoTableConfiguration.KeyName);

            // Assert
            this.appSettingsMock.Verify(x => x.Value, Times.AtLeastOnce);
        }

        /// <summary>
        /// Verifies for true result if the job has coordinated records
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task DoesJobCoordinatedRecordExist_HasCoordinatedRecord_ReturnsTrue()
        {
            // Arrange
            int jobId = 123;
            IEnumerable<string> excludedCoordinationStatuses = new List<string>();
            this.repositoryMock.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.CoordinatedRecordCountSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(1));

            // Act
            var result = await this.jobCoordinationRepository.DoesJobCoordinatedRecordExist(jobId, excludedCoordinationStatuses);

            // Assert
            Assert.True(result);
            this.repositoryMock.Verify(
                x => x.ExecuteQuery<int>(
                    JobRepositoryQueries.CoordinatedRecordCountSelectQuery,
                    It.Is<object>(y => y.GetType().GetProperty("JOB_ID") != null
                                       && (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)),
                Times.Once);
        }

        /// <summary>
        /// Verifies for false result if the job has no coordinated records
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task DoesJobCoordinatedRecordExist_HasNoCoordinatedRecord_ReturnsFalse()
        {
            // Arrange
            int jobId = 13;
            IEnumerable<string> excludedCoordinationStatuses = new List<string>();
            this.repositoryMock.Setup(x => x.ExecuteQuery<int>(JobRepositoryQueries.CoordinatedRecordCountSelectQuery, It.IsAny<object>())).Returns(Task.FromResult(0));

            // Act
            var result = await this.jobCoordinationRepository.DoesJobCoordinatedRecordExist(jobId, excludedCoordinationStatuses);

            // Assert
            Assert.False(result);
            this.repositoryMock.Verify(
                x => x.ExecuteQuery<int>(
                    JobRepositoryQueries.CoordinatedRecordCountSelectQuery,
                    It.Is<object>(y => y.GetType().GetProperty("JOB_ID") != null
                                       && (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)),
                Times.Once);
        }
    }
}
