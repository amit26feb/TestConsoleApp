// <copyright file="CustomSenderRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace JobService.Test.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using DocumentDBWrapper;
    using JobService.Configurations;
    using JobService.Core.Models;
    using JobService.Repository;
    using JobService.Test.Common;
    using Microsoft.Extensions.Options;
    using MongoDB.Driver;
    using Moq;
    using Xunit;

    /// <summary>
    /// Custom sender repository test
    /// </summary>
    public class CustomSenderRepositoryTest
    {
        private readonly CustomSenderRepository customSenderRepository;
        private readonly Mock<IDocumentDBConnectionFactory> documentDBConnectionFactory;
        private readonly Mock<IOptions<JobServiceSettings>> documentSettings;
        private readonly Mock<IDocumentDBProvider> documentDBProviderMock;
        private readonly Mock<IDocumentDBCollection<CustomSenderModel>> documentDBCollectionMock;

        public CustomSenderRepositoryTest()
        {
            this.documentDBProviderMock = new Mock<IDocumentDBProvider>();
            this.documentDBCollectionMock = new Mock<IDocumentDBCollection<CustomSenderModel>>();
            this.documentDBConnectionFactory = new Mock<IDocumentDBConnectionFactory>();

            this.documentSettings = new Mock<IOptions<JobServiceSettings>>();
            JobServiceSettings setting = new JobServiceSettings() { DocumentDBCustomSenderConnectionName = "TSMT-DocumentPackageService" };
            this.documentSettings.Setup(app => app.Value).Returns(setting);

            this.documentDBConnectionFactory.Setup(x => x.GetCollection<CustomSenderModel>(setting.DocumentDBCustomSenderConnectionName)).Returns(this.documentDBCollectionMock.Object);
            this.customSenderRepository = new CustomSenderRepository(this.documentDBConnectionFactory.Object, this.documentSettings.Object);
        }

        /// <summary>
        /// Retrieve custom senders with valid filter definition
        /// </summary>
        /// <returns>Custom sender details</returns>
        [Fact]
        public async Task GetCustomSenders_HasFilterDefinition_ReturnsCustomSenderDetails()
        {
            // Arrange
            int drAddressId = 256;
            IEnumerable<CustomSenderModel> customSenderList = Helper.GetCustomSenderModels(drAddressId);
            FilterDefinition<CustomSenderModel> filterDefinition = Builders<CustomSenderModel>.Filter.Eq(x => x.JobDrAddressId, drAddressId);
            this.documentDBCollectionMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<CustomSenderModel>>(), It.IsAny<FindOptions<CustomSenderModel, CustomSenderModel>>()))
             .Returns(Task.FromResult(customSenderList));

            // Act
            IEnumerable<CustomSenderModel> result = await this.customSenderRepository.GetCustomSenders(drAddressId);

            // Assert
            Assert.Equal(customSenderList, result);
            this.documentDBCollectionMock.Verify(x => x.FindAsync(It.IsAny<FilterDefinition<CustomSenderModel>>(), It.IsAny<FindOptions<CustomSenderModel, CustomSenderModel>>()), Times.Once);
        }

        /// <summary>
        /// Method to test create custom sender inserted successfully
        /// </summary>
        /// <returns>completed task</returns>
        [Fact]
        public async Task CreateCustomSender_ValidCustomSenderDetail_InsertedSuccessfully()
        {
            // Arrange
            CustomSenderModel customSenderModel = Helper.GetCustomSenderModel();
            this.documentDBCollectionMock.Setup(x => x.InsertOneAsync(It.IsAny<CustomSenderModel>())).Returns(Task.CompletedTask);

            // Act
            await this.customSenderRepository.CreateCustomSender(customSenderModel);

            // Assert
            this.documentDBCollectionMock.Verify(x => x.InsertOneAsync(It.IsAny<CustomSenderModel>()), Times.Once);
        }

        /// <summary>
        /// Retrieve custom sender detail with valid filter definition
        /// </summary>
        /// <returns>Custom sender detail</returns>
        [Fact]
        public async Task GetCustomSenderById_HasData_ReturnsCustomSender()
        {
            // Arrange
            string customSenderId = "45LY";
            CustomSenderModel customSenderModel = Helper.GetCustomSenderModel(customSenderId);
            FilterDefinition<CustomSenderModel> filterDefinition = Builders<CustomSenderModel>.Filter.Eq(x => x.CustomSenderId, customSenderId);
            this.documentDBCollectionMock.Setup(x => x.FindOneAsync(It.IsAny<FilterDefinition<CustomSenderModel>>(), It.IsAny<FindOptions<CustomSenderModel, CustomSenderModel>>()))
               .Returns(Task.FromResult(customSenderModel));

            // Act
            CustomSenderModel result = await this.customSenderRepository.GetCustomSenderById(customSenderId);

            // Assert
            Assert.Equal(customSenderModel, result);
            this.documentDBCollectionMock.Verify(x => x.FindOneAsync(It.IsAny<FilterDefinition<CustomSenderModel>>(), It.IsAny<FindOptions<CustomSenderModel, CustomSenderModel>>()), Times.Once);
        }

        /// <summary>
        /// Method to test Delete custom sender for a given custom sender id
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task DeleteCustomSender_DeletedSuccessfully_ReturnsTrue()
        {
            // Arrange
            string customSenderId = "f49fd5e5-ca4e-4a6d-b922-758f9510ca47";
            this.documentDBCollectionMock.Setup(x => x.DeleteOneAsync(It.IsAny<FilterDefinition<CustomSenderModel>>())).Returns(Task.FromResult(true));

            // Act
            bool result = await this.customSenderRepository.DeleteCustomSender(customSenderId);

            // Assert
            Assert.True(result);
            this.documentDBCollectionMock.Verify(x => x.DeleteOneAsync(It.IsAny<FilterDefinition<CustomSenderModel>>()), Times.Once);
        }

        /// <summary>
        /// Method to test update custom sender inserted successfully
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateCustomSender_UpdatedSuccessfully_ReturnsTrue()
        {
            // Arrange
            string customSenderId = "xyz-12rt-fg568-jk78";
            CustomSenderModel customSenderModel = Helper.GetCustomSenderModel(customSenderId);
            this.documentDBCollectionMock.Setup(x => x.UpdateOneAsync(It.IsAny<FilterDefinition<CustomSenderModel>>(), It.IsAny<UpdateDefinition<CustomSenderModel>>(), null))
                .Returns(Task.FromResult(true));

            // Act
            await this.customSenderRepository.UpdateCustomSender(customSenderModel);

            // Assert
            this.documentDBCollectionMock.Verify(x => x.UpdateOneAsync(It.IsAny<FilterDefinition<CustomSenderModel>>(), It.IsAny<UpdateDefinition<CustomSenderModel>>(), null), Times.Once);
        }

        /// <summary>
        ///  Verifies for existing custom sender nick name count response with valid inputs
        /// </summary>
        [Fact]
        public void GetCustomSenderNickNameCount_ValidInputs_ReturnsTaskCount()
        {
            // Arrange
            string customSenderNickName = "ccghrn";
            int jobDrAddressId = 101;
            int count = 21;
            this.documentDBCollectionMock.Setup(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<CustomSenderModel>>())).Returns(count);

            // Act
            var result = this.customSenderRepository.GetCustomSenderNickNameCount(jobDrAddressId, customSenderNickName);

            // Assert
            Assert.Equal(result, count);
            this.documentDBCollectionMock.Verify(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<CustomSenderModel>>()), Times.Once);
        }

        /// <summary>
        ///  Verifies for existing sender name count with sender name filter definition
        /// </summary>
        [Fact]
        public void GetSenderNameCount_HasSenderNameFilterDefinition_ReturnsTaskCount()
        {
            // Arrange
            string senderName = "ccghrn";
            int jobDrAddressId = 101;
            int count = 21;
            this.documentDBCollectionMock.Setup(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<CustomSenderModel>>())).Returns(count);

            // Act
            var result = this.customSenderRepository.GetSenderNameCount(jobDrAddressId, senderName);

            // Assert
            Assert.Equal(result, count);
            this.documentDBCollectionMock.Verify(x => x.GetDocumentsCount(It.IsAny<FilterDefinition<CustomSenderModel>>()), Times.Once);
        }
    }
}
