﻿// <copyright file="SelectionService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.ComponentModel;
   using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using JobSelectionService.Core.Models;
    using JobSelectionService.Core.Repository;
    using JobSelectionService.Core.ViewModels;
    using Microsoft.AspNetCore.Http;
    using Newtonsoft.Json;
    using TSMT.DataAccess;

    /// <summary>
    /// Service for Selection operations
    /// </summary>
    public class SelectionService : ISelectionService
    {
        private readonly ISelectionRepository selectionRepository;
        private readonly IMapper mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="SelectionService"/> class.
        /// </summary>
        /// <param name="repository">repository</param>
        /// <param name="selectionRepository">SelectionRepository</param>
        /// <param name="contextAccessor">contextAccessor</param>
        /// <param name="mapper">mapper</param>
        public SelectionService(IRepository<Selection> repository, ISelectionRepository selectionRepository, IHttpContextAccessor contextAccessor, IMapper mapper)
        {
            this.mapper = mapper;

            // We know this microservice has told the ConnectionFactory that it needs to produce connections that honor a DrAddressId.
            // By putting this responsibility on the ConnectionFactory, we greatly reduce the chance that we accidentally introduce a database interaction that doesn't honor a DrAddressId (VPD) when it should.

            // So these repositories should be honoring a DrAddressId, because they are utilizing the ConnectionFactory.
            this.selectionRepository = selectionRepository;

            // The DrAddressId to honor is stored in the HttpContext.
            int drAddressIdToHonor = 0;
            if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
                contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
                int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out drAddressIdToHonor))
            {
                this.selectionRepository.HonorDrAddressId(drAddressIdToHonor);
            }
            else
            {
                this.selectionRepository.HonorDrAddressId(null);
            }
        }

        /// <summary>
        /// Gets selections for a given job id
        /// </summary>
        /// <param name="jobId">jobId</param>
        /// <returns>Job Selections</returns>
        public async Task<JobSelectionViewModel> GetJobSelections(int jobId)
        {
            JobSelectionViewModel jobSelection = null;
            var selections = await this.selectionRepository.GetSelections(jobId);
            IEnumerable<SelectionViewModel> selectionList = this.mapper.Map<IEnumerable<Selection>, IEnumerable<SelectionViewModel>>(selections);

            if (selectionList.Any())
            {
                var pricingParams = await this.selectionRepository.GetSeparateBiddables(jobId);
                IEnumerable<PricingParamViewModel> pricingParamList = this.mapper.Map<IEnumerable<PricingParam>, IEnumerable<PricingParamViewModel>>(pricingParams);

                // Adding separate Biddable to SelectionList
                foreach (var selection in selectionList)
                {
                    selection.SeparatelyBiddableList = pricingParamList.Where(ppl => ppl.SelectionId == selection.SelectionId).ToList();
                }
            }

            var variations = await this.selectionRepository.GetVariations(jobId);
            IEnumerable<VariationViewModel> variationList = this.mapper.Map<IEnumerable<Variation>, IEnumerable<VariationViewModel>>(variations);

            // Adding selection variation to SelectionList
            foreach (var selection in selectionList)
            {
                selection.VariationList = variationList.Where(vl => vl.SelectionId == selection.SelectionId).ToList();
            }

            // Adding selectionList and JobVariationList to jobSelection
            if (selectionList.Any() || variationList.Any())
            {
                jobSelection = new JobSelectionViewModel
                {
                    SelectionList = selectionList.ToList(),
                    JobVariationList = variationList.Where(vl => vl.SelectionId == null).ToList()
                };
            }

            return jobSelection;
        }

        /// <summary>
        /// Gets the selection details
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="selectionIds">Selection ids</param>
        /// <returns>Selection details</returns>
        public async Task<IEnumerable<SelectionInfoViewModel>> GetSelectionDetails(int jobId, IEnumerable<int> selectionIds)
        {
            var selectionDetails = await this.selectionRepository.GetSelectionDetails(jobId, selectionIds);
            return this.mapper.Map<IEnumerable<SelectionInfo>, IEnumerable<SelectionInfoViewModel>>(selectionDetails);
        }

      /// <summary>
      /// Check selection exists for given job id or not
      /// </summary>
      /// <returns>Return true if selection exists else false</returns>
      /// <param name="jobId">Job id</param>
      public async Task<bool> IsSelectionExists(int jobId)
       {
         return await this.selectionRepository.GetSelectionCount(jobId) > 0;
       }

      /// <summary>
      /// Get selection performance details
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <param name="jobId">Job id</param>
      /// <param name="isJobSearch">True indicating get selections details by job id, false indicating get selections details by selection ids</param>
      /// <returns>Selection performance details</returns>
      public async Task<IEnumerable<SelectionViewModel>> GetSelectionPerformanceDetails(IEnumerable<int> selectionIds, int jobId, bool isJobSearch)
      {
         IEnumerable<Selection> selectionPerformances = await this.selectionRepository.GetSelectionPerformanceDetails(selectionIds, jobId, isJobSearch);
         return this.mapper.Map<IEnumerable<Selection>, IEnumerable<SelectionViewModel>>(selectionPerformances);
      }

      /// <summary>
      /// Get selections with reference unit details
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selections with reference unit details</returns>
      public async Task<IEnumerable<SelectionViewModel>> GetReferenceUnitDetails(int jobId)
      {
         IEnumerable<Selection> referenceUnits = await this.selectionRepository.GetReferenceUnitDetails(jobId);
         return this.mapper.Map<IEnumerable<Selection>, IEnumerable<SelectionViewModel>>(referenceUnits);
      }

      /// <summary>
      /// Get bids selections and si ids
      /// If product family ids does have ship cycle vpc then we are getting selection ids for the product family ids
      /// If product families selection ids doesn't have si ids then we are getting salesman description for the product families selection ids
      /// If product families selection ids does have si ids then we are getting si ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="jobCoordinationId">Job coordination id</param>
      /// <returns>Bids selections and si ids</returns>
      public async Task<IEnumerable<BidSelectionViewModel>> GetBidsSelections(int jobId, int jobCoordinationId)
      {
         string billOfMaterials = Encoding.UTF8.GetString(await this.selectionRepository.GetBillOfMaterials(jobCoordinationId));

         IEnumerable<BillOfMaterial> billOfMaterialsModel = this.DeserializeJsonObjectCollection<BillOfMaterial>(billOfMaterials);
         IEnumerable<BidSelectionViewModel> bidsSelections = this.mapper.Map<IEnumerable<BillOfMaterial>, IEnumerable<BidSelectionViewModel>>(billOfMaterialsModel);

         var productFamilyIds = bidsSelections.Where(x => x.SelectionSource == "C" && !x.DoesSeparatelyBiddableSelectionsExist).Select(x => x.ProductFamilyId);

         // Get product family ids which is have ship cycle vpc
         IEnumerable<int> shipCycleHavingProductFamilyIds = await this.selectionRepository.GetProductFamilyIds(productFamilyIds);

         var productFamilyDoesHaveShipCycleVpcs = productFamilyIds.Except(shipCycleHavingProductFamilyIds);
         if (productFamilyDoesHaveShipCycleVpcs.Any())
         {
            // Get selection ids does have ship cycle vpc
            IEnumerable<int> selectionIds = bidsSelections.Where(x => productFamilyDoesHaveShipCycleVpcs.Contains(x.ProductFamilyId)).SelectMany(y => y.SelectionIds).Distinct();

            // Get the SI ids for the selection ids
            IEnumerable<Si> sis = await this.selectionRepository.GetSis(jobId, selectionIds);

            if (sis.Any())
            {
               foreach (var selection in bidsSelections)
               {
                  selection.SiIds = sis.Where(x => selection.SelectionIds.Contains(x.SELECTION_ID)).Select(x => x.SI_ID).Distinct();
               }
            }

            // Get selection ids doesn't have SI id
            IEnumerable<int> selectionIdDoesntHaveSiIds = selectionIds.Except(sis.Select(x => x.SELECTION_ID));
            if (selectionIdDoesntHaveSiIds.Any())
            {
               await this.SetSelections(selectionIdDoesntHaveSiIds, jobId, bidsSelections);
            }
         }

         return bidsSelections;
      }

      /// <summary>
      /// Gets the selected items
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Selected items</returns>
      public async Task<IEnumerable<SelectionViewModel>> GetSelectedItems(int jobId, IEnumerable<int> selectionIds)
      {
         IEnumerable<Selection> selectedItems = await this.selectionRepository.GetSelectedItems(jobId, selectionIds);
         return this.mapper.Map<IEnumerable<Selection>, IEnumerable<SelectionViewModel>>(selectedItems);
      }

      /// <summary>
      /// Gets the trane items
      /// </summary>
      /// <param name="pagingOptions">Parameters to perform pagination</param>
      /// <param name="jobId ">Id of the corresponding job</param>
      /// <returns>Trane items</returns>
      public async Task<SelectionsPagingResults> GetTraneItems(ViewModels.PagingOptions pagingOptions, int jobId)
      {
         if (pagingOptions.Sort != null && pagingOptions.Sort.Any())
         {
            pagingOptions.Sort.ForEach(x => x.SortBy = this.GetModelDescription<SelectionViewModel>(x.SortBy));
         }

         if (pagingOptions.Filters != null && pagingOptions.Filters.Any())
         {
            pagingOptions.Filters.ForEach(x => x.Filters.ForEach(y => y.Field = this.GetModelDescription<SelectionViewModel>(y.Field)));
         }

         var paginations = this.mapper.Map<ViewModels.PagingOptions, TSMT.DataAccess.PagingOptions>(pagingOptions);

         var selections = await this.selectionRepository.GetTraneItems(paginations, jobId);
         IEnumerable<SelectionViewModel> selectionViews = this.mapper.Map<IEnumerable<Selection>, IEnumerable<SelectionViewModel>>(selections);

         SelectionsPagingResults selectionsPagingResults = null;
         selectionsPagingResults = new SelectionsPagingResults
         {
            SelectionList = selectionViews
         };

         if (selectionsPagingResults.SelectionList != null && selectionsPagingResults.SelectionList.Any())
         {
            selectionsPagingResults.TotalItemCount = (from sl in selectionsPagingResults.SelectionList
                                                         select sl.TotalCount).First();
            selectionsPagingResults.PageSize = pagingOptions.Take;
            selectionsPagingResults.PageNumber = Math.Ceiling((double)(pagingOptions.Skip - 1) / selectionsPagingResults.PageSize) + 1;
            if (selectionsPagingResults.TotalItemCount > 0)
            {
               selectionsPagingResults.PageCount = Math.Ceiling((double)selectionsPagingResults.TotalItemCount / selectionsPagingResults.PageSize);
            }
         }

            return selectionsPagingResults;
      }

      /// <summary>
      /// Gets all the selected item net price grouped by pricing param based on job id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selection pricing params</returns>
      public async Task<IEnumerable<PricingParamViewModel>> GetSelectedPricingParamRecords(int jobId)
      {
         IEnumerable<PricingParam> pricingParams = await this.selectionRepository.GetSelectedPricingParamRecords(jobId);
         IEnumerable<PricingParamViewModel> selectedParams = this.mapper.Map<IEnumerable<PricingParam>, IEnumerable<PricingParamViewModel>>(pricingParams);
         IEnumerable<PricingParam> separateBiddables = await this.selectionRepository.GetSeparateBiddables(jobId);
         IEnumerable<PricingParamViewModel> selectedPricingParams = (from s in selectedParams
                                                                     join sb in separateBiddables
                                                                     on s.SelectedPricingParmId equals sb.SELECTED_PRICING_PARM_ID
                                                                     select new PricingParamViewModel
                                                                     {
                                                                        SelectedPricingParmId = s.SelectedPricingParmId,
                                                                        SelectionId = s.SelectionId,
                                                                        ProductCode = sb.PROD_CODE,
                                                                        NetPrice = s.NetPrice,
                                                                        IsSeparatelyBiddable = sb.SEPARATELY_BIDDABLE_YES_NO
                                                                     }).ToList();
         IEnumerable<Selection> selections = await this.selectionRepository.GetSelections(jobId);
         selectedPricingParams.ToList().ForEach(y =>
         {
            y.IsMainUnit = selections.Any(x => x.SELECTION_ID == y.SelectionId && x.PROD_CODE == y.ProductCode);
         });
         return selectedPricingParams;
      }

      /// <summary>
      /// Gets selected pricing param records based on spp ids
      /// </summary>
      /// <param name="selectedPricingParamIds">Selected pricing param Ids</param>
      /// <returns>Selected pricing params</returns>
      public async Task<IEnumerable<PricingParamViewModel>> GetSelectedPricingParams(IEnumerable<int> selectedPricingParamIds)
      {
         IEnumerable<PricingParam> pricingParams = await this.selectionRepository.GetSelectedPricingParamByIds(selectedPricingParamIds);
         return this.mapper.Map<IEnumerable<PricingParam>, IEnumerable<PricingParamViewModel>>(pricingParams);
      }

      /// <summary>
      /// Gets ship cycle details
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Ship cycle details</returns>
      public async Task<IEnumerable<ShipCycleViewModel>> GetShipCycleDetails(IEnumerable<int> selectionIds)
      {
         IEnumerable<ShipCycle> shipCycleDetails = await this.selectionRepository.GetShipCycleDetails(selectionIds);
         return this.mapper.Map<IEnumerable<ShipCycle>, IEnumerable<ShipCycleViewModel>>(shipCycleDetails);
      }

      /// <summary>
      /// Set selections
      /// </summary>
      /// <param name="selectionIdDoesntHaveSiIds">Selection ids</param>
      /// <param name="jobId">Job id</param>
      /// <param name="bidsSelections">Bids selections</param>
      /// <returns>Set selections description</returns>
      private async Task SetSelections(IEnumerable<int> selectionIdDoesntHaveSiIds, int jobId, IEnumerable<BidSelectionViewModel> bidsSelections)
      {
         // Get the selection error message for the job id and selection ids
         IEnumerable<Selection> selections = await this.selectionRepository.GetBidsSelections(jobId, selectionIdDoesntHaveSiIds);

         foreach (var bidsSelection in bidsSelections)
         {
            bidsSelection.Descriptions = selections.Where(x => bidsSelection.SelectionIds.Contains(x.SELECTION_ID)).Select(x => x.TAG != string.Empty ? '<' + x.TAG + '>' + " " + x.SALESMAN_DESCR : x.SALESMAN_DESCR);
         }
      }

      /// <summary>
      /// Deserialize the json object to collection
      /// </summary>
      /// <typeparam name="T">Type of object to which it gets deserialized</typeparam>
      /// <param name="serializedJsonObjectCollection">Serialized json object collection data</param>
      /// <returns>Deserialized object collection</returns>
      private IEnumerable<T> DeserializeJsonObjectCollection<T>(string serializedJsonObjectCollection)
      {
         return JsonConvert.DeserializeObject<IEnumerable<T>>(serializedJsonObjectCollection);
      }

      /// <summary>
      /// Get model description
      /// </summary>
      /// <typeparam name="T">Model which is passed from the entity</typeparam>
      /// <param name="shortString">String to be converted into model description</param>
      /// <returns>Model description</returns>
      private string GetModelDescription<T>(string shortString)
      {
         shortString = char.ToUpper(shortString[0]) + shortString.Substring(1);
         return typeof(T).GetProperty(shortString).GetCustomAttributes(typeof(DescriptionAttribute), false).Cast<DescriptionAttribute>().FirstOrDefault()?.Description;
      }
   }
}
