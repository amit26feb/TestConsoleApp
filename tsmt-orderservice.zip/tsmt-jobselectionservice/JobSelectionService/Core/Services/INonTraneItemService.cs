﻿// <copyright file="INonTraneItemService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Services
{
   using System.Threading.Tasks;
   using JobSelectionService.Core.ViewModels;
   using Microsoft.AspNetCore.JsonPatch;

   /// <summary>
   /// Interface for non trane items service
   /// </summary>
   public interface INonTraneItemService
   {
      /// <summary>
      /// Gets list of non trane item based on job id
      /// </summary>
      /// <param name="pagingOptions">Parameter to perform pagination</param>
      /// <param name="jobId">Job id</param>
      /// <returns>List of non trane item for a corresponding job id</returns>
      Task<NonTraneItemPagingResults> GetNonTraneItems(PagingOptions pagingOptions, int jobId);

      /// <summary>
      /// Get non trane item based on job id and variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Non trane item based on job id and variation id</returns>
      Task<NonTraneItemViewModel> GetNonTraneItem(int variationId, int jobId);

      /// <summary>
      /// Create non trane item for a job
      /// </summary>
      /// <param name="nonTraneItem">Request for create non trane item</param>
      /// <returns>Variation id</returns>
      Task<int> CreateNonTraneItem(NonTraneItemViewModel nonTraneItem);

      /// <summary>
      /// Delete non trane item based on variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <returns>Deleted status</returns>
      Task<int> DeleteNonTraneItem(int variationId);

      /// <summary>
      /// Update non trane item for a job
      /// </summary>
      /// <param name="jsonPatchDocument">Patch payload for update non trane item</param>
      /// <returns>True or false based on update status</returns>
      Task<bool> UpdateNonTraneItem(JsonPatchDocument jsonPatchDocument);
   }
}
