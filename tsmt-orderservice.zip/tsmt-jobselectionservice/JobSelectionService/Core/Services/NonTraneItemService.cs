﻿// <copyright file="NonTraneItemService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.ComponentModel;
   using System.Linq;
   using System.Text;
   using System.Text.RegularExpressions;
   using System.Threading.Tasks;
   using AutoMapper;
   using Dapper;
   using JobSelectionService.Common.Constants;
   using JobSelectionService.Configurations;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.Repository;
   using JobSelectionService.Core.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Microsoft.AspNetCore.JsonPatch;
   using Microsoft.AspNetCore.JsonPatch.Operations;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Newtonsoft.Json;
   using Newtonsoft.Json.Linq;

   /// <summary>
   /// Service for non trane items operations
   /// </summary>
   public class NonTraneItemService : INonTraneItemService
   {
      private readonly INonTraneItemRepository nonTraneItemRepository;
      private readonly IMapper mapper;
      private readonly ILogger<INonTraneItemService> logger;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettings;

      /// <summary>
      /// Initializes a new instance of the <see cref="NonTraneItemService"/> class.
      /// </summary>
      /// <param name="nonTraneItemRepository">Non trane item repository</param>
      /// <param name="contextAccessor">contextAccessor</param>
      /// <param name="mapper">mapper</param>
      /// <param name="logger">Non trane item logger</param>
      /// <param name="commonConfigurationSettings">Common configuration settings</param>
      public NonTraneItemService(INonTraneItemRepository nonTraneItemRepository, IHttpContextAccessor contextAccessor, IMapper mapper, ILogger<INonTraneItemService> logger, IOptions<CommonConfigurationSettings> commonConfigurationSettings)
      {
         this.mapper = mapper;
         this.logger = logger;

         // We know this microservice has told the ConnectionFactory that it needs to produce connections that honor a DrAddressId.
         // By putting this responsibility on the ConnectionFactory, we greatly reduce the chance that we accidentally introduce a database interaction that doesn't honor a DrAddressId (VPD) when it should.

         // So these repositories should be honoring a DrAddressId, because they are utilizing the ConnectionFactory.
         this.nonTraneItemRepository = nonTraneItemRepository;

         // The DrAddressId to honor is stored in the HttpContext.
         int drAddressIdToHonor = 0;
         if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
             contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out drAddressIdToHonor))
         {
            this.nonTraneItemRepository.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.nonTraneItemRepository.HonorDrAddressId(null);
         }

         this.commonConfigurationSettings = commonConfigurationSettings;
      }

      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets list of non trane item based on job id
      /// </summary>
      /// <param name="pagingOptions">Parameter to perform pagination</param>
      /// <param name="jobId">Job id</param>
      /// <returns>List of non trane item for a corresponding job id</returns>
      public async Task<NonTraneItemPagingResults> GetNonTraneItems(ViewModels.PagingOptions pagingOptions, int jobId)
      {
         if (pagingOptions.Sort != null && pagingOptions.Sort.Any())
         {
            pagingOptions.Sort.ForEach(x => x.SortBy = this.GetModelDescription<NonTraneItemViewModel>(x.SortBy));
         }

         if (pagingOptions.Filters.Any())
         {
            pagingOptions.Filters.ForEach(x => x.Filters.ForEach(y => y.Field = this.GetModelDescription<NonTraneItemViewModel>(y.Field)));
         }

         var paginations = this.mapper.Map<ViewModels.PagingOptions, TSMT.DataAccess.PagingOptions>(pagingOptions);

         var nonTraneItems = await this.nonTraneItemRepository.GetNonTraneItems(paginations, jobId);
         IEnumerable<NonTraneItemViewModel> nonTraneItemViewModel = this.mapper.Map<IEnumerable<NonTraneItem>, IEnumerable<NonTraneItemViewModel>>(nonTraneItems);
         NonTraneItemPagingResults nonTraneItemPagingResults = new NonTraneItemPagingResults
         {
            NonTraneItems = nonTraneItemViewModel
         };

         if (nonTraneItemPagingResults.NonTraneItems != null && nonTraneItemPagingResults.NonTraneItems.Any())
         {
            nonTraneItemPagingResults.TotalItemCount = (from nonTraneItem in nonTraneItemPagingResults.NonTraneItems
                                                        select nonTraneItem.TotalCount).First();
            nonTraneItemPagingResults.PageSize = pagingOptions.Take;
            nonTraneItemPagingResults.PageNumber = Convert.ToInt32(Math.Ceiling((double)(pagingOptions.Skip - 1) / nonTraneItemPagingResults.PageSize) + 1);
            if (nonTraneItemPagingResults.TotalItemCount > 0)
            {
               nonTraneItemPagingResults.PageCount = Convert.ToInt32(Math.Ceiling((double)nonTraneItemPagingResults.TotalItemCount / nonTraneItemPagingResults.PageSize));
            }
         }

         return nonTraneItemPagingResults;
      }

      /// <summary>
      /// Get non trane item based on job id and variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Return non trane item based on job id and variation id</returns>
      public async Task<NonTraneItemViewModel> GetNonTraneItem(int variationId, int jobId)
      {
         NonTraneItemViewModel nonTraneItemViewModel = null;
         NonTraneItem nonTraneItem = await this.nonTraneItemRepository.GetNonTraneItem(variationId, jobId);
         if (nonTraneItem != null)
         {
            nonTraneItemViewModel = this.mapper.Map<NonTraneItem, NonTraneItemViewModel>(nonTraneItem);
            IEnumerable<TagDetail> tagDetails = await this.nonTraneItemRepository.GetTagDetails(variationId, jobId);

            IEnumerable<Document> documents = await this.nonTraneItemRepository.GetDocumentDetails(jobId, variationId);
            if (documents?.Any() == true)
            {
               nonTraneItemViewModel.DocumentDetails = this.mapper.Map<IEnumerable<Document>, IEnumerable<DocumentViewModel>>(documents);
            }

            nonTraneItemViewModel.TagDetails = this.mapper.Map<List<TagDetail>, List<TagDetailViewModel>>(tagDetails.ToList());
         }

         return nonTraneItemViewModel;
      }

      /// <summary>
      /// Create non trane item for a job
      /// </summary>
      /// <param name="nonTraneItem">Request for create non trane item</param>
      /// <returns>Variation id</returns>
      public async Task<int> CreateNonTraneItem(NonTraneItemViewModel nonTraneItem)
      {
         var variationId = await this.nonTraneItemRepository.GetSequenceNumber("VARIATION", 1);
         nonTraneItem.VariationId = variationId;

         // Reserving sequence number
         var referenceUnitSequenceNumber = await this.nonTraneItemRepository.GetSequenceNumber("REFERENCE_UNIT", nonTraneItem.TagDetails.Count);

         var nonTraneItemEntity = this.mapper.Map<NonTraneItemViewModel, NonTraneItem>(nonTraneItem);

         // Assigning values to model
         if (nonTraneItemEntity.TAGDETAILS.Any())
         {
            nonTraneItemEntity.TAGDETAILS.ForEach(x =>
            {
               x.VARIATION_ID = nonTraneItem.VariationId;
               x.JOB_ID = nonTraneItem.JobId;
               x.REFERENCE_UNIT_ID = referenceUnitSequenceNumber;
               referenceUnitSequenceNumber++;
            });
         }

         var result = await this.nonTraneItemRepository.CreateNonTraneItemAsync(nonTraneItemEntity);

         return result > 0 ? variationId : 0;
      }

      /// <summary>
      /// Delete non trane item based on variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <returns>Deleted status</returns>
      public async Task<int> DeleteNonTraneItem(int variationId)
      {
         return await this.nonTraneItemRepository.DeleteNonTraneItem(variationId);
      }

      /// <summary>
      /// Update non trane item for a job
      /// </summary>
      /// <param name="jsonPatchDocument">Patch payload for update non trane item</param>
      /// <returns>True or false based on update status</returns>
      public async Task<bool> UpdateNonTraneItem(JsonPatchDocument jsonPatchDocument)
      {
         List<PatchOperation> patchOperations = new List<PatchOperation>();
         int paramSequence = 0;
         foreach (var operation in jsonPatchDocument.Operations)
         {
            if (operation.op == "replace")
            {
               paramSequence = ++paramSequence;
            }

            List<PatchOperation> patchOperation = this.ProcessPatchOperation(operation, paramSequence);
            if (patchOperation != null)
            {
               patchOperations.AddRange(patchOperation);
            }
            else
            {
               this.logger.LogTrace("Json patch document has invalid operation for non trane item update");
               return false;
            }
         }

         if (patchOperations.Count > 0)
         {
            return await this.nonTraneItemRepository.UpdateNonTraneItemAsync(patchOperations);
         }
         else
         {
            this.logger.LogTrace("Json patch document has mismatch path for non trane item update");
            return false;
         }
      }

      /// <summary>
      /// Process patch operation for update non trane item
      /// </summary>
      /// <param name="operation">Patch operation for update non trane item</param>
      /// <param name="paramSequence">Sequence number of dynamic parameter to differentiate them in multiple queries</param>
      /// <returns>Updated patch operation</returns>
      private List<PatchOperation> ProcessPatchOperation(Operation operation, int paramSequence)
      {
         List<PatchOperation> patchOperations = new List<PatchOperation>();
         Dictionary<string, Regex> pathPatterns = this.LoadPathPatterns();
         foreach (KeyValuePair<string, Regex> element in pathPatterns)
         {
            Match match = element.Value.Match(operation.path.ToString());
            if (match.Success)
            {
               PatchOperation patchOperation = new PatchOperation();
               this.JobId = int.Parse(match.Groups["JobId"].Captures[0].ToString());
               patchOperation.DynamicParameters = new DynamicParameters();

               if (element.Key == "ReferenceUnit")
               {
                  int referenceUnitId = !match.Groups["ReferenceUnitId"].Captures[0].ToString().Contains("Reference/") ?
                  int.Parse(match.Groups["ReferenceUnitId"].Captures[0].ToString()) : 0;

                  patchOperation = this.ProcessReferenceUnitPatchOperation(operation, paramSequence, patchOperation, referenceUnitId);
                  patchOperations.Add(patchOperation);
               }
               else if (operation.op == "replace")
               {
                  int variationId = int.Parse(match.Groups["VariationId"].Captures[0].ToString());

                  List<string> filterColumns = new List<string> { "Variation_Id" };

                  patchOperation = this.SetPatchOperation("VARIATION", filterColumns, paramSequence, operation, variationId);
                  patchOperations.Add(patchOperation);

                  // Should not update variation companion table when disable rebalancing is true
                  if (!this.commonConfigurationSettings.Value.DisableRebalancing && this.HasCostForecastParam(operation))
                  {
                     patchOperation = this.SetPatchOperation("VARIATION_COMPANION", filterColumns, paramSequence, operation, variationId);
                     patchOperations.Add(patchOperation);
                  }

                  return patchOperations;
               }
            }
         }

         return patchOperations;
      }

      /// <summary>
      /// Process reference unit patch operation for update non trane item
      /// </summary>
      /// <param name="operation">Patch operation for update non trane item</param>
      /// <param name="paramSequence">Sequence number of dynamic parameter to differentiate them in multiple queries</param>
      /// <param name="patchOperation">Patch operation for reference unit</param>
      /// <param name="referenceUnitId">Reference unit id</param>
      /// <returns>Updated patch operation</returns>
      private PatchOperation ProcessReferenceUnitPatchOperation(Operation operation, int paramSequence, PatchOperation patchOperation, int referenceUnitId)
      {
         if (operation.op == "replace")
         {
            List<string> filterColumns = new List<string> { "Reference_Unit_Id" };
            JArray param = JArray.FromObject(operation.value);
            patchOperation = this.BaseReplaceQuery("REFERENCE_UNIT", param, filterColumns, paramSequence);
            patchOperation.DynamicParameters.Add($"Reference_Unit_Id{paramSequence}", referenceUnitId);
         }
         else
         {
            patchOperation.DynamicParameters.Add("Reference_Unit_Id", referenceUnitId);
         }

         patchOperation.TableName = "REFERENCE_UNIT";
         patchOperation.Operation = operation.op;
         patchOperation.TableValue = operation.value;

         if (operation.op == "add")
         {
            var referenceUnit = JsonConvert.DeserializeObject<List<ReferenceUnit>>(patchOperation.TableValue.ToString()).FirstOrDefault();
            referenceUnit.JOB_ID = this.JobId;
            patchOperation.TableValue = referenceUnit;
         }

         return patchOperation;
      }

      /// <summary>
      /// Builds the replace query dynamically
      /// </summary>
      /// <param name="tableName">Name of specific table</param>
      /// <param name="values">Json array values</param>
      /// <param name="filterColumns">Columns for replace operation</param>
      /// <param name="paramSequence">Sequence number of dynamic parameter to differentiate them in multiple queries</param>
      /// <returns>Base patch operation which contains query and dynamic parameters</returns>
      private PatchOperation BaseReplaceQuery(string tableName, JArray values, List<string> filterColumns, int paramSequence)
      {
         var dynamicParams = new DynamicParameters();
         StringBuilder sb = new StringBuilder($"UPDATE {tableName} SET ");

         // Remove cost_forecast from variation params and other params from variation_companion
         foreach (var value in values)
         {
            Dictionary<string, object> parameters = value.ToObject<Dictionary<string, object>>();

            if (tableName != "VARIATION_COMPANION")
            {
               parameters.Remove(Constants.CostForecast);
            }
            else
            {
               foreach (var data in parameters)
               {
                  if (!data.Key.Contains(Constants.CostForecast))
                  {
                     parameters.Remove(data.Key);
                  }
               }
            }

            // Append properties and their values to the query
            this.AppendColumns(dynamicParams, sb, parameters, paramSequence);
         }

         // Append filter conditions to the query
         this.AppendFilters(sb, filterColumns, paramSequence);
         PatchOperation patchOperation = new PatchOperation
         {
            Query = sb.ToString(),
            DynamicParameters = dynamicParams,
            TableName = tableName,
            Operation = "replace"
         };
         sb.Clear();
         return patchOperation;
      }

      /// <summary>
      /// Append filters for the query
      /// </summary>
      /// <param name="sb">String builder</param>
      /// <param name="filterColumns">Columns for replace operation</param>
      /// <param name="paramSequence">Sequence number of dynamic parameter to differentiate them in multiple queries</param>
      private void AppendFilters(StringBuilder sb, List<string> filterColumns, int paramSequence)
      {
         sb.Append(" WHERE ");
         var filterColumnCount = filterColumns.Count;
         int columnCount = 1;
         foreach (string column in filterColumns)
         {
            sb.Append(column + "=:" + column + paramSequence);
            if (columnCount < filterColumnCount)
            {
               sb.Append(" AND ");
            }

            columnCount++;
         }
      }

      /// <summary>
      /// Append columns and their values to the query
      /// </summary>
      /// <param name="dynamicParams">Dynamic parameters</param>
      /// <param name="sb">String builder</param>
      /// <param name="value">Dictionary containing column and their values</param>
      /// <param name="paramSequence">Sequence number of dynamic parameter to differentiate them in multiple queries</param>
      private void AppendColumns(DynamicParameters dynamicParams, StringBuilder sb, Dictionary<string, object> value, int paramSequence)
      {
         var columnCount = value.Count;
         int count = 1;
         foreach (var property in value)
         {
            if (property.Value != null)
            {
               // Converting date value to utc dateTime format
               if (property.Key.ToLower().StartsWith("date") || property.Key.ToLower().EndsWith("date"))
               {
                  dynamicParams.Add(property.Key + paramSequence, Convert.ToDateTime(property.Value), System.Data.DbType.Date);
               }
               else
               {
                  dynamicParams.Add(property.Key + paramSequence, property.Value.ToString());
               }
            }
            else
            {
               dynamicParams.Add(property.Key + paramSequence, null);
            }

            sb.Append(property.Key + "=:" + property.Key + paramSequence);
            if (count < columnCount)
            {
               sb.Append(", ");
            }

            count++;
         }
      }

      /// <summary>
      /// This method will add json path patterns into list for finding table
      /// </summary>
      /// <returns>List of json path patterns</returns>
      private Dictionary<string, Regex> LoadPathPatterns()
      {
         Dictionary<string, Regex> pathPatterns = new Dictionary<string, Regex>
         {
            { "Variation", new Regex(@"^\/Jobs/(?<JobId>[\d]+)/Variations/(?<VariationId>[a-z0-9/-]+)$", RegexOptions.IgnoreCase) },
            { "ReferenceUnit", new Regex(@"^\/Jobs\/(?<JobId>[\d]+)/ReferenceUnits/(?<ReferenceUnitId>[a-z0-9/-]+)$", RegexOptions.IgnoreCase) }
         };
         return pathPatterns;
      }

      /// <summary>
      /// Get model description
      /// </summary>
      /// <typeparam name="T">Model which is passed from the entity</typeparam>
      /// <param name="shortString">String to be converted into model description</param>
      /// <returns>Model description</returns>
      private string GetModelDescription<T>(string shortString)
      {
         shortString = char.ToUpper(shortString[0]) + shortString.Substring(1);
         return typeof(T).GetProperty(shortString).GetCustomAttributes(typeof(DescriptionAttribute), false).Cast<DescriptionAttribute>().FirstOrDefault()?.Description;
      }

      /// <summary>
      /// Set patch operation
      /// </summary>
      /// <param name="tableName">table Name</param>
      /// <param name="filterColumns">List of filter Columns</param>
      /// <param name="paramSequence">Sequence number of dynamic parameter to differentiate them in multiple queries</param>
      /// <param name="operation">operation</param>
      /// <param name="variationId">variationId</param>
      /// <returns>PatchOperation</returns>
      private PatchOperation SetPatchOperation(string tableName, List<string> filterColumns, int paramSequence, Operation operation, int variationId)
      {
         JArray param = JArray.FromObject(operation.value);
         PatchOperation patchOperation = this.BaseReplaceQuery(tableName, param, filterColumns, paramSequence);
         patchOperation.TableName = tableName;
         patchOperation.Operation = operation.op;
         patchOperation.TableValue = operation.value;

         // Adding variation id as parameter value
         patchOperation.DynamicParameters.Add($"Variation_Id{paramSequence}", variationId);
         return patchOperation;
      }

      /// <summary>
      /// Checks if costForecast param value is modified in update
      /// </summary>
      /// <param name="operation">Patch operation for update non trane item</param>
      /// <returns>bool</returns>
      private bool HasCostForecastParam(Operation operation)
      {
         JArray param = JArray.FromObject(operation.value);
         foreach (var value in param)
         {
            Dictionary<string, object> parameters = value.ToObject<Dictionary<string, object>>();
            foreach (var property in parameters)
            {
               if (property.Key == Constants.CostForecast)
               {
                  return true;
               }
            }
         }

         return false;
      }
   }
}
