﻿// <copyright file="ISelectionService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
   using JobSelectionService.Core.ViewModels;

    /// <summary>
    /// ISelectionService
    /// </summary>
    public interface ISelectionService
    {
        /// <summary>
        /// Gets list of selection based on job id
        /// </summary>
        /// <param name="jobId">job id</param>
        /// <returns>List of selection for a corresponding job id</returns>
        Task<JobSelectionViewModel> GetJobSelections(int jobId);

        /// <summary>
        /// Gets the selection details
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="selectionIds">Selection ids</param>
        /// <returns>Selection details</returns>
        Task<IEnumerable<SelectionInfoViewModel>> GetSelectionDetails(int jobId, IEnumerable<int> selectionIds);

      /// <summary>
      /// Check selection exists for given job id or not
      /// </summary>
      /// <returns>Return true if selection exists else false</returns>
      /// <param name="jobId">Job id</param>
      Task<bool> IsSelectionExists(int jobId);

      /// <summary>
      /// Get bids selections and si ids
      /// If product family ids does have ship cycle vpc then we are getting selection ids for the product family ids
      /// If product families selection ids doesn't have si ids then we are getting salesman description for the product families selection ids
      /// If product families selection ids does have si ids then we are getting si ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="jobCoordinationId">Job coordination id</param>
      /// <returns>Bids selections and si ids</returns>
      Task<IEnumerable<BidSelectionViewModel>> GetBidsSelections(int jobId, int jobCoordinationId);

      /// <summary>
      /// Gets the selected items
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Selected items</returns>
      Task<IEnumerable<SelectionViewModel>> GetSelectedItems(int jobId, IEnumerable<int> selectionIds);

      /// <summary>
      /// Get selection performance details
      /// </summary>
      /// <param name="selectionIds">selection ids</param>
      /// <param name="jobId">Job id</param>
      /// <param name="isJobSearch">True indicating get selections details by job id, false indicating get selections details by selection ids</param>
      /// <returns>Selection performance details</returns>
      Task<IEnumerable<SelectionViewModel>> GetSelectionPerformanceDetails(IEnumerable<int> selectionIds, int jobId, bool isJobSearch);

      /// <summary>
      /// Gets the trane items
      /// </summary>
      /// <param name="pagingOptions">Parameters to perform pagination</param>
      /// <param name="jobId ">Id of the corresponding job</param>
      /// <returns>Trane items</returns>
      Task<SelectionsPagingResults> GetTraneItems(PagingOptions pagingOptions, int jobId);

      /// <summary>
      /// Gets all the selected item net price grouped by pricing param based on job id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selection details</returns>
      Task<IEnumerable<PricingParamViewModel>> GetSelectedPricingParamRecords(int jobId);

      /// <summary>
      /// Gets selected pricing param records based on spp ids
      /// </summary>
      /// <param name="selectedPricingParamIds">Selected pricing param Ids</param>
      /// <returns>Selected pricing params</returns>
      Task<IEnumerable<PricingParamViewModel>> GetSelectedPricingParams(IEnumerable<int> selectedPricingParamIds);

      /// <summary>
      /// Get selections with reference unit details
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selections with reference unit details</returns>
      Task<IEnumerable<SelectionViewModel>> GetReferenceUnitDetails(int jobId);

      /// <summary>
      /// Gets ship cycle details
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Ship cycle details</returns>
      Task<IEnumerable<ShipCycleViewModel>> GetShipCycleDetails(IEnumerable<int> selectionIds);
   }
}
