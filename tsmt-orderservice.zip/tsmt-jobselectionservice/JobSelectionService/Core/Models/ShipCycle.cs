﻿// <copyright file="ShipCycle.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
   /// <summary>
   /// Ship cycle detail
   /// </summary>
   public class ShipCycle
   {
      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets si id
      /// </summary>
      public int SI_ID { get; set; }

      /// <summary>
      /// Gets or sets si type
      /// </summary>
      public string SI_TYPE { get; set; }

      /// <summary>
      /// Gets or sets unit of measure
      /// </summary>
      public string UOM { get; set; }

      /// <summary>
      /// Gets or sets ship cycle length
      /// </summary>
      public int SHIP_CYCLE_LENGTH { get; set; }

      /// <summary>
      /// Gets or sets vpc id
      /// </summary>
      public int VPC_ID { get; set; }
   }
}
