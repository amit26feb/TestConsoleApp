﻿// <copyright file="Document.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
    using TSMT.DataAccess;

    /// <summary>
    /// Model for document
    /// </summary>
    public class Document : IDataEntity
    {
        /// <summary>
        /// Gets or sets document key
        /// </summary>
        public string DOCUMENT_KEY { get; set; }

        /// <summary>
        /// Gets or sets document name
        /// </summary>
        public string DOCUMENT_NAME { get; set; }

        /// <summary>
        /// Gets or sets document version
        /// </summary>
        public string DOCUMENT_VERSION { get; set; }

        /// <summary>
        /// Gets or sets job document type id
        /// </summary>
        public int? JOB_DOCUMENT_TYPE_ID { get; set; }
   }
}
