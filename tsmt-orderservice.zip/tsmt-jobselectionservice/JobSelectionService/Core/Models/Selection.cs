﻿// <copyright file="Selection.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for Selection
   /// </summary>
   public class Selection : IDataEntity
   {
      /// <summary>
      /// Gets or sets SELECTION_ID
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets SALESMAN_DESCR
      /// </summary>
      public string SALESMAN_DESCR { get; set; }

      /// <summary>
      /// Gets or sets UNIT_QTY
      /// </summary>
      public int UNIT_QTY { get; set; }

      /// <summary>
      /// Gets or sets PROD_FAMILY
      /// </summary>
      public string PROD_FAMILY { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_ORD_NBR
      /// </summary>
      public string LEGACY_ORD_NBR { get; set; }

      /// <summary>
      /// Gets or sets PROD_CODE
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets TAG
      /// </summary>
      public string TAG { get; set; }

      /// <summary>
      /// Gets or sets ORDERED_INDICATOR
      /// </summary>
      public string ORDERED_INDICATOR { get; set; }

      /// <summary>
      /// Gets or sets PRICED_INDICATOR
      /// </summary>
      public string PRICED_INDICATOR { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the item is configured or not
      /// </summary>
      public bool IsConfiguredItem { get; set; }

      /// <summary>
      /// Gets or sets BID_ALTERNATE_ID
      /// </summary>
      public int? BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets HQTR_SELECTION_ID
      /// </summary>
      public int? HQTR_SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets SELECTION_SOURCE
      /// </summary>
      public string SELECTION_SOURCE { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int? SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets PENDING_ORDER_IND
      /// </summary>
      public string PENDING_ORDER_IND { get; set; }

      /// <summary>
      /// Gets or sets SEL_PRICE_COMPLETE
      /// </summary>
      public string SEL_PRICE_COMPLETE { get; set; }

      /// <summary>
      /// Gets or sets PRICE_CONTROL_ID
      /// </summary>
      public int? PRICE_CONTROL_ID { get; set; }

      /// <summary>
      /// Gets or sets revise date
      /// </summary>
      public DateTime? REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets list price
      /// </summary>
      public decimal? LIST_PRICE { get; set; }

      /// <summary>
      /// Gets or sets total net dollars
      /// </summary>
      public decimal? TOTAL_NET_DOLLARS { get; set; }

      /// <summary>
      /// Gets or sets total count
      /// </summary>
      public int TOTAL_COUNT { get; set; }

      /// <summary>
      /// Gets or sets sequence number
      /// </summary>
      public int? SEQUENCE_NBR { get; set; }

      /// <summary>
      /// Gets or sets source
      /// </summary>
      public string SOURCE { get; set; }

      /// <summary>
      /// Gets or sets product family id
      /// </summary>
      public int PROD_FAMILY_ID { get; set; }

      /// <summary>
      /// Gets or sets order processing rule id
      /// </summary>
      public int? OP_RULE_ID { get; set; }

      /// <summary>
      /// Gets or sets order grouping id
      /// </summary>
      public int? ORD_GRP_ID { get; set; }

      /// <summary>
      /// Gets or sets status
      /// </summary>
      public string STATUS1 { get; set; }

      /// <summary>
      /// Gets or sets bom revise date
      /// </summary>
      public DateTime? BOM_REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets non bom revise date
      /// </summary>
      public DateTime? NON_BOM_REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the selection is active in job
      /// </summary>
      public bool ACTIVE_IN_JOB_YESNO_FLAG { get; set; }

      /// <summary>
      /// Gets or sets product
      /// </summary>
      public string PROD { get; set; }

      /// <summary>
      /// Gets or sets OE tags required indicator
      /// </summary>
      public string OE_TAGS_REQUIRED_IND { get; set; }

      /// <summary>
      /// Gets or sets request topss flag
      /// </summary>
      public int PERF_CHGS_REQ_TOPSS { get; set; }

      /// <summary>
      /// Gets or sets VPC_ID
      /// </summary>
      public int VPC_ID { get; set; }

      /// <summary>
      /// Gets or sets SELECTED_ITEM_ID
      /// </summary>
      public int SELECTED_ITEM_ID { get; set; }

      /// <summary>
      /// Gets or sets SELECTED_MODULE_ID
      /// </summary>
      public int PROD_MODULE_ID { get; set; }

      /// <summary>
      /// Gets or sets VPFC_ID
      /// </summary>
      public int VPFC_ID { get; set; }

      /// <summary>
      /// Gets or sets SI_ID
      /// </summary>
      public int SI_ID { get; set; }

      /// <summary>
      /// Gets or sets ORD_LINE_NBR
      /// </summary>
      public int? ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets allow no partial shipment indicator
      /// </summary>
      public string ALLOW_NO_PARTIAL_SHIPMENT_IND { get; set; }

      /// <summary>
      /// Gets or sets order group description
      /// </summary>
      public string ORD_GRP_DESCR { get; set; }

      /// <summary>
      /// Gets or sets tag sequence number
      /// </summary>
      public int TAG_SEQUENCE_NBR { get; set; }
   }
}
