﻿// <copyright file="NonTraneItemPagingResults.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// View model for non trane item paging results
   /// </summary>
   public class NonTraneItemPagingResults
   {
      /// <summary>
      /// Gets or sets page number
      /// </summary>
      public int PageNumber { get; set; }

      /// <summary>
      /// Gets or sets page size
      /// </summary>
      public int PageSize { get; set; }

      /// <summary>
      /// Gets or sets total item count
      /// </summary>
      public int TotalItemCount { get; set; }

      /// <summary>
      /// Gets or sets page count
      /// </summary>
      public int PageCount { get; set; }

      /// <summary>
      /// Gets or sets non trane item list
      /// </summary>
      public IEnumerable<NonTraneItemViewModel> NonTraneItems { get; set; }
   }
}
