﻿// <copyright file="Variation.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
    using TSMT.DataAccess;

    /// <summary>
    /// Model for Variation
    /// </summary>
    public class Variation : IDataEntity
    {
        /// <summary>
        /// Gets or sets VARIATION_ID
        /// </summary>
        public int VARIATION_ID { get; set; }

        /// <summary>
        /// Gets or sets SELECTION_ID
        /// </summary>
        public int? SELECTION_ID { get; set; }

        /// <summary>
        /// Gets or sets SHORT_DESC
        /// </summary>
        public string SHORT_DESC { get; set; }

        /// <summary>
        /// Gets or sets MATL_QTY
        /// </summary>
        public int? MATL_QTY { get; set; }

        /// <summary>
        /// Gets or sets PROD_CODE
        /// </summary>
        public string PROD_CODE { get; set; }

        /// <summary>
        /// Gets or sets TAG
        /// </summary>
        public string TAG { get; set; }

        /// <summary>
        /// Gets or sets ORDERED_INDICATOR
        /// </summary>
        public string ORDERED_INDICATOR { get; set; }

        /// <summary>
        /// Gets or sets BID_ALTERNATE_ID
        /// </summary>
        public int? BID_ALTERNATE_ID { get; set; }

        /// <summary>
        /// Gets or sets HQTR_VARIATION_ID
        /// </summary>
        public int? HQTR_VARIATION_ID { get; set; }

        /// <summary>
        /// Gets or sets VARIATION_BILLING_METHOD_CODE
        /// </summary>
        public string VARIATION_BILLING_METHOD_CODE { get; set; }
   }
}
