﻿// <copyright file="Si.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
   /// <summary>
   /// Si details
   /// </summary>
   public class Si
   {
      /// <summary>
      /// Gets or sets SI_ID
      /// </summary>
      public int SI_ID { get; set; }

      /// <summary>
      /// Gets or sets SELECTION_ID
      /// </summary>
      public int SELECTION_ID { get; set; }
   }
}
