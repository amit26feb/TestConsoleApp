﻿// <copyright file="BillOfMaterial.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
    using System.Collections.Generic;

   /// <summary>
   /// Job coordination bill of material
   /// </summary>
   public class BillOfMaterial
   {
      /// <summary>
      /// Gets or sets the product family id
      /// </summary>
      public int PROD_FAMILY_ID { get; set; }

      /// <summary>
      /// Gets or sets the ship quarter
      /// </summary>
      public int? CJ_SHIP_QTR { get; set; }

      /// <summary>
      /// Gets or sets the ship year
      /// </summary>
      public int? CJ_SHIP_YEAR { get; set; }

      /// <summary>
      /// Gets or sets selection ids
      /// </summary>
      public IEnumerable<int> SELECTION_IDS { get; set; }

      /// <summary>
      /// Gets or sets gets selection source
      /// </summary>
      public string SELECTION_SOURCE { get; set; }

      /// <summary>
      ///  Gets or sets a value indicating whether separately biddable selections exist
      /// </summary>
      public bool DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST { get; set; }
   }
}
