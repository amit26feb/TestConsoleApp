﻿// <copyright file="PricingParam.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for PricingParam
   /// </summary>
   public class PricingParam : IDataEntity
   {
      /// <summary>
      /// Gets or sets SELECTION_ID
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets PROD_CODE
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets BID_BREAKOUT_NAME
      /// </summary>
      public string BID_BREAKOUT_NAME { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether SeparatelyBiddable or not
      /// </summary>
      public bool SEPARATELY_BIDDABLE_YES_NO { get; set; }

      /// <summary>
      /// Gets or sets SELECTED_PRICING_PARM_ID
      /// </summary>
      public int SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets ORDERED_INDICATOR
      /// </summary>
      public string ORDERED_INDICATOR { get; set; }

      /// <summary>
      /// Gets or sets PRICED_INDICATOR
      /// </summary>
      public string PRICED_INDICATOR { get; set; }

      /// <summary>
      /// Gets or sets BID_ALTERNATE_ID
      /// </summary>
      public int? BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets HQTR_SELECTED_PRICING_PARM_ID
      /// </summary>
      public int? HQTR_SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets NET_PRICE
      /// </summary>
      public decimal NET_PRICE { get; set; }

      /// <summary>
      /// Gets or sets revise date
      /// </summary>
      public DateTime? REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets quick shipment fap
      /// </summary>
      public decimal? QUICK_SHIP_FAP { get; set; }

      /// <summary>
      /// Gets or sets product family fap
      /// </summary>
      public decimal? PROD_FAMILY_FAP { get; set; }

      /// <summary>
      /// Gets or sets flexible fap
      /// </summary>
      public decimal? FLEXIBLE_FAP { get; set; }

      /// <summary>
      /// Gets or sets office fap
      /// </summary>
      public decimal? OFFICE_FAP { get; set; }

      /// <summary>
      /// Gets or sets quick ship bpaf
      /// </summary>
      public decimal? QUICK_SHIP_BPAF { get; set; }

      /// <summary>
      /// Gets or sets qty lpaf
      /// </summary>
      public decimal? QTY_LPAF { get; set; }

      /// <summary>
      /// Gets or sets list conversion multiplier
      /// </summary>
      public decimal? LIST_CONVERSION_MULT { get; set; }

      /// <summary>
      /// Gets or sets auth comm rate
      /// </summary>
      public decimal? AUTH_COMM_RATE { get; set; }

      /// <summary>
      /// Gets or sets cost point comm rate
      /// </summary>
      public decimal? COST_POINT_COMM_RATE { get; set; }

      /// <summary>
      /// Gets or sets cost point multiplier
      /// </summary>
      public decimal? COST_POINT_MULTIPLIER { get; set; }

      /// <summary>
      /// Gets or sets comm overage ratio
      /// </summary>
      public decimal? COMM_OVERAGE_RATIO { get; set; }

      /// <summary>
      /// Gets or sets base freight reserve rate
      /// </summary>
      public decimal? BASE_FREIGHT_RESERVE_RATE { get; set; }
   }
}
