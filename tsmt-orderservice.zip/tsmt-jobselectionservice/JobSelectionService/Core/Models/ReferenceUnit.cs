// <copyright file="ReferenceUnit.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
    /// <summary>
    /// Model for reference unit
    /// </summary>
    public class ReferenceUnit
    {
        /// <summary>
        /// Gets or sets job id
        /// </summary>
        public int JOB_ID { get; set; }

        /// <summary>
        /// Gets or sets reference unit id
        /// </summary>
        public int REFERENCE_UNIT_ID { get; set; }

        /// <summary>
        /// Gets or sets tag sequence number
        /// </summary>
        public int TAG_SEQUENCE_NBR { get; set; }

        /// <summary>
        /// Gets or sets tag
        /// </summary>
        public string TAG { get; set; }

        /// <summary>
        /// Gets or sets variation id
        /// </summary>
        public int? VARIATION_ID { get; set; }
    }
}
