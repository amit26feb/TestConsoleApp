// <copyright file="PagingOptions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
   using System.Collections.Generic;
   using System.ComponentModel.DataAnnotations;
   using DataAccess.Paging;

   /// <summary>
   /// Model for paging options
   /// </summary>
   public class PagingOptions
   {
      /// <summary>
      /// Gets or sets number of records to be skiped
      /// </summary>
      public int Skip { get; set; }

      /// <summary>
      /// Gets or sets number of records to take
      /// </summary>
      [Required(ErrorMessage = "Take should not be 0")]
      [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "Take must be numeric")]
      public int Take { get; set; }

      /// <summary>
      /// Gets or sets the sort
      /// </summary>
      public List<Sort> Sort { get; set; }

      /// <summary>
      /// Gets or sets filters
      /// </summary>
      public List<FilterCollection> Filters { get; set; }
   }
}
