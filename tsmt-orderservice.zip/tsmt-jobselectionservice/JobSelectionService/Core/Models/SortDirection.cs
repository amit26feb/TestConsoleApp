// <copyright file="SortDirection.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
    /// <summary>
    /// Model For sort direction
    /// </summary>
    public enum SortDirection
    {
        /// <summary>
        /// Gets or sets ascending
        /// </summary>
        Ascending,

        /// <summary>
        /// Gets or sets descending
        /// </summary>
        Descending
    }
}
