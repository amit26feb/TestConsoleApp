﻿// <copyright file="NonTraneItem.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
   using System.Collections.Generic;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for non trane item
   /// </summary>
   public class NonTraneItem : IDataEntity
   {
      /// <summary>
      /// Gets or sets variation id
      /// </summary>
      public int VARIATION_ID { get; set; }

      /// <summary>
      /// Gets or sets variation type
      /// </summary>
      public string VARIATION_TYPE { get; set; }

      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets product code
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets short description
      /// </summary>
      public string SHORT_DESC { get; set; }

      /// <summary>
      /// Gets or sets provider name
      /// </summary>
      public string PROVIDER_NAME { get; set; }

      /// <summary>
      /// Gets or sets equipment name
      /// </summary>
      public string EQUIPMENT_NAME { get; set; }

      /// <summary>
      /// Gets or sets material qty
      /// </summary>
      public int? MATL_QTY { get; set; }

      /// <summary>
      /// Gets or sets material extended cost
      /// </summary>
      public decimal? MATL_EXTENDED_COST { get; set; }

      /// <summary>
      /// Gets or sets material markup multiplier
      /// </summary>
      public decimal? MATL_MARKUP_MULTIPLIER { get; set; }

      /// <summary>
      /// Gets or sets net price
      /// </summary>
      public decimal NET_PRICE { get; set; }

      /// <summary>
      /// Gets or sets variation proposal code
      /// </summary>
      public int VARIATION_PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public string SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets pending order ind
      /// </summary>
      public string PENDING_ORDER_IND { get; set; }

      /// <summary>
      /// Gets or sets total count
      /// </summary>
      public string TOTAL_COUNT { get; set; }

      /// <summary>
      /// Gets or sets vendor name
      /// </summary>
      public string VENDOR_NAME { get; set; }

      /// <summary>
      /// Gets or sets vendor id
      /// </summary>
      public int? VENDOR_ID { get; set; }

      /// <summary>
      /// Gets or sets product id
      /// </summary>
      public int? PRODUCT_ID { get; set; }

      /// <summary>
      /// Gets or sets vendor lead time days
      /// </summary>
      public int? VENDOR_LEAD_TIME_DAYS { get; set; }

      /// <summary>
      /// Gets or sets product name
      /// </summary>
      public string PRODUCT_NAME { get; set; }

      /// <summary>
      /// Gets or sets material count
      /// </summary>
      public int MATERIAL_COUNT { get; set; }

      /// <summary>
      /// Gets or sets labor count
      /// </summary>
      public int LABOR_COUNT { get; set; }

      /// <summary>
      /// Gets or sets facilitation fee count
      /// </summary>
      public int FACILITATIONFEE_COUNT { get; set; }

      /// <summary>
      /// Gets or sets list of tag details
      /// </summary>
      public List<TagDetail> TAGDETAILS { get; set; }

      /// <summary>
      /// Gets or sets strategic provider
      /// </summary>
      public string STRATEGIC_PROVIDER { get; set; }

      /// <summary>
      /// Gets or sets cost category
      /// </summary>
      public string COST_CATEGORY { get; set; }

      /// <summary>
      /// Gets or sets cost forecast
      /// </summary>
      public decimal? COST_FORECAST { get; set; }

      /// <summary>
      /// Gets or sets cost estimate
      /// </summary>
      public decimal? COST_ESTIMATE { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether variation form is oracle or not
      /// </summary>
      public string IS_ORACLE { get; set; }
   }
}
