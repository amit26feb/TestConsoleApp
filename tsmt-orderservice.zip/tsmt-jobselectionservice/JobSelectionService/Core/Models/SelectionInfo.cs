﻿// <copyright file="SelectionInfo.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Models
{
   /// <summary>
   /// Represents the selection information
   /// </summary>
   public class SelectionInfo
   {
      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets the description of the selection
      /// </summary>
      public string DESCRIPTION { get; set; }

      /// <summary>
      /// Gets or sets coordination job ship quarter
      /// </summary>
      public int? CJ_SHIP_QTR { get; set; }

      /// <summary>
      /// Gets or sets coordination job ship year
      /// </summary>
      public int? CJ_SHIP_YEAR { get; set; }

      /// <summary>
      /// Gets or sets coordination job competitor
      /// </summary>
      public string CJ_COMPETITOR { get; set; }

      /// <summary>
      /// Gets or sets coordination job specified user
      /// </summary>
      public string CJ_SPECIFIED { get; set; }

      /// <summary>
      /// Gets or sets prod family id
      /// </summary>
      public int PROD_FAMILY_ID { get; set; }

      /// <summary>
      /// Gets or sets price control id
      /// </summary>
      public int? PRICE_CONTROL_ID { get; set; }

      /// <summary>
      ///  Gets or sets sel_price_complete
      /// </summary>
      public string SEL_PRICE_COMPLETE { get; set; }

      /// <summary>
      ///  Gets or sets SELECTION_SOURCE
      /// </summary>
      public string SELECTION_SOURCE { get; set; }
   }
}
