﻿// <copyright file="NonTraneItemViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   using System.Collections.Generic;
   using System.ComponentModel;

   /// <summary>
   /// View model for non trane item view model
   /// </summary>
   public class NonTraneItemViewModel
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="NonTraneItemViewModel"/> class.
      /// </summary>
      public NonTraneItemViewModel()
      {
         this.DocumentDetails = new List<DocumentViewModel>();
         this.TagDetails = new List<TagDetailViewModel>();
      }

      /// <summary>
      /// Gets or sets variation id
      /// </summary>
      [Description("VARIATION_ID")]
      public int VariationId { get; set; }

      /// <summary>
      /// Gets or sets variation type
      /// </summary>
      [Description("VARIATION_TYPE")]
      public string VariationType { get; set; }

      /// <summary>
      /// Gets or sets job id
      /// </summary>
      [Description("JOB_ID")]
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets product code
      /// </summary>
      public string ProdCode { get; set; }

      /// <summary>
      /// Gets or sets description
      /// </summary>
      [Description("SHORT_DESC")]
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets venor name
      /// </summary>
      [Description("VENDOR_NAME")]
      public string VendorName { get; set; }

      /// <summary>
      /// Gets or sets equipment name
      /// </summary>
      [Description("EQUIPMENT_NAME")]
      public string EquipmentName { get; set; }

      /// <summary>
      /// Gets or sets quantity
      /// </summary>
      [Description("MATL_QTY")]
      public int? Qty { get; set; }

      /// <summary>
      /// Gets or sets cost
      /// </summary>
      [Description("MATL_EXTENDED_COST")]
      public decimal? Cost { get; set; }

      /// <summary>
      /// Gets or sets markup
      /// </summary>
      [Description("MATL_MARKUP_MULTIPLIER")]
      public decimal? Markup { get; set; }

      /// <summary>
      /// Gets or sets selling price
      /// </summary>
      [Description("NET_PRICE")]
      public decimal SellingPrice { get; set; }

      /// <summary>
      /// Gets or sets proposal code
      /// </summary>
      public int ProposalCode { get; set; }

      /// <summary>
      /// Gets status
      /// </summary>
      public string Status
      {
         get
         {
            if (this.SalesOrderId != null)
            {
               return "O";
            }
            else if (this.PendingOrderInd != null)
            {
               return "C";
            }
            else
            {
               return "N";
            }
         }
      }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      [Description("SALES_ORD_ID")]
      public string SalesOrderId { get; set; }

      /// <summary>
      /// Gets or sets pending order ind
      /// </summary>
      [Description("PENDING_ORDER_IND")]
      public string PendingOrderInd { get; set; }

      /// <summary>
      /// Gets or sets total count
      /// </summary>
      public int TotalCount { get; set; }

      /// <summary>
      /// Gets or sets provider name
      /// </summary>
      [Description("PROVIDER_NAME")]
      public string ProviderName { get; set; }

      /// <summary>
      /// Gets or sets vendor id
      /// </summary>
      public int? VendorId { get; set; }

      /// <summary>
      /// Gets or sets product id
      /// </summary>
      public int? ProductId { get; set; }

      /// <summary>
      /// Gets or sets vendor lead time days
      /// </summary>
      [Description("VENDOR_LEAD_TIME_DAYS")]
      public int? VendorLeadTimeDays { get; set; }

      /// <summary>
      /// Gets or sets list of tag detail
      /// </summary>
      public List<TagDetailViewModel> TagDetails { get; set; }

      /// <summary>
      /// Gets or sets product name
      /// </summary>
      public string ProductName { get; set; }

      /// <summary>
      /// Gets or sets material count
      /// </summary>
      public int MaterialCount { get; set; }

      /// <summary>
      /// Gets or sets labor count
      /// </summary>
      public int LaborCount { get; set; }

      /// <summary>
      /// Gets or sets facilitation fee count
      /// </summary>
      public int FacilitationFeeCount { get; set; }

      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      [Description("SELECTION_ID")]
      public int? SelectionId { get; set; }

      /// <summary>
      /// Gets or sets strategic provider
      /// </summary>
      public string StrategicProvider { get; set; }

      /// <summary>
      /// Gets or sets cost category
      /// </summary>
      public string CostCategory { get; set; }

      /// <summary>
      /// Gets or sets cost forecast
      /// </summary>
      public decimal? CostForecast { get; set; }

      /// <summary>
      /// Gets or sets cost estimate
      /// </summary>
      public decimal? CostEstimate { get; set; }

      /// <summary>
      /// Gets or sets document details
      /// </summary>
      public IEnumerable<DocumentViewModel> DocumentDetails { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether variation form is oracle or not
      /// </summary>
      public bool IsOracle { get; set; }
   }
}
