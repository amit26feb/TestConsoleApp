﻿// <copyright file="DocumentViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   /// <summary>
   /// Represents the document view model
   /// </summary>
   public class DocumentViewModel
   {
      /// <summary>
      /// Gets or sets the document key
      /// </summary>
      public string DocumentKey { get; set; }

      /// <summary>
      /// Gets or sets the document name
      /// </summary>
      public string DocumentName { get; set; }

      /// <summary>
      /// Gets or sets the document version
      /// </summary>
      public string DocumentVersion { get; set; }

      /// <summary>
      /// Gets or sets the job document type id
      /// </summary>
      public int? JobDocumentTypeId { get; set; }
   }
}
