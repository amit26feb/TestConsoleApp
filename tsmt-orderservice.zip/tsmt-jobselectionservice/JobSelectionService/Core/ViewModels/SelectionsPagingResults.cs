// <copyright file="SelectionsPagingResults.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
    using System.Collections.Generic;

    /// <summary>
    /// View model for selections paging results
    /// </summary>
    public class SelectionsPagingResults
    {
        /// <summary>
        /// Gets or sets page number
        /// </summary>
        public double PageNumber { get; set; }

        /// <summary>
        /// Gets or sets pagesize
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or sets total item count
        /// </summary>
        public int TotalItemCount { get; set; }

        /// <summary>
        /// Gets or sets page count
        /// </summary>
        public double PageCount { get; set; }

        /// <summary>
        /// Gets or sets selection list
        /// </summary>
        public IEnumerable<SelectionViewModel> SelectionList { get; set; }
    }
}
