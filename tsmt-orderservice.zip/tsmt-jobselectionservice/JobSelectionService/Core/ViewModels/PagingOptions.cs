// <copyright file="PagingOptions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   using System.Collections.Generic;
   using System.ComponentModel.DataAnnotations;
   using JobSelectionService.ViewModels;

   /// <summary>
   /// View model for job paging options
   /// </summary>
   public class PagingOptions
   {
      /// <summary>
      /// Gets or sets number of records to be skiped
      /// </summary>
      public int Skip { get; set; }

      /// <summary>
      /// Gets or sets number of records to take
      /// </summary>
      [Required(ErrorMessage = "Take should not be 0")]
      [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "Take must be numeric")]
      public int Take { get; set; }

      /// <summary>
      /// Gets or sets the sort type
      /// </summary>
      public List<SortViewModel> Sort { get; set; }

      /// <summary>
      /// Gets or sets filters
      /// </summary>
      public List<FilterCollectionViewModel> Filters { get; set; }
   }
}
