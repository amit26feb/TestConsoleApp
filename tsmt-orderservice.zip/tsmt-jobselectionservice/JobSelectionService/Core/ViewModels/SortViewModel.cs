// <copyright file="SortViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
    /// <summary>
    /// View Model for sort
    /// </summary>
    public class SortViewModel
    {
        /// <summary>
        /// Gets or sets sort by
        /// </summary>
        public string SortBy { get; set; }

        /// <summary>
        /// Gets or sets sort direction
        /// </summary>
        public SortDirectionViewModel SortDirection { get; set; }
    }
}
