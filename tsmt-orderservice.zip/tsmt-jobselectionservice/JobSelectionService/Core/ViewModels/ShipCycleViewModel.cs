﻿// <copyright file="ShipCycleViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   /// <summary>
   /// Ship cycle detail
   /// </summary>
   public class ShipCycleViewModel
   {
      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SelectionId { get; set; }

      /// <summary>
      /// Gets or sets si id
      /// </summary>
      public int SiId { get; set; }

      /// <summary>
      /// Gets or sets si type
      /// </summary>
      public string SiType { get; set; }

      /// <summary>
      /// Gets or sets unit of measure
      /// </summary>
      public string UnitOfMeasure { get; set; }

      /// <summary>
      /// Gets or sets ship cycle length
      /// </summary>
      public int ShipCycleLength { get; set; }

      /// <summary>
      /// Gets or sets vpc id
      /// </summary>
      public int VpcId { get; set; }
   }
}
