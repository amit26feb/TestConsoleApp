﻿// <copyright file="BidSelectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
    using System.Collections.Generic;

   /// <summary>
   /// Represents the bid selection view model
   /// </summary>
   public class BidSelectionViewModel
   {
      /// <summary>
      /// Gets or sets the product family id
      /// </summary>
      public int ProductFamilyId { get; set; }

      /// <summary>
      /// Gets or sets the ship quarter
      /// </summary>
      public int ShipQuarter { get; set; }

      /// <summary>
      /// Gets or sets the ship year
      /// </summary>
      public int ShipYear { get; set; }

      /// <summary>
      /// Gets or sets the selection ids
      /// </summary>
      public IEnumerable<int> SelectionIds { get; set; }

      /// <summary>
      /// Gets or sets selection errors
      /// </summary>
      public IEnumerable<string> Descriptions { get; set; }

      /// <summary>
      /// Gets or sets the si ids
      /// </summary>
      public IEnumerable<int> SiIds { get; set; }

      /// <summary>
      /// Gets or sets selection source
      /// </summary>
      public string SelectionSource { get; set; }

      /// <summary>
      ///  Gets or sets a value indicating whether separately biddable selections exist
      /// </summary>
      public bool DoesSeparatelyBiddableSelectionsExist { get; set; }
   }
}
