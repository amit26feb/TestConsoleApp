// <copyright file="FilterCollectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.ViewModels
{
    using System.Collections.Generic;

   /// <summary>
   /// FilterCollection
   /// </summary>
   public class FilterCollectionViewModel
    {
         /// <summary>
         /// Gets or sets filters
         /// </summary>
         public List<Filter> Filters { get; set; }

        /// <summary>
        /// Gets or sets Logic
        /// </summary>
        public string Logic { get; set; }
    }
}
