﻿// <copyright file="SelectionInfoViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   /// <summary>
   /// Represents the selection information view model
   /// </summary>
   public class SelectionInfoViewModel
   {
      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SelectionId { get; set; }

      /// <summary>
      /// Gets or sets the description of the selection
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets coordination job ship quarter
      /// </summary>
      public int? CoordinationJobShipQuarter { get; set; }

      /// <summary>
      /// Gets or sets coordination job ship year
      /// </summary>
      public int? CoordinationJobShipYear { get; set; }

      /// <summary>
      /// Gets or sets coordination job competitor
      /// </summary>
      public string CoordinationJobCompetitor { get; set; }

      /// <summary>
      /// Gets or sets coordination job specified user
      /// </summary>
      public string CoordinationJobSpecifiedUser { get; set; }

      /// <summary>
      /// Gets or sets price control id
      /// </summary>
      public int? PriceControlId { get; set; }

      /// <summary>
      /// Gets or sets prod family id
      /// </summary>
      public int ProdFamilyId { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether selection price is complete (sel_price_complete != N)
      /// </summary>
      public bool IsSelectionPriceComplete { get; set; }

      /// <summary>
      /// Gets or sets selection source
      /// </summary>
      public string SelectionSource { get; set; }
   }
}
