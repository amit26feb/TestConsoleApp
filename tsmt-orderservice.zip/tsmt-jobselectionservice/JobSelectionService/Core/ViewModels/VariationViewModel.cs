﻿// <copyright file="VariationViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
    /// <summary>
    /// View model for Variation
    /// </summary>
    public class VariationViewModel
    {
        /// <summary>
        /// Gets or sets VariationId
        /// </summary>
        public int VariationId { get; set; }

        /// <summary>
        /// Gets or sets SelectionId
        /// </summary>
        public int? SelectionId { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Qty
        /// </summary>
        public int? Qty { get; set; }

        /// <summary>
        /// Gets or sets ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// Gets or sets Tag
        /// </summary>
        public string Tag { get; set; }

        /// <summary>
        /// Gets or sets OrderedIndicator
        /// </summary>
        public string OrderedIndicator { get; set; }

        /// <summary>
        /// Gets or sets BidAlternateId
        /// </summary>
        public int? BidAlternateId { get; set; }

        /// <summary>
        /// Gets or sets HqtrVariationId
        /// </summary>
        public int? HqtrVariationId { get; set; }

        /// <summary>
        /// Gets or sets VariationBillingMethodCode
        /// </summary>
        public string VariationBillingMethodCode { get; set; }
   }
}
