﻿// <copyright file="TagDetailViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace JobSelectionService.Core.ViewModels
{
   /// <summary>
   /// View model for tag detail
   /// </summary>
   public class TagDetailViewModel
   {
      /// <summary>
      /// Gets or sets reference unit id
      /// </summary>
      public int ReferenceUnitId { get; set; }

      /// <summary>
      /// Gets or sets tag
      /// </summary>
      public string Tag { get; set; }

      /// <summary>
      /// Gets or sets tag sequence number
      /// </summary>
      public int TagSequenceNbr { get; set; }
   }
}
