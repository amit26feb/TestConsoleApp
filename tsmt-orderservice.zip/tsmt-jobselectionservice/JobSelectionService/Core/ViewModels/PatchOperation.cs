// <copyright file="PatchOperation.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
    using Dapper;

    /// <summary>
    /// View model for patch operation
    /// </summary>
    public class PatchOperation
    {
        /// <summary>
        /// Gets or sets table name
        /// </summary>
        public string TableName { get; set; }

        /// <summary>
        /// Gets or sets operation
        /// </summary>
        public string Operation { get; set; }

        /// <summary>
        /// Gets or sets query
        /// </summary>
        public string Query { get; set; }

        /// <summary>
        /// Gets or sets dynamic parameters
        /// </summary>
        public DynamicParameters DynamicParameters { get; set; }

        /// <summary>
        /// Gets or sets table value
        /// </summary>
        public object TableValue { get; set; }
    }
}
