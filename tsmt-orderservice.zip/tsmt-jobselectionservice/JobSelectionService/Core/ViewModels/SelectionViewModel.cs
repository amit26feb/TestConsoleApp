﻿// <copyright file="SelectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   using System;
   using System.Collections.Generic;
   using System.ComponentModel;

   /// <summary>
   /// View model for selection
   /// </summary>
   public class SelectionViewModel
    {
      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      [Description("SELECTION_ID")]
      public int SelectionId { get; set; }

        /// <summary>
        /// Gets or sets selection description
        /// </summary>
        [Description("SALESMAN_DESCR")]
        public string SelectionDescription { get; set; }

        /// <summary>
        /// Gets or sets qty
        /// </summary>
        [Description("UNIT_QTY")]
        public int Qty { get; set; }

        /// <summary>
        /// Gets or sets product family
        /// </summary>
        [Description("PROD_FAMILY")]
        public string ProductFamily { get; set; }

        /// <summary>
        /// Gets or sets product code
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// Gets or sets tag
        /// </summary>
        [Description("Tag")]
        public string Tag { get; set; }

        /// <summary>
        /// Gets ordered indicator
        /// </summary>
      public string OrderedIndicator
      {
         get
         {
            if (this.SalesOrderId != null)
            {
               return "O";
            }
            else if (this.PendingOrderInd != null)
            {
               return "C";
            }
            else
            {
               return "N";
            }
         }
      }

      /// <summary>
      /// Gets priced indicator
      /// </summary>
      public string PricedIndicator
      {
         get
         {
            if (this.SelectionSource == "N")
            {
               return "NA";
            }
            else if (this.SelPriceComplete != null)
            {
               return "NP";
            }
            else if (this.PriceControlId == null)
            {
               return "NA";
            }

            return "P";
         }
      }

      /// <summary>
      /// Gets a value indicating whether the item is configured or not
      /// </summary>
      public bool IsConfiguredItem
      {
         get
         {
            if (this.SelectionSource == "C")
            {
               return true;
            }

            return false;
         }
      }

      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int? BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets hqtr selection id
      /// </summary>
      public int? HqtrSelectionId { get; set; }

      /// <summary>
      /// Gets or sets list price
      /// </summary>
      [Description("LIST_PRICE")]
      public decimal? ListPrice { get; set; }

      /// <summary>
      /// Gets or sets net price
      /// </summary>
      [Description("TOTAL_NET_DOLLARS")]
      public decimal? NetPrice { get; set; }

      /// <summary>
      /// Gets or sets model or ordering number
      /// </summary>
      public string ModelOrOrderingNumber { get; set; }

      /// <summary>
      /// Gets or sets revise date
      /// </summary>
      [Description("REVISE_DATE")]
      public DateTime? ReviseDate { get; set; }

      /// <summary>
      /// Gets or sets total count
      /// </summary>
      public int TotalCount { get; set; }

      /// <summary>
      /// Gets or sets legacy order number
      /// </summary>
      public string LegacyOrderNumber { get; set; }

      /// <summary>
      /// Gets or sets list of separately bBiddables
      /// </summary>
      public List<PricingParamViewModel> SeparatelyBiddableList { get; set; }

        /// <summary>
        /// Gets or sets list of selection variation
        /// </summary>
        public List<VariationViewModel> VariationList { get; set; }

      /// <summary>
      /// Gets or sets selection source
      /// </summary>
      public string SelectionSource { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int? SalesOrderId { get; set; }

      /// <summary>
      /// Gets or sets pending order ind
      /// </summary>
      public string PendingOrderInd { get; set; }

      /// <summary>
      /// Gets or sets sel price complete
      /// </summary>
      public string SelPriceComplete { get; set; }

      /// <summary>
      /// Gets or sets price control id
      /// </summary>
      public int? PriceControlId { get; set; }

      /// <summary>
      /// Gets or sets sequence number
      /// </summary>
      [Description("SEQUENCE_NBR")]
      public int? SequenceNumber { get; set; }

      /// <summary>
      /// Gets or sets source
      /// </summary>
      public string Source { get; set; }

      /// <summary>
      /// Gets or sets product family id
      /// </summary>
      public int ProductFamilyId { get; set; }

      /// <summary>
      /// Gets or sets order processing rule id
      /// </summary>
      public int? OrderProcessingRuleId { get; set; }

      /// <summary>
      /// Gets or sets order grouping id
      /// </summary>
      public int? OrderGroupingId { get; set; }

      /// <summary>
      /// Gets or sets status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets bom revise date
      /// </summary>
      public DateTime? BOMReviseDate { get; set; }

      /// <summary>
      /// Gets or sets non bom revise date
      /// </summary>
      public DateTime? NonBOMReviseDate { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the selection is active in job
      /// </summary>
      public bool IsActiveInJob { get; set; }

      /// <summary>
      /// Gets or sets product
      /// </summary>
      public string Product { get; set; }

      /// <summary>
      /// Gets or sets OE tags required indicator
      /// </summary>
      public string OeTagsRequiredIndicator { get; set; }

      /// <summary>
      /// Gets or sets request topss flag
      /// </summary>
      public int RequestTopssFlag { get; set; }

      /// <summary>
      /// Gets or sets the vpc id
      /// </summary>
      public int VpcId { get; set; }

      /// <summary>
      /// Gets or sets the selected item id
      /// </summary>
      public int SelectedItemId { get; set; }

      /// <summary>
      /// Gets or sets the prod module id
      /// </summary>
      public int ProdModuleId { get; set; }

      /// <summary>
      /// Gets or sets the performance category id
      /// </summary>
      public int VpfcId { get; set; }

      /// <summary>
      /// Gets or sets the si id
      /// </summary>
      public int SiId { get; set; }

      /// <summary>
      /// Gets or sets the orderline number
      /// </summary>
      public int? OrderLineNumber { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether to allow partial shipment
      /// </summary>
      public bool IsAllowPartialShipment { get; set; }

      /// <summary>
      /// Gets or sets order group description
      /// </summary>
      public string OrderGroupDescription { get; set; }

      /// <summary>
      /// Gets or sets tag sequence number
      /// </summary>
      public int TagSequenceNumber { get; set; }
   }
}
