// <copyright file="Filter.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.ViewModels
{
    /// <summary>
    /// Filter
    /// </summary>
    public class Filter
    {
        /// <summary>
        /// Gets or sets Field by which column
        /// </summary>
        public string Field { get; set; }

        /// <summary>
        /// Gets or sets Operator to apply
        /// </summary>
        public string Operator { get; set; }

        /// <summary>
        /// Gets or sets Value for filter
        /// </summary>
        public string Value { get; set; }
    }
}
