﻿// <copyright file="PricingParamViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
   using System;

   /// <summary>
   /// View model for pricing param
   /// </summary>
   public class PricingParamViewModel
    {
        /// <summary>
        /// Gets or sets SelectionId
        /// </summary>
        public int SelectionId { get; set; }

        /// <summary>
        /// Gets or sets ProductCode
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether SeparatelyBiddable or not
        /// </summary>
        public bool IsSeparatelyBiddable { get; set; }

        /// <summary>
        /// Gets or sets SelectedPricingParmId
        /// </summary>
        public int SelectedPricingParmId { get; set; }

        /// <summary>
        /// Gets or sets OrderedIndicator
        /// </summary>
        public string OrderedIndicator { get; set; }

        /// <summary>
        /// Gets or sets PricedIndicator
        /// </summary>
        public string PricedIndicator { get; set; }

        /// <summary>
        /// Gets or sets BidAlternateId
        /// </summary>
        public int? BidAlternateId { get; set; }

        /// <summary>
        /// Gets or sets HqtrSelectedPricingParmId
        /// </summary>
        public int? HqtrSelectedPricingParmId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to consider as SeparatelyBiddableInPractice or not
        /// </summary>
        public bool IsSeparatelyBiddableInPractice { get; set; }

        /// <summary>
        /// Gets or sets Net Price
        /// </summary>
        public decimal NetPrice { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the SPP belongs to main unit
        /// </summary>
        public bool IsMainUnit { get; set; }

       /// <summary>
       /// Gets or sets revise date
       /// </summary>
       public DateTime? ReviseDate { get; set; }

       /// <summary>
       /// Gets or sets quick shipment fap
       /// </summary>
       public decimal? QuickShipFap { get; set; }

       /// <summary>
       /// Gets or sets product family fap
       /// </summary>
       public decimal? ProdFamilyFap { get; set; }

       /// <summary>
       /// Gets or sets flexible fap
       /// </summary>
       public decimal? FlexibleFap { get; set; }

       /// <summary>
       /// Gets or sets office fap
       /// </summary>
       public decimal? OfficeFap { get; set; }

      /// <summary>
      /// Gets or sets quick ship bpaf
      /// </summary>
      public decimal? QuickShipBpaf { get; set; }

      /// <summary>
      /// Gets or sets qty lpaf
      /// </summary>
      public decimal? QtyLpaf { get; set; }

      /// <summary>
      /// Gets or sets list conversion multiplier
      /// </summary>
      public decimal? ListConversionMult { get; set; }

      /// <summary>
      /// Gets or sets auth comm rate
      /// </summary>
      public decimal? AuthCommRate { get; set; }

      /// <summary>
      /// Gets or sets cost point comm rate
      /// </summary>
      public decimal? CostPointCommRate { get; set; }

      /// <summary>
      /// Gets or sets cost point multiplier
      /// </summary>
      public decimal? CostPointMultiplier { get; set; }

      /// <summary>
      /// Gets or sets comm overage ratio
      /// </summary>
      public decimal? CommOverageRatio { get; set; }

      /// <summary>
      /// Gets or sets base freight reserve rate
      /// </summary>
      public decimal? BaseFreightReserveRate { get; set; }
   }
}
