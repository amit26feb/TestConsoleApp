// <copyright file="SortDirectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
    /// <summary>
    /// View Model for sort direction
    /// </summary>
    public enum SortDirectionViewModel
    {
        /// <summary>
        /// Gets or sets ascending
        /// </summary>
        Ascending,

        /// <summary>
        /// Gets or sets descending
        /// </summary>
        Descending
    }
}
