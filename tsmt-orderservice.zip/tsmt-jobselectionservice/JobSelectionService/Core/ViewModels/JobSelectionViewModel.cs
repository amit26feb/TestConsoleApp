﻿// <copyright file="JobSelectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.ViewModels
{
    using System.Collections.Generic;

    /// <summary>
    /// View model for View job selections
    /// </summary>
    public class JobSelectionViewModel
    {
        /// <summary>
        /// Gets or sets list of selection
        /// </summary>
        public List<SelectionViewModel> SelectionList { get; set; }

        /// <summary>
        /// Gets or sets list of job variation
        /// </summary>
        public List<VariationViewModel> JobVariationList { get; set; }
    }
}
