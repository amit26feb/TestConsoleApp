﻿// <copyright file="CreateNonTraneItemCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Validators
{
   using FluentValidation;
   using JobSelectionService.Core.Commands;

   /// <summary>
   /// Validates fields that are required for creating non trane item
   /// </summary>
   public class CreateNonTraneItemCommandValidator : AbstractValidator<CreateNonTraneItemCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="CreateNonTraneItemCommandValidator"/> class.
      /// </summary>
      public CreateNonTraneItemCommandValidator()
      {
         this.RuleFor(command => command.NonTraneItem.JobId).GreaterThan(0).WithMessage("Job id should be greater than 0");
         this.RuleFor(command => command.NonTraneItem.VariationType).NotEmpty().WithMessage("Variation type cannot be empty");
         this.RuleFor(command => command.NonTraneItem.Description).NotEmpty().WithMessage("Description cannot be empty");
      }
   }
}
