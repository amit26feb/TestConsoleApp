﻿// <copyright file="DeleteNonTraneItemCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Validators
{
   using FluentValidation;
   using JobSelectionService.Core.Commands;

   /// <summary>
   /// Validates fields that are required for deleting non trane item
   /// </summary>
   public class DeleteNonTraneItemCommandValidator : AbstractValidator<DeleteNonTraneItemCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="DeleteNonTraneItemCommandValidator"/> class.
      /// </summary>
      public DeleteNonTraneItemCommandValidator()
      {
         this.RuleFor(command => command.VariationId).GreaterThan(0).WithMessage("Variation Id should be greater than 0");
      }
   }
}
