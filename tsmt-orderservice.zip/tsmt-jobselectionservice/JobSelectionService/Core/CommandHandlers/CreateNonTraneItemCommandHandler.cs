﻿// <copyright file="CreateNonTraneItemCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using JobSelectionService.Core.Commands;
    using JobSelectionService.Core.Services;
    using MediatR;

    /// <summary>
    /// Handler which process the command for creating non trane item for a job
    /// </summary>
    public class CreateNonTraneItemCommandHandler : IRequestHandler<CreateNonTraneItemCommand, int>
    {
        private readonly INonTraneItemService nonTraneItemService;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateNonTraneItemCommandHandler"/> class.
      /// </summary>
      /// <param name="nonTraneItemService">Non trane item service</param>
      public CreateNonTraneItemCommandHandler(INonTraneItemService nonTraneItemService)
        {
            this.nonTraneItemService = nonTraneItemService;
        }

      /// <summary>
      /// Handler which process the create non trane item for a job
      /// </summary>
      /// <param name="request">Request payload for create non trane item</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>Variation id of the created non trane item</returns>
      public async Task<int> Handle(CreateNonTraneItemCommand request, CancellationToken cancellationToken)
        {
         return await this.nonTraneItemService.CreateNonTraneItem(request.NonTraneItem);
        }
    }
}
