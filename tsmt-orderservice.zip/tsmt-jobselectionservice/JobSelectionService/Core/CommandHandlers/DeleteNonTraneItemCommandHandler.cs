﻿// <copyright file="DeleteNonTraneItemCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.CommandHandlers
{
   using System.Threading;
   using System.Threading.Tasks;
   using JobSelectionService.Core.Commands;
   using JobSelectionService.Core.Services;
   using MediatR;

   /// <summary>
   /// Handler which process the command for deleting non trane item for a job
   /// </summary>
   public class DeleteNonTraneItemCommandHandler : IRequestHandler<DeleteNonTraneItemCommand, int>
   {
      private readonly INonTraneItemService nonTraneItemService;

      /// <summary>
      /// Initializes a new instance of the <see cref="DeleteNonTraneItemCommandHandler"/> class.
      /// </summary>
      /// <param name="nonTraneItemService">Non trane item service</param>
      public DeleteNonTraneItemCommandHandler(INonTraneItemService nonTraneItemService)
      {
         this.nonTraneItemService = nonTraneItemService;
      }

      /// <summary>
      /// Handler which process the delete non trane item for a job
      /// </summary>
      /// <param name="request">Request payload for delete non trane item</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>Variation id of the created non trane item</returns>
      public async Task<int> Handle(DeleteNonTraneItemCommand request, CancellationToken cancellationToken)
      {
         return await this.nonTraneItemService.DeleteNonTraneItem(request.VariationId);
      }
   }
}
