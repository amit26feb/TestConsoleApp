﻿// <copyright file="NonTraneItemRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Linq;
   using System.Text;
   using System.Threading.Tasks;
   using Dapper;
   using DataAccess.Core.Abstractions;
   using JobSelectionService.Common.Constants;
   using JobSelectionService.Common.Exceptions;
   using JobSelectionService.Configurations;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Oracle.ManagedDataAccess.Client;
   using TSMT.DataAccess;
   using TSMT.DataAccess.Models;

   /// <summary>
   /// Repository for non trane item operations
   /// </summary>
   public class NonTraneItemRepository : INonTraneItemRepository
   {
      private readonly IConnectionFactory connectionFactory;
      private readonly IRepository<NonTraneItem> repository;
      private readonly ILogger<NonTraneItem> logger;
      private readonly string exceptionMessage = "Unknown data type";
      private int? drAddressId;
      private IDbConnection dbConnection;
      private IDbTransaction dbTransaction;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettings;

      /// <summary>
      /// Initializes a new instance of the <see cref="NonTraneItemRepository"/> class.
      /// </summary>
      /// <param name="repository">Repository</param>
      /// <param name="connectionFactory">Database connection parameter</param>
      /// <param name="logger">Logger for non trane item</param>
      public NonTraneItemRepository(IRepository<NonTraneItem> repository, IConnectionFactory connectionFactory, ILogger<NonTraneItem> logger, IOptions<CommonConfigurationSettings> commonConfigurationSettings)
      {
         this.repository = repository;
         this.connectionFactory = connectionFactory;
         this.logger = logger;
         this.commonConfigurationSettings = commonConfigurationSettings;
      }

      /// <summary>
      /// Gets a database connection.
      /// Pays attention to a specific dr address id if we have been told to do so.
      /// </summary>
      private IDbConnection GetConnection
      {
         get
         {
            if (this.drAddressId.HasValue)
            {
               return this.connectionFactory.GetOpenConnectionForDrAddressId(this.drAddressId.Value);
            }
            else
            {
               return this.connectionFactory.GetConnection;
            }
         }
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         // Keep track of it, in case we have the connection factory generate a new connection in this repository.
         this.drAddressId = drAddressId;

         // Tell all IRepository instances about it.
         this.repository.HonorDrAddressId(drAddressId);
      }

      /// <summary>
      /// Gets the list of non trane item
      /// </summary>
      /// <param name="pagingOptions">Parameters to perform pagination</param>
      /// <param name="jobId">Id of the corresponding job</param>
      /// <returns>List of non trane item</returns>
      public async Task<IEnumerable<NonTraneItem>> GetNonTraneItems(TSMT.DataAccess.PagingOptions pagingOptions, int jobId)
      {
         var stringBuilder = this.commonConfigurationSettings.Value.DisableRebalancing ? new StringBuilder(NonTraneItemRepositoryQueries.GetNonTraneItemsQuery) : new StringBuilder(NonTraneItemRepositoryQueries.GetNonTraneItemsVariationCompanionQuery);
         string sortClause = this.repository.BuildSortClause<NonTraneItem>(pagingOptions.Sort);
         string sortClauseQuery = string.IsNullOrEmpty(sortClause) ? string.Empty : " ORDER BY " + sortClause + " NULLS LAST";

         DynamicParameters dynamicParam = new DynamicParameters();
         dynamicParam.Add("Skip", pagingOptions.Skip + 1);
         dynamicParam.Add("Take", pagingOptions.Take + pagingOptions.Skip);
         dynamicParam.Add("JOB_ID", jobId);

         if (pagingOptions.Filters != null && pagingOptions.Filters.Count > 0)
         {
            QueryResult filterClause = this.repository.BuildFilterClause<NonTraneItem>(pagingOptions.Filters);
            string filterClauseQuery = string.IsNullOrEmpty(filterClause.Query) ? string.Empty : filterClause.Query;
            dynamicParam.AddDynamicParams(filterClause.Parameters);
            stringBuilder.Append(filterClauseQuery);
         }

         stringBuilder.Append(") WHERE RowNumber BETWEEN :SKIP AND :TAKE");
         stringBuilder.Append(sortClauseQuery);

         var query = stringBuilder.ToString();
         var nonTraneItems = await this.repository.ExecuteListQuery<NonTraneItem>(query, dynamicParam);
         return nonTraneItems;
      }

      /// <summary>
      /// Get non trane item based on job id and variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Non trane item based on job id and variation id</returns>
      public async Task<NonTraneItem> GetNonTraneItem(int variationId, int jobId)
      {
         var param = new
         {
            VARIATION_ID = variationId,
            JOB_ID = jobId
         };

         NonTraneItem nonTraneItem = this.commonConfigurationSettings.Value.DisableRebalancing ?
            await this.repository.ExecuteQuery<NonTraneItem>(Common.Constants.NonTraneItemRepositoryQueries.GetVariationDetailQuery, param) :
            await this.repository.ExecuteQuery<NonTraneItem>(Common.Constants.NonTraneItemRepositoryQueries.GetVariationDetailWithCostForecastQuery, param);

         return nonTraneItem;
      }

      /// <summary>
      /// Get tag details for non trane item based on job id and variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Tag detals of the non trane item based on job id and variation id</returns>
      public async Task<IEnumerable<TagDetail>> GetTagDetails(int variationId, int jobId)
      {
         var param = new
         {
            VARIATION_ID = variationId,
            JOB_ID = jobId
         };

         var tagDetails = await this.repository.ExecuteListQuery<TagDetail>(Common.Constants.NonTraneItemRepositoryQueries.GetTagDetailQuery, param);
         return tagDetails;
      }

      /// <summary>
      /// Method to get maximum sequence number of specific table
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <param name="howManyToReserve">How many blocks of new ids to reserve for a table</param>
      /// <returns>Maximum value of table primary key column</returns>
      public async Task<int> GetSequenceNumber(string tableName, int howManyToReserve = 1)
      {
         var param = new
         {
            TABLENAME = tableName,
            HOW_MANY_TO_RESERVE = howManyToReserve
         };

         return await this.repository.ExecuteQuery<int>(NonTraneItemRepositoryQueries.GetSequenceNumberQuery, param);
      }

      /// <summary>
      /// Inserts new non trane item for a job
      /// </summary>
      /// <param name="nonTraneItem">Model of the non trane item</param>
      /// <returns>Create status</returns>
      public async Task<int> CreateNonTraneItemAsync(Models.NonTraneItem nonTraneItem)
      {
         var param = new
         {
            nonTraneItem.JOB_ID,
            nonTraneItem.VARIATION_ID,
            nonTraneItem.VENDOR_NAME,
            nonTraneItem.MATL_EXTENDED_COST,
            nonTraneItem.MATL_MARKUP_MULTIPLIER,
            nonTraneItem.MATL_QTY,
            nonTraneItem.NET_PRICE,
            nonTraneItem.PROVIDER_NAME,
            nonTraneItem.SHORT_DESC,
            nonTraneItem.VARIATION_PROD_CODE,
            nonTraneItem.VARIATION_TYPE,
            nonTraneItem.PROD_CODE,
            nonTraneItem.VENDOR_ID,
            nonTraneItem.EQUIPMENT_NAME,
            nonTraneItem.PRODUCT_ID,
            nonTraneItem.VENDOR_LEAD_TIME_DAYS,
            nonTraneItem.STRATEGIC_PROVIDER,
            nonTraneItem.COST_CATEGORY,
         };

         var variationCompanionParam = new
         {
            nonTraneItem.VARIATION_ID,
            nonTraneItem.COST_FORECAST,
            nonTraneItem.IS_ORACLE
         };

         int returnVal = 0;
         using (this.dbConnection = this.GetConnection)
         {
            using (IDbTransaction transaction = this.dbConnection.BeginTransaction())
            {
               try
               {
                  returnVal = await this.dbConnection.ExecuteAsync(NonTraneItemRepositoryQueries.CreateNonTraneItemQuery, param, transaction);

                  // Should not update variation companion table in stage/production environments.
                  if (!this.commonConfigurationSettings.Value.DisableRebalancing && nonTraneItem.COST_FORECAST != null)
                  {
                     await this.dbConnection.ExecuteAsync(NonTraneItemRepositoryQueries.CreateVariationCompanionQuery, variationCompanionParam, transaction);
                  }

                  if (nonTraneItem.TAGDETAILS != null && nonTraneItem.TAGDETAILS.Count > 0)
                  {
                     this.BulkInsertEntities(nonTraneItem.TAGDETAILS, NonTraneItemRepositoryQueries.ReferenceUnitInsertQuery);
                  }

                  transaction.Commit();
               }
               catch (Exception e)
               {
                  transaction.Rollback();
                  throw new JobSelectionServiceDomainException(e.Message);
               }
            }
         }

         return returnVal;
      }

      /// <summary>
      /// Delete non trane item based on variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <returns>Deleted status</returns>
      public async Task<int> DeleteNonTraneItem(int variationId)
      {
         var param = new
         {
            VARIATION_ID = variationId
         };

         int returnVal = 0;
         using (IDbConnection connection = this.GetConnection)
         {
            IDbTransaction transaction = connection.BeginTransaction();
            try
            {
               returnVal = await connection.ExecuteAsync(NonTraneItemRepositoryQueries.VariationDetailDeleteQuery, param, transaction);
               await connection.ExecuteAsync(NonTraneItemRepositoryQueries.TagDetailDeleteQuery, param, transaction);
               transaction.Commit();
            }
            catch (Exception e)
            {
               transaction.Rollback();
               throw new JobSelectionServiceDomainException(e.Message);
            }
         }

         return returnVal;
      }

      /// <summary>
      /// Update non trane item for a job
      /// </summary>
      /// <param name="patchOperations">List of patch operation for update non trane item</param>
      /// <returns>True or false based update status</returns>
      public async Task<bool> UpdateNonTraneItemAsync(IEnumerable<PatchOperation> patchOperations)
      {
         using (this.dbConnection = this.GetConnection)
         {
            this.dbTransaction = this.dbConnection.BeginTransaction();
            try
            {
               // Executing remove operation for reference unit table
               var referenceUnitRemoveOperations = patchOperations.Where(o => o.TableName == "REFERENCE_UNIT" && o.Operation == "remove");
               if (referenceUnitRemoveOperations.Any())
               {
                  this.BulkRemoveOperation(referenceUnitRemoveOperations.Select(n => n.DynamicParameters), NonTraneItemRepositoryQueries.ReferenceUnitDeleteQuery);
               }

               // Executing add operation for reference unit table
               var referenceUnitAddOperations = patchOperations.Where(o => o.TableName == "REFERENCE_UNIT" && o.Operation == "add");
               if (referenceUnitAddOperations.Any())
               {
                  // Sequence number genaration and update for reference unit table
                  var referenceUnitId = await this.GetSequenceNumber("REFERENCE_UNIT", referenceUnitAddOperations.Count());
                  foreach (PatchOperation patchOperation in referenceUnitAddOperations)
                  {
                     var referenceUnit = (ReferenceUnit)patchOperation.TableValue;
                     referenceUnit.REFERENCE_UNIT_ID = referenceUnitId++;
                     patchOperation.TableValue = referenceUnit;
                  }

                  this.BulkInsertJobEntities(referenceUnitAddOperations.Select(n => n.TableValue), NonTraneItemRepositoryQueries.ReferenceUnitInsertQuery);
               }

               // Executing replace operation for reference unit table
               var referenceUnitReplaceOperations = patchOperations.Where(o => o.TableName == "REFERENCE_UNIT" && o.Operation == "replace");
               if (referenceUnitReplaceOperations.Any())
               {
                  string query = string.Join(";", referenceUnitReplaceOperations.Select(n => n.Query));
                  query = "Begin " + query + "; End;";
                  this.BulkReplaceOperation(referenceUnitReplaceOperations.Select(n => n.DynamicParameters), query);
               }

               // Executing replace operation for variation unit table
               var variationReplaceOperations = patchOperations.Where(o => o.TableName == "VARIATION" && o.Operation == "replace");
               if (variationReplaceOperations.Any())
               {
                  string query = string.Join(";", variationReplaceOperations.Select(n => n.Query));
                  query = "Begin " + query + "; End;";
                  this.BulkReplaceOperation(variationReplaceOperations.Select(n => n.DynamicParameters), query);
               }

               // Should not update variation companion table in stage/production environments.
               if (!this.commonConfigurationSettings.Value.DisableRebalancing)
               {
                  var variationCompanionReplaceOperations = patchOperations.Where(o => o.TableName == "VARIATION_COMPANION" && o.Operation == "replace");
                  if (variationCompanionReplaceOperations.Any())
                  {
                     string query = string.Join(";", variationCompanionReplaceOperations.Select(n => n.Query));
                     query = "Begin " + query + "; End;";
                     this.BulkReplaceOperation(variationCompanionReplaceOperations.Select(n => n.DynamicParameters), query);
                  }
               }

               this.dbTransaction.Commit();
               return true;
            }
            catch (Exception ex)
            {
               this.dbTransaction.Rollback();
               this.logger.LogError($"Error while performing transaction for non trane item patch operation: {ex.ToString()}");
               return false;
            }
         }
      }

      /// <summary>
      /// Get document details based on job id and variation id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="variationId">Variation id</param>
      /// <returns>Document details</returns>
      public async Task<IEnumerable<Document>> GetDocumentDetails(int jobId, int variationId)
      {
         var param = new
         {
            // Saved variation id as folder name for maintaining folder structure
            FOLDER_NAME = variationId.ToString(),
            JOB_ID = jobId,
            JOB_FOLDER_TYPE_ID = Constants.JobFolderTypeId
         };

         IEnumerable<Document> documentDetails = await this.repository.ExecuteListQuery<Document>(Common.Constants.NonTraneItemRepositoryQueries.GetDocumentDetailQuery, param);
         return documentDetails;
      }

      /// <summary>
      /// Insert bulk records
      /// </summary>
      /// <param name="insertData">Records to insert</param>
      /// <param name="insertQuery">Query for insert operation</param>
      private void BulkInsertEntities(IEnumerable<object> insertData, string insertQuery)
      {
         using (var command = (OracleCommand)this.dbConnection.CreateCommand())
         {
            command.CommandText = insertQuery;
            command.CommandType = CommandType.Text;
            command.ArrayBindCount = insertData.Count();
            command.BindByName = true;

            foreach (var prop in insertData.First().GetType().GetProperties())
            {
               var data = insertData.Select(x => prop.GetValue(x) == null ? DBNull.Value : prop.GetValue(x)).ToArray();
               var propertyType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
               if (propertyType == typeof(int) || propertyType == typeof(int?))
               {
                  command.Parameters.Add(":" + prop.Name, OracleDbType.Int32, data, ParameterDirection.Input);
               }
               else if (propertyType == typeof(string))
               {
                  command.Parameters.Add(":" + prop.Name, OracleDbType.Varchar2, data, ParameterDirection.Input);
               }
            }

            command.ExecuteNonQuery();
         }
      }

      /// <summary>
      /// Inserts records for specific table
      /// </summary>
      /// <param name="insertData">List of table records to insert</param>
      /// <param name="insertQuery">Query for add operation</param>
      private void BulkInsertJobEntities(IEnumerable<object> insertData, string insertQuery)
      {
         using (var command = (OracleCommand)this.dbConnection.CreateCommand())
         {
            command.CommandText = insertQuery;
            command.CommandType = CommandType.Text;
            command.ArrayBindCount = insertData.Count();
            command.BindByName = true;

            foreach (var property in insertData.First().GetType().GetProperties())
            {
               var data = insertData.Select(x => property.GetValue(x) == null ? DBNull.Value : property.GetValue(x)).ToArray();
               var propertyType = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
               if (propertyType == typeof(string))
               {
                  command.Parameters.Add(":" + property.Name, OracleDbType.Varchar2, data, ParameterDirection.Input);
               }
               else if (propertyType == typeof(decimal))
               {
                  command.Parameters.Add(":" + property.Name, OracleDbType.Decimal, data, ParameterDirection.Input);
               }
               else if (propertyType == typeof(DateTime))
               {
                  command.Parameters.Add(":" + property.Name, OracleDbType.Date, data, ParameterDirection.Input);
               }
               else if (propertyType == typeof(int))
               {
                  command.Parameters.Add(":" + property.Name, OracleDbType.Int64, data, ParameterDirection.Input);
               }
               else if (propertyType == typeof(double))
               {
                  command.Parameters.Add(":" + property.Name, OracleDbType.Double, data, ParameterDirection.Input);
               }
               else
               {
                  throw new ArgumentNullException(this.exceptionMessage);
               }
            }

            command.ExecuteNonQuery();
         }
      }

      /// <summary>
      /// Delete records for specific table
      /// </summary>
      /// <param name="removeData">List of table records for remove</param>
      /// <param name="removeQuery">Query for remove operation</param>
      private void BulkRemoveOperation(IEnumerable<DynamicParameters> removeData, string removeQuery)
      {
         using (var command = (OracleCommand)this.dbConnection.CreateCommand())
         {
            command.CommandText = removeQuery;
            command.CommandType = CommandType.Text;
            command.ArrayBindCount = removeData.Count();
            command.BindByName = true;

            foreach (var column in removeData.FirstOrDefault().ParameterNames)
            {
               var data = removeData.Select(x => x.Get<object>(column).ToString());
               command.Parameters.Add($":{column}", data.ToArray());
            }

            command.ExecuteNonQuery();
         }
      }

      /// <summary>
      /// Replace records for specific table
      /// </summary>
      /// <param name="replaceData">List of table records for replace</param>
      /// <param name="replaceQuery">Query for replace operation</param>
      private void BulkReplaceOperation(IEnumerable<DynamicParameters> replaceData, string replaceQuery)
      {
         using (var command = (OracleCommand)this.dbConnection.CreateCommand())
         {
            command.CommandText = replaceQuery;
            command.CommandType = CommandType.Text;
            command.BindByName = true;

            foreach (DynamicParameters dynamicParameters in replaceData)
            {
               foreach (var paramName in dynamicParameters.ParameterNames)
               {
                  var paramValue = dynamicParameters.Get<dynamic>(paramName);
                  paramValue = paramValue ?? DBNull.Value;
                  var propType = paramValue.GetType();
                  if (propType == typeof(int))
                  {
                     command.Parameters.Add(":" + paramName, OracleDbType.Int64, paramValue, ParameterDirection.Input);
                  }
                  else if (propType == typeof(DateTime))
                  {
                     command.Parameters.Add(":" + paramName, OracleDbType.Date, paramValue, ParameterDirection.Input);
                  }
                  else if (propType == typeof(double))
                  {
                     command.Parameters.Add(":" + paramName, OracleDbType.Double, paramValue, ParameterDirection.Input);
                  }
                  else if (propType == typeof(decimal))
                  {
                     command.Parameters.Add(":" + paramName, OracleDbType.Decimal, paramValue, ParameterDirection.Input);
                  }
                  else
                  {
                     command.Parameters.Add(":" + paramName, OracleDbType.Varchar2, paramValue, ParameterDirection.Input);
                  }
               }
            }

            command.ExecuteNonQuery();
         }
      }
   }
}
