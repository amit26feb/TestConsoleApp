﻿// <copyright file="INonTraneItemRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.ViewModels;

   /// <summary>
   /// Interface for non trane item repository
   /// </summary>
   public interface INonTraneItemRepository
   {
      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Gets the list of non trane item
      /// </summary>
      /// <param name="pagingOptions">Parameter to perform pagination</param>
      /// <param name="jobId">Job id</param>
      /// <returns>List of non trane item</returns>
      Task<IEnumerable<NonTraneItem>> GetNonTraneItems(TSMT.DataAccess.PagingOptions pagingOptions, int jobId);

      /// <summary>
      /// Get non trane item based on job id and variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Non trane item based on job id and variation id</returns>
      Task<NonTraneItem> GetNonTraneItem(int variationId, int jobId);

      /// <summary>
      /// Get tag details for non trane item based on job id and variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Tag detals of the non trane item based on job id and variation id</returns>
      Task<IEnumerable<TagDetail>> GetTagDetails(int variationId, int jobId);

      /// <summary>
      /// Method to get maximum sequence number of specific table
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <param name="howManyToReserve">How many blocks of new ids to reserve for a table</param>
      /// <returns>Maximum value of table primary key column</returns>
      Task<int> GetSequenceNumber(string tableName, int howManyToReserve = 1);

      /// <summary>
      /// Inserts new non trane item for a job
      /// </summary>
      /// <param name="nonTraneItem">Model of the non trane item</param>
      /// <returns>Created status</returns>
      Task<int> CreateNonTraneItemAsync(Models.NonTraneItem nonTraneItem);

      /// <summary>
      /// Delete non trane item based on variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <returns>Deleted status</returns>
      Task<int> DeleteNonTraneItem(int variationId);

      /// <summary>
      /// Update non trane item for a job
      /// </summary>
      /// <param name="patchOperations">List of patch operation for update non trane item</param>
      /// <returns>True or false based update status</returns>
      Task<bool> UpdateNonTraneItemAsync(IEnumerable<PatchOperation> patchOperations);

      /// <summary>
      /// Get document details based on job id and variation id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="variationId">Variation id</param>
      /// <returns>Document details</returns>
      Task<IEnumerable<Document>> GetDocumentDetails(int jobId, int variationId);
   }
}
