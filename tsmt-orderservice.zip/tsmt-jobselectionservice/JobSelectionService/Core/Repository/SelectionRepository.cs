﻿// <copyright file="SelectionRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Text;
   using System.Threading.Tasks;
   using Dapper;
   using JobSelectionService.Common;
   using JobSelectionService.Core.Models;
   using TSMT.DataAccess;
   using TSMT.DataAccess.Models;

   /// <summary>
   /// Repository for JobSelection operations
   /// </summary>
   public class SelectionRepository : ISelectionRepository
   {
      private const int OracleMaxListSize = 1000;
      private readonly IRepository<Selection> repository;

      /// <summary>
      /// Initializes a new instance of the <see cref="SelectionRepository"/> class.
      /// </summary>
      /// <param name="repository">Repository</param>
      public SelectionRepository(IRepository<Selection> repository)
      {
         this.repository = repository;
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         // Tell all IRepository instances about it.
         this.repository.HonorDrAddressId(drAddressId);
      }

      /// <summary>
      /// Gets the list of selections
      /// </summary>
      /// <param name="jobId"> Id of the corresponding job</param>
      /// <returns> List of selections </returns>
      public async Task<IEnumerable<Selection>> GetSelections(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         return await this.repository.ExecuteListQuery<Selection>(SelectionRepositoryQueries.GetSelectionsByJobIdQuery, param);
      }

      /// <summary>
      /// Gets the list of separate biddables
      /// </summary>
      /// <param name="jobId">Id of the corresponding job</param>
      /// <returns>List of separate biddables</returns>
      public async Task<IEnumerable<PricingParam>> GetSeparateBiddables(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         var query = @"SELECT DISTINCT CJ.bid_alternate_id, 
                       PPG.prod_code,
                       trim(both ' ' FROM PPG.bid_breakout_name) as bid_breakout_name,
                       PPG.separately_biddable_yes_no,
                       SPP.selected_pricing_parm_id,
                       SPP.hqtr_selected_pricing_parm_id,
                       SPP.revise_date,
                       S.selection_id,
                       spp.quick_ship_fap,
                       spp.prod_family_fap,
                       spp.flexible_fap,
                       spp.office_fap,
                       CASE 
                         WHEN S.sales_ord_id IS NOT NULL THEN 'O' 
                         WHEN S.pending_order_ind IS NOT NULL THEN 'C' 
                         ELSE 'N' 
                       END AS ORDERED_INDICATOR, 
                       CASE 
                         WHEN S.price_control_id IS NOT NULL THEN 'P' 
                         ELSE 'NP' 
                       END AS PRICED_INDICATOR 
                FROM   selected_pricing_parm SPP 
                       INNER JOIN selection S 
                               ON SPP.selection_id = S.selection_id 
                       INNER JOIN prod_pricing_grp PPG 
                               ON PPG.prod_pricing_grp_id = SPP.prod_pricing_grp_id 
                       LEFT JOIN order_line ol 
                              ON ol.selected_pricing_parm_id = spp.selected_pricing_parm_id 
                       LEFT JOIN credit_job CJ 
                              ON ol.credit_job_id = CJ.credit_job_id 
                WHERE  S.job_id = :JOB_ID 
                ORDER  BY SPP.selected_pricing_parm_id";

         return await this.repository.ExecuteListQuery<PricingParam>(query, param);
      }

      /// <summary>
      /// Gets the list of variations
      /// </summary>
      /// <param name="jobId">Id of the corresponding job</param>
      /// <returns>List of Variations(job and selection variations)</returns>
      public async Task<IEnumerable<Variation>> GetVariations(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         var query = @"SELECT DISTINCT cj.bid_alternate_id, 
                       v.variation_id,
                       trim(both ' ' FROM v.short_desc) as short_desc,
                       v.matl_qty, 
                       v.selection_id, 
                       v.hqtr_variation_id,
                       v.prod_code,
                       v.variation_billing_method_code,
                       CASE 
                         WHEN v.sales_ord_id IS NOT NULL THEN 'O' 
                         WHEN v.pending_order_ind IS NOT NULL THEN 'C' 
                         ELSE 'N' 
                       END             AS ORDERED_INDICATOR, 
                       (SELECT tag 
                        FROM   (SELECT RU.tag, 
                                       Row_number() 
                                         OVER( 
                                           partition BY RU.variation_id 
                                           ORDER BY RU.tag_sequence_nbr) rm 
                                FROM   reference_unit RU 
                                WHERE  RU.variation_id = v.variation_id) 
                        WHERE  rm = 1) AS TAg 
                FROM   variation v 
                       LEFT JOIN sales_order so 
                              ON so.sales_ord_id = v.sales_ord_id 
                                  OR so.legacy_ord_nbr = v.legacy_ord_nbr 
                       LEFT JOIN credit_job cj 
                              ON so.credit_job_id = cj.credit_job_id 
                WHERE  v.job_id = :job_id 
                ORDER  BY short_desc";

         return await this.repository.ExecuteListQuery<Variation>(query, param);
      }

      /// <summary>
      /// Gets the selection details
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Selection details</returns>
      public async Task<IEnumerable<SelectionInfo>> GetSelectionDetails(int jobId, IEnumerable<int> selectionIds)
      {
         var selectionQueryParameter = new
         {
            JOB_ID = jobId,
            SELECTION_ID_LIST = selectionIds
         };
         return await this.repository.ExecuteListQuery<SelectionInfo>(SelectionRepositoryQueries.SelectionDetailsQuery, selectionQueryParameter);
      }

      /// <summary>
      /// Gets the count of selections for job id
      /// </summary>
      /// <returns>Return selection count based on job id</returns>
      /// <param name="jobId">Job id</param>
      public async Task<int> GetSelectionCount(int jobId)
      {
         var selectionQueryParameter = new
         {
            JOB_ID = jobId,
         };
         return await this.repository.ExecuteQuery<int>(SelectionRepositoryQueries.SelectionCountQuery, selectionQueryParameter);
      }

      /// <summary>
      /// Gets the bill of materials
      /// </summary>
      /// <param name="coordinationId">Coordination id</param>
      /// <returns>Bill of materials</returns>
      public async Task<byte[]> GetBillOfMaterials(int coordinationId)
      {
         var param = new
         {
            COORDINATION_ID = coordinationId
         };

         return await this.repository.ExecuteQuery<byte[]>(SelectionRepositoryQueries.BomQuery, param) ?? Array.Empty<byte>();
      }

      /// <summary>
      /// Gets the selected item
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Selected item</returns>
      public async Task<IEnumerable<Selection>> GetSelectedItems(int jobId, IEnumerable<int> selectionIds)
      {
         var selectionQueryParameter = new
         {
            JOB_ID = jobId,
            SELECTION_IDS = selectionIds
         };
         return await this.repository.ExecuteListQuery<Selection>(SelectionRepositoryQueries.SelectedItemGetQuery, selectionQueryParameter);
      }

      /// <summary>
      /// Gets the product family ids for available ship cycle vpcs
      /// If the sum = 0 (1 row returned) then the selection does not have a ship cycle vpc
      /// If the sum is blank (no row returned) then the selection does have a ship cycle vpc
      /// </summary>
      /// <param name="productFamilyIds">Product family id</param>
      /// <returns>Product family ids</returns>
      public async Task<IEnumerable<int>> GetProductFamilyIds(IEnumerable<int> productFamilyIds)
      {
         var param = new
         {
            PROD_FAMILY_ID = productFamilyIds
         };

         return await this.repository.ExecuteListQuery<int>(SelectionRepositoryQueries.ShipCycleVpcAvailable, param);
      }

      /// <summary>
      /// Get SI ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Si ids</returns>
      public async Task<IEnumerable<Si>> GetSis(int jobId, IEnumerable<int> selectionIds)
      {
         var param = new
         {
            SELECTION_ID = selectionIds,
            JOB_ID = jobId
         };

         return await this.repository.ExecuteListQuery<Si>(SelectionRepositoryQueries.SelectionHasShipCycleVpc, param);
      }

      /// <summary>
      /// Get bids selections
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Bids selections</returns>
      public async Task<IEnumerable<Selection>> GetBidsSelections(int jobId, IEnumerable<int> selectionIds)
      {
         var param = new
         {
            SELECTION_ID = selectionIds,
            JOB_ID = jobId
         };

         return await this.repository.ExecuteListQuery<Selection>(SelectionRepositoryQueries.GetSelectionQuery, param);
      }

      /// <summary>
      /// Get selection performance details
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <param name="jobId">Job id</param>
      /// <param name="isJobSearch">True indicating get selections details by job id, false indicating get selections details by selection ids</param>
      /// <returns>Selection performance details</returns>
      public async Task<IEnumerable<Selection>> GetSelectionPerformanceDetails(IEnumerable<int> selectionIds, int jobId, bool isJobSearch)
      {
         StringBuilder query = new StringBuilder(SelectionRepositoryQueries.SelectionPerformanceGetQuery);
         object param;
         if (isJobSearch)
         {
            param = new
            {
               JOB_ID = jobId
            };
            query.Append(SelectionRepositoryQueries.SelectionPerformanceByJobIdGetQuery);
         }
         else
         {
            param = new
            {
               SELECTION_IDS = selectionIds
            };
            query.Append(SelectionRepositoryQueries.SelectionPerformanceBySelectionIdGetQuery);
         }

         return await this.repository.ExecuteListQuery<Selection>(query.ToString(), param);
      }

      /// <summary>
      /// Gets the trane items
      /// </summary>
      /// <param name="pagingOptions">Parameters to perform pagination</param>
      /// <param name="jobId ">Id of the corresponding job</param>
      /// <returns>Trane items</returns>
      public async Task<IEnumerable<Selection>> GetTraneItems(TSMT.DataAccess.PagingOptions pagingOptions, int jobId)
      {
         StringBuilder stringBuilder = new StringBuilder();
         string sortClause = this.repository.BuildSortClause<Selection>(pagingOptions.Sort);
         stringBuilder.AppendFormat(SelectionRepositoryQueries.SelectionsQuery, sortClause);

         DynamicParameters dynamicParams = new DynamicParameters();
         dynamicParams.Add("Skip", pagingOptions.Skip + 1);
         dynamicParams.Add("Take", pagingOptions.Take + pagingOptions.Skip);
         dynamicParams.Add("JOB_ID", jobId);

         if (pagingOptions.Filters != null && pagingOptions.Filters.Count > 0)
         {
            QueryResult filterClause = this.repository.BuildFilterClause<Selection>(pagingOptions.Filters);
            string filterClauseQuery = string.IsNullOrEmpty(filterClause.Query) ? string.Empty : filterClause.Query;
            dynamicParams.AddDynamicParams(filterClause.Parameters);
            stringBuilder.Append(filterClauseQuery);
         }

         stringBuilder.Append(") WHERE RowNumber BETWEEN :SKIP AND :TAKE");

         string query = stringBuilder.ToString();
         var selections = await this.repository.ExecuteListQuery<Selection>(query, dynamicParams);
         return selections;
      }

      /// <summary>
      /// Gets net price of selected pricing parm records based on job id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selection details</returns>
      public async Task<IEnumerable<PricingParam>> GetSelectedPricingParamRecords(int jobId)
      {
         var selectionQueryParameter = new
         {
            JOB_ID = jobId,
         };
         return await this.repository.ExecuteListQuery<PricingParam>(SelectionRepositoryQueries.SelectedPricingParamQuery, selectionQueryParameter);
      }

      /// <summary>
      /// Gets selected pricing param records based on spp ids
      /// </summary>
      /// <param name="selectedPricingParamIds">Selected pricing param Ids</param>
      /// <returns>Selected pricing params</returns>
      public async Task<IEnumerable<PricingParam>> GetSelectedPricingParamByIds(IEnumerable<int> selectedPricingParamIds)
      {
         var param = new
         {
            SELECTED_PRICING_PARM_IDS = selectedPricingParamIds,
         };
         return await this.repository.ExecuteListQuery<PricingParam>(SelectionRepositoryQueries.SelectedPricingParmByIdsQuery, param);
      }

      /// <summary>
      /// Get selections with reference unit details
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selections with reference unit details</returns>
      public async Task<IEnumerable<Selection>> GetReferenceUnitDetails(int jobId)
      {
         StringBuilder query = new StringBuilder(SelectionRepositoryQueries.ReferenceUnitGetQuery);
         query.Append(SelectionRepositoryQueries.SelectionPerformanceByJobIdGetQuery);
         var param = new
         {
            JOB_ID = jobId
         };
         return await this.repository.ExecuteListQuery<Selection>(query.ToString(), param);
      }

      /// <summary>
      /// Gets ship cycle detail
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Ship cycle detail</returns>
      public async Task<IEnumerable<ShipCycle>> GetShipCycleDetails(IEnumerable<int> selectionIds)
      {
         IEnumerable<ShipCycle> shipCycleDetails = new List<ShipCycle>() { };
         int skip = 0;
         while (skip < selectionIds.Count())
         {
            var maximumSelectionIds = selectionIds.Skip(skip).Take(OracleMaxListSize);
            var param = new
            {
               SELECTION_IDS = maximumSelectionIds
            };
            IEnumerable<ShipCycle> shipCycle = await this.repository.ExecuteListQuery<ShipCycle>(SelectionRepositoryQueries.ShipCycleGetQuery, param);
            shipCycleDetails = shipCycleDetails.Concat(shipCycle);
            skip += OracleMaxListSize;
         }

         return shipCycleDetails;
      }
   }
}
