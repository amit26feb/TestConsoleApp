﻿// <copyright file="ISelectionRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobSelectionService.Core.Models;

   /// <summary>
   /// Interface for job selection operations
   /// </summary>
   public interface ISelectionRepository
    {
        /// <summary>
        /// Method to indicate a particular DrAddressId to honor when interacting with the database.
        /// </summary>
        /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
        void HonorDrAddressId(int? drAddressId);

        /// <summary>
        /// Gets the List of Selections
        /// </summary>
        /// <param name="jobId"> Id of the corresponding Job</param>
        /// <returns> List of selections</returns>
        Task<IEnumerable<Selection>> GetSelections(int jobId);

        /// <summary>
        /// Gets the list of separate biddables
        /// </summary>
        /// <param name="jobId">Id of the corresponding job</param>
        /// <returns>List of separate biddables</returns>
        Task<IEnumerable<PricingParam>> GetSeparateBiddables(int jobId);

        /// <summary>
        /// Gets the list of variations
        /// </summary>
        /// <param name="jobId">Id of corresponding job</param>
        /// <returns>List of Variations</returns>
        Task<IEnumerable<Variation>> GetVariations(int jobId);

        /// <summary>
        /// Gets the selection details
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="selectionIds">Selection ids</param>
        /// <returns>Selection details</returns>
        Task<IEnumerable<SelectionInfo>> GetSelectionDetails(int jobId, IEnumerable<int> selectionIds);

       /// <summary>
       /// Gets the count of selections for job id
       /// </summary>
       /// <returns>Return selection count based on job id</returns>
       /// <param name="jobId">Job id</param>
       Task<int> GetSelectionCount(int jobId);

      /// <summary>
      /// Gets the bill of materials
      /// </summary>
      /// <param name="coordinationId">Coordination id</param>
      /// <returns>Bill of materials</returns>
      Task<byte[]> GetBillOfMaterials(int coordinationId);

      /// <summary>
      /// Gets the product family ids for available ship cycle vpcs
      /// If the sum = 0 (1 row returned) then the selection does not have a ship cycle vpc
      /// If the sum is blank (no row returned) then the selection does have a ship cycle vpc
      /// </summary>
      /// <param name="productFamilyIds">Product family id</param>
      /// <returns>Product family ids</returns>
      Task<IEnumerable<int>> GetProductFamilyIds(IEnumerable<int> productFamilyIds);

      /// <summary>
      /// Gets the selected item
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Selected tem</returns>
      Task<IEnumerable<Selection>> GetSelectedItems(int jobId, IEnumerable<int> selectionIds);

      /// <summary>
      /// Get SI ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Si ids</returns>
      Task<IEnumerable<Si>> GetSis(int jobId, IEnumerable<int> selectionIds);

      /// <summary>
      /// Get bids selections
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Bids selections</returns>
      Task<IEnumerable<Selection>> GetBidsSelections(int jobId, IEnumerable<int> selectionIds);

      /// <summary>
      /// Get selection performance details
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <param name="jobId">Job id</param>
      /// <param name="isJobSearch">True indicating get selections details by job id, false indicating get selections details by selection ids</param>
      /// <returns>Selection performance details</returns>
      Task<IEnumerable<Selection>> GetSelectionPerformanceDetails(IEnumerable<int> selectionIds, int jobId, bool isJobSearch);

      /// <summary>
      /// Gets the trane items
      /// </summary>
      /// <param name="pagingOptions">Parameters to perform pagination</param>
      /// <param name="jobId ">Id of the corresponding job</param>
      /// <returns>Trane items</returns>
      Task<IEnumerable<Selection>> GetTraneItems(TSMT.DataAccess.PagingOptions pagingOptions, int jobId);

      /// <summary>
      /// Gets all the selected pricing parm records based on job id
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selection details</returns>
      Task<IEnumerable<PricingParam>> GetSelectedPricingParamRecords(int jobId);

      /// <summary>
      /// Gets selected pricing param records based on spp ids
      /// </summary>
      /// <param name="selectedPricingParamIds">Selected pricing param Ids</param>
      /// <returns>Selected pricing params</returns>
      Task<IEnumerable<PricingParam>> GetSelectedPricingParamByIds(IEnumerable<int> selectedPricingParamIds);

      /// <summary>
      /// Get selections with reference unit details
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selections with reference unit details</returns>
      Task<IEnumerable<Selection>> GetReferenceUnitDetails(int jobId);

      /// <summary>
      /// Gets ship cycle details
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Ship cycle details</returns>
      Task<IEnumerable<ShipCycle>> GetShipCycleDetails(IEnumerable<int> selectionIds);
   }
}
