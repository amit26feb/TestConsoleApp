﻿// <copyright file="CreateNonTraneItemCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Commands
{
   using System.Runtime.Serialization;
   using JobSelectionService.Core.ViewModels;
   using MediatR;

   /// <summary>
   /// Handles command to create non trane item for a job
   /// </summary>
   [DataContract]
   public class CreateNonTraneItemCommand : IRequest<int>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="CreateNonTraneItemCommand"/> class.
      /// </summary>
      /// <param name="nonTraneItem">Request payload for create non trane item</param>
      public CreateNonTraneItemCommand(NonTraneItemViewModel nonTraneItem)
      {
         this.NonTraneItem = nonTraneItem;
      }

      /// <summary>
      /// Gets non trane item model property
      /// </summary>
      [DataMember]
      public NonTraneItemViewModel NonTraneItem { get; private set; }
   }
}
