﻿// <copyright file="DeleteNonTraneItemCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Core.Commands
{
   using System.Runtime.Serialization;
   using MediatR;

   /// <summary>
   /// Handles command to delete non trane item for a job
   /// </summary>
   [DataContract]
   public class DeleteNonTraneItemCommand : IRequest<int>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="DeleteNonTraneItemCommand"/> class.
      /// </summary>
      /// <param name="variationId">Request payload for delete non trane item</param>
      public DeleteNonTraneItemCommand(int variationId)
      {
         this.VariationId = variationId;
      }

      /// <summary>
      /// Gets variation id
      /// </summary>
      [DataMember]
      public int VariationId { get; private set; }
   }
}
