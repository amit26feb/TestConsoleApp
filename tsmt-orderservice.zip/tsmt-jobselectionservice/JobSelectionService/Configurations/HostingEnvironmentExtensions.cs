﻿// <copyright file="HostingEnvironmentExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Configurations
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Hosting;

    /// <summary>
    /// Hosting environment extensions
    /// </summary>
    public static class HostingEnvironmentExtensions
    {
        /// <summary>
        /// UAT Environment
        /// </summary>
        public const string UATEnvironment = "UAT";

        /// <summary>
        /// Check Is UAT
        /// </summary>
        /// <param name="hostingEnvironment">Web host environment</param>
        /// <returns>Web host environment details</returns>
        public static bool IsUAT(this IWebHostEnvironment hostingEnvironment)
        {
            return hostingEnvironment.IsEnvironment(UATEnvironment);
        }
    }
}
