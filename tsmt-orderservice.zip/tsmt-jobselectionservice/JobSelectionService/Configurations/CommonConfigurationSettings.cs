﻿// <copyright file="CommonConfigurationSettings.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Configurations
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

   /// <summary>
   /// Common configuration settings
   /// </summary>
   public class CommonConfigurationSettings
   {
      /// <summary>
      /// Gets or sets a value indicating whether the rebalancing is disabled
      /// </summary>
      public bool DisableRebalancing { get; set; }
   }
}
