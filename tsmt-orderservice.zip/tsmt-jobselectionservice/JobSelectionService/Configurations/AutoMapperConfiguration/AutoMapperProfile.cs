﻿// <copyright file="AutoMapperProfile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Configurations.AutoMapperConfiguration
{
   using AutoMapper;
   using JobSelectionService.Common.Constants;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.ViewModels;
   using Models = JobSelectionService.Core.Models;
   using ViewModels = JobSelectionService.Core.ViewModels;

   /// <summary>
   /// Auto mapper profile
   /// </summary>
   public class AutoMapperProfile : Profile
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="AutoMapperProfile"/> class.
      /// </summary>
      public AutoMapperProfile()
      {
         this.MapForViewing();
         this.MapForAdding();

         this.SourceMemberNamingConvention = new LowerUnderscoreNamingConvention();
         this.DestinationMemberNamingConvention = new PascalCaseNamingConvention();
         this.ReplaceMemberName("_", string.Empty);
      }

      /// <summary>
      /// Maps the domain models to the view models that are used for viewing in UI
      /// </summary>
      private void MapForViewing()
      {
         this.CreateMap<SelectionInfo, SelectionInfoViewModel>()
             .ForMember(dest => dest.SelectionId, opt => opt.MapFrom(src => src.SELECTION_ID))
             .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.DESCRIPTION))
             .ForMember(dest => dest.CoordinationJobShipYear, opt => opt.MapFrom(src => src.CJ_SHIP_YEAR))
             .ForMember(dest => dest.CoordinationJobShipQuarter, opt => opt.MapFrom(src => src.CJ_SHIP_QTR))
             .ForMember(dest => dest.CoordinationJobCompetitor, opt => opt.MapFrom(src => src.CJ_COMPETITOR))
             .ForMember(dest => dest.CoordinationJobSpecifiedUser, opt => opt.MapFrom(src => src.CJ_SPECIFIED))
             .ForMember(dest => dest.PriceControlId, opt => opt.MapFrom(src => src.PRICE_CONTROL_ID))
             .ForMember(dest => dest.ProdFamilyId, opt => opt.MapFrom(src => src.PROD_FAMILY_ID))
             .ForMember(dest => dest.SelectionSource, opt => opt.MapFrom(src => src.SELECTION_SOURCE))

             // sel price complete = true, when SEL_PRICE_COMPLETE is null
             //  there may be a better way to accomplish, but string.IsNullOrWhitespace doens't execute on NULL, preventing the true option
             .ForMember(dest => dest.IsSelectionPriceComplete, opt => opt.MapFrom(src => src.SEL_PRICE_COMPLETE != "N"))
             .ReverseMap();
      }

      /// <summary>
      /// Maps the Domain Models to the view models and viceversa for Add scenarios
      /// </summary>
      private void MapForAdding()
      {
         // JobSelection Mapping
         this.CreateMap<Models.Selection, ViewModels.SelectionViewModel>()
             .ForMember(dest => dest.SelectionId, opt => opt.MapFrom(src => src.SELECTION_ID))
             .ForMember(dest => dest.SelectionDescription, opt => opt.MapFrom(src => src.SALESMAN_DESCR))
             .ForMember(dest => dest.ProductCode, opt => opt.MapFrom(src => src.PROD_CODE))
             .ForMember(dest => dest.ProductFamily, opt => opt.MapFrom(src => src.PROD_FAMILY))
             .ForMember(dest => dest.Qty, opt => opt.MapFrom(src => src.UNIT_QTY))
             .ForMember(dest => dest.Tag, opt => opt.MapFrom(src => src.TAG))
             .ForMember(dest => dest.OrderedIndicator, opt => opt.MapFrom(src => src.ORDERED_INDICATOR))
             .ForMember(dest => dest.PricedIndicator, opt => opt.MapFrom(src => src.PRICED_INDICATOR))
             .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
             .ForMember(dest => dest.HqtrSelectionId, opt => opt.MapFrom(src => src.HQTR_SELECTION_ID))
             .ForMember(dest => dest.SelectionSource, opt => opt.MapFrom(src => src.SELECTION_SOURCE))
             .ForMember(dest => dest.SalesOrderId, opt => opt.MapFrom(src => src.SALES_ORD_ID))
             .ForMember(dest => dest.PendingOrderInd, opt => opt.MapFrom(src => src.PENDING_ORDER_IND))
             .ForMember(dest => dest.SelPriceComplete, opt => opt.MapFrom(src => src.SEL_PRICE_COMPLETE))
             .ForMember(dest => dest.PriceControlId, opt => opt.MapFrom(src => src.PRICE_CONTROL_ID))
             .ForMember(dest => dest.ListPrice, opt => opt.MapFrom(src => src.LIST_PRICE))
             .ForMember(dest => dest.NetPrice, opt => opt.MapFrom(src => src.TOTAL_NET_DOLLARS))
             .ForMember(dest => dest.ReviseDate, opt => opt.MapFrom(src => src.REVISE_DATE))
             .ForMember(dest => dest.TotalCount, opt => opt.MapFrom(src => src.TOTAL_COUNT))
             .ForMember(dest => dest.LegacyOrderNumber, opt => opt.MapFrom(src => src.LEGACY_ORD_NBR))
             .ForMember(dest => dest.SequenceNumber, opt => opt.MapFrom(src => src.SEQUENCE_NBR))
             .ForMember(dest => dest.Source, opt => opt.MapFrom(src => src.SOURCE))
             .ForMember(dest => dest.ProductFamilyId, opt => opt.MapFrom(src => src.PROD_FAMILY_ID))
             .ForMember(dest => dest.OrderProcessingRuleId, opt => opt.MapFrom(src => src.OP_RULE_ID))
             .ForMember(dest => dest.OrderGroupingId, opt => opt.MapFrom(src => src.ORD_GRP_ID))
             .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.STATUS1))
             .ForMember(dest => dest.BOMReviseDate, opt => opt.MapFrom(src => src.BOM_REVISE_DATE))
             .ForMember(dest => dest.NonBOMReviseDate, opt => opt.MapFrom(src => src.NON_BOM_REVISE_DATE))
             .ForMember(dest => dest.IsActiveInJob, opt => opt.MapFrom(src => src.ACTIVE_IN_JOB_YESNO_FLAG))
             .ForMember(dest => dest.Product, opt => opt.MapFrom(src => src.PROD))
             .ForMember(dest => dest.OeTagsRequiredIndicator, opt => opt.MapFrom(src => src.OE_TAGS_REQUIRED_IND))
             .ForMember(dest => dest.RequestTopssFlag, opt => opt.MapFrom(src => src.PERF_CHGS_REQ_TOPSS))
             .ForMember(dest => dest.VpcId, opt => opt.MapFrom(src => src.VPC_ID))
             .ForMember(dest => dest.SelectedItemId, opt => opt.MapFrom(src => src.SELECTED_ITEM_ID))
             .ForMember(dest => dest.ProdModuleId, opt => opt.MapFrom(src => src.PROD_MODULE_ID))
             .ForMember(dest => dest.VpfcId, opt => opt.MapFrom(src => src.VPFC_ID))
             .ForMember(dest => dest.SiId, opt => opt.MapFrom(src => src.SI_ID))
             .ForMember(dest => dest.OrderLineNumber, opt => opt.MapFrom(src => src.ORD_LINE_NBR))
             .ForMember(dest => dest.OrderGroupDescription, opt => opt.MapFrom(src => src.ORD_GRP_DESCR))
             .ForMember(dest => dest.IsAllowPartialShipment, opt => opt.MapFrom(src => src.ALLOW_NO_PARTIAL_SHIPMENT_IND == "N"))
             .ForMember(dest => dest.TagSequenceNumber, opt => opt.MapFrom(src => src.TAG_SEQUENCE_NBR))
             .ReverseMap();

         // separateBiddable Mapping
         this.CreateMap<Models.PricingParam, ViewModels.PricingParamViewModel>()
             .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.BID_BREAKOUT_NAME))
             .ForMember(dest => dest.ProductCode, opt => opt.MapFrom(src => src.PROD_CODE))
             .ForMember(dest => dest.SelectedPricingParmId, opt => opt.MapFrom(src => src.SELECTED_PRICING_PARM_ID))
             .ForMember(dest => dest.IsSeparatelyBiddable, opt => opt.MapFrom(src => src.SEPARATELY_BIDDABLE_YES_NO)).ReverseMap();

         // Variation Mapping
         this.CreateMap<Models.Variation, ViewModels.VariationViewModel>()
             .ForMember(dest => dest.SelectionId, opt => opt.MapFrom(src => src.SELECTION_ID))
             .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.SHORT_DESC))
             .ForMember(dest => dest.ProductCode, opt => opt.MapFrom(src => src.PROD_CODE))
             .ForMember(dest => dest.VariationId, opt => opt.MapFrom(src => src.VARIATION_ID))
             .ForMember(dest => dest.Qty, opt => opt.MapFrom(src => src.MATL_QTY))
             .ForMember(dest => dest.OrderedIndicator, opt => opt.MapFrom(src => src.ORDERED_INDICATOR))
             .ForMember(dest => dest.Tag, opt => opt.MapFrom(src => src.TAG))
             .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
             .ForMember(dest => dest.HqtrVariationId, opt => opt.MapFrom(src => src.HQTR_VARIATION_ID)).ReverseMap();

         // Bids selection mapping
         this.CreateMap<BillOfMaterial, BidSelectionViewModel>()
             .ForMember(dest => dest.ProductFamilyId, opt => opt.MapFrom(src => src.PROD_FAMILY_ID))
             .ForMember(dest => dest.ShipQuarter, opt => opt.MapFrom(src => src.CJ_SHIP_QTR))
             .ForMember(dest => dest.ShipYear, opt => opt.MapFrom(src => src.CJ_SHIP_YEAR))
             .ForMember(dest => dest.SelectionIds, opt => opt.MapFrom(src => src.SELECTION_IDS))
             .ForMember(dest => dest.SelectionSource, opt => opt.MapFrom(src => src.SELECTION_SOURCE))
             .ForMember(dest => dest.DoesSeparatelyBiddableSelectionsExist, opt => opt.MapFrom(src => src.DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST))
             .ReverseMap();

         // Paging options mapping
         this.CreateMap<ViewModels.PagingOptions, Models.PagingOptions>()
                .ForMember(dest => dest.Skip, opt => opt.MapFrom(src => src.Skip))
                .ForMember(dest => dest.Sort, opt => opt.MapFrom(src => src.Sort))
                .ForMember(dest => dest.Take, opt => opt.MapFrom(src => src.Take))
                .ReverseMap();

         // mapping
         this.CreateMap<ViewModels.NonTraneItemViewModel, Models.NonTraneItem>()
                .ForMember(dest => dest.JOB_ID, opt => opt.MapFrom(src => src.JobId))
                .ForMember(dest => dest.VARIATION_ID, opt => opt.MapFrom(src => src.VariationId))
                .ForMember(dest => dest.VARIATION_TYPE, opt => opt.MapFrom(src => src.VariationType))
                .ForMember(dest => dest.MATL_EXTENDED_COST, opt => opt.MapFrom(src => src.Cost))
                .ForMember(dest => dest.MATL_MARKUP_MULTIPLIER, opt => opt.MapFrom(src => src.Markup))
                .ForMember(dest => dest.MATL_QTY, opt => opt.MapFrom(src => src.Qty))
                .ForMember(dest => dest.SALES_ORD_ID, opt => opt.MapFrom(src => src.SalesOrderId))
                .ForMember(dest => dest.SHORT_DESC, opt => opt.MapFrom(src => src.Description))
                .ForMember(dest => dest.PROVIDER_NAME, opt => opt.MapFrom(src => src.ProviderName))
                .ForMember(dest => dest.PENDING_ORDER_IND, opt => opt.MapFrom(src => src.PendingOrderInd))
                .ForMember(dest => dest.NET_PRICE, opt => opt.MapFrom(src => src.SellingPrice))
                .ForMember(dest => dest.TOTAL_COUNT, opt => opt.MapFrom(src => src.TotalCount))
                .ForMember(dest => dest.VENDOR_NAME, opt => opt.MapFrom(src => src.VendorName))
                .ForMember(dest => dest.EQUIPMENT_NAME, opt => opt.MapFrom(src => src.EquipmentName))
                .ForMember(dest => dest.VENDOR_ID, opt => opt.MapFrom(src => src.VendorId))
                .ForMember(dest => dest.PRODUCT_ID, opt => opt.MapFrom(src => src.ProductId))
                .ForMember(dest => dest.VENDOR_LEAD_TIME_DAYS, opt => opt.MapFrom(src => src.VendorLeadTimeDays))
                .ForMember(dest => dest.PROD_CODE, opt => opt.MapFrom(src => src.ProdCode))
                .ForMember(dest => dest.PRODUCT_NAME, opt => opt.MapFrom(src => src.ProductName))
                .ForMember(dest => dest.MATERIAL_COUNT, opt => opt.MapFrom(src => src.MaterialCount))
                .ForMember(dest => dest.LABOR_COUNT, opt => opt.MapFrom(src => src.LaborCount))
                .ForMember(dest => dest.FACILITATIONFEE_COUNT, opt => opt.MapFrom(src => src.FacilitationFeeCount))
                .ForMember(dest => dest.STRATEGIC_PROVIDER, opt => opt.MapFrom(src => src.StrategicProvider))
                .ForMember(dest => dest.COST_CATEGORY, opt => opt.MapFrom(src => src.CostCategory))
                .ForMember(dest => dest.COST_FORECAST, opt => opt.MapFrom(src => src.CostForecast))
                .ForMember(dest => dest.COST_ESTIMATE, opt => opt.MapFrom(src => src.CostEstimate))
                .ForMember(dest => dest.IS_ORACLE, opt => opt.MapFrom(src => src.IsOracle ? "Y" : "N"))

                // We will not receive variation prod code value from UI
                // and for supporting legacy system, assign default variation prod code value as 5119
                .ForMember(dest => dest.VARIATION_PROD_CODE, opt => opt.UseValue<int>(Constants.VariationProductCode))
                .ReverseMap()
                .ForPath(dest => dest.IsOracle, opt => opt.MapFrom(src => src.IS_ORACLE == "Y" ? true : false));

         // Tag detail mapping
         this.CreateMap<TagDetail, TagDetailViewModel>()
                .ForMember(dest => dest.ReferenceUnitId, opt => opt.MapFrom(src => src.REFERENCE_UNIT_ID))
                .ForMember(dest => dest.Tag, opt => opt.MapFrom(src => src.TAG))
                .ForMember(dest => dest.TagSequenceNbr, opt => opt.MapFrom(src => src.TAG_SEQUENCE_NBR))
                .ReverseMap();

         // document detail mapping
         this.CreateMap<Document, DocumentViewModel>().ReverseMap();

         // ship cycle detail mapping
         this.CreateMap<ShipCycle, ShipCycleViewModel>()
            .ForMember(dest => dest.UnitOfMeasure, opt => opt.MapFrom(src => src.UOM))
            .ReverseMap();
      }
   }
}
