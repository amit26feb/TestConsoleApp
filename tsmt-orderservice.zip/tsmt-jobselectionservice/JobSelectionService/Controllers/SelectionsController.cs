﻿// <copyright file="SelectionsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using JobSelectionService.Common.Constants;
    using JobSelectionService.Common.Exceptions;
    using JobSelectionService.Core.Services;
    using JobSelectionService.Core.ViewModels;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// SelectionsController
    /// </summary>
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/[controller]")]
    [Authorize]
    public class SelectionsController : Controller
    {
        private readonly ILogger<SelectionsController> logger;
        private readonly ISelectionService selectionService;

        /// <summary>
        /// Initializes a new instance of the <see cref="SelectionsController"/> class.
        /// </summary>
        /// <param name="selectionService">Selections Service</param>
        /// <param name="logger">Selections logger</param>
        public SelectionsController(ISelectionService selectionService, ILogger<SelectionsController> logger)
        {
            this.selectionService = selectionService;
            this.logger = logger;
        }

        /// <summary>
        /// GetJobSelections
        /// </summary>
        /// <returns>Return JobSelection based on JobId</returns>
        /// <param name="jobId">jobId</param>
        [HttpGet]
        [ProducesResponseType(typeof(JobSelectionViewModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> GetJobSelections(int jobId)
        {
            if (jobId > 0)
            {
                JobSelectionViewModel jobSelection = await this.selectionService.GetJobSelections(jobId);
                if (jobSelection != null)
                {
                    return this.Ok(jobSelection);
                }
                else
                {
                    string message = $"No Selection available for Job Id: {jobId}";
                    this.logger.LogInformation(message);
                    return this.NoContent();
                }
            }
            else
            {
                string errorMessage = $"Invalid Request. Job Id '{jobId}' is not valid";
                this.logger.LogError(errorMessage);
                return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
            }
        }

        /// <summary>
        /// Gets the selection details
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="selectionIds">Selection ids</param>
        /// <returns>Selection details</returns>
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<SelectionInfoViewModel>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> GetSelectionDetails(int jobId, [FromBody]IEnumerable<int> selectionIds)
        {
            if (jobId > 0 && selectionIds.Any() && selectionIds.All(x => x > 0))
            {
                var selectionDetails = await this.selectionService.GetSelectionDetails(jobId, selectionIds);
                return selectionDetails.Any() ? this.Ok(selectionDetails) : (IActionResult)this.NoContent();
            }

            string errorMessage = $"Invalid request. Job id '{jobId}' or empty selection id list or invalid selection id";
            this.logger.LogError(errorMessage);
            return this.BadRequest(errorMessage);
        }

      /// <summary>
      /// Check selection exists for given job id or not
      /// </summary>
      /// <returns>Return true if selection exists else false</returns>
      /// <param name="jobId">Job id</param>
      [Route("IsExist")]
      [HttpGet]
      [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> IsSelectionExists(int jobId)
      {
         if (jobId > 0)
         {
            bool isSelectionExist = await this.selectionService.IsSelectionExists(jobId);
            return this.Ok(isSelectionExist);
         }
         else
         {
            string errorMessage = $"Invalid Request. Job Id '{jobId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }
      }

      /// <summary>
      /// Get bids selections and si ids
      /// If product family ids does have ship cycle vpc then we are getting selection ids for the product family ids
      /// If product families selection ids doesn't have si ids then we are getting salesman description for the product families selection ids
      /// If product families selection ids does have si ids then we are getting si ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="jobCoordinationId">Job coordination id</param>
      /// <returns>Bids selections and si ids</returns>
      [HttpGet]
      [Route("{jobCoordinationId}/Selection")]
      [ProducesResponseType(typeof(IEnumerable<BidSelectionViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetBidsSelections(int jobId, int jobCoordinationId)
      {
         if (jobId > 0 && jobCoordinationId > 0)
         {
            var selectionDetails = await this.selectionService.GetBidsSelections(jobId, jobCoordinationId);
            return selectionDetails.Any() ? this.Ok(selectionDetails) : (IActionResult)this.NoContent();
         }

         string errorMessage = $"Invalid request. Job id '{jobId}' or job coordination id {jobCoordinationId}";
         this.logger.LogError(errorMessage);
         return this.BadRequest(errorMessage);
      }

      /// <summary>
      /// Gets the selected items
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Selected items</returns>
      [Route("SelectedItems")]
      [HttpPost]
      [ProducesResponseType(typeof(IEnumerable<JobSelectionService.Core.Models.Selection>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetSelectedItems(int jobId, [FromBody] IEnumerable<int> selectionIds)
      {
         if (jobId > 0 && selectionIds?.Any() == true)
         {
            IEnumerable<SelectionViewModel> selectedItems = await this.selectionService.GetSelectedItems(jobId, selectionIds);
            return selectedItems.Any() ? this.Ok(selectedItems) : (IActionResult)this.NoContent();
         }

         string errorMessage = $"Invalid request. Job id '{jobId}' or empty selection id list or invalid selection id";
         this.logger.LogError(errorMessage);
         return this.BadRequest(errorMessage);
      }

      /// <summary>
      /// Get selection performance details
      /// </summary>
      /// <param name="selectionIds">Selection ids</param>
      /// <param name="jobId">Job id</param>
      /// <param name="isJobSearch">True indicating get selections details by job id, false indicating get selections details by selection ids</param>
      /// <returns>Selection performance details</returns>
      [Route("SelectionPerformance")]
      [HttpPost]
      [ProducesResponseType(typeof(IEnumerable<SelectionViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetSelectionPerformanceDetails([FromBody] IEnumerable<int> selectionIds, int jobId, bool isJobSearch)
      {
         if ((selectionIds.Any() && selectionIds.All(x => x > 0)) || (isJobSearch && jobId > 0))
         {
            IEnumerable<SelectionViewModel> selectionPerformances = await this.selectionService.GetSelectionPerformanceDetails(selectionIds, jobId, isJobSearch);
            return selectionPerformances.Any() ? this.Ok(selectionPerformances) : (IActionResult)this.NoContent();
         }

         this.logger.LogError(Constants.InvalidRequest);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { Constants.InvalidRequest }));
      }

      /// <summary>
      /// Get selections with reference unit details
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Selections with reference unit details</returns>
      [Route("ReferenceUnit")]
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<SelectionViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetReferenceUnitDetails(int jobId)
      {
         if (jobId > 0)
         {
            IEnumerable<SelectionViewModel> referenceUnits = await this.selectionService.GetReferenceUnitDetails(jobId);
            return referenceUnits.Any() ? this.Ok(referenceUnits) : (IActionResult)this.NoContent();
         }

         this.logger.LogError(Constants.InvalidRequest);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { Constants.InvalidRequest }));
      }

      /// <summary>
      /// Gets the trane items
      /// </summary>
      /// <param name="pagingOptions">Parameters to perform pagination</param>
      /// <param name="jobId ">Id of the corresponding job</param>
      /// <returns>Trane items</returns>
      [Route("TraneItems")]
      [HttpPost]
      [ProducesResponseType(typeof(IEnumerable<SelectionsPagingResults>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetTraneItems([FromBody]PagingOptions pagingOptions, int jobId)
      {
         if (jobId > 0)
         {
            var traneItems = await this.selectionService.GetTraneItems(pagingOptions, jobId);
            return traneItems.SelectionList.Any() ? this.Ok(traneItems) : (IActionResult)this.NoContent();
         }

         string errorMessage = $"Invalid request. Job id '{jobId}'";
         this.logger.LogError(errorMessage);
         return this.BadRequest(errorMessage);
      }

      /// <summary>
      /// Get selected pricing params of a job
      /// </summary>
      /// <param name="jobId">Job Id</param>
      /// <returns>List of selected pricing params</returns>
      [Route("SelectedPricingParams")]
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<PricingParamViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetSelectedPricingParams(int jobId)
      {
         if (jobId > 0)
         {
            IEnumerable<PricingParamViewModel> pricingParams = await this.selectionService.GetSelectedPricingParamRecords(jobId);
            if (pricingParams?.Any() == true)
            {
               return this.Ok(pricingParams);
            }
            else
            {
               this.logger.LogInformation($"No Selected Pricing Params available for Job Id: {jobId}");
               return this.NoContent();
            }
         }
         else
         {
            string errorMessage = $"Invalid Request. Job Id '{jobId}' is not valid.";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }
      }

      /// <summary>
      /// Get selected pricing params by Ids
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectedPricingParamIds">Selected pricing param ids</param>
      /// <returns>List of selected pricing params</returns>
      [Route("SelectedPricingParams")]
      [HttpPost]
      [ProducesResponseType(typeof(IEnumerable<PricingParamViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetSelectedPricingParams(int jobId, [FromBody] IEnumerable<int> selectedPricingParamIds)
      {
         if (jobId > 0 && selectedPricingParamIds?.Any() == true)
         {
            IEnumerable<PricingParamViewModel> pricingParams = await this.selectionService.GetSelectedPricingParams(selectedPricingParamIds);
            return pricingParams.Any() ? this.Ok(pricingParams) : (IActionResult)this.NoContent();
         }
         else
         {
            this.logger.LogInformation(Constants.InvalidRequest);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { Constants.InvalidRequest }));
         }
      }

      /// <summary>
      /// Gets ship cycle details
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="selectionIds">Selection ids</param>
      /// <returns>Ship cycle detail</returns>
      [Route("ShipCycle")]
      [HttpPost]
      [ProducesResponseType(typeof(IEnumerable<ShipCycleViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetShipCycleDetails(int jobId, [FromBody] IEnumerable<int> selectionIds)
      {
         if (jobId > 0 && selectionIds?.Any() == true)
         {
            IEnumerable<ShipCycleViewModel> shipCycles = await this.selectionService.GetShipCycleDetails(selectionIds);
            return shipCycles != null ? this.Ok(shipCycles) : (IActionResult)this.NoContent();
         }
         else
         {
            this.logger.LogInformation(Constants.InvalidRequest);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { Constants.InvalidRequest }));
         }
      }
   }
}