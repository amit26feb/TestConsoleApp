﻿// <copyright file="NonTraneItemsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using JobSelectionService.Common.Exceptions;
   using JobSelectionService.Core.Commands;
   using JobSelectionService.Core.Services;
   using JobSelectionService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.JsonPatch;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Non trane items controller
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/[controller]")]
   [Authorize]
   public class NonTraneItemsController : Controller
   {
      private readonly ILogger<NonTraneItemsController> logger;
      private readonly INonTraneItemService nonTraneItemService;
      private readonly IMediator mediator;

      /// <summary>
      /// Initializes a new instance of the <see cref="NonTraneItemsController"/> class.
      /// </summary>
      /// <param name="nonTraneItemService">Non trane item Service</param>
      /// <param name="logger">Non trane items logger</param>
      /// <param name="mediator">Non trane item mediator</param>
      public NonTraneItemsController(INonTraneItemService nonTraneItemService, ILogger<NonTraneItemsController> logger, IMediator mediator)
      {
         this.nonTraneItemService = nonTraneItemService;
         this.logger = logger;
         this.mediator = mediator;
      }

      /// <summary>
      /// Get non trane items
      /// </summary>
      /// <param name="pagingOptions">Parameter to perform pagination</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Return non trane items based on job id</returns>
      [Route("Search")]
      [HttpPost]
      [ProducesResponseType(typeof(NonTraneItemPagingResults), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetNonTraneItems([FromBody]PagingOptions pagingOptions, int jobId)
      {
         if (jobId > 0)
         {
            NonTraneItemPagingResults nonTraneItems = await this.nonTraneItemService.GetNonTraneItems(pagingOptions, jobId);
            if (nonTraneItems.NonTraneItems.Any())
            {
               return this.Ok(nonTraneItems);
            }
            else
            {
               string message = $"Non trane items are not available for job id: {jobId}";
               this.logger.LogInformation(message);
               return this.NoContent();
            }
         }
         else
         {
            string errorMessage = $"Invalid Request. Job id '{jobId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }
      }

      /// <summary>
      /// Create non trane item for a job
      /// </summary>
      /// <param name="request">Non trane item request payload</param>
      /// <returns>Created status with variation id</returns>
      [HttpPost]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> CreateNonTraneItem([FromBody]NonTraneItemViewModel request)
      {
         string errorMessage;
         if (request != null)
         {
            // Create a non trane item
            var createNonTraneItemCommand = new CreateNonTraneItemCommand(request);
            int commandResult = await this.mediator.Send(createNonTraneItemCommand);

            // Check if the command has returned valid variation id(Inserted data in database)
            if (commandResult > 0)
            {
               this.logger.LogTrace("Non trane item created successfully");
               return this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Unexpected error occurred while create non trane item for job id:{request.JobId}";
            }
         }
         else
         {
            errorMessage = "Invalid request for create non trane item, please check the request parameter";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Update non trane item for a job
      /// </summary>
      /// <param name="jsonPatchDocument">Patch payload for update non trane item</param>
      /// <returns>Patch update status</returns>
      [HttpPatch]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> UpdateNonTraneaItemAsync([FromBody]JsonPatchDocument jsonPatchDocument)
      {
         string errorMessage;
         if (jsonPatchDocument != null)
         {
            bool isUpdated = await this.nonTraneItemService.UpdateNonTraneItem(jsonPatchDocument);
            if (isUpdated)
            {
               this.logger.LogTrace("Non trane item updated successfully");
               return this.Ok();
            }

            errorMessage = "Error occurred while updating non trane item";
         }
         else
         {
            errorMessage = "Invalid request for update non trane item, please check the request parameter";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Get non trane item based on job id and variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Non trane item based on job id and variation id</returns>
      [Route("{variationId}")]
      [HttpGet]
      [ProducesResponseType(typeof(NonTraneItemViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetNonTraneItem(int variationId, int jobId)
      {
         if (jobId > 0 && variationId > 0)
         {
            NonTraneItemViewModel nonTraneItem = await this.nonTraneItemService.GetNonTraneItem(variationId, jobId);
            if (nonTraneItem != null)
            {
                return this.Ok(nonTraneItem);
            }

            string message = $"Non trane item is not available for job id: {jobId}";
            this.logger.LogError(message);
            return this.NoContent();
         }

         string errorMessage = $"Invalid Request. Job id '{jobId}' or Variation id '{variationId}' is not valid";
         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Delete non trane item based on variation id
      /// </summary>
      /// <param name="variationId">Variation id</param>
      /// <returns>Deleted status</returns>
      [Route("{variationId}")]
      [HttpDelete]
      [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> DeleteNonTraneItem(int variationId)
      {
         string errorMessage;
         var removeNonTraneItemCommand = new DeleteNonTraneItemCommand(variationId);
         int isRecordDeleted = await this.mediator.Send(removeNonTraneItemCommand);
         if (isRecordDeleted == 1)
         {
            this.logger.LogTrace("Non trane item deleted successfully");
            return this.Ok(isRecordDeleted);
         }

         errorMessage = $"Unexpected error occurred while deleting non trane item for variation id:{variationId}";
         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }
   }
}
