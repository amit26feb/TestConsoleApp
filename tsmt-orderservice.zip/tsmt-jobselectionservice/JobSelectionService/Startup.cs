// <copyright file="Startup.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Reflection;
   using App.Metrics;
   using Autofac;
   using Autofac.Extensions.DependencyInjection;
   using AutoMapper;
   using JobSelectionService.Common.Configurations.AutofacModules;
   using JobSelectionService.Common.Filters;
   using JobSelectionService.Common.Middlewares;
   using JobSelectionService.Configurations.AutoMapperConfiguration;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Builder;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.AspNetCore.Mvc.Authorization;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.Extensions.Hosting;
   using Microsoft.Extensions.Logging;
   using Microsoft.OpenApi.Models;
   using NLog.Web;
   using Okta.AspNetCore;
   using TraneSalesTools.Middlewares;
   using TSMT.Settings;

   /// <summary>
   /// Startup
   /// </summary>
   public class Startup
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="Startup"/> class.
      /// </summary>
      /// <param name="configuration">configuration</param>
      /// <param name="env">Web host environment</param>
      /// <param name="loggerFactory">loggerFactory</param>
      public Startup(IConfiguration configuration, IWebHostEnvironment env, ILoggerFactory loggerFactory)
      {
         this.Configuration = configuration;
         this.HostingEnvironment = env;
         NLogBuilder.ConfigureNLog($"nlog.{env.EnvironmentName}.config");
      }

      /// <summary>
      /// Gets Configuration
      /// </summary>
      public IConfiguration Configuration { get; }

      /// <summary>
      /// Gets the web host Environment.
      /// </summary>
      public IWebHostEnvironment HostingEnvironment { get; }

      // This method gets called by the runtime. Use this method to add services to the container.

      /// <summary>
      /// Initializes a new instance of the <see cref="IServiceProvider"/> class.
      /// </summary>
      /// <param name="services">configuration</param>
      /// <returns>Config</returns>
      public IServiceProvider ConfigureServices(IServiceCollection services)
      {
         var metrics = AppMetrics.CreateDefaultBuilder()

                     .Configuration.Configure(
                         options =>
                         {
                            options.AddEnvTag(this.HostingEnvironment.EnvironmentName);
                         })
                       .Report.ToInfluxDb(options =>
                       {
                          options.InfluxDb.BaseUri = new Uri(this.Configuration["InfluxDbUrl"]);
                          options.InfluxDb.Database = this.Configuration["InfluxDb"];
                          options.InfluxDb.UserName = this.Configuration["InfluxDbUserName"];
                          options.InfluxDb.Password = this.Configuration["InfluxDbPassword"];
                          options.InfluxDb.CreateDataBaseIfNotExists = true;
                       }).Build();

         services.AddMetrics(metrics);
         services.AddMetricsReportingHostedService();
         services.AddMetricsEndpoints();
         services.AddMetricsTrackingMiddleware();

         // Add framework services.
         services.AddMvc(options =>
         {
            options.Filters.Add(typeof(HttpGlobalExceptionFilter));
            AuthorizationPolicy policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
            options.Filters.Add(new AuthorizeFilter(policy));
         }).AddControllersAsServices().AddMetrics().AddNewtonsoftJson();

         services.AddMvcCore(options =>
         {
            options.Filters.Add(typeof(HttpGlobalExceptionFilter));
         }).AddControllersAsServices();

         services.Configure<TSMTSettings>(this.Configuration);
         services.Configure<JobSelectionService.Configurations.CommonConfigurationSettings>(this.Configuration);

         services.AddSwaggerGen(options =>
         {
#pragma warning disable SA1118 // Parameter must not span multiple lines
            options.SwaggerDoc("v1", new OpenApiInfo
            {
               Title = "JobSelection Service HTTP API",
               Version = "v1",
               Description = "The JobSelection Service HTTP API"
            });
            OpenApiSecurityScheme apiKeyScheme = new OpenApiSecurityScheme()
            {
               Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
               Name = "Authorization",
               In = ParameterLocation.Header,
               Type = SecuritySchemeType.ApiKey,
               Scheme = "Bearer",
               BearerFormat = "JWT"
            };
            options.AddSecurityDefinition("Bearer", apiKeyScheme);
            options.AddSecurityRequirement(new OpenApiSecurityRequirement()
            {
               {
                  new OpenApiSecurityScheme
                  {
                     Reference = new OpenApiReference
                     {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer",
                     },
                     Scheme = "OAuth2",
                     Name = "Bearer",
                     In = ParameterLocation.Header
                  }, new List<string>()
               }
            });
            //// Set the comments path for the Swagger JSON and UI.
            var xmlFile = $"{Assembly.GetEntryAssembly().GetName().Name}.xml";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            options.IncludeXmlComments(xmlPath);
         });

         services.AddAuthentication(options =>
         {
            options.DefaultAuthenticateScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultChallengeScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultSignInScheme = OktaDefaults.ApiAuthenticationScheme;
         })
         .AddOktaWebApi(new OktaWebApiOptions()
         {
            OktaDomain = this.Configuration["OktaDomain"],
            AuthorizationServerId = this.Configuration["OktaAuthorizationServerID"]
         });

         services.AddCors(options =>
         {
            options.AddPolicy(
                   "CorsPolicy",
                   builder => builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader());
         });

         services.AddApiVersioning();

         services.AddOptions();

         services.AddAutoMapper(typeof(AutoMapperProfile));

         // configure autofac
         var container = new ContainerBuilder();
         container.Populate(services);

         // The mediator module uses the pipeline, notification and Request/Response Command handler
         // This is stored as a separate Module
         container.RegisterModule(new MediatorModule());

         return new AutofacServiceProvider(container.Build());
      }

      /// <summary>
      /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
      /// </summary>
      /// <param name="app">application builder</param>
      /// <param name="env">Web host environment</param>
      public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
      {
         string live = "/liveness";
         var pathBase = this.Configuration["PATH_BASE"];

         if (!string.IsNullOrEmpty(pathBase))
         {
            app.UsePathBase(pathBase);
         }

         app.UseLogger();
         app.UseMetricsAllMiddleware();
         app.UseMetricsAllEndpoints();
         app.UseRouting();
         app.UseCors("CorsPolicy");
         app.UseAuthentication();
         app.UseAuthorization();
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseDrAddressIdResolver();
         });
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseVPDAuthenticator();
         });

#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
         app.Map(live, lapp => lapp.Run(async ctx => ctx.Response.StatusCode = 200));
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously

         app.UseEndpoints(endpoints =>
         {
            endpoints.MapControllers();
         });

         app.UseSwagger()
            .UseSwaggerUI(c =>
            {
               c.SwaggerEndpoint($"{(!string.IsNullOrEmpty(pathBase) ? pathBase : string.Empty)}/swagger/v1/swagger.json", "JobSelectionService.API V1");
            });
      }
   }
}
