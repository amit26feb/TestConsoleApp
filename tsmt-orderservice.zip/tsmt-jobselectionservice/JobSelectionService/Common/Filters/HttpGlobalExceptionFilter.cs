﻿// <copyright file="HttpGlobalExceptionFilter.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Common.Filters
{
    using System.Linq;
    using System.Net;
    using FluentValidation;
    using JobSelectionService.Common.ActionResults;
    using JobSelectionService.Common.Exceptions;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Http Global Exception Filter
    /// </summary>
    public class HttpGlobalExceptionFilter : IExceptionFilter
    {
        /// <summary>
        /// IWebHost Environment
        /// </summary>
        private readonly IWebHostEnvironment env;

        /// <summary>
        /// Http Global Exception Filter logger
        /// </summary>
        private readonly ILogger<HttpGlobalExceptionFilter> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpGlobalExceptionFilter"/> class.
        /// </summary>
        /// <param name="env">Environment details</param>
        /// <param name="logger">Logger details</param>
        public HttpGlobalExceptionFilter(IWebHostEnvironment env, ILogger<HttpGlobalExceptionFilter> logger)
        {
            this.env = env;
            this.logger = logger;
        }

        /// <summary>
        /// On Exception
        /// </summary>
        /// <param name="context">Exception Context</param>
        public void OnException(ExceptionContext context)
        {
            this.logger.LogError(context.Exception.ToString());

            if (context.Exception.GetType() == typeof(JobSelectionServiceDomainException))
            {
                var data = context.Exception.InnerException != null ? ((ValidationException)context.Exception.InnerException).Errors.Select(x => x.ErrorMessage).Distinct() : null;

                var json = new JsonErrorResponse
                {
                    Messages = data != null && data.Any() ? data.ToArray() : new[] { context.Exception.Message }
                };
                context.Result = new BadRequestObjectResult(json);
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
            }
            else
            {
                var json = new JsonErrorResponse
                {
                    Messages = new[] { "An error occured.Try it again." }
                };

                if (this.env.IsDevelopment())
                {
                    json.DeveloperMessage = context.Exception;
                }

                context.Result = new InternalServerErrorObjectResult(json);
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }

            context.ExceptionHandled = true;
        }
    }
}
