﻿// <copyright file="JobSelectionServiceDomainException.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Common.Exceptions
{
    using System;
    using System.Runtime.Serialization;

    /// <summary>
    /// Exception type for app exceptions
    /// </summary>
    [Serializable]
    public class JobSelectionServiceDomainException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="JobSelectionServiceDomainException"/> class.
        /// </summary>
        public JobSelectionServiceDomainException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="JobSelectionServiceDomainException"/> class.
        /// </summary>
        /// <param name="message">message</param>
        public JobSelectionServiceDomainException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="JobSelectionServiceDomainException"/> class.
        /// </summary>
        /// <param name="message">Message detatails</param>
        /// <param name="innerException">inner exception</param>
        public JobSelectionServiceDomainException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="JobSelectionServiceDomainException"/> class.
        /// </summary>
        /// <param name="info">The serialization info</param>
        /// <param name="context">The streaming context</param>
        protected JobSelectionServiceDomainException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}