﻿// <copyright file="LoggerMiddleware.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Common.Middlewares
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Logger middleware
    /// </summary>
    public class LoggerMiddleware
    {
        /// <summary>
        /// logger middleware
        /// </summary>
        private readonly ILogger<LoggerMiddleware> logger;

        /// <summary>
        /// Request delegate
        /// </summary>
        private readonly RequestDelegate next;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggerMiddleware"/> class.
        /// Logger middleware
        /// </summary>
        /// <param name="next">next</param>
        /// <param name="logger">Logger Middleware</param>
        public LoggerMiddleware(RequestDelegate next, ILogger<LoggerMiddleware> logger)
        {
            this.next = next;
            this.logger = logger;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Invoke"/> class.
        /// </summary>
        /// <param name="context">context</param>
        /// <returns>asyn Task</returns>
        public async Task Invoke(HttpContext context)
        {
            // Get the Query string and request form data.
            string requestQueryStrings = context.Request.QueryString.ToString();
            string requestBody = await this.FormatRequest(context.Request);

            var originalBodyStream = context.Response.Body;

            using (var responseBody = new MemoryStream())
            {
                context.Response.Body = responseBody;

                await this.next(context);

                // Form the request - response log message
                string userName = context.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value;
                string responseBodyMessage = await this.FormatResponse(context.Response);
                var statusCode = $"Status Code: {context.Response.StatusCode}";

                // No need to log the request and response if the status code is 200 and 204.
                if (context.Response.StatusCode == StatusCodes.Status200OK || context.Response.StatusCode == StatusCodes.Status204NoContent)
                {
                    responseBodyMessage = string.Empty;
                    requestBody = string.Empty;
                }

                var logMessage = $"User: {userName}|QueryStrings: {requestQueryStrings}|Request Body: {requestBody}|{statusCode}|ResponseMessage: {responseBodyMessage}";
                this.logger.LogInformation(logMessage);

                await responseBody.CopyToAsync(originalBodyStream);
            }
        }

        /// <summary>
        /// Format Request
        /// </summary>
        /// <param name="request">http request</param>
        /// <returns>Formatted Request</returns>
        private async Task<string> FormatRequest(HttpRequest request)
        {
            request.EnableBuffering();
            var body = request.Body;
            request.EnableBuffering();

            var buffer = new byte[Convert.ToInt32(request.ContentLength)];
            await request.Body.ReadAsync(buffer, 0, buffer.Length);
            var bodyAsText = Encoding.UTF8.GetString(buffer);
            body.Seek(0, SeekOrigin.Begin);
            request.Body = body;

            return $"{bodyAsText}";
        }

        /// <summary>
        /// Format Response
        /// </summary>
        /// <param name="response">http response</param>
        /// <returns>Formatted response</returns>
        private async Task<string> FormatResponse(HttpResponse response)
        {
            response.Body.Seek(0, SeekOrigin.Begin);
            var text = await new StreamReader(response.Body).ReadToEndAsync();
            response.Body.Seek(0, SeekOrigin.Begin);

            return $"Response {text}";
        }
    }
}
