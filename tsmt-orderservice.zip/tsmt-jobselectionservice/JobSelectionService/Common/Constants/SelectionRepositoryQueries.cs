﻿// <copyright file="SelectionRepositoryQueries.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Common
{
   /// <summary>
   /// Constant file for selection repository queries
   /// </summary>
   public static class SelectionRepositoryQueries
   {
      /// <summary>
      /// Query to get selection details
      /// </summary>
      public const string SelectionDetailsQuery = @"SELECT DISTINCT PF.DESCRIPTION,
                                                                      JPX.CJ_SHIP_QTR,
                                                                      JPX.CJ_SHIP_YEAR,
                                                                      JPX.CJ_COMPETITOR,
                                                                      JPX.CJ_SPECIFIED,
                                                                      S.SELECTION_ID,
                                                                      S.PRICE_CONTROL_ID,
                                                                      S.PROD_FAMILY_ID,
                                                                      S.SEL_PRICE_COMPLETE,
                                                                      S.SELECTION_SOURCE
                                                      FROM JOB_PROD_XREF JPX
                                                      INNER JOIN PROD_FAMILY PF ON JPX.PROD_FAMILY_ID = PF.PROD_FAMILY_ID
                                                      AND JPX.JOB_ID = :JOB_ID
                                                      INNER JOIN SELECTION S ON S.PROD_FAMILY_ID = JPX.PROD_FAMILY_ID
                                                      WHERE S.JOB_ID = :JOB_ID
                                                        AND S.SELECTION_ID IN :SELECTION_ID_LIST";

      /// <summary>
      /// Query to get selection count
      /// </summary>
      public const string SelectionCountQuery = @"SELECT Count(SELECTION_ID) 
                                                      FROM   SELECTION 
                                                      WHERE  JOB_ID = :JOB_ID";

      /// <summary>
      /// Check if the product family does have a ship cycle vpc available
      /// If the sum = 0 (1 row returned) then the selection does NOT have a Ship Cycle vpc available
      /// If the sum is blank (no row returned) then the selection does have a Ship Cycle vpc available.
      /// </summary>
      public const string ShipCycleVpcAvailable = @"SELECT PF.PROD_FAMILY_ID
                                     FROM PROD_FAMILY PF,
                                          PROD_MODULE PM,
                                          VPC V
                                     WHERE PF.PROD_FAMILY_ID = PM.PROD_FAMILY_ID
                                       AND PM.PROD_MODULE_ID = V.PROD_MODULE_ID
                                       AND PF.PROD_FAMILY_ID IN :PROD_FAMILY_ID
                                     GROUP BY PF.PROD_FAMILY_ID,
                                              PF.BU_MFG_LOC_ID
                                     HAVING SUM(V.SHIP_CYCLE_YES_NO_FLAG) = 0";

      /// <summary>
      /// Check selection has ship cycle vpc
      /// </summary>
      public const string SelectionHasShipCycleVpc = @"SELECT SI.SI_ID, SEL.SELECTION_ID
                                                        FROM SELECTION SEL,
                                                             SELECTED_MODULE SM,
                                                             VPC V,
                                                             SELECTED_ITEM SI
                                                        WHERE SM.SELECTION_ID = SEL.SELECTION_ID
                                                          AND SI.SELECTED_MODULE_ID = SM.SELECTED_MODULE_ID
                                                          AND SI.VPC_ID = V.VPC_ID
                                                          AND V.SHIP_CYCLE_YES_NO_FLAG = 1
                                                          AND SEL.SELECTION_ID IN :SELECTION_ID
                                                          AND SEL.JOB_ID = :JOB_ID";

      /// <summary>
      /// Get selected items
      /// </summary>
      public const string SelectedItemGetQuery = @"SELECT SI.VPC_ID,
                                                                   SI.SOURCE,
                                                                   SI.SI_ID,
                                                                   SI.SELECTED_ITEM_ID,
                                                                   SM.SELECTION_ID,
                                                                   SM.PROD_MODULE_ID,
                                                                   S.SELECTION_SOURCE
                                                   FROM SELECTION S
                                                   JOIN SELECTED_MODULE SM ON S.SELECTION_ID = SM.SELECTION_ID
                                                   JOIN SELECTED_ITEM SI ON SI.SELECTED_MODULE_ID = SM.SELECTED_MODULE_ID
                                                   WHERE SM.SELECTION_ID IN :SELECTION_IDS AND S.JOB_ID = :JOB_ID";

      /// <summary>
      /// Get selections
      /// </summary>
      public const string GetSelectionQuery = @"SELECT MAX(TRIM(SEL.SALESMAN_DESCR)) KEEP (DENSE_RANK FIRST
                                                                                        ORDER BY TRIM(SEL.SALESMAN_DESCR)) AS SALESMAN_DESCR,
                                                    MAX(TRIM(RE_UN.TAG)) KEEP (DENSE_RANK FIRST
                                                                               ORDER BY TRIM(RE_UN.TAG)) AS TAG,
                                                    SEL.SELECTION_ID
                                             FROM REFERENCE_UNIT RE_UN
                                             JOIN SELECTION_XREF SEXREF ON SEXREF.REFERENCE_UNIT_ID = RE_UN.REFERENCE_UNIT_ID
                                             JOIN SELECTION SEL ON SEL.SELECTION_ID = SEXREF.SELECTION_ID
                                             WHERE SEL.SELECTION_ID IN :SELECTION_ID
                                               AND SEL.JOB_ID = :JOB_ID
                                             GROUP BY SEL.SELECTION_ID
                                             ORDER BY SEL.SELECTION_ID ASC";

      /// <summary>
      /// Get bill of materials details
      /// </summary>
      public const string BomQuery = @"SELECT COORDINATION_JOB_BOM
                                       FROM JOB_COORDINATION_HISTORY
                                       WHERE COORDINATION_ID = :COORDINATION_ID";

      /// <summary>
      /// Query to get selection performance details
      /// </summary>
      public const string SelectionPerformanceGetQuery = @"SELECT DISTINCT SP.VPFC_ID,
                                                                           S.SELECTION_ID,
                                                                           SP.SOURCE,
                                                                           S.PROD_FAMILY_ID,
                                                                           S.SELECTION_SOURCE,
                                                                           S.LEGACY_ORD_NBR, 
                                                                           S.SALESMAN_DESCR, 
                                                                           RU.TAG, 
                                                                           RU.ORD_LINE_NBR, 
                                                                           RU.SALES_ORD_ID, 
                                                                           SX.REVISE_DATE 
                                                           FROM SELECTION S
                                                           JOIN SELECTION_XREF SX ON S.SELECTION_ID = SX.SELECTION_ID
                                                           JOIN SELECTED_PERF SP ON SP.SELECTION_XREF_ID = SX.SELECTION_XREF_ID
                                                           JOIN REFERENCE_UNIT RU ON RU.REFERENCE_UNIT_ID = SX.REFERENCE_UNIT_ID ";

      /// <summary>
      /// Condition based on job id column
      /// </summary>
      public const string SelectionPerformanceByJobIdGetQuery = @"WHERE S.JOB_ID = :JOB_ID";

      /// <summary>
      /// Condition based on selection id column
      /// </summary>
      public const string SelectionPerformanceBySelectionIdGetQuery = @"WHERE S.SELECTION_ID IN :SELECTION_IDS";

      /// <summary>
      /// Query to get selections
      /// </summary>
      public const string SelectionsQuery = @"SELECT * 
                                                FROM   ( 
                                                                SELECT   V.*, 
                                                                         Row_number() OVER( ORDER BY  {0} ) AS ROWNUMBER, 
                                                                         Count(1) OVER()                            AS TOTAL_COUNT 
                                                                FROM     ( 
                                                                                SELECT SELECTION_ID, 
                                                                                       SELECTION_SOURCE, 
                                                                                       PROD_CODE, 
                                                                                       SALES_ORD_ID, 
                                                                                       PENDING_ORDER_IND, 
                                                                                       LEGACY_ORD_NBR,
                                                                                       SEL_PRICE_COMPLETE, 
                                                                                       PRICE_CONTROL_ID, 
                                                                                       TAG, 
                                                                                       PROD_FAMILY, 
                                                                                       SALESMAN_DESCR, 
                                                                                       UNIT_QTY, 
                                                                                       REVISE_DATE,
                                                                                       PROD_FAMILY_ID,
                                                                                       ROUND(LIST_PRICE,2) AS LIST_PRICE, 
                                                                                       SEQUENCE_NBR,
                                                                                       ROUND(TOTAL_NET_DOLLARS,2) AS TOTAL_NET_DOLLARS
                                                                                FROM   ( 
                                                                                                  SELECT     S.SELECTION_ID, 
                                                                                                             Trim(BOTH ' ' FROM S.SALESMAN_DESCR) AS SALESMAN_DESCR,
                                                                                                             S.UNIT_QTY, 
                                                                                                             S.REVISE_DATE, 
                                                                                                             S.LEGACY_ORD_NBR, 
                                                                                                             PROD.PROD_FAMILY,
                                                                                                             PROD.PROD_FAMILY_ID,
                                                                                                             S.SELECTION_SOURCE, 
                                                                                                             PPG.PROD_CODE,
                                                                                                             S.SEQUENCE_NBR,
                                                                                                             S.SALES_ORD_ID, 
                                                                                                             S.PENDING_ORDER_IND, 
                                                                                                             S.SEL_PRICE_COMPLETE, 
                                                                                                             S.PRICE_CONTROL_ID, 
                                                                                                             ( 
                                                                                                                    SELECT TAG 
                                                                                                                    FROM   ( 
                                                                                                                                      SELECT     RU.TAG,
                                                                                                                                                 Row_number() OVER( PARTITION BY SX.SELECTION_ID ORDER BY RU.TAG_SEQUENCE_NBR) RM
                                                                                                                                      FROM       SELECTION_XREF SX
                                                                                                                                      INNER JOIN REFERENCE_UNIT RU
                                                                                                                                      ON         SX.REFERENCE_UNIT_ID = RU.REFERENCE_UNIT_ID
                                                                                                                                      WHERE      SX.SELECTION_ID = S.SELECTION_ID)
                                                                                                                    WHERE  RM = 1) AS TAG, ( 
                                                                                                             CASE 
                                                                                                                        WHEN ( 
                                                                                                                                              S.SELECTION_SOURCE = 'C') THEN ( (
                                                                                                                                   CASE Nvl(S.PRICE_CONTROL_ID, -1)
                                                                                                                                              WHEN -1 THEN NULL
                                                                                                                                              ELSE ( S.TOTAL_UNADJUSTED_BASE_PRICE *
                                                                                                                                                         (
                                                                                                                                                                SELECT Nvl(Min(CC.LIST_CONVERSION_MULT), 1)
                                                                                                                                                                FROM   CURRENCY_CONVERSION CC,
                                                                                                                                                                       JOB J
                                                                                                                                                                WHERE  J.JOB_ID = S.JOB_ID
                                                                                                                                                                AND    CC.PROD_FAMILY_ID = S.PROD_FAMILY_ID
                                                                                                                                                                AND    CC.CUST_CHANNEL_ID = J.CUST_CHANNEL_ID))
                                                                                                                                   END )) 
                                                                                                                        ELSE S.TOTAL_UNADJUSTED_BASE_PRICE
                                                                                                             END) AS LIST_PRICE, ( 
                                                                                                             CASE 
                                                                                                                        WHEN ( 
                                                                                                                                              S.SELECTION_SOURCE = 'C') THEN ( (
                                                                                                                                   CASE Nvl(S.PRICE_CONTROL_ID, -1)
                                                                                                                                              WHEN -1 THEN NULL
                                                                                                                                              ELSE ( S.TOTAL_NET_DOLLARS *
                                                                                                                                                         (
                                                                                                                                                                SELECT Nvl(Min(CC.NET_CONVERSION_MULT), 1)
                                                                                                                                                                FROM   CURRENCY_CONVERSION CC,
                                                                                                                                                                       JOB J
                                                                                                                                                                WHERE  J.JOB_ID = S.JOB_ID
                                                                                                                                                                AND    CC.PROD_FAMILY_ID = S.PROD_FAMILY_ID
                                                                                                                                                                AND    CC.CUST_CHANNEL_ID = J.CUST_CHANNEL_ID))
                                                                                                                                   END )) 
                                                                                                                        ELSE S.TOTAL_NET_DOLLARS
                                                                                                             END) AS TOTAL_NET_DOLLARS 
                                                                                                  FROM       SELECTION S 
                                                                                                  INNER JOIN PROD_FAMILY PROD 
                                                                                                  ON         S.PROD_FAMILY_ID = PROD.PROD_FAMILY_ID
                                                                                                  INNER JOIN PROD_PRICING_GRP PPG 
                                                                                                  ON         PROD.PROD_PRICING_GRP_ID = PPG.PROD_PRICING_GRP_ID
                                                                                                  WHERE      S.JOB_ID = :JOB_ID)) V";

      /// <summary>
      /// Query to get net dollar value of selected pricing parm records
      /// </summary>
      public const string SelectedPricingParamQuery = @"SELECT S.SELECTION_ID,
                                                                   SPP.SELECTED_PRICING_PARM_ID,
                                                                   SUM(NVL(SI.NET_PRICE, 0)) AS NET_PRICE
                                                            FROM SELECTION S
                                                            INNER JOIN SELECTED_PRICING_PARM SPP ON S.SELECTION_ID = SPP.SELECTION_ID
                                                            INNER JOIN SELECTED_ITEM SI ON SPP.SELECTED_PRICING_PARM_ID = SI.SELECTED_PRICING_PARM_ID
                                                            WHERE S.JOB_ID = :JOB_ID
                                                            GROUP BY S.SELECTION_ID,
                                                                     SPP.SELECTED_PRICING_PARM_ID
                                                            ORDER  BY S.SELECTION_ID";

      /// <summary>
      /// Query to get selected pricing param records by their Ids
      /// </summary>
      public const string SelectedPricingParmByIdsQuery = @"SELECT SELECTION_ID,
                                                                   SELECTED_PRICING_PARM_ID,
                                                                   QUICK_SHIP_BPAF, 
                                                                   QTY_LPAF, 
                                                                   LIST_CONVERSION_MULT, 
                                                                   AUTH_COMM_RATE, 
                                                                   COST_POINT_COMM_RATE, 
                                                                   COST_POINT_MULTIPLIER, 
                                                                   COMM_OVERAGE_RATIO, 
                                                                   BASE_FREIGHT_RESERVE_RATE,
                                                                   HQTR_SELECTED_PRICING_PARM_ID
                                                            FROM SELECTED_PRICING_PARM 
                                                            WHERE SELECTED_PRICING_PARM_ID IN :SELECTED_PRICING_PARM_IDS";

      /// <summary>
      /// Query to get reference unit details
      /// </summary>
      public const string ReferenceUnitGetQuery = @"SELECT S.SELECTION_ID,
                                                           S.PROD_FAMILY_ID,
                                                           S.SELECTION_SOURCE,
                                                           S.LEGACY_ORD_NBR, 
                                                           S.SALESMAN_DESCR, 
                                                           RU.TAG, 
                                                           RU.ORD_LINE_NBR, 
                                                           RU.SALES_ORD_ID, 
                                                           SX.REVISE_DATE 
                                                    FROM SELECTION S
                                                    JOIN SELECTION_XREF SX ON S.SELECTION_ID = SX.SELECTION_ID
                                                    JOIN REFERENCE_UNIT RU ON RU.REFERENCE_UNIT_ID = SX.REFERENCE_UNIT_ID ";

      /// <summary>
      /// Query to get selections based on job id
      /// </summary>
      public const string GetSelectionsByJobIdQuery = @"SELECT CJ.BID_ALTERNATE_ID,
                                                               S.HQTR_SELECTION_ID,
                                                               S.SELECTION_ID,
                                                               TRIM(BOTH ' ' FROM SALESMAN_DESCR) AS SALESMAN_DESCR,
                                                               S.UNIT_QTY,
                                                               S.SELECTION_SOURCE,
                                                               S.SALES_ORD_ID,
                                                               S.PENDING_ORDER_IND,
                                                               S.SEL_PRICE_COMPLETE,
                                                               S.PRICE_CONTROL_ID,
                                                               S.SEQUENCE_NBR,
                                                               PPG.PROD_CODE,
                                                               PROD.PROD_FAMILY,
                                                               OGC.ORD_GRP_DESCR,
                                                               OGC.ALLOW_NO_PARTIAL_SHIPMENT_IND,
                                                               (SELECT TAG
                                                                FROM   (SELECT RU.TAG,
                                                                               ROW_NUMBER()
                                                                                 OVER(
                                                                                   PARTITION BY SX.SELECTION_ID
                                                                                   ORDER BY RU.TAG_SEQUENCE_NBR) rm
                                                                        FROM   SELECTION_XREF SX
                                                                               INNER JOIN REFERENCE_UNIT RU
                                                                                       ON SX.REFERENCE_UNIT_ID = RU.REFERENCE_UNIT_ID
                                                                        WHERE  SX.SELECTION_ID = S.SELECTION_ID)
                                                                WHERE  RM = 1) AS TAG,
                                                                (SELECT TAG_SEQUENCE_NBR
                                                                FROM   (SELECT RU.TAG_SEQUENCE_NBR,
                                                                               ROW_NUMBER()
                                                                                 OVER(
                                                                                   PARTITION BY SX.SELECTION_ID
                                                                                   ORDER BY RU.TAG_SEQUENCE_NBR) rm
                                                                        FROM   SELECTION_XREF SX
                                                                               INNER JOIN REFERENCE_UNIT RU
                                                                                       ON SX.REFERENCE_UNIT_ID = RU.REFERENCE_UNIT_ID
                                                                        WHERE  SX.SELECTION_ID = S.SELECTION_ID)
                                                                WHERE  RM = 1) AS TAG_SEQUENCE_NBR,
                                                               S.SOURCE,
                                                               S.PROD_FAMILY_ID,
                                                               S.ACTIVE_IN_JOB_YESNO_FLAG,
                                                               S.BOM_REVISE_DATE,
                                                               S.NON_BOM_REVISE_DATE,
                                                               S.LEGACY_ORD_NBR,
                                                               PROD.OP_RULE_ID,
                                                               PROD.ORD_GRP_ID,
                                                               PROD.STATUS1,
                                                               PROD.OE_TAGS_REQUIRED_IND,
                                                               PROD.PERF_CHGS_REQ_TOPSS,
                                                               PROD.PROD
                                                        FROM   SELECTION S
                                                               INNER JOIN PROD_FAMILY PROD
                                                                       ON S.PROD_FAMILY_ID = PROD.PROD_FAMILY_ID
                                                               INNER JOIN PROD_PRICING_GRP PPG
                                                                       ON PROD.PROD_PRICING_GRP_ID = PPG.PROD_PRICING_GRP_ID
                                                               LEFT JOIN SALES_ORDER SO
                                                                      ON SO.SALES_ORD_ID = S.SALES_ORD_ID
                                                                          OR SO.LEGACY_ORD_NBR = S.LEGACY_ORD_NBR
                                                               LEFT JOIN CREDIT_JOB CJ
                                                                      ON SO.CREDIT_JOB_ID = CJ.CREDIT_JOB_ID
                                                               LEFT OUTER JOIN ORDER_GROUPING_CRITERIA OGC
                                                                            ON OGC.ORD_GRP_ID = PROD.ORD_GRP_ID
                                                        WHERE  S.JOB_ID = :JOB_ID
                                                        ORDER  BY S.SELECTION_ID";

      /// <summary>
      /// Query to get ship cycle information
      /// </summary>
      public const string ShipCycleGetQuery = @"SELECT S.SI_TYPE,
                                                       U.UOM,
                                                       S.SI_ID,
                                                       SSC.SHIP_CYCLE_LENGTH,
                                                       SM.SELECTION_ID,
                                                       V.VPC_ID
                                                FROM SI S,
                                                     SI_SHIP_CYCLE SSC,
                                                     SELECTED_ITEM SI,
                                                     SELECTED_MODULE SM,
                                                     UOM U,
                                                     VPC V
                                                WHERE SM.SELECTION_ID IN :SELECTION_IDS
                                                  AND SI.SELECTED_MODULE_ID = SM.SELECTED_MODULE_ID
                                                  AND SI.VPC_ID = V.VPC_ID
                                                  AND V.SHIP_CYCLE_YES_NO_FLAG = 1
                                                  AND S.SI_ID = SI.SI_ID
                                                  AND SSC.SI_ID = S.SI_ID
                                                  AND U.UOM_ID = SSC.UOM_ID";
   }
}