﻿// <copyright file="NonTraneItemRepositoryQueries.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Common.Constants
{
   /// <summary>
   /// Constant file for non trane item repository
   /// </summary>
   public static class NonTraneItemRepositoryQueries
   {
      /// <summary>
      /// Query to get non trane items
      /// </summary>
      public const string GetNonTraneItemsQuery = @"SELECT * 
                                                      FROM   ( 
                                                                      SELECT   v.*, 
                                                                               Row_number() OVER( ORDER BY variation_type ) RowNumber, 
                                                                               Count(1) OVER() AS TOTAL_COUNT 
                                                                      FROM     ( 
                                                                                         SELECT       V.variation_id, 
                                                                                                      v.selection_id,
                                                                                                      V.variation_type, 
                                                                                                      V.job_id, 
                                                                                                      V.short_desc, 
                                                                                                      V.provider_name,                                                                       
                                                                                                      V.matl_qty, 
                                                                                                      V.vendor_lead_time_days, 
                                                                                                      V.matl_extended_cost, 
                                                                                                      V.matl_markup_multiplier, 
                                                                                                      V.net_price, 
                                                                                                      V.variation_prod_code, 
                                                                                                      V.sales_ord_id, 
                                                                                                      V.pending_order_ind,   
                                                                                                      V.strategic_provider,
                                                                                                      V.prod_code,
                                                                                                      BVP.product_name,
                                                                                                      (SELECT Count(1) 
                                                                                                       FROM   variation 
                                                                                                       WHERE  job_id = :JOB_ID 
                                                                                                              AND variation_type = 'M' AND selection_id IS NULL) AS MATERIAL_COUNT, 
                                                                                                      (SELECT Count(1) 
                                                                                                       FROM   variation 
                                                                                                       WHERE  job_id = :JOB_ID 
                                                                                                              AND variation_type = 'L' AND selection_id IS NULL) AS LABOR_COUNT, 
                                                                                                      (SELECT Count(1) 
                                                                                                       FROM   variation 
                                                                                                       WHERE  job_id = :JOB_ID 
                                                                                                              AND variation_type = 'F' AND selection_id IS NULL) AS FACILITATIONFEE_COUNT,
                                                                                                       (CASE 
                                                                                                       WHEN (V.equipment_name is Null) THEN BVP.product_name 
                                                                                                       ELSE V.equipment_name 
                                                                                                       END) As equipment_name,

                                                                                                       (CASE  
                                                                                                       WHEN (V.variation_type = 'M') THEN BV.vendor_name 
                                                                                                       ELSE V.provider_name 
                                                                                                       END) As vendor_name

                                                                                               FROM   variation V 
                                                                                                      LEFT JOIN br_vendor BV 
                                                                                                             ON V.vendor_id = BV.vendor_id 
                                                                                                      LEFT JOIN br_vendor_product BVP 
                                                                                                             ON V.product_id = BVP.product_id where V.job_id = :JOB_ID 
                                                                                                                                    AND V.selection_id IS NULL ) V";

      /// <summary>
      /// Query to get variation detail for non trane item
      /// </summary>
      public const string GetVariationDetailWithCostForecastQuery = @"SELECT V.VARIATION_ID, 
                                                                               V.VARIATION_TYPE, 
                                                                               V.JOB_ID, 
                                                                               V.PROD_CODE,
                                                                               V.EQUIPMENT_NAME,
                                                                               V.SHORT_DESC, 
                                                                               V.PROVIDER_NAME, 
                                                                               V.PRODUCT_ID,
                                                                               V.VENDOR_ID, 
                                                                               V.VENDOR_LEAD_TIME_DAYS,
                                                                               V.MATL_QTY, 
                                                                               V.MATL_EXTENDED_COST, 
                                                                               V.MATL_MARKUP_MULTIPLIER, 
                                                                               V.NET_PRICE, 
                                                                               V.VARIATION_PROD_CODE,
                                                                               V.STRATEGIC_PROVIDER,
                                                                               V.COST_CATEGORY,
                                                                               VC.COST_FORECAST,
                                                                               VC.IS_ORACLE
                                                                        FROM   VARIATION V
                                                                        LEFT JOIN VARIATION_COMPANION VC
                                                                        ON V.VARIATION_ID = VC.VARIATION_ID
                                                                        WHERE  V.JOB_ID = :JOB_ID 
                                                                               AND V.VARIATION_ID = :VARIATION_ID";

      /// <summary>
      /// Query to get variation detail for non trane item
      /// </summary>
      public const string GetVariationDetailQuery = @"SELECT VARIATION_ID, 
                                                             VARIATION_TYPE, 
                                                             JOB_ID, 
                                                             PROD_CODE,
                                                             EQUIPMENT_NAME,
                                                             SHORT_DESC, 
                                                             PROVIDER_NAME, 
                                                             PRODUCT_ID,
                                                             VENDOR_ID, 
                                                             VENDOR_LEAD_TIME_DAYS,
                                                             MATL_QTY, 
                                                             MATL_EXTENDED_COST, 
                                                             MATL_MARKUP_MULTIPLIER, 
                                                             NET_PRICE, 
                                                             VARIATION_PROD_CODE,
                                                             STRATEGIC_PROVIDER,
                                                             COST_CATEGORY
                                                      FROM   VARIATION
                                                      WHERE  JOB_ID = :JOB_ID 
                                                             AND VARIATION_ID = :VARIATION_ID";

      /// <summary>
      /// Query to get tag detail for non trane item
      /// </summary>
      public const string GetTagDetailQuery = @"SELECT REFERENCE_UNIT_ID, 
                                                       TAG_SEQUENCE_NBR, 
                                                       TAG 
                                                FROM   REFERENCE_UNIT 
                                                WHERE  JOB_ID = : JOB_ID 
                                                       AND VARIATION_ID = : VARIATION_ID 
                                                ORDER  BY TAG_SEQUENCE_NBR";

      /// <summary>
      ///  Query to get sequence number from package
      /// </summary>
      public const string GetSequenceNumberQuery = @"SELECT PKG_SEQUENCE_NUMBER.GET_NEXT_SEQUENCE(:TABLENAME, :HOW_MANY_TO_RESERVE) 
                                                     FROM DUAL";

      /// <summary>
      ///  Query to create non trane item
      /// </summary>
      public const string CreateNonTraneItemQuery = @"INSERT INTO VARIATION 
                                                                     (VARIATION_ID, 
                                                                      JOB_ID, 
                                                                      VARIATION_TYPE, 
                                                                      PROD_CODE, 
                                                                      SHORT_DESC, 
                                                                      VENDOR_ID, 
                                                                      PROVIDER_NAME, 
                                                                      EQUIPMENT_NAME, 
                                                                      PRODUCT_ID, 
                                                                      MATL_QTY, 
                                                                      MATL_EXTENDED_COST, 
                                                                      MATL_MARKUP_MULTIPLIER, 
                                                                      NET_PRICE, 
                                                                      VENDOR_LEAD_TIME_DAYS,
                                                                      VARIATION_PROD_CODE,
                                                                      COST_CATEGORY,
                                                                      STRATEGIC_PROVIDER) 
                                                         VALUES      (:VARIATION_ID, 
                                                                      :JOB_ID, 
                                                                      :VARIATION_TYPE, 
                                                                      :PROD_CODE, 
                                                                      :short_desc, 
                                                                      :VENDOR_ID, 
                                                                      :PROVIDER_NAME, 
                                                                      :EQUIPMENT_NAME, 
                                                                      :PRODUCT_ID, 
                                                                      :MATL_QTY, 
                                                                      :MATL_EXTENDED_COST, 
                                                                      :MATL_MARKUP_MULTIPLIER, 
                                                                      :NET_PRICE, 
                                                                      :VENDOR_LEAD_TIME_DAYS,
                                                                      :VARIATION_PROD_CODE,
                                                                      :COST_CATEGORY,
                                                                      :STRATEGIC_PROVIDER)";

      /// <summary>
      ///  Query to insert into Variation_companion
      /// </summary>
      public const string CreateVariationCompanionQuery = @"INSERT INTO VARIATION_COMPANION 
                                                                     (VARIATION_ID, 
                                                                      COST_FORECAST,
                                                                      IS_ORACLE)
                                                         VALUES      (:VARIATION_ID, 
                                                                      :COST_FORECAST,
                                                                      :IS_ORACLE)";

      /// <summary>
      ///  Query to delete variation detail for non trane item
      /// </summary>
      public const string VariationDetailDeleteQuery = @"DELETE FROM VARIATION WHERE VARIATION_ID = :VARIATION_ID";

      /// <summary>
      ///  Query to delete tag detail for non trane item
      /// </summary>
      public const string TagDetailDeleteQuery = @"DELETE FROM REFERENCE_UNIT WHERE VARIATION_ID = :VARIATION_ID";

      /// <summary>
      /// Query to insert record in reference unit table
      /// </summary>
      public const string ReferenceUnitInsertQuery = @"INSERT INTO REFERENCE_UNIT 
                                                                     (REFERENCE_UNIT_ID,                                                                       
                                                                      JOB_ID, 
                                                                      TAG_SEQUENCE_NBR,
                                                                      TAG,
                                                                      VARIATION_ID) 
                                                        VALUES      ( :REFERENCE_UNIT_ID,                                                                       
                                                                      :JOB_ID, 
                                                                      :TAG_SEQUENCE_NBR,
                                                                      :TAG,
                                                                      :VARIATION_ID)";

      /// <summary>
      /// Query to delete record from refernce unit table
      /// </summary>
      public const string ReferenceUnitDeleteQuery = @"DELETE FROM REFERENCE_UNIT WHERE REFERENCE_UNIT_ID = :REFERENCE_UNIT_ID";

      /// <summary>
      /// Query to get document details
      /// </summary>
      public const string GetDocumentDetailQuery = @"SELECT JD.DOCUMENT_KEY, 
                                                             JD.DOCUMENT_NAME, 
                                                             JD.DOCUMENT_VERSION,
                                                             JD.JOB_DOCUMENT_TYPE_ID  
                                                      FROM   SO.JOB_DOCUMENT_FOLDER JDF 
                                                             JOIN SO.JOB_DOCUMENT JD 
                                                                    ON JDF.FOLDER_ID = JD.FOLDER_ID 
                                                                       AND JDF.JOB_ID = JD.JOB_ID 
                                                      WHERE  JDF.FOLDER_NAME = :FOLDER_NAME 
                                                             AND JDF.JOB_ID = :JOB_ID 
                                                             AND JDF.JOB_FOLDER_TYPE_ID = :JOB_FOLDER_TYPE_ID";

      /// <summary>
      /// Query to get non trane items variation companion query
      /// </summary>
      public const string GetNonTraneItemsVariationCompanionQuery = @"SELECT *
                                                                      FROM (
                                                                        SELECT v.*,
                                                                               Row_number() OVER(
                                                                                                 ORDER BY variation_type) RowNumber,
                                                                                            Count(1) OVER() AS TOTAL_COUNT
                                                                        FROM
                                                                          (SELECT V.variation_id,
                                                                                  v.selection_id,
                                                                                  V.variation_type,
                                                                                  V.job_id,
                                                                                  V.short_desc,
                                                                                  V.provider_name,
                                                                                  V.matl_qty,
                                                                                  V.vendor_lead_time_days,
                                                                                  V.matl_extended_cost,
                                                                                  V.matl_markup_multiplier,
                                                                                  V.net_price,
                                                                                  V.variation_prod_code,
                                                                                  V.sales_ord_id,
                                                                                  V.pending_order_ind,
                                                                                  V.strategic_provider,
                                                                                  V.prod_code,
                                                                                  VC.cost_forecast,
                                                                                  VC.cost_estimate,
                                                                                  VC.is_oracle,
                                                                                  BVP.product_name,

                                                                             (SELECT Count(1)
                                                                              FROM variation
                                                                              WHERE job_id = :JOB_ID
                                                                                AND variation_type = 'M'
                                                                                AND selection_id IS NULL) AS MATERIAL_COUNT,

                                                                             (SELECT Count(1)
                                                                              FROM variation
                                                                              WHERE job_id = :JOB_ID
                                                                                AND variation_type = 'L'
                                                                                AND selection_id IS NULL) AS LABOR_COUNT,

                                                                             (SELECT Count(1)
                                                                              FROM variation
                                                                              WHERE job_id = :JOB_ID
                                                                                AND variation_type = 'F'
                                                                                AND selection_id IS NULL) AS FACILITATIONFEE_COUNT,
                                                                                  (CASE
                                                                                       WHEN (V.equipment_name IS NULL) THEN BVP.product_name
                                                                                       ELSE V.equipment_name
                                                                                   END) AS equipment_name,
                                                                                  (CASE
                                                                                       WHEN (V.variation_type = 'M') THEN BV.vendor_name
                                                                                       ELSE V.provider_name
                                                                                   END) AS vendor_name
                                                                           FROM variation V
                                                                           LEFT JOIN variation_companion VC ON V.variation_id = VC.variation_id
                                                                           LEFT JOIN br_vendor BV ON V.vendor_id = BV.vendor_id
                                                                           LEFT JOIN br_vendor_product BVP ON V.product_id = BVP.product_id
                                                                           WHERE V.job_id = :JOB_ID
                                                                             AND V.selection_id IS NULL ) V";
   }
}
