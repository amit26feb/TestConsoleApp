﻿// <copyright file="Constants.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Common.Constants
{
   /// <summary>
   /// Constant file for non trane item
   /// </summary>
   public static class Constants
   {
      /// <summary>
      /// Set variation product code
      /// </summary>
      public const int VariationProductCode = 5119;

      /// <summary>
      /// Invalid request
      /// </summary>
      public const string InvalidRequest = "Invalid request, please check the request parameter";

      /// <summary>
      /// cost forecast
      /// </summary>
      public const string CostForecast = "cost_forecast";

      /// <summary>
      /// Job folder type id for non trane
      /// </summary>
      public const int JobFolderTypeId = 5;
   }
}
