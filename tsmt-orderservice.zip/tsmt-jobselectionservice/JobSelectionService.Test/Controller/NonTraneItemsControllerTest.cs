﻿// <copyright file="NonTraneItemsControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Controller
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using JobSelectionService.Common.Exceptions;
   using JobSelectionService.Controllers;
   using JobSelectionService.Core.Commands;
   using JobSelectionService.Core.Services;
   using JobSelectionService.Core.ViewModels;
   using JobSelectionService.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.JsonPatch;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Newtonsoft.Json;
   using Xunit;

   /// <summary>
   /// Non trane item controller test
   /// </summary>
   public class NonTraneItemsControllerTest
   {
      private readonly Mock<INonTraneItemService> nonTraneItemsMock;
      private readonly Mock<ILogger<NonTraneItemsController>> logger;
      private readonly Mock<IMediator> mediatorMock;
      private readonly NonTraneItemsController nonTraneItemsController;

      public NonTraneItemsControllerTest()
      {
         this.nonTraneItemsMock = new Mock<INonTraneItemService>();
         this.logger = new Mock<ILogger<NonTraneItemsController>>();
         this.mediatorMock = new Mock<IMediator>();
         this.nonTraneItemsController = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);
      }

      [Fact]
      public async Task GetNonTraneItems_ValidRequest_ReturnsOkResponse()
      {
         // Arrange
         int jobId = 56704;
         List<Filter> filters = new List<Filter>
            {
                new Filter()
                {
                    Field = "description",
                    Operator = "contains",
                    Value = "a"
                },
            };

         List<FilterCollectionViewModel> filterCollection = new List<FilterCollectionViewModel>
            {
                new FilterCollectionViewModel()
                {
                    Filters = filters,
                    Logic = "and"
                }
            };

         PagingOptions pagingOptions = new PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = new List<SortViewModel>()
            {
               new SortViewModel()
               {
                  SortBy = "Description",
                  SortDirection = SortDirectionViewModel.Ascending
               }
            },
            Filters = filterCollection
         };
         IEnumerable<JobSelectionService.Core.ViewModels.NonTraneItemViewModel> nonTraneItems = new List<JobSelectionService.Core.ViewModels.NonTraneItemViewModel>
            {
              new JobSelectionService.Core.ViewModels.NonTraneItemViewModel()
              {
               VariationId = 56594,
               JobId = 56704,
               Description = "Curb Adapter",
               ProviderName = "CDI",
               Qty = 1,
               TotalCount = 1
              }
            };
         NonTraneItemPagingResults pagingResult = new NonTraneItemPagingResults()
         {
            PageCount = 1,
            PageNumber = 1,
            PageSize = 1,
            TotalItemCount = 1,
            NonTraneItems = nonTraneItems
         };
         var nonTraneItemsController = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);
         this.nonTraneItemsMock.Setup(x => x.GetNonTraneItems(pagingOptions, jobId)).Returns(Task.FromResult(pagingResult));

         // Act
         var result = await nonTraneItemsController.GetNonTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.nonTraneItemsMock.Verify(x => x.GetNonTraneItems(pagingOptions, jobId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItems_ValidRequest_ReturnsNoContent()
      {
         // Arrange
         int jobId = 56704;
         PagingOptions pagingOptions = new PagingOptions()
         {
            Skip = 10,
            Take = 10
         };
         IEnumerable<JobSelectionService.Core.ViewModels.NonTraneItemViewModel> nonTraneItems = new List<JobSelectionService.Core.ViewModels.NonTraneItemViewModel>();
         NonTraneItemPagingResults pagingResult = new NonTraneItemPagingResults()
         {
            PageCount = 1,
            PageNumber = 1,
            PageSize = 1,
            TotalItemCount = 1,
            NonTraneItems = nonTraneItems
         };
         var nonTraneItemsController = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);
         this.nonTraneItemsMock.Setup(x => x.GetNonTraneItems(pagingOptions, jobId)).Returns(Task.FromResult(pagingResult));

         // Act
         var result = await nonTraneItemsController.GetNonTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.nonTraneItemsMock.Verify(x => x.GetNonTraneItems(pagingOptions, jobId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItems_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         PagingOptions pagingOptions = new PagingOptions()
         {
            Skip = 10,
            Take = 10
         };

         var nonTraneItemsController = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);

         // Act
         var result = await nonTraneItemsController.GetNonTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.nonTraneItemsMock.Verify(x => x.GetNonTraneItems(pagingOptions, jobId), Times.Never);
      }

      [Fact]
      public async Task CreateNonTraneItem_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         int variationId = 1789;
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 12886,
            VariationId = 0,
            Cost = 900,
            Markup = 1,
            Qty = 1,
            SellingPrice = 16609.6M,
            ProviderName = "CDI",
            Description = "Adapter Curb",
            VariationType = "M",
            ProdCode = "0913",
            StrategicProvider = "Y",
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateNonTraneItemCommand>(), default)).Returns(Task.FromResult(variationId));
         var controller = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);

         // Act
         var actionResult = await controller.CreateNonTraneItem(nonTraneItem);

         // Assert
         Assert.Equal(((ObjectResult)actionResult).Value, variationId);
         Assert.IsType<OkObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateNonTraneItemCommand>(), default), Times.Once);
      }

      [Fact]
      public async Task CreateNonTraneItem_NullRequest_ReturnsBadRequest()
      {
         // Arrange
         NonTraneItemViewModel nonTraneItem = null;
         var controller = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);

         // Act
         var actionResult = await controller.CreateNonTraneItem(nonTraneItem);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Contains((((BadRequestObjectResult)actionResult).Value as JsonErrorResponse).Messages, x => x == "Invalid request for create non trane item, please check the request parameter");
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateNonTraneItemCommand>(), default), Times.Never);
      }

      [Fact]
      public async Task CreateNonTraneItem_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int variationId = 0;
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 0,
            VariationType = string.Empty,
            ProdCode = "0913",
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateNonTraneItemCommand>(), default)).Returns(Task.FromResult(variationId));
         var controller = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);

         // Act
         var actionResult = await controller.CreateNonTraneItem(nonTraneItem);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Contains((((BadRequestObjectResult)actionResult).Value as JsonErrorResponse).Messages, x => x == $"Unexpected error occurred while create non trane item for job id:{nonTraneItem.JobId}");
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateNonTraneItemCommand>(), default), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_ValidRequest_ReturnsOkResponse()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         NonTraneItemViewModel nonTraneItem = new NonTraneItemViewModel()
         {
            VariationId = 56594,
            VariationType = "M",
            JobId = 56704,
            Description = "Curb Adapter",
            ProviderName = "CDI",
            Qty = 1,
            TotalCount = 1,
            StrategicProvider = "Y"
         };
         var nonTraneItemsController = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);
         this.nonTraneItemsMock.Setup(x => x.GetNonTraneItem(variationId, jobId)).Returns(Task.FromResult(nonTraneItem));

         // Act
         var result = await nonTraneItemsController.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.nonTraneItemsMock.Verify(x => x.GetNonTraneItem(variationId, jobId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_ValidRequest_ReturnsNoContent()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         NonTraneItemViewModel nonTraneItem = null;

         var nonTraneItemsController = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);
         this.nonTraneItemsMock.Setup(x => x.GetNonTraneItem(variationId, jobId)).Returns(Task.FromResult(nonTraneItem));

         // Act
         var result = await nonTraneItemsController.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.nonTraneItemsMock.Verify(x => x.GetNonTraneItem(variationId, jobId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         int variationId = 56594;

         var nonTraneItemsController = new NonTraneItemsController(this.nonTraneItemsMock.Object, this.logger.Object, this.mediatorMock.Object);

         // Act
         var result = await nonTraneItemsController.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.nonTraneItemsMock.Verify(x => x.GetNonTraneItem(variationId, jobId), Times.Never);
      }

      [Fact]
      public async Task DeleteNonTraneItem_ValidRequest_ReturnsOkResponse()
      {
         // Arrange
         int variationId = 56594;
         int deleteResult = 1;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<DeleteNonTraneItemCommand>(), default)).Returns(Task.FromResult(deleteResult));

         // Act
         var result = await this.nonTraneItemsController.DeleteNonTraneItem(variationId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<DeleteNonTraneItemCommand>(), default), Times.Once);
      }

      [Fact]
      public async Task DeleteNonTraneItem_ValidRequest_ReturnsBadRequest()
      {
         // Arrange
         int variationId = 0;
         int deleteResult = 0;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<DeleteNonTraneItemCommand>(), default)).Returns(Task.FromResult(deleteResult));

         // Act
         var result = await this.nonTraneItemsController.DeleteNonTraneItem(variationId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<DeleteNonTraneItemCommand>(), default), Times.Once);
      }

      [Fact]
      public async Task UpdateNonTraneItem_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         var requestPayload = "[{ \"op\": \"replace\", \"path\": \"/Jobs/40737/Variations/979359\", \"value\": [{ \"Provider_Name\": \"Poolpak\"}]}]";
         var jsonPatchDocument = JsonConvert.DeserializeObject<JsonPatchDocument>(requestPayload);

         this.nonTraneItemsMock.Setup(x => x.UpdateNonTraneItem(jsonPatchDocument)).Returns(Task.FromResult(true));

         // Act
         var actionResult = await this.nonTraneItemsController.UpdateNonTraneaItemAsync(jsonPatchDocument);

         // Assert
         Assert.IsType<OkResult>(actionResult);
         this.nonTraneItemsMock.Verify(x => x.UpdateNonTraneItem(jsonPatchDocument), Times.Once);
      }

      [Fact]
      public async Task UpdateNonTraneItem_NullRequest_ReturnsBadRequest()
      {
         // Arrange
         JsonPatchDocument jsonPatchDocument = null;

         // Act
         var actionResult = await this.nonTraneItemsController.UpdateNonTraneaItemAsync(jsonPatchDocument);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.nonTraneItemsMock.Verify(x => x.UpdateNonTraneItem(jsonPatchDocument), Times.Never);
      }

      [Fact]
      public async Task UpdateNonTraneItem_WhenUpdateFailed_ReturnsBadRequest()
      {
         // Arrange
         var requestPayload = "[{ \"op\": \"replace\", \"path\": \"/Jobs/40737/Variations/979359\", \"value\": [{ \"Provider_Name\": \"Poolpak\"}]}]";
         var jsonPatchDocument = JsonConvert.DeserializeObject<JsonPatchDocument>(requestPayload);

         this.nonTraneItemsMock.Setup(x => x.UpdateNonTraneItem(jsonPatchDocument)).Returns(Task.FromResult(false));

         // Act
         var actionResult = await this.nonTraneItemsController.UpdateNonTraneaItemAsync(jsonPatchDocument);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.nonTraneItemsMock.Verify(x => x.UpdateNonTraneItem(jsonPatchDocument), Times.Once);
      }
   }
}
