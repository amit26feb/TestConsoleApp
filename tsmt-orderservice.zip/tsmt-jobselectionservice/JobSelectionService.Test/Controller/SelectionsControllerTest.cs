﻿// <copyright file="SelectionsControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Controller
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoFixture;
   using JobSelectionService.Common.Constants;
   using JobSelectionService.Common.Exceptions;
   using JobSelectionService.Controllers;
   using JobSelectionService.Core.Services;
   using JobSelectionService.Core.ViewModels;
   using JobSelectionService.Test.Common;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class SelectionsControllerTest
   {
      private readonly Mock<ISelectionService> jobSelectionsMock;
      private readonly Mock<ILogger<SelectionsController>> logger;
      private readonly SelectionsController selectionsController;
      private readonly IEnumerable<int> selectedPricingParamIds;

      public SelectionsControllerTest()
      {
         this.jobSelectionsMock = new Mock<ISelectionService>();
         this.logger = new Mock<ILogger<SelectionsController>>();
         this.selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         this.selectedPricingParamIds = new[] { 8899, 6699 };
      }

      [Fact]
      public async Task GetJobSelections_ValidJobId_ReturnsValidData()
      {
         // Arrange
         int jobId = 11466;
         JobSelectionViewModel viewSelectionViewModel = new JobSelectionViewModel();

         List<SelectionViewModel> selectionList = new List<SelectionViewModel>
         {
            new SelectionViewModel()
            {
               SelectionId = 11
            }
         };
         List<VariationViewModel> variationList = new List<VariationViewModel>
         {
            new VariationViewModel()
            {
               SelectionId = 11,
               Description = "atsc",
               ProductCode = "0913"
            }
         };
         viewSelectionViewModel.SelectionList = selectionList;
         viewSelectionViewModel.JobVariationList = variationList;

         this.jobSelectionsMock.Setup(x => x.GetJobSelections(jobId)).Returns(Task.FromResult(viewSelectionViewModel)).Verifiable();

         // Act
         var jobSelectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         var result = await jobSelectionsController.GetJobSelections(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, viewSelectionViewModel);
         this.jobSelectionsMock.Verify();
      }

      [Fact]
      public async Task GetJobSelections_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;

         // Act
         var jobSelectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         var result = await jobSelectionsController.GetJobSelections(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify();
      }

      [Fact]
      public async Task GetJobSelections_ValidJobId_ReturnsEmptyList()
      {
         // Arrange
         int jobId = 10;
         JobSelectionViewModel selections = null;
         this.jobSelectionsMock.Setup(x => x.GetJobSelections(jobId)).Returns(Task.FromResult(selections)).Verifiable();

         // Act
         var jobSelectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         var result = await jobSelectionsController.GetJobSelections(jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify();
      }

      /// <summary>
      /// Verifies for the ok response when the request is valid and contains selection data
      /// </summary>
      /// <returns>Ok response</returns>
      [Fact]
      public async Task GetSelectionDetails_ValidRequestHasSelectionData_ReturnsOkResponse()
      {
         // Arrange
         int jobId = 10987;
         IEnumerable<int> selectionIds = new List<int>() { 230733, 319529 };
         IEnumerable<SelectionInfoViewModel> selectionDetails = new List<SelectionInfoViewModel>()
         {
            CommonHelper.GetSelectionInfoViewModel()
         };
         this.jobSelectionsMock.Setup(x => x.GetSelectionDetails(jobId, selectionIds)).Returns(Task.FromResult(selectionDetails));
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.GetSelectionDetails(jobId, selectionIds);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, selectionDetails);
         this.jobSelectionsMock.Verify(x => x.GetSelectionDetails(jobId, selectionIds), Times.Once);
      }

      /// <summary>
      /// Verifies for the no content response when the request is valid and contains empty selection data
      /// </summary>
      /// <returns>No content response</returns>
      [Fact]
      public async Task GetSelectionDetails_ValidRequestHasEmptySelectionData_ReturnsNoContentResponse()
      {
         // Arrange
         int jobId = 10984;
         IEnumerable<int> selectionIds = new List<int>() { 2303 };
         IEnumerable<SelectionInfoViewModel> selectionDetails = Enumerable.Empty<SelectionInfoViewModel>();
         this.jobSelectionsMock.Setup(x => x.GetSelectionDetails(jobId, selectionIds)).Returns(Task.FromResult(selectionDetails));
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.GetSelectionDetails(jobId, selectionIds);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectionDetails(jobId, selectionIds), Times.Once);
      }

      /// <summary>
      /// Verifies for the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task GetSelectionDetails_InvalidRequest_ReturnsBadRequestResponse()
      {
         // Arrange
         int jobId = 1097;
         IEnumerable<int> selectionIds = Enumerable.Empty<int>();
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.GetSelectionDetails(jobId, selectionIds);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectionDetails(jobId, selectionIds), Times.Never);
      }

      /// <summary>
      /// Verifies for the ok response when the request is valid
      /// </summary>
      /// <returns>Ok response</returns>
      [Fact]
      public async Task IsSelectionExists_ValidRequest_ReturnsTrue()
      {
         // Arrange
         int jobId = 12678;
         this.jobSelectionsMock.Setup(x => x.IsSelectionExists(It.IsAny<int>())).Returns(Task.FromResult(true)).Verifiable();
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.IsSelectionExists(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.jobSelectionsMock.Verify();
      }

      /// <summary>
      /// Verifies for the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task IsSelectionExists_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.IsSelectionExists(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.IsSelectionExists(jobId), Times.Never);
      }

      /// <summary>
      /// Verifies for the ok response when the request is valid and contains selected item
      /// </summary>
      /// <returns>Ok response</returns>
      [Fact]
      public async Task GetSelectedItems_ValidRequestHasSelectedItem_ReturnsOkResponse()
      {
         // Arrange
         int jobId = 10987;
         IEnumerable<int> selectionIds = new List<int>() { 123, 319529 };
         IEnumerable<SelectionViewModel> selectedItems = new List<SelectionViewModel>()
            {
                CommonHelper.GetSelectionViewModel()
            };
         this.jobSelectionsMock.Setup(x => x.GetSelectedItems(jobId, selectionIds)).Returns(Task.FromResult(selectedItems));

         // Act
         IActionResult result = await this.selectionsController.GetSelectedItems(jobId, selectionIds);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, selectedItems);
         this.jobSelectionsMock.Verify(x => x.GetSelectedItems(jobId, selectionIds), Times.Once);
      }

      /// <summary>
      /// Verifies for the no content response when the request is valid and contains empty selected item
      /// </summary>
      /// <returns>No content response</returns>
      [Fact]
      public async Task GetSelectedItems_ValidRequestHasEmptySelectedItem_ReturnsNoContentResponse()
      {
         // Arrange
         int jobId = 10984;
         IEnumerable<int> selectionIds = new List<int>() { 2303 };
         IEnumerable<SelectionViewModel> selectedItems = Enumerable.Empty<SelectionViewModel>();
         this.jobSelectionsMock.Setup(x => x.GetSelectedItems(jobId, selectionIds)).Returns(Task.FromResult(selectedItems));

         // Act
         IActionResult result = await this.selectionsController.GetSelectedItems(jobId, selectionIds);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectedItems(jobId, selectionIds), Times.Once);
      }

      /// <summary>
      /// Verifies for the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task GetSelectedItems_InvalidRequest_ReturnsBadRequestResponse()
      {
         // Arrange
         int jobId = 0;
         IEnumerable<int> selectionIds = Enumerable.Empty<int>();

         // Act
         IActionResult result = await this.selectionsController.GetSelectedItems(jobId, selectionIds);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectedItems(jobId, selectionIds), Times.Never);
      }

      /// <summary>
      /// Verifies for the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad request</returns>
      [Fact]
      public async Task GetBidsSelections_InvalidRequest_ReturnBadRequest()
      {
         // Arrange
         int jobId = 0;
         int jobCoordinationId = 0;
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.GetBidsSelections(jobId, jobCoordinationId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetBidsSelections(jobId, jobCoordinationId), Times.Never);
      }

      /// <summary>
      /// Verifies for the bad request response when the job id is invalid
      /// </summary>
      /// <returns>Bad request</returns>
      [Fact]
      public async Task GetBidsSelections_InvalidJobId_ReturnBadRequest()
      {
         // Arrange
         int jobId = 0;
         int jobCoordinationId = 123456;
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.GetBidsSelections(jobId, jobCoordinationId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetBidsSelections(jobId, jobCoordinationId), Times.Never);
      }

      /// <summary>
      /// Verifies for the bad request response when the job coordination id is invalid
      /// </summary>
      /// <returns>Bad request</returns>
      [Fact]
      public async Task GetBidsSelections_InvalidJobCoordinationId_ReturnBadRequest()
      {
         // Arrange
         int jobId = 123456;
         int jobCoordinationId = 0;
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.GetBidsSelections(jobId, jobCoordinationId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetBidsSelections(jobId, jobCoordinationId), Times.Never);
      }

      /// <summary>
      /// Verifies for the ok response when the request is valid
      /// </summary>
      /// <returns>Ok Response</returns>
      [Fact]
      public async Task GetBidsSelections_ValidRequest_ReturnsOkResponse()
      {
         // Arrange
         int jobId = 12345;
         int jobCoordinationId = 435456;
         IEnumerable<BidSelectionViewModel> selectionValidations = new List<BidSelectionViewModel>()
         {
            CommonHelper.BidsSelection()
         };
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         this.jobSelectionsMock.Setup(x => x.GetBidsSelections(jobId, jobCoordinationId)).Returns(Task.FromResult(selectionValidations));

         // Act
         var result = await selectionsController.GetBidsSelections(jobId, jobCoordinationId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetBidsSelections(jobId, jobCoordinationId), Times.Once);
      }

      /// <summary>
      /// Verifies for the no content response when the request is valid
      /// </summary>
      /// <returns>No content</returns>
      [Fact]
      public async Task GetBidsSelections_ValidRequest_ReturnsNoContent()
      {
         // Arrange
         int jobId = 12345;
         int jobCoordinationId = 435456;
         IEnumerable<BidSelectionViewModel> selectionValidations = new List<BidSelectionViewModel>();
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         this.jobSelectionsMock.Setup(x => x.GetBidsSelections(jobId, jobCoordinationId)).Returns(Task.FromResult(selectionValidations));

         // Act
         var result = await selectionsController.GetBidsSelections(jobId, jobCoordinationId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetBidsSelections(jobId, jobCoordinationId), Times.Once);
      }

      /// <summary>
      /// Verifies that calling GetSelectionPerformanceDetails with ids and getting results returns them with OK result
      /// </summary>
      /// <returns>Selection performances</returns>
      [Fact]
      public async Task GetSelectionPerformanceDetails_HasData_ReturnsOkResult()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int> { 1246033, 1246021 };
         int jobId = 123;
         Fixture fixture = new Fixture();
         IEnumerable<SelectionViewModel> selectionPerformances = fixture.CreateMany<SelectionViewModel>(2);
         selectionPerformances.ElementAt(0).SelectionId = 1246033;
         selectionPerformances.ElementAt(0).VpfcId = 1246033;

         SelectionsController selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         this.jobSelectionsMock.Setup(x => x.GetSelectionPerformanceDetails(It.IsAny<IEnumerable<int>>(), It.IsAny<int>(), It.IsAny<bool>())).Returns(Task.FromResult(selectionPerformances));

         // Act
         IActionResult actionResult = await selectionsController.GetSelectionPerformanceDetails(selectionIds, jobId, false);

         // Assert
         Assert.Equal(((OkObjectResult)actionResult).Value, selectionPerformances);
         Assert.IsType<OkObjectResult>(actionResult);
         this.jobSelectionsMock.Verify(x => x.GetSelectionPerformanceDetails(selectionIds, jobId, false), Times.Once);
      }

      /// <summary>
      /// Verfies that calling GetSelectionPerformanceDetails with ids but getting no results from service returns no content
      /// </summary>
      /// <returns>No content</returns>
      [Fact]
      public async Task GetSelectionPerformanceDetails_HasNoData_ReturnsNoContent()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int> { 1460, 160 };
         int jobId = 123;
         IEnumerable<SelectionViewModel> selectionPerformances = new List<SelectionViewModel>();
         SelectionsController selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         this.jobSelectionsMock.Setup(s => s.GetSelectionPerformanceDetails(It.IsAny<IEnumerable<int>>(), It.IsAny<int>(), It.IsAny<bool>())).Returns(Task.FromResult(selectionPerformances));

         // Act
         IActionResult result = await selectionsController.GetSelectionPerformanceDetails(selectionIds, jobId, false);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(m => m.GetSelectionPerformanceDetails(selectionIds, jobId, false), Times.Once);
      }

      /// <summary>
      /// Verifies that calling GetSelectionPerformanceDetails with empty ids returns bad request
      /// </summary
      /// <returns>Bad request</returns>
      [Fact]
      public async Task GetSelectionPerformanceDetails_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int>();
         int jobId = 0;

         // Act
         SelectionsController selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         IActionResult result = await selectionsController.GetSelectionPerformanceDetails(selectionIds, jobId, false);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Contains((((ObjectResult)result).Value as JsonErrorResponse).Messages, x => x == Constants.InvalidRequest);
         this.jobSelectionsMock.Verify(m => m.GetSelectionPerformanceDetails(It.IsAny<IEnumerable<int>>(), It.IsAny<int>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verifies for the ok response
      /// </summary>
      /// <returns>Ok Response</returns>
      [Fact]
      public async Task GetTraneItems_ValidRequest_ReturnsOkResponse()
      {
         // Arrange
         int jobId = 12345;
         List<JobSelectionService.Core.ViewModels.SortViewModel> sortAttributes = new List<JobSelectionService.Core.ViewModels.SortViewModel>()
         {
            new JobSelectionService.Core.ViewModels.SortViewModel()
            {
            SortBy = "Qty",
            SortDirection = global::JobSelectionService.Core.ViewModels.SortDirectionViewModel.Ascending
            }
         };
         PagingOptions pagingOptions = new PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = sortAttributes
         };
         IEnumerable<JobSelectionService.Core.ViewModels.SelectionViewModel> selections = new List<JobSelectionService.Core.ViewModels.SelectionViewModel>
            {
              new JobSelectionService.Core.ViewModels.SelectionViewModel()
              {
                SelectionId = 567,
                TotalCount = 1,
                NetPrice = 5678,
                ListPrice = 0,
                ReviseDate = null
              }
            };
         SelectionsPagingResults pagingResult = new SelectionsPagingResults()
         {
            PageCount = 1,
            PageNumber = 1,
            PageSize = 1,
            TotalItemCount = 1,
            SelectionList = selections
         };
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         this.jobSelectionsMock.Setup(x => x.GetTraneItems(pagingOptions, jobId)).Returns(Task.FromResult(pagingResult));

         // Act
         var result = await selectionsController.GetTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetTraneItems(pagingOptions, jobId), Times.Once);
      }

      /// <summary>
      /// Verifies for the no content response
      /// </summary>
      /// <returns>No content</returns>
      [Fact]
      public async Task GetTraneItems_ValidRequest_ReturnsNoContent()
      {
         // Arrange
         int jobId = 12345;
         List<JobSelectionService.Core.ViewModels.SortViewModel> sortAttributes = new List<JobSelectionService.Core.ViewModels.SortViewModel>()
         {
            new JobSelectionService.Core.ViewModels.SortViewModel()
            {
            SortBy = "Qty",
            SortDirection = global::JobSelectionService.Core.ViewModels.SortDirectionViewModel.Ascending
            }
         };
         PagingOptions pagingOptions = new PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = sortAttributes
         };
         IEnumerable<JobSelectionService.Core.ViewModels.SelectionViewModel> selections = new List<SelectionViewModel>();
         SelectionsPagingResults pagingResult = new SelectionsPagingResults()
         {
            PageCount = 0,
            PageNumber = 0,
            PageSize = 0,
            TotalItemCount = 0,
            SelectionList = selections
         };
         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);
         this.jobSelectionsMock.Setup(x => x.GetTraneItems(pagingOptions, jobId)).Returns(Task.FromResult(pagingResult));

         // Act
         var result = await selectionsController.GetTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetTraneItems(pagingOptions, jobId), Times.Once);
      }

      /// <summary>
      /// Verifies for the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad Response</returns>
      [Fact]
      public async Task GetTraneItems_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         List<JobSelectionService.Core.ViewModels.SortViewModel> sortAttributes = new List<JobSelectionService.Core.ViewModels.SortViewModel>()
         {
            new JobSelectionService.Core.ViewModels.SortViewModel()
            {
            SortBy = "Qty",
            SortDirection = global::JobSelectionService.Core.ViewModels.SortDirectionViewModel.Ascending
            }
         };
         PagingOptions pagingOptions = new PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = sortAttributes
         };

         var selectionsController = new SelectionsController(this.jobSelectionsMock.Object, this.logger.Object);

         // Act
         var result = await selectionsController.GetTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetTraneItems(pagingOptions, jobId), Times.Never);
      }

      [Fact]
      public async Task GetSelectedPricingParams_ValidJobId_ReturnsValidData()
      {
         // Arrange
         int jobId = 1234;
         IEnumerable<PricingParamViewModel> pricingParams = new List<PricingParamViewModel>()
         {
            new PricingParamViewModel()
            {
               SelectionId = 556677,
               SelectedPricingParmId = 8899,
               ProductCode = "BK14",
               NetPrice = 4321,
               IsMainUnit = false
            }
         };
         this.jobSelectionsMock.Setup(x => x.GetSelectedPricingParamRecords(jobId)).Returns(Task.FromResult(pricingParams));

         // Act
         var result = await this.selectionsController.GetSelectedPricingParams(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, pricingParams);
         this.jobSelectionsMock.Verify(x => x.GetSelectedPricingParamRecords(jobId), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParams_ValidJobId_ReturnsNoContent()
      {
         // Arrange
         int jobId = 1234;
         IEnumerable<PricingParamViewModel> pricingParams = new List<PricingParamViewModel>();
         this.jobSelectionsMock.Setup(x => x.GetSelectedPricingParamRecords(jobId)).Returns(Task.FromResult(pricingParams));

         // Act
         var result = await this.selectionsController.GetSelectedPricingParams(jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectedPricingParamRecords(jobId), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParams_InvalidJobId_ReturnsBadRequest()
      {
         // Act
         var result = await this.selectionsController.GetSelectedPricingParams(0);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectedPricingParamRecords(It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task GetSelectedPricingParams_HasData_ReturnsPricingParams()
      {
         // Arrange
         int jobId = 1234;
         IEnumerable<PricingParamViewModel> pricingParams = CommonHelper.GetPricingParamsViewModel();
         this.jobSelectionsMock.Setup(x => x.GetSelectedPricingParams(It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(pricingParams));

         // Act
         var result = await this.selectionsController.GetSelectedPricingParams(jobId, this.selectedPricingParamIds);

         // Assert
         Assert.Equal(pricingParams, ((OkObjectResult)result).Value);
         this.jobSelectionsMock.Verify(x => x.GetSelectedPricingParams(this.selectedPricingParamIds), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParams_HasNoData_ReturnsNoContent()
      {
         // Arrange
         int jobId = 1234;
         IEnumerable<PricingParamViewModel> pricingParams = Enumerable.Empty<PricingParamViewModel>();
         this.jobSelectionsMock.Setup(x => x.GetSelectedPricingParams(It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(pricingParams));

         // Act
         var result = await this.selectionsController.GetSelectedPricingParams(jobId, this.selectedPricingParamIds);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectedPricingParams(this.selectedPricingParamIds), Times.Once);
      }

      [Theory]
      [InlineData(0, null)]
      [InlineData(123, null)]
      public async Task GetSelectedPricingParams_InvalidRequest_ReturnsBadRequest(int jobId, IEnumerable<int> sppIds)
      {
         // Act
         var result = await this.selectionsController.GetSelectedPricingParams(jobId, sppIds);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetSelectedPricingParams(It.IsAny<IEnumerable<int>>()), Times.Never);
      }

      [Fact]
      public async Task GetReferenceUnitDetails_HasData_ReturnsOkResult()
      {
         // Arrange
         int jobId = 123;
         IEnumerable<SelectionViewModel> selections = new Fixture().CreateMany<SelectionViewModel>(2);
         selections.ElementAt(0).Tag = "tag1";
         selections.ElementAt(0).SelectionDescription = "desc";
         this.jobSelectionsMock.Setup(x => x.GetReferenceUnitDetails(It.IsAny<int>())).Returns(Task.FromResult(selections));

         // Act
         IActionResult actionResult = await this.selectionsController.GetReferenceUnitDetails(jobId);

         // Assert
         Assert.Equal(((OkObjectResult)actionResult).Value, selections);
         Assert.IsType<OkObjectResult>(actionResult);
         this.jobSelectionsMock.Verify(x => x.GetReferenceUnitDetails(jobId), Times.Once);
      }

      [Fact]
      public async Task GetReferenceUnitDetails_HasNoData_ReturnsNoContent()
      {
         // Arrange
         int jobId = 123;
         this.jobSelectionsMock.Setup(s => s.GetReferenceUnitDetails(It.IsAny<int>())).Returns(Task.FromResult(Enumerable.Empty<SelectionViewModel>()));

         // Act
         IActionResult result = await this.selectionsController.GetReferenceUnitDetails(jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetReferenceUnitDetails(jobId), Times.Once);
      }

      [Fact]
      public async Task GetReferenceUnitDetails_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;

         // Act
         IActionResult result = await this.selectionsController.GetReferenceUnitDetails(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Contains((((ObjectResult)result).Value as JsonErrorResponse).Messages, x => x == Constants.InvalidRequest);
         this.jobSelectionsMock.Verify(m => m.GetReferenceUnitDetails(It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task GetShipCycleDetails_HasData_ReturnsOkResult()
      {
         // Arrange
         int jobId = 4353;
         IEnumerable<int> selectionIds = new List<int>() { 55, 77 };
         IEnumerable<ShipCycleViewModel> shipCycles = new Fixture().CreateMany<ShipCycleViewModel>(2);
         this.jobSelectionsMock.Setup(x => x.GetShipCycleDetails(It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(shipCycles));

         // Act
         IActionResult actionResult = await this.selectionsController.GetShipCycleDetails(jobId, selectionIds);

         // Assert
         Assert.Equal(((OkObjectResult)actionResult).Value, shipCycles);
         this.jobSelectionsMock.Verify(x => x.GetShipCycleDetails(selectionIds), Times.Once);
      }

      [Fact]
      public async Task GetShipCycleDetails_HasNoData_ReturnsNoContent()
      {
         // Arrange
         int jobId = 123;
         IEnumerable<int> selectionIds = new List<int>() { 55, 77 };
         IEnumerable<ShipCycleViewModel> shipCycles = null;
         this.jobSelectionsMock.Setup(x => x.GetShipCycleDetails(It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(shipCycles));

         // Act
         IActionResult result = await this.selectionsController.GetShipCycleDetails(jobId, selectionIds);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.jobSelectionsMock.Verify(x => x.GetShipCycleDetails(selectionIds), Times.Once);
      }

      [Fact]
      public async Task GetShipCycleDetails_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         IEnumerable<int> selectionIds = new List<int>() { };

         // Act
         IActionResult result = await this.selectionsController.GetShipCycleDetails(jobId, selectionIds);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Contains((((ObjectResult)result).Value as JsonErrorResponse).Messages, x => x == Constants.InvalidRequest);
         this.jobSelectionsMock.Verify(m => m.GetShipCycleDetails(It.IsAny<IEnumerable<int>>()), Times.Never);
      }
   }
}
