// <copyright file="DomainGroupEnvironmentExtensionsTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Configurations
{
    using Microsoft.AspNetCore.Hosting;
    using Moq;
    using Xunit;

    /// <summary>
    /// Class for domain group environment extensions test
    /// </summary>
    public class DomainGroupEnvironmentExtensionsTest
    {
        private readonly Mock<IWebHostEnvironment> mockEnv;

        /// <summary>
        /// Initializes a new instance of the <see cref="DomainGroupEnvironmentExtensionsTest"/> class.
        /// </summary>
        public DomainGroupEnvironmentExtensionsTest()
        {
            this.mockEnv = new Mock<IWebHostEnvironment>();
        }

        /// <summary>
        /// Domain group environment development returns environment name
        /// </summary>
        [Fact]
        public void DomainGroupEnvironemt_Development_ReturnsDevelopmentEnvironmentName()
        {
            // Arrange
            this.mockEnv.Setup(x => x.EnvironmentName).Returns("Development");

            // Act
            var test = JobSelectionService.Configurations.DomainGroupEnvironmentExtensions.DomainGroupEnvironmentName(this.mockEnv.Object);

            // Assert
            Assert.Equal("DEV", test);
        }

        /// <summary>
        /// Domain group environment production returns environment name
        /// </summary>
        [Fact]
        public void DomainGroupEnvironemt_Production_ReturnsProductionEnvironmentName()
        {
            // Arrange
            this.mockEnv.Setup(x => x.EnvironmentName).Returns("Production");

            // Act
            var test = JobSelectionService.Configurations.DomainGroupEnvironmentExtensions.DomainGroupEnvironmentName(this.mockEnv.Object);

            // Assert
            Assert.Equal("PROD", test);
        }

        /// <summary>
        /// Domain group environment staging returns environment name
        /// </summary>
        [Fact]
        public void DomainGroupEnvironemt_Staging_ReturnsStagingEnvironmentName()
        {
            // Arrange
            this.mockEnv.Setup(x => x.EnvironmentName).Returns("Staging");

            // Act
            var test = JobSelectionService.Configurations.DomainGroupEnvironmentExtensions.DomainGroupEnvironmentName(this.mockEnv.Object);

            // Assert
            Assert.Equal("STAGING", test);
        }

        /// <summary>
        /// Domain group environment testing returns environment name
        /// </summary>
        [Fact]
        public void DomainGroupEnvironemt_Testing_ReturnsStagingEnvironmentName()
        {
            // Arrange
            this.mockEnv.Setup(x => x.EnvironmentName).Returns("Testing");

            // Act
            var test = JobSelectionService.Configurations.DomainGroupEnvironmentExtensions.DomainGroupEnvironmentName(this.mockEnv.Object);

            // Assert
            Assert.Equal("TEST", test);
        }
    }
}
