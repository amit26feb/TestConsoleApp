﻿// <copyright file="ProgramTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test
{
    using System;
    using System.IO;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using JobSelectionService;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.TestHost;
    using Xunit;

    public class ProgramTest
    {
        [Fact]
        public async Task ShouldBuildWebHost()
        {
            // Arrange
            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
            string appRootPath = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory,
                "..",
                "..",
                "..",
                "..",
                "JobSelectionService"));
            var webHostBuilder = Program.BuildWebHost(Array.Empty<string>())
                .UseContentRoot(appRootPath);
            var server = new TestServer(webHostBuilder);
            var client = server.CreateClient();
            HttpResponseMessage response = new HttpResponseMessage();

            // Act
            response = await client.GetAsync(" ");

            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }
    }
}