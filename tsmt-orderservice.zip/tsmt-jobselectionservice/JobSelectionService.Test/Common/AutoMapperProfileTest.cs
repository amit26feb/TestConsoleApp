﻿// <copyright file="AutoMapperProfileTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Common
{
    using AutoFixture;
    using AutoMapper;
    using JobSelectionService.Configurations.AutoMapperConfiguration;
    using JobSelectionService.Core.Models;
    using JobSelectionService.Core.ViewModels;
    using Xunit;

   /// <summary>
   /// Automapper profile test
   /// </summary>
   public class AutoMapperProfileTest
   {
      private readonly MapperConfiguration config;
      private readonly IMapper mapper;

      /// <summary>
      /// Initializes a new instance of the <see cref="AutoMapperProfileTest"/> class.
      /// </summary>
      public AutoMapperProfileTest()
      {
         // Arrange
         this.config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });
         this.mapper = this.config.CreateMapper();
      }

      /// <summary>
      /// Ensure the mapping from selection model to selection view model.
      /// </summary>
      [Fact]
      public void Map_SelectionToSelectionViewModel_Works()
      {
         // Arrange
         Fixture fixture = new Fixture();
         fixture.Customize<Selection>(x => x.With(x => x.ALLOW_NO_PARTIAL_SHIPMENT_IND, "N"));
         Selection source = fixture.Create<Selection>();

         // Act
         SelectionViewModel destination = this.mapper.Map<SelectionViewModel>(source);

         // Assert
         Assert.Equal(source.SELECTION_ID, destination.SelectionId);
         Assert.Equal(source.SOURCE, destination.Source);
         Assert.Equal(source.SELECTION_SOURCE, destination.SelectionSource);
         Assert.Equal(source.VPFC_ID, destination.VpfcId);
         Assert.Equal(source.PROD_FAMILY_ID, destination.ProductFamilyId);
         Assert.Equal(source.SI_ID, destination.SiId);
         Assert.Equal(source.ORD_LINE_NBR, destination.OrderLineNumber);
         Assert.True(destination.IsAllowPartialShipment);
         Assert.Equal(source.TAG_SEQUENCE_NBR, destination.TagSequenceNumber);
      }

      [Fact]
      public void Map_PricingParamToPricingParamViewModel_Works()
      {
         // Arrange
         Fixture fixture = new Fixture();
         PricingParam source = fixture.Create<PricingParam>();

         // Act
         PricingParamViewModel destination = this.mapper.Map<PricingParamViewModel>(source);

         // Assert
         Assert.Equal(source.SELECTION_ID, destination.SelectionId);
         Assert.Equal(source.BID_BREAKOUT_NAME, destination.Description);
         Assert.Equal(source.PROD_CODE, destination.ProductCode);
         Assert.Equal(source.SELECTED_PRICING_PARM_ID, destination.SelectedPricingParmId);
         Assert.Equal(source.ORDERED_INDICATOR, destination.OrderedIndicator);
         Assert.Equal(source.PRICED_INDICATOR, destination.PricedIndicator);
         Assert.Equal(source.BID_ALTERNATE_ID, destination.BidAlternateId);
         Assert.Equal(source.HQTR_SELECTED_PRICING_PARM_ID, destination.HqtrSelectedPricingParmId);
         Assert.Equal(source.NET_PRICE, destination.NetPrice);
         Assert.Equal(source.REVISE_DATE, destination.ReviseDate);
         Assert.Equal(source.OFFICE_FAP, destination.OfficeFap);
         Assert.Equal(source.QUICK_SHIP_FAP, destination.QuickShipFap);
         Assert.Equal(source.PROD_FAMILY_FAP, destination.ProdFamilyFap);
         Assert.Equal(source.FLEXIBLE_FAP, destination.FlexibleFap);
      }

      [Fact]
      public void Map_NonTraneItemToNonTraneItemViewModel_Works()
      {
         // Arrange
         NonTraneItem source = new NonTraneItem()
         {
            COST_ESTIMATE = 100
         };

         // Act
         NonTraneItemViewModel destination = this.mapper.Map<NonTraneItemViewModel>(source);

         // Assert
         Assert.Equal(source.COST_ESTIMATE, destination.CostEstimate);
      }

      [Fact]
      public void Map_VariationToVariationViewModel_Works()
      {
         // Arrange
         Fixture fixture = new Fixture();
         Variation source = fixture.Create<Variation>();

         // Act
         VariationViewModel destination = this.mapper.Map<VariationViewModel>(source);

         // Assert
         Assert.Equal(source.SELECTION_ID, destination.SelectionId);
         Assert.Equal(source.SHORT_DESC, destination.Description);
         Assert.Equal(source.PROD_CODE, destination.ProductCode);
         Assert.Equal(source.VARIATION_ID, destination.VariationId);
         Assert.Equal(source.ORDERED_INDICATOR, destination.OrderedIndicator);
         Assert.Equal(source.MATL_QTY, destination.Qty);
         Assert.Equal(source.BID_ALTERNATE_ID, destination.BidAlternateId);
         Assert.Equal(source.TAG, destination.Tag);
         Assert.Equal(source.HQTR_VARIATION_ID, destination.HqtrVariationId);
         Assert.Equal(source.VARIATION_BILLING_METHOD_CODE, destination.VariationBillingMethodCode);
      }

      [Fact]
      public void Map_ShipCycleToShipCycleViewModel_Works()
      {
         // Arrange
         Fixture fixture = new Fixture();
         ShipCycle source = fixture.Create<ShipCycle>();

         // Act
         ShipCycleViewModel destination = this.mapper.Map<ShipCycleViewModel>(source);

         // Assert
         Assert.Equal(source.SELECTION_ID, destination.SelectionId);
         Assert.Equal(source.VPC_ID, destination.VpcId);
         Assert.Equal(source.UOM, destination.UnitOfMeasure);
         Assert.Equal(source.SI_ID, destination.SiId);
      }
   }
}
