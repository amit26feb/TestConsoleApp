﻿// <copyright file="CommonHelper.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Common
{
   using System;
   using System.Collections.Generic;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.ViewModels;

   public static class CommonHelper
   {
      /// <summary>
      /// Gets the selection information view model
      /// </summary>
      /// <returns>Selection information view model</returns>
      public static SelectionInfoViewModel GetSelectionInfoViewModel()
      {
         return new SelectionInfoViewModel()
         {
            SelectionId = 12345,
            Description = "Variable Air Volume Single Duct Terminal Units",
            CoordinationJobCompetitor = "Carnes,Metal-Aire,Ti",
            CoordinationJobSpecifiedUser = "Titus",
            CoordinationJobShipQuarter = 2,
            CoordinationJobShipYear = 2008
         };
      }

      /// <summary>
      /// Gets the selection information
      /// </summary>
      /// <returns>Selection information</returns>
      public static SelectionInfo GetSelectionInfo()
      {
         return new SelectionInfo()
         {
            SELECTION_ID = 12345,
            DESCRIPTION = "Variable Air Volume Single Duct Terminal Units",
            CJ_COMPETITOR = "Carnes,Metal-Aire,Ti",
            CJ_SPECIFIED = "Titus",
            CJ_SHIP_QTR = 2,
            CJ_SHIP_YEAR = 2008
         };
      }

      /// <summary>
      /// Get bid selection
      /// </summary>
      /// <returns>Bid selection</returns>
      public static BidSelectionViewModel BidsSelection()
      {
         return new BidSelectionViewModel()
         {
            ProductFamilyId = 123546,
            Descriptions = new List<string> { "ABCD" },
            SelectionIds = new List<int> { 1234, 4567 },
            ShipQuarter = 1,
            ShipYear = 2019,
            SiIds = new List<int> { 353, 34534 }
         };
      }

      /// <summary>
      /// Get si
      /// </summary>
      /// <param name="selectionId">Selection id</param>
      /// <param name="siId">Si id</param>
      /// <returns>Si</returns>
      public static Si GetSi(int selectionId, int siId)
      {
         return new Si()
         {
            SELECTION_ID = selectionId,
            SI_ID = siId
         };
      }

      /// <summary>
      /// Get selection
      /// </summary>
      /// <param name="selectionId">Selection id</param>
      /// <param name="salesmanDescription">Salesman description</param>
      /// <param name="tag">Tag</param>
      /// <returns>Selection</returns>
      public static Selection GetSelection(int selectionId, string salesmanDescription, string tag)
      {
         return new Selection()
         {
            SALESMAN_DESCR = salesmanDescription,
            SELECTION_ID = selectionId,
            TAG = tag,
            SELECTED_ITEM_ID = 123,
            VPC_ID = 12345,
            SI_ID = 456786
         };
      }

      /// <summary>
      /// Gets the selection view model
      /// </summary>
      /// <returns>Selection information view model</returns>
      public static SelectionViewModel GetSelectionViewModel()
      {
         return new SelectionViewModel()
         {
            SelectionId = 123,
            VpcId = 23456,
            Source = "Test",
            ProdModuleId = 567,
            SelectedItemId = 123,
            SiId = 34566
         };
      }

      /// <summary>
      /// Get non trane item data
      /// </summary>
      /// <returns>Non trane item data</returns>
      public static NonTraneItem GetNonTraneItemData()
      {
         return new NonTraneItem()
         {
            VARIATION_ID = 56594,
            VARIATION_TYPE = "M",
            JOB_ID = 56704,
            SHORT_DESC = "Curb Adapter",
            PROVIDER_NAME = "CDI",
            MATL_QTY = 1
         };
      }

      /// <summary>
      /// Get tag details
      /// </summary>
      /// <returns>Tag details</returns>
      public static IEnumerable<TagDetail> GetTagDetails()
      {
         return new List<TagDetail>()
         {
            new TagDetail()
            {
               TAG = "curb",
               REFERENCE_UNIT_ID = 1538212,
               TAG_SEQUENCE_NBR = 1
            }
         };
      }

      /// <summary>
      /// Get non trane item data with cost forecast
      /// </summary>
      /// <returns>Non trane item data with cost forecast</returns>
      public static NonTraneItem GetNonTraneItemDataWithCostForecast()
      {
         return new NonTraneItem()
         {
            VARIATION_ID = 56594,
            VARIATION_TYPE = "M",
            JOB_ID = 56704,
            SHORT_DESC = "Curb Adapter",
            PROVIDER_NAME = "CDI",
            MATL_QTY = 1,
            COST_FORECAST = 20,
            IS_ORACLE = "Y",
         };
      }

      /// <summary>
      /// Get list of selected pricing param
      /// </summary>
      /// <param name="selectionId">Selection Id</param>
      /// <returns>List of selected pricing param</returns>
      public static IEnumerable<PricingParam> GetPricingParam(int selectionId)
      {
         return new List<PricingParam>()
         {
            new PricingParam()
            {
               SELECTION_ID = selectionId,
               SELECTED_PRICING_PARM_ID = 8899,
               PROD_CODE = "BK14",
               NET_PRICE = 4321
            }
         };
      }

      /// <summary>
      /// Gets selected pricing param data model
      /// </summary>
      /// <returns>List of selected pricing param</returns>
      public static IEnumerable<PricingParam> GetPricingParams()
      {
         return new List<PricingParam>()
         {
            new PricingParam()
            {
               SELECTION_ID = 1353,
               SELECTED_PRICING_PARM_ID = 8899,
               AUTH_COMM_RATE = 0.05M,
               BASE_FREIGHT_RESERVE_RATE = 0.03M,
               COMM_OVERAGE_RATIO = 0.5M,
               COST_POINT_COMM_RATE = 0.05M,
               COST_POINT_MULTIPLIER = 0.358M,
               HQTR_SELECTED_PRICING_PARM_ID = 1245,
               LIST_CONVERSION_MULT = 1,
               QTY_LPAF = 1,
               QUICK_SHIP_BPAF = 1
            },
            new PricingParam()
            {
               SELECTION_ID = 1353,
               SELECTED_PRICING_PARM_ID = 6699,
               AUTH_COMM_RATE = 0.065M,
               BASE_FREIGHT_RESERVE_RATE = 0.02M,
               COMM_OVERAGE_RATIO = 0.5M,
               COST_POINT_COMM_RATE = 0.06M,
               COST_POINT_MULTIPLIER = 0.358M,
               HQTR_SELECTED_PRICING_PARM_ID = 6645,
               LIST_CONVERSION_MULT = 1,
               QTY_LPAF = 1,
               QUICK_SHIP_BPAF = 1
            }
         };
      }

      /// <summary>
      /// Gets selected pricing params view model
      /// </summary>
      /// <returns>List of selected pricing param</returns>
      public static IEnumerable<PricingParamViewModel> GetPricingParamsViewModel()
      {
         return new List<PricingParamViewModel>()
         {
            new PricingParamViewModel()
            {
               SelectionId = 1353,
               SelectedPricingParmId = 8899,
               AuthCommRate = 0.05M,
               BaseFreightReserveRate = 0.03M,
               CommOverageRatio = 0.5M,
               CostPointCommRate = 0.05M,
               CostPointMultiplier = 0.358M,
               HqtrSelectedPricingParmId = 1245,
               ListConversionMult = 1,
               QtyLpaf = 1,
               QuickShipBpaf = 1
            },
            new PricingParamViewModel()
            {
               SelectionId = 1353,
               SelectedPricingParmId = 6699,
               AuthCommRate = 0.065M,
               BaseFreightReserveRate = 0.02M,
               CommOverageRatio = 0.5M,
               CostPointCommRate = 0.06M,
               CostPointMultiplier = 0.358M,
               HqtrSelectedPricingParmId = 6645,
               ListConversionMult = 1,
               QtyLpaf = 1,
               QuickShipBpaf = 1
            }
         };
      }

      /// <summary>
      /// Get list of separately biddable
      /// </summary>
      /// <returns>List of separately biddable</returns>
      public static IEnumerable<PricingParam> GetSeparateBiddable()
      {
         return new List<PricingParam>()
         {
            new PricingParam()
            {
               SELECTED_PRICING_PARM_ID = 8899,
               PROD_CODE = "BK14"
            }
         };
      }

      /// <summary>
      /// Get list of selection
      /// </summary>
      /// <param name="selectionId">Selection Id</param>
      /// <returns>List of selections</returns>
      public static IEnumerable<Selection> GetSelection(int selectionId)
      {
         return new List<Selection>
         {
            new Selection()
            {
               SELECTION_ID = selectionId,
               SALESMAN_DESCR = "Test Selection",
               PROD_CODE = "BK14",
               PROD_FAMILY_ID = 100,
               SELECTION_SOURCE = "CM",
               LEGACY_ORD_NBR = "2-90",
               ORD_LINE_NBR = 1,
               SALES_ORD_ID = 105,
               REVISE_DATE = new DateTime(202, 05, 05)
            }
         };
      }

      public static NonTraneItemViewModel GetNonTraneItemViewModel()
      {
         return new NonTraneItemViewModel()
         {
            JobId = 12886,
            VariationId = 0,
            Cost = 900,
            Markup = 1,
            Qty = 1,
            SellingPrice = 16609.6M,
            ProviderName = "CDI",
            Description = "Adapter Curb",
            VariationType = "M",
            ProdCode = "0913",
            CostForecast = 20,
            IsOracle = true,
            TagDetails = new List<TagDetailViewModel>() { new TagDetailViewModel { ReferenceUnitId = 456, Tag = "MF-10", TagSequenceNbr = 1 } }
         };
      }

      public static IEnumerable<NonTraneItem> GetNonTraneItems()
      {
         return new List<NonTraneItem>
         {
            new NonTraneItem()
            {
               VARIATION_ID = 56594,
               JOB_ID = 56704,
               SHORT_DESC = "Curb Adapter",
               PROVIDER_NAME = "CDI",
               MATL_QTY = 1,
               TOTAL_COUNT = "1",
               MATERIAL_COUNT = 3,
               FACILITATIONFEE_COUNT = 4,
               LABOR_COUNT = 5,
               EQUIPMENT_NAME = "Acoustics",
               VENDOR_NAME = "Annexair",
               STRATEGIC_PROVIDER = "Y",
               COST_ESTIMATE = 100
            },
            new JobSelectionService.Core.Models.NonTraneItem()
            {
               VARIATION_ID = 56594,
               JOB_ID = 56704,
               SHORT_DESC = "Curb Adapter",
               PROVIDER_NAME = "CDI",
               MATL_QTY = 1,
               TOTAL_COUNT = "1",
               EQUIPMENT_NAME = "Annexair",
               VENDOR_LEAD_TIME_DAYS = 1,
               VENDOR_NAME = "Custom AHUs",
               COST_ESTIMATE = 200
            }
         };
      }

      /// <summary>
      /// Get ship cycle detail
      /// </summary>
      /// <returns>Ship cycle detail</returns>
      public static IEnumerable<ShipCycle> GetShipCycles()
      {
         return new List<ShipCycle>()
         {
            new ShipCycle()
            {
               SELECTION_ID = 3435,
               SHIP_CYCLE_LENGTH = 2,
               UOM = "week"
            }
         };
      }
   }
}
