﻿// <copyright file="HttpGlobalExceptionFilterTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Common.Filters
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Runtime.Serialization.Formatters.Binary;
    using FluentValidation;
    using JobSelectionService.Common.ActionResults;
    using JobSelectionService.Common.Exceptions;
    using JobSelectionService.Common.Filters;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Abstractions;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.AspNetCore.Routing;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Http global exception filter test
    /// </summary>
    public class HttpGlobalExceptionFilterTest
    {
        private readonly Mock<IWebHostEnvironment> env;
        private readonly Mock<ILogger<HttpGlobalExceptionFilter>> logger;
        private readonly Mock<List<IFilterMetadata>> filterMetadata;
        private HttpGlobalExceptionFilter httpGlobalFilter;

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpGlobalExceptionFilterTest"/> class.
        /// Http global exception filter test
        /// </summary>
        public HttpGlobalExceptionFilterTest()
        {
            this.env = new Mock<IWebHostEnvironment>();
            this.logger = new Mock<ILogger<HttpGlobalExceptionFilter>>();
            this.filterMetadata = new Mock<List<IFilterMetadata>>();
        }

        /// <summary>
        /// On exception handles exception - returns internal server error - success
        /// </summary>
        [Fact]
        public void OnException_SuccessHandle_ReturnsInternalServerError()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);

            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor()
            },
            this.filterMetadata.Object)
            {
                Exception = new Exception()
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.InternalServerError, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        /// <summary>
        /// On exception handles exception - returns bad request - success
        /// </summary>
        [Fact]
        public void OnException_SuccessHandle_ReturnsBadRequest()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);

            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new JobSelectionServiceDomainException()
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        /// <summary>
        /// On exception handles exception with message - success
        /// </summary>
        [Fact]
        public void OnException_SuccessHandle_ReturnsExceptionMessage()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor()
            },
            this.filterMetadata.Object)
            {
                Exception = new JobSelectionServiceDomainException("Exception")
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        /// <summary>
        /// On exception handles exception with inner exception - success
        /// </summary>
        [Fact]
        public void OnException_SuccessHandle_ReturnsInnerException()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var httpContext = new DefaultHttpContext();
            var innerException = new ValidationException("message");
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new JobSelectionServiceDomainException("InnerException", innerException)
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        /// <summary>
        /// On Exception handles serializable exception with message - Success
        /// </summary>
        [Fact]
        public void OnException_SerializableException_ReturnsException()
        {
            // Arrange
            JobSelectionServiceDomainException exception = new JobSelectionServiceDomainException("test");
            JobSelectionServiceDomainException result;

            // Act
            using (Stream s = new MemoryStream())
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(s, exception);
                s.Position = 0; // Reset stream position
                result = (JobSelectionServiceDomainException)formatter.Deserialize(s);
            }

            // Assert
            Assert.Equal("test", result.Message);
        }

        /// <summary>
        /// On Exception handles exception on the development environment
        /// </summary>
        [Fact]
        public void OnException_Development_GetsException()
        {
            // Arrange
            this.env.Setup(m => m.EnvironmentName).Returns("Development");
            var filterUnderTest = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var someException = new Exception("asdf");
            var excepContext = this.GetExceptionContext(someException);

            // Act
            filterUnderTest.OnException(excepContext);

            // Assert
            Assert.IsType<InternalServerErrorObjectResult>(excepContext.Result);
            var result = excepContext.Result as InternalServerErrorObjectResult;
            Assert.IsType<JsonErrorResponse>(result.Value);
            var jsonResult = result.Value as JsonErrorResponse;
            Assert.True(jsonResult.DeveloperMessage == someException);
        }

        /// <summary>
        /// On Exception handles exception on the production environment
        /// </summary>
        [Fact]
        public void OnException_NonDevelopment_GetsNoException()
        {
            // Arrange
            this.env.Setup(m => m.EnvironmentName).Returns("Production");
            var filterUnderTest = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var someException = new Exception("asdf");
            var excepContext = this.GetExceptionContext(someException);

            // Act
            filterUnderTest.OnException(excepContext);

            // Assert
            Assert.IsType<InternalServerErrorObjectResult>(excepContext.Result);
            var result = excepContext.Result as InternalServerErrorObjectResult;
            Assert.IsType<JsonErrorResponse>(result.Value);
            var jsonResult = result.Value as JsonErrorResponse;
            Assert.True(jsonResult.DeveloperMessage == null);
        }

        /// <summary>
        /// On Exception handles exception with the status code
        /// </summary>
        [Fact]
        public void OnException_SetsStatus()
        {
            // Arrange
            var filterUnderTest = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var someException = new Exception("asdf");
            var excepContext = this.GetExceptionContext(someException);

            // Act
            filterUnderTest.OnException(excepContext);

            // Assert
            Assert.True(excepContext.HttpContext.Response.StatusCode == (int)HttpStatusCode.InternalServerError);
        }

        /// <summary>
        /// Method to get the exception context based on the exception object
        /// </summary>
        /// <param name="exception">Exception object</param>
        /// <returns>Exception context </returns>
        private ExceptionContext GetExceptionContext(Exception exception)
        {
            return new ExceptionContext(
              new ActionContext
              {
                  HttpContext = new DefaultHttpContext(),
                  RouteData = new RouteData(),
                  ActionDescriptor = new ActionDescriptor(),
              },
              this.filterMetadata.Object)
            {
                Exception = exception
            };
        }

        /// <summary>
        /// Fake logger class to be used HttpGlobalExceptionFilterTest for logging
        /// </summary>
        public class FakeLogger : ILogger<HttpGlobalExceptionFilter>
        {
            /// <summary>
            /// Gets or sets the Logged Exception
            /// </summary>
            public Exception LoggedException { get; set; }

            /// <summary>
            /// BeginScope
            /// </summary>
            /// <typeparam name="TState">The transaction state type</typeparam>
            /// <param name="state">The state object</param>
            /// <returns>IDisposable interface object</returns>
            public IDisposable BeginScope<TState>(TState state)
            {
                throw new NotImplementedException();
            }

            /// <summary>
            /// IsEnabled
            /// </summary>
            /// <param name="logLevel">The log level enum</param>
            /// <returns>Boolean</returns>
            public bool IsEnabled(LogLevel logLevel)
            {
                throw new NotImplementedException();
            }

            /// <summary>
            /// Log
            /// </summary>
            /// <typeparam name="TState">TState type param</typeparam>
            /// <param name="logLevel">The log level enum</param>
            /// <param name="eventId">EventId</param>
            /// <param name="state">TState</param>
            /// <param name="exception">Exception</param>
            /// <param name="formatter">Func</param>
            public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
            {
                this.LoggedException = exception;
            }
        }
    }
}
