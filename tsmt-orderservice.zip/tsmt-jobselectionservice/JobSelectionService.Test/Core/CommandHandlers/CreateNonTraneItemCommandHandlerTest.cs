// <copyright file="CreateNonTraneItemCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.CommandHandlers
{
   using System.Threading.Tasks;
   using JobSelectionService.Core.CommandHandlers;
   using JobSelectionService.Core.Commands;
   using JobSelectionService.Core.Services;
   using JobSelectionService.Core.ViewModels;
   using Moq;
   using Xunit;

   public class CreateNonTraneItemCommandHandlerTest
   {
      private readonly Mock<INonTraneItemService> nonTraneItemServiceMock;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateNonTraneItemCommandHandlerTest"/> class.
      /// </summary>
      public CreateNonTraneItemCommandHandlerTest()
      {
         this.nonTraneItemServiceMock = new Mock<INonTraneItemService>();
      }

      /// <summary>
      /// Test successful create non trane item for a job
      /// </summary>
      /// <returns>Valid variation id</returns>
      [Fact]
      public async Task Handle_CreateNonTraneItem_ReturnsVariationId()
      {
         // Arrange
         int variationId = 1;
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 12886,
            VariationId = 0,
            Cost = 900,
            Markup = 1,
            Qty = 1,
            SellingPrice = 16609.6M,
            ProviderName = "CDI",
            Description = "Adapter Curb",
            VariationType = "M",
            ProdCode = "0913",
         };

         var createNonTraneItemCommand = new CreateNonTraneItemCommand(nonTraneItem);
         this.nonTraneItemServiceMock.Setup(x => x.CreateNonTraneItem(It.IsAny<NonTraneItemViewModel>())).
            Returns(Task.FromResult(variationId));
         var createNonTraneItemCommandHandler = new CreateNonTraneItemCommandHandler(this.nonTraneItemServiceMock.Object);
         var cltToken = default(System.Threading.CancellationToken);

         // Act
         var result = await createNonTraneItemCommandHandler.Handle(createNonTraneItemCommand, cltToken);

         // Assert
         Assert.Equal(variationId, result);
         this.nonTraneItemServiceMock.Verify(x => x.CreateNonTraneItem(nonTraneItem), Times.Once);
      }

      /// <summary>
      /// Test unsuccessful create non trane item for invalid job id
      /// </summary>
      /// <returns>Invalid variation id</returns>
      [Fact]
      public async Task Handle_CreateNonTraneItem_ReturnsInvalidVariationId()
      {
         // Arrange
         int variationId = 0;
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 0,
            Description = "Adapter Curb",
            VariationType = string.Empty
         };

         var createNonTraneItemCommand = new CreateNonTraneItemCommand(nonTraneItem);
         this.nonTraneItemServiceMock.Setup(x => x.CreateNonTraneItem(It.IsAny<NonTraneItemViewModel>()))
             .Returns(Task.FromResult(variationId));
         var createNonTraneItemCommandHandler = new CreateNonTraneItemCommandHandler(this.nonTraneItemServiceMock.Object);
         var cltToken = default(System.Threading.CancellationToken);

         // Act
         var result = await createNonTraneItemCommandHandler.Handle(createNonTraneItemCommand, cltToken);

         // Assert
         Assert.Equal(variationId, result);
         this.nonTraneItemServiceMock.Verify(x => x.CreateNonTraneItem(nonTraneItem), Times.Once);
      }
   }
}
