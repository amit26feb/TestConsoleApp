﻿// <copyright file="DeleteNonTraneItemCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.CommandHandlers
{
   using System.Threading;
   using System.Threading.Tasks;
   using JobSelectionService.Core.CommandHandlers;
   using JobSelectionService.Core.Commands;
   using JobSelectionService.Core.Services;
   using Moq;
   using Xunit;

   public class DeleteNonTraneItemCommandHandlerTest
   {
      private readonly Mock<INonTraneItemService> nonTraneItemServiceMock;

      private readonly DeleteNonTraneItemCommandHandler deleteNonTraneItemCommandHandler;

      private readonly CancellationToken cltToken;

      /// <summary>
      /// Initializes a new instance of the <see cref="DeleteNonTraneItemCommandHandlerTest"/> class.
      /// </summary>
      public DeleteNonTraneItemCommandHandlerTest()
      {
         this.nonTraneItemServiceMock = new Mock<INonTraneItemService>();
         this.deleteNonTraneItemCommandHandler = new DeleteNonTraneItemCommandHandler(this.nonTraneItemServiceMock.Object);
         this.cltToken = default(CancellationToken);
      }

      /// <summary>
      /// Test successful delete non trane item for a job
      /// </summary>
      /// <returns>Deleted status</returns>
      [Fact]
      public async Task Handle_DeleteNonTraneItem_ReturnsDeletedStatus()
      {
         // Arrange
         int isDeleted = 1;
         int variationId = 12886;
         var removeNonTraneItemCommand = new DeleteNonTraneItemCommand(variationId);
         this.nonTraneItemServiceMock.Setup(x => x.DeleteNonTraneItem(variationId)).
            Returns(Task.FromResult(isDeleted));

         // Act
         var result = await this.deleteNonTraneItemCommandHandler.Handle(removeNonTraneItemCommand, this.cltToken);

         // Assert
         Assert.Equal(isDeleted, result);
         this.nonTraneItemServiceMock.Verify(x => x.DeleteNonTraneItem(variationId), Times.Once);
      }

      /// <summary>
      /// Test unsuccessful delete non trane item for invalid variation id
      /// </summary>
      /// <returns>Delete status</returns>
      [Fact]
      public async Task Handle_DeleteNonTraneItem_ReturnsZero()
      {
         // Arrange
         int variationId = 0;
         int isDeleted = 0;
         var removeNonTraneItemCommand = new DeleteNonTraneItemCommand(variationId);
         this.nonTraneItemServiceMock.Setup(x => x.DeleteNonTraneItem(variationId))
             .Returns(Task.FromResult(isDeleted));

         // Act
         var result = await this.deleteNonTraneItemCommandHandler.Handle(removeNonTraneItemCommand, this.cltToken);

         // Assert
         Assert.Equal(isDeleted, result);
         this.nonTraneItemServiceMock.Verify(x => x.DeleteNonTraneItem(variationId), Times.Once);
      }
   }
}
