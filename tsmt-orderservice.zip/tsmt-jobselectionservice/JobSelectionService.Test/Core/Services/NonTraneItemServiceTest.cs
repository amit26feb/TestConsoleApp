﻿// <copyright file="NonTraneItemServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using DataAccess.Paging;
   using JobSelectionService.Common.Constants;
   using JobSelectionService.Configurations;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.Repository;
   using JobSelectionService.Core.Services;
   using JobSelectionService.Core.ViewModels;
   using JobSelectionService.Test.Common;
   using JobSelectionService.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Microsoft.AspNetCore.JsonPatch;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using Newtonsoft.Json;
   using Xunit;

   /// <summary>
   /// Non trane item service test
   /// </summary>
   public class NonTraneItemServiceTest
   {
      private readonly Mock<INonTraneItemRepository> nonTraneItemRepository;
      private readonly NonTraneItemService nonTraneItemService;
      private readonly Mock<ILogger<INonTraneItemService>> logger;
      private readonly Mock<IOptions<CommonConfigurationSettings>> commonConfigurationSettingsMock;
      private readonly CommonConfigurationSettings commonConfigurationSettings;

      public NonTraneItemServiceTest()
      {
         this.nonTraneItemRepository = new Mock<INonTraneItemRepository>();
         this.logger = new Mock<ILogger<INonTraneItemService>>();
         var contextAccessor = new Mock<IHttpContextAccessor>();
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<global::JobSelectionService.Configurations.AutoMapperConfiguration.AutoMapperProfile>();
         });
         var mapper = config.CreateMapper();
         this.commonConfigurationSettingsMock = new Mock<IOptions<CommonConfigurationSettings>>();

         this.commonConfigurationSettings = new CommonConfigurationSettings()
         {
            DisableRebalancing = true
         };
         this.commonConfigurationSettingsMock.Setup(ap => ap.Value).Returns(this.commonConfigurationSettings);
         this.nonTraneItemService = new NonTraneItemService(this.nonTraneItemRepository.Object, contextAccessor.Object, mapper, this.logger.Object, this.commonConfigurationSettingsMock.Object);
      }

      [Fact]
      public async Task GetNonTraneItems_ValidRequest_ReturnsData()
      {
         // Arrange
         int jobId = 56704;
         IEnumerable<NonTraneItemViewModel> nonTraneDetails = new List<NonTraneItemViewModel>
         {
            new NonTraneItemViewModel()
            {
               VariationId = 56596,
               VariationType = "M",
               JobId = 56704,
               Description = "Adapter",
               VendorName = "CDI",
               ProdCode = "0913",
               Qty = 2,
               TotalCount = 1
            },

            new NonTraneItemViewModel()
            {
               VariationId = 56594,
               VariationType = "M",
               JobId = 56704,
               Description = "Curb Adapter",
               ProviderName = "CDI",
               ProdCode = "0082",
               Qty = 1,
               TotalCount = 1
            }
         };
         IEnumerable<NonTraneItem> nonTraneItems = new List<NonTraneItem>
         {
            new NonTraneItem()
            {
               VARIATION_ID = 56598,
               JOB_ID = 567046,
               SHORT_DESC = "Adapter",
               PROVIDER_NAME = "CDI",
               PROD_CODE = "0913",
               MATL_QTY = 1,
               TOTAL_COUNT = "1"
            },

            new NonTraneItem()
            {
               VARIATION_ID = 56594,
               JOB_ID = 56707,
               SHORT_DESC = "Curb Adapter",
               PROVIDER_NAME = "CD2",
               PROD_CODE = "0082",
               MATL_QTY = 2,
               TOTAL_COUNT = "1"
            }

         };
         NonTraneItemPagingResults pagingResult = new NonTraneItemPagingResults()
         {
            PageCount = 1,
            PageNumber = 1,
            PageSize = 1,
            TotalItemCount = 1,
            NonTraneItems = nonTraneDetails
         };
         List<Filter> filters = new List<Filter>
            {
                new Filter()
                {
                    Field = "description",
                    Operator = "contains",
                    Value = "a"
                },
            };

         List<FilterCollectionViewModel> filterCollection = new List<FilterCollectionViewModel>
            {
                new FilterCollectionViewModel()
                {
                    Filters = filters,
                    Logic = "and"
                }
            };
         JobSelectionService.Core.ViewModels.PagingOptions pagingOptions = new JobSelectionService.Core.ViewModels.PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = new List<SortViewModel>()
            {
               new SortViewModel()
               {
                  SortBy = "Description",
                  SortDirection = SortDirectionViewModel.Ascending
               }
            },
            Filters = filterCollection
         };

         this.nonTraneItemRepository.Setup(x => x.GetNonTraneItems(It.IsAny<TSMT.DataAccess.PagingOptions>(), jobId))
             .Returns(Task.FromResult(nonTraneItems));

         // Act
         var result = await this.nonTraneItemService.GetNonTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<JobSelectionService.Core.ViewModels.NonTraneItemPagingResults>(result);
         Assert.NotNull(result);
         Assert.True(result.TotalItemCount == 1);
         Assert.True(result.PageCount == 1);
         this.nonTraneItemRepository.Verify(x => x.GetNonTraneItems(It.IsAny<TSMT.DataAccess.PagingOptions>(), jobId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItems_ValidRequestWithoutSortAndFilter_ReturnsData()
      {
         // Arrange
         int jobId = 56704;
         IEnumerable<NonTraneItemViewModel> nonTraneDetails = new List<NonTraneItemViewModel>
         {
            new NonTraneItemViewModel()
            {
               VariationId = 56596,
               VariationType = "M",
               JobId = 56704,
               Description = "Adapter",
               VendorName = "CDI",
               ProdCode = "0913",
               Qty = 2,
               TotalCount = 1
            },

            new NonTraneItemViewModel()
            {
               VariationId = 56594,
               VariationType = "M",
               JobId = 56704,
               Description = "Curb Adapter",
               VendorName = "CD2",
               ProdCode = "0082",
               Qty = 1,
               TotalCount = 1
            }
         };
         IEnumerable<NonTraneItem> nonTraneItems = new List<NonTraneItem>
         {
            new NonTraneItem()
            {
               VARIATION_ID = 56598,
               JOB_ID = 567046,
               SHORT_DESC = "Adapter",
               PROVIDER_NAME = "CDI",
               PROD_CODE = "0913",
               MATL_QTY = 1,
               TOTAL_COUNT = "1"
            },

            new NonTraneItem()
            {
               VARIATION_ID = 56594,
               JOB_ID = 56707,
               SHORT_DESC = "Curb Adapter",
               PROVIDER_NAME = "CD2",
               PROD_CODE = "0082",
               MATL_QTY = 2,
               TOTAL_COUNT = "1"
            }

         };
         NonTraneItemPagingResults pagingResult = new NonTraneItemPagingResults()
         {
            PageCount = 1,
            PageNumber = 2,
            PageSize = 10,
            TotalItemCount = 1,
            NonTraneItems = nonTraneDetails
         };
         JobSelectionService.Core.ViewModels.PagingOptions pagingOptions = new JobSelectionService.Core.ViewModels.PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = new List<SortViewModel>(),
            Filters = new List<FilterCollectionViewModel>()
         };

         this.nonTraneItemRepository.Setup(x => x.GetNonTraneItems(It.IsAny<TSMT.DataAccess.PagingOptions>(), jobId))
             .Returns(Task.FromResult(nonTraneItems));

         // Act
         var result = await this.nonTraneItemService.GetNonTraneItems(pagingOptions, jobId);

         // Assert
         Assert.IsType<JobSelectionService.Core.ViewModels.NonTraneItemPagingResults>(result);
         Assert.NotNull(result);
         Assert.True(result.TotalItemCount == 1);
         Assert.True(result.PageCount == 1);
         this.nonTraneItemRepository.Verify(x => x.GetNonTraneItems(It.IsAny<TSMT.DataAccess.PagingOptions>(), jobId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_HasValidData_ReturnsNonTraneItem()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         NonTraneItem nonTraneItem = CommonHelper.GetNonTraneItemData();
         IEnumerable<TagDetail> tagDetails = CommonHelper.GetTagDetails();

         IEnumerable<Document> documentDetails = new List<Document>
         {
            new Document()
            {
               DOCUMENT_VERSION = "25Lpz22Bli0ruzJ2aCmY2uSJUXFy0x4C",
               DOCUMENT_NAME = "Variation_TestDocument.txt",
               DOCUMENT_KEY = "Jobs/122/15639/84/90/Variation_TestDocument.txt",
               JOB_DOCUMENT_TYPE_ID = 1
            }
         };

         this.nonTraneItemRepository.Setup(x => x.GetNonTraneItem(variationId, jobId))
             .Returns(Task.FromResult(nonTraneItem));
         this.nonTraneItemRepository.Setup(x => x.GetTagDetails(variationId, jobId))
             .Returns(Task.FromResult(tagDetails));
         this.nonTraneItemRepository.Setup(x => x.GetDocumentDetails(jobId, variationId))
             .Returns(Task.FromResult(documentDetails));

         // Act
         NonTraneItemViewModel result = await this.nonTraneItemService.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.IsType<NonTraneItemViewModel>(result);
         Assert.NotNull(result);
         Assert.True(result.DocumentDetails.First().DocumentName == "Variation_TestDocument.txt");
         Assert.True(result.DocumentDetails.First().JobDocumentTypeId == 1);
         this.nonTraneItemRepository.Verify(x => x.GetNonTraneItem(variationId, jobId), Times.Once);
         this.nonTraneItemRepository.Verify(x => x.GetTagDetails(variationId, jobId), Times.Once);
         this.nonTraneItemRepository.Verify(x => x.GetDocumentDetails(jobId, variationId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_EmptyDocuments_ReturnsNonTraneItemWithEmptyDocumentDetails()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         NonTraneItem nonTraneItem = CommonHelper.GetNonTraneItemData();
         IEnumerable<TagDetail> tagDetails = CommonHelper.GetTagDetails();

         IEnumerable<Document> documentDetails = Enumerable.Empty<Document>();
         this.nonTraneItemRepository.Setup(x => x.GetNonTraneItem(It.IsAny<int>(), It.IsAny<int>()))
             .Returns(Task.FromResult(nonTraneItem));
         this.nonTraneItemRepository.Setup(x => x.GetTagDetails(It.IsAny<int>(), It.IsAny<int>()))
             .Returns(Task.FromResult(tagDetails));
         this.nonTraneItemRepository.Setup(x => x.GetDocumentDetails(It.IsAny<int>(), It.IsAny<int>()))
             .Returns(Task.FromResult(documentDetails));

         // Act
         NonTraneItemViewModel result = await this.nonTraneItemService.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.Empty(result.DocumentDetails);
         this.nonTraneItemRepository.Verify(x => x.GetNonTraneItem(variationId, jobId), Times.Once);
         this.nonTraneItemRepository.Verify(x => x.GetTagDetails(variationId, jobId), Times.Once);
         this.nonTraneItemRepository.Verify(x => x.GetDocumentDetails(jobId, variationId), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_HasInvalidData_ReturnsNull()
      {
         // Arrange
         int jobId = 0;
         int variationId = 0;
         NonTraneItem nonTraneItem = null;
         this.nonTraneItemRepository.Setup(x => x.GetNonTraneItem(It.IsAny<int>(), It.IsAny<int>()))
             .Returns(Task.FromResult(nonTraneItem));

         // Act
         NonTraneItemViewModel result = await this.nonTraneItemService.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.Null(result);
         this.nonTraneItemRepository.Verify(x => x.GetNonTraneItem(variationId, jobId), Times.Once);
         this.nonTraneItemRepository.Verify(x => x.GetTagDetails(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.nonTraneItemRepository.Verify(x => x.GetDocumentDetails(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task CreateNonTraneItem_WhenInserted_ReturnsValidId()
      {
         // Arrange
         int variationId = 19313;
         int createdRows = 1;
         string tableName = "VARIATION";
         int howManyToReserve = 1;
         var nonTraneItem = CommonHelper.GetNonTraneItemViewModel();

         this.nonTraneItemRepository.Setup(x => x.GetSequenceNumber(tableName, howManyToReserve))
             .Returns(Task.FromResult(variationId));

         this.nonTraneItemRepository.Setup(x => x.CreateNonTraneItemAsync(It.IsAny<NonTraneItem>()))
             .Returns(Task.FromResult(createdRows));

         // Act
         var result = await this.nonTraneItemService.CreateNonTraneItem(nonTraneItem);

         // Assert
         Assert.Equal(result, variationId);
         this.nonTraneItemRepository.Verify(x => x.GetSequenceNumber(tableName, howManyToReserve), Times.Exactly(1));
         this.nonTraneItemRepository.Verify(x => x.CreateNonTraneItemAsync(It.IsAny<NonTraneItem>()), Times.Once);
         this.nonTraneItemRepository.Verify(x => x.CreateNonTraneItemAsync(VerifyNOnTraneItemMapping(nonTraneItem)), Times.Once);
      }

      [Fact]
      public async Task CreateNonTraneItem_WhenDoesNotInserted_ReturnsZero()
      {
         // Arrange
         int variationId = 19313;
         int createdRows = 0;
         string tableName = "VARIATION";
         int howManyToReserve = 1;
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 12886,
            Qty = 1,
            VariationId = 0,
            Cost = 900,
            Markup = 1,
            TagDetails = new List<TagDetailViewModel>() { new TagDetailViewModel { ReferenceUnitId = 456, Tag = "MF-10", TagSequenceNbr = 1 } }
         };

         this.nonTraneItemRepository.Setup(x => x.GetSequenceNumber(tableName, howManyToReserve))
             .Returns(Task.FromResult(variationId));

         this.nonTraneItemRepository.Setup(x => x.CreateNonTraneItemAsync(It.IsAny<NonTraneItem>()))
             .Returns(Task.FromResult(createdRows));

         // Act
         var result = await this.nonTraneItemService.CreateNonTraneItem(nonTraneItem);

         // Assert
         Assert.Equal(result, createdRows);
         this.nonTraneItemRepository.Verify(x => x.GetSequenceNumber(tableName, howManyToReserve), Times.Exactly(1));
         this.nonTraneItemRepository.Verify(x => x.CreateNonTraneItemAsync(It.IsAny<NonTraneItem>()), Times.Once);
      }

      [Fact]
      public async Task DeleteNonTraneItem_WhenDeleted_ReturnsDeletedRows()
      {
         // Arrange
         int variationId = 19313;
         int deletedRows = 1;

         this.nonTraneItemRepository.Setup(x => x.DeleteNonTraneItem(variationId))
             .Returns(Task.FromResult(deletedRows));

         // Act
         var result = await this.nonTraneItemService.DeleteNonTraneItem(variationId);

         // Assert
         Assert.Equal(result, deletedRows);
         this.nonTraneItemRepository.Verify(x => x.DeleteNonTraneItem(variationId), Times.Once);
      }

      [Fact]
      public async Task DeleteNonTraneItem_WhenNotDeleted_ReturnsZero()
      {
         // Arrange
         int variationId = 19313;
         int deletedRows = 0;

         this.nonTraneItemRepository.Setup(x => x.DeleteNonTraneItem(variationId))
             .Returns(Task.FromResult(deletedRows));

         // Act
         var result = await this.nonTraneItemService.DeleteNonTraneItem(variationId);

         // Assert
         Assert.Equal(result, deletedRows);
         this.nonTraneItemRepository.Verify(x => x.DeleteNonTraneItem(variationId), Times.Once);
      }

      [Fact]
      public async Task UpdateNonTraneItem_ValidInput_ReturnsTrue()
      {
         // Arrange
         JsonPatchDocument jsonPatchDocument = new JsonPatchDocument();

         // Reading Output Json
         string jsonFilepath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "Core/NonTraneItemTestData/NonTraneItemPatch.json"));
         var fileStream = File.Open(jsonFilepath, FileMode.Open, FileAccess.Read, FileShare.Read);
         using (StreamReader reader = new StreamReader(fileStream))
         {
            string jsonData = reader.ReadToEnd();
            jsonPatchDocument = JsonConvert.DeserializeObject<JsonPatchDocument>(jsonData);
         }

         this.nonTraneItemRepository.Setup(x => x.UpdateNonTraneItemAsync(It.IsAny<List<PatchOperation>>())).Returns(Task.FromResult(true));

         // Act
         var actionResult = await this.nonTraneItemService.UpdateNonTraneItem(jsonPatchDocument);

         // Assert
         Assert.True(actionResult);
         this.nonTraneItemRepository.Verify(x => x.UpdateNonTraneItemAsync(It.IsAny<List<PatchOperation>>()), Times.Once);
      }

      [Fact]
      public async Task UpdateNonTraneItem_InvalidInput_ReturnsFalse()
      {
         // Arrange
         var requestPayload = "[{ \"op\": \"replace\", \"path\": \"/Jobs/40737/Selection/979359\", \"value\": [{ \"Selection_Description\": \"Testing Desc\"}]}]";
         var jsonPatchDocument = JsonConvert.DeserializeObject<JsonPatchDocument>(requestPayload);

         // Act
         var actionResult = await this.nonTraneItemService.UpdateNonTraneItem(jsonPatchDocument);

         // Assert
         Assert.False(actionResult);
         this.nonTraneItemRepository.Verify(x => x.UpdateNonTraneItemAsync(It.IsAny<List<PatchOperation>>()), Times.Never);
      }

      [Fact]
      public async Task UpdateNonTraneItem_InvalidOperation_ReturnsFalse()
      {
         // Arrange
         var requestPayload = "[{ \"op\": \"remove\", \"path\": \"/Jobs/40737/Variations/979359\", \"value\": [{ }]}]";
         var jsonPatchDocument = JsonConvert.DeserializeObject<JsonPatchDocument>(requestPayload);

         // Act
         var actionResult = await this.nonTraneItemService.UpdateNonTraneItem(jsonPatchDocument);

         // Assert
         Assert.False(actionResult);
         this.nonTraneItemRepository.Verify(x => x.UpdateNonTraneItemAsync(It.IsAny<List<PatchOperation>>()), Times.Never);
      }

      private static NonTraneItem VerifyNOnTraneItemMapping(NonTraneItemViewModel nonTraneItem)
      {
         return It.Is<NonTraneItem>(y => y.VARIATION_PROD_CODE == Constants.VariationProductCode);
      }
   }
}
