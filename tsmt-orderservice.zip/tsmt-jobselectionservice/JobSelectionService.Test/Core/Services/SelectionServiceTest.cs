﻿// <copyright file="SelectionServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Text;
   using System.Threading.Tasks;
   using AutoFixture;
   using AutoMapper;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.Repository;
   using JobSelectionService.Core.Services;
   using JobSelectionService.Core.ViewModels;
   using JobSelectionService.Test.Common;
   using JobSelectionService.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   public class SelectionServiceTest
   {
      private readonly int jobId = 11;
      private readonly Mock<ISelectionRepository> jobSelectionsRepository;
      private readonly ISelectionService selectionService;
      private readonly IEnumerable<int> sppIds;

      public SelectionServiceTest()
      {
         this.jobSelectionsRepository = new Mock<ISelectionRepository>();

         var repository = new Mock<IRepository<Selection>>();
         var contextAccessor = new Mock<IHttpContextAccessor>();
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<global::JobSelectionService.Configurations.AutoMapperConfiguration.AutoMapperProfile>();
         });
         var mapper = config.CreateMapper();

         this.selectionService = new SelectionService(repository.Object, this.jobSelectionsRepository.Object, contextAccessor.Object, mapper);
         this.sppIds = new[] { 8899, 6699 };
      }

      [Fact]
      public async Task GetJobSelections_ValidId_ReturnsValidData()
      {
         // Arrange
         IEnumerable<Selection> selections = new List<Selection>
         {
            new Selection()
            {
               SELECTION_ID = 12,
               ORDERED_INDICATOR = "O",
               PRICED_INDICATOR = "P"
            }
         };

         IEnumerable<PricingParam> pricingParams = new List<PricingParam>
         {
            new PricingParam()
            {
               SELECTION_ID = 12,
               BID_BREAKOUT_NAME = "425 Tyler Accessories",
               ORDERED_INDICATOR = "O",
               PRICED_INDICATOR = "P"
            }
         };

         IEnumerable<Variation> variations = new List<Variation>
         {
            new Variation()
            {
               SELECTION_ID = 12,
               VARIATION_ID = 17,
               SHORT_DESC = "atsc",
               ORDERED_INDICATOR = "O"
            },
            new Variation()
            {
               SELECTION_ID = null,
               VARIATION_ID = 89,
               SHORT_DESC = "STARTUP",
               ORDERED_INDICATOR = "O"
            }
         };

         this.jobSelectionsRepository.Setup(x => x.GetSelections(It.IsAny<int>()))
             .Returns(Task.FromResult(selections)).Verifiable();
         this.jobSelectionsRepository.Setup(x => x.GetSeparateBiddables(It.IsAny<int>()))
             .Returns(Task.FromResult(pricingParams)).Verifiable();
         this.jobSelectionsRepository.Setup(x => x.GetVariations(It.IsAny<int>()))
             .Returns(Task.FromResult(variations)).Verifiable();

         // Act
         var result = await this.selectionService.GetJobSelections(this.jobId);

         // Assert
         Assert.True(result.SelectionList.Select(a => a.SelectionId == 12).Any());
         Assert.True(result.SelectionList.Select(a => a.OrderedIndicator == "O").Any());
         Assert.True(result.SelectionList.Select(a => a.SeparatelyBiddableList.Count == 1).Any());
         Assert.True(result.SelectionList.Select(a => a.VariationList.Count == 1).Any());
         Assert.True(result.SelectionList.Select(a => a.PricedIndicator == "P").Any());
         Assert.True(result.JobVariationList.Select(a => a.SelectionId == null).Any());
         this.jobSelectionsRepository.Verify();
      }

      [Fact]
      public async Task GetJobSelections_ValidId_ReturnsNoSeparatelyBiddables()
      {
         // Arrange
         IEnumerable<Selection> selections = new List<Selection>
         {
            new Selection()
            {
               SELECTION_ID = 12,
            }
         };

         IEnumerable<PricingParam> pricingParams = new List<PricingParam>();

         this.jobSelectionsRepository.Setup(x => x.GetSelections(It.IsAny<int>()))
             .Returns(Task.FromResult(selections)).Verifiable();
         this.jobSelectionsRepository.Setup(x => x.GetSeparateBiddables(It.IsAny<int>()))
             .Returns(Task.FromResult(pricingParams)).Verifiable();

         // Act
         var result = await this.selectionService.GetJobSelections(this.jobId);

         // Assert
         Assert.True(result.SelectionList.Select(a => a.SelectionId == 12).Any());
         Assert.True(result.SelectionList.Select(a => a.SeparatelyBiddableList.Count == 0).Any());
         this.jobSelectionsRepository.Verify();
      }

      [Fact]
      public async Task GetJobSelections_ValidId_ReturnsNoVariations()
      {
         // Arrange
         IEnumerable<Selection> selections = new List<Selection>
         {
            new Selection()
            {
               SELECTION_ID = 12,
            }
         };

         IEnumerable<Variation> variations = new List<Variation>();

         this.jobSelectionsRepository.Setup(x => x.GetSelections(It.IsAny<int>()))
             .Returns(Task.FromResult(selections)).Verifiable();
         this.jobSelectionsRepository.Setup(x => x.GetVariations(It.IsAny<int>()))
             .Returns(Task.FromResult(variations)).Verifiable();

         // Act
         var result = await this.selectionService.GetJobSelections(this.jobId);

         // Assert
         Assert.True(result.SelectionList.Select(a => a.SelectionId == 12).Any());
         Assert.True(result.SelectionList.Select(a => a.VariationList.Count == 0).Any());
         this.jobSelectionsRepository.Verify();
      }

      [Fact]
      public async Task GetJobSelections_ValidId_ReturnsNoSelections()
      {
         // Arrange
         IEnumerable<Selection> selections = new List<Selection>();
         IEnumerable<Variation> variations = new List<Variation>();
         this.jobSelectionsRepository.Setup(x => x.GetSelections(It.IsAny<int>()))
             .Returns(Task.FromResult(selections)).Verifiable();
         this.jobSelectionsRepository.Setup(x => x.GetVariations(It.IsAny<int>()))
             .Returns(Task.FromResult(variations)).Verifiable();

         // Act
         var result = await this.selectionService.GetJobSelections(this.jobId);

         // Assert
         Assert.Null(result);
         this.jobSelectionsRepository.Verify(x => x.GetSeparateBiddables(It.IsAny<int>()), Times.Never);
         this.jobSelectionsRepository.Verify(x => x.GetVariations(It.IsAny<int>()), Times.Once);
      }

      // Verify returned value translates/maps sel_price_complete (null = good) as true
      [Fact]
      public async Task GetSelectionDetails_SelPriceCompleteIsNull_ReturnsTrue()
      {
         IEnumerable<int> selectionIds = new List<int>() { 230733 };
         IEnumerable<SelectionInfo> selectionDetails = new List<SelectionInfo>()
         {
            new SelectionInfo()
         };

         this.jobSelectionsRepository.Setup(x => x.GetSelectionDetails(this.jobId, selectionIds)).Returns(Task.FromResult(selectionDetails));

         // Act
         var result = await this.selectionService.GetSelectionDetails(this.jobId, selectionIds);

         // Assert
         Assert.True(result.Single().IsSelectionPriceComplete);
         this.jobSelectionsRepository.Verify(x => x.GetSelectionDetails(this.jobId, selectionIds), Times.Once);
      }

      // Verify returned value translates/maps sel_price_complete (empty = good) as true
      [Fact]
      public async Task GetSelectionDetails_SelPriceCompleteIsEmpty_ReturnsTrue()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int>() { 230733 };
         IEnumerable<SelectionInfo> selectionDetails = new List<SelectionInfo>()
         {
            new SelectionInfo()
            {
               SEL_PRICE_COMPLETE = string.Empty
            }
         };

         this.jobSelectionsRepository.Setup(x => x.GetSelectionDetails(this.jobId, selectionIds)).Returns(Task.FromResult(selectionDetails));

         // Act
         var result = await this.selectionService.GetSelectionDetails(this.jobId, selectionIds);

         // Assert
         Assert.True(result.Single().IsSelectionPriceComplete);
         this.jobSelectionsRepository.Verify(x => x.GetSelectionDetails(this.jobId, selectionIds), Times.Once);
      }

      // Verify returned value translates/maps sel_price_complete (bad) as false
      [Fact]
      public async Task GetSelectionDetails_SelPriceCompleteIsNotNull_ReturnsFalse()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int>() { 230733, 319529 };
         IEnumerable<SelectionInfo> selectionDetails = new List<SelectionInfo>()
         {
            new SelectionInfo()
            {
               SEL_PRICE_COMPLETE = "N"
            }
         };

         this.jobSelectionsRepository.Setup(x => x.GetSelectionDetails(this.jobId, selectionIds)).Returns(Task.FromResult(selectionDetails));

         // Act
         var result = await this.selectionService.GetSelectionDetails(this.jobId, selectionIds);

         // Assert
         Assert.False(result.Single().IsSelectionPriceComplete);
         this.jobSelectionsRepository.Verify(x => x.GetSelectionDetails(this.jobId, selectionIds), Times.Once);
      }

      [Fact]
      public async Task IsSelectionExists_ValidId_HasSelections_ReturnsTrue()
      {
         // Arrange
         int jobId = 12389;

         this.jobSelectionsRepository.Setup(x => x.GetSelectionCount(It.IsAny<int>()))
             .Returns(Task.FromResult(2)).Verifiable();

         // Act
         var result = await this.selectionService.IsSelectionExists(jobId);

         // Assert
         Assert.True(result);
         this.jobSelectionsRepository.Verify();
      }

      [Fact]
      public async Task IsSelectionExists_ValidId_NoSelections_ReturnsFalse()
      {
         // Arrange
         int jobId = 12389;

         this.jobSelectionsRepository.Setup(x => x.GetSelectionCount(It.IsAny<int>()))
             .Returns(Task.FromResult(0)).Verifiable();

         // Act
         var result = await this.selectionService.IsSelectionExists(jobId);

         // Assert
         Assert.False(result);
         this.jobSelectionsRepository.Verify();
      }

      /// <summary>
      /// Get selections
      /// </summary>
      /// <returns>Empty selections</returns>
      [Fact]
      public async Task GetBidsSelections_ValidInput_ReturnsEmptySelections()
      {
         // Arrange
         int jobId = 12389;
         int jobCoordinationId = 12346;
         IEnumerable<int> productFamilyIds = new List<int> { 2005665 };
         string billOfMaterials = "[{'BID_ALTERNATE_ID':199882,'PROD_FAMILY_ID':2005665,'CJ_SHIP_QTR':2,'CJ_SHIP_YEAR':2022,'CJ_COMPETITOR':'Daikin York','CJ_SPECIFIED':null,'SELECTION_IDS':[843877,850109],'SELECTION_SOURCE': 'C', 'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false}]";
         this.jobSelectionsRepository.Setup(x => x.GetBillOfMaterials(jobCoordinationId)).Returns(Task.FromResult(Encoding.UTF8.GetBytes(billOfMaterials)));
         this.jobSelectionsRepository.Setup(x => x.GetProductFamilyIds(productFamilyIds)).Returns(Task.FromResult(productFamilyIds));

         // Act
         var result = await this.selectionService.GetBidsSelections(jobId, jobCoordinationId);
         var selectionValidation = result.Single(x => x.ProductFamilyId == 2005665);

         // Assert
         Assert.NotNull(result);
         Assert.Null(selectionValidation.Descriptions);
         this.jobSelectionsRepository.Verify(x => x.GetBillOfMaterials(It.IsAny<int>()), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetProductFamilyIds(It.IsAny<IEnumerable<int>>()), Times.Once);
      }

      /// <summary>
      ///  Get selections
      ///  With tag and description and without tag and description
      ///  Skip non configured selection
      /// </summary>
      /// <returns>Selections</returns>
      [Fact]
      public async Task GetBidsSelections_SkipNonConfiguredSelection_ReturnsSelections()
      {
         // Arrange
         int jobId = 12389;
         int jobCoordinationId = 12346;
         IEnumerable<Selection> selectionErrors = new List<Selection>()
         {
            CommonHelper.GetSelection(843877, "test", string.Empty),
            CommonHelper.GetSelection(850109, "test12", "xyz")
         };
         IEnumerable<int> selectionIds = new List<int> { 843877, 850109 };
         IEnumerable<int> productFamilyIds = new List<int> { 2005665 };
         IEnumerable<int> emptyProductFamilyIds = new List<int>();
         string billOfMaterials = "[{'BID_ALTERNATE_ID':199882,'PROD_FAMILY_ID':2005665,'CJ_SHIP_QTR':2,'CJ_SHIP_YEAR':2022,'CJ_COMPETITOR':'Daikin York','CJ_SPECIFIED':null,'SELECTION_IDS':[843877,850109],'SELECTION_SOURCE': 'C', 'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false}," +
                                   "{'BID_ALTERNATE_ID':199883,'PROD_FAMILY_ID':2005666,'CJ_SHIP_QTR':2,'CJ_SHIP_YEAR':2019,'CJ_COMPETITOR':'Daikin York','CJ_SPECIFIED':null,'SELECTION_IDS':[843878,850110],'SELECTION_SOURCE': 'N', 'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false}]";
         this.jobSelectionsRepository.Setup(x => x.GetBillOfMaterials(jobCoordinationId)).Returns(Task.FromResult(Encoding.UTF8.GetBytes(billOfMaterials)));
         this.jobSelectionsRepository.Setup(x => x.GetProductFamilyIds(productFamilyIds)).Returns(Task.FromResult(emptyProductFamilyIds));
         this.jobSelectionsRepository.Setup(x => x.GetBidsSelections(jobId, selectionIds)).Returns(Task.FromResult(selectionErrors));

         // Act
         var result = await this.selectionService.GetBidsSelections(jobId, jobCoordinationId);
         var selectionValidation = result.Single(x => x.ProductFamilyId == 2005665);

         // Assert
         Assert.NotNull(result);
         Assert.NotNull(selectionValidation.Descriptions);
         Assert.Contains(selectionValidation.Descriptions, x => x == "<xyz> test12");
         Assert.Contains(selectionValidation.Descriptions, x => x == "test");
         this.jobSelectionsRepository.Verify(x => x.GetBillOfMaterials(jobCoordinationId), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetProductFamilyIds(It.IsAny<IEnumerable<int>>()), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetBidsSelections(It.IsAny<int>(), It.IsAny<IEnumerable<int>>()), Times.Once);
      }

      /// <summary>
      ///  Get selections
      ///  Skip separately biddable selections
      /// </summary>
      /// <returns>Selections</returns>
      [Fact]
      public async Task GetBidsSelections_HasSeparatelyBiddableSelections_ReturnsSelections()
      {
         // Arrange
         int jobId = 12389;
         int jobCoordinationId = 12346;
         IEnumerable<int> productFamilyIds = new List<int> { 2005665 };
         IEnumerable<int> emptyProductFamilyIds = new List<int>();
         string billOfMaterials = "[{'BID_ALTERNATE_ID':199882,'PROD_FAMILY_ID':2005665,'CJ_SHIP_QTR':2,'CJ_SHIP_YEAR':2022,'CJ_COMPETITOR':'Daikin York','CJ_SPECIFIED':null,'SELECTION_IDS':[843877,850109],'SELECTION_SOURCE': 'C', 'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : true}]";
         this.jobSelectionsRepository.Setup(x => x.GetBillOfMaterials(jobCoordinationId)).Returns(Task.FromResult(Encoding.UTF8.GetBytes(billOfMaterials)));
         this.jobSelectionsRepository.Setup(x => x.GetProductFamilyIds(productFamilyIds)).Returns(Task.FromResult(emptyProductFamilyIds));

         // Act
         var result = await this.selectionService.GetBidsSelections(jobId, jobCoordinationId);
         var selectionValidation = result.Single(x => x.ProductFamilyId == 2005665);

         // Assert
         Assert.Null(selectionValidation.Descriptions);
         this.jobSelectionsRepository.Verify(x => x.GetBillOfMaterials(jobCoordinationId), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetProductFamilyIds(emptyProductFamilyIds), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetBidsSelections(jobId, productFamilyIds), Times.Never);
      }

      /// <summary>
      ///  Get bid selections with si ids and without selection
      /// </summary>
      /// <returns>Selection validations with si ids</returns>
      [Fact]
      public async Task GetBidsSelections_ValidRequest_ReturnsSelectionValidationWithSids()
      {
         // Arrange
         int jobId = 12389;
         int jobCoordinationId = 12346;
         IEnumerable<Selection> selectionErrors = new List<Selection>()
         {
            CommonHelper.GetSelection(843877, "test", string.Empty),
            CommonHelper.GetSelection(850109, "test12", "xyz")
         };
         IEnumerable<int> selectionIds = new List<int> { 843877, 850109 };
         IEnumerable<int> productFamilyIds = new List<int> { 2005665 };
         IEnumerable<int> selectionIdDoesntHaveSiIds = new List<int> { 850109 };
         IEnumerable<Si> sis = new List<Si>()
         {
            CommonHelper.GetSi(843877, 123455)
         };
         IEnumerable<int> emptyProductFamilyIds = new List<int>();
         string billOfMaterials = "[{'BID_ALTERNATE_ID':199882,'PROD_FAMILY_ID':2005665,'CJ_SHIP_QTR':2,'CJ_SHIP_YEAR':2022,'CJ_COMPETITOR':'Daikin York','CJ_SPECIFIED':null,'SELECTION_IDS':[843877,850109],'SELECTION_SOURCE': 'C', 'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false}]";
         this.jobSelectionsRepository.Setup(x => x.GetBillOfMaterials(jobCoordinationId)).Returns(Task.FromResult(Encoding.UTF8.GetBytes(billOfMaterials)));
         this.jobSelectionsRepository.Setup(x => x.GetProductFamilyIds(productFamilyIds)).Returns(Task.FromResult(emptyProductFamilyIds));
         this.jobSelectionsRepository.Setup(x => x.GetBidsSelections(jobId, selectionIds)).Returns(Task.FromResult(selectionErrors));
         this.jobSelectionsRepository.Setup(x => x.GetSis(jobId, selectionIds)).Returns(Task.FromResult(sis));

         // Act
         var result = await this.selectionService.GetBidsSelections(jobId, jobCoordinationId);
         var selectionValidation = result.Single(x => x.ProductFamilyId == 2005665);

         // Assert
         Assert.NotNull(result);
         Assert.NotNull(selectionValidation.SiIds);
         this.jobSelectionsRepository.Verify(x => x.GetBillOfMaterials(jobCoordinationId), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetProductFamilyIds(productFamilyIds), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetBidsSelections(jobId, selectionIdDoesntHaveSiIds), Times.Once);
      }

      /// <summary>
      ///  Get bid selections with si ids
      /// </summary>
      /// <returns>Selection with si ids</returns>
      [Fact]
      public async Task GetBidsSelections_ValidRequest_ReturnsSelectionWithSiIds()
      {
         // Arrange
         int jobId = 12389;
         int jobCoordinationId = 12346;
         IEnumerable<Selection> selectionErrors = new List<Selection>()
         {
            CommonHelper.GetSelection(850109, "test12", "xyz")
         };
         IEnumerable<int> selectionIds = new List<int> { 850109 };
         IEnumerable<int> productFamilyIds = new List<int> { 2005665 };
         IEnumerable<Si> sis = new List<Si>()
         {
            CommonHelper.GetSi(843877, 123455)
         };
         IEnumerable<int> emptyProductFamilyIds = new List<int>();
         string billOfMaterials = "[{'BID_ALTERNATE_ID':199882,'PROD_FAMILY_ID':2005665,'CJ_SHIP_QTR':2,'CJ_SHIP_YEAR':2022,'CJ_COMPETITOR':'Daikin York','CJ_SPECIFIED':null,'SELECTION_IDS':[850109],'SELECTION_SOURCE': 'C', 'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false}]";
         this.jobSelectionsRepository.Setup(x => x.GetBillOfMaterials(jobCoordinationId)).Returns(Task.FromResult(Encoding.UTF8.GetBytes(billOfMaterials)));
         this.jobSelectionsRepository.Setup(x => x.GetProductFamilyIds(selectionIds)).Returns(Task.FromResult(emptyProductFamilyIds));
         this.jobSelectionsRepository.Setup(x => x.GetBidsSelections(jobId, selectionIds)).Returns(Task.FromResult(selectionErrors));
         this.jobSelectionsRepository.Setup(x => x.GetSis(jobId, selectionIds)).Returns(Task.FromResult(sis));

         // Act
         var result = await this.selectionService.GetBidsSelections(jobId, jobCoordinationId);
         var selectionValidation = result.Single(x => x.ProductFamilyId == 2005665);

         // Assert
         Assert.NotNull(result);
         Assert.NotNull(selectionValidation.SiIds);
         Assert.NotNull(selectionValidation.Descriptions);
         this.jobSelectionsRepository.Verify(x => x.GetBillOfMaterials(It.IsAny<int>()), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetProductFamilyIds(It.IsAny<IEnumerable<int>>()), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetBidsSelections(It.IsAny<int>(), It.IsAny<IEnumerable<int>>()), Times.Once);
      }

      /// <summary>
      ///  Get bid selections with si ids
      /// </summary>
      /// <returns>Si ids</returns>
      [Fact]
      public async Task GetBidsSelections_ValidRequestSelectionIdDoesntHaveSiIds_ReturnsSelectionsWithSiIds()
      {
         // Arrange
         int jobId = 12389;
         int jobCoordinationId = 12346;
         IEnumerable<int> selectionIds = new List<int> { 843877 };
         IEnumerable<int> productFamilyIds = new List<int> { 2005665 };
         IEnumerable<Si> sis = new List<Si>()
         {
            CommonHelper.GetSi(843877, 123455)
         };
         IEnumerable<int> emptyProductFamilyIds = new List<int>();
         string billOfMaterials = "[{'BID_ALTERNATE_ID':199882,'PROD_FAMILY_ID':2005665,'CJ_SHIP_QTR':2,'CJ_SHIP_YEAR':2022,'CJ_COMPETITOR':'Daikin York','CJ_SPECIFIED':null,'SELECTION_IDS':[843877],'SELECTION_SOURCE': 'C', 'DOES_SEPARATELY_BIDDABLE_SELECTIONS_EXIST' : false}]";
         this.jobSelectionsRepository.Setup(x => x.GetBillOfMaterials(jobCoordinationId)).Returns(Task.FromResult(Encoding.UTF8.GetBytes(billOfMaterials)));
         this.jobSelectionsRepository.Setup(x => x.GetProductFamilyIds(selectionIds)).Returns(Task.FromResult(emptyProductFamilyIds));
         this.jobSelectionsRepository.Setup(x => x.GetSis(jobId, selectionIds)).Returns(Task.FromResult(sis));

         // Act
         var result = await this.selectionService.GetBidsSelections(jobId, jobCoordinationId);
         var selectionValidation = result.Single(x => x.ProductFamilyId == 2005665);

         // Assert
         Assert.NotNull(result);
         Assert.NotNull(selectionValidation.SiIds);
         Assert.Null(selectionValidation.Descriptions);
         this.jobSelectionsRepository.Verify(x => x.GetBillOfMaterials(It.IsAny<int>()), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetProductFamilyIds(It.IsAny<IEnumerable<int>>()), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetBidsSelections(It.IsAny<int>(), It.IsAny<IEnumerable<int>>()), Times.Never);
      }

      /// <summary>
      ///  Get selected items
      /// </summary>
      /// <returns>Selected items</returns>
      [Fact]
      public async Task GetSelectedItems_ValidSelectionId_ReturnsSelections()
      {
         // Arrange
         int jobId = 12389;
         IEnumerable<Selection> selectedItems = new List<Selection>()
         {
            CommonHelper.GetSelection(843877, "test", string.Empty),
            CommonHelper.GetSelection(850109, "test12", "xyz")
         };
         IEnumerable<int> selectionIds = new List<int> { 843877, 850109 };
         this.jobSelectionsRepository.Setup(x => x.GetSelectedItems(jobId, selectionIds)).Returns(Task.FromResult(selectedItems));

         // Act
         IEnumerable<SelectionViewModel> result = await this.selectionService.GetSelectedItems(jobId, selectionIds);

         // Assert
         Assert.NotNull(result);
         this.jobSelectionsRepository.Verify(x => x.GetSelectedItems(jobId, selectionIds), Times.Once);
      }

      /// <summary>
      /// Get selection performance details
      /// </summary>
      /// <returns>Selection performance details</returns>
      [Fact]
      public async Task GetSelectionPerformanceDetails_HasData_ReturnsSelectionPerformanceDetails()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int> { 1246020, 1246032 };
         int jobId = 123;
         Fixture fixture = new Fixture();
         IEnumerable<Selection> selectionPerformances = fixture.Create<IEnumerable<Selection>>();
         selectionPerformances.ElementAt(0).SELECTION_ID = 1246020;
         selectionPerformances.ElementAt(0).VPFC_ID = 1246020;
         this.jobSelectionsRepository.Setup(x => x.GetSelectionPerformanceDetails(It.IsAny<IEnumerable<int>>(), It.IsAny<int>(), It.IsAny<bool>())).Returns(Task.FromResult(selectionPerformances));

         // Act
         IEnumerable<SelectionViewModel> result = await this.selectionService.GetSelectionPerformanceDetails(selectionIds, jobId, false);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(1246020, result.First().SelectionId);
         Assert.Equal(1246020, result.First().VpfcId);
         this.jobSelectionsRepository.Verify(x => x.GetSelectionPerformanceDetails(selectionIds, jobId, false), Times.Once);
      }

      [Fact]
      public async Task GetTraneItems_ValidRequest_ReturnsData()
      {
         // Arrange
         IEnumerable<JobSelectionService.Core.Models.Selection> selections = new List<JobSelectionService.Core.Models.Selection>
            {
                    new JobSelectionService.Core.Models.Selection()
                    {
                      SELECTION_ID = 67,
                      SALESMAN_DESCR = "abc",
                      TOTAL_COUNT = 1
                    }
            };
         List<JobSelectionService.ViewModels.Filter> filters = new List<JobSelectionService.ViewModels.Filter>
            {
                new JobSelectionService.ViewModels.Filter()
                {
                    Field = "SelectionDescription",
                    Operator = "contains",
                    Value = "a"
                },
            };

         List<FilterCollectionViewModel> filterCollections = new List<FilterCollectionViewModel>
            {
                new FilterCollectionViewModel()
                {
                    Filters = filters,
                    Logic = "and"
                }
            };
         List<JobSelectionService.Core.ViewModels.SortViewModel> sortAttributes = new List<JobSelectionService.Core.ViewModels.SortViewModel>()
         {
            new JobSelectionService.Core.ViewModels.SortViewModel()
            {
            SortBy = "Qty",
            SortDirection = global::JobSelectionService.Core.ViewModels.SortDirectionViewModel.Ascending
            }
         };
         JobSelectionService.Core.ViewModels.PagingOptions pagingOptions = new JobSelectionService.Core.ViewModels.PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = sortAttributes,
            Filters = filterCollections
         };
         this.jobSelectionsRepository.Setup(x => x.GetTraneItems(It.IsAny<TSMT.DataAccess.PagingOptions>(), It.IsAny<int>()))
            .Returns(Task.FromResult(selections));

         // Act
         var result = await this.selectionService.GetTraneItems(pagingOptions, 90);

         // Assert
         Assert.IsType<JobSelectionService.Core.ViewModels.SelectionsPagingResults>(result);
         Assert.NotNull(result);
         this.jobSelectionsRepository.Verify(x => x.GetTraneItems(It.IsAny<TSMT.DataAccess.PagingOptions>(), It.IsAny<int>()), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParamRecords_ReturnsPricingParamsWithMainUnit()
      {
         // Arrange
         int jobId = 1234;
         int selectionId = 556677;
         this.jobSelectionsRepository.Setup(x => x.GetSelectedPricingParamRecords(jobId)).Returns(Task.FromResult(CommonHelper.GetPricingParam(selectionId)));
         this.jobSelectionsRepository.Setup(x => x.GetSeparateBiddables(jobId)).Returns(Task.FromResult(CommonHelper.GetSeparateBiddable()));
         this.jobSelectionsRepository.Setup(x => x.GetSelections(jobId)).Returns(Task.FromResult(CommonHelper.GetSelection(selectionId)));

         // Act
         IEnumerable<PricingParamViewModel> result = await this.selectionService.GetSelectedPricingParamRecords(jobId);

         // Assert
         this.jobSelectionsRepository.Verify(x => x.GetSelectedPricingParamRecords(jobId), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetSeparateBiddables(jobId), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetSelections(jobId), Times.Once);
         Assert.Equal(selectionId, result.First().SelectionId);
         Assert.True(result.First().IsMainUnit);
      }

      [Fact]
      public async Task GetSelectedPricingParamRecords_ReturnsPricingParamsWithNonMainUnit()
      {
         // Arrange
         int jobId = 1234;
         int selectionId = 556677;
         int testSelectionId = 889900;
         this.jobSelectionsRepository.Setup(x => x.GetSelectedPricingParamRecords(jobId)).Returns(Task.FromResult(CommonHelper.GetPricingParam(selectionId)));
         this.jobSelectionsRepository.Setup(x => x.GetSeparateBiddables(jobId)).Returns(Task.FromResult(CommonHelper.GetSeparateBiddable()));
         this.jobSelectionsRepository.Setup(x => x.GetSelections(jobId)).Returns(Task.FromResult(CommonHelper.GetSelection(testSelectionId)));

         // Act
         IEnumerable<PricingParamViewModel> result = await this.selectionService.GetSelectedPricingParamRecords(jobId);

         // Assert
         this.jobSelectionsRepository.Verify(x => x.GetSelectedPricingParamRecords(jobId), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetSeparateBiddables(jobId), Times.Once);
         this.jobSelectionsRepository.Verify(x => x.GetSelections(jobId), Times.Once);
         Assert.Equal(selectionId, result.First().SelectionId);
         Assert.False(result.First().IsMainUnit);
      }

      [Fact]
      public async Task GetReferenceUnitDetails_HasData_ReturnsSelections()
      {
         // Arrange
         int jobId = 123;
         IEnumerable<Selection> selections = CommonHelper.GetSelection(1);
         this.jobSelectionsRepository.Setup(x => x.GetReferenceUnitDetails(It.IsAny<int>())).Returns(Task.FromResult(selections));

         // Act
         IEnumerable<SelectionViewModel> result = await this.selectionService.GetReferenceUnitDetails(jobId);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(selections.ElementAt(0).TAG, result.First().Tag);
         Assert.Equal(selections.ElementAt(0).SALESMAN_DESCR, result.First().SelectionDescription);
         Assert.Equal(selections.ElementAt(0).SELECTION_ID, result.First().SelectionId);
         Assert.Equal(selections.ElementAt(0).PROD_FAMILY_ID, result.First().ProductFamilyId);
         Assert.Equal(selections.ElementAt(0).SELECTION_SOURCE, result.First().SelectionSource);
         Assert.Equal(selections.ElementAt(0).LEGACY_ORD_NBR, result.First().LegacyOrderNumber);
         Assert.Equal(selections.ElementAt(0).ORD_LINE_NBR, result.First().OrderLineNumber);
         Assert.Equal(selections.ElementAt(0).SALES_ORD_ID, result.First().SalesOrderId);
         Assert.Equal(selections.ElementAt(0).REVISE_DATE, result.First().ReviseDate);
         this.jobSelectionsRepository.Verify(x => x.GetReferenceUnitDetails(jobId), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParams_HasNoData_ReturnsEmptyResult()
      {
         // Arrange
         IEnumerable<PricingParam> pricingParams = Enumerable.Empty<PricingParam>();

         this.jobSelectionsRepository.Setup(x => x.GetSelectedPricingParamByIds(It.IsAny<IEnumerable<int>>()))
             .Returns(Task.FromResult(pricingParams));

         // Act
         var result = await this.selectionService.GetSelectedPricingParams(this.sppIds);

         // Assert
         Assert.Empty(result);
         this.jobSelectionsRepository.Verify(x => x.GetSelectedPricingParamByIds(this.sppIds), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParams_HasData_ReturnsPricingParams()
      {
         // Arrange
         IEnumerable<PricingParam> pricingParams = CommonHelper.GetPricingParams();

         this.jobSelectionsRepository.Setup(x => x.GetSelectedPricingParamByIds(It.IsAny<IEnumerable<int>>()))
             .Returns(Task.FromResult(pricingParams));

         // Act
         var result = await this.selectionService.GetSelectedPricingParams(this.sppIds);

         // Assert
         Assert.NotEmpty(result);
         Assert.Equal(pricingParams.Count(), result.Count());
         Assert.Equal(pricingParams.First().SELECTED_PRICING_PARM_ID, result.First().SelectedPricingParmId);
         Assert.Equal(pricingParams.First().AUTH_COMM_RATE, result.First().AuthCommRate);
         Assert.Equal(pricingParams.First().BASE_FREIGHT_RESERVE_RATE, result.First().BaseFreightReserveRate);
         this.jobSelectionsRepository.Verify(x => x.GetSelectedPricingParamByIds(this.sppIds), Times.Once);
      }

      [Fact]
      public async Task GetShipCycleDetails_HasData_ReturnsShipCycleDetail()
      {
         // Arrange
         IEnumerable<ShipCycle> shipCycles = CommonHelper.GetShipCycles();
         IEnumerable<int> selectionIds = new List<int>() { };
         this.jobSelectionsRepository.Setup(x => x.GetShipCycleDetails(It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(shipCycles));

         // Act
         IEnumerable<ShipCycleViewModel> result = await this.selectionService.GetShipCycleDetails(selectionIds);

         // Assert
         Assert.Equal(shipCycles.ElementAt(0).SELECTION_ID, result.First().SelectionId);
         Assert.Equal(shipCycles.ElementAt(0).SHIP_CYCLE_LENGTH, result.First().ShipCycleLength);
         Assert.Equal(shipCycles.ElementAt(0).UOM, result.First().UnitOfMeasure);
         this.jobSelectionsRepository.Verify(x => x.GetShipCycleDetails(selectionIds), Times.Once);
      }
   }
}
