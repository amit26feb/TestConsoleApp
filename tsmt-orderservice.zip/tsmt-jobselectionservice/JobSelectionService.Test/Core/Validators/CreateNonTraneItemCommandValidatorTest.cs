﻿// <copyright file="CreateNonTraneItemCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.Validators
{
   using System.Linq;
   using JobSelectionService.Core.Commands;
   using JobSelectionService.Core.Validators;
   using JobSelectionService.Core.ViewModels;
   using Xunit;

   public class CreateNonTraneItemCommandValidatorTest
   {
      /// <summary>
      /// Tests create non trane item validation with valid inputs
      /// </summary>
      [Fact]
      public void CreateNonTraneItemCommandValidator_ValidInput_Success()
      {
         // Arrange
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 12886,
            Description = "Adapter Curb",
            VariationType = "M"
         };

         // Act
         var nonTraneItemDetails = new CreateNonTraneItemCommandValidator().Validate(new CreateNonTraneItemCommand(nonTraneItem));

         // Assert
         Assert.True(nonTraneItemDetails.IsValid);
      }

      /// <summary>
      /// Test create non trane item validation with empty variation type
      /// </summary>
      [Fact]
      public void CreateNonTraneItemCommandValidator_EmptyVariationType_ReturnsErrorMessage()
      {
         // Arrange
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 12886,
            Description = "Adapter Curb",
            VariationType = string.Empty
         };

         // Act
         var nonTraneItemDetails = new CreateNonTraneItemCommandValidator().Validate(new CreateNonTraneItemCommand(nonTraneItem));

         // Assert
         Assert.True(nonTraneItemDetails.Errors.Select(a => a.ErrorMessage == "Variation type cannot be empty").FirstOrDefault());
         Assert.False(nonTraneItemDetails.IsValid);
      }

      /// <summary>
      /// Test create non trane item validation with empty description
      /// </summary>
      [Fact]
      public void CreateNonTraneItemCommandValidator_EmptyDescription_ReturnsErrorMessage()
      {
         // Arrange
         var nonTraneItem = new NonTraneItemViewModel()
         {
            JobId = 12886,
            Description = string.Empty,
            VariationType = "M"
         };

         // Act
         var nonTraneItemDetails = new CreateNonTraneItemCommandValidator().Validate(new CreateNonTraneItemCommand(nonTraneItem));

         // Assert
         Assert.True(nonTraneItemDetails.Errors.Select(a => a.ErrorMessage == "Description cannot be empty").FirstOrDefault());
         Assert.False(nonTraneItemDetails.IsValid);
      }
   }
}
