﻿// <copyright file="DeleteNonTraneItemCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.Validators
{
   using JobSelectionService.Core.Commands;
   using JobSelectionService.Core.Validators;
   using Xunit;

   /// <summary>
   /// Non trane item controller test
   /// </summary>
   public class DeleteNonTraneItemCommandValidatorTest
   {
      /// <summary>
      /// Tests delete non trane item validation with valid variation id
      /// </summary>
      [Fact]
      public void RemoveNonTraneItemCommandValidator_ValidInput_Success()
      {
         // Arrange
         int variationId = 12886;

         // Act
         var validationResult = new DeleteNonTraneItemCommandValidator().Validate(new DeleteNonTraneItemCommand(variationId));

         // Assert
         Assert.True(validationResult.IsValid);
      }

      /// <summary>
      /// Test delete non trane item validation with variation id as zero
      /// </summary>
      [Fact]
      public void RemoveNonTraneItemCommandValidator_EmptyVariationType_ReturnsErrorMessage()
      {
         // Arrange
         int variationId = 0;

         // Act
         var validationResult = new DeleteNonTraneItemCommandValidator().Validate(new DeleteNonTraneItemCommand(variationId));

         // Assert
         Assert.False(validationResult.IsValid);
      }
   }
}
