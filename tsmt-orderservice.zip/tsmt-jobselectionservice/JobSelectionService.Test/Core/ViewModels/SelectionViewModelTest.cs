﻿// <copyright file="SelectionViewModelTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.ViewModels
{
   using JobSelectionService.Core.ViewModels;
   using Xunit;

   /// <summary>
   /// Selection view model test
   /// </summary>
   public class SelectionViewModelTest
   {
      /// <summary>
      /// Checks the priced indicator value is 'NA' when selection source is 'N'
      /// </summary>
      [Fact]
      public void PricedIndicator_SelectionSourceIsNone_ReturnsNA()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            SelectionSource = "N"
         };

         // Assert
         Assert.Equal("NA", selection.PricedIndicator);
      }

      /// <summary>
      /// Checks the priced indicator value is 'NP' when selection price complete is not null
      /// </summary>
      [Fact]
      public void PricedIndicator_SelectionPriceCompleteIsNotNull_ReturnsNP()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            SelPriceComplete = "N"
         };

         // Assert
         Assert.Equal("NP", selection.PricedIndicator);
      }

      /// <summary>
      /// Checks the priced indicator value is 'NA' when price control id is null
      /// </summary>
      [Fact]
      public void PricedIndicator_PriceControlIdIsNull_ReturnsNA()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            PriceControlId = null
         };

         // Assert
         Assert.Equal("NA", selection.PricedIndicator);
      }

      /// <summary>
      /// Check the order indicator status as 'Ordered' when sales order is not null
      /// </summary>
      [Fact]
      public void OrderedIndicator_SelesOrderIdIsNotNull_ReturnsOrderedStatus()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            SalesOrderId = 345
         };

         // Assert
         Assert.Equal("O", selection.OrderedIndicator);
      }

      /// <summary>
      /// Check the order indicator status as 'committed' when pending order indicator is not null
      /// </summary>
      [Fact]
      public void OrderedIndicator_PendingOrderedIndicatorAndIsNotNull_ReturnsCommittedStatus()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            PendingOrderInd = "Y"
         };

         // Assert
         Assert.Equal("C", selection.OrderedIndicator);
      }

      /// <summary>
      /// Check the order indicator status as 'None' when sales order id and pending order indicator is null
      /// </summary>
      [Fact]
      public void OrderedIndicator_SalesOrderedIdAndPendingOrderedIndicatorIsNull_ReturnsNoneStatus()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            PendingOrderInd = null,
            SalesOrderId = null
         };

         // Assert
         Assert.Equal("N", selection.OrderedIndicator);
      }

      /// <summary>
      /// Check IsConfiguredItem is 'True' when selection source is committed
      /// </summary>
      [Fact]
      public void IsConfiguredItem_SelectionSourceIsCommitted_ReturnsTrue()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            SelectionSource = "C"
         };

         // Assert
         Assert.True(selection.IsConfiguredItem);
      }

      /// <summary>
      /// Check IsConfiguredItem is 'False' when selection source is not committed
      /// </summary>
      [Fact]
      public void IsConfiguredItem_SelectionSourceIsNotCommitted_ReturnsFalse()
      {
         // Arrange + Act
         SelectionViewModel selection = new SelectionViewModel()
         {
            SelectionSource = "N"
         };

         // Assert
         Assert.False(selection.IsConfiguredItem);
      }
   }
}
