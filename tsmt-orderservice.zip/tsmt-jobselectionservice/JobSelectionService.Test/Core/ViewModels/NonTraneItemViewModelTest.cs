﻿// <copyright file="NonTraneItemViewModelTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.ViewModels
{
   using JobSelectionService.Core.ViewModels;
   using Xunit;

   public class NonTraneItemViewModelTest
   {
      /// <summary>
      /// Checks the provider value is equal to vendor name when variation type is "M"
      /// </summary>
      [Fact]
      public void Provider_VariationTypeIsM_ReturnsVendorName()
      {
         // Arrange + Act
         NonTraneItemViewModel nonTrane = new NonTraneItemViewModel()
         {
            VariationType = "M",
            VendorName = "Others",
            ProviderName = "Munters"
         };

         // Assert
         Assert.Equal("Others", nonTrane.VendorName);
      }

      /// <summary>
      /// Checks the provider value when variation type is other than "M"
      /// </summary>
      [Fact]
      public void Provider_VariationTypeNotM_ReturnsProvider()
      {
         // Arrange + Act
         NonTraneItemViewModel nonTrane = new NonTraneItemViewModel()
         {
            VariationType = "L",
            VendorName = "Others",
            ProviderName = "Munters"
         };

         // Assert
         Assert.Equal("Munters", nonTrane.ProviderName);
      }

      /// <summary>
      /// Checks the equipment value when it is not null
      /// </summary>
      [Fact]
      public void EquipmentNameIsNotNull_ReturnsEquipmentName()
      {
         // Arrange + Act
         NonTraneItemViewModel nonTrane = new NonTraneItemViewModel()
         {
            EquipmentName = "Others",
            ProductName = "Munters"
         };

         // Assert
         Assert.Equal("Others", nonTrane.EquipmentName);
      }

      [Fact]
      public void CostEstimateIsNotNull_ReturnsCostEstimate()
      {
         // Arrange + Act
         NonTraneItemViewModel nonTrane = new NonTraneItemViewModel()
         {
            CostEstimate = 100
         };

         // Assert
         Assert.Equal(100, nonTrane.CostEstimate);
      }
   }
}
