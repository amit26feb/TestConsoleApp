﻿// <copyright file="NonTraneItemRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using Dapper;
   using DataAccess.Core.Abstractions;
   using DataAccess.Paging;
   using JobSelectionService.Common.Constants;
   using JobSelectionService.Configurations;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.Repository;
   using JobSelectionService.Core.ViewModels;
   using JobSelectionService.Test.Common;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using TSMT.DataAccess;
   using TSMT.DataAccess.Models;
   using Xunit;

   /// <summary>
   /// Non trane item repository test
   /// </summary>
   public class NonTraneItemRepositoryTest
   {
      private readonly Mock<IRepository<JobSelectionService.Core.Models.NonTraneItem>> repository;
      private readonly Mock<IConnectionFactory> connectionFactory;
      private readonly NonTraneItemRepository nonTraneItemRepository;
      private readonly Mock<ILogger<NonTraneItem>> logger;
      private readonly Mock<IOptions<CommonConfigurationSettings>> commonConfigurationSettingsMock;
      private readonly CommonConfigurationSettings commonConfigurationSettings;

      /// <summary>
      /// Initializes a new instance of the <see cref="NonTraneItemRepositoryTest"/> class.
      /// NonTraneItemRepositoryTest
      /// </summary>
      public NonTraneItemRepositoryTest()
      {
         this.connectionFactory = new Mock<IConnectionFactory>();
         this.repository = new Mock<IRepository<JobSelectionService.Core.Models.NonTraneItem>>();
         this.logger = new Mock<ILogger<NonTraneItem>>();
         this.commonConfigurationSettingsMock = new Mock<IOptions<CommonConfigurationSettings>>();

         this.commonConfigurationSettings = new CommonConfigurationSettings()
         {
            DisableRebalancing = true
         };
         this.commonConfigurationSettingsMock.Setup(ap => ap.Value).Returns(this.commonConfigurationSettings);
         this.nonTraneItemRepository = new NonTraneItemRepository(this.repository.Object, this.connectionFactory.Object, this.logger.Object, this.commonConfigurationSettingsMock.Object);
      }

      [Fact]
      public void HonorDrAddressId_Execution()
      {
         // Arrange
         int drAddressId = 12;
         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

         // Act
         this.nonTraneItemRepository.HonorDrAddressId(drAddressId);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItems_ValidInput_ReturnsValidData()
      {
         // Arrange
         int jobId = 56704;
         IEnumerable<JobSelectionService.Core.Models.NonTraneItem> nonTraneItems = CommonHelper.GetNonTraneItems();
         DynamicParameters dParam = new DynamicParameters();
         dParam.Add("Field0", ":a");

         QueryResult queryResult = new QueryResult
         {
            Query = "where  description = :a",
            Parameters = dParam
         };
         List<Filter> filters = new List<Filter>
            {
                new Filter() { Field = "description", Operator = "contains", Value = "a" }
            };

         List<FilterCollection> filterCollection = new List<FilterCollection>
            {
                new FilterCollection() { Filters = filters, Logic = "Or" },
            };
         var sortOrder = new List<TSMT.DataAccess.Sort>
         {
              new TSMT.DataAccess.Sort
              {
                    SortBy = "Description",
                    SortDirection = TSMT.DataAccess.SortDirection.Ascending
              }
         };

         TSMT.DataAccess.PagingOptions pagingOptions = new TSMT.DataAccess.PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = sortOrder,
            Filters = filterCollection
         };

         string sortClause = "ORDER BY Description";

         this.repository.Setup(x => x.ExecuteListQuery<NonTraneItem>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(nonTraneItems));
         this.repository.Setup(x => x.BuildSortClause<NonTraneItem>(pagingOptions.Sort)).Returns(sortClause);
         this.repository.Setup(x => x.BuildFilterClause<NonTraneItem>(filterCollection, string.Empty)).Returns(queryResult);

         // Act
         var result = await this.nonTraneItemRepository.GetNonTraneItems(pagingOptions, jobId);

         // Assert
         Assert.Equal(result, nonTraneItems);
         this.repository.Verify(x => x.BuildSortClause<NonTraneItem>(pagingOptions.Sort), Times.Once);
         this.repository.Verify(x => x.BuildFilterClause<NonTraneItem>(filterCollection, string.Empty), Times.Once);
         this.repository.Verify(x => x.ExecuteListQuery<JobSelectionService.Core.Models.NonTraneItem>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItems_ValidInputWithoutFilter_ReturnsValidData()
      {
         // Arrange
         int jobId = 56704;
         IEnumerable<NonTraneItem> nonTraneItems = new List<NonTraneItem>
         {
               new NonTraneItem()
               {
                     VARIATION_ID = 56594,
                     JOB_ID = 56704,
                     SHORT_DESC = "Curb Adapter",
                     PROVIDER_NAME = "CDI",
                     MATL_QTY = 1,
                     TOTAL_COUNT = "1",
                     MATERIAL_COUNT = 3,
                     FACILITATIONFEE_COUNT = 4,
                     LABOR_COUNT = 5,
                     EQUIPMENT_NAME = "Acoustics",
                     VENDOR_NAME = "Annexair",
                     STRATEGIC_PROVIDER = "Y"
               },
               new NonTraneItem()
               {
                      VARIATION_ID = 56594,
                      JOB_ID = 56704,
                      SHORT_DESC = "Curb Adapter",
                      PROVIDER_NAME = "CDI",
                      MATL_QTY = 1,
                      TOTAL_COUNT = "1",
                      EQUIPMENT_NAME = "Annexair",
                      VENDOR_LEAD_TIME_DAYS = 1,
                      VENDOR_NAME = "Custom AHUs"
               }
         };
         DynamicParameters dParam = new DynamicParameters();

         QueryResult queryResult = new QueryResult
         {
            Query = "where  description = :a",
            Parameters = dParam
         };

         List<Filter> filters = new List<Filter>
            {
                new Filter() { Field = "description", Operator = "contains", Value = "a" }
            };

         List<FilterCollection> filterCollection = new List<FilterCollection>
            {
                new FilterCollection() { Filters = filters, Logic = "Or" },
            };
         var sortOrder = new List<TSMT.DataAccess.Sort>
         {
              new TSMT.DataAccess.Sort
              {
                    SortBy = "Description",
                    SortDirection = TSMT.DataAccess.SortDirection.Ascending
              }
         };

         TSMT.DataAccess.PagingOptions pagingOptions = new TSMT.DataAccess.PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = sortOrder,
            Filters = null
         };

         string sortClause = "ORDER BY Description";

         this.repository.Setup(x => x.ExecuteListQuery<NonTraneItem>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(nonTraneItems));
         this.repository.Setup(x => x.BuildSortClause<NonTraneItem>(pagingOptions.Sort)).Returns(sortClause);
         this.repository.Setup(x => x.BuildFilterClause<NonTraneItem>(filterCollection, string.Empty)).Returns(queryResult);

         // Act
         var result = await this.nonTraneItemRepository.GetNonTraneItems(pagingOptions, jobId);

         // Assert
         Assert.Equal(result, nonTraneItems);
         this.repository.Verify(x => x.BuildSortClause<NonTraneItem>(pagingOptions.Sort), Times.Once);
         this.repository.Verify(x => x.BuildFilterClause<NonTraneItem>(filterCollection, string.Empty), Times.Never);
         this.repository.Verify(x => x.ExecuteListQuery<NonTraneItem>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_HasDisableRebalancingAsTrue_ReturnsNonTraneItemWithNoCostForecastAndIsOracle()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         NonTraneItem nonTraneItems = CommonHelper.GetNonTraneItemData();
         this.repository.Setup(x => x.ExecuteQuery<NonTraneItem>(NonTraneItemRepositoryQueries.GetVariationDetailQuery, It.IsAny<object>()))
          .Returns(Task.FromResult(nonTraneItems));

         // Act
         var result = await this.nonTraneItemRepository.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.Null(result.IS_ORACLE);
         this.repository.Verify(x => x.ExecuteQuery<NonTraneItem>(NonTraneItemRepositoryQueries.GetVariationDetailQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetNonTraneItem_HasDisableRebalancingAsFalse_ReturnsNonTraneItemWithCostForecastAndIsOracle()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         NonTraneItem nonTraneItems = CommonHelper.GetNonTraneItemDataWithCostForecast();
         this.commonConfigurationSettings.DisableRebalancing = false;
         this.repository.Setup(x => x.ExecuteQuery<NonTraneItem>(NonTraneItemRepositoryQueries.GetVariationDetailWithCostForecastQuery, It.IsAny<object>()))
          .Returns(Task.FromResult(nonTraneItems));

         // Act
         var result = await this.nonTraneItemRepository.GetNonTraneItem(variationId, jobId);

         // Assert
         Assert.Equal("Y", result.IS_ORACLE);
         this.repository.Verify(x => x.ExecuteQuery<NonTraneItem>(NonTraneItemRepositoryQueries.GetVariationDetailWithCostForecastQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetTagDetails_HasValidData_ReturnsValidData()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         IEnumerable<TagDetail> tagDetails = new List<TagDetail>
         {
            new TagDetail()
            {
               TAG = "curb",
               REFERENCE_UNIT_ID = 1538212,
               TAG_SEQUENCE_NBR = 1
            }
         };
         this.repository.Setup(x => x.ExecuteListQuery<TagDetail>(NonTraneItemRepositoryQueries.GetTagDetailQuery, It.IsAny<object>()))
          .Returns(Task.FromResult(tagDetails));

         // Act
         var result = await this.nonTraneItemRepository.GetTagDetails(variationId, jobId);

         // Assert
         this.repository.Verify(x => x.ExecuteListQuery<TagDetail>(NonTraneItemRepositoryQueries.GetTagDetailQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSequenceNumber_HasValidData_ReturnsSequenceNumber()
      {
         // Arrange
         string tableName = "VARIATION";
         int id = 12567;
         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(id));

         // Act
         var result = await this.nonTraneItemRepository.GetSequenceNumber(tableName, 1);

         // Assert
         Assert.Equal(result, id);
         this.repository.Verify(x => x.ExecuteQuery<int>(NonTraneItemRepositoryQueries.GetSequenceNumberQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetDocumentDetails_HasDocumentDetails_ReturnsDocumentDetails()
      {
         // Arrange
         int jobId = 56704;
         int variationId = 56594;
         IEnumerable<Document> documentDetails = new List<Document>
         {
            new Document()
            {
               DOCUMENT_VERSION = "25Lpz22Bli0ruzJ2aCmY2uSJUXFy0x4C",
               DOCUMENT_NAME = "Variation_TestDocument.txt",
               DOCUMENT_KEY = "Jobs/122/15639/84/90/Variation_TestDocument.txt",
               JOB_DOCUMENT_TYPE_ID = 1
            }
         };
         this.repository.Setup(x => x.ExecuteListQuery<Document>(NonTraneItemRepositoryQueries.GetDocumentDetailQuery, It.IsAny<object>()))
            .Returns(Task.FromResult(documentDetails));

         // Act
         IEnumerable<Document> result = await this.nonTraneItemRepository.GetDocumentDetails(jobId, variationId);

         // Assert
         Assert.Equal(result, documentDetails);
         this.repository.Verify(
            x => x.ExecuteListQuery<Document>(
               NonTraneItemRepositoryQueries.GetDocumentDetailQuery,
               It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId
               && (string)y.GetType().GetProperty("FOLDER_NAME").GetValue(y) == variationId.ToString()
               && (int)y.GetType().GetProperty("JOB_FOLDER_TYPE_ID").GetValue(y) == 5)), Times.Once);
      }
   }
}
