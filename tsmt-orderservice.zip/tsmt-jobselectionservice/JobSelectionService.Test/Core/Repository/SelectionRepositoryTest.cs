﻿// <copyright file="SelectionRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace JobSelectionService.Test.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Text;
   using System.Threading.Tasks;
   using AutoFixture;
   using DataAccess.Core.Abstractions;
   using JobSelectionService.Common;
   using JobSelectionService.Core.Models;
   using JobSelectionService.Core.Repository;
   using JobSelectionService.Core.ViewModels;
   using JobSelectionService.Test.Common;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   public class SelectionRepositoryTest
   {
      private readonly Mock<IRepository<JobSelectionService.Core.Models.Selection>> repository;
      private readonly Mock<IConnectionFactory> connectionFactory;
      private readonly SelectionRepository selectionRepository;
      private readonly IEnumerable<int> selectedPricingParamIds;

      /// <summary>
      /// Initializes a new instance of the <see cref="SelectionRepositoryTest"/> class.
      /// SelectionRepository Test
      /// </summary>
      public SelectionRepositoryTest()
      {
         this.connectionFactory = new Mock<IConnectionFactory>();
         this.repository = new Mock<IRepository<JobSelectionService.Core.Models.Selection>>();
         this.selectionRepository = new SelectionRepository(this.repository.Object);
         this.selectedPricingParamIds = new[] { 8899, 6699 };
      }

      [Fact]
      public void HonorDrAddressId_Execution()
      {
         // Arrange
         int drAddressId = 12;
         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

         // Act
         var repo = new SelectionRepository(this.repository.Object);
         repo.HonorDrAddressId(drAddressId);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
      }

      [Fact]
      public async Task GetSelections_ValidInput_ReturnsValidData()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<Selection> selections = new List<Selection>
         {
            new Selection()
            {
               SELECTION_ID = 11,
               SALESMAN_DESCR = "20-75 Ton Packaged Industrial Rooftop - ",
               UNIT_QTY = 1,
               PROD_CODE = "0293",
               ORDERED_INDICATOR = "O",
               PRICED_INDICATOR = "P",
               IsConfiguredItem = false
            }
         };
         this.repository.Setup(x => x.ExecuteListQuery<Selection>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(selections)).Verifiable();

         // Act
         var repo = new SelectionRepository(this.repository.Object);
         var result = await repo.GetSelections(jobId);

         // Assert
         Assert.True(result.Select(a => a.SELECTION_ID == 11).Any());
         Assert.True(result.Select(a => a.SALESMAN_DESCR == "20-75 Ton Packaged Industrial Rooftop - ").Any());
         Assert.True(result.Select(a => a.UNIT_QTY == 1).Any());
         Assert.True(result.Select(a => a.PROD_CODE == "0293").Any());
         Assert.True(result.Select(a => a.ORDERED_INDICATOR == "O").Any());
         Assert.True(result.Select(a => a.PRICED_INDICATOR == "P").Any());
         Assert.True(result.Select(a => a.IsConfiguredItem == false).Any());
         this.repository.Verify();
      }

      [Fact]
      public async Task GetSeparateBiddables_ValidInput_ReturnsValidData()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<PricingParam> pricingParams = new List<PricingParam>
         {
            new PricingParam()
            {
               SELECTION_ID = 11,
               ORDERED_INDICATOR = "O",
               QUICK_SHIP_FAP = 4.5m,
               PROD_FAMILY_FAP = 6.4m,
               FLEXIBLE_FAP = 4.3m,
               OFFICE_FAP = 7.1m
            }
         };
         this.repository.Setup(x => x.ExecuteListQuery<PricingParam>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(pricingParams)).Verifiable();

         // Act
         var repo = new SelectionRepository(this.repository.Object);
         var result = await repo.GetSeparateBiddables(jobId);

         // Assert
         Assert.True(result.Select(a => a.SELECTION_ID == 11).Any());
         Assert.True(result.Select(a => a.ORDERED_INDICATOR == "O").Any());
         Assert.True(result.Select(a => a.PRICED_INDICATOR == "P").Any());
         Assert.Contains(result, a => a.QUICK_SHIP_FAP == 4.5m && a.PROD_FAMILY_FAP == 6.4m && a.FLEXIBLE_FAP == 4.3m && a.OFFICE_FAP == 7.1m);
         this.repository.Verify();
      }

      [Fact]
      public async Task Get_ValidInput_ReturnsValidData()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<Variation> variations = new List<Variation>
         {
            new Variation()
            {
               SELECTION_ID = 15,
               SHORT_DESC = "ATSC",
               MATL_QTY = 1,
               PROD_CODE = "0913",
               ORDERED_INDICATOR = "O",
               VARIATION_ID = 23
            }
         };
         this.repository.Setup(x => x.ExecuteListQuery<Variation>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(variations)).Verifiable();

         // Act
         var repo = new SelectionRepository(this.repository.Object);
         var result = await repo.GetVariations(jobId);

         // Assert
         Assert.True(result.Select(a => a.SELECTION_ID == 15).Any());
         Assert.True(result.Select(a => a.SHORT_DESC == "ATSC").Any());
         Assert.True(result.Select(a => a.MATL_QTY == 1).Any());
         Assert.True(result.Select(a => a.PROD_CODE == "0913").Any());
         Assert.True(result.Select(a => a.ORDERED_INDICATOR == "O").Any());
         this.repository.Verify();
      }

      /// <summary>
      /// Verifies for the selection data
      /// </summary>
      /// <returns>Selection data</returns>
      [Fact]
      public async Task GetSelectionDetails_HasRecords_ReturnsSelectionData()
      {
         // Arrange
         int jobId = 10987;
         IEnumerable<int> selectionIds = new List<int>() { 230733, 319529 };
         IEnumerable<SelectionInfo> selectionDetails = new List<SelectionInfo>()
         {
            CommonHelper.GetSelectionInfo()
         };
         this.repository.Setup(x => x.ExecuteListQuery<SelectionInfo>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(selectionDetails));
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         var result = await repository.GetSelectionDetails(jobId, selectionIds);

         // Assert
         Assert.Equal(result.First().SELECTION_ID, selectionDetails.First().SELECTION_ID);
         this.repository.Verify(x => x.ExecuteListQuery<SelectionInfo>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSelectionCount_ValidInput_ReturnsValidData()
      {
         // Arrange
         int jobId = 11466;
         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(2)).Verifiable();
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         var result = await repository.GetSelectionCount(jobId);

         // Assert
         Assert.Equal(2, result);
         this.repository.Verify();
      }

      /// <summary>
      /// Verifies for the selected items
      /// </summary>
      /// <returns>Selected items</returns>
      [Fact]
      public async Task GetSelectedItems_HasRecords_ReturnsSelectedItem()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int> { 1234, 4567 };
         int jobId = 123456;
         IEnumerable<Selection> selectedItems = new List<Selection>()
         {
            CommonHelper.GetSelection(123, "test", "abcd")
         };
         this.repository.Setup(x => x.ExecuteListQuery<Selection>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(selectedItems));
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         IEnumerable<Selection> result = await repository.GetSelectedItems(jobId, selectionIds);

         // Assert
         Assert.Equal(result.First().SELECTION_ID, selectedItems.First().SELECTION_ID);
         this.repository.Verify(
               x => x.ExecuteListQuery<Selection>(SelectionRepositoryQueries.SelectedItemGetQuery, It.Is<object>(y =>
               ((y.GetType().GetProperty("JOB_ID") != null) && (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId) &&
               ((y.GetType().GetProperty("SELECTION_IDS") != null) && (IEnumerable<int>)y.GetType().GetProperty("SELECTION_IDS").GetValue(y) == selectionIds)
               && (y.GetType().GetProperties().Length == 2))), Times.Once);
      }

      [Fact]
      public async Task GetBillOfMaterials_HasData_ReturnsBillOfMaterials()
      {
         // Arrange
         int coordinationId = 123456;
         string billOfMaterials = "Abcdst";

         this.repository.Setup(x => x.ExecuteQuery<byte[]>(SelectionRepositoryQueries.BomQuery, It.IsAny<object>())).Returns(Task.FromResult(Encoding.UTF8.GetBytes(billOfMaterials)));
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         var result = await repository.GetBillOfMaterials(coordinationId);

         // Assert
         Assert.Equal(result, Encoding.UTF8.GetBytes(billOfMaterials));
         this.repository.Verify(x => x.ExecuteQuery<byte[]>(SelectionRepositoryQueries.BomQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetBillOfMaterials_HasNullData_ReturnsEmptyBillOfMaterials()
      {
         // Arrange
         int coordinationId = 12356;

         this.repository.Setup(x => x.ExecuteQuery<byte[]>(SelectionRepositoryQueries.BomQuery, It.IsAny<object>())).Returns(Task.FromResult<byte[]>(null));
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         var result = await repository.GetBillOfMaterials(coordinationId);

         // Assert
         Assert.Equal(result, Array.Empty<byte>());
         this.repository.Verify(x => x.ExecuteQuery<byte[]>(SelectionRepositoryQueries.BomQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetAvailableShipCycleVpcs_ValidRequet_ReturnsAvailableShipCycleVpcs()
      {
         // Arrange
         IEnumerable<int> productFamilyIds = new List<int> { 1234, 4567 };

         this.repository.Setup(x => x.ExecuteListQuery<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(productFamilyIds));
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         var result = await repository.GetProductFamilyIds(productFamilyIds);

         // Assert
         Assert.Equal(result, productFamilyIds);
         this.repository.Verify(x => x.ExecuteListQuery<int>(SelectionRepositoryQueries.ShipCycleVpcAvailable, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSiIds_ValidRequest_ReturnsSiIds()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int> { 1234, 4567 };
         int jobId = 123456;
         IEnumerable<Si> sis = new List<Si>()
         {
            CommonHelper.GetSi(1234, 654)
         };
         this.repository.Setup(x => x.ExecuteListQuery<Si>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(sis));
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         var result = await repository.GetSis(jobId, selectionIds);

         // Assert
         Assert.Equal(result, sis);
         this.repository.Verify(x => x.ExecuteListQuery<Si>(SelectionRepositoryQueries.SelectionHasShipCycleVpc, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetBidsSelections_ValidRequest_ReturnsSelections()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int> { 1234, 4567 };
         int jobId = 123456;
         IEnumerable<Selection> selections = new List<Selection>()
         {
            CommonHelper.GetSelection(123, "test", "abcd")
         };
         this.repository.Setup(x => x.ExecuteListQuery<Selection>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(selections));
         var repository = new SelectionRepository(this.repository.Object);

         // Act
         var result = await repository.GetBidsSelections(jobId, selectionIds);

         // Assert
         Assert.Equal(result, selections);
         this.repository.Verify(x => x.ExecuteListQuery<Selection>(SelectionRepositoryQueries.GetSelectionQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSelectionPerformanceDetails_ValidInputWithSelectionIdBasedSearch_ReturnsSelectionPerformanceDetails()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int> { 1246033, 1246021 };
         int jobId = 0;
         Fixture fixture = new Fixture();
         IEnumerable<Selection> selectionPerformances = fixture.Create<IEnumerable<Selection>>();
         selectionPerformances.ElementAt(0).SELECTION_ID = 1246033;
         selectionPerformances.ElementAt(0).VPFC_ID = 1246033;
         StringBuilder query = new StringBuilder(SelectionRepositoryQueries.SelectionPerformanceGetQuery);
         query.Append(SelectionRepositoryQueries.SelectionPerformanceBySelectionIdGetQuery);

         this.repository.Setup(x => x.ExecuteListQuery<Selection>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(selectionPerformances));
         SelectionRepository repository = new SelectionRepository(this.repository.Object);

         // Act
         IEnumerable<Selection> result = await repository.GetSelectionPerformanceDetails(selectionIds, jobId, false);

         // Assert
         Assert.Equal(result, selectionPerformances);
         this.repository.Verify(x => x.ExecuteListQuery<Selection>(query.ToString(), It.Is<object>(y => (IEnumerable<int>)y.GetType().GetProperty("SELECTION_IDS").GetValue(y) == selectionIds)), Times.Once);
      }

      [Fact]
      public async Task GetSelectionPerformanceDetails_ValidInputWithJobIdBasedSearch_ReturnsSelectionPerformanceDetails()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int>();
         int jobId = 123;
         Fixture fixture = new Fixture();
         IEnumerable<Selection> selectionPerformances = fixture.Create<IEnumerable<Selection>>();
         selectionPerformances.ElementAt(0).SELECTION_ID = 1246033;
         selectionPerformances.ElementAt(0).VPFC_ID = 1246033;
         StringBuilder query = new StringBuilder(SelectionRepositoryQueries.SelectionPerformanceGetQuery);
         query.Append(SelectionRepositoryQueries.SelectionPerformanceByJobIdGetQuery);

         this.repository.Setup(x => x.ExecuteListQuery<Selection>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(selectionPerformances));
         SelectionRepository repository = new SelectionRepository(this.repository.Object);

         // Act
         IEnumerable<Selection> result = await repository.GetSelectionPerformanceDetails(selectionIds, jobId, true);

         // Assert
         Assert.Equal(result, selectionPerformances);
         this.repository.Verify(x => x.ExecuteListQuery<Selection>(query.ToString(), It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)), Times.Once);
      }

      [Fact]
      public async Task GetTraneItems_ValidInput_ReturnsValidData()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<JobSelectionService.Core.Models.Selection> selections = new List<JobSelectionService.Core.Models.Selection>
            {
                    new JobSelectionService.Core.Models.Selection()
                    {
                       SELECTION_ID = 567,
                       SALESMAN_DESCR = "abc",
                       UNIT_QTY = 1,
                       PROD_FAMILY_ID = 1234,
                    }
            };
         List<TSMT.DataAccess.Sort> sortAttributes = new List<TSMT.DataAccess.Sort>()
         {
            new TSMT.DataAccess.Sort()
            {
            SortBy = "Qty",
            SortDirection = global::TSMT.DataAccess.SortDirection.Ascending
            }
         };
         TSMT.DataAccess.PagingOptions pagingOptions = new TSMT.DataAccess.PagingOptions()
         {
            Skip = 10,
            Take = 10,
            Sort = sortAttributes
         };
         this.repository.Setup(x => x.ExecuteListQuery<JobSelectionService.Core.Models.Selection>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(selections)).Verifiable();

         // Act
         var repo = new SelectionRepository(this.repository.Object);
         var result = await repo.GetTraneItems(pagingOptions, jobId);

         // Assert
         this.repository.Verify(x => x.ExecuteListQuery<JobSelectionService.Core.Models.Selection>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParamRecords_HasData_ReturnsSelectedParamsPriceDetails()
      {
         // Arrange
         int jobId = 1234;
         int selectionId = 556677;
         IEnumerable<PricingParam> selectedParams = CommonHelper.GetPricingParam(selectionId);
         this.repository.Setup(x => x.ExecuteListQuery<PricingParam>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(selectedParams));
         SelectionRepository repository = new SelectionRepository(this.repository.Object);

         // Act
         IEnumerable<PricingParam> result = await repository.GetSelectedPricingParamRecords(jobId);

         // Assert
         Assert.Equal(result, selectedParams);
         this.repository.Verify(x => x.ExecuteListQuery<PricingParam>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParamByIds_HasData_ReturnsSelectedPricingParams()
      {
         // Arrange
         IEnumerable<PricingParam> pricingParams = CommonHelper.GetPricingParams();
         this.repository.Setup(x => x.ExecuteListQuery<PricingParam>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(pricingParams));

         // Act
         IEnumerable<PricingParam> result = await this.selectionRepository.GetSelectedPricingParamByIds(this.selectedPricingParamIds);

         // Assert
         Assert.Equal(pricingParams, result);
         this.repository.Verify(x => x.ExecuteListQuery<PricingParam>(SelectionRepositoryQueries.SelectedPricingParmByIdsQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetReferenceUnitDetails_HasData_ReturnsSelections()
      {
         // Arrange
         int jobId = 20;
         IEnumerable<Selection> selections = new Fixture().Create<IEnumerable<Selection>>();
         StringBuilder query = new StringBuilder(SelectionRepositoryQueries.ReferenceUnitGetQuery);
         query.Append(SelectionRepositoryQueries.SelectionPerformanceByJobIdGetQuery);

         this.repository.Setup(x => x.ExecuteListQuery<Selection>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(selections));

         // Act
         IEnumerable<Selection> result = await this.selectionRepository.GetReferenceUnitDetails(jobId);

         // Assert
         Assert.Equal(selections, result);
         this.repository.Verify(x => x.ExecuteListQuery<Selection>(query.ToString(), It.Is<object>(y => (int)y.GetType().GetProperty("JOB_ID").GetValue(y) == jobId)), Times.Once);
      }

      [Fact]
      public async Task GetShipCycleDetails_HasData_ReturnsShipCycleData()
      {
         // Arrange
         IEnumerable<int> selectionIds = new List<int>() { 55, 77 };
         IEnumerable<ShipCycle> shipCycles = new Fixture().Create<IEnumerable<ShipCycle>>();
         this.repository.Setup(x => x.ExecuteListQuery<ShipCycle>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(shipCycles));

         // Act
         IEnumerable<ShipCycle> result = await this.selectionRepository.GetShipCycleDetails(selectionIds);

         // Assert
         Assert.Equal(result, shipCycles);
         this.repository.Verify(x => x.ExecuteListQuery<ShipCycle>(SelectionRepositoryQueries.ShipCycleGetQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetShipCycleDetails_ForMoreThanThousandSelections_ReturnsShipCycleData()
      {
         // Arrange
         IEnumerable<int> selectionIds = new Fixture().CreateMany<int>(1500);
         IEnumerable<ShipCycle> shipCycles = new Fixture().Create<IEnumerable<ShipCycle>>();
         var expectedResult = shipCycles.Concat(shipCycles);
         this.repository.Setup(x => x.ExecuteListQuery<ShipCycle>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(shipCycles));

         // Act
         IEnumerable<ShipCycle> result = await this.selectionRepository.GetShipCycleDetails(selectionIds);

         // Assert
         Assert.Equal(result, expectedResult);
         this.repository.Verify(x => x.ExecuteListQuery<ShipCycle>(SelectionRepositoryQueries.ShipCycleGetQuery, It.IsAny<object>()), Times.Exactly(2));
      }
   }
}
