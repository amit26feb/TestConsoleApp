﻿// <copyright file="LegacyFilesControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Controllers
{
   using System.Collections.Generic;
   using System.Net;
   using System.Threading.Tasks;
   using DocumentPackageService.Controllers;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Legacy files controller test
   /// </summary>
   public class LegacyFilesControllerTest
   {
      /// <summary>
      /// Logger mock
      /// </summary>
      private readonly Mock<ILogger<LegacyFilesController>> loggerMock;

      /// <summary>
      /// Legacy files Service mock
      /// </summary>
      private readonly Mock<ILegacyFileService> legacyFileServiceMock;

      /// <summary>
      /// Legacy files controller
      /// </summary>
      private readonly LegacyFilesController controllerUnderTest;

      /// <summary>
      /// Initializes a new instance of the <see cref="LegacyFilesControllerTest"/> class.
      /// </summary>
      public LegacyFilesControllerTest()
      {
         this.loggerMock = new Mock<ILogger<LegacyFilesController>>();
         this.legacyFileServiceMock = new Mock<ILegacyFileService>();
         this.controllerUnderTest = new LegacyFilesController(this.loggerMock.Object, this.legacyFileServiceMock.Object);
      }

      /// <summary>
      /// Get Files returns Bad Request when Dr Address doesn't make sense
      /// </summary>
      /// <returns>Bad Request</returns>
      [Fact]
      public async Task GetFiles_InvalidDrAddress_ReturnsBadRequest()
      {
         // Arrange
         int drAddressId = -1;
         int jobId = 123;
         string errorMessage = "Invalid request - Dr Address Id and Job Id must be > 0.";

         // Act
         var actionResult = await this.controllerUnderTest.GetFiles(drAddressId, jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Contains(errorMessage, ((BadRequestObjectResult)actionResult).Value.ToString());
      }

      /// <summary>
      /// Get Files returns Bad Request when Job Id doesn't make sense
      /// </summary>
      /// <returns>Bad Request</returns>
      [Fact]
      public async Task GetFiles_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int drAddressId = 43;
         int jobId = -1;
         string errorMessage = "Invalid request - Dr Address Id and Job Id must be > 0.";

         // Act
         var actionResult = await this.controllerUnderTest.GetFiles(drAddressId, jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
         Assert.Contains(errorMessage, ((BadRequestObjectResult)actionResult).Value.ToString());
      }

      /// <summary>
      /// Get Files returns No Content when there are no files to return
      /// </summary>
      /// <returns>No Content</returns>
      [Fact]
      public async Task GetFiles_HasNoFiles_ReturnsNoContent()
      {
         // Arrange
         int drAddressId = 43;
         int jobId = 123;
         this.legacyFileServiceMock.Setup(l => l.GetLegacyFiles(drAddressId, jobId))
            .Returns(Task.FromResult<IEnumerable<LegacyFileViewModel>>(null)).Verifiable();

         // Act
         var actionResult = await this.controllerUnderTest.GetFiles(drAddressId, jobId);

         // Assert
         Assert.IsType<NoContentResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
         this.legacyFileServiceMock.Verify();
      }

      /// <summary>
      /// Get Files returns OK with files when there are files to return
      /// </summary>
      /// <returns>No Content</returns>
      [Fact]
      public async Task GetFiles_HasFiles_ReturnsOkAndFiles()
      {
         // Arrange
         int drAddressId = 43;
         int jobId = 123;
         this.legacyFileServiceMock.Setup(l => l.GetLegacyFiles(drAddressId, jobId))
            .Returns(Task.FromResult<IEnumerable<LegacyFileViewModel>>(new List<LegacyFileViewModel>() { new LegacyFileViewModel() })).Verifiable();

         // Act
         var actionResult = await this.controllerUnderTest.GetFiles(drAddressId, jobId);

         // Assert
         Assert.IsType<OkObjectResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
         this.legacyFileServiceMock.Verify();
      }
   }
}
