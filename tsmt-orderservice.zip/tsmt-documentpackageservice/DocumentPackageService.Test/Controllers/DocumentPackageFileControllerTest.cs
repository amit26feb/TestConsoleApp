﻿// <copyright file="DocumentPackageFileControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Controllers
{
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Controllers;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Document package file controller tests
   /// </summary>
   public class DocumentPackageFileControllerTest
   {
      private readonly DocumentPackageFileController controllerUnderTest;
      private readonly Mock<ILogger<DocumentPackageFileController>> mockLogger;
      private readonly Mock<IMediator> mockMediator;
      private readonly Mock<IDocumentPackageService> mockDocumentPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageFileControllerTest"/> class.
      /// </summary>
      public DocumentPackageFileControllerTest()
      {
         this.mockLogger = new Mock<ILogger<DocumentPackageFileController>>();
         this.mockMediator = new Mock<IMediator>();
         this.mockDocumentPackageService = new Mock<IDocumentPackageService>();
         this.controllerUnderTest = new DocumentPackageFileController(this.mockLogger.Object, this.mockMediator.Object, this.mockDocumentPackageService.Object);
      }

      /// <summary>
      /// Tests that the SetStatus method validates input and does not submit a command without valid input
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetStatus_InvalidInputs_ReturnBadRequest()
      {
         // Arrange: various invalid inputs
         List<DocumentPackageFileStatusViewModel> invalidInputs = new List<DocumentPackageFileStatusViewModel>()
         {
             new DocumentPackageFileStatusViewModel() { DocumentPackageId = 0, FileVersion = -1, Status = null },
             new DocumentPackageFileStatusViewModel() { DocumentPackageId = 1, FileVersion = -1, Status = null }
         };

         string expectedError = "Invalid request: docPkgId must be > 0 and fileVersion must be >= 0.";

         foreach (var input in invalidInputs)
         {
            // Act
            IActionResult result = await this.controllerUnderTest.SetStatus(input);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(expectedError, ((BadRequestObjectResult)result).Value.ToString());
         }
      }

      /// <summary>
      /// Tests that the SetStatus method validates input and does submit a command with valid input, but does fail
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetStatus_ValidInputsCouldNotUpdate_ReturnBadRequest()
      {
         // Arrange: various invalid inputs
         List<DocumentPackageFileStatusViewModel> invalidInputs = new List<DocumentPackageFileStatusViewModel>()
         {
             new DocumentPackageFileStatusViewModel() { DocumentPackageId = 1, FileVersion = 0, Status = "Invalid text" },
             new DocumentPackageFileStatusViewModel() { DocumentPackageId = 1, FileVersion = 0, Status = null }
         };

         string expectedError = "Could not update document package file status.";

         foreach (var input in invalidInputs)
         {
            // Act
            IActionResult result = await this.controllerUnderTest.SetStatus(input);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(expectedError, ((BadRequestObjectResult)result).Value.ToString());
         }
      }

      /// <summary>
      /// Tests that the SetStatus method returns an OK result if valid in progress inputs are passed and the updated command is successful
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetStatus_ValidInputsWithInProgressUpdate_ReturnOk()
      {
         // Arrange
         DocumentPackageFileStatusViewModel validInput = new DocumentPackageFileStatusViewModel()
         { DocumentPackageId = 1, FileVersion = 0, Status = GeneratedStatusOptions.InProgress };

         this.mockMediator.Setup(m => m.Send(
            It.Is<UpdateDocumentPackageFileCommand>(cmd => cmd.DocumentPackageFileStatusUpdate == validInput),
            default(CancellationToken))).Returns(Task.FromResult(true)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.SetStatus(validInput);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.mockMediator.Verify();
      }

      /// <summary>
      /// Tests that the SetStatus method returns an OK result if valid uploaded inputs are passed and the updated command is successful
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetStatus_ValidInputsWithUploadedUpdate_ReturnOk()
      {
         // Arrange
         DocumentPackageFileStatusViewModel validInput = new DocumentPackageFileStatusViewModel()
         { DocumentPackageId = 1, FileVersion = 0, Status = GeneratedStatusOptions.Uploaded };

         this.mockMediator.Setup(m => m.Send(
            It.Is<UpdateDocumentPackageFileCommand>(cmd => cmd.DocumentPackageFileStatusUpdate == validInput),
            default(CancellationToken))).Returns(Task.FromResult(true)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.SetStatus(validInput);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.mockMediator.Verify();
      }

      /// <summary>
      /// Tests that the SetStatus method returns a bad request result if valid inputs are passed and the updated command is unsuccessful
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetStatus_ValidInputsWithNoUpdate_ReturnsBadRequest()
      {
         // Arrange
         DocumentPackageFileStatusViewModel validInput = new DocumentPackageFileStatusViewModel()
         { DocumentPackageId = 1, FileVersion = 0, Status = GeneratedStatusOptions.InProgress };

         this.mockMediator.Setup(m => m.Send(
            It.Is<UpdateDocumentPackageFileCommand>(cmd => cmd.DocumentPackageFileStatusUpdate == validInput),
            default(CancellationToken))).Returns(Task.FromResult(false)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.SetStatus(validInput);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         string expectedError = $"Could not update document package file status.";
         Assert.Equal(expectedError, ((BadRequestObjectResult)result).Value.ToString());
         this.mockMediator.Verify();
      }

      /// <summary>
      /// Tests that the SetFilename validates the document package id
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetFilename_BadDocumentPackageId_ReturnBadRequest()
      {
         string expectedError = "Update filename: documentPackageId and version must be > 0 and filename must be populated.";

         // Act
         IActionResult result = await this.controllerUnderTest.SetFilename(-1, 1, "blah");

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal(expectedError, ((BadRequestObjectResult)result).Value.ToString());
      }

      /// <summary>
      /// Tests that the SetFilename validates the version
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetFilename_BadVersion_ReturnBadRequest()
      {
         string expectedError = "Update filename: documentPackageId and version must be > 0 and filename must be populated.";

         // Act
         IActionResult result = await this.controllerUnderTest.SetFilename(1, -1, "blah");

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal(expectedError, ((BadRequestObjectResult)result).Value.ToString());
      }

      /// <summary>
      /// Tests that the SetFilename returns bad request when doc pkg service cannot update the filename
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetFilename_ServiceReturnsFalse_ReturnsBadRequest()
      {
         // Arrange
         int documentPackageId = 123;
         int fileVersion = 1;
         string filename = "blah";
         string expectedError = $"Update filename: could not update the filename for docPackageId: {documentPackageId} and version {fileVersion}.";
         this.mockDocumentPackageService.Setup(d => d.UpdateDocumentPackageFilename(documentPackageId, fileVersion, filename)).Returns(Task.FromResult<bool>(false)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.SetFilename(documentPackageId, fileVersion, filename);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal(expectedError, ((BadRequestObjectResult)result).Value.ToString());
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Tests that the SetFilename returns no content response when it updates filename successfully
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetFilename_ServiceReturnsTrue_ReturnNoContentResult()
      {
         // Arrange
         int documentPackageId = 123;
         int version = 1;
         string filename = "blah";
         this.mockDocumentPackageService.Setup(d => d.UpdateDocumentPackageFilename(documentPackageId, version, filename)).Returns(Task.FromResult<bool>(true)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.SetFilename(documentPackageId, version, filename);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Tests that the SetFileStoreVerison validates the document package id
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetFilestoreVersion_BadDocumentPackageId_ReturnBadRequest()
      {
         string expectedError = "Update filestore version: documentPackageId must be > 0.";

         // Act
         IActionResult result = await this.controllerUnderTest.SetFilestoreVersion(-1, "blah");

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal(expectedError, ((BadRequestObjectResult)result).Value.ToString());
      }

      /// <summary>
      /// Tests that the SetFilestoreVersion returns no content when it cannot update the filestore version id
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetFilestoreVersion_DidNotUpdate_ReturnNoContent()
      {
         // Arrange
         int documentPackageId = 123;
         string filestoreVersionId = "blah";
         this.mockDocumentPackageService.Setup(d => d.UpdateFilestoreVersionId(documentPackageId, filestoreVersionId)).Returns(Task.FromResult<DocumentPackageFilestoreViewModel>(null)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.SetFilestoreVersion(documentPackageId, filestoreVersionId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Tests that the SetFilestoreVersion returns ok when it updates the filestore version id
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task SetFilestoreVersion_ValidInputsWithUpdate_ReturnsOkResult()
      {
         // Arrange
         int documentPackageId = 123;
         string filestoreVersionId = "blah";
         this.mockDocumentPackageService.Setup(d => d.UpdateFilestoreVersionId(documentPackageId, filestoreVersionId)).Returns(Task.FromResult<DocumentPackageFilestoreViewModel>(new DocumentPackageFilestoreViewModel())).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.SetFilestoreVersion(documentPackageId, filestoreVersionId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid job Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetStatus_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         int validDocPkgId = 123;
         int validVersion = 5;

         // Act
         IActionResult result = await this.controllerUnderTest.GetStatus(invalidJobId, validDocPkgId, validVersion);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid document package Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetStatus_InvalidDocPkgId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int invalidDocPkgId = 0;
         int validVersion = 5;

         // Act
         IActionResult result = await this.controllerUnderTest.GetStatus(jobId, invalidDocPkgId, validVersion);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid version will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetStatus_InvalidVersionId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int validDocPkgId = 5;
         int invalidVersion = -1;

         // Act
         IActionResult result = await this.controllerUnderTest.GetStatus(jobId, validDocPkgId, invalidVersion);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call returning a null status returns a NotFound response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetStatus_NullStatus_ReturnsNotFound()
      {
         // Arrange
         int validJobId = 1;
         int validDocPkgId = 5;
         int validVersion = 0;
         this.mockDocumentPackageService.Setup(dps => dps.GetDocumentFileStatus(validJobId, validDocPkgId, validVersion))
            .Returns(Task.FromResult<DocumentPackageFileStatusModel>(null)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetStatus(validJobId, validDocPkgId, validVersion);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call returning an actual status returns an OK response and the status
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetStatus_HasStatus_ReturnsOkAndStatus()
      {
         // Arrange
         int validJobId = 1;
         int validDocPkgId = 5;
         int validVersion = 0;
         DocumentPackageFileStatusModel validStatus = new DocumentPackageFileStatusModel() { Status = "single" };
         this.mockDocumentPackageService.Setup(dps => dps.GetDocumentFileStatus(validJobId, validDocPkgId, validVersion))
            .Returns(Task.FromResult(validStatus)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetStatus(validJobId, validDocPkgId, validVersion);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.mockDocumentPackageService.Verify();
         Assert.Equal(validStatus, ((OkObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid job Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task Download_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         int validDocPkgId = 123;
         int validVersion = 5;

         // Act
         IActionResult result = await this.controllerUnderTest.Download(invalidJobId, validDocPkgId, validVersion);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid document package Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task Download_InvalidDocPkgId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int invalidDocPkgId = 0;
         int validVersion = 5;

         // Act
         IActionResult result = await this.controllerUnderTest.Download(jobId, invalidDocPkgId, validVersion);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid version will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task Download_InvalidVersionId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int validDocPkgId = 5;
         int invalidVersion = -1;

         // Act
         IActionResult result = await this.controllerUnderTest.Download(jobId, validDocPkgId, invalidVersion);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call returning no download info returns bad request
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task Download_NullDownloadInfo_ReturnsBadRequest()
      {
         // Arrange
         int validJobId = 1;
         int validDocPkgId = 5;
         int validVersion = 0;
         this.mockDocumentPackageService.Setup(dps => dps.GetDocumentFileStream(validJobId, validDocPkgId, validVersion))
            .Returns(Task.FromResult<KeyValuePair<string, Stream>?>(null)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.Download(validJobId, validDocPkgId, validVersion);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Could not retrieve document.", ((BadRequestObjectResult)result).Value);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call returning a file stream returns an FileStreamResult and the name
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task Download_HasStatus_ReturnsFileStreamAndStatus()
      {
         // Arrange
         int validJobId = 1;
         int validDocPkgId = 5;
         int validVersion = 0;
         string fileName = "YourDocument.docx";
         using (Stream someStream = new MemoryStream())
         {
            this.mockDocumentPackageService.Setup(dps => dps.GetDocumentFileStream(validJobId, validDocPkgId, validVersion))
               .Returns(Task.FromResult<KeyValuePair<string, Stream>?>(new KeyValuePair<string, Stream>(fileName, someStream))).Verifiable();

            // Act
            IActionResult result = await this.controllerUnderTest.Download(validJobId, validDocPkgId, validVersion);

            // Assert
            Assert.IsType<FileStreamResult>(result);
            FileStreamResult typedResult = result as FileStreamResult;
            Assert.Equal(fileName, typedResult.FileDownloadName);
            Assert.Equal(someStream, typedResult.FileStream);
         }

         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid job Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task DownloadMostRecent_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         int validDocPkgId = 123;

         // Act
         IActionResult result = await this.controllerUnderTest.DownloadMostRecent(invalidJobId, validDocPkgId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to the controller with an invalid document package Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task DownloadMostRecent_InvalidDocPkgId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int invalidDocPkgId = 0;

         // Act
         IActionResult result = await this.controllerUnderTest.DownloadMostRecent(jobId, invalidDocPkgId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call returning no download info returns bad request
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task DownloadMostRecent_NullDownloadInfo_ReturnsBadRequest()
      {
         // Arrange
         int validJobId = 1;
         int validDocPkgId = 5;
         this.mockDocumentPackageService.Setup(dps => dps.GetDocumentFileStream(validJobId, validDocPkgId, null))
            .Returns(Task.FromResult<KeyValuePair<string, Stream>?>(null)).Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.DownloadMostRecent(validJobId, validDocPkgId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Could not retrieve document.", ((BadRequestObjectResult)result).Value);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call returning a file stream returns an FileStreamResult and the name
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task DownloadMostRecent_HasStatus_ReturnsFileStreamAndStatus()
      {
         // Arrange
         int validJobId = 1;
         int validDocPkgId = 5;
         string fileName = "YourDocument.docx";
         using (Stream someStream = new MemoryStream())
         {
            this.mockDocumentPackageService.Setup(dps => dps.GetDocumentFileStream(validJobId, validDocPkgId, null))
               .Returns(Task.FromResult<KeyValuePair<string, Stream>?>(new KeyValuePair<string, Stream>(fileName, someStream))).Verifiable();

            // Act
            IActionResult result = await this.controllerUnderTest.DownloadMostRecent(validJobId, validDocPkgId);

            // Assert
            Assert.IsType<FileStreamResult>(result);
            FileStreamResult typedResult = result as FileStreamResult;
            Assert.Equal(fileName, typedResult.FileDownloadName);
            Assert.Equal(someStream, typedResult.FileStream);
         }

         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to GetFileHistories with an invalid job Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetFileHistories_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         int validDocPkgId = 123;

         // Act
         IActionResult result = await this.controllerUnderTest.GetFileHistories(invalidJobId, validDocPkgId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to GetFileHistories with an invalid document package Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetFileHistories_InvalidDocPkgId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int invalidDocPkgId = 0;

         // Act
         IActionResult result = await this.controllerUnderTest.GetFileHistories(jobId, invalidDocPkgId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to GetFileHistories returning no download info returns bad request
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetFileHistories_NoFileHistories_ReturnsNotFound()
      {
         // Arrange
         int jobId = 1;
         int docPkgId = 2;
         this.mockDocumentPackageService.Setup(dps => dps.GetDocumentPackageFileHistories(jobId, docPkgId))
            .Returns(Task.FromResult(Enumerable.Empty<DocumentPackageFileHistoryViewModel>()))
            .Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetFileHistories(jobId, docPkgId);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to GetFileHistories returning download info returns ok request
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetFileHistories_HasFileHistories_ReturnsOk()
      {
         // Arrange
         int jobId = 1;
         int docPkgId = 2;
         IEnumerable<DocumentPackageFileHistoryViewModel> hisStory = new List<DocumentPackageFileHistoryViewModel>() { new DocumentPackageFileHistoryViewModel { } }.AsEnumerable();
         this.mockDocumentPackageService.Setup(dps => dps.GetDocumentPackageFileHistories(jobId, docPkgId))
            .Returns(Task.FromResult(hisStory))
            .Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetFileHistories(jobId, docPkgId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(hisStory, ((OkObjectResult)result).Value);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to GetMostRecentlyGeneratedFileHistory with an invalid job Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetMostRecentlyGeneratedFileHistory_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         int validDocPkgId = 123;

         // Act
         IActionResult result = await this.controllerUnderTest.GetMostRecentlyGeneratedFileHistory(invalidJobId, validDocPkgId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to GetMostRecentlyGeneratedFileHistory with an invalid document package Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetMostRecentlyGeneratedFileHistory_InvalidDocPkgId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int invalidDocPkgId = 0;

         // Act
         IActionResult result = await this.controllerUnderTest.GetMostRecentlyGeneratedFileHistory(jobId, invalidDocPkgId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentPackageId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to GetMostRecentlyGeneratedFileHistory returning no download info returns bad request
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetMostRecentlyGeneratedFileHistory_NoFileHistories_ReturnsNotFound()
      {
         // Arrange
         int jobId = 1;
         int docPkgId = 2;
         this.mockDocumentPackageService.Setup(dps => dps.GetMostRecentlyGeneratedDocumentPackageFileHistory(jobId, docPkgId))
            .Returns(Task.FromResult<DocumentPackageMostRecentFileHistoryViewModel>(null))
            .Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetMostRecentlyGeneratedFileHistory(jobId, docPkgId);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to GetMostRecentlyGeneratedFileHistory returning download info returns ok request
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetMostRecentlyGeneratedFileHistory_HasFileHistories_ReturnsOk()
      {
         // Arrange
         int jobId = 1;
         int docPkgId = 2;
         DocumentPackageMostRecentFileHistoryViewModel history = new DocumentPackageMostRecentFileHistoryViewModel();
         this.mockDocumentPackageService.Setup(dps => dps.GetMostRecentlyGeneratedDocumentPackageFileHistory(jobId, docPkgId))
            .Returns(Task.FromResult(history))
            .Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetMostRecentlyGeneratedFileHistory(jobId, docPkgId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(history, ((OkObjectResult)result).Value);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to GetPackageDocument with an invalid job Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetPackageDocument_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         int validDocTypeId = 123;

         // Act
         IActionResult result = await this.controllerUnderTest.GetPackageDocument(invalidJobId, validDocTypeId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentTypeId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to GetPackageDocument with an invalid document type Id will return a BadRequest response
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetPackageDocument_InvalidDocPkgId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 1;
         int invalidDocTypeId = 0;

         // Act
         IActionResult result = await this.controllerUnderTest.GetPackageDocument(jobId, invalidDocTypeId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         Assert.Equal("Invalid request: jobId must be > 0 and documentTypeId must be > 0.", ((BadRequestObjectResult)result).Value);
      }

      /// <summary>
      /// Verifies that a call to GetPackageDocument will return a NotFoundResult
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetPackageDocument_ValidInputWithNoDocumentPackage_NotFoundResult()
      {
         // Arrange
         int jobId = 1;
         int docTypeId = 2;
         this.mockDocumentPackageService.Setup(dps => dps.GetPackageDocument(jobId, docTypeId))
            .Returns(Task.FromResult(Enumerable.Empty<DocumentPackageFileViewModel>()))
            .Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetPackageDocument(jobId, docTypeId);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.mockDocumentPackageService.Verify();
      }

      /// <summary>
      /// Verifies that a call to GetPackageDocument will return a package document files
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetPackageDocument_HasPackageDocument_ReturnsOk()
      {
         // Arrange
         int jobId = 1;
         int docTypeId = 2;
         IEnumerable<DocumentPackageFileViewModel> documentPackageFile = new List<DocumentPackageFileViewModel>() { new DocumentPackageFileViewModel { } }.AsEnumerable();
         this.mockDocumentPackageService.Setup(dps => dps.GetPackageDocument(jobId, docTypeId))
            .Returns(Task.FromResult(documentPackageFile))
            .Verifiable();

         // Act
         IActionResult result = await this.controllerUnderTest.GetPackageDocument(jobId, docTypeId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(documentPackageFile, ((OkObjectResult)result).Value);
         this.mockDocumentPackageService.Verify();
      }
   }
}
