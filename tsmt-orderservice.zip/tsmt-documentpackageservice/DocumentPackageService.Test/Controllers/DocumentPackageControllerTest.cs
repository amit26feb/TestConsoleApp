﻿// <copyright file="DocumentPackageControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Controllers;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Document package controller test
   /// </summary>
   public class DocumentPackageControllerTest
   {
      /// <summary>
      /// Document package view model for passing for using in the test cases
      /// </summary>
      private static readonly DocPackageViewModel DocPackModel1 = new DocPackageViewModel
      {
         Package = new DocumentPackageViewModel
         {
            BusinessStreamId = 1,
            DocumentTypeId = 1,
            SalesOfficeCode = "AC",
            DocumentTypeName = "EqvProposal",
            DrAddressId = 127,
            JobId = 8401
         },
         PackageFile = new DocumentPackageFileViewModel
         {
            LegalEntityId = 1,
            TermsAndConditionsId = 1
         }
      };

      /// <summary>
      /// Document package view model for passing for using in the test cases
      /// </summary>
      private static readonly DocPackageViewModel DocPackModel2 = new DocPackageViewModel
      {
         Package = new DocumentPackageViewModel
         {
            BusinessStreamId = 1,
            DocumentTypeId = 1,
            SalesOfficeCode = "AE",
            DrAddressId = 127,
            JobId = 8401,
            DocumentPackageId = 1
         },
         PackageFile = new DocumentPackageFileViewModel
         {
            LegalEntityId = 1,
            TermsAndConditionsId = 1,
            DocumentPackageId = 1,
            DocumentPackageFileId = 1
         }
      };

      /// <summary>
      /// Mediator mock
      /// </summary>
      private readonly Mock<IMediator> mediatorMock;

      /// <summary>
      /// Logger mock
      /// </summary>
      private readonly Mock<ILogger<DocumentPackageController>> loggerMock;

      /// <summary>
      /// Document Package Service mock
      /// </summary>
      private readonly Mock<IDocumentPackageService> documentPackageServiceMock;

      /// <summary>
      /// Document package controller
      /// </summary>
      private readonly DocumentPackageController documentPackageController;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageControllerTest"/> class.
      /// </summary>
      public DocumentPackageControllerTest()
      {
         this.mediatorMock = new Mock<IMediator>();
         this.loggerMock = new Mock<ILogger<DocumentPackageController>>();
         this.documentPackageServiceMock = new Mock<IDocumentPackageService>();
         this.documentPackageController = new DocumentPackageController(this.mediatorMock.Object, this.loggerMock.Object, this.documentPackageServiceMock.Object);
      }

      /// <summary>
      /// Loading data for the create document package test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for CreateDocumentPackage</returns>
      public static IEnumerable<object[]> GetDataForCreateDocumentPackage(int numTests)
      {
         string messageWhenRequestNull = "Invalid request - Request parameter can not be null.";
         string messageWhenInsertFailed = "Unexpected error occurred while creating the document package.";

         // <summary>
         // object[] definition
         // </summary>
         // <param name="request">Document package view model </param>
         // <param name="timesCalled">Times the method is called</param>
         // <param name="statusCode">HttpStatusCode value</param>
         // <param name="errorMessage">Error message for different status</param>
         // <param name="statusCodeValue">HttpStatusCode value for different action results</param>
         // <param name="mediatorResponse">response from the mediator</param>
         var allData = new List<object[]>
            {
                // Scenario 1: Null request will return BadRequest result
                new object[] { null, Times.Never(), HttpStatusCode.BadRequest, messageWhenRequestNull, new BadRequestObjectResult(messageWhenRequestNull).StatusCode, null },

                // Scenario 2: Valid request but insert failed returns BadRequest result
                new object[] { DocPackModel1, Times.Once(), HttpStatusCode.BadRequest, messageWhenInsertFailed, new BadRequestObjectResult(messageWhenInsertFailed).StatusCode, null },

                // Scenario 3: Valid reuest when inserted successfullt returns Ok result
                new object[] { DocPackModel1, Times.Once(), HttpStatusCode.OK, string.Empty, new OkObjectResult(1).StatusCode, DocPackModel2 },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Loading data for the update document package test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for UpdateDocumentPackage</returns>
      public static IEnumerable<object[]> GetDataForUpdateDocumentPackage(int numTests)
      {
         string messageInvalidRequest = "Invalid request - Please check the request parameter.";
         string messageWhenUpdateFailed = "Unexpected error occurred while updating the document package.";

         // <summary>
         // object[] definition
         // </summary>
         // <param name="request">Document package view model </param>
         // <param name="timesCalled">Times the method is called</param>
         // <param name="statusCode">HttpStatusCode value</param>
         // <param name="errorMessage">Error message for different status</param>
         // <param name="statusCodeValue">HttpStatusCode value for different action results</param>
         // <param name="mediatorResponse">response from the mediator</param>
         var allData = new List<object[]>
            {
                // Scenario 1: Null request will return BadRequest result
                new object[] { null, 1, Times.Never(), HttpStatusCode.BadRequest, messageInvalidRequest, new BadRequestObjectResult(messageInvalidRequest).StatusCode, null },

                // Scenario 2: invalid document package id will return BadRequest result
                new object[] { DocPackModel2, 0, Times.Never(), HttpStatusCode.BadRequest, messageInvalidRequest, new BadRequestObjectResult(messageInvalidRequest).StatusCode, null },

                // Scenario 3: valid document package id but different in request payload will return BadRequest result
                new object[] { DocPackModel2, 2, Times.Never(), HttpStatusCode.BadRequest, messageInvalidRequest, new BadRequestObjectResult(messageInvalidRequest).StatusCode, null },

                // Scenario 4: Valid request but update failed returns BadRequest result
                new object[] { DocPackModel2, 1, Times.Once(), HttpStatusCode.BadRequest, messageWhenUpdateFailed, new BadRequestObjectResult(messageWhenUpdateFailed).StatusCode, null },

                // Scenario 5: Valid reuest when updated successfullt returns Ok result
                new object[] { DocPackModel2, 1, Times.Once(), HttpStatusCode.OK, string.Empty, new OkObjectResult(1).StatusCode, DocPackModel2 },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test create document package for different scenarios
      /// </summary>
      /// <param name="request">Document package view model </param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="statusCode">HttpStatusCode value</param>
      /// <param name="errorMessage">Error message for different status</param>
      /// <param name="statusCodeValue">HttpStatusCode value for different action results</param>
      /// <param name="response">response from the mediator</param>
      /// <returns>Returns action result</returns>
      [Theory]
      [MemberData(nameof(GetDataForCreateDocumentPackage), parameters: 3)]
      public async Task CreateDocumentPackage__ForThreeDifferentRequests_ReturnsActionResult(DocPackageViewModel request, Times timesCalled, HttpStatusCode statusCode, string errorMessage, int statusCodeValue, DocPackageViewModel response)
      {
         var createDocumentPackageCommand = new CreateDocumentPackageCommand(request);

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateDocumentPackageCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(response));

         IActionResult actionResult = await this.documentPackageController.Create(request);

         Assert.Equal((int)statusCode, statusCodeValue);
         if (!string.IsNullOrEmpty(errorMessage))
         {
            Assert.Contains(errorMessage, ((ObjectResult)actionResult).Value.ToString());
         }
         else
         {
            Assert.NotNull(actionResult);
            Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
            Assert.Equal(response.Package.DocumentPackageId, ((DocPackageViewModel)((ObjectResult)actionResult).Value).Package.DocumentPackageId);
         }

         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateDocumentPackageCommand>(), default(CancellationToken)), timesCalled);
      }

      /// <summary>
      /// Get document package details for invalid input
      /// </summary>
      /// <returns>No content</returns>
      [Fact]
      public async Task GetDocumentPackageDetails_InvalidInput_ReturnsNoContent()
      {
         // Arrange
         DocPkgDetailsViewModel documentPackageList = null;

         this.documentPackageServiceMock.Setup(x => x.GetDocPkgDetails(It.IsAny<int>()))
                .Returns(Task.FromResult(documentPackageList));

         // Act
         var actionResult = await this.documentPackageController.GetDocumentPackageDetails(1112);

         // Assert
         Assert.IsType<NoContentResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
         this.documentPackageServiceMock.Verify(x => x.GetDocPkgDetails(1112), Times.Once);
      }

      /// <summary>
      /// Get document packages details - valid inputs
      /// </summary>
      /// <returns>Document Package Details for the given package reference id </returns>
      [Fact]
      public async Task GetDocumentPackages_ValidInput_ReturnsResult()
      {
         // Arrange
         DocPkgDetailsViewModel documentPackageList = new DocPkgDetailsViewModel()
         {
            DocumentPackageId = 1,
            Name = "Doc Package 6",
            Description = "CKL - COJO Test Sample Desc",
            UpdatedOn = System.DateTime.Now,
            CreatedOn = System.DateTime.Now,
            UpdatedBy = "Ingalls, Linda"
         };

         this.documentPackageServiceMock.Setup(x => x.GetDocPkgDetails(1))
                .Returns(Task.FromResult(documentPackageList));

         // Act
         var actionResult = await this.documentPackageController.GetDocumentPackageDetails(1);

         // Assert
         Assert.IsType<OkObjectResult>(actionResult);
         Assert.Equal(documentPackageList.DocumentPackageId, ((DocPkgDetailsViewModel)((ObjectResult)actionResult).Value).DocumentPackageId);
         this.documentPackageServiceMock.Verify(x => x.GetDocPkgDetails(1), Times.Once);
      }

      /// <summary>
      /// Get document package details when reference id is 0
      /// </summary>
      /// <returns>Bad request</returns>
      [Fact]
      public async Task GetDocumentPackageDetails_InvalidInput_ReturnsBadRequest()
      {
         // Act
         var actionResult = await this.documentPackageController.GetDocumentPackageDetails(0);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
      }

      /// <summary>
      /// Method to test update document package for different scenarios
      /// </summary>
      /// <param name="request">Document package view model </param>
      /// <param name="docPackageId">Document package id </param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="statusCode">HttpStatusCode value</param>
      /// <param name="errorMessage">Error message for different status</param>
      /// <param name="statusCodeValue">HttpStatusCode value for different action results</param>
      /// <param name="response">response from the mediator</param>
      /// <returns>Returns action result</returns>
      [Theory]
      [MemberData(nameof(GetDataForUpdateDocumentPackage), parameters: 5)]
      public async Task UpdateDocumentPackage_ForDifferentRequest_ReturnsActionResult(DocPackageViewModel request, int docPackageId, Times timesCalled, HttpStatusCode statusCode, string errorMessage, int statusCodeValue, DocPackageViewModel response)
      {
         var updateDocumentPackageCommand = new UpdateDocumentPackageCommand(request);

         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateDocumentPackageCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(response));

         IActionResult actionResult = await this.documentPackageController.Update(request, docPackageId);

         Assert.Equal((int)statusCode, statusCodeValue);
         if (!string.IsNullOrEmpty(errorMessage))
         {
            Assert.Contains(errorMessage, ((ObjectResult)actionResult).Value.ToString());
         }
         else
         {
            Assert.NotNull(actionResult);
            Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)actionResult).StatusCode);
            Assert.Equal(response.Package.DocumentPackageId, ((DocPackageViewModel)((ObjectResult)actionResult).Value).Package.DocumentPackageId);
         }

         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateDocumentPackageCommand>(), default(CancellationToken)), timesCalled);
      }

      /// <summary>
      /// Get document packages detail with invalid input
      /// </summary>
      /// <returns>No content</returns>
      [Fact]
      public async Task GetDocumentPackages_InvalidInput_ReturnsNoContent()
      {
         // Arrange
         var jobId = 8401;
         IEnumerable<DocumentPackageSummaryViewModel> documentpackagelist = null;

         this.documentPackageServiceMock.Setup(x => x.GetDocumentPackages(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.FromResult(documentpackagelist));

         // Act
         var actionResult = await this.documentPackageController.GetDocumentPackages(jobId, "Ingersoll Rand", "PKG_NAME");

         // Assert
         Assert.IsType<NoContentResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
         this.documentPackageServiceMock.Verify(x => x.GetDocumentPackages(jobId, "Ingersoll Rand", "PKG_NAME"), Times.Once);
      }

      /// <summary>
      /// Get document packages list with valid inputs
      /// </summary>
      /// <returns>Document packages detail list</returns>
      [Fact]
      public async Task GetDocumentPackagesList_ValidInput_ReturnsResult()
      {
         // Arrange
         var jobId = 8401;
         IEnumerable<DocumentPackageSummaryViewModel> documentpackagelist = new List<DocumentPackageSummaryViewModel>
         {
            new DocumentPackageSummaryViewModel()
                    {
                        DocumentType = "Equipment Proposal",
                        DocPkgId = 1,
                        Name = "Doc Package 6",
                        Description = "CKL - COJO Test Sample Desc",
                        ModifiedDate = System.DateTime.Now,
                        CreatedDate = System.DateTime.Now,
                        ModifiedUser = "Ingalls, Linda",
                        Status = "Complete",
                        FileGeneratedByUser = "Ingalls, Linda",
                        FileGeneratedDate = System.DateTime.Now,
                        LastGeneratedFileVersion = 1,
                        LastUploadedFileVersion = 2,
                        FileUploadedDate = System.DateTime.Now,
                        FileUploadedByUser = "Ingalls, Linda"
                    }
         };

         this.documentPackageServiceMock.Setup(x => x.GetDocumentPackages(jobId, "Doc Package", It.IsAny<string>()))
                .Returns(Task.FromResult(documentpackagelist));

         // Act
         var actionResult = await this.documentPackageController.GetDocumentPackages(jobId, "Doc Package", string.Empty);

         // Assert
         Assert.IsType<OkObjectResult>(actionResult);
         Assert.Equal(documentpackagelist.Count(), ((IEnumerable<DocumentPackageSummaryViewModel>)((ObjectResult)actionResult).Value).Count());
         Assert.Equal(documentpackagelist.FirstOrDefault().Name, ((IEnumerable<DocumentPackageSummaryViewModel>)((ObjectResult)actionResult).Value).FirstOrDefault().Name);
         this.documentPackageServiceMock.Verify(x => x.GetDocumentPackages(jobId, "Doc Package", string.Empty), Times.Once);
      }
   }
}
