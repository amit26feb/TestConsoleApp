﻿// <copyright file="DocumentFolderControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Controllers
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Controllers;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Document folder controller test
   /// </summary>
   public class DocumentFolderControllerTest
   {
      /// <summary>
      /// Document folder view model for passing for using in the test cases
      /// </summary>
      private static readonly DocumentFolderViewModel DocFolder1 = new DocumentFolderViewModel
      {
         FolderId = 0,
         FolderName = "Sample",
         FolderSource = "user",
         CreatedByUser = "user",
         CreatedDate = DateTime.Now,
         DrAddressId = 101,
         FolderParentId = 0,
         JobId = 12345,
         LastModifiedDate = DateTime.Now,
         LastModifiedUser = "user",
      };

      private static readonly IEnumerable<DocumentFolderViewModel> DocFolder2 = new List<DocumentFolderViewModel>
      {
         new DocumentFolderViewModel
         {
            FolderId = 1,
            FolderName = "Sample",
            FolderSource = "user",
            CreatedByUser = "user",
            CreatedDate = DateTime.Now,
            DrAddressId = 101,
            FolderParentId = 0,
            JobId = 12345,
            LastModifiedDate = DateTime.Now,
            LastModifiedUser = "user",
         },
         new DocumentFolderViewModel
         {
            FolderId = 2,
            FolderName = "TestFolder",
            FolderSource = "user",
            CreatedByUser = "user",
            CreatedDate = DateTime.Now,
            DrAddressId = 101,
            FolderParentId = 0,
            JobId = 12345,
            LastModifiedDate = DateTime.Now,
            LastModifiedUser = "user",
         }
      };

      /// <summary>
      /// Mediator mock
      /// </summary>
      private readonly Mock<IMediator> mediatorMock;

      /// <summary>
      /// Logger mock
      /// </summary>
      private readonly Mock<ILogger<DocumentFolderController>> loggerMock;

      /// <summary>
      /// Document folder controller
      /// </summary>
      private readonly DocumentFolderController documentFolderController;

      /// <summary>
      /// Document Folder Service mock
      /// </summary>
      private readonly Mock<IDocumentFolderService> documentFolderServiceMock;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentFolderControllerTest"/> class.
      /// </summary>
      public DocumentFolderControllerTest()
      {
         this.mediatorMock = new Mock<IMediator>();
         this.loggerMock = new Mock<ILogger<DocumentFolderController>>();
         this.documentFolderServiceMock = new Mock<IDocumentFolderService>();
         this.documentFolderController = new DocumentFolderController(this.mediatorMock.Object, this.loggerMock.Object, this.documentFolderServiceMock.Object);
      }

      /// <summary>
      /// Method to test Create a document folder inserted successfully
      /// </summary>
      /// <returns>Ok result</returns>
      [Fact]
      public async Task CreateDocumentFolder_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateDocumentFolderCommand>(), default(CancellationToken))).Returns(Task.FromResult(DocFolder2));

         // Act
         IActionResult actionResult = await this.documentFolderController.Create(DocFolder1);

         // Assert
         Assert.IsType<OkObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateDocumentFolderCommand>(), default(CancellationToken)), Times.Once);
      }

      /// <summary>
      /// Method to test Create a document folder for invalid request returns bad request
      /// </summary>
      /// <returns>Bad request</returns>
      [Fact]
      public async Task CreateDocumentFolder_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         DocumentFolderViewModel request = null;
         string errorMessage = "Invalid request - Request parameter can not be null.";

         // Act
         IActionResult actionResult = await this.documentFolderController.Create(request);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Contains(errorMessage, ((BadRequestObjectResult)actionResult).Value.ToString());
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateDocumentFolderCommand>(), default(CancellationToken)), Times.Never);
      }

      /// <summary>
      /// Method to test Create Custom Sender for valid request but insert failed returns conflict
      /// </summary>
      /// <returns>Bad request</returns>
      [Fact]
      public async Task CreateDocumentFolder_ValidRequestButInsertFailed_ReturnsBadRequest()
      {
         // Arrange
         IEnumerable<DocumentFolderViewModel> response = null;
         string errorMessage = "Unexpected error occurred while creating the document folder.";
         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateDocumentFolderCommand>(), default(CancellationToken))).Returns(Task.FromResult(response));

         // Act
         IActionResult actionResult = await this.documentFolderController.Create(DocFolder1);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Contains(errorMessage, ((BadRequestObjectResult)actionResult).Value.ToString());
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateDocumentFolderCommand>(), default(CancellationToken)), Times.Once);
      }

      /// <summary>
      /// Get folder details with invalid request
      /// </summary>
      /// <returns>Bad request</returns>
      [Fact]
      public async Task GetFolders_InvalidInput_ReturnsBadRequest()
      {
         // Arrange
         var jobId = 0;

         // Act
         var actionResult = await this.documentFolderController.GetFolders(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.BadRequest, ((BadRequestObjectResult)actionResult).StatusCode);
      }

      /// <summary>
      /// Get Folder details for valid input
      /// </summary>
      /// <returns>No content</returns>
      [Fact]
      public async Task GetFolders_ValidInput_ReturnsNoContent()
      {
         // Arrange
         var jobId = 5;
         List<DocumentFolderViewModel> folderViewModel = null;

         this.documentFolderServiceMock.Setup(x => x.GetFolders(It.IsAny<int>()))
                .Returns(Task.FromResult<IEnumerable<DocumentFolderViewModel>>(folderViewModel));

         // Act
         var actionResult = await this.documentFolderController.GetFolders(jobId);

         // Assert
         Assert.IsType<NoContentResult>(actionResult);
         Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)actionResult).StatusCode);
         this.documentFolderServiceMock.Verify(x => x.GetFolders(jobId), Times.Once);
      }

      /// <summary>
      /// Get Folder details for valid input with result
      /// </summary>
      /// <returns>Ok result</returns>
      [Fact]
      public async Task GetFolders_ValidInput_ReturnsOkResult()
      {
         // Arrange
         var jobId = 5;
         List<DocumentFolderViewModel> folders = new List<DocumentFolderViewModel>
         {
            new DocumentFolderViewModel()
            {
               JobId = 5,
               FolderId = 1,
               FolderName = "Folder1",
               FolderParentId = 0,
               FolderSource = "User",
               DrAddressId = 101,
               CreatedByUser = "abcd",
            }
         };

         this.documentFolderServiceMock.Setup(x => x.GetFolders(It.IsAny<int>()))
                .Returns(Task.FromResult<IEnumerable<DocumentFolderViewModel>>(folders));

         // Act
         var actionResult = await this.documentFolderController.GetFolders(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(actionResult);
         Assert.Equal(folders.FirstOrDefault().FolderName, ((IEnumerable<DocumentFolderViewModel>)((ObjectResult)actionResult).Value).FirstOrDefault().FolderName);
         Assert.Equal(folders.Count, ((IEnumerable<DocumentFolderViewModel>)((ObjectResult)actionResult).Value).Count());
         this.documentFolderServiceMock.Verify(x => x.GetFolders(jobId), Times.Once);
      }
   }
}
