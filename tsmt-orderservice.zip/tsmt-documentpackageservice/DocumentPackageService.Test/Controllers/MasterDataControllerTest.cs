﻿// <copyright file="MasterDataControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Controllers
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using DocumentPackageService.Controllers;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// MasterDataControllerTest
   /// </summary>
   public class MasterDataControllerTest
   {
      private readonly Mock<IMediator> mediator;
      private readonly Mock<IMasterDataService> masterDataService;
      private readonly Mock<ILogger<MasterDataController>> logger;

      /// <summary>
      /// Initializes a new instance of the <see cref="MasterDataControllerTest"/> class.
      /// </summary>
      public MasterDataControllerTest()
      {
         this.mediator = new Mock<IMediator>();
         this.masterDataService = new Mock<IMasterDataService>();
         this.logger = new Mock<ILogger<MasterDataController>>();
      }

      /// <summary>
      /// GetBusinessStreams when there is no value returns no content
      /// </summary>
      [Fact]
      public void GetBusinessStreams_HasNoValue_ReturnsNoContent()
      {
         // Arrange
         List<BusinessStreamViewModel> businessStreams = null;

         this.masterDataService.Setup(x => x.GetBusinessStreams())
                .Returns(Task.FromResult<IEnumerable<BusinessStreamViewModel>>(businessStreams));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetBusinessStreams();

         // Assert
         Assert.IsType<NoContentResult>(result.Result);
         this.masterDataService.Verify(x => x.GetBusinessStreams(), Times.Once);
      }

      /// <summary>
      /// GetBusinessStreams has value returns BusinessStreamViewModel list
      /// </summary>
      [Fact]
      public void GetBusinessStreams_HasValue_ReturnsBusinessStreamViewModelList()
      {
         // Arrange
         IEnumerable<BusinessStreamViewModel> businessStreams = new List<BusinessStreamViewModel>()
         {
            new BusinessStreamViewModel()
                    {
                        BusinessStreamId = 1,
                        BusinessStreamName = "stream 1",
                        Status = "C",
                        BusinessStreamAbstract = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new BusinessStreamViewModel()
                    {
                       BusinessStreamId = 2,
                       BusinessStreamName = "stream 2"
                    }
                };
         this.masterDataService.Setup(x => x.GetBusinessStreams())
               .Returns(Task.FromResult<IEnumerable<BusinessStreamViewModel>>(businessStreams));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetBusinessStreams();

         // Assert
         Assert.IsType<OkObjectResult>(result.Result);
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)result.Result).StatusCode);
         Assert.Equal(businessStreams.Count(), ((IEnumerable<BusinessStreamViewModel>)((ObjectResult)result.Result).Value).Count());
         this.masterDataService.Verify(x => x.GetBusinessStreams(), Times.Once);
      }

      /// <summary>
      /// GetDocumentTypes when there is no value returns no content
      /// </summary>
      [Fact]
      public void GetDocumentTypes_ValidInputHasNoValue_ReturnsNoContent()
      {
         // Arrange
         List<DocumentTypeViewModel> documentTypes = null;
         int docGroupId = 1;

         this.masterDataService.Setup(x => x.GetDocumentTypes(docGroupId))
                .Returns(Task.FromResult<IEnumerable<DocumentTypeViewModel>>(documentTypes));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetDocumentTypes(docGroupId);

         // Assert
         Assert.IsType<NoContentResult>(result.Result);
         this.masterDataService.Verify(x => x.GetDocumentTypes(docGroupId), Times.Once);
      }

      /// <summary>
      /// GetDocumentTypes with invalid document group id
      /// </summary>
      [Fact]
      public void GetDocumentTypes_InvalidInput_ReturnsNoContent()
      {
         // Arrange
         List<DocumentTypeViewModel> documentTypes = null;
         int docGroupId = -1;

         this.masterDataService.Setup(x => x.GetDocumentTypes(docGroupId))
                .Returns(Task.FromResult<IEnumerable<DocumentTypeViewModel>>(documentTypes));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetDocumentTypes(docGroupId);

         // Assert
         Assert.IsType<NoContentResult>(result.Result);
         this.masterDataService.Verify(x => x.GetDocumentTypes(docGroupId), Times.Never);
      }

      /// <summary>
      /// GetDocumentTypes has value returns DocumentTypeViewModel list
      /// </summary>
      [Fact]
      public void GetDocumentTypes_HasValue_ReturnsDocumentTypeViewModelList()
      {
         // Arrange
         int docGroupId = 1;
         IEnumerable<DocumentTypeViewModel> documentTypes = new List<DocumentTypeViewModel>()
         {
            new DocumentTypeViewModel()
                    {
                        DocumentTypeId = 1,
                        DocumentTypeName = "Equipment Proposal",
                        DocumentGroupId = 1,
                        Status = "C",
                        DocumentTypeAbstract = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new DocumentTypeViewModel()
                    {
                       DocumentTypeId = 2,
                       DocumentTypeName = "Guide Spec"
                    }
                };
         this.masterDataService.Setup(x => x.GetDocumentTypes(docGroupId))
               .Returns(Task.FromResult<IEnumerable<DocumentTypeViewModel>>(documentTypes));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetDocumentTypes(docGroupId);

         // Assert
         Assert.IsType<OkObjectResult>(result.Result);
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)result.Result).StatusCode);
         Assert.Equal(documentTypes.Count(), ((IEnumerable<DocumentTypeViewModel>)((ObjectResult)result.Result).Value).Count());
         this.masterDataService.Verify(x => x.GetDocumentTypes(docGroupId), Times.Once);
      }

      /// <summary>
      /// GetLegalEntities using invalid document type id returns no content
      /// </summary>
      [Fact]
      public void GetLegalEntities_InvalidInput_ReturnsNoContent()
      {
         // Arrange
         List<LegalEntityViewModel> legalEntities = null;
         int docTypeId = 0;

         this.masterDataService.Setup(x => x.GetLegalEntities(docTypeId))
                .Returns(Task.FromResult<IEnumerable<LegalEntityViewModel>>(legalEntities));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetLegalEntities(docTypeId);

         // Assert
         Assert.IsType<NoContentResult>(result.Result);
         this.masterDataService.Verify(x => x.GetLegalEntities(docTypeId), Times.Never);
      }

      /// <summary>
      /// GetLegalEntities when there is no value returns no content
      /// </summary>
      [Fact]
      public void GetLegalEntities_HasNoValue_ReturnsNoContent()
      {
         // Arrange
         List<LegalEntityViewModel> legalEntities = null;
         int docTypeId = 5;

         this.masterDataService.Setup(x => x.GetLegalEntities(docTypeId))
                .Returns(Task.FromResult<IEnumerable<LegalEntityViewModel>>(legalEntities));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetLegalEntities(docTypeId);

         // Assert
         Assert.IsType<NoContentResult>(result.Result);
         this.masterDataService.Verify(x => x.GetLegalEntities(docTypeId), Times.Once);
      }

      /// <summary>
      /// GetLegalEntities has value returns LegalEntityViewModel list
      /// </summary>
      [Fact]
      public void GetLegalEntities_HasValue_ReturnsLegalEntityViewModelList()
      {
         // Arrange
         int docTypeId = 5;
         IEnumerable<LegalEntityViewModel> legalEntities = new List<LegalEntityViewModel>()
         {
            new LegalEntityViewModel()
            {
               LegalEntityId = 1,
               LegalEntityName = "Entity",
               ShortName = "Entity",
               EntityAbstract = "Entity",
            },
            new LegalEntityViewModel()
            {
               LegalEntityId = 2,
               LegalEntityName = "Ent",
               ShortName = "Ent",
               EntityAbstract = "Ent",
            }
         };
         this.masterDataService.Setup(x => x.GetLegalEntities(It.IsAny<int>()))
               .Returns(Task.FromResult<IEnumerable<LegalEntityViewModel>>(legalEntities));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetLegalEntities(docTypeId);

         // Assert
         Assert.IsType<OkObjectResult>(result.Result);
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)result.Result).StatusCode);
         Assert.Equal(legalEntities.Count(), ((IEnumerable<LegalEntityViewModel>)((ObjectResult)result.Result).Value).Count());
         this.masterDataService.Verify(x => x.GetLegalEntities(It.IsAny<int>()), Times.Once);
      }

      /// <summary>
      /// GetTermsAndConditions when there is no value returns no content
      /// </summary>
      [Fact]
      public void GetTermsAndConditions_HasNoValue_ReturnsNoContent()
      {
         // Arrange
         List<TermsAndConditionsViewModel> termsAndConditions = null;
         int docTypeId = 5;
         this.masterDataService.Setup(x => x.GetTermsAndConditions(It.IsAny<int>()))
                .Returns(Task.FromResult<IEnumerable<TermsAndConditionsViewModel>>(termsAndConditions));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetTermsAndConditions(docTypeId);

         // Assert
         Assert.IsType<NoContentResult>(result.Result);
         this.masterDataService.Verify(x => x.GetTermsAndConditions(It.IsAny<int>()), Times.Once);
      }

      /// <summary>
      /// GetTermsAndConditions has value returns TermsAndConditions list
      /// </summary>
      [Fact]
      public void GetTermsAndConditions_HasValue_ReturnsLegalEntityViewModelList()
      {
         // Arrange
         int docTypeId = 5;
         IEnumerable<TermsAndConditionsViewModel> termsAndConditions = new List<TermsAndConditionsViewModel>()
         {
            new TermsAndConditionsViewModel()
                    {
                        TermsAndConditionsId = 1,
                        TermsAndConditionsName = "term1",
                        SequenceNumber = 1,
                        Description = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new TermsAndConditionsViewModel()
                    {
                       TermsAndConditionsId = 2,
                       TermsAndConditionsName = "term2",
                       SequenceNumber = 2
                    }
                };
         this.masterDataService.Setup(x => x.GetTermsAndConditions(It.IsAny<int>()))
               .Returns(Task.FromResult<IEnumerable<TermsAndConditionsViewModel>>(termsAndConditions));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetTermsAndConditions(docTypeId);

         // Assert
         Assert.IsType<OkObjectResult>(result.Result);
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)result.Result).StatusCode);
         Assert.Equal(termsAndConditions.Count(), ((IEnumerable<TermsAndConditionsViewModel>)((ObjectResult)result.Result).Value).Count());
         this.masterDataService.Verify(x => x.GetTermsAndConditions(It.IsAny<int>()), Times.Once);
      }

      /// <summary>
      /// GetJobDocumentType when there is no value returns no content
      /// </summary>
      [Fact]
      public void GetJobDocumentType_HasNoValue_ReturnsNoContent()
      {
         // Arrange
         List<JobDocumentTypeViewModel> filetTypes = null;

         this.masterDataService.Setup(x => x.GetJobDocumentType())
                .Returns(Task.FromResult<IEnumerable<JobDocumentTypeViewModel>>(filetTypes));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetJobDocumentType();

         // Assert
         Assert.IsType<NoContentResult>(result.Result);
         this.masterDataService.Verify(x => x.GetJobDocumentType(), Times.Once);
      }

      /// <summary>
      /// GetJobDocumentType has value returns FileTypeViewModel list
      /// </summary>
      [Fact]
      public void GetJobDocumentType_HasValue_ReturnsFileTypeViewModelList()
      {
         // Arrange
         IEnumerable<JobDocumentTypeViewModel> fileTypes = new List<JobDocumentTypeViewModel>()
         {
            new JobDocumentTypeViewModel()
                    {
                        JobDocumentTypeId = 1,
                        TypeName = "Contract",
                        SequenceNumber = 1,
                        TypeAbstract = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new JobDocumentTypeViewModel()
                    {
                       JobDocumentTypeId = 2,
                       TypeName = "Submittal"
                    }
                };
         this.masterDataService.Setup(x => x.GetJobDocumentType())
               .Returns(Task.FromResult<IEnumerable<JobDocumentTypeViewModel>>(fileTypes));

         // Act
         var masterDataController = new MasterDataController(this.masterDataService.Object, this.logger.Object);
         var result = masterDataController.GetJobDocumentType();

         // Assert
         Assert.IsType<OkObjectResult>(result.Result);
         Assert.Equal((int)HttpStatusCode.OK, ((OkObjectResult)result.Result).StatusCode);
         Assert.Equal(fileTypes.Count(), ((IEnumerable<JobDocumentTypeViewModel>)((ObjectResult)result.Result).Value).Count());
         this.masterDataService.Verify(x => x.GetJobDocumentType(), Times.Once);
      }
   }
}
