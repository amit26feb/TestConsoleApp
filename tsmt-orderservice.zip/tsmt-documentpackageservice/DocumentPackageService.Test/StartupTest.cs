﻿// <copyright file="StartupTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using App.Metrics;
    using DocumentPackageService.Controllers;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Builder.Internal;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Hosting.Internal;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.ObjectPool;
    using Moq;
    using Xunit;

    /// <summary>
    /// StartupTest
    /// </summary>
    public class StartupTest
    {
        private readonly Mock<IHostingEnvironment> env;

        /// <summary>
        /// Initializes a new instance of the <see cref="StartupTest"/> class.
        /// </summary>
        public StartupTest()
        {
            this.env = new Mock<IHostingEnvironment>();
        }

        /// <summary>
        /// Registering the dependencies for the configuration services correctly.
        /// </summary>
        [Fact]
        public void ConfigureServices_RegistersDependenciesCorrectly()
        {
            // Arrange
            Mock<IConfigurationSection> configurationSectionStub = new Mock<IConfigurationSection>();
            var mockEnvironment = new Mock<IHostingEnvironment>();
            mockEnvironment
                .Setup(m => m.EnvironmentName)
                .Returns("Hosting:UnitTestEnvironment");
            mockEnvironment.Setup(m => m.ContentRootPath).Returns(Path.Combine(Directory.GetCurrentDirectory(), "..", "..", "..", string.Empty));
            Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
            configurationStub.Setup(x => x[It.IsAny<string>()]).Returns("https://domain.account.com/");
            Mock<ILoggerFactory> logger = new Mock<ILoggerFactory>();
            Mock<IApplicationBuilder> builder = new Mock<IApplicationBuilder>();

            IServiceCollection services = new ServiceCollection();
            var target = new Startup(configurationStub.Object, mockEnvironment.Object, logger.Object);

            // Act
            target.ConfigureServices(services);

            // Mimic internal asp.net core logic.
            services.AddTransient<DocumentPackageController>();

            // Assert
            var serviceProvider = services.BuildServiceProvider();

            Assert.NotNull(serviceProvider);
        }

        /// <summary>
        /// Configuring successfully
        /// </summary>
        [Fact]
        public void Configure_Success()
        {
            // Arrange
            var mockEnvironment = new Mock<IHostingEnvironment>();
            mockEnvironment
                .Setup(m => m.EnvironmentName)
                .Returns("Hosting:UnitTestEnvironment");
            mockEnvironment.Setup(m => m.ContentRootPath).Returns(Directory.GetCurrentDirectory());

            Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
            Mock<ILoggerFactory> logger = new Mock<ILoggerFactory>();
            IServiceCollection services = new ServiceCollection();
            var target = new Startup(configurationStub.Object, mockEnvironment.Object, logger.Object);

            // Mimic internal asp.net core logic.
            services.AddTransient<DocumentPackageController>();
            var metrics = AppMetrics.CreateDefaultBuilder()

                        .Configuration.Configure(
                            options =>
                            {
                                options.AddEnvTag("DEV");
                            })
                          .Report.ToInfluxDb(options =>
                          {
                              options.InfluxDb.BaseUri = new Uri("https://InfluxUri.com/");
                              options.InfluxDb.Database = "testDb";
                              options.InfluxDb.UserName = "testUser";
                              options.InfluxDb.Password = "testPw";
                              options.InfluxDb.CreateDataBaseIfNotExists = true;
                          }).Build();
            services.AddMetrics(metrics);
            services.AddMetricsReportScheduler();
            services.AddMetricsEndpoints();
            services.AddMetricsTrackingMiddleware();
            services.AddSingleton<ObjectPoolProvider, DefaultObjectPoolProvider>();
            services.AddSingleton<IHostingEnvironment>(new HostingEnvironment());
            var diagnosticSource = new DiagnosticListener("Microsoft.AspNet");
            services.AddSingleton<DiagnosticSource>(diagnosticSource);
            services.AddMvc();
            services.AddLogging();
            services.AddRouting();

            // Assert
            var serviceProvider = services.BuildServiceProvider();
            IApplicationBuilder app = new ApplicationBuilder(serviceProvider);

            // Act
            target.Configure(app, mockEnvironment.Object);

            Assert.NotNull(app);
        }
    }
}