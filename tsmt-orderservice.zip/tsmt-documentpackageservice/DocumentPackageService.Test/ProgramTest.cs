﻿// <copyright file="ProgramTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test
{
   using System;
   using System.IO;
   using System.Net;
   using System.Threading.Tasks;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.TestHost;
   using Xunit;

   /// <summary>
   /// Program test
   /// </summary>
   public class ProgramTest
   {
      /// <summary>
      /// Should build web host
      /// </summary>
      /// <returns>Status Code</returns>
      [Fact]
      public async Task ShouldBuildWebHost()
      {
         // Arrange
         Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
         string appRootPath = Path.GetFullPath(Path.Combine(
             AppContext.BaseDirectory,
             "..",
             "..",
             "..",
             "..",
             "DocumentPackageService"));
         var webHostBuilder = Program.BuildWebHost(Array.Empty<string>())
             .UseContentRoot(appRootPath);
         var server = new TestServer(webHostBuilder);
         var client = server.CreateClient();

         // Act
         var response = await client.GetAsync("/api/v1/masterdata");

         Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
      }
   }
}