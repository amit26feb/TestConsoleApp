﻿// <copyright file="InternalServerErrorObjectResultTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Common.ActionResults
{
    using DocumentPackageService.Common.ActionResults;
    using Microsoft.AspNetCore.Http;
    using Xunit;

    /// <summary>
    /// Internal server error test
    /// </summary>
    public class InternalServerErrorObjectResultTest
    {
        /// <summary>
        /// Constructor sets the status code
        /// </summary>
        [Fact]
        public void Constructor_SetsStatusCode()
        {
            var objUnderTest = new InternalServerErrorObjectResult(null);
            Assert.True(objUnderTest.StatusCode == StatusCodes.Status500InternalServerError);
        }

        /// <summary>
        /// Constructor sets object
        /// </summary>
        [Fact]
        public void Constructor_SetsObject()
        {
            string anObject = "sample text";
            var objUnderTest = new InternalServerErrorObjectResult(anObject);
            Assert.IsType<string>(objUnderTest.Value);
            Assert.True(objUnderTest.Value.ToString() == anObject);
        }
    }
}
