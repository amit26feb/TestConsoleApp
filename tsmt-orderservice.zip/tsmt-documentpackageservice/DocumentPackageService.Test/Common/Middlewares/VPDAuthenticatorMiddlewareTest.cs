﻿// <copyright file="VPDAuthenticatorMiddlewareTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Common.Middlewares
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using DocumentPackageService.Common.Middlewares;
    using DocumentPackageService.Core.Services;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using TraneSalesToolsCommon;
   using TraneSalesToolsCommon.Middlewares;
   using Xunit;

   /// <summary>
   /// VPDAuthenticatorMiddlewareTest
   /// </summary>
   public class VPDAuthenticatorMiddlewareTest
   {
      private readonly Mock<VpdAuthenticatorMiddleware> vpdAuthenticatorMock;
      private readonly Mock<IDocumentPackageService> documentPackageServiceMock;

      /// <summary>
      /// Initializes a new instance of the <see cref="VPDAuthenticatorMiddlewareTest"/> class.
      /// VPDAuthenticatorMiddlewareTest
      /// </summary>
      public VPDAuthenticatorMiddlewareTest()
      {
         this.vpdAuthenticatorMock = new Mock<VpdAuthenticatorMiddleware>();
         this.documentPackageServiceMock = new Mock<IDocumentPackageService>();
      }

      /// <summary>
      /// Invoke VpdAuthenticatorMiddleware with no draddress
      /// </summary>
      /// <returns>Context with mo draddress</returns>
      [Fact]
      public async Task Invoke_NoDRAddressId_InvokesNext()
      {
         Mock<HttpRequest> requestMock = new Mock<HttpRequest>();
         requestMock.Setup(x => x.Path).Returns(new PathString("/api/v1/123/Jobs/12/DocumentPackage/"));

         var contextMock = new Mock<HttpContext>();
         Dictionary<object, object> contextMockItems = new Dictionary<object, object>();
         contextMock.Setup(x => x.Items).Returns(contextMockItems);
         contextMock.Setup(x => x.Request).Returns(requestMock.Object);

         var vpdAuthenticatorMiddleware = new VpdAuthenticatorMiddleware(this.documentPackageServiceMock.Object, next: (innerHttpContext) => Task.FromResult(0));
         await vpdAuthenticatorMiddleware.Invoke(contextMock.Object);

         Assert.False(contextMock.Object.Items.ContainsKey("DR_ADDRESS_ID"));
      }

      /// <summary>
      /// Invoke VpdAuthenticatorMiddleware with valid DR address id which does not have any sales office returns unauthorized error
      /// </summary>
      /// <returns>Unauthorized error</returns>
      [Fact]
      public async Task Invoke_NoSalesOffice_Returns401()
      {
         Mock<HttpRequest> requestMock = new Mock<HttpRequest>();
         requestMock.Setup(x => x.Path).Returns(new PathString("/api/v1/123/Jobs/12/DocumentPackage/"));
         var contextMock = new Mock<HttpContext>();
         Dictionary<object, object> contextMockItems = new Dictionary<object, object>();
         contextMockItems.Add("DR_ADDRESS_ID", 127);
         contextMock.Setup(x => x.Items).Returns(contextMockItems);
         contextMock.Setup(x => x.Request).Returns(requestMock.Object);
         var mockResponse = new Mock<HttpResponse>();
         mockResponse.SetupSet(resp => resp.StatusCode = 401).Verifiable();

         contextMock.Setup(x => x.Response).Returns(mockResponse.Object);

         IEnumerable<SalesOfficeView> salesOfficeView = new List<SalesOfficeView>();

         this.documentPackageServiceMock.Setup(x => x.GetOfficeSelector())
               .Returns(Task.FromResult(salesOfficeView));

         var vpdAuthenticatorMiddleware = new VpdAuthenticatorMiddleware(this.documentPackageServiceMock.Object, next: (innerHttpContext) => Task.FromResult(0));
         await vpdAuthenticatorMiddleware.Invoke(contextMock.Object);

         mockResponse.Verify();
      }

      /// <summary>
      /// Invoke VpdAuthenticatorMiddleware with invalid DR address idreturns unauthorized error
      /// </summary>
      /// <returns>Unauthorized error</returns>
      [Fact]
      public async Task Invoke_InvalidDrAddressId_Returns401()
      {
         Mock<HttpRequest> requestMock = new Mock<HttpRequest>();
         requestMock.Setup(x => x.Path).Returns(new PathString("/api/v1/123/Jobs/12/DocumentPackage/"));

         var contextMock = new Mock<HttpContext>();
         Dictionary<object, object> contextMockItems = new Dictionary<object, object>();
         contextMockItems.Add("DR_ADDRESS_ID", 127);
         contextMock.Setup(x => x.Items).Returns(contextMockItems);
         contextMock.Setup(x => x.Request).Returns(requestMock.Object);
         var mockResponse = new Mock<HttpResponse>();
         mockResponse.SetupSet(resp => resp.StatusCode = 401).Verifiable();

         contextMock.Setup(x => x.Response).Returns(mockResponse.Object);

         IEnumerable<SalesOfficeView> salesOfficeView = new List<SalesOfficeView>
            {
                new SalesOfficeView
                {
                   Country = "country",
                   CrmIntegrationInd = "Ind",
                   DrAddressId = 122,
                   HomeDrAddressId = 122,
                   SalesOfficeName = "name"
                }
            };

         this.documentPackageServiceMock.Setup(x => x.GetOfficeSelector())
             .Returns(Task.FromResult(salesOfficeView));

         var vpdAuthenticatorMiddleware = new VpdAuthenticatorMiddleware(this.documentPackageServiceMock.Object, next: (innerHttpContext) => Task.FromResult(0));
         await vpdAuthenticatorMiddleware.Invoke(contextMock.Object);

         mockResponse.Verify();
      }

      /// <summary>
      /// Invoke VpdAuthenticatorMiddleware with invalid DR address id returns valid context with dr_address_id
      /// </summary>
      /// <returns>Context</returns>
      [Fact]
      public async Task Invoke_ValidDrAddressId_InvokesNext()
      {
         Mock<HttpRequest> requestMock = new Mock<HttpRequest>();
         requestMock.Setup(x => x.Path).Returns(new PathString("/api/v1/123/Jobs/12/DocumentPackage/"));

         var contextMock = new Mock<HttpContext>();
         Dictionary<object, object> contextMockItems = new Dictionary<object, object>();
         contextMockItems.Add("DR_ADDRESS_ID", 127);
         contextMock.Setup(x => x.Items).Returns(contextMockItems);
         contextMock.Setup(x => x.Request).Returns(requestMock.Object);

         IEnumerable<SalesOfficeView> salesOfficeView = new List<SalesOfficeView>
            {
                new SalesOfficeView
                {
                   Country = "country",
                   CrmIntegrationInd = "Ind",
                   DrAddressId = 127,
                   HomeDrAddressId = 127,
                   SalesOfficeName = "name"
                }
            };

         this.documentPackageServiceMock.Setup(x => x.GetOfficeSelector())
             .Returns(Task.FromResult(salesOfficeView));

         var vpdAuthenticatorMiddleware = new VpdAuthenticatorMiddleware(this.documentPackageServiceMock.Object, next: (innerHttpContext) => Task.FromResult(0));
         await vpdAuthenticatorMiddleware.Invoke(contextMock.Object);

         Assert.True(contextMock.Object.Items.ContainsKey("DR_ADDRESS_ID"));
         Assert.Equal(127, contextMock.Object.Items["DR_ADDRESS_ID"]);
      }
   }
}
