﻿// <copyright file="DrAddressIdResolverMiddlewareTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Common.Middlewares
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using DocumentPackageService.Common.Middlewares;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using TraneSalesToolsCommon.Middlewares;
   using Xunit;

   /// <summary>
   /// DrAddressIdResolverMiddlewareTest
   /// </summary>
   public class DrAddressIdResolverMiddlewareTest
   {
      private readonly Mock<DrAddressIdResolverMiddleware> drAddressIdResolverMock;

      /// <summary>
      /// Initializes a new instance of the <see cref="DrAddressIdResolverMiddlewareTest"/> class.
      /// DrAddressIdResolverMiddlewareTest
      /// </summary>
      public DrAddressIdResolverMiddlewareTest()
      {
         this.drAddressIdResolverMock = new Mock<DrAddressIdResolverMiddleware>();
      }

      /// <summary>
      /// Parse DrAddressId from the Route returns DR_Address_ID
      /// </summary>
      /// <returns>Task</returns>
      [Fact]
      public async Task DRAddresserResolverTest()
      {
         Mock<HttpRequest> requestMock = new Mock<HttpRequest>();
         requestMock.Setup(x => x.Path).Returns(new PathString("/api/v1/123/Jobs/12/DocumentPackage/"));

         var contextMock = new Mock<HttpContext>();
         Dictionary<object, object> contextMockItems = new Dictionary<object, object>();
         contextMock.Setup(x => x.Items).Returns(contextMockItems);
         contextMock.Setup(x => x.Request).Returns(requestMock.Object);

         var drAddressIdResolverMiddleware = new DrAddressIdResolverMiddleware(next: (innerHttpContext) => Task.FromResult(0));
         await drAddressIdResolverMiddleware.Invoke(contextMock.Object);

         Assert.NotNull(contextMock);
         Assert.True(contextMock.Object.Items.ContainsKey("DR_ADDRESS_ID"));
         Assert.Equal("123", contextMock.Object.Items["DR_ADDRESS_ID"]);
      }

      /// <summary>
      /// Parse DrAddressId from the Route without DR_Address_Id returns empty string
      /// </summary>
      /// <returns>Task</returns>
      [Fact]
      public async Task DRAddresserResolverWithNoDRAddressIDTest()
      {
         Mock<HttpRequest> requestMock = new Mock<HttpRequest>();
         requestMock.Setup(x => x.Path).Returns(new PathString("/api/v1/Jobs/12/DocumentPackage/"));

         var contextMock = new Mock<HttpContext>();
         Dictionary<object, object> contextMockItems = new Dictionary<object, object>();
         contextMock.Setup(x => x.Items).Returns(contextMockItems);
         contextMock.Setup(x => x.Request).Returns(requestMock.Object);

         var drAddressIdResolverMiddleware = new DrAddressIdResolverMiddleware(next: (innerHttpContext) => Task.FromResult(0));
         await drAddressIdResolverMiddleware.Invoke(contextMock.Object);

         Assert.NotNull(contextMock);
         Assert.True(contextMock.Object.Items.ContainsKey("DR_ADDRESS_ID"));
         Assert.Empty(contextMock.Object.Items["DR_ADDRESS_ID"].ToString());
      }
   }
}
