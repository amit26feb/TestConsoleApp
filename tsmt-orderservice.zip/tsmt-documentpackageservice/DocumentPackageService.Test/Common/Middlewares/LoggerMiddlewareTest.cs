﻿// <copyright file="LoggerMiddlewareTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Common.Middlewares
{
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using DocumentPackageService.Common.Middlewares;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Logger middleware test
    /// </summary>
    public class LoggerMiddlewareTest
    {
        /// <summary>
        /// Http request
        /// </summary>
        private readonly Mock<HttpRequest> requestMock;

        /// <summary>
        /// Mock object for ILogger interface
        /// </summary>
        private readonly Mock<ILogger<LoggerMiddleware>> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggerMiddlewareTest"/> class.
        /// </summary>
        public LoggerMiddlewareTest()
        {
            this.requestMock = new Mock<HttpRequest>();
            this.logger = new Mock<ILogger<LoggerMiddleware>>();
        }

        /// <summary>
        /// Log request
        /// </summary>
        [Fact]

        public async void It_Should_Log_Request()
        {
            this.requestMock.Setup(x => x.Scheme).Returns("http");
            this.requestMock.Setup(x => x.Host).Returns(new HostString("localhost"));
            this.requestMock.Setup(x => x.Path).Returns(new PathString("/test"));
            this.requestMock.Setup(x => x.PathBase).Returns(new PathString("/"));
            this.requestMock.Setup(x => x.Method).Returns("GET");
            this.requestMock.Setup(x => x.Body).Returns(new MemoryStream());
            this.requestMock.Setup(x => x.QueryString).Returns(new QueryString("?param1=1"));
            var contextMock = new Mock<HttpContext>();
            contextMock.Setup(x => x.Response.Body).Returns(new MemoryStream());
            contextMock.Setup(x => x.Request).Returns(this.requestMock.Object);
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "user")
            };
            contextMock.Setup(x => x.User.Claims).Returns(claims);
            var loggerMiddlewar = new LoggerMiddleware(next: (innerHttpContext) => Task.FromResult(0), logger: this.logger.Object);
            await loggerMiddlewar.Invoke(contextMock.Object);

            Assert.NotNull(contextMock);
            this.requestMock.Verify();
        }

        /// <summary>
        /// It should not log the request if the status code is either 200 or 204
        /// </summary>
        [Fact]
        public async void It_Should_Not_Log_Request_If_Status200()
        {
            this.requestMock.Setup(x => x.Scheme).Returns("http");
            this.requestMock.Setup(x => x.Host).Returns(new HostString("localhost"));
            this.requestMock.Setup(x => x.Path).Returns(new PathString("/test"));
            this.requestMock.Setup(x => x.PathBase).Returns(new PathString("/"));
            this.requestMock.Setup(x => x.Method).Returns("GET");
            this.requestMock.Setup(x => x.Body).Returns(new MemoryStream());
            this.requestMock.Setup(x => x.QueryString).Returns(new QueryString("?param1=1"));
            var contextMock = new Mock<HttpContext>();
            contextMock.Setup(x => x.Response.Body).Returns(new MemoryStream());
            contextMock.Setup(x => x.Response.StatusCode).Returns(200);
            contextMock.Setup(x => x.Request).Returns(this.requestMock.Object);
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "user")
            };
            contextMock.Setup(x => x.User.Claims).Returns(claims);
            var loggerMiddlewar = new LoggerMiddleware(next: (innerHttpContext) => Task.FromResult(0), logger: this.logger.Object);
            await loggerMiddlewar.Invoke(contextMock.Object);

            Assert.NotNull(contextMock);
            this.requestMock.Verify();
        }
    }
}
