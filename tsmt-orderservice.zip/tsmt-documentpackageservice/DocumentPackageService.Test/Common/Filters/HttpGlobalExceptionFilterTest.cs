﻿// <copyright file="HttpGlobalExceptionFilterTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Common.Filters
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Net;
    using DocumentPackageService.Common.Exceptions;
    using DocumentPackageService.Common.Filters;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Abstractions;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.AspNetCore.Routing;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Http global exception filter test
    /// </summary>
    public class HttpGlobalExceptionFilterTest
    {
        private readonly Mock<IWebHostEnvironment> env;
        private readonly Mock<ILogger<HttpGlobalExceptionFilter>> logger;
        private readonly Mock<List<IFilterMetadata>> filterMetadata;
        private HttpGlobalExceptionFilter httpGlobalFilter;

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpGlobalExceptionFilterTest"/> class.
        /// </summary>
        public HttpGlobalExceptionFilterTest()
        {
            this.env = new Mock<IWebHostEnvironment>();
            this.logger = new Mock<ILogger<HttpGlobalExceptionFilter>>();
            this.filterMetadata = new Mock<List<IFilterMetadata>>();
        }

        /// <summary>
        /// On exception internal server error - Success
        /// </summary>
        [Fact]
        public void OnException_InternalServerError_Success()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            this.env.Setup(m => m.EnvironmentName).Returns("Development");
            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new Exception()
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.InternalServerError, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        /// <summary>
        /// On exception bad request - Success
        /// </summary>
        [Fact]
        public void OnException_BadRequest_Success()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);

            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new DocumentPackageServiceDomainException()
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        /// <summary>
        /// On exception exception message - Success
        /// </summary>
        [Fact]
        public void OnException_ExceptionMessage_Success()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var httpContext = new DefaultHttpContext();
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new DocumentPackageServiceDomainException("Exception")
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }

        /// <summary>
        /// On exception inner exception - Success
        /// </summary>
        [Fact]
        public void OnException_InnerException_Success()
        {
            // Arrange
            this.httpGlobalFilter = new HttpGlobalExceptionFilter(this.env.Object, this.logger.Object);
            var httpContext = new DefaultHttpContext();
            var innerException = new ValidationException("message");
            var excepContext = new ExceptionContext(
            new ActionContext
            {
                HttpContext = httpContext,
                RouteData = new RouteData(),
                ActionDescriptor = new ActionDescriptor(),
            },
            this.filterMetadata.Object)
            {
                Exception = new DocumentPackageServiceDomainException("InnerException", innerException)
            };

            // Act
            this.httpGlobalFilter.OnException(excepContext);

            // Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, excepContext.HttpContext.Response.StatusCode);
            Assert.True(excepContext.ExceptionHandled);
        }
    }
}
