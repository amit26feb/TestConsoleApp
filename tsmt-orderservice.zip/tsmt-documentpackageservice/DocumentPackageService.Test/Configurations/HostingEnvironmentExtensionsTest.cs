﻿// <copyright file="HostingEnvironmentExtensionsTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Configurations
{
    using Microsoft.AspNetCore.Hosting;
    using Moq;
    using Xunit;

    /// <summary>
    /// Class for hosting environment extensions test
    /// </summary>
    public class HostingEnvironmentExtensionsTest
    {
        private readonly Mock<IWebHostEnvironment> mockEnv;

        /// <summary>
        /// Initializes a new instance of the <see cref="HostingEnvironmentExtensionsTest"/> class.
        /// </summary>
        public HostingEnvironmentExtensionsTest()
        {
            this.mockEnv = new Mock<IWebHostEnvironment>();
        }

        /// <summary>
        /// Hosting environment IsUAT returns false
        /// </summary>
        [Fact]
        public void HostingEnvironment_IsUAT_ReturnsFalse()
        {
            // Arrange
            this.mockEnv.Setup(x => x.EnvironmentName).Returns("Development");

            // Act
            var test = DocumentPackageService.Configurations.HostingEnvironmentExtensions.IsUAT(this.mockEnv.Object);

            // Assert
            Assert.False(test);
            this.mockEnv.Verify(x => x.EnvironmentName, Times.Once);
        }

        /// <summary>
        /// Hosting environment IsUAT returns true
        /// </summary>
        [Fact]
        public void HostingEnvironment_IsUAT_ReturnsTrue()
        {
            // Arrange
            this.mockEnv.Setup(x => x.EnvironmentName).Returns("UAT");

            // Act
            var test = DocumentPackageService.Configurations.HostingEnvironmentExtensions.IsUAT(this.mockEnv.Object);

            // Assert
            Assert.True(test);
            Assert.Equal("UAT", DocumentPackageService.Configurations.HostingEnvironmentExtensions.UATEnvironment);
            this.mockEnv.Verify(x => x.EnvironmentName, Times.Once);
        }
    }
}
