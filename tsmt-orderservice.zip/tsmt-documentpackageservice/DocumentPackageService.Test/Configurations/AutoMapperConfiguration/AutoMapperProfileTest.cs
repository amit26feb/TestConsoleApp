﻿// <copyright file="AutoMapperProfileTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Configurations.AutoMapperConfiguration
{
    using DocumentPackageService.Configurations.AutoMapperConfiguration;
    using Xunit;

    /// <summary>
    /// Auto mapper profile test
    /// </summary>
    public class AutoMapperProfileTest
    {
        /// <summary>
        /// Test whether the constructor of the automapperprofile workes
        /// </summary>
        [Fact]
        public void ConstructorWorks()
        {
            var profileUnderTest = new AutoMapperProfile();
            Assert.NotNull(profileUnderTest);
        }
    }
}
