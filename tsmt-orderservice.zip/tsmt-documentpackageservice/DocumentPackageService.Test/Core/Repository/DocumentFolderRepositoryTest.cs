﻿// <copyright file="DocumentFolderRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Repository
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using DataAccess.Core.Abstractions;
   using DocumentPackageService.Common;
   using DocumentPackageService.Common.Exceptions;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.ViewModels;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   /// <summary>
   /// Document folder repository test
   /// </summary>
   public class DocumentFolderRepositoryTest
   {
      /// <summary>
      /// Document folder repository mock
      /// </summary>
      private readonly Mock<IRepository<DocumentFolderModel>> documentFolderRepository;

      /// <summary>
      /// Document folder repository
      /// </summary>
      private readonly DocumentFolderRepository folderRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentFolderRepositoryTest"/> class.
      /// </summary>
      public DocumentFolderRepositoryTest()
      {
         this.documentFolderRepository = new Mock<IRepository<DocumentFolderModel>>();
         this.folderRepository = new DocumentFolderRepository(this.documentFolderRepository.Object);
      }

      /// <summary>
      /// Tests that if the repo does create that true is returned.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task CreateDocumentFolder_RepoDoescreate_ReturnsTrue()
      {
         // Arrange
         this.documentFolderRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.CreateDocumentFolder, It.IsAny<object>()))
            .Returns(Task.FromResult(1)).Verifiable();

         // Act
         bool result = await this.folderRepository.CreateDocumentFolder(new DocumentFolderModel());

         // Assert
         Assert.True(result);
         this.documentFolderRepository.Verify();
      }

      /// <summary>
      /// Tests that if the repo doesnt creaye that false is returned.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task CreateDocumentFolder_RepoDoesntUpdate_ReturnsFalse()
      {
         // Arrange
         this.documentFolderRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.CreateDocumentFolder, It.IsAny<object>()))
            .Returns(Task.FromResult(0)).Verifiable();

         // Act
         bool result = await this.folderRepository.CreateDocumentFolder(new DocumentFolderModel());

         // Assert
         Assert.False(result);
         this.documentFolderRepository.Verify();
      }

      /// <summary>
      /// Tests that if the repo throws an exception that the method does as well.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task CreateDocumentFolder_RepoThrowsException_MethodThrowsException()
      {
         // Arrange
         string exceptionMessage = "I'm an exception";
         this.documentFolderRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.CreateDocumentFolder, It.IsAny<object>()))
            .Throws(new System.Exception(exceptionMessage)).Verifiable();

         // Act
         DocumentPackageServiceDomainException exception = await Assert.ThrowsAsync<DocumentPackageServiceDomainException>(async () => { await this.folderRepository.CreateDocumentFolder(new DocumentFolderModel()); });

         // Assert
         Assert.Equal(exceptionMessage, exception.Message);
         this.documentFolderRepository.Verify();
      }

      /// <summary>
      /// GetFolders has no value returns empty folder list
      /// </summary>
      /// <returns>returns empty folder list</returns>
      [Fact]
      public async Task GetFolders_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         int jobId = 1;
         IEnumerable<DocumentFolderModel> folderModel = null;

         this.documentFolderRepository.Setup(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(folderModel));

         // Act
         var result = await this.folderRepository.GetFolders(jobId);

         // Assert
         Assert.Null(result);
         this.documentFolderRepository.Verify(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Get document folders - valid input
      /// </summary>
      /// <returns>Document folders</returns>
      [Fact]
      public async Task GetFolders_ValidInput_ReturnsDetails()
      {
         // Arrange
         IEnumerable<DocumentFolderModel> folders = new List<DocumentFolderModel>()
         {
            new DocumentFolderModel()
            {
               FOLDER_ID = 2,
               FOLDER_NAME = "folders",
               FOLDER_PARENT_ID = 0,
               FOLDER_SOURCE = "system",
               CREATED_DATE = System.DateTime.Now,
            }
          };
         this.documentFolderRepository.Setup(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(folders));

         // Act
         var result = await this.folderRepository.GetFolders(2);

         // Assert
         Assert.IsAssignableFrom<IEnumerable<DocumentFolderModel>>(result);
         Assert.True(result.Any());
         Assert.Contains(result, a => a.FOLDER_ID == 2);
         Assert.Contains(result, a => a.FOLDER_NAME == "folders");
         this.documentFolderRepository.Verify(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Checks whether the document folder name does not exists already in database if folders count is equal to zero
      /// </summary>
      /// <returns>True</returns>
      [Fact]
      public async Task ValidateDocumentFolder_FolderNameCountEqualsToZero_ReturnsTrue()
      {
         // Arrange
         DocumentFolderViewModel docFolder = new DocumentFolderViewModel
         {
            FolderName = "Test folder",
            FolderParentId = null,
            DrAddressId = 12,
            JobId = 12345,
         };
         this.documentFolderRepository.Setup(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(Enumerable.Empty<DocumentFolderModel>()));

         // Act
         bool result = await this.folderRepository.ValidateDocumentFolder(docFolder);

         // Assert
         Assert.True(result);
         this.documentFolderRepository.Verify(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Checks whether the document folder name already exists in database if folders count is greater than zero
      /// </summary>
      /// <returns>False</returns>
      [Fact]
      public async Task ValidateDocumentFolder_FolderNameCountGreaterThanZero_ReturnsFalse()
      {
         // Arrange
         DocumentFolderViewModel docFolder = new DocumentFolderViewModel
         {
            FolderName = "New folder 3",
            FolderParentId = 2,
            DrAddressId = 12,
            JobId = 12345,
         };
         IEnumerable<DocumentFolderModel> docFolderList = new List<DocumentFolderModel>
         {
            new DocumentFolderModel
            {
               FOLDER_ID = 3,
               FOLDER_NAME = "New folder 3",
               FOLDER_PARENT_ID = 2,
            }
         };
         this.documentFolderRepository.Setup(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(docFolderList));

         // Act
         bool result = await this.folderRepository.ValidateDocumentFolder(docFolder);

         // Assert
         Assert.False(result);
         this.documentFolderRepository.Verify(x => x.ExecuteListQuery<DocumentFolderModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// DoesFolderExist has no folder returns false
      /// </summary>
      /// <returns>returns false</returns>
      [Fact]
      public async Task DoesFolderExist_HasNoFolder_ReturnsFalse()
      {
         // Arrange
         int jobId = 1;
         int documentJobId = 5;

         this.documentFolderRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(0));

         // Act
         var result = await this.folderRepository.DoesFolderExist(documentJobId, jobId);

         // Assert
         Assert.False(result);
         this.documentFolderRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// DoesFolderExist has folder returns true
      /// </summary>
      /// <returns>returns true</returns>
      [Fact]
      public async Task DoesFolderExist_HasFolder_ReturnsTrue()
      {
         // Arrange
         int jobId = 1;
         int documentJobId = 5;

         this.documentFolderRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(1));

         // Act
         var result = await this.folderRepository.DoesFolderExist(documentJobId, jobId);

         // Assert
         Assert.True(result);
         this.documentFolderRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Get a job document folder id  with sequence
      /// </summary>
      /// <returns>returns job document folder id</returns>
      [Fact]
      public async Task GetSequenceNumberAsync_ReturnsValidId()
      {
         // Arrange
         int id = 34;
         this.documentFolderRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(id)).Verifiable();

         // Act
         var result = await this.folderRepository.GetSequenceNumberAsync("jobdocument");

         // Assert
         Assert.Equal(result, id);
         this.documentFolderRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Get a job document folder id  with sequence
      /// </summary>
      /// <returns>returns no job document folder</returns>
      [Fact]
      public async Task GetSequenceNumberAsync_ReturnsInvalidId()
      {
         // Arrange
         int id = 0;
         this.documentFolderRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(id)).Verifiable();

         // Act
         var result = await this.folderRepository.GetSequenceNumberAsync("jobdocument");

         // Assert
         Assert.Equal(result, id);
         this.documentFolderRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }
   }
}
