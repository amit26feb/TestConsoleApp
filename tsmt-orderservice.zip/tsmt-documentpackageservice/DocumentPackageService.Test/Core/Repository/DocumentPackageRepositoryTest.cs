﻿// <copyright file="DocumentPackageRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using DataAccess.Core.Abstractions;
   using DocumentPackageService.Common;
   using DocumentPackageService.Common.Exceptions;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Repository;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   /// <summary>
   /// Document package repository test
   /// </summary>
   public class DocumentPackageRepositoryTest
   {
      /// <summary>
      /// Document package repository mock
      /// </summary>
      private readonly Mock<IRepository<DocumentPackageModel>> documentPackageRepository;

      /// <summary>
      /// Connection factory
      /// </summary>
      private readonly Mock<IConnectionFactory> connectionFactory;

      /// <summary>
      /// Document package repository
      /// </summary>
      private readonly DocumentPackageRepository packageRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageRepositoryTest"/> class.
      /// Product family repository test
      /// </summary>
      public DocumentPackageRepositoryTest()
      {
         this.connectionFactory = new Mock<IConnectionFactory>();
         this.documentPackageRepository = new Mock<IRepository<DocumentPackageModel>>();
         this.packageRepository = new DocumentPackageRepository(this.connectionFactory.Object, this.documentPackageRepository.Object);
      }

      /// <summary>
      /// Loading data for the GetDocumentPackageSeqAsync  test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>returns document package id</returns>
      public static IEnumerable<object[]> GetDocumentPackage(int numTests)
      {
         // <summary>
         // object[] definition
         // </summary>
         // <param name="tableName">Table name</param>
         // <param name="expectedId">Expected  document package id</param>
         // <param name="timesCalled">Times the method is called</param>
         var allData = new List<object[]>
            {
               // Scenario 1: when there is no record returns 1
                new object[] { "DG_DOC_PACKAGE",  1, Times.Once() },

                // Scenario 2: when there is an existing record return the next id
                new object[] { "DG_DOC_PACKAGE_FILE", 2, Times.Once() },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Loading data for the ValidateDocumentPackageModel  test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for ValidateDocumentPackageModel</returns>
      public static IEnumerable<object[]> GetDataForValidation(int numTests)
      {
         // <summary>
         // object[] definition
         // </summary>
         // <param name="documentPackageName">Document package name</param>
         // <param name="count">Actual count of the items with the same document package name</param>
         // <param name="expectedResult">Validation result</param>
         // <param name="timesCalled">Times the method is called</param>
         var allData = new List<object[]>
            {
               // Scenario 1: Null document package name returns false
               new object[] { null, 0, false, Times.Never() },

               // Scenario 2: Document package name which already exist returns false
               new object[] { "Existing Package", 1, false, Times.Once() },

               // Scenario 3: Document package name which does not exist returns true
               new object[] { "New Package", 0, true, Times.Once() },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Loading data for the GetProposalSequence  test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for ValidateDocumentPackageModel</returns>
      public static IEnumerable<object[]> GetDataForGetProposalSequence(int numTests)
      {
         // <summary>
         // object[] definition
         // </summary>
         // <param name="document package id">Document package name</param>
         // <param name="expectedResult">expected sequence</param>
         // <param name="timesCalled">Times the method is called</param>
         var allData = new List<object[]>
            {
               // Scenario 1: valid document package id returns count
              new object[] { 1, 1, Times.Once() },

               // Scenario 2: valid document package id returns count
               new object[] { 2, 2, Times.Once() }
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test GetDocumentPackageSeqAsync for different scenarios
      /// </summary>
      /// <param name="tableName">Table name</param>
      /// <param name="expectedId">Expected  document package id</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <returns>Document package Id</returns>
      [Theory]
      [MemberData(nameof(GetDocumentPackage), parameters: 2)]
      public async Task GetSequenceNumberAsync_ForDifferentRequest_ReturnsDocumentPackageId(string tableName, int expectedId, Times timesCalled)
      {
         this.documentPackageRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(expectedId));

         // Act
         var actionResult = await this.packageRepository.GetSequenceNumberAsync(tableName);

         // Assert
         Assert.IsType<int>(actionResult);
         Assert.Equal(expectedId, actionResult);
         this.documentPackageRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), timesCalled);
      }

      /// <summary>
      /// Method to test ValidateDocumentPackageModel for different scenarios
      /// </summary>
      /// <param name="documentPackageName">Document package name</param>
      /// <param name="count">Actual count of the items with the same document package name</param>
      /// <param name="expectedResult">Validation result</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <returns>Returns true if the document package name does not exist else returns false</returns>
      [Theory]
      [MemberData(nameof(GetDataForValidation), parameters: 2)]
      public async Task ValidateDocumentPackageModel_ForDifferentRequest_ReturnsTrueOrFalse(string documentPackageName, int count, bool expectedResult, Times timesCalled)
      {
         int jobId = 8401;
         this.documentPackageRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(count));

         // Act
         var actionResult = await this.packageRepository.ValidateDocumentPackage(documentPackageName, jobId);

         // Assert
         Assert.IsType<bool>(actionResult);
         Assert.Equal(expectedResult, actionResult);
         this.documentPackageRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), timesCalled);
      }

      /// <summary>
      /// Get document package details - invalid input
      /// </summary>
      /// <returns>Null</returns>
      [Fact]
      public async Task GetDocPkgDetails_InvalidInput_ReturnsNull()
      {
         // Arrange
         DocPkgDetailsModel documentPackageList = null;

         this.documentPackageRepository.Setup(x => x.ExecuteQuery<DocPkgDetailsModel>(It.IsAny<string>(), It.IsAny<string>()))
          .Returns(Task.FromResult(documentPackageList));

         // Act
         var result = await this.packageRepository.GetDocPkgDetails(-11);

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify(x => x.ExecuteQuery<DocPkgDetailsModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Get document package details - valid input
      /// </summary>
      /// <returns>Document package details for the corresponding reference ID</returns>
      [Fact]
      public async Task GetDocumentPackageDetails_ValidInput_ReturnsDetails()
      {
         // Arrange
         DocPkgDetailsModel documentPackageList = new DocPkgDetailsModel()
         {
            DOC_PKG_ID = 2,
            PKG_NAME = "doc package 6",
            PKG_DESCRIPTION = "CKL - COJO Test Sample Desc",
            LAST_MODIFIED_DATE = System.DateTime.Now,
            CREATED_DATE = System.DateTime.Now,
         };

         this.documentPackageRepository.Setup(x => x.ExecuteQuery<DocPkgDetailsModel>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(documentPackageList));

         // Act
         var result = await this.packageRepository.GetDocPkgDetails(2);

         // Assert
         Assert.IsAssignableFrom<DocPkgDetailsModel>(result);
         Assert.Equal(documentPackageList.DOC_PKG_ID, result.DOC_PKG_ID);
         this.documentPackageRepository.Verify(x => x.ExecuteQuery<DocPkgDetailsModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      ///  Method to test GetProposalSequence for different scenarios
      /// </summary>
      /// <param name="documentPackageId">Document package id</param>
      /// <param name="expectedResult">Expected count</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <returns>Returns the next sequence number for generating the proposal number</returns>
      [Theory]
      [MemberData(nameof(GetDataForGetProposalSequence), parameters: 2)]
      public async Task GetProposalSequence_ForDifferentRequest_ReturnsCount(int documentPackageId, int expectedResult, Times timesCalled)
      {
         this.documentPackageRepository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(expectedResult));

         // Act
         var actionResult = await this.packageRepository.GetProposalSequence(documentPackageId);

         // Assert
         Assert.IsType<int>(actionResult);
         Assert.Equal(expectedResult, actionResult);
         this.documentPackageRepository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), timesCalled);
      }

      /// <summary>
      /// Get document packaged with invalid input
      /// </summary>
      /// <returns>Empty List</returns>
      [Fact]
      public async Task GetDocumentPackageDetails_InvalidInput_ReturnsEmptyList()
      {
         // Arrange
         var jobId = 8401;
         IEnumerable<DocumentPackageSummaryModel> documentpackageList = Enumerable.Empty<DocumentPackageSummaryModel>();

         this.documentPackageRepository.Setup(x => x.ExecuteListQuery<DocumentPackageSummaryModel>(It.IsAny<string>(), It.IsAny<string>()))
          .Returns(Task.FromResult(documentpackageList));

         // Act
         var result = await this.packageRepository.GetDocumentPackages(jobId, "Ingersoll", "Status");

         // Assert
         Assert.Empty(result);
         this.documentPackageRepository.Verify(x => x.ExecuteListQuery<DocumentPackageSummaryModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Get document packages detail with valid input
      /// </summary>
      /// <returns>Document packages detail list</returns>
      [Fact]
      public async Task GetDocumentPackageDetails_ValidInput_ReturnsPackagesDetailList()
      {
         // Arrange
         var jobId = 8401;
         IEnumerable<DocumentPackageSummaryModel> documentpackageList = new List<DocumentPackageSummaryModel>
            {
                new DocumentPackageSummaryModel()
                {
                   DOCUMENT_TYPE = "Equipment Proposal",
                        DOC_PKG_ID = 1,
                        NAME = "doc package 6",
                        DESCRIPTION = "CKL - COJO Test Sample Desc",
                        LAST_MODIFIED_DATE = System.DateTime.Now,
                        CREATED_DATE = System.DateTime.Now,
                        LAST_MODIFIED_USER = "Ingalls, Linda",
                        STATUS = "Complete",
                        FILE_GENERATED_BY_USER = "Ingalls, Linda",
                        FILE_GENERATED_DATE = System.DateTime.Now,
                        FILE_UPLOADED_BY_USER = "Ingalls, Linda",
                        FILE_UPLOADED_DATE = System.DateTime.Now,
                        LAST_UPLOADED_VERSION = 2
                }
            };

         this.documentPackageRepository.Setup(x => x.ExecuteListQuery<DocumentPackageSummaryModel>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(documentpackageList));

         // Act
         var result = await this.packageRepository.GetDocumentPackages(jobId, "doc", "Name");

         // Assert
         Assert.IsAssignableFrom<IEnumerable<DocumentPackageSummaryModel>>(result);
         Assert.Equal(documentpackageList.FirstOrDefault().NAME, result.FirstOrDefault().NAME);
         this.documentPackageRepository.Verify(x => x.ExecuteListQuery<DocumentPackageSummaryModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFileGenerationDetails returns true when the DB updates a row
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGenerationDetails_UpdatesRow_ReturnsTrue()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGenerationDetails, It.IsAny<object>()))
            .Returns(Task.FromResult(1)).Verifiable();

         // Act
         bool result = await this.packageRepository.UpdateDocumentPackageFileGenerationDetails(1, 1, string.Empty, string.Empty, null);

         // Assert
         Assert.True(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFileGenerationDetails returns false when the DB does not update a row
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGenerationDetails_DoesntUpdateRow_ReturnsFalse()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGenerationDetails, It.IsAny<object>()))
            .Returns(Task.FromResult(0)).Verifiable();

         // Act
         bool result = await this.packageRepository.UpdateDocumentPackageFileGenerationDetails(1, 1, string.Empty, string.Empty, null);

         // Assert
         Assert.False(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFileGenerationDetails returns false if exceptions from the DB are thrown
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGenerationDetails_ConnectionThrowsException_ReturnsFalse()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGenerationDetails, It.IsAny<object>()))
            .Throws(new System.Exception("Derp")).Verifiable();

         // Act
         DocumentPackageServiceDomainException exception = await Assert.ThrowsAsync<DocumentPackageServiceDomainException>(async () => { await this.packageRepository.UpdateDocumentPackageFileGenerationDetails(1, 1, string.Empty, string.Empty, null); });

         // Assert
         Assert.NotNull(exception);
         Assert.Equal("Derp", exception.Message);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFilename returns true when the DB updates a row
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFilename_UpdatesRow_ReturnsTrue()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFilename, It.IsAny<object>()))
            .Returns(Task.FromResult(1)).Verifiable();

         // Act
         bool result = await this.packageRepository.UpdateDocumentPackageFilename(1, 1, string.Empty);

         // Assert
         Assert.True(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFilename returns false when the DB does not update a row
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFilename_DoesntUpdateRow_ReturnsFalse()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFilename, It.IsAny<object>()))
            .Returns(Task.FromResult(0)).Verifiable();

         // Act
         bool result = await this.packageRepository.UpdateDocumentPackageFilename(1, 1, string.Empty);

         // Assert
         Assert.False(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFilename returns false if exceptions from the DB are thrown
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFilename_ConnectionThrowsException_ReturnsFalse()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFilename, It.IsAny<object>()))
            .Throws(new System.Exception("Derp")).Verifiable();

         // Act
         DocumentPackageServiceDomainException exception = await Assert.ThrowsAsync<DocumentPackageServiceDomainException>(async () => { await this.packageRepository.UpdateDocumentPackageFilename(1, 1, string.Empty); });

         // Assert
         Assert.NotNull(exception);
         Assert.Equal("Derp", exception.Message);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that if the repo doesnt update that false is returned.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_RepoDoesntUpdate_ReturnsFalse()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGeneratedInfo, It.IsAny<object>()))
            .Returns(Task.FromResult(0)).Verifiable();

         // Act
         bool result = await this.packageRepository.UpdateDocumentPackageFileGeneratedInfo(new FileGeneratedModel());

         // Assert
         Assert.False(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that if the repo does update that true is returned.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_RepoDoesUpdate_ReturnsTrue()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGeneratedInfo, It.IsAny<object>()))
            .Returns(Task.FromResult(1)).Verifiable();

         // Act
         bool result = await this.packageRepository.UpdateDocumentPackageFileGeneratedInfo(new FileGeneratedModel());

         // Assert
         Assert.True(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Tests that if the repo throws an exception that the method does as well.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_RepoThrowsException_MethodThrowsException()
      {
         // Arrange
         string exceptionMessage = "I'm an exception";
         this.documentPackageRepository.Setup(d => d.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGeneratedInfo, It.IsAny<object>()))
            .Throws(new System.Exception(exceptionMessage)).Verifiable();

         // Act
         DocumentPackageServiceDomainException exception = await Assert.ThrowsAsync<DocumentPackageServiceDomainException>(async () => { await this.packageRepository.UpdateDocumentPackageFileGeneratedInfo(new FileGeneratedModel()); });

         // Assert
         Assert.Equal(exceptionMessage, exception.Message);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that a query returning no status returns null from the repo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStatus_NoStatus_ReturnsNull()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.ExecuteQuery<DocumentPackageFileStatusModel>(QueryConstants.GetDocumentPackageFileStatus, It.IsAny<object>()))
            .Returns(Task.FromResult<DocumentPackageFileStatusModel>(null)).Verifiable();

         // Act
         DocumentPackageFileStatusModel result = await this.packageRepository.GetDocumentFileStatus(1, 2, 3);

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that string status returned from the query is returned by the repo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStatus_HasStatus_ReturnsIt()
      {
         // Arrange
         DocumentPackageFileStatusModel someVeryImportantStatus = new DocumentPackageFileStatusModel() { Status = "HahaHohoHeehee", GeneratedDate = DateTime.Now };
         this.documentPackageRepository.Setup(d => d.ExecuteQuery<DocumentPackageFileStatusModel>(QueryConstants.GetDocumentPackageFileStatus, It.IsAny<object>()))
            .Returns(Task.FromResult(someVeryImportantStatus)).Verifiable();

         // Act
         DocumentPackageFileStatusModel result = await this.packageRepository.GetDocumentFileStatus(1, 2, 3);

         // Assert
         Assert.Equal(someVeryImportantStatus, result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that a DocumentPackageFileDownloadModel returned by the inner repo is returned by the outer repo when calling GetDocumentFileDownloadInfo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileDownloadInfo_HasDownloadInfo_ReturnsIt()
      {
         // Arrange
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel() { Location = "Here", Name = "T-roy", VersionId = 3 };
         this.documentPackageRepository.Setup(d => d.ExecuteQuery<DocumentPackageFileDownloadModel>(QueryConstants.GetDocumentPackageFileDownloadInfo, It.IsAny<object>()))
            .Returns(Task.FromResult(downloadModel)).Verifiable();

         // Act
         DocumentPackageFileDownloadModel result = await this.packageRepository.GetDocumentFileDownloadInfo(1, 2, 3);

         // Assert
         Assert.Equal(downloadModel, result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that a DocumentPackageFileDownloadModel returned by the inner repo is returned by the outer repo when calling GetMostRecentDocumentFileDownloadInfo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetMostRecentDocumentFileDownloadInfo_HasDownloadInfo_ReturnsIt()
      {
         // Arrange
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel() { Location = "Here", Name = "T-roy", VersionId = 3 };
         this.documentPackageRepository.Setup(d => d.ExecuteQuery<DocumentPackageFileDownloadModel>(QueryConstants.GetMostRecentDocumentPackageFileDownloadInfo, It.IsAny<object>()))
            .Returns(Task.FromResult(downloadModel)).Verifiable();

         // Act
         DocumentPackageFileDownloadModel result = await this.packageRepository.GetMostRecentDocumentFileDownloadInfo(1, 2);

         // Assert
         Assert.Equal(downloadModel, result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that models returned by the internal repo get passed out through the outer repo.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentPackageFileHistories_HasHistoryRecords_ReturnsThem()
      {
         // Arrange
         DocumentPackageFileHistoryModel historyModel = new DocumentPackageFileHistoryModel();

         this.documentPackageRepository.Setup(d => d.ExecuteListQuery<DocumentPackageFileHistoryModel>(QueryConstants.GetDocumentPackageFileHistories, It.IsAny<object>()))
            .Returns(Task.FromResult(new DocumentPackageFileHistoryModel[] { historyModel }.AsEnumerable()))
            .Verifiable();

         // Act
         IEnumerable<DocumentPackageFileHistoryModel> result = await this.packageRepository.GetDocumentPackageFileHistories(1, 2);

         // Assert
         Assert.Equal(historyModel, result.First());
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that models returned by the internal repo get passed out through the outer repo.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetPackageDocument_HasPackageDocumentRecords_ReturnsThem()
      {
         // Arrange
         DocumentPackageFileModel dataPackageFileModel = new DocumentPackageFileModel()
         {
            FILE_NAME = "someFileName",
            GENERATED_BY_USER = "user",
            GENERATED_DATE = DateTime.Now,
         };

         this.documentPackageRepository.Setup(d => d.ExecuteListQuery<DocumentPackageFileModel>(QueryConstants.GetPackageDocument, It.IsAny<object>()))
            .Returns(Task.FromResult(new DocumentPackageFileModel[] { dataPackageFileModel }.AsEnumerable()))
            .Verifiable();

         // Act
         IEnumerable<DocumentPackageFileModel> result = await this.packageRepository.GetPackageDocument(1, 2);

         // Assert
         Assert.Equal(dataPackageFileModel, result.First());
         this.documentPackageRepository.Verify();
      }
   }
}
