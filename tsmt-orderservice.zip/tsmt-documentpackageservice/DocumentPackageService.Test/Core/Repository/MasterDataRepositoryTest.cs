﻿// <copyright file="MasterDataRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using DataAccess.Core.Abstractions;
   using DocumentPackageService.Configurations.AutoMapperConfiguration;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.ViewModels;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   /// <summary>
   /// MasterDataRepositoryTest
   /// </summary>
   public class MasterDataRepositoryTest
   {
      private readonly Mock<IRepository<DocumentGroupModel>> repository;
      private readonly IMapper mapper;
      private readonly Mock<IConnectionFactory> connectionFactory;
      private readonly MasterDataRepository masterDataRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="MasterDataRepositoryTest"/> class.
      /// </summary>
      public MasterDataRepositoryTest()
      {
         this.connectionFactory = new Mock<IConnectionFactory>();
         this.repository = new Mock<IRepository<DocumentGroupModel>>();
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });

         this.mapper = config.CreateMapper();
         this.masterDataRepository = new MasterDataRepository(this.mapper, this.repository.Object);
      }

      /// <summary>
      /// Get Business streams has no value returns empty business stream List
      /// </summary>
      /// <returns>returns empty business stream list</returns>
      [Fact]
      public async Task GetBusinessStreams_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         IEnumerable<DocumentGroupModel> businessStreamList = null;

         this.repository.Setup(x => x.ExecuteListQuery<DocumentGroupModel>(It.IsAny<string>()))
             .Returns(Task.FromResult(businessStreamList));

         // Act
         var result = await this.masterDataRepository.GetBusinessStreams();

         // Assert
         Assert.Null(result);
         this.repository.Verify(x => x.ExecuteListQuery<DocumentGroupModel>(It.IsAny<string>()), Times.Once);
      }

      /// <summary>
      /// Get Business streams returns business stream List
      /// </summary>
      /// <returns>returns business stream list</returns>
      [Fact]
      public async Task GetBusinessStreams_HasValue_ReturnsValidList()
      {
         // Arrange
         IEnumerable<DocumentGroupModel> businessStreamList = new List<DocumentGroupModel>()
         {
            new DocumentGroupModel()
            {
               DOC_GROUP_ID = 1,
               GROUP_NAME = "New Equipment",
               STATUS = "C",
               GROUP_ABSTRACT = "New Equipment",
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            }
         };

         this.repository.Setup(x => x.ExecuteListQuery<DocumentGroupModel>(It.IsAny<string>()))
             .Returns(Task.FromResult(businessStreamList));

         // Act
         var result = await this.masterDataRepository.GetBusinessStreams();

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Any());
         Assert.True(result.Where(a => a.BusinessStreamId == 1).Count() > 0);
         Assert.True(result.Where(a => a.BusinessStreamName == "New Equipment").Count() > 0);
         this.repository.Verify(x => x.ExecuteListQuery<DocumentGroupModel>(It.IsAny<string>()), Times.Once);
      }

      /// <summary>
      /// GetDocumentTypes has no value returns empty document type list
      /// </summary>
      /// <returns>returns empty document type list</returns>
      [Fact]
      public async Task GetDocumentTypes_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         int docGroupId = 1;
         IEnumerable<DocumentTypeModel> documentTypeList = null;

         this.repository.Setup(x => x.ExecuteListQuery<DocumentTypeModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(documentTypeList));

         // Act
         var result = await this.masterDataRepository.GetDocumentTypes(docGroupId);

         // Assert
         Assert.Null(result);
         this.repository.Verify(x => x.ExecuteListQuery<DocumentTypeModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// GetDocumentTypes returns document type list
      /// </summary>
      /// <returns>returns document type list</returns>
      [Fact]
      public async Task GetDocumentTypes_HasValue_ReturnsValidList()
      {
         // Arrange
         int docGroupId = 1;
         IEnumerable<DocumentTypeModel> documentTypeList = new List<DocumentTypeModel>()
         {
            new DocumentTypeModel()
            {
               DOC_TYPE_ID = 1,
               DOC_TYPE_NAME = "Equipment Proposal",
               DOC_GROUP_ID = 1,
               STATUS = "C",
               DOC_TYPE_ABSTRACT = "Equipment Proposal",
               DOC_TYPE_SEQ_NBR = 1,
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            },
            new DocumentTypeModel()
            {
               DOC_TYPE_ID = 2,
               DOC_GROUP_ID = 1,
               DOC_TYPE_NAME = "Equipment Submittal",
               STATUS = "C",
               DOC_TYPE_ABSTRACT = "Equipment Submittal",
               DOC_TYPE_SEQ_NBR = 1,
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            }
         };

         this.repository.Setup(x => x.ExecuteListQuery<DocumentTypeModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(documentTypeList));

         // Act
         var result = await this.masterDataRepository.GetDocumentTypes(docGroupId);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(2, result.Count());
         Assert.True(result.Where(a => a.DocumentTypeId == 1).Count() > 0);
         Assert.True(result.Where(a => a.DocumentTypeName == "Equipment Proposal").Count() > 0);
         this.repository.Verify(x => x.ExecuteListQuery<DocumentTypeModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// GetLegalEntities has no value returns empty legal entity list
      /// </summary>
      /// <returns>returns empty legal entities list</returns>
      [Fact]
      public async Task GetLegalEntities_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         int docTypeId = 1;
         IEnumerable<LegalEntityModel> legalEntityList = null;

         this.repository.Setup(x => x.ExecuteListQuery<LegalEntityModel>(It.IsAny<string>()))
             .Returns(Task.FromResult(legalEntityList));

         // Act
         var result = await this.masterDataRepository.GetLegalEntities(docTypeId);

         // Assert
         Assert.Null(result);
         this.repository.Verify(x => x.ExecuteListQuery<LegalEntityModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// GetLegalEntities returns legal entity list
      /// </summary>
      /// <returns>returns legal entities list</returns>
      [Fact]
      public async Task GetLegalEntities_HasValue_ReturnsValidList()
      {
         // Arrange
         int docTypeId = 1;
         IEnumerable<LegalEntityModel> legalEntityList = new List<LegalEntityModel>()
         {
            new LegalEntityModel()
            {
               LEGAL_ENTITY_ID = 1,
               ENTITY_SHORT_NAME = "Trane",
               ENTITY_ABSTRACT = "Trane U.S. Inc.",
               ENTITY_LONG_NAME = "Trane U.S. Inc.",
               ENTITY_EFFECTIVE_DATE = DateTime.Now.AddDays(-300),
               ENTITY_EXPIRATION_DATE = DateTime.Now.AddDays(300),
               SEQUENCE_NBR = 1
            },
            new LegalEntityModel()
            {
               LEGAL_ENTITY_ID = 2,
               ENTITY_SHORT_NAME = "Trane",
               ENTITY_ABSTRACT = "Trane Canada ULC",
               ENTITY_LONG_NAME = "Trane Canada ULC",
               ENTITY_EFFECTIVE_DATE = DateTime.Now.AddDays(-300),
               ENTITY_EXPIRATION_DATE = DateTime.Now.AddDays(300),
               SEQUENCE_NBR = 2
            },
         };

         this.repository.Setup(x => x.ExecuteListQuery<LegalEntityModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(legalEntityList));

         // Act
         var result = await this.masterDataRepository.GetLegalEntities(docTypeId);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(2, result.Count());
         Assert.True(result.Where(a => a.LegalEntityId == 1).Count() > 0);
         Assert.True(result.Where(a => a.LegalEntityName == "Trane U.S. Inc.").Count() > 0);
         this.repository.Verify(x => x.ExecuteListQuery<LegalEntityModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// GetTermsAndConditions has no value returns empty terms and condition list
      /// </summary>
      /// <returns>returns empty terms and conditions list</returns>
      [Fact]
      public async Task GetTermsAndConditions_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         int docTypeId = 5;
         IEnumerable<TermsAndConditionsModel> termsAndConditionsModelList = null;

         this.repository.Setup(x => x.ExecuteListQuery<TermsAndConditionsModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(termsAndConditionsModelList));

         // Act
         var result = await this.masterDataRepository.GetTermsAndConditions(docTypeId);

         // Assert
         Assert.Null(result);
         this.repository.Verify(x => x.ExecuteListQuery<TermsAndConditionsModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// GetTermsAndConditions returns terms and condition list
      /// </summary>
      /// <returns>returns terms and conditions list</returns>
      [Fact]
      public async Task GetTermsAndConditions_HasValue_ReturnsValidList()
      {
         // Arrange
         int docTypeId = 5;
         IEnumerable<TermsAndConditionsModel> termsAndConditionsModelList = new List<TermsAndConditionsModel>()
         {
            new TermsAndConditionsModel()
            {
               TERMS_COND_ID = 1,
               TERMS_COND_NAME = "Supplier",
               SEQUENCE_NBR = 1,
                DEFAULT_IND = 0,
               TERMS_COND_DESCRIPTION = "Supplier",
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            },
            new TermsAndConditionsModel()
            {
               TERMS_COND_ID = 2,
               TERMS_COND_NAME = "Installation",
               SEQUENCE_NBR = 2,
               DEFAULT_IND = 1,
               TERMS_COND_DESCRIPTION = "Installation",
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            },
            new TermsAndConditionsModel()
            {
               TERMS_COND_ID = 3,
               TERMS_COND_NAME = "Supplier (French Canadian)",
               SEQUENCE_NBR = 3,
                DEFAULT_IND = 0,
               TERMS_COND_DESCRIPTION = "Supplier (French Canadian)",
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            },
            new TermsAndConditionsModel()
            {
               TERMS_COND_ID = 4,
               TERMS_COND_NAME = "Installation (French Canadian)",
               SEQUENCE_NBR = 4,
                DEFAULT_IND = 0,
               TERMS_COND_DESCRIPTION = "Installation (French Canadian)",
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            }
         };

         this.repository.Setup(x => x.ExecuteListQuery<TermsAndConditionsModel>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(termsAndConditionsModelList));

         // Act
         var result = await this.masterDataRepository.GetTermsAndConditions(docTypeId);

         // Assert
         Assert.NotNull(result);
         Assert.Equal(4, result.Count());
         Assert.True(result.Where(a => a.TermsAndConditionsId == 1).Count() > 0);
         Assert.True(result.Where(a => a.TermsAndConditionsName == "Supplier").Count() > 0);
         this.repository.Verify(x => x.ExecuteListQuery<TermsAndConditionsModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Get job document types has no value returns empty file type List
      /// </summary>
      /// <returns>returns empty  list job document type</returns>
      [Fact]
      public async Task GetJobDocumentType_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         IEnumerable<JobDocumentTypeModel> fileTypeList = null;

         this.repository.Setup(x => x.ExecuteListQuery<JobDocumentTypeModel>(It.IsAny<string>()))
             .Returns(Task.FromResult(fileTypeList));

         // Act
         var result = await this.masterDataRepository.GetJobDocumentType();

         // Assert
         Assert.Null(result);
         this.repository.Verify(x => x.ExecuteListQuery<JobDocumentTypeModel>(It.IsAny<string>()), Times.Once);
      }

      /// <summary>
      /// Get job document types returns file type List
      /// </summary>
      /// <returns>returns job document type list</returns>
      [Fact]
      public async Task GetJobDocumentType_HasValue_ReturnsValidList()
      {
         // Arrange
         IEnumerable<JobDocumentTypeModel> fileTypeList = new List<JobDocumentTypeModel>()
         {
            new JobDocumentTypeModel()
            {
               JOB_DOCUMENT_TYPE_ID = 0,
               TYPE_NAME = "Contract",
               TYPE_SEQ_NBR = 1,
               TYPE_ABSTRACT = "Contract",
               CREATED_BY_USER = string.Empty,
               CREATED_DATE = DateTime.Now,
               LAST_MODIFIED_USER = string.Empty,
               LAST_MODIFIED_DATE = DateTime.Now
            }
         };

         this.repository.Setup(x => x.ExecuteListQuery<JobDocumentTypeModel>(It.IsAny<string>()))
             .Returns(Task.FromResult(fileTypeList));

         // Act
         var result = await this.masterDataRepository.GetJobDocumentType();

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Any());
         Assert.True(result.Where(a => a.JobDocumentTypeId == 0).Count() > 0);
         Assert.True(result.Where(a => a.TypeName == "Contract").Count() > 0);
         this.repository.Verify(x => x.ExecuteListQuery<JobDocumentTypeModel>(It.IsAny<string>()), Times.Once);
      }
   }
}
