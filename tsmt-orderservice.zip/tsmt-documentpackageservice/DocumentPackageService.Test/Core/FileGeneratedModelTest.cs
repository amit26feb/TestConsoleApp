﻿// <copyright file="FileGeneratedModelTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core
{
   using System;
   using System.Collections.Generic;
   using System.Text;
   using DocumentPackageService.Core.Models;
   using Xunit;

   /// <summary>
   /// FileGeneratedModel tests
   /// </summary>
   public class FileGeneratedModelTest
   {
      private readonly FileGeneratedModel modelUnderTest;
      private readonly int drAddressId = 1;
      private readonly int jobId = 2;
      private readonly int docPackageId = 3;
      private readonly int version = 4;

      /// <summary>
      /// Initializes a new instance of the <see cref="FileGeneratedModelTest"/> class.
      /// </summary>
      public FileGeneratedModelTest()
      {
         this.modelUnderTest = new FileGeneratedModel();
      }

      /// <summary>
      /// Verifies that the ReportId setter updates the separate parts of the id
      /// </summary>
      [Fact]
      public void ReportId_Setter_SetsIdParts()
      {
         this.modelUnderTest.ReportId = $"{this.drAddressId}/{this.jobId}/{this.docPackageId}/{this.version}";
         Assert.Equal(this.drAddressId, this.modelUnderTest.GetDrAddressId());
         Assert.Equal(this.jobId, this.modelUnderTest.GetJobId());
         Assert.Equal(this.docPackageId, this.modelUnderTest.GetDocPackageId());
         Assert.Equal(this.version, this.modelUnderTest.GetVersion());
      }

      /// <summary>
      /// Verifies IsRequestValid method with multiple different invalid text.
      /// </summary>
      [Fact]
      public void IsRequestValid_InvalidVariants_ReturnFalse()
      {
         this.modelUnderTest.ReportId = string.Empty;
         Assert.False(this.modelUnderTest.IsRequestValid());

         this.modelUnderTest.ReportId = this.drAddressId.ToString();
         Assert.False(this.modelUnderTest.IsRequestValid());

         this.modelUnderTest.ReportId = $"{this.drAddressId}/{this.jobId}";
         Assert.False(this.modelUnderTest.IsRequestValid());

         this.modelUnderTest.ReportId = $"{this.drAddressId}/{this.jobId}/{this.docPackageId}";
         Assert.False(this.modelUnderTest.IsRequestValid());

         this.modelUnderTest.ReportId = $"{this.drAddressId}/0/{this.docPackageId}/{this.version}";
         Assert.False(this.modelUnderTest.IsRequestValid());

         this.modelUnderTest.ReportId = $"{this.drAddressId}/{this.jobId}/0/{this.version}";
         Assert.False(this.modelUnderTest.IsRequestValid());
      }

      /// <summary>
      /// Verifies IsRequestValid with valid requestId parts
      /// </summary>
      [Fact]
      public void IsRequestValid_ValidRequestIdParts_ReturnTrue()
      {
         this.modelUnderTest.ReportId = $"{this.drAddressId}/{this.jobId}/{this.docPackageId}/{this.version}";
         Assert.True(this.modelUnderTest.IsRequestValid());

         // 0 is also a valid version
         this.modelUnderTest.ReportId = $"{this.drAddressId}/{this.jobId}/{this.docPackageId}/0";
         Assert.True(this.modelUnderTest.IsRequestValid());
      }

      /// <summary>
      /// Verifies GetGeneratedStatus returns Failed status if there are errors.
      /// </summary>
      [Fact]
      public void GetGeneratedStatus_HasErrors_ReturnsFailed()
      {
         // Arrange
         this.modelUnderTest.InternalErrors = new List<string>() { "some error" };

         // Act
         string status = this.modelUnderTest.GetGeneratedStatus();

         // Assert
         Assert.Equal(GeneratedStatusOptions.Failed, status);
      }

      /// <summary>
      /// Verifies GetGeneratedStatus returns Complete if there are null errors
      /// </summary>
      [Fact]
      public void GetGeneratedStatus_NullErrors_ReturnsComplete()
      {
         // Arrange
         this.modelUnderTest.InternalErrors = null;

         // Act
         string status = this.modelUnderTest.GetGeneratedStatus();

         // Assert
         Assert.Equal(GeneratedStatusOptions.Complete, status);
      }

      /// <summary>
      /// Verifies GetGeneratedStatus returns Complete if there are no errors
      /// </summary>
      [Fact]
      public void GetGeneratedStatus_NoErrors_ReturnsComplete()
      {
         // Arrange
         this.modelUnderTest.InternalErrors = new List<string>();

         // Act
         string status = this.modelUnderTest.GetGeneratedStatus();

         // Assert
         Assert.Equal(GeneratedStatusOptions.Complete, status);
      }

      /// <summary>
      /// Verifies GetErrorSummary returns null if there are no errors
      /// </summary>
      [Fact]
      public void GetErrorSummary_NoErrors_ReturnsNull()
      {
         // Arrange
         this.modelUnderTest.InternalErrors = new List<string>();

         // Act
         string errorSummary = this.modelUnderTest.GetErrorSummary();

         // Assert
         Assert.Null(errorSummary);
      }

      /// <summary>
      /// Verifies GetErrorSummary returns the error description if there is one
      /// </summary>
      [Fact]
      public void GetErrorSummary_SingleError_ReturnsIt()
      {
         // Arrange
         string someError = "some error";
         this.modelUnderTest.InternalErrors = new List<string>() { someError };

         // Act
         string errorSummary = this.modelUnderTest.GetErrorSummary();

         // Assert
         Assert.Equal(someError, errorSummary);
      }

      /// <summary>
      /// Verifies GetErrorSummary concatenates errors together if there are many
      /// </summary>
      [Fact]
      public void GetErrorSummary_MultipleErrors_ConcatsThem()
      {
         // Arrange
         string someError = "some error";
         string anotherError = "another error";
         this.modelUnderTest.InternalErrors = new List<string>() { someError, anotherError };

         // Act
         string errorSummary = this.modelUnderTest.GetErrorSummary();

         // Assert
         Assert.Equal($"{someError}, {anotherError}", errorSummary);
      }
   }
}
