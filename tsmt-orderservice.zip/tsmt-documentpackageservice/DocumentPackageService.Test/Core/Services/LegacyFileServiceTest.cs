﻿// <copyright file="LegacyFileServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Threading.Tasks;
   using Amazon.S3.Model;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.Services;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Options;
   using Moq;
   using S3Wrapper;
   using TSMT.Settings;
   using Xunit;

   /// <summary>
   /// Legacy File service test
   /// </summary>
   public class LegacyFileServiceTest
   {
      /// <summary>
      /// App Settings
      /// </summary>
      private readonly Mock<IOptions<TSMTSettings>> appSettings;

      /// <summary>
      /// S3 repo
      /// </summary>
      private readonly Mock<IS3Repository> s3Repository;

      /// <summary>
      /// Context Accessor
      /// </summary>
      private readonly Mock<IHttpContextAccessor> contextAccessor;

      /// <summary>
      /// Legacy File repository
      /// </summary>
      private readonly Mock<ILegacyFileRepository> legacyFileRepository;

      /// <summary>
      /// Legacy file service
      /// </summary>
      private readonly ILegacyFileService serviceUnderTest;

      /// <summary>
      /// Initializes a new instance of the <see cref="LegacyFileServiceTest"/> class.
      /// </summary>
      public LegacyFileServiceTest()
      {
         this.appSettings = new Mock<IOptions<TSMTSettings>>();
         this.s3Repository = new Mock<IS3Repository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.legacyFileRepository = new Mock<ILegacyFileRepository>();
         this.serviceUnderTest = new LegacyFileService(this.contextAccessor.Object, this.s3Repository.Object, this.appSettings.Object, this.legacyFileRepository.Object);
      }

      /// <summary>
      /// GetLegacyFiles returns empty list when there is no mapped legacy tst db name
      /// </summary>
      /// <returns>Empty collection</returns>
      [Fact]
      public async Task GetLegacyFiles_HasNoMappedLegacyTstDbName_ReturnsEmptyList()
      {
         // Arrange
         int jobId = 123;
         int drAddressId = 43;
         this.legacyFileRepository.Setup(l => l.GetLegacyTstDbName(drAddressId))
            .Returns(Task.FromResult<string>(null)).Verifiable();

         // Act
         var result = await this.serviceUnderTest.GetLegacyFiles(drAddressId, jobId);

         // Assert
         Assert.Empty(result);
         this.legacyFileRepository.Verify();
      }

      /// <summary>
      /// GetLegacyFiles returns empty list when there is a mapped legacy tst db name but no files
      /// </summary>
      /// <returns>Empty collection</returns>
      [Fact]
      public async Task GetLegacyFiles_HasMappedLegacyTstDbNameNoFiles_ReturnsEmptyList()
      {
         // Arrange
         int jobId = 123;
         int drAddressId = 43;
         string bucketName = "blurg";
         string legacyTstDbName = "SO_N_ORL";
         string legacyPrefix = legacyTstDbName.Split('_').Last().ToLower();
         string possibleFileLocation = $"jobs-legacy-files/{legacyPrefix}/{drAddressId}/{jobId}";
         this.legacyFileRepository.Setup(l => l.GetLegacyTstDbName(drAddressId))
            .Returns(Task.FromResult<string>(legacyTstDbName)).Verifiable();
         this.appSettings.Setup(a => a.Value).Returns(new TSMTSettings() { JobsBucket = bucketName }).Verifiable();
         this.s3Repository.Setup(l => l.ListVersionsAsync(bucketName, possibleFileLocation))
            .Returns(Task.FromResult<ListVersionsResponse>(new ListVersionsResponse())).Verifiable();

         // Act
         var result = await this.serviceUnderTest.GetLegacyFiles(drAddressId, jobId);

         // Assert
         Assert.Empty(result);
         this.appSettings.Verify();
         this.s3Repository.Verify();
         this.legacyFileRepository.Verify();
      }

      /// <summary>
      /// GetLegacyFiles returns a list of files when there are mapped and stored files
      /// </summary>
      /// <returns>List of files</returns>
      [Fact]
      public async Task GetLegacyFiles_HasLegacyFiles_ReturnsThem()
      {
         // Arrange
         int jobId = 123;
         int drAddressId = 43;
         string bucketName = "blurg";
         string legacyTstDbName = "SO_N_ORL";
         string legacyPrefix = legacyTstDbName.Split('_').Last().ToLower();
         string possibleFilesLocation = $"jobs-legacy-files/{legacyPrefix}/{drAddressId}/{jobId}";
         this.legacyFileRepository.Setup(l => l.GetLegacyTstDbName(drAddressId))
            .Returns(Task.FromResult<string>(legacyTstDbName)).Verifiable();
         this.appSettings.Setup(a => a.Value).Returns(new TSMTSettings() { JobsBucket = bucketName }).Verifiable();

         List<S3ObjectVersion> s3Objects = new List<S3ObjectVersion>()
         {
            new S3ObjectVersion()
            {
               Key = $"{possibleFilesLocation}/1/xyz123.docx",
               LastModified = DateTime.UtcNow,
               VersionId = "blah123",
               IsLatest = true,
               IsDeleteMarker = false
            },
            new S3ObjectVersion()
            {
               Key = $"{possibleFilesLocation}/2/abc333.docx",
               LastModified = DateTime.UtcNow.AddDays(-1),
               VersionId = "blah555",
               IsLatest = true,
               IsDeleteMarker = false
            },
            new S3ObjectVersion()
            {
               Key = $"{possibleFilesLocation}/Attachments/dfasdf.docx",
               LastModified = DateTime.UtcNow.AddDays(-2),
               VersionId = "blah999",
               IsLatest = true,
               IsDeleteMarker = false
            },
            new S3ObjectVersion()
            {
               Key = $"{possibleFilesLocation}/Attachments/iminasubdirectory/oldthing.docx",
               LastModified = DateTime.UtcNow.AddDays(-50),
               VersionId = "blah333",
               IsLatest = false,
               IsDeleteMarker = false
            },
            new S3ObjectVersion()
            {
               Key = $"{possibleFilesLocation}/Attachments/imadirectory",
               LastModified = DateTime.UtcNow.AddDays(-3),
               VersionId = "blah777",
               IsLatest = true,
               IsDeleteMarker = false
            },
            new S3ObjectVersion()
            {
               Key = $"{possibleFilesLocation}/Attachments/imadeletedfile.docx",
               LastModified = DateTime.UtcNow.AddDays(-4),
               VersionId = "blah888",
               IsLatest = true,
               IsDeleteMarker = true
            }
         };

         this.s3Repository.Setup(l => l.ListVersionsAsync(bucketName, possibleFilesLocation))
            .Returns(Task.FromResult<ListVersionsResponse>(new ListVersionsResponse()
            {
               Versions = s3Objects
            })).Verifiable();

         // Act
         var result = await this.serviceUnderTest.GetLegacyFiles(drAddressId, jobId);
         var listResult = result.ToList();

         // Assert
         Assert.NotEmpty(listResult);
         Assert.Equal(3, listResult.Count);
         Assert.Equal(Path.GetFileName(s3Objects[0].Key), listResult[0].FileName);
         Assert.Equal(s3Objects[0].LastModified, listResult[0].LastModifiedDate);
         Assert.Equal(s3Objects[0].VersionId, listResult[0].VersionId);
         Assert.Equal(s3Objects[0].Key.Replace($"{possibleFilesLocation}/", string.Empty), listResult[0].RelativeDirectoryAndFileName);
         Assert.True(listResult[0].IsLegacyLdgFile);
         Assert.False(listResult[0].IsLegacyJobCenterFile);
         Assert.Equal(Path.GetFileName(s3Objects[1].Key), listResult[1].FileName);
         Assert.Equal(s3Objects[1].LastModified, listResult[1].LastModifiedDate);
         Assert.Equal(s3Objects[1].VersionId, listResult[1].VersionId);
         Assert.Equal(s3Objects[1].Key.Replace($"{possibleFilesLocation}/", string.Empty), listResult[1].RelativeDirectoryAndFileName);
         Assert.True(listResult[1].IsLegacyLdgFile);
         Assert.False(listResult[1].IsLegacyJobCenterFile);
         Assert.Equal(Path.GetFileName(s3Objects[2].Key), listResult[2].FileName);
         Assert.Equal(s3Objects[2].LastModified, listResult[2].LastModifiedDate);
         Assert.Equal(s3Objects[2].VersionId, listResult[2].VersionId);
         Assert.Equal(s3Objects[2].Key.Replace($"{possibleFilesLocation}/Attachments/", string.Empty), listResult[2].RelativeDirectoryAndFileName);
         Assert.False(listResult[2].IsLegacyLdgFile);
         Assert.True(listResult[2].IsLegacyJobCenterFile);
         this.appSettings.Verify();
         this.s3Repository.Verify();
         this.legacyFileRepository.Verify();
      }
   }
}
