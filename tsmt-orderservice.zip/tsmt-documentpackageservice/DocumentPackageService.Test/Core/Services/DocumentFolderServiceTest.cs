﻿// <copyright file="DocumentFolderServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Security.Claims;
   using System.Threading.Tasks;
   using AutoMapper;
   using DocumentPackageService.Configurations.AutoMapperConfiguration;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using Xunit;

   /// <summary>
   /// Docuemnt folder service test
   /// </summary>
   public class DocumentFolderServiceTest
   {
      /// <summary>
      /// Mapper details
      /// </summary>
      private readonly IMapper mapper;

      /// <summary>
      /// Document folder repository
      /// </summary>
      private readonly Mock<IDocumentFolderRepository> documentFolderRepository;

      /// <summary>
      /// contextAccessor
      /// </summary>
      private readonly Mock<IHttpContextAccessor> contextAccessor;

      /// <summary>
      /// Document Folder service
      /// </summary>
      private readonly DocumentFolderService folderService;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentFolderServiceTest"/> class.
      /// </summary>
      public DocumentFolderServiceTest()
      {
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });
         this.mapper = config.CreateMapper();
         this.documentFolderRepository = new Mock<IDocumentFolderRepository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.folderService = new DocumentFolderService(this.documentFolderRepository.Object, this.mapper, this.contextAccessor.Object);
      }

      /// <summary>
      /// Verifies a request with a good DrAddressId sets it on docPackageRepo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task CreateDocumentFolder_ValidFolderViewModel_CreatedDocumentFolderSuccessfully()
      {
         // Arrange
         DocumentFolderViewModel folderViewModel = new DocumentFolderViewModel
         {
            FolderId = 0,
            FolderName = "Sample",
            FolderSource = "user",
            CreatedByUser = "dummy user",
            CreatedDate = DateTime.Now,
            DrAddressId = 101,
            FolderParentId = 0,
            JobId = 12345,
            LastModifiedDate = DateTime.Now,
            LastModifiedUser = "dummy user",
         };
         var claims = new List<Claim>()
         {
            new Claim("samAccountName", "dummy user")
         };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

         this.documentFolderRepository.Setup(x => x.GetSequenceNumberAsync(It.IsAny<string>()))
       .Returns(Task.FromResult(1));

         this.documentFolderRepository.Setup(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()))
             .Returns(Task.FromResult(true));

         // Act
         IEnumerable<DocumentFolderViewModel> result = await this.folderService.CreateDocumentFolder(folderViewModel);

         // Assert
         Assert.NotNull(result);
         this.documentFolderRepository.Verify(p => p.GetSequenceNumberAsync(It.IsAny<string>()), Times.Once);
         this.documentFolderRepository.Verify(p => p.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()), Times.Once);
      }

      /// <summary>
      ///  Getfolders returns empty list
      /// </summary>
      /// <returns>Empty result</returns>
      [Fact]
      public async Task GetFolders_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         int jobId = 1;
         IEnumerable<DocumentFolderModel> folderModel = new List<DocumentFolderModel>();

         this.documentFolderRepository.Setup(x => x.GetFolders(jobId))
         .Returns(Task.FromResult(folderModel));

         // Act
         var result = await this.folderService.GetFolders(jobId);

         // Assert
         Assert.Empty(result);
         this.documentFolderRepository.Verify(x => x.GetFolders(jobId), Times.Once);
      }

      /// <summary>
      ///  Get Folders returns DocumentFolderViewModel list
      /// </summary>
      /// <returns>DocumentFolderViewModel list</returns>
      [Fact]
      public async Task GetFolders_HasValue_ReturnsValidData()
      {
         // Arrange
         int jobId = 1;
         IEnumerable<DocumentFolderModel> modelFolders = new List<DocumentFolderModel>()
         {
            new DocumentFolderModel()
            {
               FOLDER_ID = 1,
               FOLDER_NAME = "Folder1",
               FOLDER_PARENT_ID = 0,
               FOLDER_SOURCE = "User",
               CREATED_DATE = System.DateTime.Now,
            }
          };
         IEnumerable<DocumentFolderViewModel> folders = new List<DocumentFolderViewModel>()
         {
            new DocumentFolderViewModel()
            {
               JobId = 5,
               FolderId = 1,
               FolderName = "Folder1",
               FolderParentId = 0,
               FolderSource = "User",
               DrAddressId = 101,
               CreatedByUser = "abcd",
            },
         };

         this.documentFolderRepository.Setup(x => x.GetFolders(jobId))
        .Returns(Task.FromResult(modelFolders)).Verifiable();

         // Act
         var result = await this.folderService.GetFolders(jobId);

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Count() == 1);
         Assert.True(result.Select(a => a.FolderId == 1).Any());
         Assert.True(result.Select(a => a.FolderName == "Folder1").Any());
         this.documentFolderRepository.Verify(x => x.GetFolders(jobId), Times.Once);
      }
   }
}
