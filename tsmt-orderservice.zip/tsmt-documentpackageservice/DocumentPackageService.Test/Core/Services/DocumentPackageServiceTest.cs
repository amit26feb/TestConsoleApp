﻿// <copyright file="DocumentPackageServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Security.Claims;
   using System.Threading.Tasks;
   using Amazon.S3.Model;
   using AutoMapper;
   using DocumentPackageService.Configurations.AutoMapperConfiguration;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using global::DocumentPackageService.Core.Repository;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Options;
   using Moq;
   using Newtonsoft.Json;
   using S3Wrapper;
   using TraneSalesTools;
   using TSMT.Settings;
   using Xunit;

   /// <summary>
   /// Document package service test
   /// </summary>
   public class DocumentPackageServiceTest
   {
      // Invalid data
      private static DocPackageViewModel invalidRequest = new DocPackageViewModel
      {
         Package = new DocumentPackageViewModel
         {
            BusinessStreamId = 1,
            DocumentPackageId = 0,
            DocumentTypeId = 0,
            DrAddressId = 0,
            JobId = 0,
            SalesOfficeCode = string.Empty,
            Name = string.Empty
         },
         PackageFile = new DocumentPackageFileViewModel
         {
            LegalEntityId = 0,
            TermsAndConditionsId = 0,
            AdditionalInfo = null,
            BidAlternateId = 0,
            DocumentPackageFileId = 0,
            DocumentPackageId = 0,
            DrAddressId = 0,
            FileLocation = null,
            GeneratedBy = null,
            GeneratedInfo = null,
            Status = null,
            JobId = 0,
            ProposalNumber = "001",
            Version = 0
         }
      };

      // Valid request
      private static DocPackageViewModel validProposalRequest = new DocPackageViewModel
      {
         Package = new DocumentPackageViewModel
         {
            BusinessStreamId = 1,
            DocumentPackageId = 1,
            DocumentTypeId = 5,
            DocumentTypeName = "Eqv Proposal",
            DrAddressId = 127,
            JobId = 8401,
            SalesOfficeCode = "AC",
            Name = "Package 1"
         },
         PackageFile = new DocumentPackageFileViewModel
         {
            LegalEntityId = 1,
            TermsAndConditionsId = 1,
            AdditionalInfo = new AdditionalInfoViewModel
            {
               Addressee = new AddresseeViewModel
               {
                  AllBidders = false,
                  BidderId = 1,
                  SoldToId = 0,
                  IsOther = false,
                  OtherCustomerFirstName = string.Empty,
                  OtherCustomerLastName = string.Empty,
                  OtherCustomerName = string.Empty
               },
               Introduction = new IntroductionViewModel
               {
                  ShowGreeting = true,
                  GreetingMessage = "test message",
                  ShowCustomerPONumber = false,
                  CustomerPONumber = "12345",
                  ShowCreditJobNumber = false,
                  CustomerProjectNumber = "111111",
                  ShowCustomerProjectNumber = false,
                  CreditJobNumber = "001100",
               },
               Pricing = new PricingViewModel
               {
                  IncludeADP = true
               },
               Signature = new SignatureViewModel
               {
                  AddressLine1 = "No 1",
                  AddressLine2 = "2nd street",
                  CellPhoneNumber = "12345",
                  City = "LA",
                  Country = "LA",
                  County = "LA",
                  EmailAddress = "test@ir.com",
                  FaxNumber = "1233",
                  OfficeName = "TRANE",
                  OfficePhoneNumber = "12345",
                  Sender = "Sender 1",
                  State = "LA",
                  Title = "MR",
                  ZipCode = "12345",
                  BlockOption = "both",
                  IsCustomSender = false,
                  CustomSenderNickName = "Nick"
               },
               Clarifications = new List<ClarificationViewModel>()
               {
                  new ClarificationViewModel()
                  {
                     ProductFamilyId = 1,
                     ClarificationDetails = new List<string>()
                     {
                        "1 Additional level of authority is needed in order to approve pricing.",
                        "1 Clarifications for the selected product",
                        "1 Exception for the selected product"
                     }
                  },
                  new ClarificationViewModel()
                  {
                     ProductFamilyId = 2,
                     ClarificationDetails = new List<string>()
                     {
                        "2 Additional level of authority is needed in order to approve pricing.",
                        "2 Clarifications for the selected product",
                        "2 Exception for the selected product"
                     }
                  }
               },
               ItemsNotIncluded = new List<ItemsNotIncludedViewModel>()
               {
                  new ItemsNotIncludedViewModel()
                  {
                     ProductFamilyId = 1,
                     ItemsNotIncludedDetails = new List<string>()
                     {
                        "Refrigerant",
                        "Filters"
                     }
                  },
                  new ItemsNotIncludedViewModel()
                  {
                     ProductFamilyId = 2,
                     ItemsNotIncludedDetails = new List<string>()
                     {
                        "Damage Liability",
                        "Dampeners"
                     }
                  }
               },
               DocumentSectionsToInclude = new List<DocumentSectionViewModel>()
               {
                  new DocumentSectionViewModel()
                  {
                     ProductFamilyId = 123,
                     Sections = 3
                  },
                  new DocumentSectionViewModel()
                  {
                     ProductFamilyId = 456,
                     Sections = 0
                  },
               },
               UOMMetric = false,
            },
            BidAlternateId = 1,
            DocumentPackageFileId = 1,
            DocumentPackageId = 1,
            DrAddressId = 1,
            FileLocation = "S3 file location",
            GeneratedBy = "ccecfc",
            GeneratedInfo = "Generated",
            Status = "Success",
            JobId = 8401,
            ProposalNumber = "001",
            Version = 1
         }
      };

      private static DocPackageViewModel validSubmittalRequest = new DocPackageViewModel
      {
         Package = new DocumentPackageViewModel
         {
            BusinessStreamId = 1,
            DocumentPackageId = 1,
            DocumentTypeId = 6,
            DocumentTypeName = "Eqv Submittal",
            DrAddressId = 127,
            JobId = 8401,
            SalesOfficeCode = "AC",
            Name = "Package 1"
         },
         PackageFile = new DocumentPackageFileViewModel
         {
            LegalEntityId = 1,
            TermsAndConditionsId = 1,
            AdditionalInfo = new AdditionalInfoViewModel
            {
               Addressee = new AddresseeViewModel
               {
                  AllBidders = false,
                  BidderId = 1,
                  SoldToId = 0
               },
               Introduction = new IntroductionViewModel
               {
                  ShowGreeting = true,
                  GreetingMessage = "test message"
               },
               Pricing = new PricingViewModel
               {
                  IncludeADP = true
               },
               Signature = new SignatureViewModel
               {
                  AddressLine1 = "No 1",
                  AddressLine2 = "2nd street",
                  CellPhoneNumber = "12345",
                  City = "LA",
                  Country = "LA",
                  County = "LA",
                  EmailAddress = "test@ir.com",
                  FaxNumber = "1233",
                  OfficeName = "TRANE",
                  OfficePhoneNumber = "12345",
                  Sender = "Sender 1",
                  State = "LA",
                  Title = "MR",
                  ZipCode = "12345",
                  BlockOption = "both"
               },
               Clarifications = new List<ClarificationViewModel>()
               {
                  new ClarificationViewModel()
                  {
                     ProductFamilyId = 1,
                     ClarificationDetails = new List<string>()
                     {
                        "1 Additional level of authority is needed in order to approve pricing.",
                        "1 Clarifications for the selected product",
                        "1 Exception for the selected product"
                     }
                  },
                  new ClarificationViewModel()
                  {
                     ProductFamilyId = 2,
                     ClarificationDetails = new List<string>()
                     {
                        "2 Additional level of authority is needed in order to approve pricing.",
                        "2 Clarifications for the selected product",
                        "2 Exception for the selected product"
                     }
                  }
               },
               ItemsNotIncluded = new List<ItemsNotIncludedViewModel>()
               {
                  new ItemsNotIncludedViewModel()
                  {
                     ProductFamilyId = 1,
                     ItemsNotIncludedDetails = new List<string>()
                     {
                        "Refrigerant",
                        "Filters"
                     }
                  },
                  new ItemsNotIncludedViewModel()
                  {
                     ProductFamilyId = 2,
                     ItemsNotIncludedDetails = new List<string>()
                     {
                        "Damage Liability",
                        "Dampeners"
                     }
                  }
               },
               DocumentSectionsToInclude = new List<DocumentSectionViewModel>()
               {
                  new DocumentSectionViewModel()
                  {
                     ProductFamilyId = 123,
                     Sections = 3
                  },
                  new DocumentSectionViewModel()
                  {
                     ProductFamilyId = 456,
                     Sections = 0
                  },
               }
            },
            BidAlternateId = 1,
            DocumentPackageFileId = 1,
            DocumentPackageId = 1,
            DrAddressId = 1,
            FileLocation = "S3 file location",
            GeneratedBy = "ccecfc",
            GeneratedInfo = "Generated",
            Status = "Success",
            JobId = 8401,
            ProposalNumber = null,
            Version = 1
         }
      };

      // Sample data
      private readonly int docPackId = 2;
      private readonly int version = 1;
      private readonly int jobId = 3;
      private readonly string bucketName = "mrBucket";
      private readonly string someLocation = "here";
      private readonly string someFileName = "TrueDat";
      private readonly string someFileVersion = "1";
      private readonly int docTypeId = 5;

      /// <summary>
      /// Mapper details
      /// </summary>
      private readonly IMapper mapper;

      /// <summary>
      /// Document package repository
      /// </summary>
      private readonly Mock<IDocumentPackageRepository> documentPackageRepository;

      /// <summary>
      /// contextAccessor
      /// </summary>
      private readonly Mock<IHttpContextAccessor> contextAccessor;

      /// <summary>
      /// hostingEnvironment
      /// </summary>
      private readonly Mock<IWebHostEnvironment> hostingEnvironment;

      /// <summary>
      /// salesOfficeService
      /// </summary>
      private readonly Mock<ISalesOfficeService> salesOfficeService;

      /// <summary>
      /// Document package service
      /// </summary>
      private readonly DocumentPackageService packageService;

      /// <summary>
      /// Mock S3 repository for mockin S3 related stuff
      /// </summary>
      private readonly Mock<IS3Repository> mockS3Repo;

      /// <summary>
      /// Mock TSMT setting options
      /// </summary>
      private readonly Mock<IOptions<TSMTSettings>> mockSettings;

      /// <summary>
      /// Document folder repository
      /// </summary>
      private readonly Mock<IDocumentFolderRepository> documentFolderRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageServiceTest"/> class.
      /// </summary>
      public DocumentPackageServiceTest()
      {
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });
         this.mapper = config.CreateMapper();
         this.documentPackageRepository = new Mock<IDocumentPackageRepository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.hostingEnvironment = new Mock<IWebHostEnvironment>();
         this.salesOfficeService = new Mock<ISalesOfficeService>();
         this.mockS3Repo = new Mock<IS3Repository>();
         this.mockSettings = new Mock<IOptions<TSMTSettings>>();
         this.mockSettings.Setup(ms => ms.Value).Returns(new TSMTSettings() { Bucket = this.bucketName });
         this.documentFolderRepository = new Mock<IDocumentFolderRepository>();
         this.packageService = new DocumentPackageService(this.documentPackageRepository.Object, this.mapper, this.contextAccessor.Object, this.hostingEnvironment.Object, this.salesOfficeService.Object, this.mockS3Repo.Object, this.mockSettings.Object, this.documentFolderRepository.Object);
      }

      /// <summary>
      /// Loading data for the create document package test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for CreateDocumentPackage</returns>
      public static IEnumerable<object[]> GetDataForCreateDocumentPackage(int numTests)
      {
         // <summary>
         // object[] definition
         // </summary>
         // <param name="request">Document package view model</param>
         // <param name="timesCalled">Times the method is called</param>
         // <param name="documentPackageSequence">Document package sequence number</param>
         // <param name="documentPackageFileSequence">Document package file sequence number</param>
         // <param name="status">Expected status</param>
         var allData = new List<object[]>
            {
               // Scenario 1: invalid request, returns false
               new object[] { invalidRequest, Times.Never(), 0, 0, false },

               // Scenario 2: valid proposal request returns true
               new object[] { validProposalRequest, Times.Once(), 1, 1, true },

               // Scenario 3: valid submittal request returns true
               new object[] { validSubmittalRequest, Times.Once(), 1, 1, true },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Loading data for the update document package test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for CreateDocumentPackage</returns>
      public static IEnumerable<object[]> GetDataForUpdateDocumentPackage(int numTests)
      {
         // <summary>
         // object[] definition
         // </summary>
         // <param name="request">DocumentPackageViewModel</param>
         // <param name="timesCalled">Times the method is called</param>
         // <param name="documentPackageFileSequence">Document package file sequence number</param>
         // <param name="status">Expected status</param>
         // <param name="nextProposalSeq">Next proposal sequence number</param>
         // <param name="proposalSeqTimes">Times the get proposal sequence number method is called</param>
         // <param name="docPackFileCount">Count of the doc pack file with the same combination and generated status</param>
         // <param name="validationTimesCalled">Times the document package file validation method is called</param>
         var allData = new List<object[]>
            {
               // Scenario 1: invalid request, returns false
               new object[] { invalidRequest, Times.Once(), 0, false, 0, Times.Never(), 0, Times.Once() },

               // Scenario 2: valid proposal request returns true
               new object[] { validProposalRequest, Times.Once(), 2, true, 2, Times.Once(), 1, Times.Once() },

               // Scenario 3: valid submittal request returns true
               new object[] { validSubmittalRequest, Times.Once(), 2, true, 2, Times.Once(), 1, Times.Once() },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Loading data for the get office selector
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for CreateDocumentPackage</returns>
      public static IEnumerable<object[]> GetDataForOfficeSelector(int numTests)
      {
         // Invalid data
         List<SalesOfficeView> invalidSalesOfficeList = new List<SalesOfficeView>();

         // Valid request
         List<SalesOfficeView> validSalesOfficeList = new List<SalesOfficeView>
            {
                new SalesOfficeView()
                {
                    SalesOfficeName = "Portland ME",
                    DrAddressId = 94,
                    Country = "USA"
                },

                new SalesOfficeView()
                {
                    SalesOfficeName = "Springfield MA",
                    DrAddressId = 34,
                    Country = "USA"
                },
            };

         var allData = new List<object[]>
            {
                new object[] { invalidSalesOfficeList, Times.Once() },
                new object[] { validSalesOfficeList, Times.Once() },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test createdocument package for different scenarios
      /// </summary>
      /// <param name="request">CreateDocumentPackageViewModel</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="documentPackageSequence">Document package sequence number</param>
      /// <param name="documentPackageFileSequence">Document package file sequence number</param>
      /// <param name="status">Creation status</param>
      /// <returns>Returns true if document package is created successfully else returns false</returns>
      [Theory]
      [MemberData(nameof(GetDataForCreateDocumentPackage), parameters: 2)]
      public async Task CreateDocumentPackage_ForTwoDifferentRequests_ReturnsCreationStatus(DocPackageViewModel request, Times timesCalled, int documentPackageSequence, int documentPackageFileSequence, bool status)
      {
         // Arrange
         this.documentPackageRepository.Setup(x => x.GetSequenceNumberAsync(It.IsAny<string>()))
            .Returns(Task.FromResult(documentPackageSequence));

         this.documentPackageRepository.Setup(x => x.GetSequenceNumberAsync(It.IsAny<string>()))
            .Returns(Task.FromResult(documentPackageFileSequence));

         this.documentPackageRepository.Setup(x => x.CreateDocumentPackage(It.IsAny<DocumentPackageModel>(), It.IsAny<DocumentPackageFileModel>()))
             .Returns(Task.FromResult(status));

         var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

         // Act
         var result = await this.packageService.CreateDocumentPackage(request);

         // Assert
         if (status)
         {
            Assert.IsType<DocPackageViewModel>(result);
            Assert.Equal(result.Package.DocumentPackageId, documentPackageSequence);
            if (result.Package.DocumentTypeId == validProposalRequest.Package.DocumentTypeId)
            {
               Assert.True(!string.IsNullOrEmpty(result.PackageFile.ProposalNumber));
            }
            else
            {
               Assert.True(string.IsNullOrEmpty(result.PackageFile.ProposalNumber));
            }
         }
         else
         {
            Assert.Null(result);
         }

         this.documentPackageRepository.Verify(x => x.CreateDocumentPackage(It.IsAny<DocumentPackageModel>(), It.IsAny<DocumentPackageFileModel>()), timesCalled);
      }

      /// <summary>
      /// Method to test update document package for different scenarios
      /// </summary>
      /// <param name="request">DocumentPackageViewModel</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="documentPackageFileSequence">Document package file sequence number</param>
      /// <param name="status">Creation status</param>
      /// <param name="nextProposalSeq">Next proposal sequence number</param>
      /// <param name="proposalSeqTimes">Times the get proposal sequence number method is called</param>
      /// <param name="docPackFileCount">Count of the doc pack file with the same combination and generated status</param>
      /// <param name="validationTimesCalled">Times the document package file validation method is called</param>
      /// <returns>Returns true if document package is created successfully else returns false</returns>
      [Theory]
      [MemberData(nameof(GetDataForUpdateDocumentPackage), parameters: 2)]
      public async Task UpdateDocumentPackage_ForTwoDifferentRequests_ReturnsCreationStatus(DocPackageViewModel request, Times timesCalled, int documentPackageFileSequence, bool status, int nextProposalSeq, Times proposalSeqTimes, int docPackFileCount, Times validationTimesCalled)
      {
         // Arrange
         this.documentPackageRepository.Setup(x => x.UpsertDocumentPackage(It.IsAny<DocumentPackageModel>(), It.IsAny<DocumentPackageFileModel>(), It.IsAny<bool>()))
             .Returns(Task.FromResult(status));

         this.documentPackageRepository.Setup(x => x.GetSequenceNumberAsync(It.IsAny<string>()))
            .Returns(Task.FromResult(documentPackageFileSequence));

         this.documentPackageRepository.Setup(x => x.GetDocumentPackFileCount(It.IsAny<DocumentPackageFileModel>()))
            .Returns(Task.FromResult(docPackFileCount));

         this.documentPackageRepository.Setup(x => x.GetProposalSequence(It.IsAny<int>()))
            .Returns(Task.FromResult(nextProposalSeq));

         var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

         // Act
         var result = await this.packageService.UpdateDocumentPackage(request);

         // Assert
         if (status)
         {
            Assert.IsType<DocPackageViewModel>(result);
            Assert.Equal(result.Package.DocumentPackageId, request.Package.DocumentPackageId);
            if (result.Package.DocumentTypeId == validProposalRequest.Package.DocumentTypeId)
            {
               Assert.True(!string.IsNullOrEmpty(result.PackageFile.ProposalNumber));
            }
            else
            {
               Assert.True(string.IsNullOrEmpty(result.PackageFile.ProposalNumber));
            }
         }
         else
         {
            Assert.Null(result);
         }

         this.documentPackageRepository.Verify(x => x.GetDocumentPackFileCount(It.IsAny<DocumentPackageFileModel>()), validationTimesCalled);
         this.documentPackageRepository.Verify(x => x.UpsertDocumentPackage(It.IsAny<DocumentPackageModel>(), It.IsAny<DocumentPackageFileModel>(), It.IsAny<bool>()), timesCalled);
         this.documentPackageRepository.Verify(x => x.GetProposalSequence(It.IsAny<int>()), proposalSeqTimes);
      }

      /// <summary>
      /// Method to test get office selector for different scenarios
      /// </summary>
      /// <param name="salesOfficeList">salesOfficeList</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <returns>SalesOfficeView</returns>
      [Theory]
      [MemberData(nameof(GetDataForOfficeSelector), parameters: 2)]
      public async Task GetOfficeSelector_InvalidRequest_ReturnsEmptyList(List<SalesOfficeView> salesOfficeList, Times timesCalled)
      {
         // Arrange
         this.salesOfficeService.Setup(x => x.GetSalesOffice(It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()))
              .Returns(Task.FromResult(salesOfficeList.AsEnumerable()));

         List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

         // Act
         IEnumerable<SalesOfficeView> returnSalesOffices = await this.packageService.GetOfficeSelector();

         // Assert
         Assert.IsType<List<SalesOfficeView>>(returnSalesOffices);
         Assert.Equal(returnSalesOffices.Count(), salesOfficeList.Count);
         Assert.Equal(returnSalesOffices, salesOfficeList);
         this.salesOfficeService.Verify(x => x.GetSalesOffice(It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()), timesCalled);
      }

      /// <summary>
      /// Get document package details with invalid input
      /// </summary>
      /// <returns>Null</returns>
      [Fact]
      public async Task GetDocPkgDetails_InvalidInput_ReturnsNull()
      {
         // Arrange
         DocPkgDetailsModel documentPackageList = null;

         this.documentPackageRepository.Setup(x => x.GetDocPkgDetails(0))
            .Returns(Task.FromResult(documentPackageList));

         // Act
         DocPkgDetailsViewModel result = await this.packageService.GetDocPkgDetails(0);

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify(x => x.GetDocPkgDetails(0), Times.Once);
      }

      /// <summary>
      /// Get document package details with valid input
      /// </summary>
      /// <returns>Document package details for the corresponding reference ID</returns>
      [Fact]
      public async Task GetDocumentPackages_ValidInput_ReturnsPackageDetails()
      {
         // Arrange
         DocPkgDetailsModel documentPackageList = new DocPkgDetailsModel
         {
            DOC_PKG_ID = 2,
            PKG_NAME = "doc package 6",
            PKG_DESCRIPTION = "CKL - COJO Test Sample Desc",
            LAST_MODIFIED_DATE = System.DateTime.Now,
            CREATED_DATE = System.DateTime.Now,
            LAST_MODIFIED_USER = "Ingalls, Linda",
            PROPOSAL_NBR = "Test 1",
            ADDITIONAL_INFO = null,
            GENERATED_DATE = System.DateTime.Now
         };

         this.documentPackageRepository.Setup(x => x.GetDocPkgDetails(2))
            .Returns(Task.FromResult(documentPackageList));

         // Act
         DocPkgDetailsViewModel result = await this.packageService.GetDocPkgDetails(2);

         // Assert
         Assert.IsAssignableFrom<DocPkgDetailsViewModel>(result);
         Assert.Equal(documentPackageList.DOC_PKG_ID, result.DocumentPackageId);
         this.documentPackageRepository.Verify(x => x.GetDocPkgDetails(2), Times.Once);
      }

      /// <summary>
      /// Get document packages with invalid input
      /// </summary>
      /// <returns>null</returns>
      [Fact]
      public async Task GetDocumentPackages_InvalidInput_ReturnsNull()
      {
         // Arrange
         var jobId = 8401;
         IEnumerable<DocumentPackageSummaryModel> documentpackagelist = new List<DocumentPackageSummaryModel>();

         this.documentPackageRepository.Setup(x => x.GetDocumentPackages(jobId, "Ingersoll", "MODIFIED_DATE"))
            .Returns(Task.FromResult(documentpackagelist));

         // Act
         IEnumerable<DocumentPackageSummaryViewModel> result = await this.packageService.GetDocumentPackages(jobId, "Ingersoll", "MODIFIED_DATE");

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify(x => x.GetDocumentPackages(jobId, "Ingersoll", "MODIFIED_DATE"), Times.Once);
      }

      /// <summary>
      /// Get document packages with valid input
      /// </summary>
      /// <returns>Document packages detail List</returns>
      [Fact]
      public async Task GetDocumentPackages_ValidInput_ReturnsPackageList()
      {
         // Arranges
         var jobId = 8401;
         IEnumerable<DocumentPackageSummaryModel> documentpackageList = new List<DocumentPackageSummaryModel>
            {
                new DocumentPackageSummaryModel()
                {
                   DOCUMENT_TYPE = "Equipment Proposal",
                        DOC_PKG_ID = 1,
                        NAME = "Doc Package 6",
                        DESCRIPTION = "CKL - COJO Test Sample Desc",
                        LAST_MODIFIED_DATE = System.DateTime.Now,
                        CREATED_DATE = System.DateTime.Now,
                        LAST_MODIFIED_USER = "Ingalls, Linda",
                        STATUS = "Complete"
                }
            };

         this.documentPackageRepository.Setup(x => x.GetDocumentPackages(jobId, "Doc Package", "STATUS"))
            .Returns(Task.FromResult(documentpackageList));

         // Act
         IEnumerable<DocumentPackageSummaryViewModel> result = await this.packageService.GetDocumentPackages(jobId, "Doc Package", "STATUS");

         // Assert
         Assert.IsAssignableFrom<IEnumerable<DocumentPackageSummaryViewModel>>(result);
         Assert.Equal(documentpackageList.FirstOrDefault().NAME, result.FirstOrDefault().Name);
         this.documentPackageRepository.Verify(x => x.GetDocumentPackages(jobId, "Doc Package", "STATUS"), Times.Once);
      }

      /// <summary>
      /// Tests that method UpdateDocumentPackageFileStatus will not attempt an update if an account name
      /// is not included in the HttpContext and returns false
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileStatus_NoUserIdInClaims_ReturnsFalseAndDoesntUpdate()
      {
         // Arrange
         this.contextAccessor.Setup(ca => ca.HttpContext.User).Returns<ClaimsPrincipal>(null);

         // Act
         bool result = await this.packageService.UpdateDocumentPackageFileStatus(1, 2, string.Empty);

         // Assert
         Assert.False(result);
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFileStatus succeeds and retains generation details if HttpContext
      /// contains a value for the account name and generation status is not "uploaded"
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGenerationDetails_HasUserIdInClaimsGeneratedStatus_ReturnsUpdateResultAndRetainsGeneratedDetails()
      {
         // Arrange
         string status = "Generated";
         string userId = "RolloSigurdsson";
         List<Claim> claims = new List<Claim>() { new Claim("samAccountName", userId) };
         this.contextAccessor.Setup(ca => ca.HttpContext.User.Claims).Returns(claims);
         this.documentPackageRepository.Setup(d => d.UpdateDocumentPackageFileGenerationDetails(this.docPackId, this.version, status, userId.ToLower(), It.IsAny<DateTime>()))
            .Returns(Task.FromResult(true)).Verifiable();

         // Act
         bool result = await this.packageService.UpdateDocumentPackageFileStatus(this.docPackId, this.version, status);

         // Assert
         Assert.True(result);
         this.documentPackageRepository.Verify();
         this.documentPackageRepository.Verify(d => d.UpdateDocumentPackageFileGenerationDetails(this.docPackId, this.version, status, null, null), Times.Never);
      }

      /// <summary>
      /// Tests that UpdateDocumentPackageFileStatus succeeds and clears generation details if HttpContext
      /// contains a value for the account name and generation status is "uploaded"
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGenerationDetails_HasUserIdInClaimsUploadedStatus_ReturnsUpdateResultAndClearsGeneratedDetails()
      {
         // Arrange
         string status = "Uploaded";
         string userId = "RagnarLothbrok";
         List<Claim> claims = new List<Claim>() { new Claim("samAccountName", userId) };
         this.contextAccessor.Setup(ca => ca.HttpContext.User.Claims).Returns(claims);
         this.documentPackageRepository.Setup(d => d.UpdateDocumentPackageFileGenerationDetails(this.docPackId, this.version, status, null, null))
            .Returns(Task.FromResult(true)).Verifiable();

         // Act
         bool result = await this.packageService.UpdateDocumentPackageFileStatus(this.docPackId, this.version, status);

         // Assert
         Assert.True(result);
         this.documentPackageRepository.Verify();
         this.documentPackageRepository.Verify(d => d.UpdateDocumentPackageFileGenerationDetails(this.docPackId, this.version, status, userId.ToLower(), It.IsAny<DateTime>()), Times.Never);
      }

      /// <summary>
      /// Tests that method UpdateDocumentPackageFilename will not attempt an update if the filename
      /// is not included and returns false
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFilename_NoFilename_ReturnsFalseAndDoesntUpdate()
      {
         // Arrange
         this.contextAccessor.Setup(ca => ca.HttpContext.User).Returns<ClaimsPrincipal>(null);

         // Act
         bool result = await this.packageService.UpdateDocumentPackageFilename(1, 2, string.Empty);

         // Assert
         Assert.False(result);
      }

      /// <summary>
      /// Tests that method UpdateDocumentPackageFilename will update if the filename
      /// is included and returns true
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFilename_HasFilename_ReturnsUpdateResult()
      {
         // Arrange
         string filename = "ricos_awesome_file";
         this.documentPackageRepository.Setup(d => d.UpdateDocumentPackageFilename(this.docPackId, this.version, filename))
            .Returns(Task.FromResult(true)).Verifiable();

         // Act
         bool result = await this.packageService.UpdateDocumentPackageFilename(this.docPackId, this.version, filename);

         // Assert
         Assert.True(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies a null model passed to update returns an error.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_NullModel_ReturnsError()
      {
         // Arrange
         FileGeneratedModel nullModel = null;

         // Act
         string result = await this.packageService.UpdateDocumentPackageFileGeneratedInfo(nullModel);

         // Assert
         Assert.Equal("FileGeneratedModel is null", result);
      }

      /// <summary>
      /// Verifies a model with a bad DrAddressId returns an error
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_BadDrAddressId_ReturnsError()
      {
         // Arrange
         FileGeneratedModel badDrAddressIdModel = new FileGeneratedModel();

         // Act
         string result = await this.packageService.UpdateDocumentPackageFileGeneratedInfo(badDrAddressIdModel);

         // Assert
         Assert.Equal("Invalid drAddressId", result);
      }

      /// <summary>
      /// Verifies a request with a good DrAddressId sets it on docPackageRepo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_GoodDrAddressId_SetsItOnRepo()
      {
         // Arrange
         int drAddressId = 123;
         FileGeneratedModel goodDrAddressIdModel = new FileGeneratedModel() { ReportId = drAddressId.ToString() };

         // Act
         string result = await this.packageService.UpdateDocumentPackageFileGeneratedInfo(goodDrAddressIdModel);

         // Assert
         this.documentPackageRepository.Verify(p => p.HonorDrAddressId(drAddressId), Times.Once);
      }

      /// <summary>
      /// Verifies an invalid request returns an error
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_InvalidRequest_ReturnsError()
      {
         // Arrange
         FileGeneratedModel invalidModel = new FileGeneratedModel() { ReportId = "123" };

         // Act
         string result = await this.packageService.UpdateDocumentPackageFileGeneratedInfo(invalidModel);

         // Assert
         Assert.Equal("Invalid document package update model: 123 -1 -1 -1", result);
      }

      /// <summary>
      /// Verifies a valid request that does not update returns an error
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_ValidRequestNoUpdate_ReturnsError()
      {
         // Arrange
         FileGeneratedModel validModel = new FileGeneratedModel() { ReportId = "1/1/1/1" };
         this.documentPackageRepository.Setup(r => r.UpdateDocumentPackageFileGeneratedInfo(validModel))
            .Returns(Task.FromResult(false))
            .Verifiable();

         // Act
         string result = await this.packageService.UpdateDocumentPackageFileGeneratedInfo(validModel);

         // Assert
         this.documentPackageRepository.Verify();
         Assert.Equal("Did not update document package file generation info.", result);
      }

      /// <summary>
      /// Verifies a valid request that does update the repo returns an empty string
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateDocumentPackageFileGeneratedInfo_ValidRequestWithUpdate_ReturnsEmptyString()
      {
         // Arrange
         FileGeneratedModel validModel = new FileGeneratedModel() { ReportId = "1/1/1/1" };
         this.documentPackageRepository.Setup(r => r.UpdateDocumentPackageFileGeneratedInfo(validModel))
            .Returns(Task.FromResult(true))
            .Verifiable();

         // Act
         string result = await this.packageService.UpdateDocumentPackageFileGeneratedInfo(validModel);

         // Assert
         this.documentPackageRepository.Verify();
         Assert.Empty(result);
      }

      /// <summary>
      /// Verifies that a query returning no status returns null from the repo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStatus_NoStatus_ReturnsNull()
      {
         // Arrange
         this.documentPackageRepository.Setup(d => d.GetDocumentFileStatus(this.jobId, this.docPackId, this.version))
            .Returns(Task.FromResult<DocumentPackageFileStatusModel>(null)).Verifiable();

         // Act
         DocumentPackageFileStatusModel result = await this.packageService.GetDocumentFileStatus(this.jobId, this.docPackId, this.version);

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that string status returned from the query is returned by the repo
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStatus_HasStatus_ReturnsIt()
      {
         // Arrange
         DocumentPackageFileStatusModel status = new DocumentPackageFileStatusModel() { Status = "Complete" };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileStatus(this.jobId, this.docPackId, this.version))
            .Returns(Task.FromResult(status)).Verifiable();

         // Act
         DocumentPackageFileStatusModel result = await this.packageService.GetDocumentFileStatus(this.jobId, this.docPackId, this.version);

         // Assert
         Assert.Equal(status, result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that if we dont have DB data for the doc file we will return null
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_NoDownloadModel_ReturnsNull()
      {
         // Arrange
         DocumentPackageFileDownloadModel downloadModel = null;
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, this.version))
            .Returns(Task.FromResult(downloadModel)).Verifiable();

         // Act
         KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, this.version);

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that if the DB data is empty for the doc file we will return null
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_EmptyDownloadModel_ReturnsNull()
      {
         // Arrange
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel();
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, this.version))
            .Returns(Task.FromResult(downloadModel)).Verifiable();

         // Act
         KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, this.version);

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that if we have DB data but there is no data file in the repo we will return null
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_HasDownloadModelNoStream_ReturnsNull()
      {
         // Arrange
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = "Alehandro" };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, this.version))
            .Returns(Task.FromResult(downloadModel)).Verifiable();
         this.mockS3Repo.Setup(s => s.ListVersionsAsync(this.bucketName, this.someLocation))
            .Returns(Task.FromResult(new ListVersionsResponse() { Versions = new List<S3ObjectVersion>() { new S3ObjectVersion() { LastModified = DateTime.Now, VersionId = this.someFileVersion, Key = this.someLocation } } }));
         this.mockS3Repo.Setup(m => m.GetObjectAsync(this.bucketName, this.someLocation, this.someFileVersion))
            .Returns(Task.FromResult<GetObjectResponse>(null)).Verifiable();

         // Act
         KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, this.version);

         // Assert
         Assert.Null(result);
         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify();
      }

      /// <summary>
      /// Verifies that if we have DB data and a file in the repo we will return a stream of the file and the file name
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_HasDownloadModelAndStream_ReturnsFilenameAndStream()
      {
         // Arrange
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, this.version))
            .Returns(Task.FromResult(downloadModel)).Verifiable();
         this.mockS3Repo.Setup(s => s.ListVersionsAsync(this.bucketName, this.someLocation))
            .Returns(Task.FromResult(new ListVersionsResponse() { Versions = new List<S3ObjectVersion>() { new S3ObjectVersion() { LastModified = DateTime.Now, VersionId = this.someFileVersion, Key = this.someLocation } } }));
         using (Stream someStream = new MemoryStream())
         {
            this.mockS3Repo.Setup(m => m.GetObjectAsync(this.bucketName, this.someLocation, this.someFileVersion))
               .Returns(Task.FromResult(new GetObjectResponse() { ResponseStream = someStream })).Verifiable();

            // Act
            KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, this.version);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(downloadModel.GetNameWithExtension(), result.Value.Key);
            Assert.Equal(someStream, result.Value.Value);
         }

         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify();
      }

      /// <summary>
      /// Verifies that if there is not version data in S3 that we just return null.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_NoVersions_ReturnsNull()
      {
         // Arrange
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, this.version))
            .Returns(Task.FromResult(downloadModel)).Verifiable();

         this.mockS3Repo.Setup(m => m.ListVersionsAsync(this.bucketName, this.someLocation))
            .Returns(Task.FromResult<ListVersionsResponse>(null)).Verifiable();

         // Act
         KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, this.version);

         // Assert
         Assert.Null(result);

         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify();
      }

      /// <summary>
      /// Verifies that if our oracle version data is higher than s3 versions, we just return null
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_InvalidVersions_ReturnsNull()
      {
         // Arrange
         int aVersionHigherThanOurS3FileCount = 2;
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, aVersionHigherThanOurS3FileCount))
            .Returns(Task.FromResult(downloadModel)).Verifiable();

         this.mockS3Repo.Setup(m => m.ListVersionsAsync(this.bucketName, this.someLocation))
            .Returns(Task.FromResult(new ListVersionsResponse() { Versions = new List<S3ObjectVersion>() { new S3ObjectVersion() } }))
            .Verifiable();

         // Act
         KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, aVersionHigherThanOurS3FileCount);

         // Assert
         Assert.Null(result);

         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify();
      }

      /// <summary>
      /// Verifies that if the doc package does not exist we don't try to update the filestore version.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateFilestoreVersionId_DocPkgDoesNotExist_RreturnsNull()
      {
         // Arrange.
         this.documentPackageRepository.Setup(d => d.GetDocPkgDetails(It.IsAny<int>())).Returns(Task.FromResult<DocPkgDetailsModel>(null)).Verifiable();

         // Act.
         DocumentPackageFilestoreViewModel result = await this.packageService.UpdateFilestoreVersionId(123, "blah");

         // Assert.
         Assert.Null(result);
         this.documentPackageRepository.Verify();
         this.documentPackageRepository.Verify(
            d => d.UpdateDocumentPackageFileGeneratedInfo(
            It.IsAny<int>(),
            It.IsAny<int>(),
            It.IsAny<int>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<GeneratedInfoModel>()), Times.Never);
      }

      /// <summary>
      /// Verifies that the file history is not added and still points to the old filestore version.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateFilestoreVersionId_FailsCloningDocPackage_ReturnsNull()
      {
         // Arrange.
         string newFilestoreVersion = "newblah";
         string oldFilestoreVersionId = "oldblah";
         DocPkgDetailsModel docPackageDetails = new DocPkgDetailsModel()
         {
            JOB_ID = 111,
            DOC_PKG_ID = 123,
            DR_ADDRESS_ID = 122,
            DOC_PKG_FILE_ID = 999,
            DOC_TYPE_ID = 6,
            GENERATED_INFO = JsonConvert.SerializeObject(new GeneratedInfoModel() { VersionId = oldFilestoreVersionId }),
            FILE_LOCATION = "my house",
            FILE_VERSION = 1,
         };
         var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
         this.documentPackageRepository.Setup(d => d.GetDocPkgDetails(It.IsAny<int>())).Returns(Task.FromResult<DocPkgDetailsModel>(docPackageDetails)).Verifiable();
         this.documentPackageRepository.Setup(d => d.GetDocumentPackFileCount(It.IsAny<DocumentPackageFileModel>())).Returns(Task.FromResult<int>(2)).Verifiable();
         this.documentPackageRepository.Setup(d => d.UpsertDocumentPackage(It.IsAny<DocumentPackageModel>(), It.IsAny<DocumentPackageFileModel>(), true)).Returns(Task.FromResult<bool>(false));

         // Act.
         DocumentPackageFilestoreViewModel result = await this.packageService.UpdateFilestoreVersionId(docPackageDetails.DOC_PKG_ID, newFilestoreVersion);

         // Assert.
         Assert.Null(result);
         this.documentPackageRepository.Verify();
         this.documentPackageRepository.Verify(
            d => d.UpdateDocumentPackageFileGeneratedInfo(
            It.IsAny<int>(),
            It.IsAny<int>(),
            It.IsAny<int>(),
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<GeneratedInfoModel>()), Times.Never);
      }

      /// <summary>
      /// Verifies that the file history is added but the filestore version update fails and still points to the old filestore version.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateFilestoreVersionId_ClonesExistingDocPkgAndFailsUpdates_ReturnsNull()
      {
         // Arrange.
         string newFilestoreVersion = "newblah";
         string oldFilestoreVersionId = "oldblah";
         DocPkgDetailsModel docPackageDetails = new DocPkgDetailsModel()
         {
            JOB_ID = 111,
            DOC_PKG_ID = 123,
            DR_ADDRESS_ID = 122,
            DOC_PKG_FILE_ID = 999,
            DOC_TYPE_ID = 5,
            GENERATED_INFO = JsonConvert.SerializeObject(new GeneratedInfoModel() { VersionId = oldFilestoreVersionId }),
            FILE_LOCATION = "my house",
            FILE_VERSION = 1,
         };
         var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
         this.documentPackageRepository.Setup(d => d.GetDocPkgDetails(It.IsAny<int>())).Returns(Task.FromResult<DocPkgDetailsModel>(docPackageDetails)).Verifiable();
         this.documentPackageRepository.Setup(d => d.GetDocumentPackFileCount(It.IsAny<DocumentPackageFileModel>())).Returns(Task.FromResult<int>(2)).Verifiable();
         this.documentPackageRepository.Setup(d => d.UpsertDocumentPackage(It.IsAny<DocumentPackageModel>(), It.IsAny<DocumentPackageFileModel>(), true)).Returns(Task.FromResult<bool>(true));
         this.documentPackageRepository.Setup(d => d.UpdateDocumentPackageFileGeneratedInfo(
               docPackageDetails.JOB_ID,
               docPackageDetails.DOC_PKG_ID,
               docPackageDetails.FILE_VERSION + 1,
               docPackageDetails.FILE_LOCATION,
               GeneratedStatusOptions.Complete,
               It.IsAny<GeneratedInfoModel>()))
            .Returns(Task.FromResult<bool>(false)).Verifiable();

         // Act.
         DocumentPackageFilestoreViewModel result = await this.packageService.UpdateFilestoreVersionId(docPackageDetails.DOC_PKG_ID, newFilestoreVersion);

         // Assert.
         Assert.Null(result);
         this.documentPackageRepository.Verify();
         this.documentPackageRepository.Verify(d => d.GetProposalSequence(It.IsAny<int>()), Times.Never);
      }

      /// <summary>
      /// Verifies that if the doc package exists and updates the filestore version id.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task UpdateFilestoreVersionId_ClonesExistingDocPkgAndUpdates_ReturnsNewFileDetails()
      {
         // Arrange.
         string newFilestoreVersion = "newblah";
         string oldFilestoreVersionId = "oldblah";
         DocPkgDetailsModel docPackageDetails = new DocPkgDetailsModel()
         {
            JOB_ID = 111,
            DOC_PKG_ID = 123,
            DR_ADDRESS_ID = 122,
            DOC_PKG_FILE_ID = 999,
            DOC_TYPE_ID = 5,
            GENERATED_INFO = JsonConvert.SerializeObject(new GeneratedInfoModel() { VersionId = oldFilestoreVersionId }),
            FILE_LOCATION = "my house",
            FILE_VERSION = 1,
            PROPOSAL_NBR = "1234abc"
         };
         var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);
         this.documentPackageRepository.Setup(d => d.GetDocPkgDetails(It.IsAny<int>())).Returns(Task.FromResult<DocPkgDetailsModel>(docPackageDetails)).Verifiable();
         this.documentPackageRepository.Setup(d => d.GetDocumentPackFileCount(It.IsAny<DocumentPackageFileModel>())).Returns(Task.FromResult<int>(2)).Verifiable();
         this.documentPackageRepository.Setup(d => d.UpsertDocumentPackage(It.IsAny<DocumentPackageModel>(), It.IsAny<DocumentPackageFileModel>(), true)).Returns(Task.FromResult<bool>(true));
         this.documentPackageRepository.Setup(d => d.UpdateDocumentPackageFileGeneratedInfo(
               docPackageDetails.JOB_ID,
               docPackageDetails.DOC_PKG_ID,
               docPackageDetails.FILE_VERSION + 1,
               docPackageDetails.FILE_LOCATION,
               GeneratedStatusOptions.Complete,
               It.IsAny<GeneratedInfoModel>()))
            .Returns(Task.FromResult<bool>(true)).Verifiable();

         // Act.
         DocumentPackageFilestoreViewModel result = await this.packageService.UpdateFilestoreVersionId(docPackageDetails.DOC_PKG_ID, newFilestoreVersion);

         // Assert.
         Assert.NotNull(result);
         Assert.Equal(docPackageDetails.FILE_VERSION + 1, result.FileVersion);
         Assert.Equal(newFilestoreVersion, result.FilestoreVersionId);
         this.documentPackageRepository.Verify();
         this.documentPackageRepository.Verify(d => d.GetProposalSequence(It.IsAny<int>()), Times.Never);
      }

      /// <summary>
      /// Verifies that S3 version data is sorted by date and that we retrieve the version corresponding to the
      /// oracle version (as a 1 based index) applied to the sorted dates.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_MultipleVersions_ReturnsVersionBasedOnDateAndIndex()
      {
         // Arrange
         S3ObjectVersion middleVersion = new S3ObjectVersion() { VersionId = "middleVersion", LastModified = DateTime.Today.AddDays(-2), Key = this.someLocation };
         S3ObjectVersion earliestVersion = new S3ObjectVersion() { VersionId = "earliestVersion", LastModified = DateTime.Today.AddDays(-4), Key = this.someLocation };
         S3ObjectVersion latestVersion = new S3ObjectVersion() { VersionId = "latestVersion", LastModified = DateTime.Today, Key = this.someLocation };
         DocumentPackageFileDownloadModel downloadModel1 = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName, VersionId = 1 };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, 1))
            .Returns(Task.FromResult(downloadModel1)).Verifiable();
         DocumentPackageFileDownloadModel downloadModel2 = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName, VersionId = 2 };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, 2))
            .Returns(Task.FromResult(downloadModel2)).Verifiable();
         DocumentPackageFileDownloadModel downloadModel3 = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName, VersionId = 3 };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, 3))
            .Returns(Task.FromResult(downloadModel3)).Verifiable();

         using (Stream someStream = new MemoryStream())
         {
            this.mockS3Repo.Setup(m => m.ListVersionsAsync(this.bucketName, this.someLocation))
               .Returns(Task.FromResult(
                  new ListVersionsResponse()
                  { Versions = new List<S3ObjectVersion>() { middleVersion, earliestVersion, latestVersion } })).Verifiable();
            this.mockS3Repo.Setup(m => m.GetObjectAsync(this.bucketName, It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(new GetObjectResponse() { ResponseStream = someStream }));

            // Act/Assert 1:  make sure our first version fetches a file using the oldest S3 version
            KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, 1);
            this.mockS3Repo.Verify(m => m.GetObjectAsync(this.bucketName, this.someLocation, earliestVersion.VersionId), Times.Once);
            Assert.NotNull(result);
            Assert.Equal(someStream, result.Value.Value);

            // Act/Assert 2:  make sure our middle version fetches a file using the middle S3 version
            result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, 2);
            this.mockS3Repo.Verify(m => m.GetObjectAsync(this.bucketName, this.someLocation, middleVersion.VersionId), Times.Once);
            Assert.NotNull(result);
            Assert.Equal(someStream, result.Value.Value);

            // Act/Assert 3:  make sure our latest version fetches a file using the newest S3 version
            result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, 3);
            this.mockS3Repo.Verify(m => m.GetObjectAsync(this.bucketName, this.someLocation, latestVersion.VersionId), Times.Once);
            Assert.NotNull(result);
            Assert.Equal(someStream, result.Value.Value);
         }

         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify();
         this.documentPackageRepository.Verify(d => d.GetMostRecentDocumentFileDownloadInfo(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
      }

      /// <summary>
      /// Verifies that S3 version data is sorted by date and that we retrieve the version corresponding to the most recent
      /// oracle version (as a 1 based index) applied to the sorted dates.
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_MultipleVersions_ReturnsMostRecentDocBasedOnDateAndIndex()
      {
         // Arrange
         S3ObjectVersion middleVersion = new S3ObjectVersion() { VersionId = "middleVersion", LastModified = DateTime.Today.AddDays(-2), Key = this.someLocation };
         S3ObjectVersion earliestVersion = new S3ObjectVersion() { VersionId = "earliestVersion", LastModified = DateTime.Today.AddDays(-4), Key = this.someLocation };
         S3ObjectVersion latestVersion = new S3ObjectVersion() { VersionId = "latestVersion", LastModified = DateTime.Today, Key = this.someLocation };
         DocumentPackageFileDownloadModel downloadModel1 = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName, VersionId = 3 };
         this.documentPackageRepository.Setup(d => d.GetMostRecentDocumentFileDownloadInfo(this.jobId, this.docPackId))
            .Returns(Task.FromResult(downloadModel1)).Verifiable();

         using (Stream someStream = new MemoryStream())
         {
            this.mockS3Repo.Setup(m => m.ListVersionsAsync(this.bucketName, this.someLocation))
               .Returns(Task.FromResult(
                  new ListVersionsResponse()
                  { Versions = new List<S3ObjectVersion>() { middleVersion, earliestVersion, latestVersion } })).Verifiable();
            this.mockS3Repo.Setup(m => m.GetObjectAsync(this.bucketName, It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(new GetObjectResponse() { ResponseStream = someStream }));

            // Act/Assert 1:  make sure our first version fetches a file using the oldest S3 version
            KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, null);
            this.mockS3Repo.Verify(m => m.GetObjectAsync(this.bucketName, this.someLocation, latestVersion.VersionId), Times.Once);
            Assert.NotNull(result);
            Assert.Equal(someStream, result.Value.Value);
         }

         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify();
         this.documentPackageRepository.Verify(d => d.GetDocumentFileDownloadInfo(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.Never);
      }

      /// <summary>
      /// Verifies that versions that dont match our key are ignored.  (ListVersionsAsync takes a prefix, not a key)
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_InputFileVersions_AreIgnored()
      {
         // Arrange
         S3ObjectVersion ourFile = new S3ObjectVersion() { VersionId = "ourFile", LastModified = DateTime.Today, Key = this.someLocation };
         S3ObjectVersion inputFile = new S3ObjectVersion() { VersionId = "inputFile", LastModified = DateTime.Today.AddMinutes(-2), Key = this.someLocation + "input" };
         DocumentPackageFileDownloadModel downloadModel1 = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName, VersionId = 1 };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, 1))
            .Returns(Task.FromResult(downloadModel1)).Verifiable();
         DocumentPackageFileDownloadModel downloadModel2 = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName, VersionId = 2 };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, 2))
            .Returns(Task.FromResult(downloadModel2)).Verifiable();

         using (Stream someStream = new MemoryStream())
         {
            this.mockS3Repo.Setup(m => m.ListVersionsAsync(this.bucketName, this.someLocation))
               .Returns(Task.FromResult(
                  new ListVersionsResponse()
                  { Versions = new List<S3ObjectVersion>() { inputFile, ourFile } })).Verifiable();
            this.mockS3Repo.Setup(m => m.GetObjectAsync(this.bucketName, this.someLocation, ourFile.VersionId))
               .Returns(Task.FromResult(new GetObjectResponse() { ResponseStream = someStream }));

            // Act/Assert 1:  make sure we get ourFile for version 1.
            KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, 1);
            this.mockS3Repo.Verify(m => m.GetObjectAsync(this.bucketName, this.someLocation, ourFile.VersionId), Times.Once);
            Assert.Equal(someStream, result.Value.Value);

            // Act/Assert 2:  make sure we dont get a hit on version 2.  (there is only one version of our file)
            result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, 2);
            this.mockS3Repo.Verify(m => m.GetObjectAsync(this.bucketName, this.someLocation, inputFile.VersionId), Times.Never);
            Assert.Null(result);
         }

         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify();
         this.documentPackageRepository.Verify(d => d.GetMostRecentDocumentFileDownloadInfo(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
      }

      /// <summary>
      /// Verifies that we dont try looking up the S3 version with the additional call to S3 if we dont need to
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentFileStream_HasDocPackageFileVersion_DoesntLookUpS3Version()
      {
         // Arrange
         S3ObjectVersion ourFile = new S3ObjectVersion() { VersionId = "ourFile", LastModified = DateTime.Today, Key = this.someLocation };
         DocumentPackageFileDownloadModel downloadModel = new DocumentPackageFileDownloadModel() { Location = this.someLocation, Name = this.someFileName, GeneratedInfo = "{\"ErrorDescription\":null,\"VersionId\":\"2QI.yoJi6wtwdIFtH5BVRLHdAQWywz9j\"}" };
         this.documentPackageRepository.Setup(d => d.GetDocumentFileDownloadInfo(this.jobId, this.docPackId, It.IsAny<int>()))
            .Returns(Task.FromResult(downloadModel)).Verifiable();

         // Act/Assert 1:  make sure we get ourFile for version 1.
         KeyValuePair<string, Stream>? result = await this.packageService.GetDocumentFileStream(this.jobId, this.docPackId, 1);

         this.documentPackageRepository.Verify();
         this.mockS3Repo.Verify(m => m.ListVersionsAsync(this.bucketName, this.someLocation), Times.Never);
      }

      /// <summary>
      /// Verifies that if there are records returned from the repo they are mapped and returned correctly
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentPackageFileHistories_HasRecord_ReturnsIt()
      {
         // Arrange
         DocumentPackageFileHistoryModel historyModel = new DocumentPackageFileHistoryModel()
         {
            FILE_NAME = "someFileName",
            FILE_VERSION = 1,
            GENERATED_BY_USER = "me",
            LAST_MODIFIED_DATE = DateTime.Now.AddDays(-1),
            LAST_MODIFIED_USER = "you",
            GENERATED_DATE = DateTime.Now,
            GENERATED_INFO = null,
            STATUS = "done"
         };
         this.documentPackageRepository.Setup(r => r.GetDocumentPackageFileHistories(this.jobId, this.docPackId)).Returns(Task.FromResult(new DocumentPackageFileHistoryModel[] { historyModel }.AsEnumerable()));

         // Act
         IEnumerable<DocumentPackageFileHistoryViewModel> result = await this.packageService.GetDocumentPackageFileHistories(this.jobId, this.docPackId);

         // Assert
         DocumentPackageFileHistoryViewModel firstResult = result.First();
         Assert.Equal(historyModel.FILE_NAME, firstResult.FileName);
         Assert.Equal(historyModel.FILE_VERSION, firstResult.FileVersion);
         Assert.Equal(historyModel.GENERATED_BY_USER, firstResult.GeneratedByUser);
         Assert.Equal(historyModel.LAST_MODIFIED_DATE, firstResult.ModifiedDate);
         Assert.Equal(historyModel.LAST_MODIFIED_USER, firstResult.LastModifiedByUser);
         Assert.Equal(historyModel.GENERATED_DATE, firstResult.GeneratedDate);
         Assert.Equal(historyModel.GENERATED_INFO, firstResult.Error);
         Assert.Equal(historyModel.STATUS, firstResult.Status);
      }

      /// <summary>
      /// Verifies that if there are no records returned from the repo an empty enumerable is returned
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetDocumentPackageFileHistories_NoRecords_ReturnsEmpty()
      {
         // Arrange
         this.documentPackageRepository.Setup(r => r.GetDocumentPackageFileHistories(this.jobId, this.docPackId))
            .Returns(Task.FromResult(Enumerable.Empty<DocumentPackageFileHistoryModel>()))
            .Verifiable();

         // Act
         IEnumerable<DocumentPackageFileHistoryViewModel> result = await this.packageService.GetDocumentPackageFileHistories(this.jobId, this.docPackId);

         // Assert
         Assert.Empty(result);
      }

      /// <summary>
      /// Verifies that if there are records returned from the repo they are mapped and returned correctly
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetMostRecentlyGeneratedDocumentPackageFileHistory_HasRecord_ReturnsIt()
      {
         // Arrange
         List<DocumentPackageFileHistoryModel> historyModels = new List<DocumentPackageFileHistoryModel>()
         {
            new DocumentPackageFileHistoryModel()
            {
               FILE_NAME = "rick job_proposal_big bid",
               FILE_VERSION = 1,
               GENERATED_BY_USER = "me",
               GENERATED_DATE = new DateTime(2000, 1, 1),
               GENERATED_INFO = null,
               STATUS = "complete"
            },
            new DocumentPackageFileHistoryModel()
            {
               FILE_NAME = "rick job_proposal_big bid_1",
               FILE_VERSION = 2,
               GENERATED_BY_USER = "me",
               GENERATED_DATE = new DateTime(2001, 1, 1),
               GENERATED_INFO = null,
               STATUS = "complete"
            },
            new DocumentPackageFileHistoryModel()
            {
               FILE_NAME = "fancy uploaded file",
               FILE_VERSION = 3,
               GENERATED_BY_USER = "me",
               GENERATED_DATE = new DateTime(2002, 1, 1),
               GENERATED_INFO = null,
               STATUS = "uploaded"
            },
            new DocumentPackageFileHistoryModel()
            {
               FILE_NAME = "fancy uploaded file 2",
               FILE_VERSION = 4,
               GENERATED_BY_USER = "me",
               GENERATED_DATE = new DateTime(2003, 1, 1),
               GENERATED_INFO = null,
               STATUS = "uploaded"
            },
            new DocumentPackageFileHistoryModel()
            {
               FILE_NAME = "rick job_proposal_big bid_2",
               FILE_VERSION = 5,
               GENERATED_BY_USER = "me",
               GENERATED_DATE = new DateTime(2004, 1, 1),
               GENERATED_INFO = null,
               STATUS = "complete"
            },
            new DocumentPackageFileHistoryModel()
            {
               FILE_NAME = "fancy uploaded file 3",
               FILE_VERSION = 6,
               GENERATED_BY_USER = "me",
               GENERATED_DATE = new DateTime(2005, 1, 1),
               GENERATED_INFO = null,
               STATUS = "uploaded"
            },
         };
         this.documentPackageRepository.Setup(r => r.GetDocumentPackageFileHistories(this.jobId, this.docPackId)).Returns(Task.FromResult(historyModels.AsEnumerable()));

         // Act
         DocumentPackageMostRecentFileHistoryViewModel result = await this.packageService.GetMostRecentlyGeneratedDocumentPackageFileHistory(this.jobId, this.docPackId);

         // Assert
         Assert.Equal(historyModels[4].FILE_NAME, result.FileName);
         Assert.Equal(historyModels[4].FILE_VERSION, result.FileVersion);
         Assert.Equal(3, result.TotalGeneratedVersions);
      }

      /// <summary>
      /// Verifies that if there are no records returned from the repo a null is returned
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetMostRecentlyGeneratedDocumentPackageFileHistory_NoRecords_ReturnsNull()
      {
         // Arrange
         this.documentPackageRepository.Setup(r => r.GetDocumentPackageFileHistories(this.jobId, this.docPackId))
            .Returns(Task.FromResult(Enumerable.Empty<DocumentPackageFileHistoryModel>()))
            .Verifiable();

         // Act
         DocumentPackageMostRecentFileHistoryViewModel result = await this.packageService.GetMostRecentlyGeneratedDocumentPackageFileHistory(this.jobId, this.docPackId);

         // Assert
         Assert.Null(result);
      }

      /// <summary>
      ///  If document folder alreay exist new job document folder will not be created
      /// </summary>
      [Fact]
      public void CheckAndCreateJobFolder_WhenFolderAlreadyExists_DoesNotCreateNewFolder()
      {
         // Arrange
         bool folderExists = true;

         this.documentFolderRepository.Setup(x => x.DoesFolderExist(validProposalRequest.Package.DocumentTypeId, validProposalRequest.Package.JobId))
        .Returns(Task.FromResult(folderExists)).Verifiable();

         this.documentPackageRepository.Setup(x => x.GetSequenceNumberAsync(It.IsAny<string>()))
          .Returns(Task.FromResult(1));

         this.documentFolderRepository.Setup(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()))
        .Returns(Task.FromResult(folderExists)).Verifiable();

         // Act
         this.packageService.CheckAndCreateJobFolder(validProposalRequest);

         // Assert
         this.documentFolderRepository.Verify(x => x.DoesFolderExist(validProposalRequest.Package.DocumentTypeId, validProposalRequest.Package.JobId), Times.Once);
         this.documentPackageRepository.Verify(x => x.GetSequenceNumberAsync(It.IsAny<string>()), Times.Never);
         this.documentFolderRepository.Verify(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()), Times.Never);
      }

      /// <summary>
      /// If document folder does not exist new job document folder will be created
      /// </summary>
      [Fact]
      public void CheckAndCreateJobFolder_WhenFolderDoesNotExists_CreatesNewFolder()
      {
         // Arrange
         bool folderExists = false;
         var claims = new List<Claim>()
            {
                new Claim("samAccountName", "dummy user")
            };
         this.contextAccessor.Setup(x => x.HttpContext.User.Claims).Returns(claims);

         this.documentFolderRepository.Setup(x => x.DoesFolderExist(validProposalRequest.Package.DocumentTypeId, validProposalRequest.Package.JobId))
        .Returns(Task.FromResult(folderExists)).Verifiable();

         this.documentPackageRepository.Setup(x => x.GetSequenceNumberAsync(It.IsAny<string>()))
         .Returns(Task.FromResult(1));

         this.documentFolderRepository.Setup(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()))
        .Returns(Task.FromResult(true)).Verifiable();

         // Act
         this.packageService.CheckAndCreateJobFolder(validProposalRequest);

         // Assert
         this.documentFolderRepository.Verify(x => x.DoesFolderExist(validProposalRequest.Package.DocumentTypeId, validProposalRequest.Package.JobId), Times.Once);
         this.documentPackageRepository.Verify(x => x.GetSequenceNumberAsync(It.IsAny<string>()), Times.Once);
         this.documentFolderRepository.Verify(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderModel>()), Times.Once);
      }

      /// <summary>
      /// Verifies that if there are records returned from the repo they are mapped and returned correctly
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetPackageDocument_HasRecord_ReturnsIt()
      {
         // Arrange
         DocumentPackageFileModel documentPackageFileModel = new DocumentPackageFileModel()
         {
            FILE_NAME = "someFileName",
            GENERATED_BY_USER = "user",
            GENERATED_DATE = DateTime.Now,
            LAST_MODIFIED_DATE = DateTime.Now,
            LAST_MODIFIED_USER = "rick"
         };
         this.documentPackageRepository.Setup(r => r.GetPackageDocument(this.jobId, this.docTypeId)).Returns(Task.FromResult(new DocumentPackageFileModel[] { documentPackageFileModel }.AsEnumerable()));

         // Act
         IEnumerable<DocumentPackageFileViewModel> result = await this.packageService.GetPackageDocument(this.jobId, this.docTypeId);

         // Assert
         DocumentPackageFileViewModel firstResult = result.First();
         Assert.Equal(documentPackageFileModel.FILE_NAME, firstResult.FileName);
         Assert.Equal(documentPackageFileModel.GENERATED_BY_USER, firstResult.GeneratedBy);
         Assert.Equal(documentPackageFileModel.GENERATED_DATE, firstResult.GeneratedDate);
         Assert.Equal(documentPackageFileModel.LAST_MODIFIED_DATE, firstResult.UpdatedOn);
         Assert.Equal(documentPackageFileModel.LAST_MODIFIED_USER, firstResult.UpdatedBy);
         this.documentPackageRepository.Verify();
      }

      /// <summary>
      /// Verifies that if there are not records returned from the repo an empty enumerable is returned
      /// </summary>
      /// <returns>Task representing completion</returns>
      [Fact]
      public async Task GetPackageDocument_NoRecords_ReturnsEmpty()
      {
         // Arrange
         this.documentPackageRepository.Setup(r => r.GetPackageDocument(this.jobId, this.docTypeId))
            .Returns(Task.FromResult(Enumerable.Empty<DocumentPackageFileModel>()))
            .Verifiable();

         // Act
         IEnumerable<DocumentPackageFileViewModel> result = await this.packageService.GetPackageDocument(this.jobId, this.docTypeId);

         // Assert
         Assert.Empty(result);
         this.documentPackageRepository.Verify();
      }
   }
}
