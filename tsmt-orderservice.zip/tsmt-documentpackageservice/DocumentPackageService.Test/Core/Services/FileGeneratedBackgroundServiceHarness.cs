﻿// <copyright file="FileGeneratedBackgroundServiceHarness.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Services
{
   using System.Threading;
   using System.Threading.Tasks;
   using AWS.MessagingWrapper.Contracts;
   using DocumentPackageService.Core.Services;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using TSMT.Settings;

   /// <summary>
   /// Test harness class for FileGeneratedBackgroundService to allow us to call ExecuteAsync
   /// </summary>
   public class FileGeneratedBackgroundServiceHarness : FileGeneratedBackgroundService
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="FileGeneratedBackgroundServiceHarness"/> class.
      /// </summary>
      /// <param name="logger">logger</param>
      /// <param name="messageReceiver">messageReceiver</param>
      /// <param name="appSettings">appSettings</param>
      /// <param name="docPackageService">docPackageService</param>
      public FileGeneratedBackgroundServiceHarness(ILogger<FileGeneratedBackgroundService> logger, IMessageReceiver messageReceiver, IOptions<TSMTSettings> appSettings, IDocumentPackageService docPackageService)
        : base(logger, messageReceiver, appSettings, docPackageService)
      {
      }

      /// <summary>
      /// Test method for calling ExecuteAsync
      /// </summary>
      /// <param name="stoppingToken">stoppingToken</param>
      /// <returns>Task representing completion</returns>
      public Task ExecuteAsyncHarness(CancellationToken stoppingToken)
      {
         return this.ExecuteAsync(stoppingToken);
      }
   }
}
