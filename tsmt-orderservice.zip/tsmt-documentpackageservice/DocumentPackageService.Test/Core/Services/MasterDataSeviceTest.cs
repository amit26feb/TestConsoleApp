﻿// <copyright file="MasterDataSeviceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using DocumentPackageService.Configurations.AutoMapperConfiguration;
    using DocumentPackageService.Core.Models;
    using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
    using Moq;
    using TSMT.DataAccess;
    using Xunit;

   /// <summary>
   /// MasterDataSeviceTest
   /// </summary>
   public class MasterDataSeviceTest
   {
      private readonly Mock<IRepository<DocumentGroupModel>> repository;
      private readonly Mock<IMasterDataRepository> masterRepository;
      private readonly IMapper mapper;

      /// <summary>
      /// Initializes a new instance of the <see cref="MasterDataSeviceTest"/> class.
      /// </summary>
      public MasterDataSeviceTest()
      {
         this.repository = new Mock<IRepository<DocumentGroupModel>>();
         this.masterRepository = new Mock<IMasterDataRepository>();
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });
         this.mapper = config.CreateMapper();
      }

      /// <summary>
      ///  GetBusinessStreams returns empty list
      /// </summary>
      /// <returns>Empty List</returns>
      [Fact]
      public async Task GetBusinessStreams_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         IEnumerable<BusinessStreamViewModel> businessStreams = new List<BusinessStreamViewModel>();

         this.masterRepository.Setup(x => x.GetBusinessStreams())
         .Returns(Task.FromResult(businessStreams)).Verifiable();

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetBusinessStreams();

         // Assert
         Assert.Empty(result);
         this.masterRepository.Verify(x => x.GetBusinessStreams(), Times.Once);
      }

      /// <summary>
      ///  GetBusinessStreams returns BusinessStreamViewModel list
      /// </summary>
      /// <returns>BusinessStreamViewModel list</returns>
      [Fact]
      public async Task GetBusinessStreams_HasValue_ReturnsValidData()
      {
         // Arrange
         IEnumerable<BusinessStreamViewModel> businessStreams = new List<BusinessStreamViewModel>()
         {
            new BusinessStreamViewModel()
                    {
                        BusinessStreamId = 1,
                        BusinessStreamName = "stream 1",
                        Status = "C",
                        BusinessStreamAbstract = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new BusinessStreamViewModel()
                    {
                       BusinessStreamId = 2,
                       BusinessStreamName = "stream 2"
                    }
                };

         this.masterRepository.Setup(x => x.GetBusinessStreams())
        .Returns(Task.FromResult(businessStreams)).Verifiable();

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetBusinessStreams();

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Count() == 2);
         Assert.True(result.Select(a => a.BusinessStreamId == 1).Any());
         Assert.True(result.Select(a => a.BusinessStreamName == "stream 1").Any());
         this.masterRepository.Verify(x => x.GetBusinessStreams(), Times.Once);
      }

      /// <summary>
      ///  GetDocumentTypes returns empty list
      /// </summary>
      /// <returns>Empty result</returns>
      [Fact]
      public async Task GetDocumentTypes_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         int docGroupId = 1;
         IEnumerable<DocumentTypeViewModel> documentTypes = new List<DocumentTypeViewModel>();

         this.masterRepository.Setup(x => x.GetDocumentTypes(docGroupId))
         .Returns(Task.FromResult(documentTypes));

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetDocumentTypes(docGroupId);

         // Assert
         Assert.Empty(result);
         this.masterRepository.Verify(x => x.GetDocumentTypes(docGroupId), Times.Once);
      }

      /// <summary>
      ///  GetDocumentTypes returns DocumentTypeViewModel list
      /// </summary>
      /// <returns>DocumentTypeViewModel list</returns>
      [Fact]
      public async Task GetDocumentTypes_HasValue_ReturnsValidData()
      {
         // Arrange
         int docGroupId = 1;
         IEnumerable<DocumentTypeViewModel> documentTypes = new List<DocumentTypeViewModel>()
         {
            new DocumentTypeViewModel()
                    {
                        DocumentTypeId = 1,
                        DocumentTypeName = "Equipment Proposal",
                        DocumentGroupId = 1,
                        Status = "C",
                        DocumentTypeAbstract = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new DocumentTypeViewModel()
                    {
                       DocumentTypeId = 2,
                       DocumentTypeName = "Guide Spec"
                    }
                };

         this.masterRepository.Setup(x => x.GetDocumentTypes(docGroupId))
        .Returns(Task.FromResult(documentTypes)).Verifiable();

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetDocumentTypes(docGroupId);

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Count() == 2);
         Assert.True(result.Select(a => a.DocumentTypeId == 1).Any());
         Assert.True(result.Select(a => a.DocumentTypeName == "Equipment Proposal").Any());
         this.masterRepository.Verify(x => x.GetDocumentTypes(docGroupId), Times.Once);
      }

      /// <summary>
      ///  GetLegalEntities invalid input returns empty list
      /// </summary>
      /// <returns>Empty result</returns>
      [Fact]
      public async Task GetLegalEntities_InvalidInput_ReturnsEmptyList()
      {
         // Arrange
         int docTypeId = 0;
         IEnumerable<LegalEntityViewModel> legalEntities = new List<LegalEntityViewModel>();

         this.masterRepository.Setup(x => x.GetLegalEntities(docTypeId))
         .Returns(Task.FromResult(legalEntities));

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetLegalEntities(docTypeId);

         // Assert
         Assert.Empty(result);
         this.masterRepository.Verify(x => x.GetLegalEntities(docTypeId), Times.Once);
      }

      /// <summary>
      ///  GetLegalEntities returns empty list
      /// </summary>
      /// <returns>Empty result</returns>
      [Fact]
      public async Task GetLegalEntities_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         int docTypeId = 5;
         IEnumerable<LegalEntityViewModel> legalEntities = new List<LegalEntityViewModel>();

         this.masterRepository.Setup(x => x.GetLegalEntities(docTypeId))
         .Returns(Task.FromResult(legalEntities));

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetLegalEntities(docTypeId);

         // Assert
         Assert.Empty(result);
         this.masterRepository.Verify(x => x.GetLegalEntities(docTypeId), Times.Once);
      }

      /// <summary>
      ///  GetLegalEntities returns LegalEntities list
      /// </summary>
      /// <returns>LegalEntityViewModel list</returns>
      [Fact]
      public async Task GetLegalEntities_HasValue_ReturnsValidData()
      {
         // Arrange
         int docTypeId = 5;
         IEnumerable<LegalEntityViewModel> legalEntities = new List<LegalEntityViewModel>()
         {
            new LegalEntityViewModel()
                    {
                        LegalEntityId = 1,
                        LegalEntityName = "Entity",
                        ShortName = "Entity",
                        EntityAbstract = "Entity",
                    },
                    new LegalEntityViewModel()
                    {
                       LegalEntityId = 2,
                       LegalEntityName = "Ent",
                       ShortName = "Ent",
                       EntityAbstract = "Ent",
                    }
                };

         this.masterRepository.Setup(x => x.GetLegalEntities(docTypeId))
        .Returns(Task.FromResult(legalEntities));

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetLegalEntities(docTypeId);

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Count() == 2);
         Assert.True(result.Select(a => a.LegalEntityId == 1).Any());
         Assert.True(result.Select(a => a.LegalEntityName == "Entity").Any());
         this.masterRepository.Verify(x => x.GetLegalEntities(docTypeId), Times.Once);
      }

      /// <summary>
      ///  GetTermsAndConditions returns empty list
      /// </summary>
      /// <returns>Empty result</returns>
      [Fact]
      public async Task GetTermsAndConditions_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         IEnumerable<TermsAndConditionsViewModel> termsAndConditions = new List<TermsAndConditionsViewModel>();
         int docTypeId = 5;
         this.masterRepository.Setup(x => x.GetTermsAndConditions(It.IsAny<int>()))
         .Returns(Task.FromResult(termsAndConditions));

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetTermsAndConditions(docTypeId);

         // Assert
         Assert.Empty(result);
         this.masterRepository.Verify(x => x.GetTermsAndConditions(It.IsAny<int>()), Times.Once);
      }

      /// <summary>
      ///  GetTermsAndConditions returns TermsAndConditions list
      /// </summary>
      /// <returns>TermsAndConditions list</returns>
      [Fact]
      public async Task GetTermsAndConditions_HasValue_ReturnsValidData()
      {
         // Arrange
         int docTypeId = 5;
         IEnumerable<TermsAndConditionsViewModel> termsAndConditions = new List<TermsAndConditionsViewModel>()
         {
            new TermsAndConditionsViewModel()
                    {
                        TermsAndConditionsId = 1,
                        TermsAndConditionsName = "term1",
                        SequenceNumber = 1,
                        Description = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new TermsAndConditionsViewModel()
                    {
                       TermsAndConditionsId = 2,
                       TermsAndConditionsName = "term2",
                       SequenceNumber = 2
                    }
                };

         this.masterRepository.Setup(x => x.GetTermsAndConditions(It.IsAny<int>()))
        .Returns(Task.FromResult(termsAndConditions));

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetTermsAndConditions(docTypeId);

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Count() == 2);
         Assert.True(result.Select(a => a.TermsAndConditionsId == 1).Any());
         Assert.True(result.Select(a => a.TermsAndConditionsName == "term1").Any());
         this.masterRepository.Verify(x => x.GetTermsAndConditions(It.IsAny<int>()), Times.Once);
      }

      /// <summary>
      ///  GetJobDocumentType returns empty list
      /// </summary>
      /// <returns>Empty List</returns>
      [Fact]
      public async Task GetJobDocumentType_HasNoValue_ReturnsEmptyList()
      {
         // Arrange
         IEnumerable<JobDocumentTypeViewModel> fileTypes = new List<JobDocumentTypeViewModel>();

         this.masterRepository.Setup(x => x.GetJobDocumentType())
         .Returns(Task.FromResult(fileTypes)).Verifiable();

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetJobDocumentType();

         // Assert
         Assert.Empty(result);
         this.masterRepository.Verify(x => x.GetJobDocumentType(), Times.Once);
      }

      /// <summary>
      ///  GetJobDocumentType returns FileTypeViewModel list
      /// </summary>
      /// <returns>FileTypeViewModel list</returns>
      [Fact]
      public async Task GetJobDocumentType_HasValue_ReturnsValidData()
      {
         // Arrange
         IEnumerable<JobDocumentTypeViewModel> fileTypes = new List<JobDocumentTypeViewModel>()
         {
            new JobDocumentTypeViewModel()
                    {
                        JobDocumentTypeId = 1,
                        TypeName = "Contract",
                        SequenceNumber = 1,
                        IsAvailableForUser = true,
                        TypeAbstract = "Description",
                        CreatedBy = "CCE",
                        CreatedOn = DateTime.Now,
                        UpdatedBy = "CCE",
                        UpdatedOn = DateTime.Now
                    },
                    new JobDocumentTypeViewModel()
                    {
                       JobDocumentTypeId = 2,
                       TypeName = "Submittal"
                    }
                };

         this.masterRepository.Setup(x => x.GetJobDocumentType())
        .Returns(Task.FromResult(fileTypes)).Verifiable();

         // Act
         var masterDataService = new MasterDataService(this.masterRepository.Object);
         var result = await masterDataService.GetJobDocumentType();

         // Assert
         Assert.NotNull(result);
         Assert.True(result.Count() == 2);
         Assert.True(result.Select(a => a.JobDocumentTypeId == 1).Any());
         Assert.True(result.Select(a => a.TypeName == "Contract").Any());
         this.masterRepository.Verify(x => x.GetJobDocumentType(), Times.Once);
      }
   }
}
