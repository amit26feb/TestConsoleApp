﻿// <copyright file="FileGeneratedBackgroundServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using AWS.MessagingWrapper.Contracts;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Services;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using Newtonsoft.Json;
   using TSMT.Settings;
   using Xunit;

   /// <summary>
   /// Tests class for FileGeneratedBackgroundService methods
   /// </summary>
   public class FileGeneratedBackgroundServiceTest
   {
      private readonly Mock<ILogger<FileGeneratedBackgroundService>> mockLogger;
      private readonly FileGeneratedBackgroundServiceHarness serviceUnderTest;
      private readonly Mock<IMessageReceiver> mockMessageReceiver;
      private readonly TSMTSettings settings;
      private readonly Mock<IOptions<TSMTSettings>> mockOptions;
      private readonly Mock<IDocumentPackageService> mockDocPackageService;
      private readonly CancellationTokenSource cancelSource;

      /// <summary>
      /// Initializes a new instance of the <see cref="FileGeneratedBackgroundServiceTest"/> class.
      /// </summary>
      public FileGeneratedBackgroundServiceTest()
      {
         this.mockLogger = new Mock<ILogger<FileGeneratedBackgroundService>>();
         this.mockMessageReceiver = new Mock<IMessageReceiver>();
         this.settings = new TSMTSettings() { SqsServiceUrl = "https://xkcd.com/" };
         this.mockOptions = new Mock<IOptions<TSMTSettings>>();
         this.mockOptions.Setup(m => m.Value).Returns(this.settings);
         this.mockDocPackageService = new Mock<IDocumentPackageService>();
         this.serviceUnderTest = new FileGeneratedBackgroundServiceHarness(
            this.mockLogger.Object,
            this.mockMessageReceiver.Object,
            this.mockOptions.Object,
            this.mockDocPackageService.Object);
         this.cancelSource = new CancellationTokenSource();
      }

      /// <summary>
      /// Verifies the class keeps reading messages if there is an exception from the receiver
      /// </summary>
      [Fact]
      public void ExecuteAsync_ReceiverException_ReadsNextMessages()
      {
         // Arrange
         this.mockMessageReceiver.Setup(r => r.ReceiveMessageAsync(It.IsAny<string>(), this.cancelSource.Token, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
            .Throws(new Exception());

         // Act
         Task runningService = Task.Run(() => this.serviceUnderTest.ExecuteAsyncHarness(this.cancelSource.Token));
         Thread.Sleep(250);
         this.cancelSource.Cancel();

         // Assert
         this.mockMessageReceiver.Verify(r => r.ReceiveMessageAsync(this.settings.SqsServiceUrl, this.cancelSource.Token, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.AtLeast(2));
      }

      /// <summary>
      /// Verifies that messages are not skipped if a message has an invalid message body
      /// </summary>
      [Fact]
      public void ExecuteAsync_InvalidMessageBody_DeletesMessageAndProcessesNext()
      {
         // Arrange
         Message message1 = new Message() { ReceiptHandle = "asdf" };
         Message message2 = new Message() { ReceiptHandle = "ghjk" };
         this.mockMessageReceiver.SetupSequence(r => r.ReceiveMessageAsync(It.IsAny<string>(), this.cancelSource.Token, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(new List<Message>() { message1, message2 }.AsEnumerable()))
            .Returns(Task.FromResult(Enumerable.Empty<Message>()));

         // Act
         Task runningService = Task.Run(() => this.serviceUnderTest.ExecuteAsyncHarness(this.cancelSource.Token));
         Thread.Sleep(250);
         this.cancelSource.Cancel();

         // Assert
         this.mockMessageReceiver.Verify(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, message1.ReceiptHandle), Times.Once);
         this.mockMessageReceiver.Verify(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, message2.ReceiptHandle), Times.Once);
      }

      /// <summary>
      /// Verifies that messages are not skipped if a message has invalid message completed contents
      /// </summary>
      [Fact]
      public void ExecuteAsync_UpdateDocPackageException_DeletesMessageAndProcessesNext()
      {
         // Arrange
         dynamic body = new System.Dynamic.ExpandoObject();
         body.Message = new FileGeneratedModel() { };
         Message message1 = new Message() { ReceiptHandle = "asdf", Body = JsonConvert.SerializeObject(body) };
         Message message2 = new Message() { ReceiptHandle = "ghjk", Body = JsonConvert.SerializeObject(body) };

         this.mockMessageReceiver.SetupSequence(r => r.ReceiveMessageAsync(It.IsAny<string>(), this.cancelSource.Token, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(new List<Message>() { message1, message2 }.AsEnumerable()))
            .Returns(Task.FromResult(Enumerable.Empty<Message>()));
         this.mockDocPackageService.SetupSequence(m => m.UpdateDocumentPackageFileGeneratedInfo(It.IsAny<FileGeneratedModel>()))
            .Throws(new Exception())
            .Returns(Task.FromResult(string.Empty));

         // Act
         Task runningService = Task.Run(() => this.serviceUnderTest.ExecuteAsyncHarness(this.cancelSource.Token));
         Thread.Sleep(250);
         this.cancelSource.Cancel();

         // Assert
         this.mockMessageReceiver.Verify(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, message1.ReceiptHandle), Times.Once);
         this.mockMessageReceiver.Verify(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, message2.ReceiptHandle), Times.Once);
      }

      /// <summary>
      /// Verifies that a valid request message gets deleted
      /// </summary>
      [Fact]
      public void ExecuteAsync_ValidMessage_DeletesMessage()
      {
         // Arrange
         dynamic body = new System.Dynamic.ExpandoObject();
         body.Message = new FileGeneratedModel();
         Message validMessage = new Message() { ReceiptHandle = "asdf", Body = JsonConvert.SerializeObject(body) };

         this.mockMessageReceiver.SetupSequence(r => r.ReceiveMessageAsync(It.IsAny<string>(), this.cancelSource.Token, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(new List<Message>() { validMessage }.AsEnumerable()))
            .Returns(Task.FromResult(Enumerable.Empty<Message>()));
         this.mockDocPackageService.SetupSequence(m => m.UpdateDocumentPackageFileGeneratedInfo(It.IsAny<FileGeneratedModel>()))
            .Returns(Task.FromResult(string.Empty));

         // Act
         Task runningService = Task.Run(() => this.serviceUnderTest.ExecuteAsyncHarness(this.cancelSource.Token));
         Thread.Sleep(250);
         this.cancelSource.Cancel();

         // Assert
         this.mockMessageReceiver.Verify(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, validMessage.ReceiptHandle), Times.Once);
      }

      /// <summary>
      /// Verifies that an exception deleting a message will process the next message
      /// </summary>
      [Fact]
      public void ExecuteAsync_DeleteMessageException_ReadsNextMessage()
      {
         // Arrange
         dynamic body = new System.Dynamic.ExpandoObject();
         body.Message = new FileGeneratedModel() { };
         Message message1 = new Message() { ReceiptHandle = "asdf", Body = JsonConvert.SerializeObject(body) };
         Message message2 = new Message() { ReceiptHandle = "ghjk", Body = JsonConvert.SerializeObject(body) };

         this.mockMessageReceiver.SetupSequence(r => r.ReceiveMessageAsync(It.IsAny<string>(), this.cancelSource.Token, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(new List<Message>() { message1, message2 }.AsEnumerable()))
            .Returns(Task.FromResult(Enumerable.Empty<Message>()));
         this.mockDocPackageService.Setup(m => m.UpdateDocumentPackageFileGeneratedInfo(It.IsAny<FileGeneratedModel>()))
            .Returns(Task.FromResult(string.Empty));
         this.mockMessageReceiver.Setup(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, message1.ReceiptHandle))
            .Throws(new Exception());

         // Act
         Task runningService = Task.Run(() => this.serviceUnderTest.ExecuteAsyncHarness(this.cancelSource.Token));
         Thread.Sleep(250);
         this.cancelSource.Cancel();

         // Assert
         this.mockMessageReceiver.Verify(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, message1.ReceiptHandle), Times.Once);
         this.mockMessageReceiver.Verify(r => r.DeleteMessageAsync(this.settings.SqsServiceUrl, message2.ReceiptHandle), Times.Once);
      }
   }
}
