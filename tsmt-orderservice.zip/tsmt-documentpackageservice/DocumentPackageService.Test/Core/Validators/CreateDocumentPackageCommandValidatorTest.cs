﻿// <copyright file="CreateDocumentPackageCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Validators
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.Validators;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using Xunit;

   /// <summary>
   /// CreateDocumentPackageCommandValidatorTest
   /// </summary>
   public class CreateDocumentPackageCommandValidatorTest
   {
      /// <summary>
      /// Product family repository
      /// </summary>
      private readonly Mock<IDocumentPackageRepository> documentPackageRepository;

      /// <summary>
      /// Context access
      /// </summary>
      private readonly Mock<IHttpContextAccessor> contextAccessor;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentPackageCommandValidatorTest"/> class.
      /// </summary>
      public CreateDocumentPackageCommandValidatorTest()
      {
         this.documentPackageRepository = new Mock<IDocumentPackageRepository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
      }

      /// <summary>
      /// Loading data for the create document package test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for CreateDocumentPackage</returns>
      public static IEnumerable<object[]> GetDataForCreateDocumentPackage(int numTests)
      {
         // Invalid data
         DocPackageViewModel invalidRequest = new DocPackageViewModel
         {
            Package = new DocumentPackageViewModel
            {
               BusinessStreamId = -1,
               DocumentPackageId = 0,
               DocumentTypeId = 0,
               DrAddressId = 0,
               JobId = 0,
               Name = string.Empty
            },
            PackageFile = new DocumentPackageFileViewModel
            {
               LegalEntityId = 0,
               TermsAndConditionsId = 0
            }
         };

         // Valid request
         DocPackageViewModel validRequest = new DocPackageViewModel
         {
            Package = new DocumentPackageViewModel
            {
               BusinessStreamId = 1,
               DocumentPackageId = 1,
               DocumentTypeId = 1,
               DrAddressId = 127,
               JobId = 8401,
               Name = "Package 1"
            },
            PackageFile = new DocumentPackageFileViewModel
            {
               LegalEntityId = 1,
               TermsAndConditionsId = 1
            }
         };

         var allData = new List<object[]>
            {
                new object[] { invalidRequest, Times.Once(), 0, 7 },
                new object[] { validRequest, Times.Once(), 1, 0 },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test createdocument package for different scenarios
      /// </summary>
      /// <param name="request">CreateDocumentPackageViewModel</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="validationResult">Validation result</param>
      /// <param name="errorCount">Error count</param>
      [Theory]
      [MemberData(nameof(GetDataForCreateDocumentPackage), parameters: 1)]
      public void CreateDocumentPackage_ForTwoDifferentRequests_ReturnsValidationResult(DocPackageViewModel request, Times timesCalled, bool validationResult, int errorCount)
      {
         this.documentPackageRepository.Setup(x => x.ValidateDocumentPackage(It.IsAny<string>(), It.IsAny<int>()))
             .Returns(Task.FromResult(validationResult));

         var testResult = new CreateDocumentPackageCommandValidator(this.documentPackageRepository.Object, this.contextAccessor.Object).ValidateAsync(new CreateDocumentPackageCommand(request), default(CancellationToken));

         Assert.Equal(testResult.Result.IsValid, validationResult);
         Assert.Equal(testResult.Result.Errors.Count, errorCount);
         this.documentPackageRepository.Verify(x => x.ValidateDocumentPackage(It.IsAny<string>(), It.IsAny<int>()), timesCalled);
      }
   }
}
