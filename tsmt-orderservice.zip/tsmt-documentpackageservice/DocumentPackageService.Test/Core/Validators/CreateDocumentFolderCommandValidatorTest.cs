﻿// <copyright file="CreateDocumentFolderCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Validators
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.Validators;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using Xunit;

   /// <summary>
   /// CreateDocumentFolderCommandValidatorTest
   /// </summary>
   public class CreateDocumentFolderCommandValidatorTest
   {
      /// <summary>
      /// Document folder repository
      /// </summary>
      private readonly Mock<IDocumentFolderRepository> documentFolderRepositoryMock;

      /// <summary>
      /// Context access
      /// </summary>
      private readonly Mock<IHttpContextAccessor> contextAccessor;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentFolderCommandValidatorTest"/> class.
      /// </summary>
      public CreateDocumentFolderCommandValidatorTest()
      {
         this.documentFolderRepositoryMock = new Mock<IDocumentFolderRepository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
      }

      /// <summary>
      /// Loading data for the create document folder test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for CreateDocumentFolder</returns>
      public static IEnumerable<object[]> GetDataForCreateDocumentFolder(int numTests)
      {
         // Invalid request
         DocumentFolderViewModel invalidRequest = new DocumentFolderViewModel
         {
            FolderId = 0,
            FolderName = string.Empty,
            FolderSource = "user",
            CreatedByUser = "user",
            CreatedDate = DateTime.Now,
            DrAddressId = 0,
            FolderParentId = 0,
            JobId = 0,
            LastModifiedDate = DateTime.Now,
            LastModifiedUser = "user",
         };

         // Valid request
         DocumentFolderViewModel validRequest = new DocumentFolderViewModel
         {
            FolderId = 0,
            FolderName = "Sample",
            FolderSource = "user",
            CreatedByUser = "user",
            CreatedDate = DateTime.Now,
            DrAddressId = 101,
            FolderParentId = 0,
            JobId = 12345,
            LastModifiedDate = DateTime.Now,
            LastModifiedUser = "user",
         };

         var allData = new List<object[]>
            {
                new object[] { invalidRequest, Times.Once(), 0, 3 },
                new object[] { validRequest, Times.Once(), 1, 0 },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test create document folder for different scenarios
      /// </summary>
      /// <param name="request">CreateDocumentFolderViewModel</param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="validationResult">Validation result</param>
      /// <param name="errorCount">Error count</param>
      [Theory]
      [MemberData(nameof(GetDataForCreateDocumentFolder), parameters: 1)]
      public void CreateDocumentFolder_ForTwoDifferentRequests_ReturnsValidationResult(DocumentFolderViewModel request, Times timesCalled, bool validationResult, int errorCount)
      {
         this.documentFolderRepositoryMock.Setup(x => x.ValidateDocumentFolder(request))
             .Returns(Task.FromResult(validationResult));

         var testResult = new CreateDocumentFolderCommandValidator(this.documentFolderRepositoryMock.Object, this.contextAccessor.Object).ValidateAsync(new CreateDocumentFolderCommand(request), default(CancellationToken));

         Assert.Equal(testResult.Result.IsValid, validationResult);
         Assert.Equal(testResult.Result.Errors.Count, errorCount);
         this.documentFolderRepositoryMock.Verify(x => x.ValidateDocumentFolder(request), timesCalled);
      }
   }
}
