﻿// <copyright file="UpdateDocumentPackageCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Validators
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.Validators;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using Xunit;

   /// <summary>
   /// Test for UpdateDocumentPackageCommandValidator
   /// </summary>
   public class UpdateDocumentPackageCommandValidatorTest
   {
      /// <summary>
      /// Product family repository
      /// </summary>
      private readonly Mock<IDocumentPackageRepository> documentPackageRepository;

      /// <summary>
      /// Context access
      /// </summary>
      private readonly Mock<IHttpContextAccessor> contextAccessor;

      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateDocumentPackageCommandValidatorTest"/> class.
      /// </summary>
      public UpdateDocumentPackageCommandValidatorTest()
      {
         this.documentPackageRepository = new Mock<IDocumentPackageRepository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
      }

      /// <summary>
      /// Loading data for the update document package test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for CreateDocumentPackage</returns>
      public static IEnumerable<object[]> GetDataForUpdateDocumentPackage(int numTests)
      {
         // Invalid data
         DocPackageViewModel invalidRequest = new DocPackageViewModel
         {
            Package = new DocumentPackageViewModel
            {
               BusinessStreamId = -1,
               DocumentPackageId = 0,
               DocumentTypeId = 0,
               DrAddressId = 0,
               JobId = 0,
               Name = string.Empty
            },
            PackageFile = new DocumentPackageFileViewModel
            {
               LegalEntityId = 0,
               TermsAndConditionsId = 0
            }
         };

         // Valid request
         DocPackageViewModel validRequest = new DocPackageViewModel
         {
            Package = new DocumentPackageViewModel
            {
               BusinessStreamId = 1,
               DocumentPackageId = 1,
               DocumentTypeId = 1,
               DrAddressId = 127,
               JobId = 8401,
               Name = "Package 1"
            },
            PackageFile = new DocumentPackageFileViewModel
            {
               LegalEntityId = 1,
               TermsAndConditionsId = 1
            }
         };

         var allData = new List<object[]>
            {
                new object[] { invalidRequest, 0, 6 },
                new object[] { validRequest, 1, 0 },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test update document package for different scenarios
      /// </summary>
      /// <param name="request">DocumentPackageViewModel</param>
      /// <param name="validationResult">Validation result</param>
      /// <param name="errorCount">Error count</param>
      [Theory]
      [MemberData(nameof(GetDataForUpdateDocumentPackage), parameters: 1)]
      public void UpdateDocumentPackage_ForTwoDifferentRequests_ReturnsValidationResult(DocPackageViewModel request, bool validationResult, int errorCount)
      {
         var testResult = new UpdateDocumentPackageCommandValidator(this.documentPackageRepository.Object, this.contextAccessor.Object).ValidateAsync(new UpdateDocumentPackageCommand(request), default(CancellationToken));

         Assert.Equal(testResult.Result.IsValid, validationResult);
         Assert.Equal(testResult.Result.Errors.Count, errorCount);
      }
   }
}
