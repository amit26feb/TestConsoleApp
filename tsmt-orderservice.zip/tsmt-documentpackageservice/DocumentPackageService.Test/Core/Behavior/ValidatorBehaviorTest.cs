﻿// <copyright file="ValidatorBehaviorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Behavior
{
    using System.Threading;
    using System.Threading.Tasks;
    using DocumentPackageService.Core.Behavior;
    using FluentValidation;
    using Xunit;

    /// <summary>
    ///  Validator behavior test
    /// </summary>
    public class ValidatorBehaviorTest
    {
        /// <summary>
        /// Validator behavior request response
        /// </summary>
        private readonly IValidator<Request>[] validators;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatorBehaviorTest"/> class.
        /// </summary>
        public ValidatorBehaviorTest()
        {
            this.validators = new IValidator<Request>[0];
        }

        /// <summary>
        /// ValidatorBehavior handle using valid input returns valid response
        /// </summary>
        /// <returns>Assertion result</returns>
        [Fact]
        public async Task Handle_ValidRequest_ReturnsResponse()
        {
            // Arrange
            ValidatorBehavior<Request, Response> validatorBehavior = new ValidatorBehavior<Request, Response>(this.validators);

            Request ping = new Request
            {
                Message = "test request"
            };
            Response pong = new Response
            {
                Message = "test response"
            };

            CancellationToken cancellationToken = default(CancellationToken);

            // Act
            var response = await validatorBehavior.Handle(ping, cancellationToken, next: () => Task.FromResult(pong));

            // Assert
            Assert.NotNull(response);
            Assert.Equal(response.Message, pong.Message);
        }
    }
}