﻿// <copyright file="UpdateDocumentPackageFileCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Behavior.CommandHandler
{
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.CommandHandler;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Update document package file command handler tests
   /// </summary>
   public class UpdateDocumentPackageFileCommandHandlerTest
   {
      private readonly Mock<ILogger<UpdateDocumentPackageFileCommand>> mockLogger;
      private readonly Mock<IDocumentPackageService> documentPackageService;
      private readonly DocumentPackageFileStatusViewModel docPackageFileStatusViewModel;
      private readonly UpdateDocumentPackageFileCommandHandler handlerUnderTest;
      private readonly UpdateDocumentPackageFileCommand documentPackageFileCommand;

      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateDocumentPackageFileCommandHandlerTest"/> class.
      /// </summary>
      public UpdateDocumentPackageFileCommandHandlerTest()
      {
         this.mockLogger = new Mock<ILogger<UpdateDocumentPackageFileCommand>>();
         this.documentPackageService = new Mock<IDocumentPackageService>();
         this.docPackageFileStatusViewModel = new DocumentPackageFileStatusViewModel()
         {
            DocumentPackageId = 1,
            FileVersion = 2,
            Status = "Single"
         };
         this.documentPackageFileCommand = new UpdateDocumentPackageFileCommand(this.docPackageFileStatusViewModel);
         this.handlerUnderTest =
            new UpdateDocumentPackageFileCommandHandler(this.mockLogger.Object, this.documentPackageService.Object);
      }

      /// <summary>
      /// Tests that Handle method passes back true result from DocumentPackageService
      /// </summary>
      /// <returns>Task signifying completion</returns>
      [Fact]
      public async Task Handle_AnyRequest_ReturnsTrueResult()
      {
         // Arrange
         this.documentPackageService.Setup(
            dps => dps.UpdateDocumentPackageFileStatus(
               this.docPackageFileStatusViewModel.DocumentPackageId,
               this.docPackageFileStatusViewModel.FileVersion,
               this.docPackageFileStatusViewModel.Status))
            .Returns(Task.FromResult(true)).Verifiable();

         // Act
         bool result = await this.handlerUnderTest.Handle(this.documentPackageFileCommand, default(CancellationToken));

         // Assert
         Assert.True(result);
         this.documentPackageService.Verify();
      }

      /// <summary>
      /// Tests that Handle method passes back false result from DocumentPackageService
      /// </summary>
      /// <returns>Task signifying completion</returns>
      [Fact]
      public async Task Handle_AnyRequest_ReturnsFalseResult()
      {
         // Arrange
         this.documentPackageService.Setup(
            dps => dps.UpdateDocumentPackageFileStatus(
               this.docPackageFileStatusViewModel.DocumentPackageId,
               this.docPackageFileStatusViewModel.FileVersion,
               this.docPackageFileStatusViewModel.Status))
            .Returns(Task.FromResult(false)).Verifiable();

         // Act
         bool result = await this.handlerUnderTest.Handle(this.documentPackageFileCommand, default(CancellationToken));

         // Assert
         Assert.False(result);
         this.documentPackageService.Verify();
      }
   }
}
