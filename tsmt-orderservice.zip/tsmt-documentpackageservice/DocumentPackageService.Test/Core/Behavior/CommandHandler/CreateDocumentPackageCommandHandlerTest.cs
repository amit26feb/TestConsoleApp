﻿// <copyright file="CreateDocumentPackageCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Behavior.CommandHandler
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.CommandHandler;
   using DocumentPackageService.Core.Commands;
    using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
    using Moq;
   using Xunit;

   /// <summary>
   /// Create document package command handler test
   /// </summary>
   public class CreateDocumentPackageCommandHandlerTest
   {
      private readonly Mock<ILogger<CreateDocumentPackageCommand>> loggerMock;
      private readonly Mock<IDocumentPackageService> documentPackageServiceMock;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentPackageCommandHandlerTest"/> class.
      /// </summary>
      public CreateDocumentPackageCommandHandlerTest()
      {
         this.loggerMock = new Mock<ILogger<CreateDocumentPackageCommand>>();
         this.documentPackageServiceMock = new Mock<IDocumentPackageService>();
      }

      /// <summary>
      /// Loading data for the create document package test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for Handle</returns>
      public static IEnumerable<object[]> GetDataForCreateDocumentPackage(int numTests)
      {
         // Invalid data
         DocPackageViewModel invalidRequest = new DocPackageViewModel
         {
            Package = new DocumentPackageViewModel
            {
               BusinessStreamId = 1,
               DocumentPackageId = 0,
               DocumentTypeId = 0,
               DrAddressId = 0,
               JobId = 0,
               Name = string.Empty
            },
            PackageFile = new DocumentPackageFileViewModel
            {
               LegalEntityId = 0,
               TermsAndConditionsId = 0
            }
         };

         // Valid request
         DocPackageViewModel validRequest = new DocPackageViewModel
         {
            Package = new DocumentPackageViewModel
            {
               BusinessStreamId = 1,
               DocumentPackageId = 1,
               DocumentTypeId = 1,
               DrAddressId = 127,
               JobId = 8401,
               Name = "Package 1"
            },
            PackageFile = new DocumentPackageFileViewModel
            {
               LegalEntityId = 1,
               TermsAndConditionsId = 1
            }
         };

         var allData = new List<object[]>
            {
                new object[] { invalidRequest, Times.Once(), null },
                new object[] { validRequest, Times.Once(), validRequest },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test Handle for different scenarios
      /// </summary>
      /// <param name="request">Document package view model </param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="response">Response</param>
      /// <returns>Returns true if document package created else returns false.</returns>
      [Theory]
      [MemberData(nameof(GetDataForCreateDocumentPackage), parameters: 2)]
      public async Task Handle_ForTwoDifferentRequests_ReturnsCreationStatus(DocPackageViewModel request, Times timesCalled, DocPackageViewModel response)
      {
         // Arrange
         this.documentPackageServiceMock.Setup(x => x.CreateDocumentPackage(It.IsAny<DocPackageViewModel>()))
             .Returns(Task.FromResult(response));

         var fakeCreateProductCommand = new CreateDocumentPackageCommand(request);

         // Act
         var handler = new CreateDocumentPackageCommandHandler(this.loggerMock.Object, this.documentPackageServiceMock.Object);
         var cltToken = default(CancellationToken);
         var result = await handler.Handle(fakeCreateProductCommand, cltToken);

         // Assert
         Assert.Equal(response, result);
         this.documentPackageServiceMock.Verify(x => x.CreateDocumentPackage(It.IsAny<DocPackageViewModel>()), timesCalled);
      }
   }
}
