﻿// <copyright file="CreateDocumentFolderCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Test.Core.Behavior.CommandHandler
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.CommandHandler;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   /// <summary>
   /// Create document folder command handler test
   /// </summary>
   public class CreateDocumentFolderCommandHandlerTest
   {
      private readonly Mock<ILogger<CreateDocumentFolderCommand>> loggerMock;
      private readonly Mock<IDocumentFolderService> documentFolderServiceMock;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentFolderCommandHandlerTest"/> class.
      /// </summary>
      public CreateDocumentFolderCommandHandlerTest()
      {
         this.loggerMock = new Mock<ILogger<CreateDocumentFolderCommand>>();
         this.documentFolderServiceMock = new Mock<IDocumentFolderService>();
      }

      /// <summary>
      /// Loading data for the create document folder test
      /// </summary>
      /// <param name="numTests">Number of tests to be performed</param>
      /// <returns>Each object returned to execute the test for Handle</returns>
      public static IEnumerable<object[]> GetDataForCreateDocumentFolder(int numTests)
      {
         // Invalid request
         DocumentFolderViewModel invalidRequest = new DocumentFolderViewModel
         {
            FolderId = 0,
            FolderName = string.Empty,
            FolderSource = "user",
            CreatedByUser = "user",
            CreatedDate = DateTime.Now,
            DrAddressId = 0,
            FolderParentId = 0,
            JobId = 0,
            LastModifiedDate = DateTime.Now,
            LastModifiedUser = "user",
         };

         // Valid request
         DocumentFolderViewModel validRequest = new DocumentFolderViewModel
         {
            FolderId = 0,
            FolderName = "Sample",
            FolderSource = "user",
            CreatedByUser = "user",
            CreatedDate = DateTime.Now,
            DrAddressId = 101,
            FolderParentId = 0,
            JobId = 12345,
            LastModifiedDate = DateTime.Now,
            LastModifiedUser = "user",
         };

         // Folders List
         IEnumerable<DocumentFolderViewModel> docFolderList = new List<DocumentFolderViewModel>
         {
            new DocumentFolderViewModel
            {
               FolderId = 1,
               FolderName = "Sample",
               FolderSource = "user",
               CreatedByUser = "user",
               CreatedDate = DateTime.Now,
               DrAddressId = 101,
               FolderParentId = 0,
               JobId = 12345,
               LastModifiedDate = DateTime.Now,
               LastModifiedUser = "user",
            },
            new DocumentFolderViewModel
            {
               FolderId = 2,
               FolderName = "TestFolder",
               FolderSource = "user",
               CreatedByUser = "user",
               CreatedDate = DateTime.Now,
               DrAddressId = 101,
               FolderParentId = 0,
               JobId = 12345,
               LastModifiedDate = DateTime.Now,
               LastModifiedUser = "user",
            }
         };

         var allData = new List<object[]>
            {
                new object[] { invalidRequest, Times.Once(), null },
                new object[] { validRequest, Times.Once(), docFolderList },
            };

         return allData.Take(numTests);
      }

      /// <summary>
      /// Method to test Handle for different scenarios
      /// </summary>
      /// <param name="request">Document folder view model </param>
      /// <param name="timesCalled">Times the method is called</param>
      /// <param name="response">Response</param>
      /// <returns>Returns true if document folder created else returns false.</returns>
      [Theory]
      [MemberData(nameof(GetDataForCreateDocumentFolder), parameters: 2)]
      public async Task Handle_ForTwoDifferentRequests_ReturnsCreationStatus(DocumentFolderViewModel request, Times timesCalled, IEnumerable<DocumentFolderViewModel> response)
      {
         // Arrange
         this.documentFolderServiceMock.Setup(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderViewModel>()))
             .Returns(Task.FromResult(response));

         var fakeCreateDocumentFolderCommand = new CreateDocumentFolderCommand(request);

         // Act
         var handler = new CreateDocumentFolderCommandHandler(this.loggerMock.Object, this.documentFolderServiceMock.Object);
         var cltToken = default(CancellationToken);
         var result = await handler.Handle(fakeCreateDocumentFolderCommand, cltToken);

         // Assert
         Assert.Equal(response, result);
         this.documentFolderServiceMock.Verify(x => x.CreateDocumentFolder(It.IsAny<DocumentFolderViewModel>()), timesCalled);
      }
   }
}
