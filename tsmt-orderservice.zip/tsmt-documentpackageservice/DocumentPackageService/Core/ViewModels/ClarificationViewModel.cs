﻿// <copyright file="ClarificationViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// View model for clarifications (exceptions) for the document package
   /// </summary>
   public class ClarificationViewModel
   {
      /// <summary>
      /// Gets or sets Product Family Id
      /// </summary>
      public int ProductFamilyId { get; set; }

      /// <summary>
      /// Gets or sets Clarification Details
      /// </summary>
      public IEnumerable<string> ClarificationDetails { get; set; }
   }
}
