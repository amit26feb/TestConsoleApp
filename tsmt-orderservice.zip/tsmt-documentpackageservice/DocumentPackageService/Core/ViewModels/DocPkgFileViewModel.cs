﻿// <copyright file="DocPkgFileViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// Document package File view model
   /// </summary>
   public class DocPkgFileViewModel : DocumentPackageFileViewModel
   {
      /// <summary>
      /// Gets or sets LegalEntityLongName
      /// </summary>
      public string LegalEntityLongName { get; set; }

      /// <summary>
      /// Gets or sets LegalEntityName
      /// </summary>
      public string LegalEntityShortName { get; set; }

      /// <summary>
      /// Gets or sets TermsConditionsName
      /// </summary>
      public string TermsConditionsName { get; set; }

      /// <summary>
      /// Gets or sets TCFileLocation
      /// </summary>
      public string TCFileLocation { get; set; }
   }
}
