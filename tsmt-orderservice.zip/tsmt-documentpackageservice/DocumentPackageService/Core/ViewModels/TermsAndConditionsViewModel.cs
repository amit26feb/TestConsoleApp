﻿// <copyright file="TermsAndConditionsViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
    using System;

   /// <summary>
   /// View model for terms and condition
   /// </summary>
    public class TermsAndConditionsViewModel
    {
      /// <summary>
      /// Gets or sets TermsAndConditionId
      /// </summary>
      public int TermsAndConditionsId { get; set; }

      /// <summary>
      /// Gets or sets TermsAndCondition
      /// </summary>
      public string TermsAndConditionsName { get; set; }

      /// <summary>
      /// Gets or sets Description
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets DocTypeId
      /// </summary>
      public int DocTypeId { get; set; }

      /// <summary>
      /// Gets or sets FileLocation
      /// </summary>
      public string FileLocation { get; set; }

      /// <summary>
      /// Gets or sets SequenceNumber
      /// </summary>
      public int SequenceNumber { get; set; }

      /// <summary>
      /// Gets or sets DefaultInd
      /// </summary>
      public int DefaultInd { get; set; }

      /// <summary>
      /// Gets or sets CreatedOn
      /// </summary>
      public DateTime CreatedOn { get; set; }

      /// <summary>
      /// Gets or sets CreatedBy
      /// </summary>
      public string CreatedBy { get; set; }

      /// <summary>
      /// Gets or sets UpdatedOn
      /// </summary>
      public DateTime UpdatedOn { get; set; }

      /// <summary>
      /// Gets or sets UpdatedBy
      /// </summary>
      public string UpdatedBy { get; set; }
   }
}
