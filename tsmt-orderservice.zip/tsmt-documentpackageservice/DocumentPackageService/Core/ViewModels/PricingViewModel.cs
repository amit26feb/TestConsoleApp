﻿// <copyright file="PricingViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// View model for the pricing information from the document package
   /// </summary>
    public class PricingViewModel
    {
      /// <summary>
      /// Gets or sets a value indicating whether to include ADP in the generated document
      /// </summary>
      public bool IncludeADP { get; set; }
   }
}
