﻿// <copyright file="DocumentPackageSummaryViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System;

   /// <summary>
   /// Document packages list view model
   /// </summary>
   public class DocumentPackageSummaryViewModel
   {
      /// <summary>
      /// Gets or sets DocumentType
      /// </summary>
      public string DocumentType { get; set; }

      /// <summary>
      /// Gets or sets DocPkgId
      /// </summary>
      public int DocPkgId { get; set; }

      /// <summary>
      /// Gets or sets NAME
      /// </summary>
      public string Name { get; set; }

      /// <summary>
      /// Gets or sets DESCRIPTION
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets DrAddressId
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets CreatedUser
      /// </summary>
      public string CreatedUser { get; set; }

      /// <summary>
      /// Gets or sets CreatedDate
      /// </summary>
      public DateTime CreatedDate { get; set; }

      /// <summary>
      /// Gets or sets ModifiedUser
      /// </summary>
      public string ModifiedUser { get; set; }

      /// <summary>
      /// Gets or sets ModifiedDate
      /// </summary>
      public DateTime ModifiedDate { get; set; }

      /// <summary>
      /// Gets or sets Status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets FileVersion
      /// </summary>
      public int FileVersion { get; set; }

      /// <summary>
      /// Gets or sets LastGeneratedFileVersion
      /// </summary>
      public int? LastGeneratedFileVersion { get; set; }

      /// <summary>
      /// Gets or sets FileGeneratedDate
      /// </summary>
      public DateTime? FileGeneratedDate { get; set; }

      /// <summary>
      /// Gets or sets FileGeneratedByUser
      /// </summary>
      public string FileGeneratedByUser { get; set; }

      /// <summary>
      /// Gets or sets LastUploadedFileVersion
      /// </summary>
      public int? LastUploadedFileVersion { get; set; }

      /// <summary>
      /// Gets or sets FileUploadedDate
      /// </summary>
      public DateTime? FileUploadedDate { get; set; }

      /// <summary>
      /// Gets or sets FileUploadedByUser
      /// </summary>
      public string FileUploadedByUser { get; set; }

      /// <summary>
      /// Gets or sets DocTypeId
      /// </summary>
      public int DocTypeId { get; set; }
   }
}
