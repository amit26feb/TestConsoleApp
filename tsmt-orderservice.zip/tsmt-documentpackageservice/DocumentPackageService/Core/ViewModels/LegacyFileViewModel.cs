﻿// <copyright file="LegacyFileViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System;

   /// <summary>
   /// Legacy file model
   /// </summary>
   public class LegacyFileViewModel
   {
      /// <summary>
      /// Gets or sets a value indicating whether this is a legacy ldg file
      /// </summary>
      public bool IsLegacyLdgFile { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether this is a legacy job center file
      /// </summary>
      public bool IsLegacyJobCenterFile { get; set; }

      /// <summary>
      /// Gets or sets the filename of the file
      /// </summary>
      public string FileName { get; set; }

      /// <summary>
      /// Gets or sets the relative directory and filename of the file
      /// </summary>
      public string RelativeDirectoryAndFileName { get; set; }

      /// <summary>
      /// Gets or sets the full path to the file
      /// </summary>
      public string FullPathToFile { get; set; }

      /// <summary>
      ///  Gets or sets the last modified date of the file
      /// </summary>
      public DateTime LastModifiedDate { get; set; }

      /// <summary>
      ///  Gets or sets the version id of the file
      /// </summary>
      public string VersionId { get; set; }
   }
}
