﻿// <copyright file="DocumentFolderViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System;

   /// <summary>
   /// Document folder view model
   /// </summary>
   public class DocumentFolderViewModel
   {
      /// <summary>
      /// Gets or sets document folder id
      /// </summary>
      public int FolderId { get; set; }

      /// <summary>
      /// Gets or sets document folder parent id
      /// </summary>
      public int? FolderParentId { get; set; }

      /// <summary>
      /// Gets or sets dr address id
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets the folder name
      /// </summary>
      public string FolderName { get; set; }

      /// <summary>
      /// Gets or sets the folder source
      /// </summary>
      public string FolderSource { get; set; }

      /// <summary>
      /// Gets or sets the created date
      /// </summary>
      public DateTime CreatedDate { get; set; }

      /// <summary>
      /// Gets or sets the created by user id
      /// </summary>
      public string CreatedByUser { get; set; }

      /// <summary>
      /// Gets or sets the last modified date
      /// </summary>
      public DateTime LastModifiedDate { get; set; }

      /// <summary>
      /// Gets or sets the last modified user id
      /// </summary>
      public string LastModifiedUser { get; set; }

      /// <summary>
      /// Gets or sets job folder type id
      /// </summary>
      public int? JobFolderTypeId { get; set; }

      /// <summary>
      /// Gets or sets document type id
      /// </summary>
      public int? DocTypeId { get; set; }
   }
}
