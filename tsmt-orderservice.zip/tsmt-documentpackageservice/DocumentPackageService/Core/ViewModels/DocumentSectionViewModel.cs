﻿// <copyright file="DocumentSectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// Gets or sets Document Section view model
   /// </summary>
   public class DocumentSectionViewModel
   {
      /// <summary>
      /// Gets or sets Product Family Id
      /// </summary>
      public int ProductFamilyId { get; set; }

      /// <summary>
      /// Gets or sets Document Sections to include (flag defined in document service)
      /// </summary>
      public int Sections { get; set; }
   }
}
