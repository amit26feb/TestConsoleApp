﻿// <copyright file="DocumentPackageFileStatusViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using Microsoft.AspNetCore.Mvc;

   /// <summary>
   /// Input model for updating document package file status
   /// </summary>
   public class DocumentPackageFileStatusViewModel
   {
      /// <summary>
      /// Gets or sets the reference identifier for the document package
      /// </summary>
      [FromRoute(Name = "documentPackageId")]
      public int DocumentPackageId { get; set; }

      /// <summary>
      /// Gets or sets the file version for the document package file
      /// </summary>
      [FromRoute(Name = "fileVersion")]
      public int FileVersion { get; set; }

      /// <summary>
      /// Gets or sets the status for file generation
      /// </summary>
      [FromRoute(Name = "status")]
      public string Status { get; set; }
   }
}
