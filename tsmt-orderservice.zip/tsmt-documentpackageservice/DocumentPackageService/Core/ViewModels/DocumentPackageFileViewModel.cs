﻿// <copyright file="DocumentPackageFileViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System;

   /// <summary>
   /// Document package file view model
   /// </summary>
   public class DocumentPackageFileViewModel
   {
      /// <summary>
      /// Gets or sets DrAddressId
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets JobId
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets DocumentPackageId
      /// </summary>
      public int DocumentPackageId { get; set; }

      /// <summary>
      /// Gets or sets Version
      /// </summary>
      public int Version { get; set; }

      /// <summary>
      /// Gets or sets DocumentPackageFileId
      /// </summary>
      public int DocumentPackageFileId { get; set; }

      /// <summary>
      /// Gets or sets LegalEntityId
      /// </summary>
      public int LegalEntityId { get; set; }

      /// <summary>
      /// Gets or sets TermsAndConditionsId
      /// </summary>
      public int TermsAndConditionsId { get; set; }

      /// <summary>
      /// Gets or sets BidAlternateId
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets FileName
      /// </summary>
      public string FileName { get; set; }

      /// <summary>
      /// Gets or sets FileLocation
      /// </summary>
      public string FileLocation { get; set; }

      /// <summary>
      /// Gets or sets AdditionalInfo
      /// </summary>
      public AdditionalInfoViewModel AdditionalInfo { get; set; }

      /// <summary>
      /// Gets or sets Status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets GeneratedInfo
      /// </summary>
      public string GeneratedInfo { get; set; }

      /// <summary>
      /// Gets or sets GeneratedDate
      /// </summary>
      public DateTime? GeneratedDate { get; set; }

      /// <summary>
      /// Gets or sets GeneratedBy
      /// </summary>
      public string GeneratedBy { get; set; }

      /// <summary>
      /// Gets or sets ProposalNumber
      /// </summary>
      public string ProposalNumber { get; set; }

      /// <summary>
      /// Gets or sets UpdatedOn
      /// </summary>
      public DateTime UpdatedOn { get; set; }

      /// <summary>
      /// Gets or sets UpdatedBy
      /// </summary>
      public string UpdatedBy { get; set; }

      /// <summary>
      /// Gets or sets DocTypeShortName
      /// </summary>
      public string DocTypeShortName { get; set; }
   }
}
