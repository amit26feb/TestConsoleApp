﻿// <copyright file="AdditionalInfoViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// View model for addition info to be saved for the document package
   /// </summary>
   public class AdditionalInfoViewModel
   {
      /// <summary>
      /// Gets or sets Addressee information
      /// </summary>
      public AddresseeViewModel Addressee { get; set; }

      /// <summary>
      /// Gets or sets Introduction information
      /// </summary>
      public IntroductionViewModel Introduction { get; set; }

      /// <summary>
      /// Gets or sets Pricing information
      /// </summary>
      public PricingViewModel Pricing { get; set; }

      /// <summary>
      /// Gets or sets Signature information
      /// </summary>
      public SignatureViewModel Signature { get; set; }

      /// <summary>
      /// Gets or sets Clarifications information
      /// </summary>
      public List<ClarificationViewModel> Clarifications { get; set; }

      /// <summary>
      /// Gets or sets Items Not Included information
      /// </summary>
      public List<ItemsNotIncludedViewModel> ItemsNotIncluded { get; set; }

      /// <summary>
      /// Gets or sets Document Sections to include
      /// </summary>
      public List<DocumentSectionViewModel> DocumentSectionsToInclude { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether unit of measure is english(IP) or metric(SI)
      /// </summary>
      public bool UOMMetric { get; set; } = false;
   }
}
