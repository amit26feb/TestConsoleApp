﻿// <copyright file="DocPkgDetailsViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// Document package Details view model
   /// </summary>
   public class DocPkgDetailsViewModel : DocumentPackageViewModel
   {
      /// <summary>
      /// Gets or sets DocPkgFileDetails
      /// </summary>
      public DocPkgFileViewModel DocPkgFileDetails { get; set; }
   }
}
