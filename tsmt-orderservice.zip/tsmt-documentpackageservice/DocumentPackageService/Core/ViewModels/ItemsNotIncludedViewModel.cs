﻿// <copyright file="ItemsNotIncludedViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// View model for items not included for the document package
   /// </summary>
   public class ItemsNotIncludedViewModel
   {
      /// <summary>
      /// Gets or sets Product Family Id
      /// </summary>
      public int ProductFamilyId { get; set; }

      /// <summary>
      /// Gets or sets Items Not Included Details
      /// </summary>
      public IEnumerable<string> ItemsNotIncludedDetails { get; set; }
   }
}
