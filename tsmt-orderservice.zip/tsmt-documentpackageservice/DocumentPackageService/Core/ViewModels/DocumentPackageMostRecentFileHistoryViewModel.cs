﻿// <copyright file="DocumentPackageMostRecentFileHistoryViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// Document package most recent file history view model
   /// </summary>
   public class DocumentPackageMostRecentFileHistoryViewModel
   {
      /// <summary>
      /// Gets or sets the file name of the document package file
      /// </summary>
      public string FileName { get; set; }

      /// <summary>
      /// Gets or sets the version of the document package file
      /// </summary>
      public int FileVersion { get; set; }

      /// <summary>
      /// Gets or sets the total number of generated versions
      /// </summary>
      public int TotalGeneratedVersions { get; set; }
   }
}
