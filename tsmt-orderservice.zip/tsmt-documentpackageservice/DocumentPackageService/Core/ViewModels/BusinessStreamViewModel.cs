﻿// <copyright file="BusinessStreamViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
    using System;

   /// <summary>
   /// View model for business stream
   /// </summary>
   public class BusinessStreamViewModel
    {
      /// <summary>
      /// Gets or sets BusinessStreamId
      /// </summary>
      public int BusinessStreamId { get; set; }

      /// <summary>
      /// Gets or sets BusinessStreamName
      /// </summary>
      public string BusinessStreamName { get; set; }

      /// <summary>
      /// Gets or sets Description
      /// </summary>
      public string BusinessStreamAbstract { get; set; }

      /// <summary>
      /// Gets or sets Status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets CreatedOn
      /// </summary>
      public DateTime CreatedOn { get; set; }

      /// <summary>
      /// Gets or sets CreatedBy
      /// </summary>
      public string CreatedBy { get; set; }

      /// <summary>
      /// Gets or sets UpdatedOn
      /// </summary>
      public DateTime UpdatedOn { get; set; }

      /// <summary>
      /// Gets or sets UpdatedBy
      /// </summary>
      public string UpdatedBy { get; set; }
   }
}
