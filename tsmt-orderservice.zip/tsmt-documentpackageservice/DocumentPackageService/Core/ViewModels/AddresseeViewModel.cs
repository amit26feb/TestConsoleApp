﻿// <copyright file="AddresseeViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// View model for addressee
   /// </summary>
   public class AddresseeViewModel
   {
      /// <summary>
      /// Gets or sets a value indicating whether if all bidders selected true else false
      /// </summary>
      public bool AllBidders { get; set; }

      /// <summary>
      /// Gets or sets selected bidder id
      /// </summary>
      public int BidderId { get; set; }

      /// <summary>
      /// Gets or sets SoldTo bidder id
      /// </summary>
      public int? SoldToId { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether if Other selected true else false
      /// </summary>
      public bool IsOther { get; set; }

      /// <summary>
      /// Gets or sets Other Customer First Name
      /// </summary>
      public string OtherCustomerFirstName { get; set; }

      /// <summary>
      /// Gets or sets Other Customer Last Name
      /// </summary>
      public string OtherCustomerLastName { get; set; }

      /// <summary>
      /// Gets or sets Other Customer Name
      /// </summary>
      public string OtherCustomerName { get; set; }
   }
}
