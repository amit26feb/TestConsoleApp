﻿// <copyright file="IntroductionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// View model for the document package introduction section
   /// </summary>
    public class IntroductionViewModel
    {
      /// <summary>
      /// Gets or sets a value indicating whether to show greeting message if true else false
      /// </summary>
      public bool ShowGreeting { get; set; }

      /// <summary>
      /// Gets or sets the greeting message
      /// </summary>
      public string GreetingMessage { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether to show customer po number if true else false
      /// </summary>
      public bool ShowCustomerPONumber { get; set; } = false;

      /// <summary>
      /// Gets or sets the customer po number
      /// </summary>
      public string CustomerPONumber { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether to show customer project number if true else false
      /// </summary>
      public bool ShowCustomerProjectNumber { get; set; } = false;

      /// <summary>
      /// Gets or sets the customer project number
      /// </summary>
      public string CustomerProjectNumber { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether to show credit job number if true else false
      /// </summary>
      public bool ShowCreditJobNumber { get; set; } = false;

      /// <summary>
      /// Gets or sets the credit job number
      /// </summary>
      public string CreditJobNumber { get; set; }
   }
}
