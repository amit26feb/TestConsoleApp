﻿// <copyright file="DocumentPackageViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
    using System;

   /// <summary>
   /// Document package view model
   /// </summary>
    public class DocumentPackageViewModel
    {
      /// <summary>
      /// Gets or sets DocumentPackageId
      /// </summary>
      public int DocumentPackageId { get; set; }

      /// <summary>
      /// Gets or sets Name
      /// </summary>
      public string Name { get; set; }

      /// <summary>
      /// Gets or sets Description
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets DrAddressId
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets SalesOfficeCode
      /// </summary>
      public string SalesOfficeCode { get; set; }

      /// <summary>
      /// Gets or sets JobId
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets BusinessStreamId
      /// </summary>
      public int BusinessStreamId { get; set; }

      /// <summary>
      /// Gets or sets DocumentTypeId
      /// </summary>
      public int DocumentTypeId { get; set; }

      /// <summary>
      /// Gets or sets DocumentTypeName
      /// </summary>
      public string DocumentTypeName { get; set; }

      /// <summary>
      /// Gets or sets CreatedOn
      /// </summary>
      public DateTime CreatedOn { get; set; }

      /// <summary>
      /// Gets or sets CreatedBy
      /// </summary>
      public string CreatedBy { get; set; }

      /// <summary>
      /// Gets or sets UpdatedOn
      /// </summary>
      public DateTime UpdatedOn { get; set; }

      /// <summary>
      /// Gets or sets UpdatedBy
      /// </summary>
      public string UpdatedBy { get; set; }
   }
}
