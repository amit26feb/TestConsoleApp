﻿// <copyright file="DocumentTypeViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
    using System;

   /// <summary>
   /// View model for document type
   /// </summary>
    public class DocumentTypeViewModel
    {
      /// <summary>
      /// Gets or sets DocumentTypeId
      /// </summary>
      public int DocumentTypeId { get; set; }

      /// <summary>
      /// Gets or sets DocumentType
      /// </summary>
      public string DocumentTypeName { get; set; }

      /// <summary>
      /// Gets or sets DocumentTypeShortName
      /// </summary>
      public string DocumentTypeShortName { get; set; }

      /// <summary>
      /// Gets or sets DocumentGroupId
      /// </summary>
      public int DocumentGroupId { get; set; }

      /// <summary>
      /// Gets or sets DocumentTypeAbstract
      /// </summary>
      public string DocumentTypeAbstract { get; set; }

      /// <summary>
      /// Gets or sets DocumentTypeSequenceNumber
      /// </summary>
      public int DocumentTypeSequenceNumber { get; set; }

      /// <summary>
      /// Gets or sets Status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets CreatedOn
      /// </summary>
      public DateTime CreatedOn { get; set; }

      /// <summary>
      /// Gets or sets CreatedBy
      /// </summary>
      public string CreatedBy { get; set; }

      /// <summary>
      /// Gets or sets UpdatedOn
      /// </summary>
      public DateTime UpdatedOn { get; set; }

      /// <summary>
      /// Gets or sets UpdatedBy
      /// </summary>
      public string UpdatedBy { get; set; }
   }
}
