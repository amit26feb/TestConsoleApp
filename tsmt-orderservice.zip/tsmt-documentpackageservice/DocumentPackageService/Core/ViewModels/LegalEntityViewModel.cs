﻿// <copyright file="LegalEntityViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// View model for legal enitity
   /// </summary>
   public class LegalEntityViewModel
   {
      /// <summary>
      /// Gets or sets LegalEntityId
      /// </summary>
      public int LegalEntityId { get; set; }

      /// <summary>
      /// Gets or sets LegalEntity
      /// </summary>
      public string LegalEntityName { get; set; }

      /// <summary>
      /// Gets or sets ShortName
      /// </summary>
      public string ShortName { get; set; }

      /// <summary>
      /// Gets or sets LongName
      /// </summary>
      public string LongName { get; set; }

      /// <summary>
      /// Gets or sets EntityAbstract
      /// </summary>
      public string EntityAbstract { get; set; }

      /// <summary>
      /// Gets or sets SequenceNumber
      /// </summary>
      public int SequenceNumber { get; set; }
   }
}
