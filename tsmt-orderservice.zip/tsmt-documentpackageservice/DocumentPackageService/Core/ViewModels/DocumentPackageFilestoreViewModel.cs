﻿// <copyright file="DocumentPackageFilestoreViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// Document package filestore properties
   /// </summary>
   public class DocumentPackageFilestoreViewModel
   {
      /// <summary>
      /// Gets or sets the version of the document package file
      /// </summary>
      public int FileVersion { get; set; }

      /// <summary>
      /// Gets or sets the filestore version of the physical file
      /// </summary>
      public string FilestoreVersionId { get; set; }
   }
}
