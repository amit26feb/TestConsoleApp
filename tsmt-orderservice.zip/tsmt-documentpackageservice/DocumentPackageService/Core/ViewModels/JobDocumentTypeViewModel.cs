﻿// <copyright file="JobDocumentTypeViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   using System;

   /// <summary>
   /// View model for job document type
   /// </summary>
   public class JobDocumentTypeViewModel
   {
      /// <summary>
      /// Gets or sets job document type id
      /// </summary>
      public int JobDocumentTypeId { get; set; }

      /// <summary>
      /// Gets or sets document type name
      /// </summary>
      public string TypeName { get; set; }

      /// <summary>
      /// Gets or sets description
      /// </summary>
      public string TypeAbstract { get; set; }

      /// <summary>
      /// Gets or sets sequence number
      /// </summary>
      public int SequenceNumber { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether gets or sets IsAvailableForUser
      /// </summary>
      public bool IsAvailableForUser { get; set; }

      /// <summary>
      /// Gets or sets created on
      /// </summary>
      public DateTime CreatedOn { get; set; }

      /// <summary>
      /// Gets or sets created by
      /// </summary>
      public string CreatedBy { get; set; }

      /// <summary>
      /// Gets or sets updated on
      /// </summary>
      public DateTime UpdatedOn { get; set; }

      /// <summary>
      /// Gets or sets updated by
      /// </summary>
      public string UpdatedBy { get; set; }
   }
}
