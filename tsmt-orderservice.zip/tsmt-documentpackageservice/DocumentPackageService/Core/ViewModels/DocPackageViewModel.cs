﻿// <copyright file="DocPackageViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// Document package view model
   /// </summary>
   public class DocPackageViewModel
   {
      /// <summary>
      /// Gets or sets Document Package
      /// </summary>
      public DocumentPackageViewModel Package { get; set; }

      /// <summary>
      /// Gets or sets DocumentPackageFile
      /// </summary>
      public DocumentPackageFileViewModel PackageFile { get; set; }
   }
}
