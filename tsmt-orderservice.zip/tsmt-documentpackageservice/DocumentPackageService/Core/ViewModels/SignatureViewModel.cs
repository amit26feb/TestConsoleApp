﻿// <copyright file="SignatureViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.ViewModels
{
   /// <summary>
   /// View model for the signature session in the document package
   /// </summary>
    public class SignatureViewModel
    {
      /// <summary>
      /// Gets or sets Sender
      /// </summary>
      public string Sender { get; set; }

      /// <summary>
      /// Gets or sets Title
      /// </summary>
      public string Title { get; set; }

      /// <summary>
      /// Gets or sets CellPhoneNumber
      /// </summary>
      public string CellPhoneNumber { get; set; }

      /// <summary>
      /// Gets or sets FaxNumber
      /// </summary>
      public string FaxNumber { get; set; }

      /// <summary>
      /// Gets or sets EmailAddress
      /// </summary>
      public string EmailAddress { get; set; }

      /// <summary>
      /// Gets or sets OfficeName
      /// </summary>
      public string OfficeName { get; set; }

      /// <summary>
      /// Gets or sets OfficePhoneNumber
      /// </summary>
      public string OfficePhoneNumber { get; set; }

      /// <summary>
      /// Gets or sets AddressLine1
      /// </summary>
      public string AddressLine1 { get; set; }

      /// <summary>
      /// Gets or sets AddressLine2
      /// </summary>
      public string AddressLine2 { get; set; }

      /// <summary>
      /// Gets or sets ZipCode
      /// </summary>
      public string ZipCode { get; set; }

      /// <summary>
      /// Gets or sets City
      /// </summary>
      public string City { get; set; }

      /// <summary>
      /// Gets or sets State
      /// </summary>
      public string State { get; set; }

      /// <summary>
      /// Gets or sets County
      /// </summary>
      public string County { get; set; }

      /// <summary>
      /// Gets or sets Country
      /// </summary>
      public string Country { get; set; }

      /// <summary>
      /// Gets or sets Block Option (ie: standard, customer, both)
      /// </summary>
      public string BlockOption { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether select sender is primary sales person or custom sender
      /// </summary>
      public bool IsCustomSender { get; set; } = false;

      /// <summary>
      /// Gets or sets custom sender nick name
      /// </summary>
      public string CustomSenderNickName { get; set; }
   }
}
