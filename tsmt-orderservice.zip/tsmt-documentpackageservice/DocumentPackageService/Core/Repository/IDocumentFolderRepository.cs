﻿// <copyright file="IDocumentFolderRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
    using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.ViewModels;

   /// <summary>
   /// Interface for document folder repository
   /// </summary>
   public interface IDocumentFolderRepository
   {
      /// <summary>
      /// Create document folder
      /// </summary>
      /// <param name="documentFolder">Document folder model</param>
      /// <returns>If created successfully returns true else false</returns>
      Task<bool> CreateDocumentFolder(DocumentFolderModel documentFolder);

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Validate document folder based on document folder name
      /// </summary>
      /// <param name="documentFolder">Document folder view model</param>
      /// <returns>If document folder name does not exist (valid) returns true else (invalid) returns false</returns>
      Task<bool> ValidateDocumentFolder(DocumentFolderViewModel documentFolder);

      /// <summary>
      /// Get document folders list based on document job id
      /// </summary>
      /// <param name="jobId">Document job id</param>
      /// <returns>List of document folder model</returns>
      Task<IEnumerable<DocumentFolderModel>> GetFolders(int jobId);

      /// <summary>
      /// Check the foldername  based on documentTypeId and jobId
      /// </summary>
      /// <param name="documentTypeId">Document type id</param>
      /// <param name="jobId">Document job id</param>
      /// <returns>If document folder name does not exist (invalid) returns false else (valid) returns true</returns>
      Task<bool> DoesFolderExist(int documentTypeId, int jobId);

      /// <summary>
      /// Get sequence number
      /// </summary>
      /// <param name="tableName">Table name</param>
      /// <returns>Sequence number of the respective table</returns>
      Task<int> GetSequenceNumberAsync(string tableName);
   }
}
