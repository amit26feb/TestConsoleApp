﻿// <copyright file="ILegacyFileRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Repository
{
   using System.Threading.Tasks;

   /// <summary>
   /// Interface for legacy file repository
   /// </summary>
   public interface ILegacyFileRepository
   {
      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Gets the legacy tst db name for the dr address
      /// </summary>
      /// <param name="drAddressId">Dr Address Id</param>
      /// <returns>Legacy file folder prefix</returns>
      public Task<string> GetLegacyTstDbName(int drAddressId);
   }
}
