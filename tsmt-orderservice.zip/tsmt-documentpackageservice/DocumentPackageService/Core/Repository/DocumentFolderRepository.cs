﻿// <copyright file="DocumentFolderRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using DocumentPackageService.Common;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.ViewModels;
   using TSMT.DataAccess;

   /// <summary>
   /// Document folder repository
   /// </summary>
   public class DocumentFolderRepository : IDocumentFolderRepository
   {
      /// <summary>
      /// Document folder repository
      /// </summary>
      private readonly IRepository<DocumentFolderModel> documentFolderRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentFolderRepository"/> class.
      /// </summary>
      /// <param name="documentfolderRepository">Document folder repository</param>
      public DocumentFolderRepository(IRepository<DocumentFolderModel> documentfolderRepository)
      {
         this.documentFolderRepository = documentfolderRepository;
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         // Keep track of it, in case we have the ConnectionFactory generate a new connection in this repository.
         // Tell all IRepository instances about it.
         this.documentFolderRepository.HonorDrAddressId(drAddressId);
      }

      /// <summary>
      /// Create document folder
      /// </summary>
      /// <param name="documentFolder">Document folder model</param>
      /// <returns>If created successfully returns true else false</returns>
      public async Task<bool> CreateDocumentFolder(DocumentFolderModel documentFolder)
      {
         bool result;
         try
         {
            var documentFolderTask = await this.documentFolderRepository.ExecuteAsync<int>(QueryConstants.CreateDocumentFolder, documentFolder);
            result = documentFolderTask > 0;
         }
         catch (Exception e)
         {
            throw new Common.Exceptions.DocumentPackageServiceDomainException(e.Message);
         }

         return result;
      }

      /// <summary>
      /// Validate document folder based on document folder name
      /// </summary>
      /// <param name="documentFolder">Document folder view model</param>
      /// <returns>If document folder name does not exist (valid) returns true else (invalid) returns false</returns>
      public async Task<bool> ValidateDocumentFolder(DocumentFolderViewModel documentFolder)
      {
         if (documentFolder != null && !string.IsNullOrWhiteSpace(documentFolder.FolderName))
         {
            var param = new
            {
               FOLDER_NAME = documentFolder.FolderName.ToLower(),
               JOB_ID = documentFolder.JobId
            };
            IEnumerable<DocumentFolderModel> documentFolderList = await this.documentFolderRepository.ExecuteListQuery<DocumentFolderModel>(QueryConstants.ValidateFolder, param);
            return !documentFolderList.Any(folder => folder.FOLDER_PARENT_ID == documentFolder.FolderParentId);
         }

         return false;
      }

      /// <summary>
      /// Get document folders list based on document job id
      /// </summary>
      /// <param name="jobId">Document job id</param>
      /// <returns>List of document folder model</returns>
      public async Task<IEnumerable<DocumentFolderModel>> GetFolders(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };
         return await this.documentFolderRepository.ExecuteListQuery<DocumentFolderModel>(QueryConstants.GetFolders, param);
      }

      /// <summary>
      /// Check the folder based on documentTypeId and jobId
      /// </summary>
      /// <param name="documentTypeId">Document type id</param>
      /// <param name="jobId">Document job id</param>
      /// <returns>If document folder name does not exist (invalid) returns false else (valid) returns true</returns>
      public async Task<bool> DoesFolderExist(int documentTypeId, int jobId)
      {
         var param = new
         {
            JOB_ID = jobId,
            DOC_TYPE_ID = documentTypeId,
            JOB_FOLDER_TYPE_ID = 2
         };
         int isAvailable = await this.documentFolderRepository.ExecuteQuery<int>(QueryConstants.DoesFolderExist, param);
         return isAvailable > 0;
      }

      /// <summary>
      /// Get sequence number
      /// </summary>
      /// <param name="tableName">Table name</param>
      /// <returns>Sequence number of the respective table</returns>
      public async Task<int> GetSequenceNumberAsync(string tableName)
      {
         var param = new
         {
            TABLENAME = tableName
         };
         var nextValQuery = "SELECT PKG_SEQUENCE_NUMBER.GET_NEXT_SEQUENCE(:TABLENAME, 1) from dual";
         var sequenceNumber = await this.documentFolderRepository.ExecuteQuery<int>(nextValQuery, param);
         return sequenceNumber;
      }
   }
}
