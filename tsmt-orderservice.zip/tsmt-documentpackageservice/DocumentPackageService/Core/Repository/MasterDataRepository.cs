﻿// <copyright file="MasterDataRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Repository
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using DocumentPackageService.Common;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.ViewModels;
   using TSMT.DataAccess;

   /// <summary>
   /// MasterDataRepository
   /// </summary>
   public class MasterDataRepository : IMasterDataRepository
   {
      private readonly IRepository<DocumentGroupModel> masterDataRepository;
      private readonly IMapper mapper;

      /// <summary>
      /// Initializes a new instance of the <see cref="MasterDataRepository"/> class.
      /// </summary>
      /// <param name="mapper">Maps sourcetype and Destination type</param>
      /// <param name="masterDataRepository">masterDataRepository</param>
      public MasterDataRepository(IMapper mapper, IRepository<DocumentGroupModel> masterDataRepository)
      {
         this.mapper = mapper;
         this.masterDataRepository = masterDataRepository;
         this.HonorDrAddressId(-1);
      }

      /// <summary>
      /// Get business stream from database
      /// </summary>
      /// <returns>List of business stream</returns>
      public async Task<IEnumerable<BusinessStreamViewModel>> GetBusinessStreams()
      {
         IEnumerable<BusinessStreamViewModel> result = null;
         IEnumerable<DocumentGroupModel> businessStreams = await this.masterDataRepository.ExecuteListQuery<DocumentGroupModel>(QueryConstants.GetBusinessStreams);
         if (businessStreams != null && businessStreams.Any())
         {
            result = this.mapper.Map<IEnumerable<DocumentGroupModel>, IEnumerable<BusinessStreamViewModel>>(businessStreams);
         }

         return result;
      }

      /// <summary>
      /// Get document type from database
      /// </summary>
      /// <param name="docGroupId">Document group id / business stream id</param>
      /// <returns>List of document type</returns>
      public async Task<IEnumerable<DocumentTypeViewModel>> GetDocumentTypes(int docGroupId)
      {
         IEnumerable<DocumentTypeViewModel> result = null;
         var param = new
         {
            DOC_GROUP_ID = docGroupId
         };
         IEnumerable<DocumentTypeModel> documentTypes = await this.masterDataRepository.ExecuteListQuery<DocumentTypeModel>(QueryConstants.GetDocumentTypes, param);
         if (documentTypes != null && documentTypes.Any())
         {
            result = this.mapper.Map<IEnumerable<DocumentTypeModel>, IEnumerable<DocumentTypeViewModel>>(documentTypes);
         }

         return result;
      }

      /// <summary>
      /// Get legal entity from database
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>List of legal entity</returns>
      public async Task<IEnumerable<LegalEntityViewModel>> GetLegalEntities(int docTypeId)
      {
         IEnumerable<LegalEntityViewModel> result = null;
         var param = new
         {
            DOC_TYPE_ID = docTypeId
         };
         IEnumerable<LegalEntityModel> legalEntities = await this.masterDataRepository.ExecuteListQuery<LegalEntityModel>(QueryConstants.GetLegalEntities, param);
         if (legalEntities != null && legalEntities.Any())
         {
            result = this.mapper.Map<IEnumerable<LegalEntityModel>, IEnumerable<LegalEntityViewModel>>(legalEntities);
         }

         return result;
      }

      /// <summary>
      /// Get terms and conditions from database
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>List of terms and conditions</returns>
      public async Task<IEnumerable<TermsAndConditionsViewModel>> GetTermsAndConditions(int docTypeId)
      {
         IEnumerable<TermsAndConditionsViewModel> result = null;
         var param = new
         {
            DOC_TYPE_ID = docTypeId
         };
         IEnumerable<TermsAndConditionsModel> termsAndConditions = await this.masterDataRepository.ExecuteListQuery<TermsAndConditionsModel>(QueryConstants.GetTermsAndConditions, param);
         if (termsAndConditions != null && termsAndConditions.Any())
         {
            result = this.mapper.Map<IEnumerable<TermsAndConditionsModel>, IEnumerable<TermsAndConditionsViewModel>>(termsAndConditions);
         }

         return result;
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         this.masterDataRepository.HonorDrAddressId(drAddressId);
      }

      /// <summary>
      /// Get job document types from database
      /// </summary>
      /// <returns>List of job document type</returns>
      public async Task<IEnumerable<JobDocumentTypeViewModel>> GetJobDocumentType()
      {
         IEnumerable<JobDocumentTypeViewModel> result = null;
         IEnumerable<JobDocumentTypeModel> jobDocumentTypes = await this.masterDataRepository.ExecuteListQuery<JobDocumentTypeModel>(QueryConstants.GetJobDocumentType);
         if (jobDocumentTypes != null && jobDocumentTypes.Any())
         {
            result = this.mapper.Map<IEnumerable<JobDocumentTypeModel>, IEnumerable<JobDocumentTypeViewModel>>(jobDocumentTypes);
         }

         return result;
      }
   }
}
