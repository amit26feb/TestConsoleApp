﻿// <copyright file="LegacyFileRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Repository
{
   using System.Data;
   using System.Threading.Tasks;
   using Dapper;
   using DataAccess.Core.Abstractions;
   using DocumentPackageService.Common;

   /// <summary>
   /// Class for legacy file repository
   /// </summary>
   public class LegacyFileRepository : ILegacyFileRepository
   {
      /// <summary>
      /// Connection factory
      /// </summary>
      private readonly IConnectionFactory connectionFactory;

      /// <summary>
      /// Dr Address Id
      /// </summary>
      private int? drAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="LegacyFileRepository"/> class.
      /// </summary>
      /// <param name="connectionFactory">Connection Factory<</param>
      public LegacyFileRepository(IConnectionFactory connectionFactory)
      {
         this.connectionFactory = connectionFactory;
      }

      /// <summary>
      /// Gets a database connection.
      /// Pays attention to a specific DrAddressId if we have been told to do so.
      /// </summary>
      private IDbConnection GetConnection
      {
         get
         {
            if (this.drAddressId.HasValue)
            {
               return this.connectionFactory.GetOpenConnectionForDrAddressId(this.drAddressId.Value);
            }
            else
            {
               return this.connectionFactory.GetConnection;
            }
         }
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         // Keep track of it, in case we have the ConnectionFactory generate a new connection in this repository.
         // Tell all IRepository instances about it.
         this.drAddressId = drAddressId;
      }

      /// <summary>
      /// Gets the legacy tst db name for the dr address
      /// </summary>
      /// <param name="drAddressId">Dr Address Id</param>
      /// <returns>Legacy file folder prefix</returns>
      public async Task<string> GetLegacyTstDbName(int drAddressId)
      {
         string result = null;
         using (IDbConnection connection = this.GetConnection)
         {
            var param = new
            {
               DR_ADDRESS_ID = drAddressId
            };
            result = (await connection.ExecuteScalarAsync(QueryConstants.GetLegacyTstDbName, param))?.ToString();
         }

         return result;
      }
   }
}
