﻿// <copyright file="DocumentPackageRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Threading.Tasks;
   using Dapper;
   using DataAccess.Core.Abstractions;
   using DocumentPackageService.Common;
   using DocumentPackageService.Core.Models;
   using Newtonsoft.Json;
   using TSMT.DataAccess;

   /// <summary>
   /// Repository for document package
   /// </summary>
   public class DocumentPackageRepository : IDocumentPackageRepository
   {
      /// <summary>
      /// Connection factory
      /// </summary>
      private readonly IConnectionFactory connectionFactory;

      /// <summary>
      /// Document package repository
      /// </summary>
      private readonly IRepository<DocumentPackageModel> documentPackageRepository;

      private int? drAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageRepository"/> class.
      /// </summary>
      /// <param name="connectionFactory">Get the connection factory</param>
      /// <param name="documentPackageRepository">Document package repository</param>
      public DocumentPackageRepository(IConnectionFactory connectionFactory, IRepository<DocumentPackageModel> documentPackageRepository)
      {
         this.connectionFactory = connectionFactory;
         this.documentPackageRepository = documentPackageRepository;
      }

      /// <summary>
      /// Result sorting order options
      /// </summary>
      private enum ResultSortOrder
      {
         Name,
         Status,
         ModifiedDate
      }

      /// <summary>
      /// Gets a database connection.
      /// Pays attention to a specific DrAddressId if we have been told to do so.
      /// </summary>
      private IDbConnection GetConnection
      {
         get
         {
            if (this.drAddressId.HasValue)
            {
               return this.connectionFactory.GetOpenConnectionForDrAddressId(this.drAddressId.Value);
            }
            else
            {
               return this.connectionFactory.GetConnection;
            }
         }
      }

      /// <summary>
      /// Create document package
      /// </summary>
      /// <param name="documentPackage">DocumentPackageModel</param>
      /// <param name="documentPackageFile">DocumentPackageFileModel</param>
      /// <returns>If created successfully returns true else false</returns>
      public async Task<bool> CreateDocumentPackage(DocumentPackageModel documentPackage, DocumentPackageFileModel documentPackageFile)
      {
         bool result = false;
         using (IDbConnection connection = this.GetConnection)
         {
            using (var transaction = connection.BeginTransaction())
            {
               try
               {
                  await connection.ExecuteAsync(QueryConstants.CreateDocumentPackage, documentPackage, transaction);
                  var documentPackageFileTask = await connection.ExecuteAsync(QueryConstants.CreateDocumentPackageFile, documentPackageFile, transaction);
                  transaction.Commit();
                  result = documentPackageFileTask > 0;
               }
               catch (Exception e)
               {
                  transaction.Rollback();
                  throw new Common.Exceptions.DocumentPackageServiceDomainException(e.Message);
               }
            }
         }

         return result;
      }

      /// <summary>
      /// Update document package and document package file or insert a new document package file against the existing document package
      /// </summary>
      /// <param name="documentPackage">DocumentPackageModel</param>
      /// <param name="documentPackageFile">DocumentPackageFileModel</param>
      /// <param name="newVersion">Indicates whether new document file record has to be created</param>
      /// <returns>If updated successfully returns true else false</returns>
      public async Task<bool> UpsertDocumentPackage(DocumentPackageModel documentPackage, DocumentPackageFileModel documentPackageFile, bool newVersion)
      {
         bool result = false;
         using (IDbConnection connection = this.GetConnection)
         {
            using (var transaction = connection.BeginTransaction())
            {
               try
               {
                  int documentPackageFileResult = 0;
                  await connection.ExecuteAsync(QueryConstants.UpdateDocumentPackage, documentPackage, transaction);
                  if (newVersion)
                  {
                     documentPackageFileResult = await connection.ExecuteAsync(QueryConstants.CreateDocumentPackageFile, documentPackageFile, transaction);
                  }
                  else
                  {
                     documentPackageFileResult = await connection.ExecuteAsync(QueryConstants.UpdateDocumentPackageFile, documentPackageFile, transaction);
                  }

                  transaction.Commit();
                  result = documentPackageFileResult > 0;
               }
               catch (Exception e)
               {
                  transaction.Rollback();
                  throw new Common.Exceptions.DocumentPackageServiceDomainException(e.Message);
               }
            }
         }

         return result;
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateDocumentPackageFileGenerationDetails(int docPkgId, int fileVersion, string status, string generatedByUser, DateTime? generatedByDate)
      {
         var param = new
         {
            DOC_PKG_ID = docPkgId,
            FILE_VERSION = fileVersion,
            STATUS = status,
            GENERATED_DATE = generatedByDate,
            GENERATED_BY_USER = generatedByUser
         };

         bool result;

         try
         {
            int updateResult = await this.documentPackageRepository.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGenerationDetails, param);
            result = updateResult > 0;
         }
         catch (Exception e)
         {
            throw new Common.Exceptions.DocumentPackageServiceDomainException(e.Message);
         }

         return result;
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateDocumentPackageFilename(int docPkgId, int fileVersion, string fileName)
      {
         var param = new
         {
            DOC_PKG_ID = docPkgId,
            FILE_VERSION = fileVersion,
            FILE_NAME = fileName
         };

         bool result;

         try
         {
            int updateResult = await this.documentPackageRepository.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFilename, param);
            result = updateResult > 0;
         }
         catch (Exception e)
         {
            throw new Common.Exceptions.DocumentPackageServiceDomainException(e.Message);
         }

         return result;
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateDocumentPackageFileGeneratedInfo(FileGeneratedModel generatedModel)
      {
         return await this.UpdateDocumentPackageFileGeneratedInfo(
            generatedModel.GetJobId(),
            generatedModel.GetDocPackageId(),
            generatedModel.GetVersion(),
            generatedModel.ReportPath,
            generatedModel.GetGeneratedStatus(),
            new GeneratedInfoModel() { ErrorDescription = generatedModel.GetErrorSummary(), VersionId = generatedModel.VersionId });
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateDocumentPackageFileGeneratedInfo(int jobId, int documentPackageId, int fileVersion, string fileLocation, string status, GeneratedInfoModel generatedInfo)
      {
         var param = new
         {
            JOB_ID = jobId,
            DOC_PKG_ID = documentPackageId,
            FILE_VERSION = fileVersion,
            FILE_LOCATION = fileLocation,
            STATUS = status,
            GENERATED_INFO = JsonConvert.SerializeObject(generatedInfo)
         };

         bool result;

         try
         {
            int updateResult = await this.documentPackageRepository.ExecuteAsync<int>(QueryConstants.UpdateDocumentPackageFileGeneratedInfo, param);
            result = updateResult > 0;
         }
         catch (Exception e)
         {
            throw new Common.Exceptions.DocumentPackageServiceDomainException(e.Message);
         }

         return result;
      }

      /// <summary>
      /// Get sequence number
      /// </summary>
      /// <param name="tableName">Table name</param>
      /// <returns>Sequence number of the respective table</returns>
      public async Task<int> GetSequenceNumberAsync(string tableName)
      {
         var param = new
         {
            TABLENAME = tableName
         };
         var nextValQuery = "SELECT PKG_SEQUENCE_NUMBER.GET_NEXT_SEQUENCE(:TABLENAME, 1) from dual";
         var sequenceNumber = await this.documentPackageRepository.ExecuteQuery<int>(nextValQuery, param);
         return sequenceNumber;
      }

      /// <summary>
      /// Validate document package based on document package name
      /// </summary>
      /// <param name="documentPackageName">Document package name</param>
      /// <param name="jobId">job id</param>
      /// <returns>If document package name does not exist (valid) returns true else (invalid) returns false</returns>
      public async Task<bool> ValidateDocumentPackage(string documentPackageName, int jobId)
      {
         if (!string.IsNullOrWhiteSpace(documentPackageName))
         {
            var param = new
            {
               PKG_NAME = documentPackageName.ToLower(),
               JOB_ID = jobId
            };
            var documentPackageCount = await this.documentPackageRepository.ExecuteQuery<int>(QueryConstants.ValidateDocPackName, param);
            return documentPackageCount == 0;
         }

         return false;
      }

      /// <summary>
      /// Gets the count of the document package file with the generated status for the specified combination
      /// </summary>
      /// <param name="documentPackageFile">Document package file model</param>
      /// <returns>Returns the count of the document package file</returns>
      public async Task<int> GetDocumentPackFileCount(DocumentPackageFileModel documentPackageFile)
      {
         var param = new
         {
            documentPackageFile.DR_ADDRESS_ID,
            documentPackageFile.JOB_ID,
            documentPackageFile.DOC_PKG_ID,
            documentPackageFile.FILE_VERSION,
         };
         return await this.documentPackageRepository.ExecuteQuery<int>(QueryConstants.ValidateDocPackFile, param);
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         // Keep track of it, in case we have the ConnectionFactory generate a new connection in this repository.
         // Tell all IRepository instances about it.
         this.drAddressId = drAddressId;
         this.documentPackageRepository.HonorDrAddressId(drAddressId);
      }

      /// <summary>
      /// Get package details from database
      /// </summary>
      /// <param name="docPkgId">The reference id of the document package</param>
      /// <returns>Document Package Details</returns>
      public async Task<DocPkgDetailsModel> GetDocPkgDetails(int docPkgId)
      {
         var docPkgDetails = await this.documentPackageRepository.ExecuteQuery<DocPkgDetailsModel>(QueryConstants.GetDocPkgDetails, new { docPkgId });
         return docPkgDetails;
      }

      /// <summary>
      /// Get next proposal sequence number based on the document package id
      /// </summary>
      /// <param name="documentPackageId">Document Package Id</param>
      /// <returns>Next proposal sequence number</returns>
      public async Task<int> GetProposalSequence(int documentPackageId)
      {
         var param = new
         {
            DOC_PKG_ID = documentPackageId
         };
         return await this.documentPackageRepository.ExecuteQuery<int>(QueryConstants.GetProposalSequence, param);
      }

      /// <summary>
      /// Get document packages detail from database
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="searchText">Filter the results based on the search keyword</param>
      /// <param name="sortBy">Sort the result based on the keyword</param>
      /// <returns>List of document packages detail</returns>
      public async Task<IEnumerable<DocumentPackageSummaryModel>> GetDocumentPackages(int jobId, string searchText, string sortBy)
      {
         if (string.IsNullOrWhiteSpace(searchText))
         {
            searchText = null;
         }

         if (!string.IsNullOrWhiteSpace(sortBy))
         {
            ResultSortOrder sortvalue = (ResultSortOrder)Enum.Parse(typeof(ResultSortOrder), sortBy);
            if (sortvalue == ResultSortOrder.ModifiedDate)
            {
               sortBy = " ORDER BY SORT_ORDER_STATUS DESC,DP.LAST_MODIFIED_DATE DESC";
            }
            else if (sortvalue == ResultSortOrder.Name)
            {
               sortBy = " ORDER BY NAME ASC,SORT_ORDER_STATUS DESC";
            }
         }
         else
         {
            sortBy = " ORDER BY SORT_ORDER_STATUS DESC,NVL(FILE_GENERATED_DATE,DP.LAST_MODIFIED_DATE) DESC";
         }

         var queryText = QueryConstants.GetDocumentPackageDetails + sortBy;

         var documentpackageDetails = await this.documentPackageRepository.ExecuteListQuery<DocumentPackageSummaryModel>(queryText, new { searchText, jobId });
         return documentpackageDetails;
      }

      /// <inheritdoc/>
      public async Task<DocumentPackageFileStatusModel> GetDocumentFileStatus(int jobId, int documentPackageId, int fileVersion)
      {
         var param = new
         {
            JOB_ID = jobId,
            DOC_PKG_ID = documentPackageId,
            FILE_VERSION = fileVersion
         };
         return await this.documentPackageRepository.ExecuteQuery<DocumentPackageFileStatusModel>(QueryConstants.GetDocumentPackageFileStatus, param);
      }

      /// <inheritdoc/>
      public async Task<DocumentPackageFileDownloadModel> GetDocumentFileDownloadInfo(int jobId, int documentPackageId, int fileVersion)
      {
         var param = new
         {
            JOB_ID = jobId,
            DOC_PKG_ID = documentPackageId,
            FILE_VERSION = fileVersion
         };
         return await this.documentPackageRepository.ExecuteQuery<DocumentPackageFileDownloadModel>(QueryConstants.GetDocumentPackageFileDownloadInfo, param);
      }

      /// <inheritdoc/>
      public async Task<DocumentPackageFileDownloadModel> GetMostRecentDocumentFileDownloadInfo(int jobId, int documentPackageId)
      {
         var param = new
         {
            JOB_ID = jobId,
            DOC_PKG_ID = documentPackageId
         };
         return await this.documentPackageRepository.ExecuteQuery<DocumentPackageFileDownloadModel>(QueryConstants.GetMostRecentDocumentPackageFileDownloadInfo, param);
      }

      /// <inheritdoc/>
      public Task<IEnumerable<DocumentPackageFileHistoryModel>> GetDocumentPackageFileHistories(int jobId, int documentPackageId)
      {
         object param = new
         {
            JOB_ID = jobId,
            DOC_PKG_ID = documentPackageId
         };
         return this.documentPackageRepository.ExecuteListQuery<DocumentPackageFileHistoryModel>(QueryConstants.GetDocumentPackageFileHistories, param);
      }

      /// <summary>
      /// Get a list of document package files
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentTypeId">The reference id of the document type</param>
      /// <returns>Document package files detail list</returns>
      public Task<IEnumerable<DocumentPackageFileModel>> GetPackageDocument(int jobId, int documentTypeId)
      {
         object param = new
         {
            JOB_ID = jobId,
            DOC_TYPE_ID = documentTypeId
         };

         return this.documentPackageRepository.ExecuteListQuery<DocumentPackageFileModel>(QueryConstants.GetPackageDocument, param);
      }
   }
}
