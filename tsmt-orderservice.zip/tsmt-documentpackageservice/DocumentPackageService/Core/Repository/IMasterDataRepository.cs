﻿// <copyright file="IMasterDataRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Repository
{
    using System.Collections.Generic;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.ViewModels;

   /// <summary>
   /// Fetch master data
   /// </summary>
   public interface IMasterDataRepository
    {
      /// <summary>
      /// Gets the list of business stream
      /// </summary>
      /// <returns>List of business stream</returns>
      Task<IEnumerable<BusinessStreamViewModel>> GetBusinessStreams();

      /// <summary>
      /// Gets the list of document type
      /// </summary>
      /// <param name="docGroupId">Document group id / business stream id</param>
      /// <returns>List of document type</returns>
      Task<IEnumerable<DocumentTypeViewModel>> GetDocumentTypes(int docGroupId);

      /// <summary>
      /// Gets the list of legal entity
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>List of legal entity</returns>
      Task<IEnumerable<LegalEntityViewModel>> GetLegalEntities(int docTypeId);

      /// <summary>
      /// Gets the list of terms and conditions
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>List of terms and conditions</returns>
      Task<IEnumerable<TermsAndConditionsViewModel>> GetTermsAndConditions(int docTypeId);

      /// <summary>
      /// Gets the list of job document type
      /// </summary>
      /// <returns>List of job document type</returns>
      Task<IEnumerable<JobDocumentTypeViewModel>> GetJobDocumentType();
   }
}
