﻿// <copyright file="LegacyFileService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Threading.Tasks;
   using Amazon.S3.Model;
   using global::DocumentPackageService.Core.Repository;
   using global::DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Options;
   using S3Wrapper;
   using TSMT.Settings;

   /// <summary>
   /// Legacy file service
   /// </summary>
   public class LegacyFileService : ILegacyFileService
   {
      private readonly IS3Repository s3repo;
      private readonly IOptions<TSMTSettings> appSettings;
      private readonly ILegacyFileRepository legacyFileRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="LegacyFileService"/> class.
      /// </summary>
      /// <param name="contextAccessor">Context Accessor</param>
      /// <param name="s3repo">S3 repository for getting doc files</param>
      /// <param name="appSettings">App settings to support S3 gets</param>
      /// <param name="legacyFileRepository">Legacy file repository</param>
      public LegacyFileService(
         IHttpContextAccessor contextAccessor,
         IS3Repository s3repo,
         IOptions<TSMTSettings> appSettings,
         ILegacyFileRepository legacyFileRepository)
      {
         this.s3repo = s3repo;
         this.appSettings = appSettings;
         this.legacyFileRepository = legacyFileRepository;

         // The DrAddressId to honor is stored in the HttpContext.
         if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
             contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.legacyFileRepository.HonorDrAddressId(drAddressIdToHonor);
         }
      }

      /// <summary>
      /// Get legacy files
      /// </summary>
      /// <param name="drAddressId">dr Address Id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Returns a list of legacy files</returns>
      public async Task<IEnumerable<LegacyFileViewModel>> GetLegacyFiles(int drAddressId, int jobId)
      {
         List<LegacyFileViewModel> filesToReturn = new List<LegacyFileViewModel>();

         string legacyTstDbName = await this.legacyFileRepository.GetLegacyTstDbName(drAddressId);
         if (!string.IsNullOrWhiteSpace(legacyTstDbName))
         {
            string legacyPrefix = legacyTstDbName.Split('_').Last().ToLower();
            string possibleFilesLocation = $"jobs-legacy-files/{legacyPrefix}/{drAddressId}/{jobId}";

            // Get a list of objects where we would expect them to be.
            ListVersionsResponse objs = await this.s3repo.ListVersionsAsync(this.appSettings.Value.JobsBucket, possibleFilesLocation);

            // Iterate the latest version objects.
            foreach (S3ObjectVersion s3Object in objs.Versions.Where(v => v.IsLatest && !v.IsDeleteMarker))
            {
               // Legacy Job Center files live in a Attachments folder (we don't need to advertise that).
               string relativeDirectoryAndFilename = s3Object.Key.Replace($"{possibleFilesLocation}/Attachments/", string.Empty);

               // Legacy LDG files live in the root.
               relativeDirectoryAndFilename = relativeDirectoryAndFilename.Replace($"{possibleFilesLocation}/", string.Empty);

               string fileExtension = Path.GetExtension(relativeDirectoryAndFilename);

               // We should only support files with extensions (s3 folders also get picked up in the S3 object versioning).
               if (!string.IsNullOrWhiteSpace(fileExtension))
               {
                  string[] directoryAndFileParts = relativeDirectoryAndFilename.Split("/");

                  // Lets see if we have a legacy LDG file here.
                  // Logic dictates that Legacy LDG files appear in a numbered subdirectory (1, 2, 3, etc).
                  // Otherwise it is Legacy Job Center file.
                  bool isLegacyLdgFile = false;

                  // Do we have a numbered subdirectory?
                  if (directoryAndFileParts.Length > 1 && int.TryParse(directoryAndFileParts[0], out int directoryVersion))
                  {
                     // If so, then you're an LDG file -- come on down!
                     isLegacyLdgFile = true;
                  }

                  // If we're not a legacy LDG file, then we're a legacy Job Center file.
                  bool isLegacyJobCenterFile = !isLegacyLdgFile;

                  // Add to collection to return.
                  filesToReturn.Add(new LegacyFileViewModel()
                  {
                     IsLegacyLdgFile = isLegacyLdgFile,
                     IsLegacyJobCenterFile = isLegacyJobCenterFile,
                     FileName = Path.GetFileName(s3Object.Key),
                     RelativeDirectoryAndFileName = relativeDirectoryAndFilename,
                     FullPathToFile = s3Object.Key,
                     LastModifiedDate = s3Object.LastModified,
                     VersionId = s3Object.VersionId
                  });
               }
            }
         }

         return filesToReturn;
      }
   }
}
