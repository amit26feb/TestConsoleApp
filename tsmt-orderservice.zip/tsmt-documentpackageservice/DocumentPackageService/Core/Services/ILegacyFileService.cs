﻿// <copyright file="ILegacyFileService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using global::DocumentPackageService.Core.ViewModels;

   /// <summary>
   /// Interface for document package service
   /// </summary>
   public interface ILegacyFileService
   {
      /// <summary>
      /// Get legacy files
      /// </summary>
      /// <param name="drAddressId">dr Address Id</param>
      /// <param name="jobId">Job id</param>
      /// <returns>Returns a list of legacy files</returns>
      Task<IEnumerable<LegacyFileViewModel>> GetLegacyFiles(int drAddressId, int jobId);
   }
}
