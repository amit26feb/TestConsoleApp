﻿// <copyright file="FileGeneratedBackgroundService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using AWS.MessagingWrapper.Contracts;
   using global::DocumentPackageService.Core.Models;
   using Microsoft.Extensions.Hosting;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Newtonsoft.Json;
   using Newtonsoft.Json.Linq;
   using TSMT.Settings;

   /// <summary>
   /// Hosted service intended to run in the background and monitor the
   /// "TSMT-ReportGenerated" queue.
   /// </summary>
   public class FileGeneratedBackgroundService : BackgroundService
   {
      private readonly ILogger<FileGeneratedBackgroundService> logger;
      private readonly IMessageReceiver messageReceiver;
      private readonly IOptions<TSMTSettings> appSettings;
      private readonly IDocumentPackageService docPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="FileGeneratedBackgroundService"/> class.
      /// </summary>
      /// <param name="logger">Logger for error messages</param>
      /// <param name="messageReceiver">Message receiver we are handling messages from</param>
      /// <param name="appSettings">App settings for message receiver properties</param>
      /// <param name="docPackageService">Document package service for updating doc package files from messages</param>
      public FileGeneratedBackgroundService(
         ILogger<FileGeneratedBackgroundService> logger,
         IMessageReceiver messageReceiver,
         IOptions<TSMTSettings> appSettings,
         IDocumentPackageService docPackageService)
      {
         this.logger = logger;
         this.messageReceiver = messageReceiver;
         this.appSettings = appSettings;
         this.docPackageService = docPackageService;
      }

      /// <summary>
      /// Executes the backround service
      /// </summary>
      /// <param name="stoppingToken">token for cancelling execution</param>
      /// <returns>Task representing completion</returns>
      protected async override Task ExecuteAsync(CancellationToken stoppingToken)
      {
         this.logger.LogTrace("FileGeneratedBackgroundService is starting.");
         while (!stoppingToken.IsCancellationRequested)
         {
            try
            {
               IEnumerable<Message> workItems = await this.messageReceiver.ReceiveMessageAsync(
                  this.appSettings.Value.SqsServiceUrl,
                  stoppingToken,
                  this.appSettings.Value.MaxNoOfMessages,
                  this.appSettings.Value.QueueWaitTimeInSeconds,
                  this.appSettings.Value.MessageHidingTimeInMinutes);

               foreach (Message message in workItems)
               {
                  await this.HandleMessage(message);
               }
            }
            catch (Exception ex)
            {
               this.logger.LogError(ex, "Error occurred executing FileGeneratedBackgroundService: " + this.appSettings.Value.SqsServiceUrl);
            }
         }

         this.logger.LogTrace("FileGeneratedBackgroundService is stopping.");
      }

      private async Task HandleMessage(Message message)
      {
         try
         {
            JObject responseData = JsonConvert.DeserializeObject<JObject>(message.Body);
            FileGeneratedModel generatedModel = JsonConvert.DeserializeObject<FileGeneratedModel>(responseData["Message"].ToString());
            try
            {
               string result = await this.docPackageService.UpdateDocumentPackageFileGeneratedInfo(generatedModel);
               if (string.IsNullOrWhiteSpace(result))
               {
                  this.logger.LogInformation("Updated document package file generated info successfully.");
               }
               else
               {
                  this.logger.LogWarning("Could not update document package file generated info.", new { result });
               }
            }
            catch (Exception ex)
            {
               this.logger.LogError(ex, "Error updating document package file generated info");
            }
         }
         catch (Exception ex)
         {
            this.logger.LogError(ex, "Error processing message in FileGeneratedBackgroundService");
         }
         finally
         {
            try
            {
               await this.messageReceiver.DeleteMessageAsync(this.appSettings.Value.SqsServiceUrl, message.ReceiptHandle);
            }
            catch (Exception ex)
            {
               this.logger.LogError(ex, "Error deleting message in FileGeneratedBackgroundService");
            }
         }
      }
   }
}
