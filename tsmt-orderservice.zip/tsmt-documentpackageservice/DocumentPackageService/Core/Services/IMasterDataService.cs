﻿// <copyright file="IMasterDataService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using global::DocumentPackageService.Core.ViewModels;

   /// <summary>
   /// IDocumentPackageService
   /// </summary>
   public interface IMasterDataService
   {
      /// <summary>
      /// Gets the BusinessStreamViewModel
      /// </summary>
      /// <returns>BusinessStreamViewModel</returns>
      Task<IEnumerable<BusinessStreamViewModel>> GetBusinessStreams();

      /// <summary>
      /// Gets the DocumentTypeViewModel
      /// </summary>
      /// <param name="docGroupId">Document group id / business stream id</param>
      /// <returns>DocumentTypeViewModel</returns>
      Task<IEnumerable<DocumentTypeViewModel>> GetDocumentTypes(int docGroupId);

      /// <summary>
      /// Gets the LegalEntityViewModel
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>LegalEntityViewModel</returns>
      Task<IEnumerable<LegalEntityViewModel>> GetLegalEntities(int docTypeId);

      /// <summary>
      /// Gets the TermsAndConditionsViewModel
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>Terms And Conditions list</returns>
      Task<IEnumerable<TermsAndConditionsViewModel>> GetTermsAndConditions(int docTypeId);

      /// <summary>
      /// Gets the JobDocumentTypeViewModel list
      /// </summary>
      /// <returns>JobDocumentTypeViewModel list</returns>
      Task<IEnumerable<JobDocumentTypeViewModel>> GetJobDocumentType();
   }
}
