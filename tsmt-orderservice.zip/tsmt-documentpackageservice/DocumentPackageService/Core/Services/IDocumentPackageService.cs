﻿// <copyright file="IDocumentPackageService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System.Collections.Generic;
   using System.IO;
   using System.Threading.Tasks;
   using global::DocumentPackageService.Core.Models;
   using global::DocumentPackageService.Core.ViewModels;

   /// <summary>
   /// Interface for document package service
   /// </summary>
   public interface IDocumentPackageService
   {
      /// <summary>
      /// Create new document package
      /// </summary>
      /// <param name="documentPackage">Document package view model</param>
      /// <returns>Returns the create document package view model</returns>
      Task<DocPackageViewModel> CreateDocumentPackage(DocPackageViewModel documentPackage);

      /// <summary>
      /// Update existing document package
      /// </summary>
      /// <param name="documentPackage">CreateDocumentPackageViewModel</param>
      /// <returns>Returns the create document package view model</returns>
      Task<DocPackageViewModel> UpdateDocumentPackage(DocPackageViewModel documentPackage);

      /// <summary>
      /// Update existing document package
      /// </summary>
      /// <param name="documentPackage">CreateDocumentPackageViewModel</param>
      /// <param name="isFromClonedPackage">Whether or not this is updating from a cloned package (we should reset some things about it, like proposal number)</param>
      /// <returns>Returns the create document package view model</returns>
      Task<DocPackageViewModel> UpdateDocumentPackage(DocPackageViewModel documentPackage, bool isFromClonedPackage);

      /// <summary>
      /// Update existing document package file status
      /// </summary>
      /// <param name="docPkgId">Reference id of the document package</param>
      /// <param name="fileVersion">File version to update</param>
      /// <param name="status">Status we are updating to</param>
      /// <returns>Boolean indicating updated or not</returns>
      Task<bool> UpdateDocumentPackageFileStatus(int docPkgId, int fileVersion, string status);

      /// <summary>
      /// Update existing document package filename
      /// </summary>
      /// <param name="docPkgId">Reference id of the document package</param>
      /// <param name="fileVersion">File version to update</param>
      /// <param name="filename">Filename we are updating to</param>
      /// <returns>Boolean indicating updated or not</returns>
      Task<bool> UpdateDocumentPackageFilename(int docPkgId, int fileVersion, string filename);

      /// <summary>
      /// Update a document package file using a file updated model
      /// </summary>
      /// <param name="generatedModel">File generated model containing info about doc package file generation</param>
      /// <returns>String including validation issue description.  Empty string means document package file was updated.</returns>
      Task<string> UpdateDocumentPackageFileGeneratedInfo(FileGeneratedModel generatedModel);

      /// <summary>
      /// Get sales office selector
      /// </summary>
      /// <returns>IEnumerable of OfficeSelector</returns>
      Task<IEnumerable<TraneSalesTools.SalesOfficeView>> GetOfficeSelector();

      /// <summary>
      /// Get Document Package Details
      /// </summary>
      /// <param name="docPkgId">The reference id of the document package</param>
      /// <returns>Document Package details</returns>
      Task<DocPkgDetailsViewModel> GetDocPkgDetails(int docPkgId);

      /// <summary>
      /// Get document package file history data
      /// </summary>
      /// <param name="jobId">Job identifier</param>
      /// <param name="documentPackageId">Document package identifier</param>
      /// <returns>Enumeration of file history data</returns>
      Task<IEnumerable<DocumentPackageFileHistoryViewModel>> GetDocumentPackageFileHistories(int jobId, int documentPackageId);

      /// <summary>
      /// Get the most recent generated file history data.
      /// </summary>
      /// <param name="jobId">Job identifier</param>
      /// <param name="documentPackageId">Document package identifier</param>
      /// <returns>Completed generated file history data</returns>
      Task<DocumentPackageMostRecentFileHistoryViewModel> GetMostRecentlyGeneratedDocumentPackageFileHistory(int jobId, int documentPackageId);

      /// <summary>
      /// Get document packages
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="searchtext">The search keywork related to document package</param>
      /// <param name="sortby">The sort order of the result set</param>
      /// <returns>Document packages list</returns>
      Task<IEnumerable<DocumentPackageSummaryViewModel>> GetDocumentPackages(int jobId, string searchtext, string sortby);

      /// <summary>
      /// Get the status for a document package file version
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="documentPackageId">Document package id</param>
      /// <param name="fileVersion">File version</param>
      /// <returns>Status and generated date of document package file</returns>
      Task<DocumentPackageFileStatusModel> GetDocumentFileStatus(int jobId, int documentPackageId, int fileVersion);

      /// <summary>
      /// Gets a document package file name and stream
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="documentPackageId">Document package id</param>
      /// <param name="fileVersion">File version (if not provided, assumed most recent file version)</param>
      /// <returns>File name and stream</returns>
      Task<KeyValuePair<string, Stream>?> GetDocumentFileStream(int jobId, int documentPackageId, int? fileVersion);

      /// <summary>
      /// Sets filestore version id on the document package file.
      /// </summary>
      /// <param name="documentPackageId">Document package id</param>
      /// <param name="filestoreVersionId">Document filestore version id</param>
      /// <returns>If successful, Doc Package version and Filestore version</returns>
      Task<DocumentPackageFilestoreViewModel> UpdateFilestoreVersionId(int documentPackageId, string filestoreVersionId);

      /// <summary>
      /// Get a list of document package files
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentTypeId">The reference id of the document type</param>
      /// <returns>Document package files detail list</returns>
      Task<IEnumerable<DocumentPackageFileViewModel>> GetPackageDocument(int jobId, int documentTypeId);
   }
}
