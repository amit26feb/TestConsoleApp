﻿// <copyright file="IDocumentFolderService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using global::DocumentPackageService.Core.ViewModels;

   /// <summary>
   /// Interface for document folder service
   /// </summary>
   public interface IDocumentFolderService
   {
      /// <summary>
      /// Create new document folder
      /// </summary>
      /// <param name="documentFolder">Document folder view model</param>
      /// <returns>Returns document folders list</returns>
      Task<IEnumerable<DocumentFolderViewModel>> CreateDocumentFolder(DocumentFolderViewModel documentFolder);

      /// <summary>
      /// Get document folders list based on document job id
      /// </summary>
      /// <param name="jobId">Document job id</param>
      /// <returns>List of document folder model</returns>
      Task<IEnumerable<DocumentFolderViewModel>> GetFolders(int jobId);
   }
}
