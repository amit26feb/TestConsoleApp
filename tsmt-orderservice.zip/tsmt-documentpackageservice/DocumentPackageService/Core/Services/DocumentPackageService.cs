﻿// <copyright file="DocumentPackageService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Threading.Tasks;
   using Amazon.S3.Model;
   using AutoMapper;
   using global::DocumentPackageService.Configurations;
   using global::DocumentPackageService.Core.Models;
   using global::DocumentPackageService.Core.Repository;
   using global::DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Options;
   using S3Wrapper;
   using TraneSalesTools;
   using TSMT.Settings;

   /// <summary>
   /// Document package service
   /// </summary>
   public class DocumentPackageService : IDocumentPackageService
   {
      private const int DocumentTypeProposalId = 5;
      private readonly IDocumentPackageRepository documentPackageRepository;
      private readonly IMapper mapper;
      private readonly IWebHostEnvironment hostingEnvironment;
      private readonly ISalesOfficeService tstCommonSalesOfficeService;
      private readonly IS3Repository s3repo;
      private readonly IOptions<TSMTSettings> appSettings;
      private readonly IDocumentFolderRepository documentFolderRepository;

      /// <summary>
      /// http Context Accessor
      /// </summary>
      private readonly IHttpContextAccessor contextAccessor;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageService"/> class.
      /// </summary>
      /// <param name="documentPackageRepository">Document package repository</param>
      /// <param name="mapper">Mapper</param>
      /// <param name="contextAccessor">Context accessor</param>
      /// <param name="hostingEnvironment">Hosting Environment</param>
      /// <param name="tstCommonSalesOfficeService">Trane sales common salesoffice service</param>
      /// <param name="s3repo">S3 repository for getting doc files</param>
      /// <param name="appSettings">App settings to support S3 gets</param>
      /// <param name="documentFolderRepository">document folder repository</param>
      public DocumentPackageService(
         IDocumentPackageRepository documentPackageRepository,
         IMapper mapper,
         IHttpContextAccessor contextAccessor,
         IWebHostEnvironment hostingEnvironment,
         ISalesOfficeService tstCommonSalesOfficeService,
         IS3Repository s3repo,
         IOptions<TSMTSettings> appSettings,
         IDocumentFolderRepository documentFolderRepository)
      {
         this.documentPackageRepository = documentPackageRepository;
         this.mapper = mapper;
         this.contextAccessor = contextAccessor;
         this.hostingEnvironment = hostingEnvironment;
         this.tstCommonSalesOfficeService = tstCommonSalesOfficeService;
         this.s3repo = s3repo;
         this.appSettings = appSettings;
         this.documentFolderRepository = documentFolderRepository;

         // The DrAddressId to honor is stored in the HttpContext.
         if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
             contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.documentPackageRepository.HonorDrAddressId(drAddressIdToHonor);
            this.documentFolderRepository.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.documentPackageRepository.HonorDrAddressId(null);
            this.documentFolderRepository.HonorDrAddressId(null);
         }
      }

      /// <summary>
      /// Create new document package
      /// </summary>
      /// <param name="documentPackage">DocPackageViewModel</param>
      /// <returns>Returns the create document package view model</returns>
      public async Task<DocPackageViewModel> CreateDocumentPackage(DocPackageViewModel documentPackage)
      {
         await this.CheckAndCreateJobFolder(documentPackage);
         int documentPackageId = await this.documentPackageRepository.GetSequenceNumberAsync("DG_DOC_PACKAGE");
         if (documentPackageId != 0)
         {
            string userId = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
            DocumentPackageModel documentPackageEntity = this.mapper.Map<DocumentPackageViewModel, DocumentPackageModel>(documentPackage.Package);
            documentPackageEntity.DOC_PKG_ID = documentPackageId;
            documentPackageEntity.CREATED_BY_USER = userId;
            documentPackageEntity.LAST_MODIFIED_USER = userId;
            DocumentPackageFileModel documentPackageFileEntity = this.mapper.Map<DocumentPackageFileViewModel, DocumentPackageFileModel>(documentPackage.PackageFile);
            documentPackageFileEntity.DOC_PKG_ID = documentPackageId;
            documentPackageFileEntity.GENERATED_BY_USER = userId;
            documentPackageFileEntity.FILE_VERSION = 1;
            documentPackageFileEntity.STATUS = GeneratedStatusOptions.NotGenerated;

            documentPackageFileEntity.PROPOSAL_NBR = documentPackage.Package.DocumentTypeId == DocumentTypeProposalId ?
               this.GetProposalNumber(documentPackage.Package.SalesOfficeCode, documentPackage.Package.JobId, documentPackageId) : null;

            documentPackageFileEntity.LAST_MODIFIED_USER = userId;
            var response = await this.documentPackageRepository.CreateDocumentPackage(documentPackageEntity, documentPackageFileEntity);

            if (response)
            {
               return new DocPackageViewModel
               {
                  Package = this.mapper.Map<DocumentPackageModel, DocumentPackageViewModel>(documentPackageEntity),
                  PackageFile = this.mapper.Map<DocumentPackageFileModel, DocumentPackageFileViewModel>(documentPackageFileEntity)
               };
            }
         }

         return null;
      }

      /// <summary>
      /// Update existing document package
      /// </summary>
      /// <param name="documentPackage">CreateDocumentPackageViewModel</param>
      /// <returns>Returns the create document package view model</returns>
      public async Task<DocPackageViewModel> UpdateDocumentPackage(DocPackageViewModel documentPackage)
      {
         return await this.UpdateDocumentPackage(documentPackage, false);
      }

      /// <summary>
      /// Update existing document package
      /// </summary>
      /// <param name="documentPackage">CreateDocumentPackageViewModel</param>
      /// <param name="isFromClonedPackage">Whether or not this is updating from a cloned package (we should reset some things about it, like proposal number)</param>
      /// <returns>Returns the create document package view model</returns>
      public async Task<DocPackageViewModel> UpdateDocumentPackage(DocPackageViewModel documentPackage, bool isFromClonedPackage)
      {
         bool createNewVersion = false;
         string userId = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
         DocumentPackageModel documentPackageEntity = this.mapper.Map<DocumentPackageViewModel, DocumentPackageModel>(documentPackage.Package);
         documentPackageEntity.LAST_MODIFIED_USER = userId;
         DocumentPackageFileModel documentPackageFileEntity = this.mapper.Map<DocumentPackageFileViewModel, DocumentPackageFileModel>(documentPackage.PackageFile);
         if (this.documentPackageRepository.GetDocumentPackFileCount(documentPackageFileEntity).Result > 0)
         {
            documentPackageFileEntity.FILE_VERSION += 1;
            if (documentPackage.Package.DocumentTypeId == DocumentTypeProposalId && !isFromClonedPackage)
            {
               int nextProposalSequence = await this.documentPackageRepository.GetProposalSequence(documentPackage.Package.DocumentPackageId);
               documentPackageFileEntity.PROPOSAL_NBR = this.GetProposalNumber(documentPackage.Package.SalesOfficeCode, documentPackage.Package.JobId, documentPackage.Package.DocumentPackageId, nextProposalSequence);
            }
            else
            {
               documentPackageFileEntity.PROPOSAL_NBR = null;
            }

            documentPackageFileEntity.LAST_MODIFIED_USER = userId;
            documentPackageFileEntity.STATUS = GeneratedStatusOptions.NotGenerated;
            createNewVersion = true;
         }

         documentPackageFileEntity.LAST_MODIFIED_USER = userId;
         var response = await this.documentPackageRepository.UpsertDocumentPackage(documentPackageEntity, documentPackageFileEntity, createNewVersion);

         if (response)
         {
            return new DocPackageViewModel
            {
               Package = this.mapper.Map<DocumentPackageModel, DocumentPackageViewModel>(documentPackageEntity),
               PackageFile = this.mapper.Map<DocumentPackageFileModel, DocumentPackageFileViewModel>(documentPackageFileEntity)
            };
         }

         return null;
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateDocumentPackageFileStatus(int docPkgId, int fileVersion, string status)
      {
         string userId = this.contextAccessor?.HttpContext?.User?.Claims?.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();

         if (string.IsNullOrWhiteSpace(userId))
         {
            return false;
         }
         else
         {
            // If we're "Uploaded" status, we should null out the generation user and generation date (they no longer make sense).
            bool isUploadedStatus = status.ToLower().Equals("uploaded");
            DateTime? generatedByDate = isUploadedStatus ? (DateTime?)null : DateTime.UtcNow;
            userId = isUploadedStatus ? null : userId;

            return await this.documentPackageRepository.UpdateDocumentPackageFileGenerationDetails(docPkgId, fileVersion, status, userId, generatedByDate);
         }
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateDocumentPackageFilename(int docPkgId, int fileVersion, string filename)
      {
         return await this.documentPackageRepository.UpdateDocumentPackageFilename(docPkgId, fileVersion, filename);
      }

      /// <inheritdoc/>
      public async Task<string> UpdateDocumentPackageFileGeneratedInfo(FileGeneratedModel generatedModel)
      {
         if (generatedModel != null)
         {
            int drAddressId = generatedModel.GetDrAddressId();
            if (drAddressId > 0)
            {
               this.documentPackageRepository.HonorDrAddressId(drAddressId);
               if (generatedModel.IsRequestValid())
               {
                  bool result = await this.documentPackageRepository.UpdateDocumentPackageFileGeneratedInfo(generatedModel);
                  return result ? string.Empty : "Did not update document package file generation info.";
               }
               else
               {
                  return $"Invalid document package update model: {generatedModel.GetDrAddressId()} {generatedModel.GetJobId()} {generatedModel.GetDocPackageId()} {generatedModel.GetVersion()}";
               }
            }
            else
            {
               return "Invalid drAddressId";
            }
         }
         else
         {
            return "FileGeneratedModel is null";
         }
      }

      /// <summary>
      /// Service method to get the OfficeSelector values
      /// </summary>
      /// <returns>List of Office Selectors</returns>
      public async Task<IEnumerable<TraneSalesTools.SalesOfficeView>> GetOfficeSelector()
      {
         var envName = this.hostingEnvironment.DomainGroupEnvironmentName();
         string userId = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
         var domainList = this.contextAccessor.HttpContext.User.Claims.Where(c => c.Type == "Groups").Select(v => v.Value.ToUpper()).ToList();

         // Gets the list of sales office from Trane sales tools commmon
         return await this.tstCommonSalesOfficeService.GetSalesOffice(userId, domainList, envName);
      }

      /// <summary>
      /// Get Document Package Details
      /// </summary>
      /// <param name="docPkgId">The reference id of the document package</param>
      /// <returns>Document Package details</returns>
      public async Task<DocPkgDetailsViewModel> GetDocPkgDetails(int docPkgId)
      {
         var documentPackageDetails = await this.documentPackageRepository.GetDocPkgDetails(docPkgId);
         if (documentPackageDetails != null)
         {
            DocPkgDetailsViewModel docPkgDetails = this.mapper.Map<DocPkgDetailsModel, DocPkgDetailsViewModel>(documentPackageDetails);
            docPkgDetails.DocPkgFileDetails = this.mapper.Map<DocPkgDetailsModel, DocPkgFileViewModel>(documentPackageDetails);
            return docPkgDetails;
         }
         else
         {
            return null;
         }
      }

      /// <summary>
      /// Get document packages list
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="searchtext">The search keywork related to document package</param>
      /// <param name="sortby">The sort order of the result set</param>
      /// <returns>Document packages detail list</returns>
      public async Task<IEnumerable<DocumentPackageSummaryViewModel>> GetDocumentPackages(int jobId, string searchtext, string sortby)
      {
         var documentPackageDetails = await this.documentPackageRepository.GetDocumentPackages(jobId, searchtext, sortby);
         IEnumerable<DocumentPackageSummaryViewModel> documentPackageList = this.mapper.Map<IEnumerable<DocumentPackageSummaryModel>, IEnumerable<DocumentPackageSummaryViewModel>>(documentPackageDetails);
         return documentPackageList.Any() ? documentPackageList : null;
      }

      /// <inheritdoc/>
      public Task<DocumentPackageFileStatusModel> GetDocumentFileStatus(int jobId, int documentPackageId, int fileVersion)
      {
         return this.documentPackageRepository.GetDocumentFileStatus(jobId, documentPackageId, fileVersion);
      }

      /// <inheritdoc/>
      public async Task<KeyValuePair<string, Stream>?> GetDocumentFileStream(int jobId, int documentPackageId, int? fileVersion)
      {
         DocumentPackageFileDownloadModel downloadInfo = null;
         if (fileVersion.HasValue)
         {
            downloadInfo = await this.documentPackageRepository.GetDocumentFileDownloadInfo(jobId, documentPackageId, fileVersion.Value);
         }
         else
         {
            downloadInfo = await this.documentPackageRepository.GetMostRecentDocumentFileDownloadInfo(jobId, documentPackageId);
         }

         if (downloadInfo != null && !string.IsNullOrEmpty(downloadInfo.Name) && !string.IsNullOrEmpty(downloadInfo.Location))
         {
            string versionId = downloadInfo.GetVersionId();
            if (string.IsNullOrWhiteSpace(versionId))
            {
               // ListVersions will return our file and the input file.  We need to just get versions on our file.
               // This fallback can be removed *some time* in the future...
               // It should only be called based on dev/test data (downloadInfo.GetVersionId() should only be empty in dev/test)
               ListVersionsResponse response = await this.s3repo.ListVersionsAsync(this.appSettings.Value.Bucket, downloadInfo.Location);
               S3ObjectVersion version = response?.Versions?.Where(v => v.Key == downloadInfo.Location)
                  .OrderBy(v => v.LastModified).Skip(downloadInfo.VersionId - 1).FirstOrDefault();
               versionId = version?.VersionId;
            }

            if (versionId != null)
            {
               GetObjectResponse resp = await this.s3repo.GetObjectAsync(this.appSettings.Value.Bucket, downloadInfo.Location, versionId);
               if (resp != null && resp.ResponseStream != null)
               {
                  return new KeyValuePair<string, Stream>(downloadInfo.GetNameWithExtension(), resp.ResponseStream);
               }
            }
         }

         return null;
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<DocumentPackageFileHistoryViewModel>> GetDocumentPackageFileHistories(int jobId, int documentPackageId)
      {
         IEnumerable<DocumentPackageFileHistoryModel> histories = await this.documentPackageRepository.GetDocumentPackageFileHistories(jobId, documentPackageId);
         IEnumerable<DocumentPackageFileHistoryViewModel> historyVMs = this.mapper.Map<IEnumerable<DocumentPackageFileHistoryModel>, IEnumerable<DocumentPackageFileHistoryViewModel>>(histories);
         return historyVMs?.Any() == true ? historyVMs : Enumerable.Empty<DocumentPackageFileHistoryViewModel>();
      }

      /// <inheritdoc/>
      public async Task<DocumentPackageMostRecentFileHistoryViewModel> GetMostRecentlyGeneratedDocumentPackageFileHistory(int jobId, int documentPackageId)
      {
         List<DocumentPackageFileHistoryModel> completedHistories = (await this.documentPackageRepository.GetDocumentPackageFileHistories(jobId, documentPackageId))
            .Where(h => h.GENERATED_DATE.HasValue && h.STATUS.ToLower().Equals("complete"))
            .OrderByDescending(h => h.GENERATED_DATE)
            .ToList();
         if (completedHistories?.Any() == true)
         {
            return new DocumentPackageMostRecentFileHistoryViewModel()
            {
               FileName = completedHistories.First().FILE_NAME,
               FileVersion = completedHistories.First().FILE_VERSION,
               TotalGeneratedVersions = completedHistories.Count()
            };
         }

         return null;
      }

      /// <inheritdoc/>
      public async Task<DocumentPackageFilestoreViewModel> UpdateFilestoreVersionId(int documentPackageId, string filestoreVersionId)
      {
         // Get existing document package details.
         DocPkgDetailsModel existingPackageDetails = await this.documentPackageRepository.GetDocPkgDetails(documentPackageId);
         if (existingPackageDetails != null)
         {
            // Map appropriately to input models for cloning.
            DocumentPackageModel package = this.mapper.Map<DocPkgDetailsModel, DocumentPackageModel>(existingPackageDetails);
            DocumentPackageFileModel packageFile = this.mapper.Map<DocPkgDetailsModel, DocumentPackageFileModel>(existingPackageDetails);

            // Generated info should be nulled out after clone, but before save, to get different file version ids to generate (we need some "change" to trigger this behavior)
            packageFile.GENERATED_INFO = null;

            // Persist the new clone, which will autoincrement the file version number (which is different from the filestore version id).
            DocPackageViewModel savedDocPackage = await this.UpdateDocumentPackage(
               new DocPackageViewModel
               {
                  Package = this.mapper.Map<DocumentPackageModel, DocumentPackageViewModel>(package),
                  PackageFile = this.mapper.Map<DocumentPackageFileModel, DocumentPackageFileViewModel>(packageFile)
               }, true);

            // Ensure the save of the clone document package file was successful.
            if (savedDocPackage != null)
            {
               // Update the filestore version information.
               bool didUpdateFileGenerationInfo = await this.documentPackageRepository.UpdateDocumentPackageFileGeneratedInfo(
                  savedDocPackage.Package.JobId,
                  savedDocPackage.Package.DocumentPackageId,
                  savedDocPackage.PackageFile.Version,
                  savedDocPackage.PackageFile.FileLocation,
                  GeneratedStatusOptions.Complete,
                  new GeneratedInfoModel() { VersionId = filestoreVersionId });

               if (didUpdateFileGenerationInfo)
               {
                  return new DocumentPackageFilestoreViewModel()
                  {
                     FileVersion = savedDocPackage.PackageFile.Version,
                     FilestoreVersionId = filestoreVersionId
                  };
               }
            }
         }

         return null;
      }

      /// <summary>
      /// Check the folder based on document package view model
      /// If document folder alreay exist new job document folder will not be created
      /// If document folder does not exist new job document folder will be created
      /// </summary>
      /// <param name="documentPackage">document package view model</param>
      /// <returns>task</returns>
      public async Task CheckAndCreateJobFolder(DocPackageViewModel documentPackage)
      {
         bool doesFolderExist = await this.documentFolderRepository.DoesFolderExist(documentPackage.Package.DocumentTypeId, documentPackage.Package.JobId);

         if (!doesFolderExist)
         {
            int jobDocumentFolderId = await this.documentPackageRepository.GetSequenceNumberAsync("JOB_DOCUMENT_FOLDER");
            if (jobDocumentFolderId != 0)
            {
               string userId = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
               DocumentFolderModel documentFolderEntity = new DocumentFolderModel()
               {
                  FOLDER_ID = jobDocumentFolderId,
                  DR_ADDRESS_ID = documentPackage.Package.DrAddressId,
                  DOC_TYPE_ID = documentPackage.Package.DocumentTypeId,
                  FOLDER_NAME = documentPackage.Package.DocumentTypeId.ToString(),
                  FOLDER_PARENT_ID = null,
                  FOLDER_SOURCE = "System",
                  JOB_ID = documentPackage.Package.JobId,
                  CREATED_BY_USER = userId,
                  LAST_MODIFIED_USER = userId,
                  JOB_FOLDER_TYPE_ID = 2,
               };
               await this.documentFolderRepository.CreateDocumentFolder(documentFolderEntity);
            }
         }
      }

      /// <summary>
      /// Get a list of document package files
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentTypeId">The reference id of the document package</param>
      /// <returns>Document package files detail list</returns>
      public async Task<IEnumerable<DocumentPackageFileViewModel>> GetPackageDocument(int jobId, int documentTypeId)
      {
         IEnumerable<DocumentPackageFileModel> documentPackageFileModel = await this.documentPackageRepository.GetPackageDocument(jobId, documentTypeId);
         IEnumerable<DocumentPackageFileViewModel> documentPackageFileViewModel = this.mapper.Map<IEnumerable<DocumentPackageFileModel>, IEnumerable<DocumentPackageFileViewModel>>(documentPackageFileModel);
         return documentPackageFileViewModel?.Any() == true ? documentPackageFileViewModel : Enumerable.Empty<DocumentPackageFileViewModel>();
      }

      /// <summary>
      /// Generate the proposal number based on the parameters
      /// x-nnnnnnn-y-z
      /// x - Sales Office Identifier - Sales Office Code for the Sales Office.
      /// nnnnnnn - internalJobIdentifierOnDatabase
      /// y - Document Package Identifier - Unique for a Job (1, 2, 3 and so on...)
      /// z - Number of Files that have been generated for a document package plus one
      /// </summary>
      /// <param name="salesOfficeCode">Sales office code</param>
      /// <param name="jobId">jobId</param>
      /// <param name="docPackId">document package unique identifier</param>
      /// <param name="fileNumber">total number of available files + 1</param>
      /// <returns>returns the proposal number as string</returns>
      private string GetProposalNumber(string salesOfficeCode, int jobId, int docPackId, int fileNumber = 1)
      {
         return salesOfficeCode + "-" + jobId + "-" + docPackId + "-" + fileNumber;
      }
   }
}