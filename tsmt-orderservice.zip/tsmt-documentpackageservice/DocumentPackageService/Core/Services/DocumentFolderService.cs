﻿// <copyright file="DocumentFolderService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using global::DocumentPackageService.Core.Models;
   using global::DocumentPackageService.Core.Repository;
   using global::DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Http;

   /// <summary>
   /// Document folder service
   /// </summary>
   public class DocumentFolderService : IDocumentFolderService
   {
      private readonly IDocumentFolderRepository documentFolderRepository;
      private readonly IMapper mapper;

      /// <summary>
      /// http Context Accessor
      /// </summary>
      private readonly IHttpContextAccessor contextAccessor;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentFolderService"/> class.
      /// </summary>
      /// <param name="documentFolderRepository">Document Folder repository</param>
      /// <param name="mapper">Mapper</param>
      /// <param name="contextAccessor">Context accessor</param>
      public DocumentFolderService(IDocumentFolderRepository documentFolderRepository, IMapper mapper, IHttpContextAccessor contextAccessor)
      {
         this.documentFolderRepository = documentFolderRepository;
         this.mapper = mapper;
         this.contextAccessor = contextAccessor;

         // The DrAddressId to honor is stored in the HttpContext.
         if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
             contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.documentFolderRepository.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.documentFolderRepository.HonorDrAddressId(null);
         }
      }

      /// <summary>
      /// Create new document folder
      /// </summary>
      /// <param name="documentFolder">Document folder view model</param>
      /// <returns>Returns the document folder list</returns>
      public async Task<IEnumerable<DocumentFolderViewModel>> CreateDocumentFolder(DocumentFolderViewModel documentFolder)
      {
         int jobDocumentFolderId = await this.documentFolderRepository.GetSequenceNumberAsync("JOB_DOCUMENT_FOLDER");
         if (jobDocumentFolderId != 0)
         {
            string userId = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
            DocumentFolderModel documentFolderEntity = this.mapper.Map<DocumentFolderViewModel, DocumentFolderModel>(documentFolder);
            documentFolderEntity.CREATED_BY_USER = userId;
            documentFolderEntity.LAST_MODIFIED_USER = userId;
            documentFolderEntity.FOLDER_ID = jobDocumentFolderId;
            var response = await this.documentFolderRepository.CreateDocumentFolder(documentFolderEntity);

            if (response)
            {
               IEnumerable<DocumentFolderModel> folderList = await this.documentFolderRepository.GetFolders(documentFolderEntity.JOB_ID);
               return this.mapper.Map<IEnumerable<DocumentFolderModel>, IEnumerable<DocumentFolderViewModel>>(folderList);
            }
         }

         return null;
      }

      /// <summary>
      /// Get document folders list based on document job id
      /// </summary>
      /// <param name="jobId">Document job id</param>
      /// <returns>List of document folder view model</returns>
      public async Task<IEnumerable<DocumentFolderViewModel>> GetFolders(int jobId)
      {
         IEnumerable<DocumentFolderModel> folderList = await this.documentFolderRepository.GetFolders(jobId);
         return this.mapper.Map<IEnumerable<DocumentFolderModel>, IEnumerable<DocumentFolderViewModel>>(folderList);
      }
   }
}
