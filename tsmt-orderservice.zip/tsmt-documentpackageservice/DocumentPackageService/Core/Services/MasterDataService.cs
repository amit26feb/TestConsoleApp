﻿// <copyright file="MasterDataService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using global::DocumentPackageService.Core.Repository;
   using global::DocumentPackageService.Core.ViewModels;

   /// <summary>
   /// DocumentPackageService
   /// </summary>
   public class MasterDataService : IMasterDataService
   {
      private readonly IMasterDataRepository masterDataRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="MasterDataService"/> class.
      /// </summary>
      /// <param name="masterDataRepository">masterDataRepository</param>
      public MasterDataService(IMasterDataRepository masterDataRepository)
      {
         this.masterDataRepository = masterDataRepository;
      }

      /// <summary>
      /// Gets the BusinessStreamViewModel list
      /// </summary>
      /// <returns>BusinessStreamViewModel list</returns>
      public async Task<IEnumerable<BusinessStreamViewModel>> GetBusinessStreams()
      {
         return await this.masterDataRepository.GetBusinessStreams();
      }

      /// <summary>
      /// Gets the DocumentTypeViewModel list
      /// </summary>
      /// <param name="docGroupId">Document group id / business stream id</param>
      /// <returns>DocumentTypeViewModel list</returns>
      public async Task<IEnumerable<DocumentTypeViewModel>> GetDocumentTypes(int docGroupId)
      {
         return await this.masterDataRepository.GetDocumentTypes(docGroupId);
      }

      /// <summary>
      /// Gets the LegalEntityViewModel list
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>LegalEntityViewModel list</returns>
      public async Task<IEnumerable<LegalEntityViewModel>> GetLegalEntities(int docTypeId)
      {
         return await this.masterDataRepository.GetLegalEntities(docTypeId);
      }

      /// <summary>
      /// Gets the TermsAndConditionsViewModel list
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>Terms and conditions list</returns>
      public async Task<IEnumerable<TermsAndConditionsViewModel>> GetTermsAndConditions(int docTypeId)
      {
         return await this.masterDataRepository.GetTermsAndConditions(docTypeId);
      }

      /// <summary>
      /// Gets the JobDocumentTypeViewModel list
      /// </summary>
      /// <returns>JobDocumentTypeViewModel list</returns>
      public async Task<IEnumerable<JobDocumentTypeViewModel>> GetJobDocumentType()
      {
         return await this.masterDataRepository.GetJobDocumentType();
      }
   }
}
