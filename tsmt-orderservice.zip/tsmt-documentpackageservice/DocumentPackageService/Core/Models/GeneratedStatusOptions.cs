﻿// <copyright file="GeneratedStatusOptions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   /// <summary>
   /// Options for document package file generated status
   /// </summary>
   public static class GeneratedStatusOptions
   {
      /// <summary>
      /// The document has not been generated yet
      /// </summary>
      public const string NotGenerated = "Not Generated";

      /// <summary>
      /// Document generation has been started
      /// </summary>
      public const string InProgress = "In Progress";

      /// <summary>
      /// Document generation has completed
      /// </summary>
      public const string Complete = "Complete";

      /// <summary>
      /// Document generation has uploaded
      /// </summary>
      public const string Uploaded = "Uploaded";

      /// <summary>
      /// Document generation has failed
      /// </summary>
      public const string Failed = "Failed";
   }
}
