﻿// <copyright file="DocumentPackageFileModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;
   using System.ComponentModel.DataAnnotations.Schema;
   using TSMT.DataAccess;

   /// <summary>
   /// Document package file model
   /// </summary>
   [Table("SO.DG_DOC_PACKAGE_FILE")]
   public class DocumentPackageFileModel : IDataEntity
   {
      /// <summary>
      /// Gets or sets DR_ADDRESS_ID
      /// </summary>
      public int DR_ADDRESS_ID { get; set; }

      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets DOC_PKG_ID
      /// </summary>
      public int DOC_PKG_ID { get; set; }

      /// <summary>
      /// Gets or sets FILE_VERSION
      /// </summary>
      public int FILE_VERSION { get; set; }

      /// <summary>
      /// Gets or sets LEGAL_ENTITY_ID
      /// </summary>
      public int LEGAL_ENTITY_ID { get; set; }

      /// <summary>
      /// Gets or sets TERMS_AND_CONDITIONS_ID
      /// </summary>
      public int TERMS_COND_ID { get; set; }

      /// <summary>
      /// Gets or sets BID_ALTERNATE_ID
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets FILE_NAME
      /// </summary>
      public string FILE_NAME { get; set; }

      /// <summary>
      /// Gets or sets FILE_LOCATION
      /// </summary>
      public string FILE_LOCATION { get; set; }

      /// <summary>
      /// Gets or sets ADDITIONAL_INFO
      /// </summary>
      public string ADDITIONAL_INFO { get; set; }

      /// <summary>
      /// Gets or sets STATUS
      /// </summary>
      public string STATUS { get; set; }

      /// <summary>
      /// Gets or sets GENERATED_INFO
      /// </summary>
      public string GENERATED_INFO { get; set; }

      /// <summary>
      /// Gets or sets GENERATED_DATE
      /// </summary>
      public DateTime? GENERATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets GENERATED_BY_USER
      /// </summary>
      public string GENERATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets PROPOSAL_NBR
      /// </summary>
      public string PROPOSAL_NBR { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_DATE
      /// </summary>
      public DateTime LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_USER
      /// </summary>
      public string LAST_MODIFIED_USER { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_SHORT_NAME
      /// </summary>
      public string DOC_TYPE_SHORT_NAME { get; set; }
   }
}
