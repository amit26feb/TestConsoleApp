﻿// <copyright file="GeneratedInfoModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   /// <summary>
   /// Model for storing file generation info in document package file
   /// </summary>
   public class GeneratedInfoModel
   {
      /// <summary>
      /// Gets or sets description of any errors encountered in report generation
      /// </summary>
      public string ErrorDescription { get; set; }

      /// <summary>
      /// Gets or sets version id of the generated file
      /// </summary>
      public string VersionId { get; set; }
   }
}
