﻿// <copyright file="DocumentTypeModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;
   using System.ComponentModel.DataAnnotations.Schema;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for DOCUMENT_TYPE
   /// </summary>
   [Table("SO.DGM_DOC_TYPE")]
   public class DocumentTypeModel : IDataEntity
   {
      /// <summary>
      /// Gets or sets DOC_TYPE_ID
      /// </summary>
      public int DOC_TYPE_ID { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_NAME
      /// </summary>
      public string DOC_TYPE_NAME { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_SHORT_NAME
      /// </summary>
      public string DOC_TYPE_SHORT_NAME { get; set; }

      /// <summary>
      /// Gets or sets DOC_GROUP_ID
      /// </summary>
      public int DOC_GROUP_ID { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_ABSTRACT
      /// </summary>
      public string DOC_TYPE_ABSTRACT { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_SEQ_NBR
      /// </summary>
      public int DOC_TYPE_SEQ_NBR { get; set; }

      /// <summary>
      /// Gets or sets STATUS
      /// </summary>
      public string STATUS { get; set; }

      /// <summary>
      /// Gets or sets CREATED_DATE
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets CREATED_BY_USER
      /// </summary>
      public string CREATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_DATE
      /// </summary>
      public DateTime LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_USER
      /// </summary>
      public string LAST_MODIFIED_USER { get; set; }
   }
}