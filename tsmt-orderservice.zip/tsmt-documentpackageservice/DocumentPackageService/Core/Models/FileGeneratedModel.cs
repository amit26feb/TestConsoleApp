﻿// <copyright file="FileGeneratedModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System.Collections.Generic;
   using System.Linq;

   /// <summary>
   /// File generated model for a document/file/report generated in document service background generation
   /// </summary>
   public class FileGeneratedModel
   {
      private string[] splitReportId;
      private string reportId;

      /// <summary>
      /// Gets or sets the ReportId The ReportId is the combination of DrAddress/Job/DocPackageID/Version.
      /// </summary>
      public string ReportId
      {
         get
         {
            return this.reportId;
         }

         set
         {
            this.reportId = value;
            this.splitReportId = value?.Split('/');
         }
      }

      /// <summary>
      /// Gets or sets errors encountered during generation
      /// </summary>
      public List<string> InternalErrors { get; set; }

      /// <summary>
      /// Gets or sets the report path of the generated report
      /// </summary>
      public string ReportPath { get; set; }

      /// <summary>
      /// Gets or sets the version id for the generated report.  Currently used for S3 versioning.
      /// </summary>
      public string VersionId { get; set; }

      /// <summary>
      /// Validate report Id properties
      /// </summary>
      /// <returns>Boolean indicating we can correctly parse Ids</returns>
      public bool IsRequestValid()
      {
         return this.GetDrAddressId() > 0 &&
            this.GetJobId() > 0 &&
            this.GetDocPackageId() > 0 &&
            this.GetVersion() >= 0;
      }

      /// <summary>
      /// Get the DrAddressId from the request
      /// </summary>
      /// <returns>DrAddressId or -1 if Id part is not valid</returns>
      public int GetDrAddressId()
      {
         return this.TryGetIdPart(0);
      }

      /// <summary>
      /// Get the JobId from the request
      /// </summary>
      /// <returns>JobId or -1 if Id part is not valid</returns>
      public int GetJobId()
      {
         return this.TryGetIdPart(1);
      }

      /// <summary>
      /// Get the DocPackageId from the request
      /// </summary>
      /// <returns>DocPackageId or -1 if Id part is not valid</returns>
      public int GetDocPackageId()
      {
         return this.TryGetIdPart(2);
      }

      /// <summary>
      /// Get the Version from the request
      /// </summary>
      /// <returns>Version or -1 if Id part is not valid</returns>
      public int GetVersion()
      {
         return this.TryGetIdPart(3);
      }

      /// <summary>
      /// Get the file generated status
      /// </summary>
      /// <returns>Status of generated file</returns>
      public string GetGeneratedStatus()
      {
         return this.InternalErrors?.Any() == true ?
            GeneratedStatusOptions.Failed : GeneratedStatusOptions.Complete;
      }

      /// <summary>
      /// Get a summary of any generation errors.
      /// </summary>
      /// <returns>Status of generated file</returns>
      public string GetErrorSummary()
      {
         return this.InternalErrors?.Any() == true ?
            string.Join(", ", this.InternalErrors) : null;
      }

      private int TryGetIdPart(int index)
      {
         // A valid report ID will have 4 parts:
         // DrAddressId/JoIdb/DocPackageId/Version
         if (this.splitReportId?.Length > index)
         {
            return int.TryParse(this.splitReportId[index], out int parsed) ? parsed : 0;
         }

         return -1;
      }
   }
}
