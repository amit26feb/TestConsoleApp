﻿// <copyright file="LegalEntityModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;
   using System.ComponentModel.DataAnnotations.Schema;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for LEGAL_ENTITY
   /// </summary>
   [Table("SO.DGM_LEGAL_ENTITY")]
   public class LegalEntityModel : IDataEntity
    {
      /// <summary>
      /// Gets or sets LEGAL_ENTITY_ID
      /// </summary>
      public int LEGAL_ENTITY_ID { get; set; }

      /// <summary>
      /// Gets or sets ENTITY_SHORT_NAME
      /// </summary>
      public string ENTITY_SHORT_NAME { get; set; }

      /// <summary>
      /// Gets or sets ENTITY_LONG_NAME
      /// </summary>
      public string ENTITY_LONG_NAME { get; set; }

      /// <summary>
      /// Gets or sets ENTITY_ABSTRACT
      /// </summary>
      public string ENTITY_ABSTRACT { get; set; }

      /// <summary>
      /// Gets or sets ENTITY_EFFECTIVE_DATE
      /// </summary>
      public DateTime ENTITY_EFFECTIVE_DATE { get; set; }

      /// <summary>
      /// Gets or sets ENTITY_EXPIRATION_DATE
      /// </summary>
      public DateTime ENTITY_EXPIRATION_DATE { get; set; }

      /// <summary>
      /// Gets or sets SEQUENCE_NBR from the xref table
      /// </summary>
      public int SEQUENCE_NBR { get; set; }
   }
}