﻿// <copyright file="TermsAndConditionsModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;
   using System.ComponentModel.DataAnnotations.Schema;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for TERMS_AND_CONDITIONS
   /// </summary>
   [Table("SO.DGM_TERMS_CONDITIONS")]
   public class TermsAndConditionsModel : IDataEntity
    {
      /// <summary>
      /// Gets or sets TERMS_COND_ID
      /// </summary>
      public int TERMS_COND_ID { get; set; }

      /// <summary>
      /// Gets or sets TERMS_COND_NAME
      /// </summary>
      public string TERMS_COND_NAME { get; set; }

      /// <summary>
      /// Gets or sets TERMS_COND_DESCRIPTION
      /// </summary>
      public string TERMS_COND_DESCRIPTION { get; set; }

      /// <summary>
      /// Gets or sets FILE_LOCTION
      /// </summary>
      public string FILE_LOCTION { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_ID
      /// </summary>
      public int DOC_TYPE_ID { get; set; }

      /// <summary>
      /// Gets or sets CREATED_DATE
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets CREATED_BY_USER
      /// </summary>
      public string CREATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_DATE
      /// </summary>
      public DateTime LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_USER
      /// </summary>
      public string LAST_MODIFIED_USER { get; set; }

      /// <summary>
      /// Gets or sets SEQUENCE_NBR from the xref table
      /// </summary>
      public int SEQUENCE_NBR { get; set; }

      /// <summary>
      /// Gets or sets DEFAULT_IND from the xref table
      /// </summary>
      public int DEFAULT_IND { get; set; }
   }
}