﻿// <copyright file="DocumentPackageFileStatusModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;

   /// <summary>
   /// Output model for doc package file status related things.
   /// </summary>
   public class DocumentPackageFileStatusModel
   {
      /// <summary>
      /// Gets or sets the status of the document package file
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets the last generated datetime of doc.
      /// </summary>
      public DateTime? GeneratedDate { get; set; }
   }
}
