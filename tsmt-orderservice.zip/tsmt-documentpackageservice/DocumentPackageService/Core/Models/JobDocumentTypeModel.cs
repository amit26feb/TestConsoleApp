﻿// <copyright file="JobDocumentTypeModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;
   using System.ComponentModel.DataAnnotations.Schema;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for job document type
   /// </summary>
   [Table("SO.JOB_DOCUMENT_TYPE")]
   public class JobDocumentTypeModel : IDataEntity
   {
      /// <summary>
      /// Gets or sets JOB_DOCUMENT_TYPE_ID
      /// </summary>
      public int JOB_DOCUMENT_TYPE_ID { get; set; }

      /// <summary>
      /// Gets or sets TYPE_NAME
      /// </summary>
      public string TYPE_NAME { get; set; }

      /// <summary>
      /// Gets or sets ABSTRACT
      /// </summary>
      public string TYPE_ABSTRACT { get; set; }

      /// <summary>
      /// Gets or sets TYPE_SEQ_NBR
      /// </summary>
      public int TYPE_SEQ_NBR { get; set; }

      /// <summary>
      /// Gets or sets IS_AVAILABLE_TO_USER_IND
      /// </summary>
      public int IS_AVAILABLE_TO_USER_IND { get; set; }

      /// <summary>
      /// Gets or sets CREATED_DATE
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets CREATED_BY_USER
      /// </summary>
      public string CREATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_DATE
      /// </summary>
      public DateTime LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_USER
      /// </summary>
      public string LAST_MODIFIED_USER { get; set; }
   }
}
