﻿// <copyright file="DocumentPackageFileDownloadModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using Newtonsoft.Json;

   /// <summary>
   /// Class containing name and location for a doc package file
   /// </summary>
   public class DocumentPackageFileDownloadModel
   {
      private GeneratedInfoModel parsedGeneratedInfo;

      /// <summary>
      /// Gets or sets name of file to download (not including extension)
      /// </summary>
      public string Name { get; set; }

      /// <summary>
      /// Gets or sets location of file to download
      /// </summary>
      public string Location { get; set; }

      /// <summary>
      /// Gets or sets the generated info for a document package file
      /// </summary>
      public string GeneratedInfo { get; set; }

      /// <summary>
      /// Gets or sets the version id for a document package file
      /// </summary>
      public int VersionId { get; set; }

      /// <summary>
      /// Gets the file name plus our currently supported extension.
      /// </summary>
      /// <returns>File name plus extension</returns>
      public string GetNameWithExtension()
      {
         return this.Name + ".docx";
      }

      /// <summary>
      /// Gets the version id from generated info
      /// </summary>
      /// <returns>String of the version Id</returns>
      public string GetVersionId()
      {
         return this.GetGeneratedInfo().VersionId;
      }

      private GeneratedInfoModel GetGeneratedInfo()
      {
         if (this.parsedGeneratedInfo == null && this.GeneratedInfo != null)
         {
            this.parsedGeneratedInfo = JsonConvert.DeserializeObject<GeneratedInfoModel>(this.GeneratedInfo);
         }

         return this.parsedGeneratedInfo ?? new GeneratedInfoModel();
      }
   }
}
