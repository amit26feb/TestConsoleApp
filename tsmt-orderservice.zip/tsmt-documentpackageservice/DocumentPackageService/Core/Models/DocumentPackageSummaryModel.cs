﻿// <copyright file="DocumentPackageSummaryModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Document packages list model
   /// </summary>
   public class DocumentPackageSummaryModel : IDataEntity
   {
      /// <summary>
      /// Gets or sets DOCUMENT_TYPE
      /// </summary>
      public string DOCUMENT_TYPE { get; set; }

      /// <summary>
      /// Gets or sets DOC_PKG_ID
      /// </summary>
      public int DOC_PKG_ID { get; set; }

      /// <summary>
      /// Gets or sets NAME
      /// </summary>
      public string NAME { get; set; }

      /// <summary>
      /// Gets or sets DESCRIPTION
      /// </summary>
      public string DESCRIPTION { get; set; }

      /// <summary>
      /// Gets or sets DR_ADDRESS_ID
      /// </summary>
      public int DR_ADDRESS_ID { get; set; }

      /// <summary>
      /// Gets or sets CREATED_BY_USER
      /// </summary>
      public string CREATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets CREATED_DATE
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_USER
      /// </summary>
      public string LAST_MODIFIED_USER { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_DATE
      /// </summary>
      public DateTime LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets STATUS
      /// </summary>
      public string STATUS { get; set; }

      /// <summary>
      /// Gets or sets FILE_VERSION
      /// </summary>
      public int FILE_VERSION { get; set; }

      /// <summary>
      /// Gets or sets LAST_GENERATED_VERSION
      /// </summary>
      public int? LAST_GENERATED_VERSION { get; set; }

      /// <summary>
      /// Gets or sets FILE_GENERATED_DATE
      /// </summary>
      public DateTime? FILE_GENERATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets FILE_GENERATED_BY_USER
      /// </summary>
      public string FILE_GENERATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets LAST_UPLOADED_VERSION,
      /// </summary>
      public int? LAST_UPLOADED_VERSION { get; set; }

      /// <summary>
      /// Gets or sets FILE_UPLOADED_DATE
      /// </summary>
      public DateTime? FILE_UPLOADED_DATE { get; set; }

      /// <summary>
      /// Gets or sets FILE_UPLOADED_BY_USER
      /// </summary>
      public string FILE_UPLOADED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_ID
      /// </summary>
      public int DOC_TYPE_ID { get; set; }
   }
}
