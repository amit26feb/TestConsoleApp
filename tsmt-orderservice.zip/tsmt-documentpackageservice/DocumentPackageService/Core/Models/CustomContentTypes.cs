﻿// <copyright file="CustomContentTypes.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   /// <summary>
   /// Class to define custome content types that are not defined in System.Net.Mime.MediaTypeNames
   /// </summary>
   public static class CustomContentTypes
   {
      /// <summary>Microsoft Word 2007 files</summary>
      public const string WordDoc = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
   }
}
