﻿// <copyright file="DocPkgDetailsModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;

   /// <summary>
   /// Document Package Details Model
   /// </summary>
   public class DocPkgDetailsModel
   {
      /// <summary>
      /// Gets or sets DR_ADDRESS_ID
      /// </summary>
      public int DR_ADDRESS_ID { get; set; }

      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets DOC_PKG_ID
      /// </summary>
      public int DOC_PKG_ID { get; set; }

      /// <summary>
      /// Gets or sets NAME
      /// </summary>
      public string PKG_NAME { get; set; }

      /// <summary>
      /// Gets or sets DESCRIPTION
      /// </summary>
      public string PKG_DESCRIPTION { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_ID
      /// </summary>
      public int DOC_TYPE_ID { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_NAME
      /// </summary>
      public string DOC_TYPE_NAME { get; set; }

      /// <summary>
      /// Gets or sets CREATED_DATE
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets CREATED_BY_USER
      /// </summary>
      public string CREATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_DATE
      /// </summary>
      public DateTime LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_USER
      /// </summary>
      public string LAST_MODIFIED_USER { get; set; }

      /// <summary>
      /// Gets or sets DOC_PKG_FILE_ID
      /// </summary>
      public int DOC_PKG_FILE_ID { get; set; }

      /// <summary>
      /// Gets or sets FILE_VERSION
      /// </summary>
      public int FILE_VERSION { get; set; }

      /// <summary>
      /// Gets or sets LEGAL_ENTITY_ID
      /// </summary>
      public int LEGAL_ENTITY_ID { get; set; }

      /// <summary>
      /// Gets or sets ENTITY_NAME
      /// </summary>
      public string ENTITY_LONG_NAME { get; set; }

      /// <summary>
      /// Gets or sets ENTITY_NAME
      /// </summary>
      public string ENTITY_SHORT_NAME { get; set; }

      /// <summary>
      /// Gets or sets TERMS_COND_ID
      /// </summary>
      public int TERMS_COND_ID { get; set; }

      /// <summary>
      /// Gets or sets TERMS_COND_NAME
      /// </summary>
      public string TERMS_COND_NAME { get; set; }

      /// <summary>
      /// Gets or sets TC_FILE_LOCATION
      /// </summary>
      public string TC_FILE_LOCATION { get; set; }

      /// <summary>
      /// Gets or sets BID_ALTERNATE_ID
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets FILE_NAME
      /// </summary>
      public string FILE_NAME { get; set; }

      /// <summary>
      /// Gets or sets FILE_LOCATION
      /// </summary>
      public string FILE_LOCATION { get; set; }

      /// <summary>
      /// Gets or sets ADDITIONAL_INFO
      /// </summary>
      public string ADDITIONAL_INFO { get; set; }

      /// <summary>
      /// Gets or sets STATUS
      /// </summary>
      public string STATUS { get; set; }

      /// <summary>
      /// Gets or sets GENERATED_INFO
      /// </summary>
      public string GENERATED_INFO { get; set; }

      /// <summary>
      /// Gets or sets GENERATED_DATE
      /// </summary>
      public DateTime? GENERATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets GENERATED_BY_USER
      /// </summary>
      public string GENERATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets PROPOSAL_NBR
      /// </summary>
      public string PROPOSAL_NBR { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_DATE
      /// </summary>
      public DateTime FILE_LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets LAST_MODIFIED_USER
      /// </summary>
      public string FILE_LAST_MODIFIED_USER { get; set; }

      /// <summary>
      /// Gets or sets DOC_TYPE_SHORT_NAME
      /// </summary>
      public string DOC_TYPE_SHORT_NAME { get; set; }
   }
}
