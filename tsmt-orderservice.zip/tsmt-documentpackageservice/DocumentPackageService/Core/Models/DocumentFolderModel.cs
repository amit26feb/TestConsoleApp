﻿// <copyright file="DocumentFolderModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Models
{
   using System;
   using System.ComponentModel.DataAnnotations.Schema;
   using TSMT.DataAccess;

   /// <summary>
   /// Docuemnt folder model
   /// </summary>
   [Table("SO.JOB_DOCUMENT_FOLDER")]
   public class DocumentFolderModel : IDataEntity
   {
      /// <summary>
      /// Gets or sets document folder id
      /// </summary>
      public int FOLDER_ID { get; set; }

      /// <summary>
      /// Gets or sets document folder parent id
      /// </summary>
      public int? FOLDER_PARENT_ID { get; set; }

      /// <summary>
      /// Gets or sets dr address id
      /// </summary>
      public int DR_ADDRESS_ID { get; set; }

      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets the folder name
      /// </summary>
      public string FOLDER_NAME { get; set; }

      /// <summary>
      /// Gets or sets the folder source
      /// </summary>
      public string FOLDER_SOURCE { get; set; }

      /// <summary>
      /// Gets or sets the created date
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets the created by user id
      /// </summary>
      public string CREATED_BY_USER { get; set; }

      /// <summary>
      /// Gets or sets the last modified date
      /// </summary>
      public DateTime LAST_MODIFIED_DATE { get; set; }

      /// <summary>
      /// Gets or sets the last modified user id
      /// </summary>
      public string LAST_MODIFIED_USER { get; set; }

      /// <summary>
      /// Gets or sets job folder type id
      /// </summary>
      public int? JOB_FOLDER_TYPE_ID { get; set; }

      /// <summary>
      /// Gets or sets document type id
      /// </summary>
      public int? DOC_TYPE_ID { get; set; }
   }
}