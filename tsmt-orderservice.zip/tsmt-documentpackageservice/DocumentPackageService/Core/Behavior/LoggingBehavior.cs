﻿// <copyright file="LoggingBehavior.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Behavior
{
    using System.Threading;
    using System.Threading.Tasks;
    using MediatR;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Logging behavior
    /// </summary>
    /// <typeparam name="TRequest">TRequest parameter</typeparam>
    /// <typeparam name="TResponse">TResponse parameter</typeparam>
    public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    {
        /// <summary>
        /// The logger.
        /// </summary>
        private readonly ILogger<LoggingBehavior<TRequest, TResponse>> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggingBehavior{TRequest, TResponse}"/> class.
        /// </summary>
        /// <param name="logger">Logger parameter</param>
        public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> logger) => this.logger = logger;

        /// <summary>
        /// Handle request
        /// </summary>
        /// <param name="request">Request value</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <param name="next">Request handler delegate</param>
        /// <returns>A <see cref="Task"/>Representing the asynchronous operation</returns>
        public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {
            this.logger.LogTrace($"Handling {typeof(TRequest).Name}");
            var response = await next();
            this.logger.LogTrace($"Handled {typeof(TResponse).Name}");
            return response;
        }
    }
}