﻿// <copyright file="CreateDocumentPackageCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Validators
{
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Repository;
   using FluentValidation;
   using Microsoft.AspNetCore.Http;

   /// <summary>
   /// Create document package command validator
   /// </summary>
   public class CreateDocumentPackageCommandValidator : AbstractValidator<CreateDocumentPackageCommand>
   {
      /// <summary>
      /// Document package repository
      /// </summary>
      private readonly IDocumentPackageRepository documentPackageRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentPackageCommandValidator"/> class.
      /// </summary>
      /// <param name="documentPackageRepository">Document package repository</param>
      /// <param name="contextAccessor">contextAccessor</param>
      public CreateDocumentPackageCommandValidator(IDocumentPackageRepository documentPackageRepository, IHttpContextAccessor contextAccessor)
      {
         this.documentPackageRepository = documentPackageRepository;

         // The DrAddressId to honor is stored in the HttpContext.
         if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
             contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.documentPackageRepository.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.documentPackageRepository.HonorDrAddressId(null);
         }

         this.RuleFor(command => command.DocumentPackage.Package.BusinessStreamId).GreaterThanOrEqualTo(0).WithMessage("Business stream must be selected.");
         this.RuleFor(command => command.DocumentPackage.Package.DocumentTypeId).NotEqual(0).WithMessage("Document type must be selected.");
         this.RuleFor(command => command.DocumentPackage.Package.DrAddressId).NotEqual(0).WithMessage("Invalid DrAddressId");
         this.RuleFor(command => command.DocumentPackage.Package.JobId).NotEqual(0).WithMessage("Invalid Job Id");
         this.RuleFor(command => command.DocumentPackage.PackageFile.LegalEntityId).NotEqual(0).WithMessage("Legal entity must be selected.");
         this.RuleFor(command => command.DocumentPackage.PackageFile.TermsAndConditionsId).NotEqual(0).WithMessage("Terms and conditions must be selected.");
         this.RuleFor(command => command.DocumentPackage.Package).NotEmpty().MustAsync(async (documentPackage, ct) => await this.documentPackageRepository.ValidateDocumentPackage(documentPackage.Name, documentPackage.JobId)).WithMessage("Document package already exists with the same name. Please enter a different document package name");
      }
   }
}
