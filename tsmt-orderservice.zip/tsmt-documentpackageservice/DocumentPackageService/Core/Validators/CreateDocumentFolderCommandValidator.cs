﻿// <copyright file="CreateDocumentFolderCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Validators
{
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Repository;
   using FluentValidation;
   using Microsoft.AspNetCore.Http;

   /// <summary>
   /// Create document package command validator
   /// </summary>
   public class CreateDocumentFolderCommandValidator : AbstractValidator<CreateDocumentFolderCommand>
   {
      /// <summary>
      /// Document folder repository
      /// </summary>
      private readonly IDocumentFolderRepository documentFolderRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentFolderCommandValidator"/> class.
      /// </summary>
      /// <param name="documentFolderRepository">Document folder repository</param>
      /// <param name="contextAccessor">contextAccessor</param>
      public CreateDocumentFolderCommandValidator(IDocumentFolderRepository documentFolderRepository, IHttpContextAccessor contextAccessor)
      {
         this.documentFolderRepository = documentFolderRepository;

         // The DrAddressId to honor is stored in the HttpContext.
         if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
             contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.documentFolderRepository.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.documentFolderRepository.HonorDrAddressId(null);
         }

         this.RuleFor(command => command.DocumentFolder.DrAddressId).NotEqual(0).WithMessage("Invalid DrAddressId");
         this.RuleFor(command => command.DocumentFolder.JobId).NotEqual(0).WithMessage("Invalid Job Id");
         this.RuleFor(command => command.DocumentFolder).NotEmpty().MustAsync(async (documentFolder, ct) => await this.documentFolderRepository.ValidateDocumentFolder(documentFolder)).WithMessage("Document folder already exists with the same name. Please enter a different folder name");
      }
   }
}
