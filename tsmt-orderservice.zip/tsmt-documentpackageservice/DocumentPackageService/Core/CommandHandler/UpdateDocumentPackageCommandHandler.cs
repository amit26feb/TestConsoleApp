﻿// <copyright file="UpdateDocumentPackageCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.CommandHandler
{
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Handler which processes the command for creating document package
   /// </summary>
   public class UpdateDocumentPackageCommandHandler : IRequestHandler<UpdateDocumentPackageCommand, DocPackageViewModel>
   {
      private readonly ILogger<UpdateDocumentPackageCommand> logger;
      private readonly IDocumentPackageService documentPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateDocumentPackageCommandHandler"/> class.
      /// Create document package command handler
      /// </summary>
      /// <param name="logger">Logger</param>
      /// <param name="documentPackageService">Document package service</param>
      public UpdateDocumentPackageCommandHandler(ILogger<UpdateDocumentPackageCommand> logger, IDocumentPackageService documentPackageService)
      {
         this.logger = logger;
         this.documentPackageService = documentPackageService;
      }

      /// <summary>
      /// Handler which processes the command when user executes update document package from the UI
      /// </summary>
      /// <param name="request">Update command request</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>Returns the updated document package view model.</returns>
      public async Task<DocPackageViewModel> Handle(UpdateDocumentPackageCommand request, CancellationToken cancellationToken)
      {
         var result = await this.documentPackageService.UpdateDocumentPackage(request.DocumentPackage);
         this.logger.LogTrace("Document package Updated successfully");
         return result;
      }
   }
}
