﻿// <copyright file="CreateDocumentPackageCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.CommandHandler
{
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Handler which processes the command for creating document package
   /// </summary>
   public class CreateDocumentPackageCommandHandler : IRequestHandler<CreateDocumentPackageCommand, DocPackageViewModel>
   {
      private readonly ILogger<CreateDocumentPackageCommand> logger;
      private readonly IDocumentPackageService documentPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentPackageCommandHandler"/> class.
      /// Create document package command handler
      /// </summary>
      /// <param name="logger">Logger</param>
      /// <param name="documentPackageService">Document package service</param>
      public CreateDocumentPackageCommandHandler(ILogger<CreateDocumentPackageCommand> logger, IDocumentPackageService documentPackageService)
      {
         this.logger = logger;
         this.documentPackageService = documentPackageService;
      }

      /// <summary>
      /// Handler which processes the command when user executes create document package from the UI
      /// </summary>
      /// <param name="request">Create command request</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>Returns the create document package view model.</returns>
      public async Task<DocPackageViewModel> Handle(CreateDocumentPackageCommand request, CancellationToken cancellationToken)
      {
         var result = await this.documentPackageService.CreateDocumentPackage(request.DocumentPackage);
         this.logger.LogTrace("Document package created successfully");
         return result;
      }
   }
}
