﻿// <copyright file="CreateDocumentFolderCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.CommandHandler
{
   using System.Collections.Generic;
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Handler which processes the command for creating document Folder
   /// </summary>
   public class CreateDocumentFolderCommandHandler : IRequestHandler<CreateDocumentFolderCommand, IEnumerable<DocumentFolderViewModel>>
   {
      private readonly ILogger<CreateDocumentFolderCommand> logger;
      private readonly IDocumentFolderService documentFolderService;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentFolderCommandHandler"/> class.
      /// Create document Folder command handler
      /// </summary>
      /// <param name="logger">Logger</param>
      /// <param name="documentFolderService">Document Folder service</param>
      public CreateDocumentFolderCommandHandler(ILogger<CreateDocumentFolderCommand> logger, IDocumentFolderService documentFolderService)
      {
         this.logger = logger;
         this.documentFolderService = documentFolderService;
      }

      /// <summary>
      /// Handler which processes the command when user executes create document Folder from the UI
      /// </summary>
      /// <param name="request">Create command request</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>Returns the create document Folder view model.</returns>
      public async Task<IEnumerable<DocumentFolderViewModel>> Handle(CreateDocumentFolderCommand request, CancellationToken cancellationToken)
      {
         var result = await this.documentFolderService.CreateDocumentFolder(request.DocumentFolder);
         this.logger.LogTrace("Document folder created successfully");
         return result;
      }
   }
}
