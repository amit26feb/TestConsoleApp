﻿// <copyright file="UpdateDocumentPackageFileCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.CommandHandler
{
   using System.Threading;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using MediatR;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Handler which processes the command for updating a document package file
   /// </summary>
   public class UpdateDocumentPackageFileCommandHandler : IRequestHandler<UpdateDocumentPackageFileCommand, bool>
   {
      private readonly ILogger<UpdateDocumentPackageFileCommand> logger;
      private readonly IDocumentPackageService documentPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateDocumentPackageFileCommandHandler"/> class.
      /// Update document package file status command handler
      /// </summary>
      /// <param name="logger">Logger</param>
      /// <param name="documentPackageService">Document package service</param>
      public UpdateDocumentPackageFileCommandHandler(ILogger<UpdateDocumentPackageFileCommand> logger, IDocumentPackageService documentPackageService)
      {
         this.logger = logger;
         this.documentPackageService = documentPackageService;
      }

      /// <summary>
      /// Handler which processes the command when user executes update document package file statua from the UI
      /// </summary>
      /// <param name="request">Update command request</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>Returns true/false based on whether or not the status could be updated.</returns>
      public async Task<bool> Handle(UpdateDocumentPackageFileCommand request, CancellationToken cancellationToken)
      {
         bool result = await this.documentPackageService.UpdateDocumentPackageFileStatus(
            request.DocumentPackageFileStatusUpdate.DocumentPackageId,
            request.DocumentPackageFileStatusUpdate.FileVersion,
            request.DocumentPackageFileStatusUpdate.Status);

         string logText = "Document package file status " +
            (result ? "updated successfully." : "could not be updated.");

         this.logger.LogTrace(logText);
         return result;
      }
   }
}
