﻿// <copyright file="CreateDocumentPackageCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Commands
{
   using System.Runtime.Serialization;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;

   /// <summary>
   /// Handles document package creation
   /// </summary>
   [DataContract]
   public class CreateDocumentPackageCommand : IRequest<DocPackageViewModel>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentPackageCommand"/> class.
      /// </summary>
      /// <param name="documentPackage">Document package view</param>
      public CreateDocumentPackageCommand(DocPackageViewModel documentPackage)
      {
         this.DocumentPackage = documentPackage;
      }

      /// <summary>
      /// Gets view model property
      /// </summary>
      [DataMember]
      public DocPackageViewModel DocumentPackage { get; private set; }
   }
}
