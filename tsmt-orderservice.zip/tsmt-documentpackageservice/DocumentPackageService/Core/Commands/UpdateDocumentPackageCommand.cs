﻿// <copyright file="UpdateDocumentPackageCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Commands
{
   using System.Runtime.Serialization;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;

   /// <summary>
   /// Handles document package creation
   /// </summary>
   [DataContract]
   public class UpdateDocumentPackageCommand : IRequest<DocPackageViewModel>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateDocumentPackageCommand"/> class.
      /// </summary>
      /// <param name="documentPackage">Document package view</param>
      public UpdateDocumentPackageCommand(DocPackageViewModel documentPackage)
      {
         this.DocumentPackage = documentPackage;
      }

      /// <summary>
      /// Gets view model property
      /// </summary>
      [DataMember]
      public DocPackageViewModel DocumentPackage { get; private set; }
   }
}
