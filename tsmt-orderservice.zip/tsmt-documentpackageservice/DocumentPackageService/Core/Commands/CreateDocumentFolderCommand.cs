﻿// <copyright file="CreateDocumentFolderCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Commands
{
   using System.Collections.Generic;
   using System.Runtime.Serialization;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;

   /// <summary>
   /// Handles document folder creation
   /// </summary>
   [DataContract]
   public class CreateDocumentFolderCommand : IRequest<IEnumerable<DocumentFolderViewModel>>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="CreateDocumentFolderCommand"/> class.
      /// </summary>
      /// <param name="documentFolder">Document folder view</param>
      public CreateDocumentFolderCommand(DocumentFolderViewModel documentFolder)
      {
         this.DocumentFolder = documentFolder;
      }

      /// <summary>
      /// Gets view model property
      /// </summary>
      [DataMember]
      public DocumentFolderViewModel DocumentFolder { get; private set; }
   }
}
