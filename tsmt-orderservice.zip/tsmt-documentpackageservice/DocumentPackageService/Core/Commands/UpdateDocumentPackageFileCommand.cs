﻿// <copyright file="UpdateDocumentPackageFileCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Core.Commands
{
   using System.Runtime.Serialization;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;

   /// <summary>
   /// Handles document package file update
   /// </summary>
   [DataContract]
   public class UpdateDocumentPackageFileCommand : IRequest<bool>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateDocumentPackageFileCommand"/> class.
      /// </summary>
      /// <param name="fileStatusUpdate">Model for updating document package file status</param>
      public UpdateDocumentPackageFileCommand(DocumentPackageFileStatusViewModel fileStatusUpdate)
      {
         this.DocumentPackageFileStatusUpdate = fileStatusUpdate;
      }

      /// <summary>
      /// Gets view model property
      /// </summary>
      [DataMember]
      public DocumentPackageFileStatusViewModel DocumentPackageFileStatusUpdate { get; private set; }
   }
}
