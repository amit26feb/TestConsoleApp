﻿// <copyright file="Program.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService
{
    using System.IO;
    using DocumentPackageService.Configurations;
    using Microsoft.AspNetCore;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using NLog.Web;
    using TSMT.Settings;

    /// <summary>
    /// Program class
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Program"/> class.
        /// Config paramerter constants
        /// </summary>
        protected Program()
        {
        }

        /// <summary>
        /// Main Method
        /// </summary>
        /// <param name="args">args</param>
        public static void Main(string[] args)
        {
            BuildWebHost(args).Build().Run();
        }

        /// <summary>
        /// Builds web host
        /// </summary>
        /// <param name="args">Arguments</param>
        /// <returns>App</returns>
        public static IWebHostBuilder BuildWebHost(string[] args) =>
             WebHost.CreateDefaultBuilder(args)
                 .UseStartup<Startup>()
                 .UseContentRoot(Directory.GetCurrentDirectory())
                 .ConfigureAppConfiguration((builderContext, config) =>
                 {
                     var env = builderContext.HostingEnvironment;
                     config.AddJsonFile("appsettings.json", optional: false)
                     .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);
                     var configBuilder = config.Build();
                     config.Add(new TsmtConfigurationSource<ConfigParameterConstants>(env.EnvironmentName, configBuilder["AWSRegion"].ToString()));
                     config.AddEnvironmentVariables();
                 })
                 .ConfigureLogging((hostingContext, builder) =>
                 {
                     builder.AddConfiguration(hostingContext.Configuration.GetSection("Logging"));
                     builder.ClearProviders();
                 })
            .UseNLog();
    }
}