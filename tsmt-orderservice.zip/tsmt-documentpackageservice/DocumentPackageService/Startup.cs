﻿// <copyright file="Startup.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Reflection;
   using Amazon.S3;
   using Autofac;
   using Autofac.Extensions.DependencyInjection;
   using AutoMapper;
   using DocumentPackageService.Common.Filters;
   using DocumentPackageService.Common.Middlewares;
   using DocumentPackageService.Configurations.AutofacModules;
   using DocumentPackageService.Configurations.AutoMapperConfiguration;
   using DocumentPackageService.Core.Services;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Builder;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.Mvc.Authorization;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.OpenApi.Models;
   using NLog.Web;
   using Okta.AspNetCore;
   using TSMT.Settings;

   /// <summary>
   /// Startup
   /// </summary>
   public class Startup
   {
      private readonly string repositoryTag;

      /// <summary>
      /// Initializes a new instance of the <see cref="Startup"/> class.
      /// </summary>
      /// <param name="configuration">Configuration</param>
      /// <param name="env">Hosting environment</param>
      public Startup(IConfiguration configuration, IWebHostEnvironment env)
      {
         this.Configuration = configuration;
         this.HostingEnvironment = env;
         if (!env.EnvironmentName.Contains("UnitTest"))
         {
            NLogBuilder.ConfigureNLog($"nlog.{env.EnvironmentName}.config");
         }

         this.repositoryTag = Environment.GetEnvironmentVariable("REPOSITORY_TAG");
         if (string.IsNullOrWhiteSpace(this.repositoryTag))
         {
            this.repositoryTag = "localhost";
         }
      }

      /// <summary>
      /// Gets gets or sets configuration
      /// </summary>
      public IConfiguration Configuration { get; }

      /// <summary>
      /// Gets the hosting environment.
      /// </summary>
      public IWebHostEnvironment HostingEnvironment { get; }

      /// <summary>
      /// This method gets called by the runtime. Use this method to add services to the container.
      /// </summary>
      /// <param name="services">Services</param>
      /// <returns>Autofac service</returns>
      public IServiceProvider ConfigureServices(IServiceCollection services)
      {
         // Add framework services.
         services.AddHttpContextAccessor();

         // Add framework services.
         services.AddMvc(options =>
         {
            AuthorizationPolicy policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
            options.Filters.Add(new AuthorizeFilter(policy));
            options.Filters.Add(typeof(HttpGlobalExceptionFilter));
         }).AddControllersAsServices().AddNewtonsoftJson();

         services.Configure<TSMTSettings>(this.Configuration);
         services.AddAWSService<IAmazonS3>(ServiceLifetime.Transient);
         services.AddHostedService<FileGeneratedBackgroundService>();

         // Add framework services.
         services.AddSwaggerGen(options =>
         {
#pragma warning disable SA1118 // Parameter must not span multiple lines
            options.SwaggerDoc("v1", new OpenApiInfo
            {
               Title = $"Document Package Service HTTP API ({this.repositoryTag})",
               Version = "v1",
               Description = $"The Document Package Service HTTP API.  Deployment tag: {this.repositoryTag}"
            });

            OpenApiSecurityScheme apiKeyScheme = new OpenApiSecurityScheme()
            {
               Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
               Name = "Authorization",
               In = ParameterLocation.Header,
               Type = SecuritySchemeType.ApiKey,
               Scheme = "Bearer",
               BearerFormat = "JWT"
            };
            options.AddSecurityDefinition("Bearer", apiKeyScheme);
            options.AddSecurityRequirement(new OpenApiSecurityRequirement()
            {
                  {
                     new OpenApiSecurityScheme
                     {
                        Reference = new OpenApiReference
                        {
                           Type = ReferenceType.SecurityScheme,
                           Id = "Bearer",
                        },
                        Scheme = "OAuth2",
                        Name = "Bearer",
                        In = ParameterLocation.Header
                     }, new List<string>()
                  }
            });
            //// Set the comments path for the Swagger JSON and UI.
            var xmlFile = $"{Assembly.GetEntryAssembly().GetName().Name}.xml";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            options.IncludeXmlComments(xmlPath);
         });

         services.AddAuthentication(options =>
         {
            options.DefaultAuthenticateScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultChallengeScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultSignInScheme = OktaDefaults.ApiAuthenticationScheme;
         })
         .AddOktaWebApi(new OktaWebApiOptions()
         {
            OktaDomain = this.Configuration["Okta:OktaDomain"],
            AuthorizationServerId = this.Configuration["Okta:OktaAuthorizationServerID"]
         });

         services.AddCors(options =>
         {
            options.AddPolicy(
                "CorsPolicy",
                builder => builder.AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader()
                .WithExposedHeaders("Content-Disposition"));
         });

         services.AddApiVersioning();

         services.AddOptions();

         services.AddAutoMapper(typeof(AutoMapperProfile));

         // configure autofac
         var container = new ContainerBuilder();
         container.Populate(services);

         // The mediator module uses the pipeline, notification and Request/Response Command handler
         // This is stored as a separate Module
         container.RegisterModule(new MediatorModule());

         return new AutofacServiceProvider(container.Build());
      }

      /// <summary>
      /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
      /// </summary>
      /// <param name="app">Application builder</param>
      public void Configure(IApplicationBuilder app)
      {
         var pathBase = this.Configuration["PATH_BASE"];

         if (!string.IsNullOrWhiteSpace(pathBase))
         {
            app.UsePathBase(pathBase);
         }

         app.UseMiddleware<LoggerMiddleware>();
         app.UseRouting();
         app.UseCors("CorsPolicy");
         app.UseAuthentication();
         app.UseAuthorization();
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseDrAddressIdResolver();
            appBuilder.UseVPDAuthenticator();
         });

#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
         app.Map("/liveness", lapp => lapp.Run(async ctx => ctx.Response.StatusCode = 200));
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously

         app.UseEndpoints(endpoints =>
         {
            endpoints.MapControllers();
         });

         app.UseSwagger()
           .UseSwaggerUI(c =>
           {
              c.SwaggerEndpoint($"{(!string.IsNullOrWhiteSpace(pathBase) ? pathBase : string.Empty)}/swagger/v1/swagger.json", "DocumentPackageService.API V1");
           });
      }
   }
}
