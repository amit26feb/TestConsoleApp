﻿// <copyright file="DocumentPackageController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Controllers
{
   using System.Collections.Generic;
   using System.Net;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// DocumentPackageController
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobid}/[controller]")]
   [Authorize]
   public class DocumentPackageController : Controller
   {
      private readonly ILogger<DocumentPackageController> logger;
      private readonly IMediator mediator;
      private readonly IDocumentPackageService documentPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageController"/> class.
      /// </summary>
      /// <param name="mediator">Document package mediator</param>
      /// <param name="logger">Document package logger</param>
      /// <param name="documentPackageService">Document Package Service Interface</param>
      public DocumentPackageController(IMediator mediator, ILogger<DocumentPackageController> logger, IDocumentPackageService documentPackageService)
      {
         this.mediator = mediator;
         this.logger = logger;
         this.documentPackageService = documentPackageService;
      }

      /// <summary>
      /// Get all document packages detail
      /// </summary>
      /// <param name="jobId">the job id value</param>
      /// <param name="searchtext">The search keyword related to document package</param>
      /// <param name="sortby">The sort order of the result set</param>
      /// <returns>Document packages detail list</returns>
      [HttpGet]
      [Route("GetDocumentPackages")]
      [ProducesResponseType(typeof(IEnumerable<DocumentPackageSummaryViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetDocumentPackages([FromRoute(Name = "jobid")] int jobId, [FromQuery(Name = "searchText")]string searchtext, [FromQuery(Name = "sortBy")]string sortby)
      {
         if (jobId > 0)
         {
            IEnumerable<DocumentPackageSummaryViewModel> packageDetails = await this.documentPackageService.GetDocumentPackages(jobId, searchtext, sortby);
            return packageDetails != null ? (IActionResult)this.Ok(packageDetails) : (IActionResult)this.NoContent();
         }
         else
         {
            string error = $"Invalid request - jobId must be greater than 0.";
            this.logger.LogError(error);
            return this.BadRequest(error);
         }
      }

      /// <summary>
      /// Creates a document package
      /// </summary>
      /// <param name="request">Insert request payload</param>
      /// <returns>Returns the create document package view model.</returns>
      [HttpPost]
      [ProducesResponseType(typeof(DocPackageViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> Create([FromBody]DocPackageViewModel request)
      {
         string message = string.Empty;
         if (request != null)
         {
            var createDocumentPackageCommand = new CreateDocumentPackageCommand(request);
            var commandResult = await this.mediator.Send(createDocumentPackageCommand);

            if (commandResult != null && commandResult.Package != null && commandResult.Package.DocumentPackageId > 0)
            {
               this.logger.LogTrace($"Document package has been created successfully.");
               return this.Ok(commandResult);
            }

            message = $"Unexpected error occurred while creating the document package.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
         else
         {
            message = $"Invalid request - Request parameter can not be null.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Update the existing document package
      /// </summary>
      /// <param name="request">Update request payload</param>
      /// <param name="docPackageId">Docuent package id</param>
      /// <returns>Returns the updated document package view model.</returns>
      [Route("{docPackageId}")]
      [HttpPut]
      [ProducesResponseType(typeof(DocPackageViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> Update([FromBody]DocPackageViewModel request, int docPackageId)
      {
         string message = $"Invalid request - Please check the request parameter.";
         if (request != null && docPackageId > 0 && docPackageId == request.Package.DocumentPackageId)
         {
            var updateDocumentPackageCommand = new UpdateDocumentPackageCommand(request);
            var commandResult = await this.mediator.Send(updateDocumentPackageCommand);

            if (commandResult != null && commandResult.Package != null && commandResult.Package.DocumentPackageId > 0)
            {
               this.logger.LogTrace($"Document package has been created successfully.");
               return this.Ok(commandResult);
            }

            message = $"Unexpected error occurred while updating the document package.";
         }

         this.logger.LogError(message);
         return this.BadRequest(message);
      }

      /// <summary>
      /// Get Document Package Details
      /// </summary>
      /// <param name="docPkgId">The reference id of the document package</param>
      /// <returns>Document Package Details</returns>
      [HttpGet]
      [Route("{docPkgId}")]
      [ProducesResponseType(typeof(DocPkgDetailsViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetDocumentPackageDetails(int docPkgId)
      {
        string message = string.Empty;
         if (docPkgId > 0)
         {
            var packageDetails = await this.documentPackageService.GetDocPkgDetails(docPkgId);
            return packageDetails != null ? (IActionResult)this.Ok(packageDetails) : (IActionResult)this.NoContent();
         }
         else
         {
            message = $"Invalid request - Request parameter can not be 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }
   }
}
