﻿// <copyright file="DocumentPackageFileController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Controllers
{
   using System.Collections.Generic;
   using System.IO;
   using System.Linq;
   using System.Net;
   using System.Net.Mime;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Document Package File Controller
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/DocumentPackages/{documentPackageId}/Files")]
   [Authorize]
   public class DocumentPackageFileController : Controller
   {
      private readonly ILogger<DocumentPackageFileController> logger;
      private readonly IMediator mediator;
      private readonly IDocumentPackageService documentPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentPackageFileController"/> class.
      /// </summary>
      /// <param name="logger">Error logging</param>
      /// <param name="mediator">Mediator</param>
      /// <param name="documentPackageService">Document package service</param>
      public DocumentPackageFileController(ILogger<DocumentPackageFileController> logger, IMediator mediator, IDocumentPackageService documentPackageService)
      {
         this.logger = logger;
         this.mediator = mediator;
         this.documentPackageService = documentPackageService;
      }

      /// <summary>
      /// Get a listing of files for the document package
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentPackageId">The reference id of the document package</param>
      /// <returns>Enumeration of file history data</returns>
      [HttpGet]
      [Route("")]
      [ProducesResponseType(typeof(IEnumerable<DocumentPackageFileHistoryViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> GetFileHistories(int jobId, int documentPackageId)
      {
         if (jobId > 0 && documentPackageId > 0)
         {
            IEnumerable<DocumentPackageFileHistoryViewModel> histories = await this.documentPackageService.GetDocumentPackageFileHistories(jobId, documentPackageId);
            return histories?.Any() == true ? (IActionResult)this.Ok(histories) : this.NotFound();
         }
         else
         {
            string message = "Invalid request: jobId must be > 0 and documentPackageId must be > 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Get the last generated file for the document package
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentPackageId">The reference id of the document package</param>
      /// <returns>File history data</returns>
      [HttpGet]
      [Route("MostRecentGeneratedFile")]
      [ProducesResponseType(typeof(DocumentPackageMostRecentFileHistoryViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> GetMostRecentlyGeneratedFileHistory(int jobId, int documentPackageId)
      {
         if (jobId > 0 && documentPackageId > 0)
         {
            DocumentPackageMostRecentFileHistoryViewModel history = await this.documentPackageService.GetMostRecentlyGeneratedDocumentPackageFileHistory(jobId, documentPackageId);
            return history != null ? (IActionResult)this.Ok(history) : this.NotFound();
         }
         else
         {
            string message = "Invalid request: jobId must be > 0 and documentPackageId must be > 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Update the document package file's status
      /// </summary>
      /// <param name="updateModel">Properties to update package file status</param>
      /// <returns>Task representing completion</returns>
      [Route("{fileVersion}/Status/{status}")]
      [HttpPut]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> SetStatus([FromRoute] DocumentPackageFileStatusViewModel updateModel)
      {
         if (updateModel.DocumentPackageId > 0 && updateModel.FileVersion >= 0)
         {
            var updateDocumentPackageCommand = new UpdateDocumentPackageFileCommand(updateModel);
            var isUpdated = await this.mediator.Send(updateDocumentPackageCommand);

            if (isUpdated)
            {
               return this.NoContent();
            }
            else
            {
               string message = "Could not update document package file status.";
               this.logger.LogError(message);
               return this.BadRequest(message);
            }
         }
         else
         {
            string message = $"Invalid request: docPkgId must be > 0 and fileVersion must be >= 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Update the document package filename
      /// </summary>
      /// <param name="documentPackageId">The reference id of the document package</param>
      /// <param name="fileVersion">Version for the document package file</param>
      /// <param name="filename">Filename to use for the document package file (do not include extension)</param>
      /// <returns>Task representing completion</returns>
      [Route("{fileVersion}/Filename")]
      [HttpPut]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> SetFilename(int documentPackageId, int fileVersion, [FromBody] string filename)
      {
         if (documentPackageId > 0 && fileVersion > 0 && !string.IsNullOrWhiteSpace(filename))
         {
            bool isUpdated = await this.documentPackageService.UpdateDocumentPackageFilename(documentPackageId, fileVersion, filename);
            if (isUpdated)
            {
               return this.NoContent();
            }
            else
            {
               string message = $"Update filename: could not update the filename for docPackageId: {documentPackageId} and version {fileVersion}.";
               this.logger.LogError(message);
               return this.BadRequest(message);
            }
         }
         else
         {
            string message = "Update filename: documentPackageId and version must be > 0 and filename must be populated.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Updates filestore version information for document package file.
      /// </summary>
      /// <param name="documentPackageId">The reference id of the document package</param>
      /// <param name="filestoreVersionId">Filestore version id for the document package file</param>
      /// <returns>Persisted document package filestore version info</returns>
      [Route("~/api/v{version:apiVersion}/{drAddressId}/DocumentPackages/{documentPackageId}/FilestoreVersion")]
      [HttpPut]
      [ProducesResponseType(typeof(DocumentPackageFilestoreViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> SetFilestoreVersion(int documentPackageId, [FromBody] string filestoreVersionId)
      {
         if (documentPackageId > 0)
         {
            DocumentPackageFilestoreViewModel documentPackageFilestoreInfo = await this.documentPackageService.UpdateFilestoreVersionId(documentPackageId, filestoreVersionId);
            if (documentPackageFilestoreInfo == null)
            {
               return this.NoContent();
            }
            else
            {
               return this.Ok(documentPackageFilestoreInfo);
            }
         }
         else
         {
            string message = "Update filestore version: documentPackageId must be > 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Get the status of the document package file for the given version.
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentPackageId">The reference id of the document package</param>
      /// <param name="fileVersion">The version of the file</param>
      /// <returns>Document Package File Status and generated date</returns>
      [HttpGet]
      [Route("{fileVersion}/Status")]
      [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> GetStatus(int jobId, int documentPackageId, int fileVersion)
      {
         string message = string.Empty;
         if (jobId > 0 && documentPackageId > 0 && fileVersion >= 0)
         {
            DocumentPackageFileStatusModel status = await this.documentPackageService.GetDocumentFileStatus(jobId, documentPackageId, fileVersion);
            return status != null ? (IActionResult)this.Ok(status) : this.NotFound();
         }
         else
         {
            message = "Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Gets returns a stream of the document for the given jobId/documentpackageid/fileVersion.
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentPackageId">The reference id of the document package</param>
      /// <param name="fileVersion">The version of the file</param>
      /// <returns>Document package file stream</returns>
      [HttpGet]
      [Route("{fileVersion}/Download")]
      [ProducesResponseType(typeof(FileStreamResult), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> Download(int jobId, int documentPackageId, int fileVersion)
      {
         string message = string.Empty;
         if (jobId > 0 && documentPackageId > 0 && fileVersion >= 0)
         {
            KeyValuePair<string, Stream>? downloadInfo = await this.documentPackageService.GetDocumentFileStream(jobId, documentPackageId, fileVersion);
            if (downloadInfo.HasValue && downloadInfo.Value.Value != null)
            {
               // Prompt the user for download
               ContentDisposition cd = new ContentDisposition { FileName = System.Uri.EscapeDataString(downloadInfo.Value.Key), Inline = false, };
               this.Response?.Headers.Add("Content-Disposition", cd.ToString());
               return new FileStreamResult(downloadInfo.Value.Value, CustomContentTypes.WordDoc) { FileDownloadName = downloadInfo.Value.Key };
            }
            else
            {
               return this.BadRequest("Could not retrieve document.");
            }
         }
         else
         {
            message = "Invalid request: jobId must be > 0 and documentPackageId must be > 0 and fileVersion must be >= 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Gets returns a stream of the most recent document for the given jobId/documentpackageid.
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentPackageId">The reference id of the document package</param>
      /// <returns>Document package file stream</returns>
      [HttpGet]
      [Route("Download")]
      [ProducesResponseType(typeof(FileStreamResult), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> DownloadMostRecent(int jobId, int documentPackageId)
      {
         string message = string.Empty;
         if (jobId > 0 && documentPackageId > 0)
         {
            KeyValuePair<string, Stream>? downloadInfo = await this.documentPackageService.GetDocumentFileStream(jobId, documentPackageId, null);
            if (downloadInfo.HasValue && downloadInfo.Value.Value != null)
            {
               // Prompt the user for download
               ContentDisposition cd = new ContentDisposition { FileName = System.Uri.EscapeDataString(downloadInfo.Value.Key), Inline = false, };
               this.Response?.Headers.Add("Content-Disposition", cd.ToString());
               return new FileStreamResult(downloadInfo.Value.Value, CustomContentTypes.WordDoc) { FileDownloadName = downloadInfo.Value.Key };
            }
            else
            {
               return this.BadRequest("Could not retrieve document.");
            }
         }
         else
         {
            message = "Invalid request: jobId must be > 0 and documentPackageId must be > 0.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Get a list of document package files
      /// </summary>
      /// <param name="jobId">The reference id of the job</param>
      /// <param name="documentTypeId">The reference id of the document type</param>
      /// <returns>Document package files detail list</returns>
      [HttpGet]
      [Route("~/api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/PackageDocuments/{documentTypeId}")]
      [ProducesResponseType(typeof(DocumentPackageFileViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> GetPackageDocument([FromRoute(Name = "jobId")] int jobId, [FromRoute(Name = "documentTypeId")] int documentTypeId)
      {
         if (jobId > 0 && documentTypeId > 0)
         {
            IEnumerable<DocumentPackageFileViewModel> documentPackageFileViewModel = await this.documentPackageService.GetPackageDocument(jobId, documentTypeId);
            return documentPackageFileViewModel?.Any() == true ? (IActionResult)this.Ok(documentPackageFileViewModel) : this.NotFound();
         }

         string message = "Invalid request: jobId must be > 0 and documentTypeId must be > 0.";
         this.logger.LogInformation(message);
         return this.BadRequest(message);
      }
   }
}
