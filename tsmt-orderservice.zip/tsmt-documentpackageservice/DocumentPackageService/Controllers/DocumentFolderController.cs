﻿// <copyright file="DocumentFolderController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Controllers
{
   using System.Collections.Generic;
   using System.Net;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Document folder controller
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobid}/[controller]")]
   [Authorize]
   public class DocumentFolderController : Controller
   {
      private readonly ILogger<DocumentFolderController> logger;
      private readonly IMediator mediator;
      private readonly IDocumentFolderService documentFolderService;

      /// <summary>
      /// Initializes a new instance of the <see cref="DocumentFolderController"/> class.
      /// </summary>
      /// <param name="mediator">Document folder mediator</param>
      /// <param name="logger">Document folder logger</param>
      /// <param name="documentFolderService">Document folder service</param>
      public DocumentFolderController(IMediator mediator, ILogger<DocumentFolderController> logger, IDocumentFolderService documentFolderService)
      {
         this.mediator = mediator;
         this.logger = logger;
         this.documentFolderService = documentFolderService;
      }

      /// <summary>
      /// Creates a document folder
      /// </summary>
      /// <param name="request">Insert request payload</param>
      /// <returns>Document folders</returns>
      [HttpPost]
      [ProducesResponseType(typeof(DocumentFolderViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> Create([FromBody] DocumentFolderViewModel request)
      {
         string message = string.Empty;
         if (request != null)
         {
            var createDocumentFolderCommand = new CreateDocumentFolderCommand(request);
            var commandResult = await this.mediator.Send(createDocumentFolderCommand);

            if (commandResult != null)
            {
               this.logger.LogTrace($"Document folder has been created successfully.");
               return this.Ok(commandResult);
            }

            message = $"Unexpected error occurred while creating the document folder.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }

         message = $"Invalid request - Request parameter can not be null.";
         this.logger.LogError(message);
         return this.BadRequest(message);
      }

      /// <summary>
      /// Get Folder Details
      /// </summary>
      /// <param name="jobId">Get the folder details based on job id</param>
      /// <returns>Document folders</returns>
      [HttpGet]
      [ProducesResponseType(typeof(DocumentFolderViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetFolders([FromRoute(Name = "jobid")] int jobId)
      {
         string message = string.Empty;
         if (jobId > 0)
         {
            IEnumerable<DocumentFolderViewModel> folderDetails = await this.documentFolderService.GetFolders(jobId);
            return folderDetails != null ? (IActionResult)this.Ok(folderDetails) : (IActionResult)this.NoContent();
         }

         message = $"Invalid request - Request parameter can not be 0.";
         return this.BadRequest(message);
      }
   }
}
