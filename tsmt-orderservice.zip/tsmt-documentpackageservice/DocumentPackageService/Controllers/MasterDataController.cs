﻿// <copyright file="MasterDataController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Controllers
{
   using System.Collections.Generic;
   using System.Net;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// MasterDataController
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/[controller]")]
   [Authorize]
   public class MasterDataController : Controller
   {
      private readonly ILogger<MasterDataController> logger;
      private readonly IMasterDataService masterDataService;

      /// <summary>
      /// Initializes a new instance of the <see cref="MasterDataController"/> class.
      /// </summary>
      /// <param name="masterDataService">masterDataService</param>
      /// <param name="logger">logger</param>
      public MasterDataController(IMasterDataService masterDataService, ILogger<MasterDataController> logger)
      {
         this.masterDataService = masterDataService;
         this.logger = logger;
      }

      /// <summary>
      /// Get all business stream
      /// </summary>
      /// <returns>string</returns>
      [HttpGet]
      [Route("BusinessStreams")]
      [ProducesResponseType(typeof(BusinessStreamViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetBusinessStreams()
      {
         var businessStreams = await this.masterDataService.GetBusinessStreams();
         this.logger.LogTrace("Returned business stream list.");
         return businessStreams != null ? (IActionResult)this.Ok(businessStreams) : (IActionResult)this.NoContent();
      }

      /// <summary>
      /// Get all document type
      /// </summary>
      /// <param name="docGroupId">Document group id / business stream id</param>
      /// <returns>string</returns>
      [HttpGet]
      [Route("Groups/{docGroupId}/DocumentTypes")]
      [ProducesResponseType(typeof(DocumentTypeViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetDocumentTypes(int docGroupId)
      {
         IEnumerable<DocumentTypeViewModel> documentTypes = null;
         if (docGroupId >= 0)
         {
            documentTypes = await this.masterDataService.GetDocumentTypes(docGroupId);
         }

         this.logger.LogTrace("Returned document type list.");
         return documentTypes != null ? (IActionResult)this.Ok(documentTypes) : (IActionResult)this.NoContent();
      }

      /// <summary>
      /// Get all legal entities
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>string</returns>
      [HttpGet]
      [Route("DocumentTypes/{docTypeId}/LegalEntities")]
      [ProducesResponseType(typeof(LegalEntityViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetLegalEntities(int docTypeId)
      {
         IEnumerable<LegalEntityViewModel> legalEntities = null;
         if (docTypeId > 0)
         {
            legalEntities = await this.masterDataService.GetLegalEntities(docTypeId);
         }

         this.logger.LogTrace("Returned legal entity list.");
         return legalEntities != null ? (IActionResult)this.Ok(legalEntities) : (IActionResult)this.NoContent();
      }

      /// <summary>
      /// Get all terms and conditions
      /// </summary>
      /// <param name="docTypeId">Document type id</param>
      /// <returns>Terms and conditions list</returns>
      [HttpGet]
      [Route("DocumentTypes/{docTypeId}/TermsAndConditions")]
      [ProducesResponseType(typeof(TermsAndConditionsViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetTermsAndConditions(int docTypeId)
      {
         var termsAndConditions = await this.masterDataService.GetTermsAndConditions(docTypeId);
         this.logger.LogTrace("Returned terms and conditions list.");
         return termsAndConditions != null ? (IActionResult)this.Ok(termsAndConditions) : (IActionResult)this.NoContent();
      }

      /// <summary>
      /// Get all job document type
      /// </summary>
      /// <returns>Job document type list</returns>
      [HttpGet]
      [Route("JobDocumentTypes")]
      [ProducesResponseType(typeof(JobDocumentTypeViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetJobDocumentType()
      {
         IEnumerable<JobDocumentTypeViewModel> fileTypes = await this.masterDataService.GetJobDocumentType();
         this.logger.LogTrace("Returned job document type list.");
         return fileTypes != null ? (IActionResult)this.Ok(fileTypes) : (IActionResult)this.NoContent();
      }
   }
}
