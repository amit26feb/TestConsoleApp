﻿// <copyright file="LegacyFilesController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Controllers
{
   using System.Collections.Generic;
   using System.Net;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.ViewModels;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Document folder controller
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobid}/[controller]")]
   [Authorize]
   public class LegacyFilesController : Controller
   {
      private readonly ILogger<LegacyFilesController> logger;
      private readonly ILegacyFileService legacyFileService;

      /// <summary>
      /// Initializes a new instance of the <see cref="LegacyFilesController"/> class.
      /// </summary>
      /// <param name="logger">Legacy files logger</param>
      /// <param name="legacyFileService">Legacy file service</param>
      public LegacyFilesController(ILogger<LegacyFilesController> logger, ILegacyFileService legacyFileService)
      {
         this.logger = logger;
         this.legacyFileService = legacyFileService;
      }

      /// <summary>
      /// Get Legacy Files for the job
      /// </summary>
      /// <param name="drAddressId">Dr Address Id</param>
      /// <param name="jobId">Job Id</param>
      /// <returns>Legacy Files</returns>
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<LegacyFileViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      public async Task<IActionResult> GetFiles([FromRoute(Name = "drAddressId")] int drAddressId, [FromRoute(Name = "jobid")] int jobId)
      {
         if (drAddressId > 0 && jobId > 0)
         {
            IEnumerable<LegacyFileViewModel> legacyFiles = await this.legacyFileService.GetLegacyFiles(drAddressId, jobId);
            return legacyFiles != null ? (IActionResult)this.Ok(legacyFiles) : (IActionResult)this.NoContent();
         }

         string message = "Invalid request - Dr Address Id and Job Id must be > 0.";
         this.logger.LogError(message);
         return this.BadRequest(message);
      }
   }
}
