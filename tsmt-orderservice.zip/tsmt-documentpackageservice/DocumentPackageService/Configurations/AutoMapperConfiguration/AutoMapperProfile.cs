﻿// <copyright file="AutoMapperProfile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Configurations.AutoMapperConfiguration
{
   using AutoMapper;
   using DocumentPackageService.Core.Models;
   using DocumentPackageService.Core.ViewModels;
   using Newtonsoft.Json;

   /// <summary>
   /// Class for auto mapper profile
   /// </summary>
   public class AutoMapperProfile : Profile
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="AutoMapperProfile"/> class.
      /// </summary>
      public AutoMapperProfile()
      {
         this.MapForViewing();
      }

      /// <summary>
      /// Maps the domain models to the view models that are used for viewing in UI
      /// </summary>
      private void MapForViewing()
      {
         this.CreateMap<DocumentGroupModel, BusinessStreamViewModel>()
                .ForMember(dest => dest.BusinessStreamId, opt => opt.MapFrom(src => src.DOC_GROUP_ID))
                .ForMember(dest => dest.BusinessStreamName, opt => opt.MapFrom(src => src.GROUP_NAME))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.STATUS))
                .ForMember(dest => dest.BusinessStreamAbstract, opt => opt.MapFrom(src => src.GROUP_ABSTRACT))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CREATED_BY_USER))
                .ForMember(dest => dest.CreatedOn, opt => opt.MapFrom(src => src.CREATED_DATE))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
                .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
                .ReverseMap();

         this.CreateMap<DocumentTypeModel, DocumentTypeViewModel>()
                .ForMember(dest => dest.DocumentTypeId, opt => opt.MapFrom(src => src.DOC_TYPE_ID))
                .ForMember(dest => dest.DocumentTypeName, opt => opt.MapFrom(src => src.DOC_TYPE_NAME))
                .ForMember(dest => dest.DocumentTypeShortName, opt => opt.MapFrom(src => src.DOC_TYPE_SHORT_NAME))
                .ForMember(dest => dest.DocumentGroupId, opt => opt.MapFrom(src => src.DOC_GROUP_ID))
                .ForMember(dest => dest.DocumentTypeSequenceNumber, opt => opt.MapFrom(src => src.DOC_TYPE_SEQ_NBR))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.STATUS))
                .ForMember(dest => dest.DocumentTypeAbstract, opt => opt.MapFrom(src => src.DOC_TYPE_ABSTRACT))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CREATED_BY_USER))
                .ForMember(dest => dest.CreatedOn, opt => opt.MapFrom(src => src.CREATED_DATE))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
                .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
                .ReverseMap();

         this.CreateMap<LegalEntityModel, LegalEntityViewModel>()
                .ForMember(dest => dest.LegalEntityId, opt => opt.MapFrom(src => src.LEGAL_ENTITY_ID))
                .ForMember(dest => dest.LegalEntityName, opt => opt.MapFrom(src => src.ENTITY_LONG_NAME))
                .ForMember(dest => dest.ShortName, opt => opt.MapFrom(src => src.ENTITY_SHORT_NAME))
                .ForMember(dest => dest.EntityAbstract, opt => opt.MapFrom(src => src.ENTITY_ABSTRACT))
                .ForMember(dest => dest.LongName, opt => opt.MapFrom(src => src.ENTITY_LONG_NAME))
                .ForMember(dest => dest.SequenceNumber, opt => opt.MapFrom(src => src.SEQUENCE_NBR))
                .ReverseMap();

         this.CreateMap<TermsAndConditionsModel, TermsAndConditionsViewModel>()
                .ForMember(dest => dest.TermsAndConditionsId, opt => opt.MapFrom(src => src.TERMS_COND_ID))
                .ForMember(dest => dest.TermsAndConditionsName, opt => opt.MapFrom(src => src.TERMS_COND_NAME))
                .ForMember(dest => dest.DocTypeId, opt => opt.MapFrom(src => src.DOC_TYPE_ID))
                .ForMember(dest => dest.FileLocation, opt => opt.MapFrom(src => src.FILE_LOCTION))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.TERMS_COND_DESCRIPTION))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CREATED_BY_USER))
                .ForMember(dest => dest.CreatedOn, opt => opt.MapFrom(src => src.CREATED_DATE))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
                .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
                .ForMember(dest => dest.SequenceNumber, opt => opt.MapFrom(src => src.SEQUENCE_NBR))
                .ForMember(dest => dest.DefaultInd, opt => opt.MapFrom(src => src.DEFAULT_IND))
                .ReverseMap();

         this.CreateMap<DocumentPackageViewModel, DocumentPackageModel>()
                .ForMember(dest => dest.CREATED_BY_USER, opt => opt.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CREATED_DATE, opt => opt.MapFrom(src => src.CreatedOn))
                .ForMember(dest => dest.PKG_DESCRIPTION, opt => opt.MapFrom(src => src.Description))
                .ForMember(dest => dest.DOC_TYPE_ID, opt => opt.MapFrom(src => src.DocumentTypeId))
                .ForMember(dest => dest.DOC_PKG_ID, opt => opt.MapFrom(src => src.DocumentPackageId))
                .ForMember(dest => dest.DR_ADDRESS_ID, opt => opt.MapFrom(src => src.DrAddressId))
                .ForMember(dest => dest.JOB_ID, opt => opt.MapFrom(src => src.JobId))
                .ForMember(dest => dest.PKG_NAME, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.LAST_MODIFIED_USER, opt => opt.MapFrom(src => src.UpdatedBy))
                .ForMember(dest => dest.LAST_MODIFIED_DATE, opt => opt.MapFrom(src => src.UpdatedOn))
                .ReverseMap();

         this.CreateMap<DocumentPackageFileViewModel, DocumentPackageFileModel>()
                .ForMember(dest => dest.ADDITIONAL_INFO, opt => opt.MapFrom(src => JsonConvert.SerializeObject(src.AdditionalInfo)))
                .ForMember(dest => dest.BID_ALTERNATE_ID, opt => opt.MapFrom(src => src.BidAlternateId))
                .ForMember(dest => dest.GENERATED_BY_USER, opt => opt.MapFrom(src => src.GeneratedBy))
                .ForMember(dest => dest.GENERATED_DATE, opt => opt.MapFrom(src => src.GeneratedDate))
                .ForMember(dest => dest.DOC_PKG_ID, opt => opt.MapFrom(src => src.DocumentPackageId))
                .ForMember(dest => dest.LEGAL_ENTITY_ID, opt => opt.MapFrom(src => src.LegalEntityId))
                .ForMember(dest => dest.FILE_NAME, opt => opt.MapFrom(src => src.FileName))
                .ForMember(dest => dest.FILE_LOCATION, opt => opt.MapFrom(src => src.FileLocation))
                .ForMember(dest => dest.STATUS, opt => opt.MapFrom(src => src.Status))
                .ForMember(dest => dest.TERMS_COND_ID, opt => opt.MapFrom(src => src.TermsAndConditionsId))
                .ForMember(dest => dest.LAST_MODIFIED_USER, opt => opt.MapFrom(src => src.UpdatedBy))
                .ForMember(dest => dest.LAST_MODIFIED_DATE, opt => opt.MapFrom(src => src.UpdatedOn))
                .ForMember(dest => dest.FILE_VERSION, opt => opt.MapFrom(src => src.Version))
                .ForMember(dest => dest.DR_ADDRESS_ID, opt => opt.MapFrom(src => src.DrAddressId))
                .ForMember(dest => dest.JOB_ID, opt => opt.MapFrom(src => src.JobId))
                .ForMember(dest => dest.PROPOSAL_NBR, opt => opt.MapFrom(src => src.ProposalNumber))
                .ForMember(dest => dest.GENERATED_INFO, opt => opt.MapFrom(src => src.GeneratedInfo))
                .ForMember(dest => dest.DOC_TYPE_SHORT_NAME, opt => opt.MapFrom(src => src.DocTypeShortName));

         this.CreateMap<DocumentPackageModel, DocumentPackageViewModel>()
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CREATED_BY_USER))
                .ForMember(dest => dest.CreatedOn, opt => opt.MapFrom(src => src.CREATED_DATE))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.PKG_DESCRIPTION))
                .ForMember(dest => dest.DocumentTypeId, opt => opt.MapFrom(src => src.DOC_TYPE_ID))
                .ForMember(dest => dest.DocumentPackageId, opt => opt.MapFrom(src => src.DOC_PKG_ID))
                .ForMember(dest => dest.DrAddressId, opt => opt.MapFrom(src => src.DR_ADDRESS_ID))
                .ForMember(dest => dest.JobId, opt => opt.MapFrom(src => src.JOB_ID))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.PKG_NAME))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
                .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
                .ReverseMap();

         this.CreateMap<DocumentPackageFileModel, DocumentPackageFileViewModel>()
                .ForMember(dest => dest.AdditionalInfo, opt => opt.MapFrom(src => JsonConvert.DeserializeObject<AdditionalInfoViewModel>(src.ADDITIONAL_INFO)))
                .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
                .ForMember(dest => dest.GeneratedBy, opt => opt.MapFrom(src => src.GENERATED_BY_USER))
                .ForMember(dest => dest.GeneratedDate, opt => opt.MapFrom(src => src.GENERATED_DATE))
                .ForMember(dest => dest.DocumentPackageId, opt => opt.MapFrom(src => src.DOC_PKG_ID))
                .ForMember(dest => dest.LegalEntityId, opt => opt.MapFrom(src => src.LEGAL_ENTITY_ID))
                .ForMember(dest => dest.FileName, opt => opt.MapFrom(src => src.FILE_NAME))
                .ForMember(dest => dest.FileLocation, opt => opt.MapFrom(src => src.FILE_LOCATION))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.STATUS))
                .ForMember(dest => dest.TermsAndConditionsId, opt => opt.MapFrom(src => src.TERMS_COND_ID))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
                .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
                .ForMember(dest => dest.Version, opt => opt.MapFrom(src => src.FILE_VERSION))
                .ForMember(dest => dest.DrAddressId, opt => opt.MapFrom(src => src.DR_ADDRESS_ID))
                .ForMember(dest => dest.JobId, opt => opt.MapFrom(src => src.JOB_ID))
                .ForMember(dest => dest.ProposalNumber, opt => opt.MapFrom(src => src.PROPOSAL_NBR))
                .ForMember(dest => dest.GeneratedInfo, opt => opt.MapFrom(src => src.GENERATED_INFO))
                .ForMember(dest => dest.DocTypeShortName, opt => opt.MapFrom(src => src.DOC_TYPE_SHORT_NAME));

         this.CreateMap<DocPkgDetailsModel, DocumentPackageViewModel>()
                .ForMember(dest => dest.DocumentPackageId, opt => opt.MapFrom(src => src.DOC_PKG_ID))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
                .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.PKG_NAME))
                .ForMember(dest => dest.DrAddressId, opt => opt.MapFrom(src => src.DR_ADDRESS_ID))
                .ForMember(dest => dest.JobId, opt => opt.MapFrom(src => src.JOB_ID))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.PKG_DESCRIPTION))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CREATED_BY_USER))
                .ForMember(dest => dest.CreatedOn, opt => opt.MapFrom(src => src.CREATED_DATE))
                .ForMember(dest => dest.DocumentTypeId, opt => opt.MapFrom(src => src.DOC_TYPE_ID))
                .ForMember(dest => dest.DocumentTypeName, opt => opt.MapFrom(src => src.DOC_TYPE_NAME))
                .ReverseMap();

         this.CreateMap<DocPkgDetailsModel, DocPkgDetailsViewModel>()
                .IncludeBase<DocPkgDetailsModel, DocumentPackageViewModel>()
                .ReverseMap();

         this.CreateMap<DocPkgDetailsModel, DocumentPackageFileViewModel>()
               .ForMember(dest => dest.DrAddressId, opt => opt.MapFrom(src => src.DR_ADDRESS_ID))
               .ForMember(dest => dest.JobId, opt => opt.MapFrom(src => src.JOB_ID))
               .ForMember(dest => dest.DocumentPackageFileId, opt => opt.MapFrom(src => src.DOC_PKG_FILE_ID))
               .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.FILE_LAST_MODIFIED_DATE))
               .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.FILE_LAST_MODIFIED_USER))
               .ForMember(dest => dest.Version, opt => opt.MapFrom(src => src.FILE_VERSION))
               .ForMember(dest => dest.FileName, opt => opt.MapFrom(src => src.FILE_NAME))
               .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
               .ForMember(dest => dest.FileLocation, opt => opt.MapFrom(src => src.FILE_LOCATION))
               .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.STATUS))
               .ForMember(dest => dest.GeneratedInfo, opt => opt.MapFrom(src => src.GENERATED_INFO))
               .ForMember(dest => dest.GeneratedBy, opt => opt.MapFrom(src => src.GENERATED_BY_USER))
               .ForMember(dest => dest.GeneratedDate, opt => opt.MapFrom(src => src.GENERATED_DATE))
               .ForMember(dest => dest.AdditionalInfo, opt => opt.MapFrom(src => JsonConvert.DeserializeObject<AdditionalInfoViewModel>(src.ADDITIONAL_INFO)))
               .ForMember(dest => dest.DocumentPackageId, opt => opt.MapFrom(src => src.DOC_PKG_ID))
               .ForMember(dest => dest.ProposalNumber, opt => opt.MapFrom(src => src.PROPOSAL_NBR))
               .ReverseMap();

         this.CreateMap<DocPkgDetailsModel, DocPkgFileViewModel>()
            .IncludeBase<DocPkgDetailsModel, DocumentPackageFileViewModel>()
               .ForMember(dest => dest.LegalEntityId, opt => opt.MapFrom(src => src.LEGAL_ENTITY_ID))
               .ForMember(dest => dest.LegalEntityLongName, opt => opt.MapFrom(src => src.ENTITY_LONG_NAME))
               .ForMember(dest => dest.LegalEntityShortName, opt => opt.MapFrom(src => src.ENTITY_SHORT_NAME))
               .ForMember(dest => dest.TermsAndConditionsId, opt => opt.MapFrom(src => src.TERMS_COND_ID))
               .ForMember(dest => dest.TermsConditionsName, opt => opt.MapFrom(src => src.TERMS_COND_NAME))
               .ForMember(dest => dest.TCFileLocation, opt => opt.MapFrom(src => src.TC_FILE_LOCATION))
               .ReverseMap();

         this.CreateMap<DocumentPackageSummaryViewModel, DocumentPackageSummaryModel>()
               .ForMember(dest => dest.CREATED_BY_USER, opt => opt.MapFrom(src => src.CreatedUser))
               .ForMember(dest => dest.CREATED_DATE, opt => opt.MapFrom(src => src.CreatedDate))
               .ForMember(dest => dest.DESCRIPTION, opt => opt.MapFrom(src => src.Description))
               .ForMember(dest => dest.DOCUMENT_TYPE, opt => opt.MapFrom(src => src.DocumentType))
               .ForMember(dest => dest.DOC_PKG_ID, opt => opt.MapFrom(src => src.DocPkgId))
               .ForMember(dest => dest.DR_ADDRESS_ID, opt => opt.MapFrom(src => src.DrAddressId))
               .ForMember(dest => dest.FILE_VERSION, opt => opt.MapFrom(src => src.FileVersion))
               .ForMember(dest => dest.LAST_GENERATED_VERSION, opt => opt.MapFrom(src => src.LastGeneratedFileVersion))
               .ForMember(dest => dest.STATUS, opt => opt.MapFrom(src => src.Status))
               .ForMember(dest => dest.NAME, opt => opt.MapFrom(src => src.Name))
               .ForMember(dest => dest.LAST_MODIFIED_USER, opt => opt.MapFrom(src => src.ModifiedUser))
               .ForMember(dest => dest.LAST_MODIFIED_DATE, opt => opt.MapFrom(src => src.ModifiedDate))
               .ForMember(dest => dest.FILE_GENERATED_BY_USER, opt => opt.MapFrom(src => src.FileGeneratedByUser))
               .ForMember(dest => dest.FILE_GENERATED_DATE, opt => opt.MapFrom(src => src.FileGeneratedDate))
               .ForMember(dest => dest.FILE_UPLOADED_BY_USER, opt => opt.MapFrom(src => src.FileUploadedByUser))
               .ForMember(dest => dest.FILE_UPLOADED_DATE, opt => opt.MapFrom(src => src.FileUploadedDate))
               .ForMember(dest => dest.LAST_UPLOADED_VERSION, opt => opt.MapFrom(src => src.LastUploadedFileVersion))
               .ForMember(dest => dest.DOC_TYPE_ID, opt => opt.MapFrom(src => src.DocTypeId))
               .ReverseMap();

         this.CreateMap<DocumentPackageFileHistoryModel, DocumentPackageFileHistoryViewModel>()
            .ForMember(dest => dest.FileVersion, opt => opt.MapFrom(src => src.FILE_VERSION))
            .ForMember(dest => dest.FileName, opt => opt.MapFrom(src => src.FILE_NAME))
            .ForMember(dest => dest.ModifiedDate, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
            .ForMember(dest => dest.LastModifiedByUser, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
            .ForMember(dest => dest.GeneratedDate, opt => opt.MapFrom(src => src.GENERATED_DATE))
            .ForMember(dest => dest.GeneratedByUser, opt => opt.MapFrom(src => src.GENERATED_BY_USER))
            .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.STATUS))
            .ForMember(dest => dest.Error, opt => opt.MapFrom(src => src.GetGenerationErrors()));

         this.CreateMap<JobDocumentTypeModel, JobDocumentTypeViewModel>()
                .ForMember(dest => dest.JobDocumentTypeId, opt => opt.MapFrom(src => src.JOB_DOCUMENT_TYPE_ID))
                .ForMember(dest => dest.TypeName, opt => opt.MapFrom(src => src.TYPE_NAME))
                .ForMember(dest => dest.SequenceNumber, opt => opt.MapFrom(src => src.TYPE_SEQ_NBR))
                .ForMember(dest => dest.IsAvailableForUser, opt => opt.MapFrom(src => src.IS_AVAILABLE_TO_USER_IND != 0))
                .ForMember(dest => dest.TypeAbstract, opt => opt.MapFrom(src => src.TYPE_ABSTRACT))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CREATED_BY_USER))
                .ForMember(dest => dest.CreatedOn, opt => opt.MapFrom(src => src.CREATED_DATE))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.LAST_MODIFIED_USER))
                .ForMember(dest => dest.UpdatedOn, opt => opt.MapFrom(src => src.LAST_MODIFIED_DATE))
                .ReverseMap();

         this.CreateMap<DocumentFolderViewModel, DocumentFolderModel>()
            .ForMember(dest => dest.CREATED_BY_USER, opt => opt.MapFrom(src => src.CreatedByUser))
            .ForMember(dest => dest.CREATED_DATE, opt => opt.MapFrom(src => src.CreatedDate))
            .ForMember(dest => dest.DR_ADDRESS_ID, opt => opt.MapFrom(src => src.DrAddressId))
            .ForMember(dest => dest.FOLDER_ID, opt => opt.MapFrom(src => src.FolderId))
            .ForMember(dest => dest.FOLDER_NAME, opt => opt.MapFrom(src => src.FolderName))
            .ForMember(dest => dest.FOLDER_SOURCE, opt => opt.MapFrom(src => src.FolderSource))
            .ForMember(dest => dest.FOLDER_PARENT_ID, opt => opt.MapFrom(src => src.FolderParentId))
            .ForMember(dest => dest.JOB_ID, opt => opt.MapFrom(src => src.JobId))
            .ForMember(dest => dest.LAST_MODIFIED_DATE, opt => opt.MapFrom(src => src.LastModifiedDate))
            .ForMember(dest => dest.LAST_MODIFIED_USER, opt => opt.MapFrom(src => src.LastModifiedUser))
            .ForMember(dest => dest.JOB_FOLDER_TYPE_ID, opt => opt.MapFrom(src => src.JobFolderTypeId))
            .ForMember(dest => dest.DOC_TYPE_ID, opt => opt.MapFrom(src => src.DocTypeId))
            .ReverseMap();
      }
   }
}