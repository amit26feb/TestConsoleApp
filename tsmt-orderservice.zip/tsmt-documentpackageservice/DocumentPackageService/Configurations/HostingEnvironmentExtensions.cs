﻿// <copyright file="HostingEnvironmentExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Configurations
{
    using Microsoft.AspNetCore.Hosting;
   using Microsoft.Extensions.Hosting;

   /// <summary>
   /// Hosting environment extensions
   /// </summary>
   public static class HostingEnvironmentExtensions
    {
        /// <summary>
        /// Represents the UAT environment
        /// </summary>
        public const string UATEnvironment = "UAT";

        /// <summary>
        /// Specifies weather the hosting environment is UAT
        /// </summary>
        /// <param name="hostingEnvironment">Hosting environment</param>
        /// <returns>True if the hosting environment is UAT, False otherwise</returns>
        public static bool IsUAT(this IWebHostEnvironment hostingEnvironment)
        {
            return hostingEnvironment.IsEnvironment(UATEnvironment);
        }
   }
}
