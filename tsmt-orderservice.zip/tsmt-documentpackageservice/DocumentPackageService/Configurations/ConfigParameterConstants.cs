﻿// <copyright file="ConfigParameterConstants.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Configurations
{
   /// <summary>
   /// Config paramerter constants - The property names on this constant file need to be same as the TSMTSetttings file propety names.
   /// </summary>
   public class ConfigParameterConstants
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="ConfigParameterConstants"/> class.
      /// Config paramerter constants
      /// </summary>
      protected ConfigParameterConstants()
      {
      }

      /// <summary>
      /// Gets TSMT Connection String Parameter name
      /// </summary>
      public static string VPNDBConnectionString => "tsmt-tstrn-DocumentPackageService-v2";

      /// <summary>
      /// Gets influxDb parameter name
      /// </summary>
      public static string InfluxDb => "tsmt-influxdb-db";

      /// <summary>
      /// Gets influxDb url parameter name
      /// </summary>
      public static string InfluxDbUrl => "tsmt-influxdb-url";

      /// <summary>
      /// Gets influxDb user name parameter name
      /// </summary>
      public static string InfluxDbUserName => "tsmt-influxdb-user";

      /// <summary>
      /// Gets influxDb password parameter name
      /// </summary>
      public static string InfluxDbPassword => "tsmt-influxdb-password";

      /// <summary>
      /// Gets redis endpoint parameter name
      /// </summary>
      public static string RedisEndpoint => "tsmt-redisendpoint-DocumentPackageService-v2";
   }
}
