﻿// <copyright file="MediatorModule.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Configurations.AutofacModules
{
   using System.Collections.Generic;
   using System.Reflection;
   using Amazon.SQS;
   using Autofac;
   using AWS.MessagingWrapper.Contracts;
   using CacheProviderWrapper;
   using DataAccess.Core.Abstractions;
   using DocumentPackageService.Core.Behavior;
   using DocumentPackageService.Core.Commands;
   using DocumentPackageService.Core.Repository;
   using DocumentPackageService.Core.Services;
   using DocumentPackageService.Core.Validators;
   using FluentValidation;
   using MediatR;
   using Microsoft.AspNetCore.Hosting;
   using S3Wrapper;
   using TraneSalesTools;
   using TSMT.DataAccess;

   /// <summary>
   /// Mediator Module
   /// </summary>
   public class MediatorModule : Autofac.Module
   {
      /// <summary>
      /// Method to Load
      /// </summary>
      /// <param name="builder">builder</param>
      protected override void Load(ContainerBuilder builder)
      {
         builder.RegisterAssemblyTypes(typeof(IMediator).GetTypeInfo().Assembly)
             .AsImplementedInterfaces();

         // Setting the Honor Dr address Id to true. Some of the tables are in VPD and they require Dr_Address_id.
         builder.RegisterAssemblyTypes(typeof(IConnectionFactory).GetTypeInfo().Assembly)
               .AsImplementedInterfaces().WithParameter("doHonorDrAddressId", true);

         builder.RegisterType(typeof(DocumentPackageService)).As(typeof(IDocumentPackageService));

         builder.RegisterType(typeof(DocumentPackageRepository)).As(typeof(IDocumentPackageRepository));

         builder.RegisterType(typeof(MasterDataService)).As(typeof(IMasterDataService));

         builder.RegisterType(typeof(MasterDataRepository)).As(typeof(IMasterDataRepository));

         builder.RegisterType(typeof(DocumentFolderRepository)).As(typeof(IDocumentFolderRepository));

         builder.RegisterType(typeof(DocumentFolderService)).As(typeof(IDocumentFolderService));

         builder.RegisterType(typeof(LegacyFileService)).As(typeof(ILegacyFileService));

         builder.RegisterType(typeof(LegacyFileRepository)).As(typeof(ILegacyFileRepository));

         builder.RegisterAssemblyTypes(typeof(IWebHostEnvironment).GetTypeInfo().Assembly)
           .AsImplementedInterfaces();

         builder.RegisterAssemblyTypes(typeof(ISalesOfficeService).GetTypeInfo().Assembly)
             .AsImplementedInterfaces();

         builder.RegisterAssemblyTypes(typeof(ICacheProvider).GetTypeInfo().Assembly)
           .AsImplementedInterfaces();

         builder.RegisterAssemblyTypes(typeof(IAmazonSQS).GetTypeInfo().Assembly).AsImplementedInterfaces();
         builder.RegisterAssemblyTypes(typeof(IMessageReceiver).GetTypeInfo().Assembly).AsImplementedInterfaces();
         builder.RegisterAssemblyTypes(typeof(IS3Repository).GetTypeInfo().Assembly).AsImplementedInterfaces();

         builder.Register<SingleInstanceFactory>(context =>
         {
            var componentContext = context.Resolve<IComponentContext>();
            return t => componentContext.TryResolve(t, out object o) ? o : null;
         });

         builder.Register<MultiInstanceFactory>(context =>
         {
            var componentContext = context.Resolve<IComponentContext>();

            return t =>
               {
                  var resolved = (IEnumerable<object>)componentContext.Resolve(typeof(IEnumerable<>).MakeGenericType(t));
                  return resolved;
               };
         });

         builder.RegisterAssemblyTypes(typeof(CreateDocumentPackageCommand).Assembly)
               .AsClosedTypesOf(typeof(IRequestHandler<,>));
         builder.RegisterAssemblyTypes(typeof(CreateDocumentPackageCommandValidator).Assembly)
                .AsClosedTypesOf(typeof(IValidator<>));
         builder.RegisterAssemblyTypes(typeof(UpdateDocumentPackageCommand).Assembly)
               .AsClosedTypesOf(typeof(IRequestHandler<,>));
         builder.RegisterAssemblyTypes(typeof(UpdateDocumentPackageCommandValidator).Assembly)
                .AsClosedTypesOf(typeof(IValidator<>));
         builder.RegisterAssemblyTypes(typeof(CreateDocumentFolderCommand).Assembly)
               .AsClosedTypesOf(typeof(IRequestHandler<,>));
         builder.RegisterAssemblyTypes(typeof(CreateDocumentFolderCommandValidator).Assembly)
                .AsClosedTypesOf(typeof(IValidator<>));

         builder.RegisterGeneric(typeof(LoggingBehavior<,>)).As(typeof(IPipelineBehavior<,>));
         builder.RegisterGeneric(typeof(ValidatorBehavior<,>)).As(typeof(IPipelineBehavior<,>));
         builder.RegisterGeneric(typeof(Repository<>)).As(typeof(IRepository<>));

         builder.RegisterAssemblyTypes(typeof(ICacheProvider).GetTypeInfo().Assembly)
            .AsImplementedInterfaces();
         builder.RegisterAssemblyTypes(typeof(IRedisConnectionFactory).GetTypeInfo().Assembly)
            .AsImplementedInterfaces()
            .SingleInstance();
      }
   }
}
