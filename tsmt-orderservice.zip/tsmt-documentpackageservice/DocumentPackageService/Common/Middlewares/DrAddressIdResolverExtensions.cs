﻿// <copyright file="DrAddressIdResolverExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common.Middlewares
{
    using Microsoft.AspNetCore.Builder;
   using TraneSalesTools.Middlewares;

   /// <summary>
   /// DrAddressIdResolverExtensions
   /// </summary>
   public static class DrAddressIdResolverExtensions
   {
      /// <summary>
      /// UseDrAddressIdResolver
      /// </summary>
      /// <param name="builder">builder</param>
      /// <returns>IApplicationBuilder</returns>
      public static IApplicationBuilder UseDrAddressIdResolver(this IApplicationBuilder builder)
      {
         return builder.UseMiddleware<DrAddressIdResolverMiddleware>();
      }
   }
}
