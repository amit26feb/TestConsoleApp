﻿// <copyright file="VpdAuthenticatorExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common.Middlewares
{
   using Microsoft.AspNetCore.Builder;
   using TraneSalesTools.Middlewares;

   /// <summary>
   /// VPDAuthenticatiorExtensions
   /// </summary>
   public static class VpdAuthenticatorExtensions
   {
      /// <summary>
      /// UseVPDAuthenticator
      /// </summary>
      /// <param name="builder">builder</param>
      /// <returns>IApplicationBuilder</returns>
      public static IApplicationBuilder UseVPDAuthenticator(this IApplicationBuilder builder)
      {
         return builder.UseMiddleware<VpdAuthenticatorMiddleware>();
      }
   }
}
