﻿// <copyright file="DrAddressIdResolverMiddleware.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common.Middlewares
{
   using System.Threading.Tasks;
   using Microsoft.AspNetCore.Http;

   /// <summary>
   /// DrAddressIdResolverMiddleware
   /// </summary>
   public class DrAddressIdResolverMiddleware
   {
      private readonly RequestDelegate next;

      /// <summary>
      /// Initializes a new instance of the <see cref="DrAddressIdResolverMiddleware"/> class.
      /// </summary>
      /// <param name="next">next</param>
      public DrAddressIdResolverMiddleware(RequestDelegate next)
      {
         this.next = next;
      }

      /// <summary>
      /// Invoke
      /// </summary>
      /// <param name="context">context</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      public async Task Invoke(HttpContext context)
      {
         // Attempt to parse out the desired DrAddressId from the route, by looking at the HttpRequest Path.
         int drAddressId = -1;
         if (context.Request != null &&
             context.Request.Path.HasValue)
         {
            // For any controllers in this API that should honor a DrAddressId, the expected route starts with:
            //   /api/v{version:apiVersion}/{drAddressId}/
            string[] requestPathSegments = context.Request.Path.Value.Split('/', System.StringSplitOptions.RemoveEmptyEntries);
            if (requestPathSegments.Length >= 3)
            {
               string potentialDra = requestPathSegments[2];
               if (!int.TryParse(potentialDra, out drAddressId))
               {
                  drAddressId = -1;
               }
            }
         }

         if (drAddressId >= 0)
         {
            // We store a valid DrAddressId in the HttpContext's Items.
            context.Items["DR_ADDRESS_ID"] = drAddressId.ToString();
         }
         else
         {
            // We were not able to parse out the DrAddressId to honor.
            context.Items["DR_ADDRESS_ID"] = string.Empty;
         }

         // Call the next middleware delegate in the pipeline.
         await this.next.Invoke(context);
      }
   }
}
