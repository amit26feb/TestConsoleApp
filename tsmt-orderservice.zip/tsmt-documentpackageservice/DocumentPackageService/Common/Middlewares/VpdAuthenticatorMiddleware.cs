﻿// <copyright file="VpdAuthenticatorMiddleware.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common.Middlewares
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using DocumentPackageService.Core.Services;
    using Microsoft.AspNetCore.Http;
   using TraneSalesToolsCommon;

   /// <summary>
   /// VPDAuthenticator Middleware
   /// </summary>
   public class VpdAuthenticatorMiddleware
   {
      private readonly RequestDelegate next;
      private readonly IDocumentPackageService documentPackageService;

      /// <summary>
      /// Initializes a new instance of the <see cref="VpdAuthenticatorMiddleware"/> class.
      /// </summary>
      /// <param name="next">next</param>
      /// <param name="documentPackageService">documentPackageService</param>
      public VpdAuthenticatorMiddleware(IDocumentPackageService documentPackageService, RequestDelegate next)
      {
         this.next = next;
         this.documentPackageService = documentPackageService;
      }

      /// <summary>
      /// Invoke
      /// </summary>
      /// <param name="context">context</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      public async Task Invoke(HttpContext context)
      {
         int drAddressId = -1;

         // Checking if the context contains Dr_AddressId
         if (context.Items != null && context.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(context.Items["DR_ADDRESS_ID"].ToString(), out drAddressId) && drAddressId > 0)
         {
            // Getting the list of sales offices
            IEnumerable<SalesOfficeView> salesOfficeList = await this.documentPackageService.GetOfficeSelector();
            if (salesOfficeList.Any())
            {
               // Checking if the user has access to the sales office
               bool isValidDrAdddressId = salesOfficeList.Any(draddressId => draddressId.DrAddressId == drAddressId);

               // If the user don't have access to the sales office, return unauthorized error
               if (!isValidDrAdddressId)
               {
                  context.Response.StatusCode = 401;
                  return;
               }
            }
            else
            {
               // If there is no sales office list for the user, returns unauthorized error.
               context.Response.StatusCode = 401;
            }
         }

         await this.next.Invoke(context);
      }
   }
}
