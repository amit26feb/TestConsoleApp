﻿// <copyright file="HttpGlobalExceptionFilter.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common.Filters
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using DocumentPackageService.Common.ActionResults;
    using DocumentPackageService.Common.Exceptions;
    using FluentValidation;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
   using Microsoft.Extensions.Hosting;
   using Microsoft.Extensions.Logging;

    /// <summary>
    /// The http global exception filter
    /// </summary>
    public class HttpGlobalExceptionFilter : IExceptionFilter
        {
            /// <summary>
            /// Hosting environment
            /// </summary>
            private readonly IWebHostEnvironment env;

            /// <summary>
            /// The logger for http global exception filter
            /// </summary>
            private readonly ILogger<HttpGlobalExceptionFilter> logger;

            /// <summary>
            /// Initializes a new instance of the <see cref="HttpGlobalExceptionFilter"/> class.
            /// </summary>
            /// <param name="env">Environment parameter value</param>
            /// <param name="logger">Logger parameter value</param>
            public HttpGlobalExceptionFilter(IWebHostEnvironment env, ILogger<HttpGlobalExceptionFilter> logger)
            {
                this.env = env;
                this.logger = logger;
            }

            /// <summary>
            /// On exception
            /// </summary>
            /// <param name="context">Context  parameter value</param>
            public void OnException(ExceptionContext context)
            {
                this.logger.LogError(context.Exception.ToString());

                IEnumerable<string> data = null;
                if (context.Exception.InnerException != null && context.Exception.InnerException.GetType() == typeof(ValidationException))
                {
                    data = ((ValidationException)context.Exception.InnerException).Errors.Select(x => x.ErrorMessage).Distinct();
                }

                var json = new JsonErrorResponse
                {
                    Messages = data != null && data.Any() ? data.ToList() : new List<string>() { context.Exception.Message }
                };

                if (context.Exception.GetType() == typeof(DocumentPackageServiceDomainException))
                {
                    context.Result = new BadRequestObjectResult(json);
                    context.HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
                else
                {
                    if (this.env.IsDevelopment())
                    {
                        json.DeveloperMessage = context.Exception;
                    }

                    context.Result = new InternalServerErrorObjectResult(json);
                    context.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                }

                context.ExceptionHandled = true;
            }
        }
    }
