﻿// <copyright file="DocumentPackageQueries.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common.Constants
{
    /// <summary>
    /// Constant file for feature document package repository queries
    /// </summary>
    public static class DocumentPackageQueries
    {
        /// <summary>
        /// Query to get all document packages
        /// </summary>
        public const string GetAllDocumentPackages = @"";
    }
}
