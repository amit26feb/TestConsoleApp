﻿// <copyright file="QueryConstants.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common
{
   using DocumentPackageService.Core.Models;

   /// <summary>
   /// QueryConstants
   /// </summary>
   public static class QueryConstants
   {
      /// <summary>
      /// Query to get all the business streams
      /// </summary>
      public static readonly string GetBusinessStreams = @"SELECT 
       	                                                      DOC_GROUP_ID, 
                                                               GROUP_NAME,
                                                               GROUP_ABSTRACT, 
                                                               STATUS, 
                                                               CREATED_DATE, 
                                                               CREATED_BY_USER, 
                                                               LAST_MODIFIED_DATE, 
                                                               LAST_MODIFIED_USER
                                                            FROM
                                                               SO.DGM_DOC_GROUP
                                                            WHERE
                                                               LOWER(STATUS) = 'c'";

      /// <summary>
      /// Query to get all the document Types
      /// </summary>
      public static readonly string GetDocumentTypes = @"SELECT 
                                                            DOC_TYPE_ID, 
                                                            DOC_TYPE_NAME,
                                                            DOC_TYPE_SHORT_NAME,
                                                            DOC_GROUP_ID, 
                                                            DOC_TYPE_ABSTRACT, 
                                                            DOC_TYPE_SEQ_NBR, 
                                                            STATUS, 
                                                            CREATED_DATE, 
                                                            CREATED_BY_USER, 
                                                            LAST_MODIFIED_DATE, 
                                                            LAST_MODIFIED_USER
                                                         FROM
                                                            SO.DGM_DOC_TYPE
                                                         WHERE
                                                            DOC_GROUP_ID=:DOC_GROUP_ID AND LOWER(STATUS) = 'c'";

      /// <summary>
      /// Query to get all the legal Entities
      /// </summary>
      public static readonly string GetLegalEntities = @"SELECT 
                                                          DGMLE.LEGAL_ENTITY_ID,
                                                          DTREF.SEQUENCE_NBR,
                                                          DGMLE.ENTITY_LONG_NAME, 
                                                          DGMLE.ENTITY_SHORT_NAME, 
                                                          DGMLE.ENTITY_ABSTRACT
                                                       FROM
                                                          SO.DGM_LEGAL_ENTITY DGMLE
                                                          INNER JOIN SO.DGM_DOC_TYPE_ENTITY_XREF DTREF ON DTREF.LEGAL_ENTITY_ID = DGMLE.LEGAL_ENTITY_ID
                                                       WHERE
                                                          DTREF.DOC_TYPE_ID=:DOC_TYPE_ID
                                                          AND DGMLE.ENTITY_EFFECTIVE_DATE <= F_DBDATE
                                                          AND DTREF.EFFECTIVE_DATE <= F_DBDATE
                                                          AND (DGMLE.ENTITY_EXPIRATION_DATE > F_DBDATE  OR (DGMLE.ENTITY_EXPIRATION_DATE is null))
                                                          AND (DTREF.EXPIRATION_DATE > F_DBDATE  OR (DTREF.EXPIRATION_DATE is null))
                                                       ORDER BY
                                                          DTREF.SEQUENCE_NBR ASC";

      /// <summary>
      /// Query to get all the terms and conditions
      /// </summary>
      public static readonly string GetTermsAndConditions = @"SELECT 
                                                               TC.TERMS_COND_ID, 
                                                               TREF.SEQUENCE_NBR,
                                                               TC.TERMS_COND_NAME,
                                                               TC.TERMS_COND_DESCRIPTION, 
                                                               TC.FILE_LOCATION,
                                                               TREF.DOC_TYPE_ID,
                                                               TREF.DEFAULT_IND,
                                                               TC.CREATED_DATE, 
                                                               TC.CREATED_BY_USER, 
                                                               TC.LAST_MODIFIED_DATE, 
                                                               TC.LAST_MODIFIED_USER
                                                            FROM
                                                               SO.DGM_TERMS_CONDITIONS TC
                                                               INNER JOIN SO.DGM_DOC_TYPE_TERMS_XREF TREF ON TREF.TERMS_COND_ID = TC.TERMS_COND_ID
                                                            WHERE
                                                               TREF.DOC_TYPE_ID=:DOC_TYPE_ID
                                                                AND TC.EFFECTIVE_DATE <= F_DBDATE
                                                                AND TREF.EFFECTIVE_DATE <= F_DBDATE
                                                                AND (TC.EXPIRATION_DATE > F_DBDATE  OR (TC.EXPIRATION_DATE is null))
                                                                AND (TREF.EXPIRATION_DATE > F_DBDATE  OR (TREF.EXPIRATION_DATE is null))
                                                             ORDER BY
                                                                TREF.SEQUENCE_NBR ASC";

      /// <summary>
      /// Query to create new document package
      /// </summary>
      public static readonly string CreateDocumentPackage = @"INSERT INTO SO.DG_DOC_PACKAGE
                                                                 (DR_ADDRESS_ID,
                                                                  JOB_ID,
                                                                  DOC_PKG_ID,
                                                                  PKG_NAME,
                                                                  PKG_DESCRIPTION,
                                                                  DOC_TYPE_ID,
                                                                  CREATED_DATE,
                                                                  CREATED_BY_USER,
                                                                  LAST_MODIFIED_DATE,
                                                                  LAST_MODIFIED_USER)
                                                              VALUES 
                                                                  (:DR_ADDRESS_ID,
                                                                  :JOB_ID,
                                                                  :DOC_PKG_ID,
                                                                  :PKG_NAME,
                                                                  :PKG_DESCRIPTION,
                                                                  :DOC_TYPE_ID,
                                                                   F_DBDATE,
                                                                  :CREATED_BY_USER,
                                                                   F_DBDATE,
                                                                  :LAST_MODIFIED_USER)";

      /// <summary>
      /// Query to create document package
      /// </summary>
      public static readonly string CreateDocumentPackageFile = @"INSERT INTO SO.DG_DOC_PACKAGE_FILE
                                                                    (DR_ADDRESS_ID,
                                                                     JOB_ID,
                                                                     DOC_PKG_ID,
                                                                     FILE_VERSION,
                                                                     LEGAL_ENTITY_ID,
                                                                     TERMS_COND_ID,
                                                                     BID_ALTERNATE_ID,
                                                                     FILE_NAME,
																	                  FILE_LOCATION,
																	                  ADDITIONAL_INFO,
                                                                     GENERATED_STATUS,
																	                  GENERATED_INFO,
                                                                     GENERATED_BY_USER,
																	                  PROPOSAL_NBR,
                                                                     LAST_MODIFIED_DATE,
                                                                     LAST_MODIFIED_USER)
                                                                  VALUES 
                                                                     (:DR_ADDRESS_ID,
                                                                     :JOB_ID,
                                                                     :DOC_PKG_ID,
                                                                     :FILE_VERSION,
                                                                     :LEGAL_ENTITY_ID,
                                                                     :TERMS_COND_ID,
																	                  :BID_ALTERNATE_ID,
                                                                     :FILE_NAME,
																	                  :FILE_LOCATION,
                                                                     UTL_RAW.CAST_TO_RAW(:ADDITIONAL_INFO),
                                                                     :STATUS,
																	                  :GENERATED_INFO,
                                                                     :GENERATED_BY_USER,
																	                  :PROPOSAL_NBR,
                                                                      F_DBDATE,
                                                                     :LAST_MODIFIED_USER)";

      /// <summary>
      /// Query to Get Document Package Details
      /// </summary>
      public static readonly string GetDocPkgDetails = @"SELECT 
                                                                 DP.DR_ADDRESS_ID,
                                                                 DP.JOB_ID,
                                                                 DP.DOC_PKG_ID,
                                                                 DP.PKG_NAME,
                                                                 DP.PKG_DESCRIPTION,
                                                                 DP.DOC_TYPE_ID,
                                                                 DT.DOC_TYPE_NAME,
                                                                 DP.CREATED_DATE,
                                                                 DP.CREATED_BY_USER,
                                                                 DP.LAST_MODIFIED_DATE,
                                                                 DP.LAST_MODIFIED_USER,
                                                                 DPF.FILE_VERSION,
                                                                 LE.LEGAL_ENTITY_ID,
                                                                 LE.ENTITY_LONG_NAME,
                                                                 LE.ENTITY_SHORT_NAME,
                                                                 DTC.TERMS_COND_ID,
                                                                 DTC.TERMS_COND_NAME,
                                                                 DTC.FILE_LOCATION AS TC_FILE_LOCATION,
                                                                 DPF.BID_ALTERNATE_ID,
                                                                 DPF.FILE_NAME,
                                                                 DPF.FILE_LOCATION,
                                                                 UTL_RAW.CAST_TO_VARCHAR2(DPF.ADDITIONAL_INFO) AS ADDITIONAL_INFO,
                                                                 DPF.GENERATED_STATUS AS STATUS,
                                                                 UTL_RAW.CAST_TO_VARCHAR2(DPF.GENERATED_INFO) AS GENERATED_INFO,
                                                                 DPF.GENERATED_DATE,
                                                                 DPF.GENERATED_BY_USER,
                                                                 DPF.PROPOSAL_NBR,
                                                                 DPF.LAST_MODIFIED_DATE AS FILE_LAST_MODIFIED_DATE,
                                                                 DPF.LAST_MODIFIED_USER AS FILE_LAST_MODIFIED_USER
                                                         FROM 
                                                                 SO.DG_DOC_PACKAGE DP
                                                         INNER JOIN 
                                                                        SO.DGM_DOC_TYPE DT ON DP.DOC_TYPE_ID=DT.DOC_TYPE_ID
                                                         INNER JOIN
                                                                 SO.DG_DOC_PACKAGE_FILE DPF ON DP.DOC_PKG_ID=DPF.DOC_PKG_ID
                                                         INNER JOIN
                                                                  SO.DGM_LEGAL_ENTITY LE ON DPF.LEGAL_ENTITY_ID=LE.LEGAL_ENTITY_ID
                                                         INNER JOIN
                                                                  SO.DGM_TERMS_CONDITIONS DTC ON DPF.TERMS_COND_ID=DTC.TERMS_COND_ID
                                                         WHERE DP.DOC_PKG_ID= :docPkgId AND 
                                                               DPF.FILE_VERSION =
                                                                  (
                                                                     SELECT MAX(FILE_VERSION) FROM SO.DG_DOC_PACKAGE_FILE MDPF WHERE MDPF.DOC_PKG_ID = DP.DOC_PKG_ID and MDPF.JOB_ID=DP.JOB_ID
                                                                   )";

      /// <summary>
      /// Query to update existing document package
      /// </summary>
      public static readonly string UpdateDocumentPackage = @"UPDATE 
                                                                  SO.DG_DOC_PACKAGE
                                                            SET 
                                                                  PKG_NAME =:PKG_NAME,
                                                                  PKG_DESCRIPTION =:PKG_DESCRIPTION,
                                                                  DOC_TYPE_ID =:DOC_TYPE_ID,
                                                                  LAST_MODIFIED_DATE =F_DBDATE,
                                                                  LAST_MODIFIED_USER =:LAST_MODIFIED_USER
                                                            WHERE
                                                                  JOB_ID =:JOB_ID 
                                                                  AND DOC_PKG_ID =:DOC_PKG_ID";

      /// <summary>
      /// Query to update document package file
      /// </summary>
      public static readonly string UpdateDocumentPackageFile = @"UPDATE 
                                                                      SO.DG_DOC_PACKAGE_FILE
                                                                  SET 
                                                                      FILE_VERSION =:FILE_VERSION,
                                                                      LEGAL_ENTITY_ID =:LEGAL_ENTITY_ID,
                                                                      TERMS_COND_ID =:TERMS_COND_ID,
                                                                      BID_ALTERNATE_ID =:BID_ALTERNATE_ID,
                                                                      FILE_NAME =:FILE_NAME,
                                                                      FILE_LOCATION =:FILE_LOCATION,
                                                                      ADDITIONAL_INFO = UTL_RAW.CAST_TO_RAW(:ADDITIONAL_INFO),
                                                                      PROPOSAL_NBR =:PROPOSAL_NBR,
                                                                      LAST_MODIFIED_DATE =F_DBDATE,
                                                                      LAST_MODIFIED_USER =:LAST_MODIFIED_USER
                                                                  WHERE
                                                                      JOB_ID =:JOB_ID 
                                                                      AND DOC_PKG_ID =:DOC_PKG_ID 
                                                                      AND FILE_VERSION=:FILE_VERSION";

      /// <summary>
      /// Query to get the proposal sequence number
      /// </summary>
      public static readonly string GetProposalSequence = @"Select 
                                                                count(*) + 1
                                                            from
                                                                SO.DG_DOC_PACKAGE_FILE
                                                            WHERE
                                                                DOC_PKG_ID =:DOC_PKG_ID AND GENERATED_STATUS IN ('" + GeneratedStatusOptions.Complete + "', '" + GeneratedStatusOptions.Uploaded + "')";

      /// <summary>
      /// Query to check whether the document package name already exist
      /// </summary>
      public static readonly string ValidateDocPackName = @"SELECT 
                                                               COUNT(*) 
                                                            FROM 
                                                               SO.DG_DOC_PACKAGE 
                                                         WHERE 
                                                            LOWER(PKG_NAME) = :PKG_NAME AND JOB_ID = :JOB_ID";

      /// <summary>
      /// Query to check whether the document package file exist and the version need to be incremented
      /// </summary>
      public static readonly string ValidateDocPackFile = @"SELECT
                                                              COUNT(*)
                                                           FROM
                                                              SO.DG_DOC_PACKAGE_FILE
                                                           WHERE
                                                              JOB_ID = :JOB_ID
                                                              AND DOC_PKG_ID = :DOC_PKG_ID
                                                              AND FILE_VERSION = :FILE_VERSION
                                                              AND GENERATED_STATUS IN ('" + GeneratedStatusOptions.Complete + "', '" + GeneratedStatusOptions.Uploaded + "')";

      /// <summary>
      /// Query to get document packages detail
      /// </summary>
      public static readonly string GetDocumentPackageDetails =
         @"SELECT 
              DT.DOC_TYPE_NAME as DOCUMENT_TYPE,
              DP.DOC_PKG_ID,
              DP.DOC_TYPE_ID,
              DP.PKG_NAME AS NAME,
              DP.PKG_DESCRIPTION AS DESCRIPTION,
              DP.DR_ADDRESS_ID,
              DP.CREATED_BY_USER AS CREATED_BY_USER,
              DP.CREATED_DATE AS CREATED_DATE,
              DP.LAST_MODIFIED_USER AS LAST_MODIFIED_USER,
              DP.LAST_MODIFIED_DATE AS LAST_MODIFIED_DATE,
              CASE WHEN DPF.GENERATED_STATUS = '" + GeneratedStatusOptions.Complete + @"' THEN '" + GeneratedStatusOptions.Complete + @"' WHEN DPF.GENERATED_STATUS = '" + GeneratedStatusOptions.Uploaded + @"' THEN '" + GeneratedStatusOptions.Uploaded + @"' Else 'Draft' END As SORT_ORDER_STATUS,
              DPF.GENERATED_STATUS AS STATUS,
              DPF.FILE_VERSION,
              LG_DPF.GENERATED_DATE AS FILE_GENERATED_DATE,
              LG_DPF.FILE_VERSION AS LAST_GENERATED_VERSION,
              LG_DPF.GENERATED_BY_USER AS FILE_GENERATED_BY_USER,
              LU_DPF.LAST_MODIFIED_DATE AS FILE_UPLOADED_DATE,
              LU_DPF.FILE_VERSION AS LAST_UPLOADED_VERSION,
              LU_DPF.LAST_MODIFIED_USER AS FILE_UPLOADED_BY_USER
           FROM
              SO.DG_DOC_PACKAGE DP
           INNER JOIN
              SO.DGM_DOC_TYPE DT ON DP.DOC_TYPE_ID=DT.DOC_TYPE_ID
           LEFT OUTER JOIN
              SO.DG_DOC_PACKAGE_FILE DPF ON DP.JOB_ID=DPF.JOB_ID AND DP.DOC_PKG_ID=DPF.DOC_PKG_ID 
           LEFT OUTER JOIN
              SO.DG_DOC_PACKAGE_FILE LG_DPF ON DP.JOB_ID=LG_DPF.JOB_ID AND DP.DOC_PKG_ID=LG_DPF.DOC_PKG_ID AND LG_DPF.FILE_VERSION = 
                 (SELECT
                     MAX(S.FILE_VERSION) 
                  FROM
                      SO.DG_DOC_PACKAGE_FILE S
                  WHERE 
                     S.JOB_ID = DP.JOB_ID 
                     AND S.DOC_PKG_ID = DP.DOC_PKG_ID
                     AND S.GENERATED_STATUS ='" + GeneratedStatusOptions.Complete + @"'
                     AND S.GENERATED_DATE IS NOT NULL)
           LEFT OUTER JOIN
              SO.DG_DOC_PACKAGE_FILE LU_DPF ON DP.JOB_ID=LU_DPF.JOB_ID AND DP.DOC_PKG_ID=LU_DPF.DOC_PKG_ID AND LU_DPF.FILE_VERSION = 
                 (SELECT
                     MAX(S.FILE_VERSION) 
                  FROM
                      SO.DG_DOC_PACKAGE_FILE S
                  WHERE 
                     S.JOB_ID = DP.JOB_ID 
                     AND S.DOC_PKG_ID = DP.DOC_PKG_ID
                     AND S.GENERATED_STATUS = '" + GeneratedStatusOptions.Uploaded + @"')
           WHERE 
              DP.JOB_ID=:jobId
              AND (DP.PKG_NAME LIKE '%' || NVL(:searchText,DP.PKG_NAME) || '%' OR DP.PKG_DESCRIPTION LIKE '%' || NVL(:searchText,DP.PKG_DESCRIPTION) || '%' )
              AND DPF.FILE_VERSION = (SELECT MAX(FILE_VERSION) FROM SO.DG_DOC_PACKAGE_FILE MDPF WHERE MDPF.DOC_PKG_ID = DP.DOC_PKG_ID and MDPF.JOB_ID=DP.JOB_ID)";

      /// <summary>
      /// Query to update document package file generation details
      /// </summary>
      public static readonly string UpdateDocumentPackageFileGenerationDetails =
         @"UPDATE
              SO.DG_DOC_PACKAGE_FILE
           SET
              GENERATED_STATUS = :STATUS,
              GENERATED_DATE = :GENERATED_DATE,
              GENERATED_BY_USER = :GENERATED_BY_USER
           WHERE
              DOC_PKG_ID= :DOC_PKG_ID AND
              FILE_VERSION = :FILE_VERSION";

      /// <summary>
      /// Query to update document package filename
      /// </summary>
      public static readonly string UpdateDocumentPackageFilename =
         @"UPDATE
              SO.DG_DOC_PACKAGE_FILE
           SET
              FILE_NAME = :FILE_NAME
           WHERE
              DOC_PKG_ID = :DOC_PKG_ID AND
              FILE_VERSION = :FILE_VERSION";

      /// <summary>
      /// Query to get document package status
      /// </summary>
      public static readonly string GetDocumentPackageFileStatus =
         @"SELECT                            
              GENERATED_STATUS AS Status,
              GENERATED_DATE AS GeneratedDate
           FROM
              SO.DG_DOC_PACKAGE_FILE
           WHERE
              JOB_ID = :JOB_ID AND
              DOC_PKG_ID = :DOC_PKG_ID AND
              FILE_VERSION = :FILE_VERSION";

      /// <summary>
      /// Query to update document package file generated information
      /// </summary>
      public static readonly string UpdateDocumentPackageFileGeneratedInfo =
         @"UPDATE
              SO.DG_DOC_PACKAGE_FILE
           SET
              FILE_LOCATION = :FILE_LOCATION,
              GENERATED_STATUS = :STATUS,
              GENERATED_INFO = UTL_RAW.CAST_TO_RAW(:GENERATED_INFO),
              GENERATED_DATE = F_DBDATE
           WHERE
              JOB_ID = :JOB_ID AND
              DOC_PKG_ID = :DOC_PKG_ID AND
              FILE_VERSION = :FILE_VERSION";

      /// <summary>
      /// Query to get document package file download info
      /// </summary>
      public static readonly string GetDocumentPackageFileDownloadInfo =
         @"SELECT                            
              FILE_NAME AS Name,
              FILE_LOCATION AS Location,
              UTL_RAW.CAST_TO_VARCHAR2(GENERATED_INFO) AS GeneratedInfo,
              FILE_VERSION AS VersionId
           FROM
              SO.DG_DOC_PACKAGE_FILE
           WHERE
              JOB_ID = :JOB_ID AND
              DOC_PKG_ID = :DOC_PKG_ID AND
              FILE_VERSION = :FILE_VERSION";

      /// <summary>
      /// Query to get most recent document package file download info
      /// </summary>
      public static readonly string GetMostRecentDocumentPackageFileDownloadInfo =
         @"SELECT                            
              FILE_NAME AS Name,
              FILE_LOCATION AS Location,
              UTL_RAW.CAST_TO_VARCHAR2(GENERATED_INFO) AS GeneratedInfo,
              FILE_VERSION AS VersionId
           FROM
              SO.DG_DOC_PACKAGE_FILE
           WHERE
              JOB_ID = :JOB_ID AND
              DOC_PKG_ID = :DOC_PKG_ID AND
              FILE_VERSION = (SELECT MAX(FILE_VERSION) FROM SO.DG_DOC_PACKAGE_FILE
                              WHERE JOB_ID = :JOB_ID AND
                              DOC_PKG_ID = :DOC_PKG_ID)";

      /// <summary>
      /// Query to get document package file history records
      /// </summary>
      public static readonly string GetDocumentPackageFileHistories =
         @"SELECT                            
              FILE_NAME,
              LAST_MODIFIED_DATE,
              LAST_MODIFIED_USER,
              GENERATED_DATE,
              GENERATED_BY_USER,
              GENERATED_STATUS AS STATUS,
              FILE_VERSION,
              UTL_RAW.CAST_TO_VARCHAR2(GENERATED_INFO) AS GENERATED_INFO
           FROM
              SO.DG_DOC_PACKAGE_FILE
           WHERE
              JOB_ID = :JOB_ID AND
              DOC_PKG_ID = :DOC_PKG_ID";

      /// <summary>
      /// Query to get all the job document type
      /// </summary>
      public static readonly string GetJobDocumentType = @"SELECT 
       	                                                      JOB_DOCUMENT_TYPE_ID, 
                                                               TYPE_NAME,
                                                               TYPE_ABSTRACT,
                                                               TYPE_SEQ_NBR,
                                                               IS_AVAILABLE_TO_USER_IND,
                                                               CREATED_DATE, 
                                                               CREATED_BY_USER, 
                                                               LAST_MODIFIED_DATE, 
                                                               LAST_MODIFIED_USER
                                                            FROM
                                                               SO.JOB_DOCUMENT_TYPE 
                                                            WHERE
                                                               IS_AVAILABLE_TO_USER_IND = 1
                                                            ORDER BY
                                                               TYPE_SEQ_NBR";

      /// <summary>
      /// Query to create new document folder
      /// </summary>
      public static readonly string CreateDocumentFolder = @"INSERT INTO SO.JOB_DOCUMENT_FOLDER
                                                                 (DR_ADDRESS_ID,
                                                                  JOB_ID,
                                                                  FOLDER_ID,
                                                                  FOLDER_PARENT_ID,
                                                                  FOLDER_NAME,
                                                                  JOB_FOLDER_TYPE_ID,
                                                                  DOC_TYPE_ID,
                                                                  CREATED_DATE,
                                                                  CREATED_BY_USER,
                                                                  LAST_MODIFIED_DATE,
                                                                  LAST_MODIFIED_USER)
                                                              VALUES 
                                                                  (:DR_ADDRESS_ID,
                                                                  :JOB_ID,
                                                                  :FOLDER_ID,
                                                                  :FOLDER_PARENT_ID,
                                                                  :FOLDER_NAME,
                                                                  :JOB_FOLDER_TYPE_ID,
                                                                  :DOC_TYPE_ID,
                                                                   F_DBDATE,
                                                                  :CREATED_BY_USER,
                                                                   F_DBDATE,
                                                                  :LAST_MODIFIED_USER)";

      /// <summary>
      /// Query to check whether the document folder name already exist
      /// </summary>
      public static readonly string ValidateFolder = @"SELECT 
                                                               FOLDER_ID,
                                                               FOLDER_PARENT_ID,       
                                                               FOLDER_NAME
                                                            FROM 
                                                               SO.JOB_DOCUMENT_FOLDER
                                                         WHERE 
                                                            LOWER(FOLDER_NAME) = :FOLDER_NAME
                                                            AND JOB_ID = :JOB_ID";

      /// <summary>
      /// Query to get the folders
      /// </summary>
      public static readonly string GetFolders = @"SELECT
                                                      JDF.FOLDER_ID,
                                                      JDF.FOLDER_PARENT_ID,
                                                      CASE
                                                         WHEN
                                                            JDF.JOB_FOLDER_TYPE_ID = 2 
                                                         THEN
                                                            DT.DOC_TYPE_NAME 
                                                         WHEN
                                                            JDF.JOB_FOLDER_TYPE_ID = 5 AND JDF.FOLDER_PARENT_ID IS NOT NULL
                                                         THEN
                                                            VAR.SHORT_DESC
                                                         ELSE
                                                            JDF.FOLDER_NAME 
                                                      END
                                                      AS FOLDER_NAME, 
                                                      JDT.FOLDER_SOURCE, 
                                                      JDF.JOB_FOLDER_TYPE_ID,
                                                      NVL(JDF.DOC_TYPE_ID, 0) AS DOC_TYPE_ID 
                                                   FROM
                                                      SO.JOB_DOCUMENT_FOLDER JDF 
                                                      INNER JOIN
                                                            SO.JOB_DOCUMENT_FOLDER_TYPE JDT 
                                                            ON JDT.JOB_FOLDER_TYPE_ID = JDF.JOB_FOLDER_TYPE_ID 
                                                      LEFT OUTER JOIN
                                                            SO.DGM_DOC_TYPE DT 
                                                            ON DT.DOC_TYPE_ID = JDF.DOC_TYPE_ID 
                                                      LEFT OUTER JOIN
                                                            SO.VARIATION VAR 
                                                            ON TO_CHAR(VAR.VARIATION_ID) = JDF.FOLDER_NAME
                                                   WHERE
                                                      JDF.JOB_ID = :JOB_ID
                                                   ORDER BY
                                                      JDT.TYPE_SEQ_NBR, JDF.FOLDER_NAME";

      /// <summary>
      /// Query to check a folder
      /// </summary>
      public static readonly string DoesFolderExist = @"SELECT 
                                                         COUNT(*) 
                                                      FROM 
                                                         SO.JOB_DOCUMENT_FOLDER 
                                                      WHERE 
                                                         JOB_ID = :JOB_ID 
                                                         AND JOB_FOLDER_TYPE_ID = :JOB_FOLDER_TYPE_ID 
                                                         AND DOC_TYPE_ID = :DOC_TYPE_ID";

      /// <summary>
      /// Query to get the package document file
      /// </summary>
      public static readonly string GetPackageDocument = @"SELECT
                                                               DDPF.DOC_PKG_ID,
                                                               DDPF.FILE_NAME,
                                                               DDPF.GENERATED_DATE,
                                                               DDPF.GENERATED_BY_USER,
                                                               DDT.DOC_TYPE_SHORT_NAME,
                                                               DDPF.FILE_VERSION,
                                                               DDPF.LAST_MODIFIED_DATE,
                                                               DDPF.LAST_MODIFIED_USER
                                                           FROM 
                                                             SO.DG_DOC_PACKAGE_FILE DDPF
                                                             INNER JOIN SO.DG_DOC_PACKAGE DDP ON DDPF.DOC_PKG_ID = DDP.DOC_PKG_ID AND DDPF.JOB_ID = DDP.JOB_ID 
                                                             INNER JOIN SO.DGM_DOC_TYPE DDT ON DDP.DOC_TYPE_ID=DDT.DOC_TYPE_ID
                                                           WHERE 
                                                              DDPF.JOB_ID = :JOB_ID  AND DDP.DOC_TYPE_ID = :DOC_TYPE_ID";

      /// <summary>
      /// Query to get the legacy tst db name
      /// </summary>
      public static readonly string GetLegacyTstDbName = @"SELECT
                                                              DB_NAME
                                                           FROM 
                                                              SO.TST_SYB_DATABASE 
                                                           WHERE 
                                                              DR_ADDRESS_ID = :DR_ADDRESS_ID";
   }
}
