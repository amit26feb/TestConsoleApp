﻿// <copyright file="DocumentPackageServiceDomainException.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DocumentPackageService.Common.Exceptions
{
    using System;
    using System.Runtime.Serialization;

    /// <summary>
    /// Document package service domain exception
    /// </summary>
    [Serializable]
    public class DocumentPackageServiceDomainException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentPackageServiceDomainException"/> class.
        /// </summary>
        public DocumentPackageServiceDomainException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentPackageServiceDomainException"/> class.
        /// </summary>
        /// <param name="message">Message value</param>
        public DocumentPackageServiceDomainException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentPackageServiceDomainException"/> class.
        /// </summary>
        /// <param name="message">Message value</param>
        /// <param name="innerException">Inner Exception</param>
        public DocumentPackageServiceDomainException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentPackageServiceDomainException"/> class.
        /// </summary>
        /// <param name="info">The serialization info</param>
        /// <param name="context">The streaming context</param>
        protected DocumentPackageServiceDomainException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}