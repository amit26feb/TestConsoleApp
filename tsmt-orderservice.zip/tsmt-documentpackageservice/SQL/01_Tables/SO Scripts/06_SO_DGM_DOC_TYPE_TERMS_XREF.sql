CREATE TABLE "SO"."DGM_DOC_TYPE_TERMS_XREF"
(
 "DOC_TYPE_ID" NUMBER(9,0) NOT NULL,  
 "TERMS_COND_ID" NUMBER(9,0) NOT NULL,
 "SEQUENCE_NBR" NUMBER(9,0) NOT NULL,
 "DEFAULT_IND" NUMBER(1,0) DEFAULT 0 NOT NULL,
 "EFFECTIVE_DATE" DATE,
 "EXPIRATION_DATE" DATE,
 "CREATED_DATE" DATE,
 "CREATED_BY_USER" VARCHAR2(12),
 "LAST_MODIFIED_DATE" DATE,
 "LAST_MODIFIED_USER" VARCHAR2(12),
 CONSTRAINT "DGM_DOC_TYPE_TERMS_XREF_PK" PRIMARY KEY ("DOC_TYPE_ID", "TERMS_COND_ID"),
 CONSTRAINT "FK_DOC_TYPE_TERMS_XREF_DT_ID" FOREIGN KEY ("DOC_TYPE_ID") REFERENCES "SO"."DGM_DOC_TYPE"("DOC_TYPE_ID"),
 CONSTRAINT "FK_DOC_TYPE_TERMS_XREF_TC_ID" FOREIGN KEY ("TERMS_COND_ID") REFERENCES "SO"."DGM_TERMS_CONDITIONS"("TERMS_COND_ID")
);

COMMENT ON TABLE SO.DGM_DOC_TYPE_TERMS_XREF IS 'Reference table to maintain the relation between the document type and a terms and conditions .';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.DOC_TYPE_ID IS 'Unique identifier of the document type with reference DGM_DOC_TYPE table.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.TERMS_COND_ID IS 'Unique identifier of the terms and conditions with reference DGM_TERMS_CONDITIONS table.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.SEQUENCE_NBR IS 'Indicates the order in which the terms and conditions should be listed.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.DEFAULT_IND IS 'Indicates whether the terms and condition is the default for the document type.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.EFFECTIVE_DATE IS 'The date on which the reference will become available for use.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.EXPIRATION_DATE IS 'The date, if any, upon which the reference will no longer be available for use.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.CREATED_DATE IS 'The date on which the reference was added to the database.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.CREATED_BY_USER IS 'The user who has added the reference to the database.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.LAST_MODIFIED_DATE IS 'The date on which the reference was most recently modified.';
COMMENT ON COLUMN SO.DGM_DOC_TYPE_TERMS_XREF.LAST_MODIFIED_USER IS 'The user who has most recently modified the reference.';