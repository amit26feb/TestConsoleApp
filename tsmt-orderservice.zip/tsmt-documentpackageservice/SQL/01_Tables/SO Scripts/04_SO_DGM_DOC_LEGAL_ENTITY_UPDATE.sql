-- Updated with TSMTDOC-2589  Legal Entity:  Obsolete "Trane Energy Services LLC� so it is no longer an available legal entity option
UPDATE SO.DGM_LEGAL_ENTITY
SET ENTITY_EXPIRATION_DATE = '26-JUN-2020'
WHERE LEGAL_ENTITY_ID = 23;