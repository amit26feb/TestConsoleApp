﻿// <copyright file="NintexApiHttpClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace ApiClient.Test
{
    using System.Net.Http;
    using TSMT.ApiClient;
    using Xunit;

    /// <summary>
    /// Nintex api http client test
    /// </summary>
    public class NintexApiHttpClientTest: HttpClient
    {
        private readonly string url = "http://dontmatter1.com";
        private readonly string token = "xyz123";
        private readonly NintexApiHttpClient nintexApiHttpClient;

        public NintexApiHttpClientTest()
        {
            nintexApiHttpClient = new NintexApiHttpClient();
        }

        /// <summary>
        /// Post content to invalid Url and returns waits for activation
        /// </summary>
        [Fact]
        public void PostAsync_InvalidUrl_WaitsForActivation()
        {
            // Arrange
            var content = new StringContent("[{'id':1,'value':'1'}]");

            // Act
            var result = this.nintexApiHttpClient.PostAsync(this.url, this.token, content);

            //Assert
            Assert.Equal("WaitingForActivation", result.Status.ToString());
        }

        /// <summary>
        /// Post content to empty Url and returns exception
        /// </summary>
        [Fact]
        public void PostAsync_EmptyUrl_ReturnsException()
        {
            // Arrange
            var content = new StringContent("[{'id':1,'value':'1'}]");

            // Act
            var result = this.nintexApiHttpClient.PostAsync("", "", content);

            //Assert
            Assert.Equal("Faulted", result.Status.ToString());
            Assert.Equal("Invalid URI: The URI is empty.", result.Exception.InnerException.Message);            
        }

        /// <summary>
        /// Post content to invalid Url format and returns exception
        /// </summary>
        [Fact]
        public void PostAsync_InvalidUrlFormat_ReturnsException()
        {
            // Arrange
            var content = new StringContent("[{'id':1,'value':'1'}]");

            // Act
            var result = this.nintexApiHttpClient.PostAsync("dontmatter1.com", this.token, content);

            //Assert
            Assert.Equal("Faulted", result.Status.ToString());
            Assert.Equal("Invalid URI: The format of the URI could not be determined.", result.Exception.InnerException.Message);
        }
    }
}
