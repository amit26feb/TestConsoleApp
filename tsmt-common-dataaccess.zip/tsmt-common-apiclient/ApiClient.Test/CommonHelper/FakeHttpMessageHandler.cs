﻿// <copyright file="FakeHttpMessageHandler" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace ApiClient.Test.CommonHelper
{
    using System.Net.Http;
    using System.Threading;
    using System.Threading.Tasks;

    /// <summary>
    /// Fake HTTP message handler for test cases
    /// </summary>
    public class FakeHttpMessageHandler : HttpMessageHandler
    {
        /// <summary>
        /// Send an HTTP request
        /// </summary>
        /// <param name="request">Request</param>
        /// <returns>HTTP status code and okta token</returns>
        public virtual HttpResponseMessage Send(HttpRequestMessage request)
        {
            CancellationToken cancellationToken = new CancellationToken();
            return SendAsync(request, cancellationToken).Result;
        }

        /// <summary>
        /// Send an HTTP request as an asynchronous operation.
        /// </summary>
        /// <param name="request">Request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>HTTP status code and okta token</returns>
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            return Task.FromResult(Send(request));
        }
    }

}
