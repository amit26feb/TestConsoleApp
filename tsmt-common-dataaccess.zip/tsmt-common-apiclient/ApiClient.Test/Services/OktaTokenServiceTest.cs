﻿// <copyright file="OktaTokenServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace ApiClient.Test.Services
{
	using ApiClient.Test.CommonHelper;
	using Microsoft.Extensions.Options;
	using Moq;
	using System.Net;
	using System.Net.Http;
	using System.Threading.Tasks;
	using TSMT.ApiClient.Services;
	using TSMT.Settings;
	using Xunit;

	/// <summary>
	/// Okta token service test
	/// </summary>
	public class OktaTokenServiceTest
	{
		private const string OktaClientId = "abc123";
		private const string OktaSecretKey = "a1b2c3";
		private const string OktaServerId = "def456";
		private const string ClientSecretCojo = "abcd0123";
		private const string ClientIdCojo = "123456";
		private const string SecretKeyCojo = "1bc23";
		private const string OktaDomain = "https://trane.okta.com/";
		private readonly Mock<IOptions<TSMTSettings>> options;
		private Mock<FakeHttpMessageHandler> fakeHttpMessageHandler;
		private HttpClient httpClient;

		public OktaTokenServiceTest()
		{
			this.options = new Mock<IOptions<TSMTSettings>>();
			this.fakeHttpMessageHandler = new Mock<FakeHttpMessageHandler> { CallBase = true };
			this.httpClient = new HttpClient(this.fakeHttpMessageHandler.Object);
		}

		[Fact]
		public async Task GetAccessToken_GivenValidToken_ReturnsExistingToken()
		{
			// Arrange
			this.options.Setup(x => x.Value).Returns(new TSMTSettings()
			{
				ClientSecretCojo = ClientSecretCojo,
				ClientIdCojo = ClientIdCojo,
				SecretKeyCojo = SecretKeyCojo,
				OktaClientIdForMicroServiceAccess = OktaClientId,
				OktaClientSecretKeyForMicroServiceAccess = OktaSecretKey,
				OktaAuthorizationServerID = OktaServerId,
				OktaDomain = OktaDomain,
				OktaDomainCredentialFlow = OktaDomain
			});

			this.fakeHttpMessageHandler.Setup(x => x.Send(It.IsAny<HttpRequestMessage>())).Returns(new HttpResponseMessage
			{
				StatusCode = HttpStatusCode.OK,
				Content = new StringContent(@"{""token_type"":""Bearer"",""expires_in"":28800,""access_token"":""bleh""}"),
			});

			var oktaTokenService = new OktaTokenService(this.options.Object, this.httpClient);
			await oktaTokenService.GetAccessToken(); // make it grab a valid token

			// Act			
			await oktaTokenService.GetAccessToken();

			// Assert
			this.fakeHttpMessageHandler.Verify(x => x.Send(It.IsAny<HttpRequestMessage>()), Times.Once);
		}

		[Fact]
		public async Task GetAccessToken_GivenInvalidToken_AttemptsToRetrieveNewToken()
		{
			// Arrange
			this.options.Setup(x => x.Value).Returns(new TSMTSettings()
			{
				ClientSecretCojo = ClientSecretCojo,
				ClientIdCojo = ClientIdCojo,
				SecretKeyCojo = SecretKeyCojo,
				OktaClientIdForMicroServiceAccess = OktaClientId,
				OktaClientSecretKeyForMicroServiceAccess = OktaSecretKey,
				OktaAuthorizationServerID = OktaServerId,
				OktaDomain = OktaDomain,
				OktaDomainCredentialFlow = OktaDomain
			});

			this.fakeHttpMessageHandler.Setup(x => x.Send(It.IsAny<HttpRequestMessage>())).Returns(new HttpResponseMessage
			{
				StatusCode = HttpStatusCode.OK,
				Content = new StringContent(@"{""token_type"":""Bearer"",""expires_in"":28800,""access_token"":""""}"),
			});

			var oktaTokenService = new OktaTokenService(this.options.Object, this.httpClient);
			await oktaTokenService.GetAccessToken(); // make it grab an invalid token

			// Act			
			await oktaTokenService.GetAccessToken();

			// Assert
			this.fakeHttpMessageHandler.Verify(x => x.Send(It.IsAny<HttpRequestMessage>()), Times.Exactly(2));
		}

		/// <summary>
		/// Get access token - Returns null
		/// </summary>
		/// <returns>Null</returns>
		[Fact]
		public async Task GetAccessToken_InvalidClientCredentials_ReturnsNull()
		{
			// Arrange
			this.options.Setup(x => x.Value).Returns(new TSMTSettings()
			{
				ClientSecretCojo = ClientSecretCojo,
				ClientIdCojo = ClientIdCojo,
				SecretKeyCojo = SecretKeyCojo,
				OktaClientIdForMicroServiceAccess = OktaClientId,
				OktaClientSecretKeyForMicroServiceAccess = OktaSecretKey,
				OktaAuthorizationServerID = OktaServerId,
				OktaDomain = OktaDomain,
				OktaDomainCredentialFlow = OktaDomain
			});

			this.fakeHttpMessageHandler.Setup(x => x.Send(It.IsAny<HttpRequestMessage>())).Returns(new HttpResponseMessage
			{
				StatusCode = HttpStatusCode.Unauthorized,
				Content = new StringContent("my string, that needs to be returned")
			});

			var oktaTokenService = new OktaTokenService(this.options.Object, this.httpClient);

			// Act
			var result = await oktaTokenService.GetAccessToken();

			// Assert
			Assert.Null(result);
			this.fakeHttpMessageHandler.Verify(x => x.Send(It.IsAny<HttpRequestMessage>()), Times.Once);
			this.options.Verify(x => x.Value, Times.Exactly(4));
		}

		/// <summary>
		/// Get access token - Returns new access token
		/// </summary>
		/// <returns>New access token</returns>
		[Fact]
		public async Task GetAccessToken_ValidClientCredentials_ReturnsNewAccessToken()
		{
			// Arrange
			this.options.Setup(x => x.Value).Returns(new TSMTSettings()
			{
				ClientSecretCojo = ClientSecretCojo,
				ClientIdCojo = ClientIdCojo,
				SecretKeyCojo = SecretKeyCojo,
				OktaClientIdForMicroServiceAccess = OktaClientId,
				OktaClientSecretKeyForMicroServiceAccess = OktaSecretKey,
				OktaAuthorizationServerID = OktaServerId,
				OktaDomain = OktaDomain,
				OktaDomainCredentialFlow = OktaDomain
			});

			this.fakeHttpMessageHandler.Setup(x => x.Send(It.IsAny<HttpRequestMessage>())).Returns(new HttpResponseMessage
			{
				StatusCode = HttpStatusCode.OK,
				Content = new StringContent("{\"access_token\": \"BearerToken\"}"),
			});

			var oktaTokenService = new OktaTokenService(this.options.Object, this.httpClient);

			// Act
			var result = await oktaTokenService.GetAccessToken();

			// Assert
			Assert.NotNull(result);
			Assert.Equal("BearerToken", result);
			this.fakeHttpMessageHandler.Verify(x => x.Send(It.IsAny<HttpRequestMessage>()), Times.Once);
			this.options.Verify(x => x.Value, Times.Exactly(4));
		}
	}
}
