// <copyright file="ApiHttpClientTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace ApiClient.Test
{
    using CrossCuttingServices.Common.Exceptions;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Primitives;
    using Moq;
    using Moq.Protected;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using TSMT.ApiClient;
    using TSMT.ApiClient.Common.Constants;
    using TSMT.ApiClient.Services;
    using Xunit;

    public class ApiHttpClientTest
    {
        private readonly Mock<IOktaTokenService> tokenService;
        private readonly Mock<IHttpContextAccessor> httpContextAccessor;
        private readonly Mock<ILogger<ApiHttpClient>> loggerMock;
        private readonly Mock<IHttpClientFactory> clientFactoryMock;
        private ApiHttpClient apiHttpClient;
        private string baseAddress = "http://test";

        private readonly string requestUri = "http://test.tsmt.com/poc/draftbillling";
        private readonly string serviceName = "BILLING_TRIGGER";
        private readonly string apiKey = "xDU2NPk1bcdffgdkfdgwwP3elCMsHwZI284Ax1rk8sf";
        private readonly HttpContent httpContent = new StringContent("[{'id':1,'value':'1'}]", Encoding.UTF8, "application/json");
        private readonly string bearerToken = "Bearer eyJraWQiOiJiMEg0RDBEYnZUMXFVUWNsRFRFcWM0TC";

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiHttpClientTest"/> class.
        /// </summary>
        public ApiHttpClientTest()
        {
            this.tokenService = new Mock<IOktaTokenService>();
            this.httpContextAccessor = new Mock<IHttpContextAccessor>();
            this.loggerMock = new Mock<ILogger<ApiHttpClient>>();
            this.clientFactoryMock = new Mock<IHttpClientFactory>();
            this.clientFactoryMock.SetReturnsDefault(new HttpClient());
        }

        [Fact]
        public void IHttpContextAccessorConstructor_EmptyHeaders_DoesNotFail()
        {
            // Arrange
            this.httpContextAccessor.Setup(m => m.HttpContext.Request.Headers).Returns(new HeaderDictionary());
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Assert
            Assert.Empty(this.apiHttpClient.httpClient.DefaultRequestHeaders);
        }

        [Fact]
        public void IHttpContextAccessorConstructor_UnimportantHeader_DoesNotAddHeader()
        {
            // Arrange
            HeaderDictionary headers = new HeaderDictionary
            {
                { "unimportant", new StringValues("junk") }
            };
            this.httpContextAccessor.Setup(m => m.HttpContext.Request.Headers).Returns(headers);
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Assert
            Assert.Empty(this.apiHttpClient.httpClient.DefaultRequestHeaders);
        }

        [Fact]
        public void IHttpContextAccessorConstructor_AuthHeader_IsCopied()
        {
            // Arrange
            HeaderDictionary headers = new HeaderDictionary
            {
                { "authorization", new Microsoft.Extensions.Primitives.StringValues("Bearer 123") }
            };
            this.httpContextAccessor.Setup(m => m.HttpContext.Request.Headers).Returns(headers);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Assert
            Assert.NotNull(this.apiHttpClient.httpClient.DefaultRequestHeaders);

            // Check upper Auth
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("Authorization"));
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("Authorization").Count() == 1);
            Assert.Contains("Bearer 123", this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("Authorization"));

            // Check lower auth
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("authorization"));
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("authorization").Count() == 1);
            Assert.Contains("Bearer 123", this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("authorization"));
        }

        [Fact]
        public void IHttpContextAccessorConstructor_XHeaders_AreCopied()
        {
            // Arrange
            string userName = "UserName";
            string password = "P@$$WeRD";

            HeaderDictionary headers = new HeaderDictionary
            {
                { "x-one", new Microsoft.Extensions.Primitives.StringValues(userName) },
                { "x-two", new Microsoft.Extensions.Primitives.StringValues(password) }
            };
            this.httpContextAccessor.Setup(m => m.HttpContext.Request.Headers).Returns(headers);
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Assert
            Assert.NotNull(this.apiHttpClient.httpClient.DefaultRequestHeaders);
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Count() == 2);

            // Check upper x-one
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("X-ONE"));
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("X-ONE").Count() == 1);
            Assert.Contains(userName, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("X-ONE"));

            // Check lower x-one
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("x-one"));
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("x-one").Count() == 1);
            Assert.Contains(userName, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("x-one"));

            // Check upper x-two
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("X-TWO"));
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("X-TWO").Count() == 1);
            Assert.Contains(password, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("X-TWO"));

            // Check lower x-two
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("x-two"));
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("x-two").Count() == 1);
            Assert.Contains(password, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("x-two"));
        }

        [Fact]
        public void ApiHttpClientConstructor_ServiceNameIsNotEmpty_CreatesNamedClient()
        {
            // Arrange
            string serviceName = "testServiceName";

            //Act
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object, serviceName);

            // Assert
            this.clientFactoryMock.Verify(x => x.CreateClient(serviceName), Times.Once);
            this.clientFactoryMock.Verify(x => x.CreateClient(""), Times.Never);
        }

        [Fact]
        public void ApiHttpClientConstructor_ServiceNameIsEmpty_CreatesDefaultClient()
        {
            //Act
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Assert
            this.clientFactoryMock.Verify(x => x.CreateClient(""), Times.Once);
        }

        [Fact]
        public void ApiHttpClientConstructor_DoesNotAddBupdHeader()
        {
            // Arrange & Act
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Assert
            Assert.False(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("X-API-DB-ID"));
        }

        /// <summary>
        /// Add impersonation token - Success
        /// </summary>
        [Fact]
        public async Task GetAsync_GivenImpersonationTokenAdded_SetsDefaultRequestHeaders()
        {
            // Arrange
            string authorizationHeaderName = "Authorization";
            string url = "getsomething";
            string expectedUrl = String.Join("/", this.baseAddress, url);
            HeaderDictionary headers = new HeaderDictionary
            {
                { "authorization", new StringValues(authorizationHeaderName) },
            };

            string someToken = "sometoken";
            this.httpContextAccessor.Setup(m => m.HttpContext.Request.Headers).Returns(headers);
            this.tokenService.Setup(x => x.GetAccessToken()).Returns(Task.FromResult(someToken));
            Mock<HttpContent> content = new Mock<HttpContent>();
            var handlerMock = new Mock<HttpMessageHandler>();
            var responseObject = new JsonErrorResponse()
            {
                Messages = new List<string>()
                {
                    "test",
                }
            };
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(responseObject), Encoding.UTF8, "application/json"),
            };
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            var client = new HttpClient(handlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.SetBaseAddress(this.baseAddress);
            this.apiHttpClient.AddImpersonationToken();

            // Act
            await this.apiHttpClient.GetAsync<JsonErrorResponse>(url);

            // Assert
            Assert.Contains($"Bearer {someToken}", this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("authorization"));
            Assert.Contains("X-API-ImpersonateToken", this.apiHttpClient.httpClient.DefaultRequestHeaders.ToString());
            this.tokenService.Verify(x => x.GetAccessToken(), Times.Once);
        }

        [Fact]
        public async Task GetAsync_GivenClientCredentialFlow_SetsAuthHeader()
        {
            // Arrange
            string authorizationHeaderName = "Authorization";
            string url = "getsomething";
            string expectedUrl = String.Join("/", this.baseAddress, url);
            HeaderDictionary headers = new HeaderDictionary
            {
                { "authorization", new StringValues(authorizationHeaderName) },
            };

            string someToken = "sometoken";
            this.httpContextAccessor.Setup(m => m.HttpContext.Request.Headers).Returns(headers);
            this.tokenService.Setup(x => x.GetAccessToken()).Returns(Task.FromResult(someToken));
            Mock<HttpContent> content = new Mock<HttpContent>();
            var handlerMock = new Mock<HttpMessageHandler>();
            var responseObject = new JsonErrorResponse()
            {
                Messages = new List<string>()
                {
                    "test",
                }
            };
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(responseObject), Encoding.UTF8, "application/json"),
            };
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            var client = new HttpClient(handlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.SetBaseAddress(this.baseAddress);
            this.apiHttpClient.AddClientCredentialAuthorizationToken();

            // Act
            JsonErrorResponse result = await this.apiHttpClient.GetAsync<JsonErrorResponse>(url);

            // Assert
            Assert.Equal(responseObject.Messages, result.Messages);
            handlerMock.Protected().Verify("SendAsync",
                Times.Exactly(1),
                ItExpr.Is<HttpRequestMessage>(req =>
                    req.Method == HttpMethod.Get
                    && req.RequestUri.ToString() == expectedUrl
                    && req.Headers.Authorization.ToString() == $"Bearer {someToken}"),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task PostAsync_ShouldSendRequest_ReturnsResult()
        {
            // Arrange
            string url = "postsomething";
            string expectedUrl = String.Join("/", this.baseAddress, url);
            Mock<HttpContent> content = new Mock<HttpContent>();
            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(101), Encoding.UTF8, "application/json"),
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            var client = new HttpClient(handlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.SetBaseAddress(this.baseAddress);

            // Act
            int result = await this.apiHttpClient.PostAsync<int>(url, content.Object);

            // Assert
            Assert.Equal(101, result);
            handlerMock.Protected().Verify("SendAsync",
                Times.Exactly(1),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri.ToString() == expectedUrl),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task PutAsync_ShouldSendRequest_ReturnsResult()
        {
            // Arrange
            string url = "putsomething";
            string expectedUrl = String.Join("/", this.baseAddress, url);
            Mock<HttpContent> content = new Mock<HttpContent>();
            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(true), Encoding.UTF8, "application/json"),
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            var client = new HttpClient(handlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.SetBaseAddress(this.baseAddress);

            // Act
            bool result = await this.apiHttpClient.PutAsync<bool>(url, content.Object);

            // Assert
            Assert.True(result);
            handlerMock.Protected().Verify("SendAsync",
                Times.Exactly(1),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Put && req.RequestUri.ToString() == expectedUrl),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task SendAsync_ShouldSendRequest_ReturnsResponseMessage()
        {
            // Arrange
            string url = "sendsomething";
            string expectedUrl = String.Join("/", this.baseAddress, url);
            Mock<HttpContent> content = new Mock<HttpContent>();
            var handlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(true), Encoding.UTF8, "application/json"),
            };
            HttpRequestMessage request = new HttpRequestMessage()
            {
                Content = new StringContent("test"),
                Method = HttpMethod.Get,
                RequestUri = new Uri(expectedUrl),
            };
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            var client = new HttpClient(handlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.SetBaseAddress(this.baseAddress);

            // Act
            HttpResponseMessage message = await this.apiHttpClient.SendAsync(request);

            // Assert
            Assert.Equal(message, response);
            handlerMock.Protected().Verify("SendAsync",
                Times.Exactly(1),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Get && req.RequestUri.ToString() == expectedUrl),
                ItExpr.IsAny<CancellationToken>());
        }

        [Fact]
        public async Task HandleResponse_SuccessStatus_ReturnsResponse()
        {
            // Arrange
            HttpResponseMessage message = new HttpResponseMessage()
            {
                Content = new StringContent(JsonConvert.SerializeObject(false), Encoding.UTF8, "application/json"),
                StatusCode = HttpStatusCode.OK,
            };
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.SetBaseAddress(this.baseAddress);

            // Act
            bool result = await this.apiHttpClient.HandleResponse<bool>(message);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task HandleResponse_BadRequestStatus_ThrowsDomainException()
        {
            // Arrange
            HttpResponseMessage message = new HttpResponseMessage()
            {
                Content = new StringContent("An error has occurred", Encoding.UTF8, "application/text"),
                StatusCode = HttpStatusCode.BadRequest,
            };
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            var result = await Assert.ThrowsAsync<DomainException>(async () => await this.apiHttpClient.HandleResponse<bool>(message));

            // Assert
            Assert.IsAssignableFrom<DomainException>(result);
            Assert.Equal("An error has occurred", result.Message);
        }

        [Fact]
        public async Task HandleResponse_InternalServerErrorStatus_ThrowsException()
        {
            // Arrange
            HttpResponseMessage message = new HttpResponseMessage()
            {
                Content = new StringContent("unknown error", Encoding.UTF8, "application/text"),
                StatusCode = HttpStatusCode.InternalServerError,
            };
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            var result = await Assert.ThrowsAsync<InvalidOperationException>(async () => await this.apiHttpClient.HandleResponse<bool>(message));

            // Assert
            Assert.IsAssignableFrom<InvalidOperationException>(result);
            Assert.Equal(message.ToString(), result.Message);
        }

        [Theory]
        [InlineData("")]
        [InlineData("test")]
        [InlineData("http://test with space")]
        [InlineData("//testWithInvalidStructure.")]
        [InlineData("http:/invalidUri")]
        public void SetBaseAddress_InvalidUri_ThrowsDomainException(string baseAddressToTest)
        {
            // Arrange
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            DomainException exception = Assert.Throws<DomainException>(() => this.apiHttpClient.SetBaseAddress(baseAddressToTest));

            // Assert
            Assert.Null(this.apiHttpClient.httpClient.BaseAddress);
            Assert.Equal(exception.Message, $"Invalid Uri: {baseAddressToTest}");
        }

        [Fact]
        public void SetBaseAddress_ValidUri_ShouldSetBaseAddress()
        {
            // Arrange
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            this.apiHttpClient.SetBaseAddress(this.baseAddress);

            // Assert
            Assert.Contains(this.baseAddress, this.apiHttpClient.httpClient.BaseAddress.AbsoluteUri);
        }

        [Fact]
        public async Task PostAsync_SuccessfulStatusCode_ReturnsHttpResponseMessage()
        {
            // Arrange
            Mock<HttpMessageHandler> httpMessageHandlerMock = new Mock<HttpMessageHandler>();
            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(true), Encoding.UTF8, "application/json"),
            };
            httpMessageHandlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            HttpClient client = new HttpClient(httpMessageHandlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.AddClientCredentialAuthorizationToken();
            this.tokenService.Setup(m => m.GetAccessToken()).Returns(Task.FromResult(bearerToken));

            // Act
            HttpResponseMessage result = await this.apiHttpClient.PostAsync(this.requestUri, this.serviceName, this.apiKey, this.httpContent);

            // Assert
            Assert.Equal(response, result);
            httpMessageHandlerMock.Protected().Verify("SendAsync",
                Times.Exactly(1),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri.AbsoluteUri == this.requestUri),
                ItExpr.IsAny<CancellationToken>());
            Assert.Single(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ServiceName));
            Assert.Equal(this.serviceName, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ServiceName).Single());
            Assert.Single(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ApiKey));
            Assert.Equal(this.apiKey, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ApiKey).Single());
            Assert.Equal(new AuthenticationHeaderValue(AppConstants.Bearer, bearerToken), this.apiHttpClient.httpClient.DefaultRequestHeaders.Authorization);
            this.tokenService.Verify(m => m.GetAccessToken(), Times.Once());
        }

        [Fact]
        public async Task PostAsync_BadRequest_ReturnsHttpResponseMessage()
        {
            // Arrange
            HttpContent httpContent = new StringContent("{}", Encoding.UTF8, "application/json");
            Mock<HttpMessageHandler> httpMessageHandlerMock = new Mock<HttpMessageHandler>();
            HttpResponseMessage response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.BadRequest,
                Content = new StringContent(JsonConvert.SerializeObject("Bad request message"), Encoding.UTF8, "application/json"),
            };
            httpMessageHandlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            HttpClient client = new HttpClient(httpMessageHandlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);

            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.AddClientCredentialAuthorizationToken();
            this.tokenService.Setup(m => m.GetAccessToken()).Returns(Task.FromResult(bearerToken));

            // Act
            HttpResponseMessage result = await this.apiHttpClient.PostAsync(this.requestUri, this.serviceName, this.apiKey, httpContent);

            // Assert
            Assert.Equal(response, result);
            httpMessageHandlerMock.Protected().Verify("SendAsync",
                Times.Exactly(1),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri.AbsoluteUri == this.requestUri),
                ItExpr.IsAny<CancellationToken>());
            Assert.Single(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ServiceName));
            Assert.Equal(this.serviceName, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ServiceName).Single());
            Assert.Single(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ApiKey));
            Assert.Equal(this.apiKey, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ApiKey).Single());
            Assert.Equal(new AuthenticationHeaderValue(AppConstants.Bearer, bearerToken), this.apiHttpClient.httpClient.DefaultRequestHeaders.Authorization);
            this.tokenService.Verify(m => m.GetAccessToken(), Times.Once());
        }

        [Fact]
        public async Task PostAsync_SuccessfulStatusCodeWithExistHeaderValues_ReturnsHttpResponseMessage()
        {
            // Arrange
            Mock<HttpMessageHandler> httpMessageHandlerMock = new Mock<HttpMessageHandler>();
            HttpResponseMessage response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(true), Encoding.UTF8, "application/json"),
            };
            httpMessageHandlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>()).Returns(Task.FromResult(response));
            HttpClient client = new HttpClient(httpMessageHandlerMock.Object);
            this.clientFactoryMock.SetReturnsDefault(client);


            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);
            this.apiHttpClient.AddClientCredentialAuthorizationToken();
            this.apiHttpClient.httpClient.DefaultRequestHeaders.Add(AppConstants.ServiceName, serviceName);
            this.apiHttpClient.httpClient.DefaultRequestHeaders.Add(AppConstants.ApiKey, apiKey);
            this.tokenService.Setup(m => m.GetAccessToken()).Returns(Task.FromResult(bearerToken));

            // Act
            HttpResponseMessage result = await this.apiHttpClient.PostAsync(this.requestUri, this.serviceName, this.apiKey, this.httpContent);

            // Assert
            Assert.Equal(response, result);
            httpMessageHandlerMock.Protected().Verify("SendAsync",
                Times.Exactly(1),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri.AbsoluteUri == this.requestUri),
                ItExpr.IsAny<CancellationToken>());
            Assert.Single(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ServiceName));
            Assert.Equal(this.serviceName, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ServiceName).Single());
            Assert.Single(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ApiKey));
            Assert.Equal(this.apiKey, this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues(AppConstants.ApiKey).Single());
            Assert.Equal(new AuthenticationHeaderValue(AppConstants.Bearer, bearerToken), this.apiHttpClient.httpClient.DefaultRequestHeaders.Authorization);
            this.tokenService.Verify(m => m.GetAccessToken(), Times.Once());
        }

        [Fact]
        public void AddAuthorization_DoesNotAttemptToGenerateTokens()
        {
            // Arrange
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            this.apiHttpClient.AddAuthorization("bleh");

            // Assert
            this.tokenService.Verify(s => s.GetAccessToken(), Times.Never);
        }

        [Fact]
        public void AddImpersonationToken_DoesNotAttemptToGenerateTokens()
        {
            // Arrange
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            this.apiHttpClient.AddImpersonationToken();

            // Assert
            this.tokenService.Verify(s => s.GetAccessToken(), Times.Never);
        }

        [Fact]
        public void AddClientCredentialAuthorizationToken_DoesNotAttemptToGenerateTokens()
        {
            // Arrange
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            this.apiHttpClient.AddClientCredentialAuthorizationToken();

            // Assert
            this.tokenService.Verify(s => s.GetAccessToken(), Times.Never);
        }

        [Fact]
        public void AddGraphAPIAuthorizationHeader_AddTokenInAuthorizationHeader_TokenAdded()
        {
            // Arrange
            string accessToken = "test";
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            this.apiHttpClient.AddGraphAPIAuthorizationHeader(accessToken);

            // Assert
            Assert.Equal(accessToken, this.apiHttpClient.httpClient.DefaultRequestHeaders.Authorization.ToString());
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("ConsistencyLevel"));
        }

        [Fact]
        public void AddGraphAPIAuthorizationHeader_CalledTwice_ConsistencyLevelSetJustOnce()
        {
            // Arrange
            string accessToken = "test";
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            this.apiHttpClient.AddGraphAPIAuthorizationHeader(accessToken);
            this.apiHttpClient.AddGraphAPIAuthorizationHeader(accessToken);

            // Assert
            Assert.Equal(accessToken, this.apiHttpClient.httpClient.DefaultRequestHeaders.Authorization.ToString());
            Assert.Single(this.apiHttpClient.httpClient.DefaultRequestHeaders.GetValues("ConsistencyLevel"));
        }

        [Fact]
        public void AddBupdApplicationEnvironmentHeader_AddsDefaultRequestHeader()
        {
            // Arrange
            this.apiHttpClient = new ApiHttpClient(this.httpContextAccessor.Object, this.tokenService.Object, this.loggerMock.Object, this.clientFactoryMock.Object);

            // Act
            this.apiHttpClient.AddBupdApplicationEnvironmentHeader();

            // Assert
            Assert.True(this.apiHttpClient.httpClient.DefaultRequestHeaders.Contains("X-API-DB-ID"));
        }
    }
}
