﻿using System;
using TSMT.ApiClient.Models;
using Xunit;

namespace ApiClient.Test.Models
{
	public class OktaTokenTest
	{
		private OktaToken OktaToken;

		[Fact]
		public void IsValidToken_GivenNotExpiredAndValidTokenText_ReturnsTrue()
		{
			// Arrange			
			this.OktaToken = new OktaToken() { AccessToken = "valid", ExpiresAt = DateTime.UtcNow.AddDays(1) };

			// Act / Assert			
			Assert.True(this.OktaToken.IsValidToken());
		}

		[Fact]
		public void IsValidToken_GivenBadTokenText_ReturnsFalse()
		{
			// Arrange
			this.OktaToken = new OktaToken() { AccessToken = String.Empty };

			// Act / Assert			
			Assert.False(this.OktaToken.IsValidToken());
		}

		[Fact]
		public void IsValidToken_GivenExpiredToken_ReturnsFalse()
		{
			// Arrange
			this.OktaToken = new OktaToken() { AccessToken = "valid", ExpiresAt = DateTime.UtcNow.AddDays(-1) };

			// Act / Assert			
			Assert.False(this.OktaToken.IsValidToken());
		}
	}
}
