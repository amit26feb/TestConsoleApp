﻿// <copyright file="AppConstants.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.ApiClient.Common.Constants
{
    /// <summary>
    /// Application constants class.
    /// </summary>
    public static class AppConstants
    {
        /// <summary>
        /// Service name.
        /// </summary>
        public const string ServiceName = "service_name";

        /// <summary>
        /// Api key name.
        /// </summary>
        public const string ApiKey = "x-api-key";

        /// <summary>
        /// Bearer token key name.
        /// </summary>
        public const string Bearer = "Bearer";
    }
}
