﻿namespace TSMT.ApiClient
{
    using System.Net.Http;
    using System.Threading.Tasks;

    /// <summary>
    /// Interface for ApiHttpClient to enable unit testing http methods
    /// </summary>
    public interface IApiHttpClient
    {
        /// <summary>
        /// Get data from the uri
        /// </summary>
        /// <param name="requestUri">Uri to get from</param>
        /// <typeparamref name="T">The response type</typeparamref>
        /// <returns>Task of <typeparamref name="T"/></returns>
        Task<T> GetAsync<T>(string requestUri);

        /// <summary>
        /// Get data from the uri
        /// </summary>
        /// <param name="requestUri">Uri to get from</param>
        /// <returns>Task of <see cref="System.Net.Http.HttpResponseMessage"/></returns>
        Task<HttpResponseMessage> GetAsync(string requestUri);

        /// <summary>
        /// Post data to the uri
        /// </summary>
        /// <param name="requestUri">Uri to post to</param>
        /// <param name="content">HttpContent to post</param>
        /// <typeparamref name="T">The response type</typeparamref>
        /// <returns>Task of <typeparamref name="T"/></returns>
        Task<T> PostAsync<T>(string requestUri, HttpContent content);

        /// <summary>
        /// Post data to the uri
        /// </summary>
        /// <param name="requestUri">Uri to post to</param>
        /// <param name="content">HttpContent to post</param>		
        /// <returns>Task of <see cref="System.Net.Http.HttpResponseMessage"/></returns>
        Task<HttpResponseMessage> PostAsync(string requestUri, HttpContent content);

        /// <summary>
        /// Method to post data to AWS api gateway with service name, api key and okta authorization bearer token in header.
        /// </summary>
        /// <param name="requestUri">Request URI.</param>
        /// <param name="serviceName">Service name.</param>
        /// <param name="apiKey">Api key.</param>
        /// <param name="httpContent">Http content.</param>
        /// <returns>Http response message.</returns>
        Task<HttpResponseMessage> PostAsync(string requestUri, string serviceName, string apiKey, HttpContent httpContent);

        /// <summary>
        /// Put data to the request uri
        /// </summary>
        /// <param name="requestUri">Uri to put to</param>
        /// <param name="content">HttpContent to put</param>
        /// <typeparamref name="T">The response type</typeparamref>
        /// <returns>Task of <typeparamref name="T"/></returns>
        Task<T> PutAsync<T>(string requestUri, HttpContent content);

        /// <summary>
        /// Put data to the request uri
        /// </summary>
        /// <param name="requestUri">Uri to get from</param>
        /// /// <param name="content">HttpContent to put</param>
        /// <returns>Task of <see cref="System.Net.Http.HttpResponseMessage"/></returns>
        Task<HttpResponseMessage> PutAsync(string requestUri, HttpContent content);

        /// <summary>
        /// Send an HTTP request
        /// </summary>
        /// <param name="request">Http request message</param>
        /// <returns>Http response message</returns>
        Task<HttpResponseMessage> SendAsync(HttpRequestMessage request);

        /// <summary>
        /// Add authorization header.  Should only be used for background calls where this class was not 
        /// created using IHttpContextAccessor.
        /// </summary>
        /// <param name="token">Token to add to authorization</param>
        void AddAuthorization(string token);

        /// <summary>
        /// Adds impersonation token
        /// </summary>
        void AddImpersonationToken();

        /// <summary>
        /// Add client credential authorization token in header.
        /// </summary>
        void AddClientCredentialAuthorizationToken();

        /// <summary>
        /// Method to set the base address of the http client
        /// </summary>
        /// <param name="baseAddress">the base address to be set to the http client</param>
        void SetBaseAddress(string baseAddress);

        /// <summary>
        /// Add token genarated from graph API client
        /// </summary>
        /// <param name="token">Token</param>
        void AddGraphAPIAuthorizationHeader(string token);

        /// <summary>
        /// Add header to target Business Unit Product Data environment (BUPD).
        /// </summary>
        void AddBupdApplicationEnvironmentHeader();
    }
}
