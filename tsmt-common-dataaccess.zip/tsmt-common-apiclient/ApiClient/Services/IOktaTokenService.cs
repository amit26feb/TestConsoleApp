﻿// <copyright file="IOktaTokenService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.ApiClient.Services
{
    using System.Threading.Tasks;

    /// <summary>
    /// Token service interface
    /// </summary>
    public interface IOktaTokenService
    {
        /// <summary>
        /// Gets a new access token or returns the current one if it is valid and not expired
        /// </summary>
        /// <returns>Access token</returns>
        Task<string> GetAccessToken();
    }
}
