﻿// <copyright file="OktaTokenService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.ApiClient.Services
{
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using TSMT.ApiClient.Models;
    using TSMT.Settings;

    /// <summary>
    /// Okta token service class
    /// </summary>
    public class OktaTokenService : IOktaTokenService
    {
        /// <summary>
        /// Okta token
        /// </summary>
        private OktaToken oktaToken;

        private readonly IOptions<TSMTSettings> tsmtSettings;

        private readonly HttpClient httpClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="OktaTokenService"/> class.
        /// </summary>
        /// <param name="tsmtSettings">TSMT settings</param>
        /// <param name="httpClient">Http client</param>
        public OktaTokenService(IOptions<TSMTSettings> tsmtSettings, HttpClient httpClient)
        {
            this.tsmtSettings = tsmtSettings;
            this.httpClient = httpClient;
        }

        /// <inheritdoc/>
        public async Task<string> GetAccessToken()
        {
            if (this.oktaToken == null || !this.oktaToken.IsValidToken())
            {
                var oktaDomain = this.tsmtSettings.Value.OktaDomain;
                var authorizationServerId = this.tsmtSettings.Value.OktaAuthorizationServerID;
                var clientId = this.tsmtSettings.Value.OktaClientIdForMicroServiceAccess;
                var clientSecretKey = this.tsmtSettings.Value.OktaClientSecretKeyForMicroServiceAccess;
                this.oktaToken = await GetNewAccessToken(this.httpClient, oktaDomain, authorizationServerId, clientId, clientSecretKey);
            }

            return this.oktaToken?.AccessToken;
        }

        /// <summary>
        /// Calls okta to get a new access token using the client credential flow.
        /// </summary>
		/// <param name="httpClient">Http client</param>
		/// <param name="oktaDomain">The domain</param>
		/// <param name="authorizationServerId">The authorization server</param>
		/// <param name="clientId">The okta client id</param>
		/// <param name="clientSecretKey">The okta client secret</param>
        /// <returns>The okta token.  Null if the request failed.</returns>
        private static async Task<OktaToken> GetNewAccessToken(HttpClient httpClient, string oktaDomain, string authorizationServerId, string clientId, string clientSecretKey)
        {
            var encodedClientCredentials = Encoding.UTF8.GetBytes($"{clientId}:{clientSecretKey}");
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(encodedClientCredentials));
            var postMessage = new Dictionary<string, string>
            {
                { "grant_type", "client_credentials" },
                { "scope", "AuthScope" }
            };
            var oktaUrl = $"{oktaDomain}oauth2/{authorizationServerId}/v1/token";
            var request = new HttpRequestMessage(HttpMethod.Post, oktaUrl)
            {
                Content = new FormUrlEncodedContent(postMessage)
            };

            var cancellationToken = new CancellationToken();

            var response = await httpClient.SendAsync(request, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var token = JsonConvert.DeserializeObject<OktaToken>(json);

                // calculate the expiration time of the token
                // include some fudge factor
                token.ExpiresAt = DateTime.UtcNow.AddSeconds(token.ExpiresIn).AddMinutes(-1);
                return token;
            }
            else
            {
                return null;
            }
        }
    }
}
