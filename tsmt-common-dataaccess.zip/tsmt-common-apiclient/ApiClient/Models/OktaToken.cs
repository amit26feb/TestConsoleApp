﻿// <copyright file="OktaToken.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.ApiClient.Models
{
	using Newtonsoft.Json;
	using System;

	/// <summary>
	/// Represents the okta token properties
	/// </summary>
	public class OktaToken
	{
		/// <summary>
		/// Gets or sets access token
		/// </summary>
		[JsonProperty(PropertyName = "access_token")]
		public string AccessToken { get; set; }

		/// <summary>
		/// Gets or sets expires in
		/// </summary>
		[JsonProperty(PropertyName = "expires_in")]
		public int ExpiresIn { get; set; }

		/// <summary>
		/// Gets or sets expires at
		/// </summary>
		public DateTime ExpiresAt { get; set; }

		/// <summary>
		/// Checks if token is valid or not
		/// </summary>
		public bool IsValidToken()
		{
			return !string.IsNullOrEmpty(this.AccessToken) && this.ExpiresAt > DateTime.UtcNow;
		}
	}
}
