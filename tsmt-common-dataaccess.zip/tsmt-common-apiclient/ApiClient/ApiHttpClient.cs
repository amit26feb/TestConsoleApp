﻿// <copyright file="ApiHttpClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.ApiClient
{
    using CrossCuttingServices.Common.Exceptions;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using System;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using TSMT.ApiClient.Common.Constants;
    using TSMT.ApiClient.Services;

    /// <summary>
    /// API Http Client class that scrapes authorization header from the incoming request so calls to other API services include the bearer auth token.  
    /// Can also be used in background service if a token is provided.
    /// </summary>
    public class ApiHttpClient : IApiHttpClient
    {
        private const string AuthorizationHeaderName = "Authorization";
        private const string ConsistencyLevelHeaderName = "ConsistencyLevel";
        private const string ImpersonationTokenName = "X-API-ImpersonateToken";
        private const string ApplicationEnvironmentHeaderName = "X-API-DB-ID";        

        private enum AuthFlow
        {
            User,
            Impersonation,
            ClientCredential,
            PassThru
        }

        private string UserToken;

        private AuthFlow CredentialFlow = AuthFlow.User;
        private readonly IOktaTokenService oktaTokenService;
        private readonly IHttpContextAccessor accessor;
        private readonly ILogger<ApiHttpClient> apiClientLogger;

        /// <summary>
        /// Gets or sets http client
        /// </summary>
        public readonly HttpClient httpClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiHttpClient"/> class.
        /// Should be used by default for in request calls/injection.
        /// </summary>
        /// <param name="accessor">Http context accessor for the request</param>
        /// <param name="oktaTokenService">Okta token service</param>
        /// <param name="logger">The logger interface</param>
        /// <param name="clientFactory">The http client factory</param>
        /// <param name="serviceName">Name of the client to create</param>
        public ApiHttpClient(IHttpContextAccessor accessor,
            IOktaTokenService oktaTokenService,
            ILogger<ApiHttpClient> logger,
            IHttpClientFactory clientFactory,
            string serviceName = null)
        {
            this.accessor = accessor;
            this.oktaTokenService = oktaTokenService;
            this.apiClientLogger = logger;
            this.httpClient = !string.IsNullOrWhiteSpace(serviceName) ? clientFactory.CreateClient(serviceName) : clientFactory.CreateClient();
            if (accessor?.HttpContext?.Request?.Headers?.Any() == true)
            {
                Microsoft.Extensions.Primitives.StringValues values;
                if (accessor.HttpContext.Request.Headers.TryGetValue(AuthorizationHeaderName, out values))
                {
                    this.CredentialFlow = AuthFlow.PassThru;
                    this.httpClient.DefaultRequestHeaders.Add(AuthorizationHeaderName, values.AsEnumerable());
                }

                foreach (var header in accessor.HttpContext.Request.Headers)
                {
                    if (header.Key.StartsWith("x-"))
                    {
                        this.httpClient.DefaultRequestHeaders.Add(header.Key, header.Value.AsEnumerable());
                    }
                }
            }
        }

        /// <inheritdoc/>
        public void AddAuthorization(string token)
        {
            this.UserToken = token;
            this.CredentialFlow = AuthFlow.User;
        }

        /// <inheritdoc/>
        public void AddImpersonationToken()
        {
            this.CredentialFlow = AuthFlow.Impersonation;
        }

        /// <summary>
        /// Add client credential authorization token in header.
        /// </summary>
        public void AddClientCredentialAuthorizationToken()
        {
            this.CredentialFlow = AuthFlow.ClientCredential;
        }

        /// <inheritdoc/>
        public void AddBupdApplicationEnvironmentHeader()
        {
            this.httpClient.DefaultRequestHeaders.Remove(ApplicationEnvironmentHeaderName);
            this.httpClient.DefaultRequestHeaders.Add(ApplicationEnvironmentHeaderName, "bupd");
        }

        /// <summary>
        /// Add token genarated from graph API client
        /// </summary>
        /// <param name="token">Token</param>
        public void AddGraphAPIAuthorizationHeader(string token)
        {
            this.httpClient.DefaultRequestHeaders.Remove(AuthorizationHeaderName);
            this.httpClient.DefaultRequestHeaders.Add(AuthorizationHeaderName, token);

            // Graph API uses an index for searching user details from AD,
            // that may not be up-to-date with recent changes to the object. So we are setting the consistency level header
            if (this.httpClient.DefaultRequestHeaders.Contains(ConsistencyLevelHeaderName))
            {
                this.httpClient.DefaultRequestHeaders.Remove(ConsistencyLevelHeaderName);
            }
            this.httpClient.DefaultRequestHeaders.Add(ConsistencyLevelHeaderName, "eventual");
        }

        /// <summary>
        /// Get data from the uri
        /// </summary>
        /// <param name="requestUri">Uri to get from</param>
        /// <typeparamref name="T">The response type</typeparamref>
        /// <returns>Task of <typeparamref name="T"/></returns>
        public async Task<T> GetAsync<T>(string requestUri)
        {
            HttpResponseMessage response = await this.GetAsync(requestUri);
            return await this.HandleResponse<T>(response);
        }

        /// <inheritdoc />
        public async Task<HttpResponseMessage> GetAsync(string requestUri)
        {
            await this.AddAuthorizationHeader();
            HttpResponseMessage response = await this.httpClient.GetAsync(requestUri);
            this.apiClientLogger.LogInformation($"API Client request {requestUri} returned status: {response.StatusCode}");
            return response;
        }

        /// <summary>
        /// Post data to the uri
        /// </summary>
        /// <param name="requestUri">Uri to post to</param>
        /// <param name="content">HttpContent to post</param>
        /// <typeparamref name="T">The response type</typeparamref>
        /// <returns>Task of <typeparamref name="T"/></returns>
        public async Task<T> PostAsync<T>(string requestUri, HttpContent content)
        {
            HttpResponseMessage response = await this.PostAsync(requestUri, content);
            return await this.HandleResponse<T>(response);
        }

        /// <inheritdoc />
        public async Task<HttpResponseMessage> PostAsync(string requestUri, HttpContent content)
        {
            await this.AddAuthorizationHeader();
            HttpResponseMessage response = await this.httpClient.PostAsync(requestUri, content);
            this.apiClientLogger.LogInformation($"API Client request {requestUri} returned status: {response.StatusCode}");
            return response;
        }

        /// <summary>
        /// Method to post data to AWS api gateway with service name, api key and okta authorization bearer token in header.
        /// </summary>
        /// <param name="requestUri">Request URI.</param>
        /// <param name="serviceName">Service name.</param>
        /// <param name="apiKey">Api key.</param>
        /// <param name="httpContent">Http content.</param>
        /// <returns>Http response message.</returns>
        public async Task<HttpResponseMessage> PostAsync(string requestUri, string serviceName, string apiKey, HttpContent httpContent)
        {
            if (!this.httpClient.DefaultRequestHeaders.Contains(AppConstants.ServiceName))
            {
                this.httpClient.DefaultRequestHeaders.Add(AppConstants.ServiceName, serviceName);
            }

            if (!this.httpClient.DefaultRequestHeaders.Contains(AppConstants.ApiKey))
            {
                this.httpClient.DefaultRequestHeaders.Add(AppConstants.ApiKey, apiKey);
            }

            await this.AddAuthorizationHeader();
            return await this.httpClient.PostAsync(requestUri, httpContent);
        }

        /// <summary>
        /// Put data to the request uri
        /// </summary>
        /// <param name="requestUri">Uri to put to</param>
        /// <param name="content">HttpContent to put</param>
        /// <typeparamref name="T">The response type</typeparamref>
        /// <returns>Task of <typeparamref name="T"/></returns>
        public async Task<T> PutAsync<T>(string requestUri, HttpContent content)
        {
            HttpResponseMessage response = await this.PutAsync(requestUri, content);
            return await this.HandleResponse<T>(response);
        }

        /// <inheritdoc />
        public async Task<HttpResponseMessage> PutAsync(string requestUri, HttpContent content)
        {
            await this.AddAuthorizationHeader();
            return await this.httpClient.PutAsync(requestUri, content);
        }

        /// <summary>
        /// Send an HTTP request
        /// </summary>
        /// <param name="request">Http request message</param>
        /// <returns>Http response message</returns>
        public async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request)
        {
            await this.AddAuthorizationHeader();
            return await this.httpClient.SendAsync(request);
        }

        /// <summary>
        /// Method to handle http the response message based on the status code
        /// </summary>
        /// <param name="response">The http response message</param>
        /// <returns>Task of <typeparamref name="T"/> if success status</returns>
        public async Task<T> HandleResponse<T>(HttpResponseMessage response)
        {
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<T>();
            }
            else if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                throw new DomainException(await response.Content.ReadAsStringAsync());
            }
            else
            {
                throw new InvalidOperationException(response.ToString());
            }
        }

        /// <summary>
        /// Method to set the base address of the http client
        /// </summary>
        /// <param name="baseAddress">the base address to be set to the http client</param>
        public void SetBaseAddress(string baseAddress)
        {
            if (Uri.IsWellFormedUriString(baseAddress, UriKind.Absolute))
            {
                this.httpClient.BaseAddress = new Uri(baseAddress);
            }
            else
            {
                throw new DomainException($"Invalid Uri: {baseAddress}");
            }
        }

        private async Task AddAuthorizationHeader()
        {
            if (this.CredentialFlow != AuthFlow.PassThru)
            {
                this.httpClient.DefaultRequestHeaders.Remove(AuthorizationHeaderName);
                this.httpClient.DefaultRequestHeaders.Remove(ImpersonationTokenName);

                switch (this.CredentialFlow)
                {
                    case AuthFlow.ClientCredential:
                        this.httpClient.DefaultRequestHeaders.Add(AuthorizationHeaderName, "Bearer " + (await this.oktaTokenService.GetAccessToken()));
                        break;
                    case AuthFlow.Impersonation:
                        this.httpClient.DefaultRequestHeaders.Add(AuthorizationHeaderName, "Bearer " + (await this.oktaTokenService.GetAccessToken()));
                        this.httpClient.DefaultRequestHeaders.Add(ImpersonationTokenName, this.accessor.HttpContext.Request.Headers[AuthorizationHeaderName].AsEnumerable());
                        break;
                    case AuthFlow.User:
                        this.httpClient.DefaultRequestHeaders.Add(AuthorizationHeaderName, $"Bearer {this.UserToken}");
                        break;
                }
            }
        }
    }
}
