﻿// <copyright file="NintexApiHttpClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.ApiClient
{
    using System;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web;
    using TSMT.ApiClient.Services;

    /// <summary>
    /// Nintex API Http Client class
    /// </summary>
    public class NintexApiHttpClient: HttpClient, INintexApiHttpClient
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NintexApiHttpClient"/> class.
        /// Should be used by default for in request calls/injection.
        /// </summary>
        public NintexApiHttpClient()
            :base()
        {

        }

        /// <summary>
        /// Post data to the uri
        /// </summary>
        /// <param name="requestUri">Request uri</param>
        /// <param name="token">Token</param>
        /// <param name="content">Content</param>
        /// <returns>Http response message</returns>
        public async Task<HttpResponseMessage> PostAsync(string requestUri, string token, HttpContent content)
        {
            var uriBuilder = new UriBuilder(new Uri(requestUri));
            var query = HttpUtility.ParseQueryString(uriBuilder.Query);
            query["token"] = token;
            uriBuilder.Query = query.ToString();
            return await this.PostAsync(uriBuilder.Uri, content);
        }
    }
}
