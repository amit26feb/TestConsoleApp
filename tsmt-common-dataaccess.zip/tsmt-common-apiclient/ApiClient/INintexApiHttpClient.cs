﻿// <copyright file="INintexApiHttpClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.ApiClient.Services
{
    using System.Net.Http;
    using System.Threading.Tasks;

    /// <summary>
    /// Nintex api http Client interface
    /// </summary>
    public interface INintexApiHttpClient
    {
        /// <summary>
        /// Post data to the uri
        /// </summary>
        /// <param name="requestUri">Uri to post to</param>
        /// <param name="token">Token</param>
        /// <param name="content">Http content to post</param>
        /// <returns>Http response message</returns>
        Task<HttpResponseMessage> PostAsync(string requestUri, string token, HttpContent content);
    }
}
