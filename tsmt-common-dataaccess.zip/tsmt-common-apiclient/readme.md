# Summary
This library is responsible for calling TSMT API resources.  This library wraps the HttpClient and applies the headers relating to Authentication & Authorization.

# Getting Started
In order to register this module for dependency injection please register the following classes.

## Autofac implementation

```
builder.RegisterType(typeof(ApiHttpClient)).As(typeof(IApiHttpClient));
builder.RegisterType(typeof(HttpContextAccessor)).As(typeof(IHttpContextAccessor));
builder.RegisterType(typeof(OktaTokenService)).As(typeof(IOktaTokenService)).SingleInstance();
builder.RegisterType(typeof(HttpClient));
builder.RegisterType(typeof(TSMTSettings));
```

### Details for Registered Classes

1. IApiHttpClient 
   - Thin wrapper around .net HttpClient class. 
1. HttpContextAccessor
   - Used to grab headers on the current http request
1. OktaTokenService
   - Responsible for generating and caching OktaTokens
1. TSMTSettings
   - In the situation where Client Credential or Impersonation flows are used the library expects the following settings to be defined
      -  `OktaDomain`
      -  `OktaAuthorizationServerID`
      -  `OktaClientIdForMicroServiceAccess`
      -  `OktaClientSecretKeyForMicroServiceAccess`

## .net core Service Registration (Startup.cs)

In order to register the HttpClient and other dependencies call `IServiceCollection.AddHttpClient()` during startup.

```
public IServiceProvider ConfigureServices(IServiceCollection services)
{
   ...
   services.AddHttpClient();
   ...
}
```

# Version History

## Version 5.x
- Refactor of ApiHttpClient
  - In order to prevent the entire client from failing when an Okta failure occurs tokens are no longer applied immediately by `AddImpersonationToken`, `AddClientCredentialAuthorizationToken`, and `AddAuthorization` (user token flow) but instead when each HTTP request is sent.
  - PostAsync overload that accepts a service name and API key follows the same pattern as other methods for authorization and supports Client Credential, Impersonation, and User token flows.
    - **NOTE: Previously this assumed ClientCredential flow.  This may need to be addressed in consumers when updating to version 5.**
- Bug fix in OktaToken that was causing tokens to immediately expire