// <copyright file="Helper.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Common
{
    using System.Collections.Generic;
    using TSMT.CAM.Data.Core.Models;

    public static class Helper
    {
        /// <summary>
        /// Gets CAM Data
        /// </summary>
        /// <returns>Cam data</returns>
        public static CamData GetCamData()
        {
            return new CamData()
            {
                DrAddressId = 1,
                UserId = "ABC",
                LocalLock = new LockData()
                {
                    JobId = 1234,
                    LockUserId = "ABC",
                    CreditProjectLocks = new List<CreditProjectLock>()
                    {
                        new CreditProjectLock()
                        {
                            LockUserId = "ABC",
                            ChangeAllowedIndicator = 'Y',
                            ChangeOrderDecisionStatus = 5,
                            ChangeOrderStatus = "Pending",
                            CreditJobId = 12343545,
                            LegacyCreditJobNumber = "CR01",
                            SalesOrderLocks = new List<SalesOrderLock>()
                            {
                                new SalesOrderLock()
                                {
                                    SalesOrderId = 98656,
                                    ChangeOrderStatus = "XX",
                                    LockUserId = "ABC"
                                }
                            }
                        }
                    }
                },
                HostLock = new LockData()
                {
                    JobId = 1234,
                    LockUserId = "ABC",
                    CreditProjectLocks = new List<CreditProjectLock>()
                    {
                        new CreditProjectLock()
                        {
                            LockUserId = "ABC",
                            ChangeAllowedIndicator = 'Y',
                            ChangeOrderDecisionStatus = 5,
                            ChangeOrderStatus = "Pending",
                            CreditJobId = 12343545,
                            LegacyCreditJobNumber = "CR01",
                            SalesOrderLocks = new List<SalesOrderLock>()
                            {
                                new SalesOrderLock()
                                {
                                    SalesOrderId = 98656,
                                    ChangeOrderStatus = "XX",
                                    LockUserId = "ABC"
                                },
                                new SalesOrderLock()
                                {
                                    SalesOrderId = 3232,
                                    ChangeOrderStatus = null,
                                    LockUserId = "ABC"
                                }
                            }
                        }
                    }
                }
            };
        }

        /// <summary>
        /// Gets context conditions
        /// </summary>
        /// <returns>Conditions to execute for the context</returns>
        public static IEnumerable<ContextCondition> GetContextConditions()
        {
            return new List<ContextCondition>
            {
                new ContextCondition()
                {
                    Id = "1",
                    Context = "CopyDown",
                    Source = "Job",
                    ConditionCheckerComponent = "CheckLocalJobAvailableConditionChecker",
                    Priority = 1
                },
                new ContextCondition()
                {
                    Id = "2",
                    Context = "CopyDown",
                    Source = "Ordering",
                    ConditionCheckerComponent = "CheckLocalNoProjectRecordConditionChecker",
                    Priority = 1
                },
                new ContextCondition()
                {
                    Id = "3",
                    Context = "CopyDown",
                    Source = "Order",
                    ConditionCheckerComponent = "CheckHostProjectLockConditionChecker",
                    Priority = 2
                },
                 new ContextCondition()
                {
                    Id = "4",
                    Context = "PreUpdateBillLetters",
                    Source = "Order",
                    ConditionCheckerComponent = "CheckHostSalesOrdersLockConditionChecker",
                    Priority = 1
                }
            };
        }

        /// <summary>
        /// Gets context conditions
        /// </summary>
        /// <returns>Cam input</returns>
        public static CamInput GetCamInput()
        {
            return new CamInput()
            {
                Context = "PreUpdateBillLetters",
                DrAddressId = 1,
                UserId = "ABC",
                HostData = new CamInputMetaData()
                {
                    JobId = 1234,
                    SalesOrderIds = new List<int> { 98656 }
                },
            };
        }

        /// <summary>
        /// Gets cam input for Transmitted Bid 
        /// </summary>
        /// <returns>Cam input</returns>
        public static CamInput GetCamInputForTransmittedBid()
        {
            return new CamInput()
            {
                Context = "TransmitToFinancials",
                DrAddressId = 1,
                UserId = "ABC",
                LocalData = new CamInputMetaData()
                {
                    JobId = 1234,
                    BidAlternateId = 134267,
                    CreditJobId = 0,
                    SalesOrderIds = null
                },
                HostData = new CamInputMetaData()
                {
                    JobId = 2251821,
                    BidAlternateId = 234267,
                    CreditJobId = 2491399,
                    SalesOrderIds = null
                },
            };
        }

        public static CamInputMetaData GetInputMetaData(int jobId, int creditJobId)
        {
            return new CamInputMetaData()
            {
                JobId = jobId,
                CreditJobId = creditJobId
            };
        }

        /// <summary>
        /// Gets context condition
        /// </summary>
        /// <returns>Condition to execute for the context</returns>
        public static ContextCondition GetContextCondition(string context, string source, int priority)
        {
            return new ContextCondition()
            {
                Context = context,
                Source = source,
                Priority = priority
            };
        }
    }
}
