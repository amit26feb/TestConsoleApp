// <copyright file="ContextServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoFixture;
    using CAMContextChecker.Test.Common;
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using Constant = TSMT.CAM.Context.Constants;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;
    using TSMT.CAMContext.Conditions.Common.Constants;
    using TSMT.CAMContext.Conditions.Common.Enumerator;
    using TSMT.CAMContext.Conditions.Core.Model;
    using TSMT.CAMContext.Conditions.Core.Services;
    using Xunit;
    using System;

    public class ContextServiceTest
    {
        private ContextService contextService;
        private Mock<IConditionFactory> conditionFactoryMock;
        private Mock<IDataClientFactory> dataClientFactoryMock;
        private Mock<IDataClientService> jobServiceMock;
        private Mock<IDataClientService> orderServiceMock;
        private Mock<IDataClientService> orderingServiceMock;
        private Mock<ICondition> checkLocalJobAvailableConditionCheckerMock;
        private Mock<ICondition> checkLocalNoProjectRecordConditionChecker;
        private Mock<ICondition> checkHostProjectLockConditionChecker;
        private Mock<ICondition> checkHostSalesOrdersLockConditionChecker;
        private readonly IEnumerable<ContextCondition> contextConditions;
        private CamData jobCamData;
        private CamData orderCamData;
        private CamData orderingCamData;
        private CamInput camInput;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommissionableEventsServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public ContextServiceTest()
        {
            Fixture fixture = new Fixture();
            this.conditionFactoryMock = new Mock<IConditionFactory>();
            this.dataClientFactoryMock = new Mock<IDataClientFactory>();
            this.jobServiceMock = new Mock<IDataClientService>();
            this.orderServiceMock = new Mock<IDataClientService>();
            this.orderingServiceMock = new Mock<IDataClientService>();

            this.jobServiceMock.Setup(x => x.ServiceContext).Returns(ServiceClient.Job);
            this.orderServiceMock.Setup(x => x.ServiceContext).Returns(ServiceClient.Order);
            this.orderingServiceMock.Setup(x => x.ServiceContext).Returns(ServiceClient.Ordering);
            this.dataClientFactoryMock.SetupSequence(x => x.GetServiceClientInstance(It.IsAny<ServiceClient>()))
                .Returns(this.jobServiceMock.Object)
                .Returns(this.orderingServiceMock.Object)
                .Returns(this.orderServiceMock.Object);

            this.checkLocalJobAvailableConditionCheckerMock = new Mock<ICondition>();
            this.checkLocalNoProjectRecordConditionChecker = new Mock<ICondition>();
            this.checkHostProjectLockConditionChecker = new Mock<ICondition>();
            this.checkHostSalesOrdersLockConditionChecker = new Mock<ICondition>();
            this.checkLocalJobAvailableConditionCheckerMock.Setup(x => x.ConditionContext).Returns(Condition.CheckLocalJobAvailableConditionChecker);
            this.checkLocalNoProjectRecordConditionChecker.Setup(x => x.ConditionContext).Returns(Condition.CheckLocalNoProjectRecordConditionChecker);
            this.checkHostProjectLockConditionChecker.Setup(x => x.ConditionContext).Returns(Condition.CheckHostProjectLockConditionChecker);
            this.checkHostSalesOrdersLockConditionChecker.Setup(x => x.ConditionContext).Returns(Condition.CheckHostSalesOrdersLockConditionChecker);
            this.conditionFactoryMock.SetupSequence(x => x.GetCondition(It.IsAny<Condition>()))
                .Returns(this.checkLocalJobAvailableConditionCheckerMock.Object)
                .Returns(this.checkLocalNoProjectRecordConditionChecker.Object)
                .Returns(this.checkHostProjectLockConditionChecker.Object)
                .Returns(this.checkHostSalesOrdersLockConditionChecker.Object);

            this.contextService = new ContextService(
                this.conditionFactoryMock.Object,
                this.dataClientFactoryMock.Object);
            this.jobCamData = Helper.GetCamData();
            this.orderCamData = Helper.GetCamData();
            this.orderingCamData = Helper.GetCamData();
            this.contextConditions = Helper.GetContextConditions();
            this.camInput = Helper.GetCamInput();
        }

        [Fact]
        public async Task ExecuteConditions_AllConditionsAllowed_ReturnsAllowStatus()
        {
            // Arrange
            ExecutionStatus conditionStatus = new ExecutionStatus { Status = Status.ALLOW };

            this.checkLocalJobAvailableConditionCheckerMock.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(conditionStatus));
            this.checkLocalNoProjectRecordConditionChecker.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(conditionStatus));
            this.checkHostProjectLockConditionChecker.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(conditionStatus));
            this.checkHostSalesOrdersLockConditionChecker.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(conditionStatus));

            var result = await this.contextService.ExecuteConditions(this.contextConditions, this.jobCamData);

            // Assert
            Assert.Equal(Status.ALLOW, result.Status);
            Assert.Empty(result.Messages);
            this.checkLocalJobAvailableConditionCheckerMock.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkLocalNoProjectRecordConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkHostProjectLockConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkHostSalesOrdersLockConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
        }

        [Fact]
        public async Task ExecuteConditions_OneOrMoreConditionsDenied_ReturnsDenyStatusWithErrorMessages()
        {
            //Arrange
            // Arrange
            ExecutionStatus denyStatus = new ExecutionStatus { Status = Status.DENY, Messages = new List<string>() { "Job is already locked" } };
            ExecutionStatus allowStatus = new ExecutionStatus { Status = Status.ALLOW };

            this.checkLocalJobAvailableConditionCheckerMock.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(denyStatus));
            this.checkLocalNoProjectRecordConditionChecker.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(allowStatus));
            this.checkHostProjectLockConditionChecker.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(allowStatus));
            this.checkHostSalesOrdersLockConditionChecker.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Returns(Task.FromResult(allowStatus));

            //Act
            var result = await this.contextService.ExecuteConditions(this.contextConditions, this.jobCamData);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.NotEmpty(result.Messages);
            this.checkLocalJobAvailableConditionCheckerMock.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkLocalNoProjectRecordConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkHostProjectLockConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkHostSalesOrdersLockConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
        }

        [Fact]
        public async Task ExecuteConditions_ThrowException_ReturnsDenyStatusWithErrorMessages()
        {
            // Arrange
            ExecutionStatus denyStatus = new ExecutionStatus
            {
                Status = Status.DENY,
                Messages = new List<string>() { Constant.Constants.ApplicationErrorExecutingConditions }
            };

            this.checkLocalJobAvailableConditionCheckerMock.Setup(x => x.Execute(It.IsAny<CamData>(), It.IsAny<ContextCondition>())).Throws(new Exception());

            //Act
            var result = await this.contextService.ExecuteConditions(this.contextConditions, this.jobCamData);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.Equal(result.Messages.First(), Constant.Constants.ApplicationErrorExecutingConditions);
            this.checkLocalJobAvailableConditionCheckerMock.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkLocalNoProjectRecordConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
            this.checkHostProjectLockConditionChecker.Verify(x => x.Execute(this.jobCamData, It.IsAny<ContextCondition>()), Times.Once);
        }

        [Fact]
        public async Task GetCamData_CamDataFromJobAndOrderService_ReturnCamData()
        {
            // Arrange
            this.jobCamData.HostLock = null;
            this.orderCamData.LocalLock = null;
            this.orderingCamData.HostLock = null;
            this.jobServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.jobCamData));
            this.orderServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderCamData));
            this.orderingServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderingCamData));

            // Act
            var actionResult = await this.contextService.GetCamData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(this.jobCamData.DrAddressId, actionResult.DrAddressId);
            Assert.Equal(this.jobCamData.UserId, actionResult.UserId);
            Assert.NotNull(actionResult.HostLock);
            Assert.NotNull(actionResult.LocalLock);
            this.jobServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
        }

        [Fact]
        public async Task GetCamData_CamDataFromJobServiceOnly_ReturnCamData()
        {
            // Arrange
            this.jobCamData.HostLock = null;
            this.jobCamData.LocalLock = null;
            this.orderCamData= null;
            this.orderingCamData = null;
            this.jobServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.jobCamData));
            this.orderServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderCamData));
            this.orderingServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderingCamData));

            // Act
            var actionResult = await this.contextService.GetCamData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(this.jobCamData.DrAddressId, actionResult.DrAddressId);
            Assert.Equal(this.jobCamData.UserId, actionResult.UserId);
            Assert.True(actionResult.HostLock.JobId == 0 && actionResult.HostLock.HqtrJobId == null);
            Assert.True(actionResult.LocalLock.JobId == 0 && actionResult.LocalLock.HqtrJobId == null);
            this.jobServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
        }

        [Fact]
        public async Task GetPriorityCount_GetMaxPriority_ReturnMaxPriority()
        {
            // Act
            var actionResult = await this.contextService.GetPriorityCount(this.contextConditions);

            // Assert
            Assert.Equal(this.contextConditions.Select(x => x.Priority).Distinct(), actionResult);
        }

        [Fact]
        public async Task GetCamData_HostSalesOrdersContainsCamInputSalesOrderIds_ReturnCamDataWithMatchedSalesOrders()
        {
            // Arrange           
            this.jobServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));
            this.orderServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderCamData));
            this.orderingServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));

            // Act
            CamData actionResult = await this.contextService.GetCamData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(this.orderCamData.HostLock.LockUserId, actionResult.UserId);
            Assert.Equal(this.orderCamData.HostLock.CreditProjectLocks.ElementAt(0).SalesOrderLocks.ElementAt(0).SalesOrderId,
                         actionResult.HostLock.CreditProjectLocks.ElementAt(0).SalesOrderLocks.ElementAt(0).SalesOrderId);
            this.jobServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
        }

        [Fact]
        public async Task GetCamData_CamInputHostDataIsNull_ReturnCamData()
        {
            // Arrange
            CamInput camInput = new CamInput()
            {
                Context = "PreUpdateBillLetter",
                DrAddressId = 1,
                UserId = "ABC",
                HostData = null
            };
            this.jobServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));
            this.orderServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderCamData));
            this.orderingServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));

            // Act
            CamData actionResult = await this.contextService.GetCamData(this.contextConditions, camInput);

            // Assert
            Assert.Equal(this.orderCamData.UserId, actionResult.UserId);
            Assert.Null(camInput.HostData);
            this.jobServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
            this.orderServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
        }

        [Fact]
        public async Task GetCamData_InputSalesOrderIdsIsNullWhenContextIsNotAPreUpdateBillLetter_ReturnCamData()
        {
            // Arrange
            CamInput camInput = new CamInput()
            {
                Context = "CopyDown",
                DrAddressId = 1,
                UserId = "ABC",
                HostData = new CamInputMetaData()
                {
                    JobId = 1234,
                    SalesOrderIds = null
                },
            };

            this.jobServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.jobCamData));
            this.orderServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));
            this.orderingServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));

            // Act
            CamData actionResult = await this.contextService.GetCamData(this.contextConditions, camInput);

            // Assert
            Assert.Equal(this.jobCamData.UserId, actionResult.UserId);
            Assert.Null(camInput.HostData.SalesOrderIds);
            this.jobServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
            this.orderServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
        }

        [Fact]
        public async Task GetCamData_CamInputLocalDataHasBidAlternateId_ReturnCamData()
        {
            // Arrange
            CamInput camInput = Helper.GetCamInputForTransmittedBid();
            this.orderCamData.LocalLock.CreditProjectLocks = null;
            this.jobServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));
            this.orderServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderCamData));
            this.orderingServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(new CamData()));

            // Act
            CamData actionResult = await this.contextService.GetCamData(this.contextConditions, camInput);

            // Assert
            Assert.Equal(this.orderCamData.UserId, actionResult.UserId);
            Assert.NotNull(actionResult.LocalLock.CreditProjectLocks);
            Assert.Equal(actionResult.LocalLock.CreditProjectLocks.First().BidId, camInput.LocalData.BidAlternateId);
            this.jobServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
            this.orderServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetCamInfo(camInput), Times.Once);
        }

        [Fact]
        public async Task GetCamData_OrderCamDataNotHaveCreditProjectLocks_ReturnCamData()
        {
            // Arrange
            this.jobCamData.HostLock = null;
            this.orderCamData.LocalLock = null;
            this.orderCamData.HostLock.CreditProjectLocks = null;
            this.orderingCamData.HostLock = null;
            this.jobServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.jobCamData));
            this.orderServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderCamData));
            this.orderingServiceMock.Setup(x => x.GetCamInfo(It.IsAny<CamInput>())).Returns(Task.FromResult(this.orderingCamData));

            // Act
            var actionResult = await this.contextService.GetCamData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(this.jobCamData.DrAddressId, actionResult.DrAddressId);
            Assert.Equal(this.jobCamData.UserId, actionResult.UserId);
            Assert.NotNull(actionResult.HostLock);
            Assert.NotNull(actionResult.LocalLock);
            this.jobServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetCamInfo(this.camInput), Times.Once);
        }
    }
}
