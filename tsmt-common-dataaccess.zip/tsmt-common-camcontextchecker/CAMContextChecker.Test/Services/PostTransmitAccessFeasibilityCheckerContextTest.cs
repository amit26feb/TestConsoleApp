// <copyright file="PostTransmitAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CAMContextChecker.Test.Common;
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;
    using Xunit;

    public class PostTransmitAccessFeasibilityCheckerContextTest
    {
        private readonly CamInput camInput;
        private readonly IEnumerable<ContextCondition> contextConditions;
        private Mock<IDataClientService> orderingServiceMock;
        private readonly PostTransmitAccessFeasibilityCheckerContext postTransmitAccessFeasibilityCheckerContext;
        private Mock<IDataClientService> jobServiceMock;
        private readonly Mock<IContextService> contextServiceMock;
        private readonly Mock<IDataClientFactory> dataClientFactory;

        public PostTransmitAccessFeasibilityCheckerContextTest()
        {
            this.dataClientFactory = new Mock<IDataClientFactory>();
            this.orderingServiceMock = new Mock<IDataClientService>();
            this.jobServiceMock = new Mock<IDataClientService>();
            this.contextServiceMock = new Mock<IContextService>();

            this.contextConditions = new List<ContextCondition>
            {
                Helper.GetContextCondition("PostTransmit", "Job", 1),
                Helper.GetContextCondition("PostTransmit", "Ordering", 2)
            };
            this.camInput = Helper.GetCamInput();

            this.orderingServiceMock.Setup(x => x.ServiceContext).Returns(ServiceClient.Ordering);
            this.jobServiceMock.Setup(x => x.ServiceContext).Returns(ServiceClient.Job);

            this.postTransmitAccessFeasibilityCheckerContext = new PostTransmitAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object, this.dataClientFactory.Object);

            this.dataClientFactory.SetupSequence(x => x.GetServiceClientInstance(It.IsAny<ServiceClient>()))
                .Returns(this.jobServiceMock.Object)
                .Returns(this.orderingServiceMock.Object);
        }

        [Fact]
        public async Task GetEnrichedCamInputData_InputEnrichedFromJobAndOrderingService_ReturnsCamInput()
        {
            // Arrange
            CamInput orderingCamInput = Helper.GetCamInput();
            orderingCamInput.HostData = Helper.GetInputMetaData(50345, 79003);
            orderingCamInput.LocalData = new CamInputMetaData();
            orderingCamInput.LocalData.CreditJobId = 23571;

            CamInput camInput = Helper.GetCamInput();
            camInput.HostData = Helper.GetInputMetaData(33409, 40231);

            CamInput jobCamInput = Helper.GetCamInput();
            jobCamInput.HostData = Helper.GetInputMetaData(89045, 29023);
            jobCamInput.LocalData = new CamInputMetaData();
            jobCamInput.LocalData.JobId = 66779;

            this.orderingServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(orderingCamInput));
            this.jobServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(jobCamInput));

            // Act
            var actionResult = await this.postTransmitAccessFeasibilityCheckerContext.GetEnrichedCamInputData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(jobCamInput.LocalData.JobId, actionResult.LocalData.JobId);
            Assert.Equal(orderingCamInput.LocalData.CreditJobId, actionResult.LocalData.CreditJobId);
            this.orderingServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
            this.jobServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
        }

        [Fact]
        public async Task GetEnrichedCamInputData_LocalDataNotAvailable_ReturnsCamInput()
        {
            // Arrange
            CamInput jobCamInput = null;

            CamInput orderingCamInput = null;

            CamInput camInput = Helper.GetCamInput();
            camInput.HostData = Helper.GetInputMetaData(49467, 19450);

            this.orderingServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(orderingCamInput));
            this.jobServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(jobCamInput));

            // Act
            var actionResult = await this.postTransmitAccessFeasibilityCheckerContext.GetEnrichedCamInputData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(0, actionResult.LocalData.JobId);
            Assert.Equal(0, actionResult.LocalData.CreditJobId);
            this.orderingServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
            this.jobServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
        }
    }
}
