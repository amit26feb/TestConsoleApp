// <copyright file="PreTransmitAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using Xunit;

    /// <summary>
    /// Initializes a new instance of the <see cref="PreTransmitAccessFeasibilityCheckerContextTest"/> class.
    /// </summary>
    public class PreTransmitAccessFeasibilityCheckerContextTest
    {
        private readonly PreTransmitAccessFeasibilityCheckerContext preTransmitAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        public PreTransmitAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.preTransmitAccessFeasibilityCheckerContext = new PreTransmitAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object);
        }

        [Fact]
        public void Validate_Context_ReturnContext()
        {
            // Act
            var actualResult = this.preTransmitAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(TSMT.CAM.Context.Enumerator.Context.PreTransmitAccessFeasibilityChecker, actualResult);
        }
    }
}
