// <copyright file="CopyDownAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CAMContextChecker.Test.Common;
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;
    using Xunit;

    /// <summary>
    /// Contains tests to verify edit copied down access feasibility checker context
    /// </summary>
    public class EditCopiedDownAccessFeasibilityCheckerContextTest
    {
        private readonly EditCopiedDownAccessFeasibilityCheckerContext editCopyDownAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;
        private readonly Mock<IDataClientFactory> dataClientFactory;
        private Mock<IDataClientService> jobServiceMock;
        private Mock<IDataClientService> orderingServiceMock;
        private readonly IEnumerable<ContextCondition> contextConditions;
        private readonly CamInput camInput;

        /// <summary>
        /// Initializes a new instance of the <see cref="CopyDownAccessFeasibilityCheckerContextTest"/> class.
        /// </summary>
        public EditCopiedDownAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.dataClientFactory = new Mock<IDataClientFactory>();
            this.jobServiceMock = new Mock<IDataClientService>();
            this.orderingServiceMock = new Mock<IDataClientService>();

            this.jobServiceMock.Setup(x => x.ServiceContext).Returns(ServiceClient.Job);
            this.orderingServiceMock.Setup(x => x.ServiceContext).Returns(ServiceClient.Ordering);

            this.dataClientFactory.SetupSequence(x => x.GetServiceClientInstance(It.IsAny<ServiceClient>()))
                .Returns(this.jobServiceMock.Object)
                .Returns(this.orderingServiceMock.Object);

            this.editCopyDownAccessFeasibilityCheckerContext = new EditCopiedDownAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object, this.dataClientFactory.Object);

            this.contextConditions = new List<ContextCondition>
            {
                Helper.GetContextCondition("EditCopyDown", "Job", 1),
                Helper.GetContextCondition("EditCopyDown", "Ordering", 2)
            };
            this.camInput = Helper.GetCamInput();
        }

        [Fact]
        public async Task GetEnrichedCamInputData_EnrichInputFromJobAndOrderingService_ReturnCamInput()
        {
            // Arrange
            CamInput camInput = Helper.GetCamInput();
            camInput.LocalData = Helper.GetInputMetaData(14644, 18766);

            CamInput jobServiceCamInput = Helper.GetCamInput();
            jobServiceCamInput.LocalData = Helper.GetInputMetaData(14644, 18766);
            jobServiceCamInput.HostData = new CamInputMetaData();
            jobServiceCamInput.HostData.JobId = 15934;

            CamInput orderingServiceCamInput = Helper.GetCamInput();
            orderingServiceCamInput.LocalData = Helper.GetInputMetaData(15303, 18493);
            orderingServiceCamInput.HostData = new CamInputMetaData();
            orderingServiceCamInput.HostData.CreditJobId = 15743;

            this.jobServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(jobServiceCamInput));
            this.orderingServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(orderingServiceCamInput));

            // Act
            var actionResult = await this.editCopyDownAccessFeasibilityCheckerContext.GetEnrichedCamInputData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(orderingServiceCamInput.HostData.CreditJobId, actionResult.HostData.CreditJobId);
            Assert.Equal(jobServiceCamInput.HostData.JobId, actionResult.HostData.JobId);
            this.jobServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
        }

        [Fact]
        public async Task GetEnrichedCamInputData_DoesNotHaveLocalData_ReturnCamInput()
        {
            // Arrange
            CamInput camInput = Helper.GetCamInput();
            camInput.LocalData = Helper.GetInputMetaData(15303, 18493);

            CamInput jobServiceCamInput = null;

            CamInput orderingServiceCamInput = null;

            this.jobServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(jobServiceCamInput));
            this.orderingServiceMock.Setup(x => x.GetEnrichedCamInput(It.IsAny<CamInput>())).Returns(Task.FromResult(orderingServiceCamInput));

            // Act
            var actionResult = await this.editCopyDownAccessFeasibilityCheckerContext.GetEnrichedCamInputData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(0, actionResult.HostData.CreditJobId);
            Assert.Equal(0, actionResult.HostData.JobId);
            this.jobServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
            this.orderingServiceMock.Verify(x => x.GetEnrichedCamInput(this.camInput), Times.Once);
        }
    }

}
