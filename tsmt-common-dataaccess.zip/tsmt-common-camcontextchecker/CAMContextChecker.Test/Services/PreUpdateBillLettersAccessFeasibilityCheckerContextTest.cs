// <copyright file="PreUpdateBillLettersAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Context.Enumerator;
    using Xunit;
    public class PreUpdateBillLettersAccessFeasibilityCheckerContextTest
    {
        private readonly PreUpdateBillLettersAccessFeasibilityCheckerContext preUpdateBillLettersAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        public PreUpdateBillLettersAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.preUpdateBillLettersAccessFeasibilityCheckerContext = new PreUpdateBillLettersAccessFeasibilityCheckerContext(this.contextServiceMock.Object);
        }

        [Fact]
        public void Initialize_ContextSetAsPreUpdateBillLetters_Works()
        {
            // Act
            Context context = this.preUpdateBillLettersAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(Context.PreUpdateBillLettersAccessFeasibilityChecker, context);
        }
    }
}
