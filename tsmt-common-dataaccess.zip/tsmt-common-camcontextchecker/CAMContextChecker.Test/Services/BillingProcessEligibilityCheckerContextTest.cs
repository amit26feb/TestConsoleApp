// <copyright file="BillingProcessEligibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Context.Enumerator;
    using Xunit;

    public class BillingProcessEligibilityCheckerContextTest
    {
        private readonly BillingProcessEligibilityCheckerContext billingProcessEligibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        public BillingProcessEligibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.billingProcessEligibilityCheckerContext = new BillingProcessEligibilityCheckerContext(this.contextServiceMock.Object);
        }

        [Fact]
        public void Initialize_ContextSetAsBillingProcessEligibilityCheck_Works()
        {
            // Act
            Context context = this.billingProcessEligibilityCheckerContext.Context;

            // Assert
            Assert.Equal(Context.BillingProcessEligibilityChecker, context);
        }
    }
}
