// <copyright file="ExitProjectAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using Xunit;

    public class ExitProjectAccessFeasibilityCheckerContextTest
    {
        private readonly ExitProjectAccessFeasibilityCheckerContext exitProjectAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExitProjectAccessFeasibilityCheckerContextTest"/> class.
        /// </summary>
        public ExitProjectAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.exitProjectAccessFeasibilityCheckerContext = new ExitProjectAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object);
        }

        [Fact]
        public void Validate_Context_ReturnContext()
        {
            // Act
            var actualResult = this.exitProjectAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(TSMT.CAM.Context.Enumerator.Context.ExitProjectAccessFeasibilityChecker, actualResult);
        }
    }
}
