// <copyright file="CommonAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using Xunit;

    public class DeleteUntransmittedAccessFeasibilityCheckerContextTest
    {
        private readonly DeleteUntransmittedAccessFeasibilityCheckerContext deleteUntransmittedAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteUntransmittedAccessFeasibilityCheckerContextTest"/> class.
        /// </summary>
        public DeleteUntransmittedAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.deleteUntransmittedAccessFeasibilityCheckerContext = new DeleteUntransmittedAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object);
        }

        [Fact]
        public void Validate_Context_ReturnContext()
        {
            // Act
            var actualResult = this.deleteUntransmittedAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(TSMT.CAM.Context.Enumerator.Context.DeleteUntransmittedAccessFeasibilityChecker, actualResult);
        }
    }
}
