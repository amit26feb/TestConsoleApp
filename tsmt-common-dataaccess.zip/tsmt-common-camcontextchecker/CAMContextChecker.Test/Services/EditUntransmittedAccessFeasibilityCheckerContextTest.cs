namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using Xunit;

    public class EditUntransmittedAccessFeasibilityCheckerContextTest
    {
        private readonly EditUntransmittedAccessFeasibilityCheckerContext editUntransmittedAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExitProjectAccessFeasibilityCheckerContextTest"/> class.
        /// </summary>
        public EditUntransmittedAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.editUntransmittedAccessFeasibilityCheckerContext = new EditUntransmittedAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object);
        }

        [Fact]
        public void Validate_Context_ReturnContext()
        {
            // Act
            var actualResult = this.editUntransmittedAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(TSMT.CAM.Context.Enumerator.Context.EditUntransmittedAccessFeasibilityChecker, actualResult);
        }
    }
}
