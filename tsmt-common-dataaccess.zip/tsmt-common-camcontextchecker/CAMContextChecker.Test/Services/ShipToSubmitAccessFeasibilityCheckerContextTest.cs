// <copyright file="ShipToSubmitAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Context.Enumerator;
    using Xunit;

    public class ShipToSubmitAccessFeasibilityCheckerContextTest
    {
        private readonly ShipToSubmitAccessFeasibilityCheckerContext shipToSubmitAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        public ShipToSubmitAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.shipToSubmitAccessFeasibilityCheckerContext = new ShipToSubmitAccessFeasibilityCheckerContext(this.contextServiceMock.Object);
        }

        [Fact]
        public void Initialize_ContextSetAsShipToSubmit_Works()
        {
            // Act
            Context context = this.shipToSubmitAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(Context.ShipToSubmitAccessFeasibilityChecker, context);
        }
    }
}
