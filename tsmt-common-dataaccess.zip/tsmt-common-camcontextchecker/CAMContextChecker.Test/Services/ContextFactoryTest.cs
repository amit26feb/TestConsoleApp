// <copyright file="ContextFactoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using System.Collections.Generic;
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Context.Enumerator;
    using Xunit;

    /// <summary>
    /// Contains tests to verify context factory methods
    /// </summary>
    public class ContextFactoryTest
    {
        private readonly ContextFactory contextFactory;
        private readonly IEnumerable<IContext> contextsMock;
        private readonly Mock<IContext> copyDownAccessFeasibilityCheckerContextMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContextFactoryTest"/> class.
        /// </summary>
        public ContextFactoryTest()
        {
            this.copyDownAccessFeasibilityCheckerContextMock = new Mock<IContext>();
            this.copyDownAccessFeasibilityCheckerContextMock.Setup(x => x.Context).Returns(Context.CopyDownAccessFeasibilityChecker);
            this.contextsMock = new List<IContext>()
            {
                this.copyDownAccessFeasibilityCheckerContextMock.Object,
            };

            this.contextFactory = new ContextFactory(this.contextsMock);
        }

        [Fact]
        public void GetContext_DefaultAccessFeasibilityChecker_ReturnsDefaultAccessFeasibilityCheckerContext()
        {
            // Act
            var actualResult = this.contextFactory.GetContextInstance(Context.CopyDownAccessFeasibilityChecker);

            // Assert
            Assert.Equal(Context.CopyDownAccessFeasibilityChecker, actualResult.Context);
        }
    }

}
