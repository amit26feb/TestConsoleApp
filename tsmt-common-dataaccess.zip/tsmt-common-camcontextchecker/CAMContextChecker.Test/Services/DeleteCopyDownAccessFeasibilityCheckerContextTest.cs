// <copyright file="DeleteCopyDownAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using Xunit;

    /// <summary>
    /// Contains tests to verify delete copy down access feasibility checker context
    /// </summary>
    public class DeleteCopyDownAccessFeasibilityCheckerContextTest
    {
        private readonly DeleteCopyDownAccessFeasibilityCheckerContext deleteCopyDownAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteCopyDownAccessFeasibilityCheckerContextTest"/> class.
        /// </summary>
        public DeleteCopyDownAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.deleteCopyDownAccessFeasibilityCheckerContext = new DeleteCopyDownAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object);
        }

        [Fact]
        public void Validate_Context_ReturnContext()
        {
            // Act
            var actualResult = this.deleteCopyDownAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(TSMT.CAM.Context.Enumerator.Context.DeleteCopyDownAccessFeasibilityChecker, actualResult);
        }
    }
}
