namespace CAMContextChecker.Test.Services
{
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using Xunit;

    public class ExitProjectAndJobAccessFeasibilityCheckerContextTest
    {
        private readonly ExitProjectAndJobAccessFeasibilityCheckerContext exitProjectAndJobAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExitProjectAndJobAccessFeasibilityCheckerContextTest"/> class.
        /// </summary>
        public ExitProjectAndJobAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.exitProjectAndJobAccessFeasibilityCheckerContext = new ExitProjectAndJobAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object);
        }

        [Fact]
        public void Validate_Context_ReturnContext()
        {
            // Act
            var actualResult = this.exitProjectAndJobAccessFeasibilityCheckerContext.Context;

            // Assert
            Assert.Equal(TSMT.CAM.Context.Enumerator.Context.ExitProjectAndJobAccessFeasibilityChecker, actualResult);
        }
    }
}
