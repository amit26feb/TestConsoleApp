// <copyright file="CommonAccessFeasibilityCheckerContextTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMContextChecker.Test.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CAMContextChecker.Test.Common;
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Common.Constants;
    using TSMT.CAMContext.Conditions.Core.Model;
    using Xunit;

    public class CommonAccessFeasibilityCheckerContextTest
    {
        private const Context Conext = Context.EditUntransmittedAccessFeasibilityChecker;
        private readonly CommonAccessFeasibilityCheckerContext commonAccessFeasibilityCheckerContext;
        private readonly Mock<IContextService> contextServiceMock;
        private readonly IEnumerable<ContextCondition> contextConditions;
        private readonly CamData camData;
        private readonly CamInput camInput;

        /// <summary>
        /// Initializes a new instance of the <see cref="CopyDownAccessFeasibilityCheckerContextTest"/> class.
        /// </summary>
        public CommonAccessFeasibilityCheckerContextTest()
        {
            this.contextServiceMock = new Mock<IContextService>();
            this.commonAccessFeasibilityCheckerContext = new CommonAccessFeasibilityCheckerContext(
                this.contextServiceMock.Object, Conext);

            this.contextConditions = Helper.GetContextConditions();
            this.camData = Helper.GetCamData();
            this.camInput = Helper.GetCamInput();
        }

        [Fact]
        public async Task ExecuteConditions_Success_ReturnsConditionExecutionStatus()
        {
            // Arrange
            ExecutionStatus conditionExecutionStatus = new ExecutionStatus { Status = Status.ALLOW, Messages = null };
            this.contextServiceMock.Setup(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamData>())).Returns(Task.FromResult(conditionExecutionStatus));

            // Act
            var actualResult = await this.commonAccessFeasibilityCheckerContext.ExecuteConditions(this.contextConditions, this.camData);

            // Assert
            Assert.Equal(conditionExecutionStatus, actualResult);
            this.contextServiceMock.Verify(x => x.ExecuteConditions(this.contextConditions, this.camData), Times.Once);
        }

        [Fact]
        public async Task GetCamData_Success_ReturnsCamData()
        {
            // Arrange
            CamData camData = Helper.GetCamData();
            this.contextServiceMock.Setup(x => x.GetCamData(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamInput>()))
                .Returns(Task.FromResult(camData));

            // Act
            var actualResult = await this.commonAccessFeasibilityCheckerContext.GetCamData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(camData, actualResult);
            this.contextServiceMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Once);
        }

        [Fact]
        public async Task GetPriorities_Success_ReturnsPrioritiesCount()
        {
            // Arrange
            IEnumerable<int> priorityList = new List<int> { 1, 2 };
            this.contextServiceMock.Setup(x => x.GetPriorityCount(It.IsAny<IEnumerable<ContextCondition>>())).Returns(Task.FromResult(priorityList));

            // Act
            var actualResult = await this.commonAccessFeasibilityCheckerContext.GetPriorities(this.contextConditions);

            // Assert
            Assert.Equal(priorityList, actualResult);
            this.contextServiceMock.Verify(x => x.GetPriorityCount(this.contextConditions), Times.Once);
        }

        [Fact]
        public async Task GetEnrichedCamInputData_DoesNotOverride_ReturnCamInput()
        {
            // Arrange
            CamInput camInput = Helper.GetCamInput();
            camInput.HostData = Helper.GetInputMetaData(15303, 18493);

            // Act
            var actionResult = await this.commonAccessFeasibilityCheckerContext.GetEnrichedCamInputData(this.contextConditions, this.camInput);

            // Assert
            Assert.Equal(this.camInput, actionResult);
        }
    }

}
