// <copyright file="Constants.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Constants
{
    /// <summary>
    /// Contains constant entries for context checker
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Exception message for the context that is not implemented
        /// </summary>
        public const string ContextNotImplementedErrorMessage = "Context is not implemented";

        /// <summary>
        /// Exception message for error when executing conditions
        /// </summary>
        public const string ApplicationErrorExecutingConditions = "Application error when executing conditions";
    }
}
