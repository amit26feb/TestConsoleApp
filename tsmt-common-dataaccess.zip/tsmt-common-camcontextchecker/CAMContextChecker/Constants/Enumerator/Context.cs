// <copyright file="Context.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Enumerator
{
    /// <summary>
    /// Represents various contexts for which the locking is being requested
    /// </summary>
    public enum Context
    {
        /// <summary>
        /// Copy down access feasibility checker component
        /// </summary>
        CopyDownAccessFeasibilityChecker,

        /// <summary>
        /// Exit project access feasibility checker
        /// </summary>
        ExitProjectAccessFeasibilityChecker,

        /// <summary>
        /// Exit project and job access feasibility checker
        /// </summary>
        ExitProjectAndJobAccessFeasibilityChecker,

        /// <summary>
        /// Edit untransmitted access feasibility checker
        /// </summary>
        EditUntransmittedAccessFeasibilityChecker,

        /// <summary>
        /// Edit copied down access feasibility Checker
        /// </summary>
        EditCopiedDownAccessFeasibilityChecker,

        /// <summary>
        /// Delete untransmitted access feasibility checker
        /// </summary>
        DeleteUntransmittedAccessFeasibilityChecker,

        /// <summary>
        /// Pre transmit access feasibility checker
        /// </summary>
        PreTransmitAccessFeasibilityChecker,

        /// <summary>
        /// Post transmit access feasibility checker
        /// </summary>
        PostTransmitAccessFeasibilityChecker,

        /// <summary>
        /// Delete copy down access feasibility checker
        /// </summary>
        DeleteCopyDownAccessFeasibilityChecker,

        /// <summary>
        /// Ship to submit access feasibility checker
        /// </summary>
        ShipToSubmitAccessFeasibilityChecker,

        /// <summary>
        /// Pre update bill letters access feasibility checker
        /// </summary>
        PreUpdateBillLettersAccessFeasibilityChecker,

        /// <summary>
        /// Billing process eligibility checker
        /// </summary>
        BillingProcessEligibilityChecker,

        /// <summary>
        /// Post update bill letters access feasibilty checker
        /// </summary>
        PostUpdateBillLettersAccessFeasibilityChecker,
    }
}
