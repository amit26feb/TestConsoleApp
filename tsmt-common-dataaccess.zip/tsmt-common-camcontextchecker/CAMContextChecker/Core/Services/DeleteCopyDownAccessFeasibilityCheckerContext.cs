// <copyright file="DeleteCopyDownAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Core.Services;

    /// <summary>
    /// Delete copy down access feasibility checker context
    /// </summary>
    public class DeleteCopyDownAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context ContextChecker = Context.DeleteCopyDownAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteCopyDownAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        public DeleteCopyDownAccessFeasibilityCheckerContext(IContextService contextService)
            : base(contextService, ContextChecker)
        {
        }
    }
}
