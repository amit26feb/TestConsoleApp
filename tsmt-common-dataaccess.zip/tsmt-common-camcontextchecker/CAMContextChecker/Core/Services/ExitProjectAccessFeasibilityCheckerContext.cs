// <copyright file="ExitProjectAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Exit project access feasibility checker context
    /// </summary>
    public class ExitProjectAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context Conext = Context.ExitProjectAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExitProjectAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        public ExitProjectAccessFeasibilityCheckerContext(IContextService contextService)
            : base(contextService, Conext)
        {
        }
    }
}
