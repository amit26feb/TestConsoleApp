// <copyright file="ContextService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CAMContext.Conditions.Common.Constants;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;
    using TSMT.CAMContext.Conditions.Common.Enumerator;
    using TSMT.CAMContext.Conditions.Core.Model;
    using TSMT.CAMContext.Conditions.Core.Services;

    /// <summary>
    /// Contains implementation for condition execution
    /// </summary>
    public class ContextService : IContextService
    {
        private readonly IConditionFactory conditionFactory;
        private readonly IDataClientFactory dataClientFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContextService"/> class.
        /// </summary>
        /// <param name="conditionFactory">Condition factory</param>
        /// <param name="dataClientFactory">Data client factory</param>
        public ContextService(
            IConditionFactory conditionFactory,
            IDataClientFactory dataClientFactory)
        {
            this.conditionFactory = conditionFactory;
            this.dataClientFactory = dataClientFactory;
        }

        /// <summary>
        /// Executes given conditions
        /// </summary>
        /// <param name="contextConditions">Context conditions to execute</param>
        /// <param name="camData">Cam data</param>
        /// <returns>Condition execution status</returns>
        public async Task<ExecutionStatus> ExecuteConditions(IEnumerable<ContextCondition> contextConditions, CamData camData)
        {
            List<Task<ExecutionStatus>> conditionStatuses = new List<Task<ExecutionStatus>>() { };
            ExecutionStatus conditionExecutionStatus = new ExecutionStatus() { Messages = new List<string>() };

            try
            {
                contextConditions.ToList().ForEach(x =>
                {
                    conditionStatuses.Add(Task.Run(async ()
                        => await this.conditionFactory.GetCondition((Condition)Enum.Parse(typeof(Condition), x.ConditionCheckerComponent)).Execute(camData, x)));
                });

                await Task.WhenAll(conditionStatuses);
            }
            catch
            {
                conditionExecutionStatus.Status = Status.DENY;
                conditionExecutionStatus.Messages = new List<string>() { Context.Constants.Constants.ApplicationErrorExecutingConditions };
                return await Task.FromResult(conditionExecutionStatus);
            }

            // Set the overall status of the condition execution based on the status of the individual condition execution status
            conditionExecutionStatus.Status = conditionStatuses.Any(x => x.Result.Status == Status.DENY) ? Status.DENY : Status.ALLOW;

            if (conditionExecutionStatus.Status == Status.DENY)
            {
                conditionStatuses.Where(x => x.Result.Status == Status.DENY).ToList().ForEach(y =>
               {
                   conditionExecutionStatus.Messages = conditionExecutionStatus.Messages.Concat(y.Result.Messages);
               });
            }

            return await Task.FromResult(conditionExecutionStatus);
        }

        /// <summary>
        /// Gets Cam data
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Input</param>
        /// <returns>Cam data</returns>
        public async Task<CamData> GetCamData(IEnumerable<ContextCondition> contextConditions, CamInput camInput)
        {
            List<Task<CamData>> camDataList = new List<Task<CamData>>();
            (await this.GetUniqueSources(contextConditions)).ForEach(x =>
            {
                camDataList.Add(Task.Run(async () =>
                await this.dataClientFactory.GetServiceClientInstance((ServiceClient)Enum.Parse(typeof(ServiceClient), x))
                    .GetCamInfo(camInput)));
            });
            await Task.WhenAll(camDataList);

            CamData camData = new CamData()
            {
                DrAddressId = camInput.DrAddressId,
                UserId = camInput.UserId,
                LocalLock = new LockData(),
                HostLock = new LockData()
            };

            // TO-DO - need to analyze moving this logic to auto mapper
            camDataList.ForEach(x =>
           {
               CamData currentCamData = x.Result;
               if (currentCamData?.HostLock != null)
               {
                   camData.HostLock = currentCamData.HostLock;
                   if (camData.HostLock.CreditProjectLocks?.Any() == true)
                   {
                       // Get the host sales orders which are matched with cam input sales order ids and assigned into host sales orders
                       camData.HostLock.CreditProjectLocks.First().SalesOrderLocks = this.GetHostSalesOrdersByCamInputSalesOrderIds(
                                                                                          camData.HostLock.CreditProjectLocks, camInput);
                   }
               }
               if (currentCamData?.LocalLock != null)
               {
                   if (currentCamData.LocalLock.CreditProjectLocks != null)
                   {
                       camData.LocalLock.CreditProjectLocks = currentCamData.LocalLock.CreditProjectLocks;
                   }

                   if (currentCamData.LocalLock.JobId > 0)
                   {
                       camData.LocalLock.JobId = currentCamData.LocalLock.JobId;
                       camData.LocalLock.JobName = currentCamData.LocalLock.JobName;
                       camData.LocalLock.HqtrJobId = currentCamData.LocalLock.HqtrJobId;
                       camData.LocalLock.LockUserId = currentCamData.LocalLock.LockUserId;
                       camData.LocalLock.LockUserName = currentCamData.LocalLock.LockUserName;
                   }
               }
           });

            if ((camInput.LocalData?.BidAlternateId ?? 0) > 0 && camData.LocalLock.CreditProjectLocks == null)
            {
                camData.LocalLock.CreditProjectLocks = new List<CreditProjectLock>()
                {
                    new CreditProjectLock
                    {
                        BidId = camInput.LocalData.BidAlternateId.Value
                    }
                };
            }

            return camData;
        }

        /// <summary>
        /// Gets the priorities of the conditions
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <returns>List of priorities of the conditions set</returns>
        public Task<IEnumerable<int>> GetPriorityCount(IEnumerable<ContextCondition> contextConditions)
        {
            return Task.FromResult(contextConditions.OrderBy(x => x.Priority).Select(x => x.Priority).Distinct());
        }

        /// <summary>
        /// Get unique sources to load data
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <returns>Unique sources</returns>
        private Task<List<string>> GetUniqueSources(IEnumerable<ContextCondition> contextConditions)
        {
            return Task.FromResult(contextConditions.Select(x => x.Source).Distinct().ToList());
        }

        /// <summary>
        /// Get the host sales orders which are matched with cam input sales order ids
        /// </summary>
        /// <param name="creditProjectLocks">Credit project locks</param>
        /// <param name="camInput">Cam input</param>
        /// <returns>Matched host sales orders</returns>
        private IEnumerable<SalesOrderLock> GetHostSalesOrdersByCamInputSalesOrderIds(IEnumerable<CreditProjectLock> creditProjectLocks, CamInput camInput)
        {
            // For update bill letter context, will always pass only one credit job id, so even though its collection will be
            // expecting one credit project lock always. That's reason we are picking the first credit project lock from service result
            // And will validate its sales orders with cam input sales orders
            IEnumerable<SalesOrderLock> salesOrderLocks = creditProjectLocks.First().SalesOrderLocks;
            if (camInput.HostData?.SalesOrderIds != null)
            {
                // Filter the sales orders which are matched with request sales order ids(cam input) and assign them in credit project lock's(host) sales orders
                salesOrderLocks = salesOrderLocks.Where(salesOrder => camInput.HostData.SalesOrderIds.Contains(salesOrder.SalesOrderId));
            }

            return salesOrderLocks;
        }
    }
}
