// <copyright file="ExitProjectAndJobAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Exit project and job access feasibility checker context
    /// </summary>
    public class ExitProjectAndJobAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context Conext = Context.ExitProjectAndJobAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExitProjectAndJobAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        public ExitProjectAndJobAccessFeasibilityCheckerContext(IContextService contextService)
            : base(contextService, Conext)
        {
        }
    }
}
