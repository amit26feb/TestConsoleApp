// <copyright file="CopyDownAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;

    /// <summary>
    /// Represents the context for Copy Down Access Feasibility Checker
    /// </summary>
    public class CopyDownAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context Conext = Context.CopyDownAccessFeasibilityChecker;
        private readonly IDataClientFactory dataClientFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="CopyDownAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        /// /// <param name="dataClientFactory">Data client factory</param>
        public CopyDownAccessFeasibilityCheckerContext(IContextService contextService, IDataClientFactory dataClientFactory)
            : base(contextService, Conext)
        {
            this.dataClientFactory = dataClientFactory;
        }

        /// <summary>
        /// Gets enriched cam input data for copy down scenario
        /// For the copy host data will be passed in request
        /// We will enrich the local data
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Input</param>
        /// <returns>Enriched copy down cam input data</returns>
        public override async Task<CamInput> GetEnrichedCamInputData(IEnumerable<ContextCondition> contextConditions, CamInput camInput)
        {
            List<Task<CamInput>> camInputDataList = new List<Task<CamInput>>();
            List<ServiceClient> serviceClients = contextConditions.Select(x => (ServiceClient)Enum.Parse(typeof(ServiceClient), x.Source)).ToList();

            serviceClients.ForEach(x =>
            {
                camInputDataList.Add(Task.Run(async () =>
                await this.dataClientFactory.GetServiceClientInstance(x)
                    .GetEnrichedCamInput(camInput)));
            });

            await Task.WhenAll(camInputDataList);

            CamInput camInputData = new CamInput()
            {
                DrAddressId = camInput.DrAddressId,
                UserId = camInput.UserId,
                HostData = camInput.HostData,
                LocalData = new CamInputMetaData()
            };

            // TO-DO - need to analyze moving this logic to auto mapper
            camInputDataList.ForEach(x =>
            {
                CamInput currentCamInputData = x.Result;
                if (currentCamInputData?.LocalData.JobId > 0)
                {
                    camInputData.LocalData.JobId = currentCamInputData.LocalData.JobId;
                }

                if (currentCamInputData?.LocalData.CreditJobId > 0)
                {
                    camInputData.LocalData.CreditJobId = currentCamInputData.LocalData.CreditJobId;
                }
            });

            return camInputData;
        }
    }
}
