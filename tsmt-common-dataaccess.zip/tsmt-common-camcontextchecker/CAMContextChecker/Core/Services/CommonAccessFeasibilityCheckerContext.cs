// <copyright file="CommonAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Core.Model;

    /// <summary>
    /// Common access feasibility checker context
    /// </summary>
    public class CommonAccessFeasibilityCheckerContext : IContext
    {
        private readonly IContextService contextService;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommonAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        /// <param name="context">Context</param>
        public CommonAccessFeasibilityCheckerContext(IContextService contextService, Context context)
        {
            this.Context = context;
            this.contextService = contextService;
        }

        /// <summary>
        /// Gets the context
        /// </summary>
        public Context Context { get; }

        /// <summary>
        /// Executes given conditions
        /// </summary>
        /// <param name="contextConditions">Context conditions to execute</param>
        /// <param name="camData">Cam data</param>
        /// <returns>Boolean</returns>
        public async Task<ExecutionStatus> ExecuteConditions(IEnumerable<ContextCondition> contextConditions, CamData camData)
        {
            return await this.contextService.ExecuteConditions(contextConditions, camData);
        }

        /// <summary>
        /// Gets Cam data based on the conditions
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Cam input</param>
        /// <returns>Cam data</returns>
        public async Task<CamData> GetCamData(IEnumerable<ContextCondition> contextConditions, CamInput camInput)
        {
            return await this.contextService.GetCamData(contextConditions, camInput);
        }

        /// <summary>
        /// Gets the total number of priorities in the conditions set
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <returns>List of priorities of the conditions set</returns>
        public async Task<IEnumerable<int>> GetPriorities(IEnumerable<ContextCondition> contextConditions)
        {
            return await this.contextService.GetPriorityCount(contextConditions);
        }

        /// <summary>
        /// Gets enriched cam input data
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Input</param>
        /// <returns>Enriched cam input data</returns>
        public virtual async Task<CamInput> GetEnrichedCamInputData(IEnumerable<ContextCondition> contextConditions, CamInput camInput)
        {
            return await Task.FromResult(camInput);
        }
    }
}
