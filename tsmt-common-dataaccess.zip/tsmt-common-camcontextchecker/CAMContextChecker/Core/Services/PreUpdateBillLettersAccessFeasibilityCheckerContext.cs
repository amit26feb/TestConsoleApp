// <copyright file="PreUpdateBillLettersAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Represents the context for pre update bill letters access feasibility checker
    /// </summary>
    public class PreUpdateBillLettersAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context ContextType = Context.PreUpdateBillLettersAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="PreUpdateBillLettersAccessFeasibilityCheckerContext"/> class
        /// </summary>
        /// <param name="contextService">Context service</param>
        public PreUpdateBillLettersAccessFeasibilityCheckerContext(IContextService contextService)
           : base(contextService, ContextType)
        {
        }
    }
}
