// <copyright file="PostUpdateBillLettersAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Represents the context for post update bill letters access feasibility checker
    /// </summary>
    public class PostUpdateBillLettersAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context ContextType = Context.PostUpdateBillLettersAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostUpdateBillLettersAccessFeasibilityCheckerContext"/> class
        /// </summary>
        /// <param name="contextService">Context service</param>
        public PostUpdateBillLettersAccessFeasibilityCheckerContext(IContextService contextService)
           : base(contextService, ContextType)
        {
        }
    }
}
