// <copyright file="ShipToSubmitAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Represents the context for ship to submit access feasibility checker
    /// </summary>
    public class ShipToSubmitAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context ContextType = Context.ShipToSubmitAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipToSubmitAccessFeasibilityCheckerContext"/> class
        /// </summary>
        /// <param name="contextService">Context service</param>
        public ShipToSubmitAccessFeasibilityCheckerContext(IContextService contextService)
            : base(contextService, ContextType)
        {
        }
    }
}
