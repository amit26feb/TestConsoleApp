// <copyright file="IContextFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Interface for context factory
    /// </summary>
    public interface IContextFactory
    {
        /// <summary>
        /// Creates an instance of the context instance based on the context name
        /// </summary>
        /// <param name="contextName">Specifies the context type for which the locking is being requested</param>
        /// <returns>Context service instance</returns>
        IContext GetContextInstance(Context contextName);
    }
}
