// <copyright file="EditCopiedDownAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;

    /// <summary>
    /// Edit copied down access feasibility checker context
    /// </summary>
    public class EditCopiedDownAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context Conext = Context.EditCopiedDownAccessFeasibilityChecker;
        private readonly IDataClientFactory dataClientFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="EditCopiedDownAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        /// /// <param name="dataClientFactory">Data client factory</param>
        public EditCopiedDownAccessFeasibilityCheckerContext(IContextService contextService, IDataClientFactory dataClientFactory)
            : base(contextService, Conext)
        {
            this.dataClientFactory = dataClientFactory;
        }

        /// <summary>
        /// Gets enriched cam input data for edit copied down scenario
        /// For the edit copied down local data will be passed in request
        /// We will enrich the host data
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Input</param>
        /// <returns>Enriched edit copied down cam input data</returns>
        public override async Task<CamInput> GetEnrichedCamInputData(IEnumerable<ContextCondition> contextConditions, CamInput camInput)
        {
            List<ServiceClient> serviceClients = contextConditions.Select(x => (ServiceClient)Enum.Parse(typeof(ServiceClient), x.Source)).ToList();
            List<Task<CamInput>> camInputDataList = new List<Task<CamInput>>();

            serviceClients.ForEach(x =>
            {
                camInputDataList.Add(Task.Run(async () =>
                await this.dataClientFactory.GetServiceClientInstance(x)
                    .GetEnrichedCamInput(camInput)));
            });

            await Task.WhenAll(camInputDataList);

            CamInput camInputData = new CamInput()
            {
                DrAddressId = camInput.DrAddressId,
                UserId = camInput.UserId,
                HostData = new CamInputMetaData(),
                LocalData = camInput.LocalData
            };

            // TO-DO - need to analyze moving this logic to auto mapper
            camInputDataList.ForEach(x =>
            {
                CamInput currentCamInputData = x.Result;
                if (currentCamInputData?.HostData.JobId > 0)
                {
                    camInputData.HostData.JobId = currentCamInputData.HostData.JobId;
                }

                if (currentCamInputData?.HostData.CreditJobId > 0)
                {
                    camInputData.HostData.CreditJobId = currentCamInputData.HostData.CreditJobId;
                }
            });

            return camInputData;
        }
    }
}
