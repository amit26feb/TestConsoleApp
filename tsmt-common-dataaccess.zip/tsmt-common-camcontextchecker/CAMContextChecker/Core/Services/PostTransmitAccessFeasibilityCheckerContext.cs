// <copyright file="PostTransmitAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;

    /// <summary>
    /// Post transmit access feasibility checker context
    /// </summary>
    public class PostTransmitAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context ContextChecker = Context.PostTransmitAccessFeasibilityChecker;
        private readonly IDataClientFactory dataClientFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostTransmitAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        /// <param name="dataClientFactory">Data client factory</param>
        public PostTransmitAccessFeasibilityCheckerContext(IContextService contextService, IDataClientFactory dataClientFactory)
            : base(contextService, ContextChecker)
        {
            this.dataClientFactory = dataClientFactory;
        }

        /// <summary>
        /// Gets enriched cam input data for post transmit scenario
        /// Host data will be passed in request for the post transmit
        /// Local data will get enriched
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Cam input</param>
        /// <returns>Enriched post transmit cam input data</returns>
        public override async Task<CamInput> GetEnrichedCamInputData(IEnumerable<ContextCondition> contextConditions, CamInput camInput)
        {
            List<Task<CamInput>> camInputDataList = new List<Task<CamInput>>();

            CamInput camInputData = new CamInput()
            {
                DrAddressId = camInput.DrAddressId,
                UserId = camInput.UserId,
                HostData = camInput.HostData,
                LocalData = new CamInputMetaData()
            };

            List<ServiceClient> serviceClients = contextConditions.Select(x => (ServiceClient)Enum.Parse(typeof(ServiceClient), x.Source)).ToList();

            serviceClients.ForEach(x =>
            {
                camInputDataList.Add(Task.Run(async () =>
                await this.dataClientFactory.GetServiceClientInstance(x)
                    .GetEnrichedCamInput(camInput)));
            });

            await Task.WhenAll(camInputDataList);

            // TO-DO - need to analyze moving this logic to auto mapper
            camInputDataList.ForEach(x =>
            {
                CamInput currentCamInputData = x.Result;

                if (currentCamInputData?.LocalData.CreditJobId > 0)
                {
                    camInputData.LocalData.CreditJobId = currentCamInputData.LocalData.CreditJobId;
                }

                if (currentCamInputData?.LocalData.JobId > 0)
                {
                    camInputData.LocalData.JobId = currentCamInputData.LocalData.JobId;
                }
            });

            return camInputData;
        }
    }
}
