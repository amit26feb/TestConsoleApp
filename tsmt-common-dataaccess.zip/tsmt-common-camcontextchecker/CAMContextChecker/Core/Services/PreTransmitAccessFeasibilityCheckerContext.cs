// <copyright file="PreTransmitAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Pre transmit access feasibility checker context
    /// </summary>
    public class PreTransmitAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context ContextChecker = Context.PreTransmitAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="PreTransmitAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        public PreTransmitAccessFeasibilityCheckerContext(IContextService contextService)
            : base(contextService, ContextChecker)
        {
        }
    }
}
