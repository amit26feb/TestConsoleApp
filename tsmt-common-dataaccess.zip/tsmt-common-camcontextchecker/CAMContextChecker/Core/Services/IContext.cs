// <copyright file="IContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Core.Model;

    /// <summary>
    /// Represents the context for which the locking is being requested
    /// </summary>
    public interface IContext
    {
        /// <summary>
        /// Gets context for which the locking is being requested
        /// </summary>
        Context Context { get; }

        /// <summary>
        /// Executes given conditions
        /// </summary>
        /// <param name="contextConditions">Context conditions to execute</param>
        /// <param name="camData">Cam data</param>
        /// <returns>Boolean</returns>
        Task<ExecutionStatus> ExecuteConditions(IEnumerable<ContextCondition> contextConditions, CamData camData);

        /// <summary>
        /// Gets Cam data based on the conditions
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Input</param>
        /// <returns>Cam data</returns>
        Task<CamData> GetCamData(IEnumerable<ContextCondition> contextConditions, CamInput camInput);

        /// <summary>
        /// Gets the priorities of the conditions set
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <returns>List of priorities of the conditions set</returns>
        Task<IEnumerable<int>> GetPriorities(IEnumerable<ContextCondition> contextConditions);

        /// <summary>
        /// Gets enriched cam input data
        /// </summary>
        /// <param name="contextConditions">Context conditions</param>
        /// <param name="camInput">Input</param>
        /// <returns>Enriched cam input data</returns>
        Task<CamInput> GetEnrichedCamInputData(IEnumerable<ContextCondition> contextConditions, CamInput camInput);
    }
}
