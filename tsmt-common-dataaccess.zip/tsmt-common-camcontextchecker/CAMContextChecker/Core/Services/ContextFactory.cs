// <copyright file="ContextFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Context factory responsible for creating the context instance based on the context name
    /// </summary>
    public class ContextFactory : IContextFactory
    {
        private readonly IEnumerable<IContext> contexts;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContextFactory"/> class.
        /// </summary>
        /// <param name="contexts">Context list</param>
        public ContextFactory(IEnumerable<IContext> contexts)
        {
            this.contexts = contexts;
        }

        /// <summary>
        /// Gets a context based on the context name
        /// </summary>
        /// <param name="contextName">Context name</param>
        /// <returns>Context</returns>
        public IContext GetContextInstance(Context contextName)
        {
            return this.contexts.First(x => x.Context == contextName);
        }
    }
}
