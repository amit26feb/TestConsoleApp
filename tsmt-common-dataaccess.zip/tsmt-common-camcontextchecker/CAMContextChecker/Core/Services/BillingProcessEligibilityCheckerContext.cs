// <copyright file="BillingProcessEligibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Represents the context for billing process eligibility checker
    /// </summary>
    public class BillingProcessEligibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context ContextType = Context.BillingProcessEligibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="BillingProcessEligibilityCheckerContext"/> class
        /// </summary>
        /// <param name="contextService">Context service</param>
        public BillingProcessEligibilityCheckerContext(IContextService contextService)
            : base(contextService, ContextType)
        {
        }
    }
}
