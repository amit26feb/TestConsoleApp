// <copyright file="EditUntransmittedAccessFeasibilityCheckerContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Context.Core.Services
{
    using TSMT.CAM.Context.Enumerator;

    /// <summary>
    /// Edit untransmitted access feasibility checker context
    /// </summary>
    public class EditUntransmittedAccessFeasibilityCheckerContext : CommonAccessFeasibilityCheckerContext
    {
        private const Context Conext = Context.EditUntransmittedAccessFeasibilityChecker;

        /// <summary>
        /// Initializes a new instance of the <see cref="EditUntransmittedAccessFeasibilityCheckerContext"/> class.
        /// </summary>
        /// <param name="contextService">Context service</param>
        public EditUntransmittedAccessFeasibilityCheckerContext(IContextService contextService)
            : base(contextService, Conext)
        {
        }
    }
}
