// <copyright file="OrderLineType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Constants
{
      /// <summary>
      /// Order line type
      /// </summary>
      public static class OrderLineType
      {
         /// <summary>
         /// Order line type accessory
         /// </summary>
         public const string Accessory = "A";

         /// <summary>
         /// Order line type charge
         /// </summary>
         public const string Charge = "C";

         /// <summary>
         /// Order line type unit
         /// </summary>
         public const string Unit = "U";

         /// <summary>
         /// Order line type variation
         /// </summary>
         public const string Variation = "V";

         /// <summary>
         /// Order line type warranty
         /// </summary>
         public const string Warranty = "W";
      }
}
