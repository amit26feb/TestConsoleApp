// <copyright file="ShipFromCode.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Constants
{
   /// <summary>
   /// Ship from code
   /// </summary>
   public static class ShipFromCode
   {
      /// <summary>
      /// Ship from code - BAS
      /// </summary>
      public const string ShipCodeBAS = "BAS";

      /// <summary>
      /// Ship from code - 062
      /// </summary>
      public const string ShipCode062 = "062";

      /// <summary>
      /// Ship from code - BASD
      /// </summary>
      public const string ShipCodeBASD = "BASD";
   }
}
