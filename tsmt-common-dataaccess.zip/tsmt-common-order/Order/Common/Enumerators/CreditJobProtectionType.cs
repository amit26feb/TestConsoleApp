// <copyright file="CreditJobProtectionType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
    using System.Runtime.Serialization;

    /// <summary>
    /// Enum for credit job protection type
    /// </summary>
    public enum CreditJobProtectionType
    {
        /// <summary>
        /// Protection type - Bond
        /// </summary>
        [EnumMember(Value = "B")]
        Bond,

        /// <summary>
        /// Protection type - Lien
        /// </summary>
        [EnumMember(Value = "L")]
        Lien,

        /// <summary>
        /// Protection type - Miller
        /// </summary>
        [EnumMember(Value = "M")]
        Miller
    }
}
