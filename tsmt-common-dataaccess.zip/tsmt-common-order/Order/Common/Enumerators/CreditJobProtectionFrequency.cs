// <copyright file="CreditJobProtectionFrequency.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
    using System.Runtime.Serialization;

    /// <summary>
    /// Enum for credit job protection frequency
    /// </summary>
    public enum CreditJobProtectionFrequency
    {
        /// <summary>
        /// Protection frequency - All
        /// </summary>
        [EnumMember(Value = "A")]
        All,

        /// <summary>
        /// Protection frequency - First
        /// </summary>
        [EnumMember(Value = "F")]
        First,

        /// <summary>
        /// Protection frequency - Last
        /// </summary>
        [EnumMember(Value = "L")]
        Last
    }
}
