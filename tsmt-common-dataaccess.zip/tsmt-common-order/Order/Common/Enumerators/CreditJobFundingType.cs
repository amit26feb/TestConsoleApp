// <copyright file="CreditJobFundingType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
    /// <summary>
    /// Enum for credit job funding type
    /// </summary>
    public enum CreditJobFundingType
    {
        /// <summary>
        /// Funding type - PUBLIC
        /// </summary>
        PUBLIC,

        /// <summary>
        /// Funding type - PRIVATE
        /// </summary>
        PRIVATE,

        /// <summary>
        /// Funding type - FEDERAL
        /// </summary>
        FEDERAL,

        /// <summary>
        /// Funding type - NA
        /// </summary>
        NA,

        /// <summary>
        /// Funding type - PRC_INC
        /// </summary>
        PRC_INC
    }
}
