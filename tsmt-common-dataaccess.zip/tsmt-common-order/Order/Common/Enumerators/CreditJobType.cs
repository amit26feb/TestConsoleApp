// <copyright file="CreditJobType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
   /// <summary>
   /// Enum for differnt credit job type
   /// </summary>
   public enum CreditJobType
   {
      /// <summary>
      /// JIS credit job type
      /// </summary>
        JIS,

        /// <summary>
        /// TST credit job type
        /// </summary>
        TST,

        /// <summary>
        /// OIS credit job type
        /// </summary>
        OIS,

        /// <summary>
        /// PRI credit job type
        /// </summary>
        PRI
   }
}
