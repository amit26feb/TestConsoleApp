// <copyright file="CreditJobTrasmitType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
   /// <summary>
   /// An enum for credit job transmit type
   /// </summary>
   public enum CreditJobTrasmitType
   {
      /// <summary>
      /// Identifies credit job transmit type as Untransmitted
      /// </summary>
      Untransmitted,

      /// <summary>
      /// Identifies credit job transmit type as Transmitted
      /// </summary>
      Transmitted,

      /// <summary>
      /// Identifies credit job transmit type as Copied Down
      /// </summary>
      CopiedDown
   }
}
