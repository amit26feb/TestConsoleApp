// <copyright file="SortDirection.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
   /// <summary>
   /// Enum for sort direction
   /// </summary>
   public enum SortDirection
   {
      /// <summary>
      /// Ascending name
      /// </summary>
      Ascending,

      /// <summary>
      /// Descending name
      /// </summary>
      Descending,
   }
}
