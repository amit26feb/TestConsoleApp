// <copyright file="ContractChainType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
   /// <summary>
   /// Enum for contract chain type
   /// </summary>
   public enum ContractChainType
   {
      /// <summary>
      /// Contract chain type - OWNER
      /// </summary>
      OWNER = 1,

      /// <summary>
      /// Contract chain type - GENCON
      /// </summary>
      GENCON = 2,

      /// <summary>
      /// Contract chain type - MECHCON
      /// </summary>
      MECHCON = 3,

      /// <summary>
      /// Contract chain type - INSTCON
      /// </summary>
      INSTCON = 4,

      /// <summary>
      /// Contract chain type - BONDCO
      /// </summary>
      BONDCO = 5,

      /// <summary>
      /// Contract chain type - CONLEND
      /// </summary>
      CONLEND = 6
   }
}
