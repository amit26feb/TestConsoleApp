// <copyright file="BonusCommissionWorkflowStatus.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Common.Enumerators
{
   /// <summary>
   /// Specifies the workflow status for bonus commission
   /// </summary>
   public enum BonusCommissionWorkflowStatus
   {
      /// <summary>
      /// Status before the bonus commission is transmitted
      /// </summary>
      NEW,

      /// <summary>
      /// Status after the bonus commission is transmitted and submitted to workflow platform
      /// </summary>
      INPROGRESS,

      /// <summary>
      /// Status after workflow platform approves the bonus commission
      /// </summary>
      APPROVED,

      /// <summary>
      /// Status after workflow platform rejects the bonus commission
      /// </summary>
      REJECTED,
   }
}
