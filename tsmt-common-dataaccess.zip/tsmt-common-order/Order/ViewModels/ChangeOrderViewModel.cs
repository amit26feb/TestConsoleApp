// <copyright file="ChangeOrderViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   /// View model for change order
   /// </summary>
   public class ChangeOrderViewModel
   {
      /// <summary>
      /// Gets or sets change order id
      /// </summary>
      public int ChangeOrderId { get; set; }

      /// <summary>
      /// Gets or sets change type
      /// </summary>
      public string ChangeType { get; set; }

      /// <summary>
      /// Gets or sets attribute
      /// </summary>
      public string Attribute { get; set; }

      /// <summary>
      /// Gets or sets old value
      /// </summary>
      public string OldValue { get; set; }

      /// <summary>
      /// Gets or sets new value
      /// </summary>
      public string NewValue { get; set; }

      /// <summary>
      /// Gets or sets ship to change order id
      /// </summary>
      public string ShipToChangeOrderId { get; set; }
   }
}
