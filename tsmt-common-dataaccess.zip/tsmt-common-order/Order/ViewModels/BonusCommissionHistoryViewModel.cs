// <copyright file="BonusCommissionHistoryViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
    using System.Collections.Generic;

    /// <summary>
    /// Represents view model for bonus commission history
    /// </summary>
    public class BonusCommissionHistoryViewModel
   {
        /// <summary>
        /// Gets or sets credit job id
        /// </summary>
        public int CreditJobId { get; set; }

        /// <summary>
        /// Gets or sets bonus commissions for the credit job
        /// </summary>
        public IEnumerable<BonusCommissionViewModel> BonusCommissions { get; set; }
    }
}
