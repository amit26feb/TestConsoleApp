// <copyright file="CommissionNotificationViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   /// View model for commission notification
   /// </summary>
   public class CommissionNotificationViewModel
   {
      /// <summary>
      /// Gets or sets dr address id
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      public int CreditJobId { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SalesOrderId { get; set; }
   }
}
