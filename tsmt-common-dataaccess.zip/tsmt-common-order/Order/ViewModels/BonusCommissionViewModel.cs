// <copyright file="BonusCommissionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   using System;
   using System.Collections.Generic;
   using System.Text;

   /// <summary>
   /// Represents bonus commission view model
   /// </summary>
   public class BonusCommissionViewModel
   {
      /// <summary>
      /// Gets or sets Sequence Number
      /// </summary>
      public int SequenceNumber { get; set; }

      /// <summary>
      /// Gets or sets the Credit Job Id
      /// </summary>
      public int CreditJobId { get; set; }

      /// <summary>
      /// Gets or sets the Program Name
      /// </summary>
      public string ProgramName { get; set; }

      /// <summary>
      /// Gets or sets the Bonus Percentage
      /// </summary>
      public decimal BonusPercentage { get; set; }

      /// <summary>
      /// Gets or sets the Status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets the date the status changed
      /// </summary>
      public DateTime? StatusChangedDate { get; set; }

      /// <summary>
      /// Gets or sets the User who changed the status
      /// </summary>
      public string StatusChangedBy { get; set; }

      /// <summary>
      /// Gets or sets the created date
      /// </summary>
      public DateTime? CreatedDate { get; set; }

      /// <summary>
      /// Gets or sets the created by user
      /// </summary>
      public string CreatedBy { get; set; }

      /// <summary>
      /// Gets or sets the Updated Date
      /// </summary>
      public DateTime? UpdatedDate { get; set; }

      /// <summary>
      /// Gets or sets the updated by user.
      /// </summary>
      public string UpdatedBy { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the Bonus Commission is Active
      /// </summary>
      public bool IsActive { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the bonus Is Transmitted
      /// </summary>
      public bool IsTransmitted { get; set; }

      /// <summary>
      /// Gets or sets note
      /// </summary>
      public string Note { get; set; }
   }
}
