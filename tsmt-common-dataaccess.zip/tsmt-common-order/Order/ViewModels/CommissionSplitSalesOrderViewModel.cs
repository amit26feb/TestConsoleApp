// <copyright file="CommissionSplitSalesOrderViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   ///  Sales orders for commission split sales order grid
   /// </summary>
   public class CommissionSplitSalesOrderViewModel
   {
      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SalesOrderId { get; set; }

      /// <summary>
      /// Gets or sets sales order number
      /// </summary>
      public string SalesOrderNumber { get; set; }

      /// <summary>
      /// Gets or sets order status
      /// </summary>
      public string OrderStatus { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether
      /// Sales order will be update for the commission split or not
      /// </summary>
      public bool WillBeUpdated { get; set; }

      /// <summary>
      /// Gets or sets comments
      /// </summary>
      public string Comment { get; set; }
   }
}
