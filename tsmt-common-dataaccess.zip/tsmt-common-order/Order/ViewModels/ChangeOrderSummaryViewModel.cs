// <copyright file="ChangeOrderSummaryViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   using System;
   using System.ComponentModel;

   /// <summary>
   /// View model for change order summary
   /// </summary>
   public class ChangeOrderSummaryViewModel
   {
      /// <summary>
      /// Gets or sets change order id
      /// </summary>
      [Description("CO_ID")]
      public int? ChangeOrderId { get; set; }

      /// <summary>
      /// Gets or sets ship to change order id
      /// </summary>
      [Description("SHIP_TO_CO_ID")]
      public string ShipToChangeOrderId { get; set; }

      /// <summary>
      /// Gets or sets date submitted
      /// </summary>
      [Description("DATE_SUBMITTED")]
      public DateTime DateSubmitted { get; set; }

      /// <summary>
      /// Gets or sets change order status
      /// </summary>
      [Description("CO_STATUS")]
      public string ChangeOrderStatus { get; set; }

      /// <summary>
      /// Gets or sets submitted by
      /// </summary>
      [Description("SUBMITTED_BY")]
      public string SubmittedBy { get; set; }

      /// <summary>
      /// Gets or sets processed by
      /// </summary>
      [Description("PROCESSED_BY")]
      public string ProcessedBy { get; set; }

      /// <summary>
      /// Gets or sets status date
      /// </summary>
      [Description("STATUS_DATE")]
      public DateTime? StatusDate { get; set; }

      /// <summary>
      /// Gets or sets submitted person first name
      /// </summary>
      public string SubmittedPersonFirstName { get; set; }

      /// <summary>
      /// Gets or sets submitted person last name
      /// </summary>
      public string SubmittedPersonLastName { get; set; }

      /// <summary>
      /// Gets or sets processed person first name
      /// </summary>
      public string ProcessedPersonFirstName { get; set; }

      /// <summary>
      /// Gets or sets processed person last name
      /// </summary>
      public string ProcessedPersonLastName { get; set; }

      /// <summary>
      /// Gets or sets business unit notes
      /// </summary>
      [Description("BU_NOTES")]
      public string BusinessUnitNotes { get; set; }

      /// <summary>
      /// Gets or sets sales office notes
      /// </summary>
      [Description("SALES_OFFICE_NOTES")]
      public string SalesOfficeNotes { get; set; }

      /// <summary>
      /// Gets or sets credit job name
      /// </summary>
      [Description("CREDIT_JOB_NAME")]
      public string CreditJobName { get; set; }

      /// <summary>
      /// Gets or sets legacy job number
      /// </summary>
      [Description("LEGACY_JOB_NBR")]
      public string LegacyJobNumber { get; set; }

      /// <summary>
      /// Gets or sets manufacturing location
      /// </summary>
      [Description("MFG_LOC")]
      public string MfgLocation { get; set; }

      /// <summary>
      /// Gets or sets sales office id
      /// </summary>
      [Description("SALES_OFFICE_ID")]
      public int SalesOfficeId { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether gets or sets no charge indicator
      /// </summary>
      [Description("NO_CHARGE_IND")]
      public bool NoChargeIndicator { get; set; }

      /// <summary>
      /// Gets or sets legacy order number
      /// </summary>
      [Description("LEGACY_ORD_NBR")]
      public string LegacyOrderNumber { get; set; }

      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      [Description("CREDIT_JOB_ID")]
      public int CreditJobId { get; set; }

      /// <summary>
      /// Gets or sets submitted person
      /// </summary>
      [Description("SUBMITTED_PERSON")]
      public string SubmittedPerson { get; set; }

      /// <summary>
      /// Gets or sets responsible person
      /// </summary>
      [Description("RESPONSIBLE_PERSON")]
      public string ResponsiblePerson { get; set; }

      /// <summary>
      /// Gets or sets the submitted user detail
      /// </summary>
      public UserViewModel SubmittedUserDetail { get; set; }

      /// <summary>
      /// Gets or sets the responsible user detail
      /// </summary>
      public UserViewModel ResponsibleUserDetail { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SalesOrderId { get; set; }
   }
}
