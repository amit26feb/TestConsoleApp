// <copyright file="CommissionSplitSalesOrderInfoViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   /// Commission split sales order info view model
   /// </summary>
   public class CommissionSplitSalesOrderInfoViewModel
   {
      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SalesOrderId { get; set; }

      /// <summary>
      /// Gets or sets sales order number
      /// </summary>
      public string SalesOrderNumber { get; set; }

      /// <summary>
      /// Gets or sets sales order status
      /// </summary>
      public string SalesOrderStatus { get; set; }

      /// <summary>
      /// Gets or sets co status
      /// </summary>
      public string CoStatus { get; set; }

      /// <summary>
      /// Gets or sets lock application
      /// </summary>
      public string LockApplication { get; set; }

      /// <summary>
      /// Gets or sets hqtr sales order id
      /// </summary>
      public int HqtrSalesOrderId { get; set; }
   }
}
