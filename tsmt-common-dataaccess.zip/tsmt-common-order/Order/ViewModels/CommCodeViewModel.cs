// <copyright file="CommCodeViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   /// Represents view model for comm code
   /// </summary>
   public class CommCodeViewModel
   {
      /// <summary>
      /// Gets or sets Name
      /// </summary>
      public string Name { get; set; }

      /// <summary>
      /// Gets or sets CommCode
      /// </summary>
      public string CommCode { get; set; }

      /// <summary>
      /// Gets or sets SalesOfficeId
      /// </summary>
      public int SalesOfficeId { get; set; }

      /// <summary>
      /// Gets or sets comm code status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets comm code id
      /// </summary>
      public int CommCodeId { get; set; }

      /// <summary>
      /// Gets or sets employee number
      /// </summary>
      public string EmployeeNumber { get; set; }
   }
}
