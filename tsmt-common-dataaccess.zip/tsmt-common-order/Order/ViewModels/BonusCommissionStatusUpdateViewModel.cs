// <copyright file="BonusCommissionStatusUpdateViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
    using System;

   /// <summary>
   /// Represents the view model for workflow status update for bonus commission event
   /// </summary>
   public class BonusCommissionStatusUpdateViewModel
   {
      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      public int CreditJobId { get; set; }

      /// <summary>
      /// Gets or sets sequence number
      /// </summary>
      public int SequenceNumber { get; set; }

      /// <summary>
      /// Gets or sets the workflow status
      /// </summary>
      public string WorkflowStatus { get; set; }

      /// <summary>
      /// Gets or sets the status changed by name
      /// </summary>
      public string StatusChangedBy { get; set; }

      /// <summary>
      /// Gets or sets the status changed by date
      /// </summary>
      public DateTime? StatusChangedOn { get; set; }

      /// <summary>
      /// Gets or sets note
      /// </summary>
      public string Note { get; set; }
   }
}
