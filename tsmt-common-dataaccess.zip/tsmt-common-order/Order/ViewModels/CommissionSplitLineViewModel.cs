// <copyright file="CommissionSplitLineViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   /// Represents view model for commission split line
   /// </summary>
   public class CommissionSplitLineViewModel
   {
      /// <summary>
      /// Gets or sets sales office id
      /// </summary>
      public int SalesOfficeId { get; set; }

      /// <summary>
      /// Gets or sets sales office name
      /// </summary>
      public string SalesOfficeName { get; set; }

      /// <summary>
      /// Gets or sets comm code
      /// </summary>
      public string CommCode { get; set; }

      /// <summary>
      /// Gets or sets sales person name
      /// </summary>
      public string SalesPersonName { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the sales office person is active
      /// </summary>
      public bool IsActiveSalesOfficePersonMapping { get; set; }

      /// <summary>
      /// Gets or sets commission percent
      /// </summary>
      public decimal CommissionPercent { get; set; }

      /// <summary>
      /// Gets or sets last modified by
      /// </summary>
      public string LastModifiedBy { get; set; }
   }
}
