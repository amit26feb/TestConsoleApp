// <copyright file="ChangeOrderDetailViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   /// View model for change order detail
   /// </summary>
   public class ChangeOrderDetailViewModel
   {
      /// <summary>
      /// Gets or sets change order id
      /// </summary>
      public int ChangeOrderId { get; set; }

      /// <summary>
      /// Gets or sets status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets type id
      /// </summary>
      public int TypeId { get; set; }

      /// <summary>
      /// Gets or sets change type
      /// </summary>
      public string ChangeType { get; set; }

      /// <summary>
      /// Gets or sets type sequence
      /// </summary>
      public int TypeSequence { get; set; }

      /// <summary>
      /// Gets or sets po number
      /// </summary>
      public string PoNumber { get; set; }

      /// <summary>
      /// Gets or sets sold to
      /// </summary>
      public string SoldTo { get; set; }
   }
}
