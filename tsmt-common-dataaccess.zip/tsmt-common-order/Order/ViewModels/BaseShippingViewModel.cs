// <copyright file="BaseShippingViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.ViewModels
{
   /// <summary>
   /// Base view model for shipping instruction and planned shipment level
   /// </summary>
   public class BaseShippingViewModel
   {
      /// <summary>
      /// Gets or sets shipping instruction street address 1
      /// </summary>
      public string StreetAddress1 { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction street address 2
      /// </summary>
      public string StreetAddress2 { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction city
      /// </summary>
      public string City { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction state code
      /// </summary>
      public string StateCode { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction province
      /// </summary>
      public string Province { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction country
      /// </summary>
      public string Country { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction zip code
      /// </summary>
      public string ZipCode { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction zip plus
      /// </summary>
      public string ZipPlus { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction non us postal code
      /// </summary>
      public string NonUsPostalCode { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction delivery contact name
      /// </summary>
      public string DeliveryContactName { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction delivery contact email
      /// </summary>
      public string DeliveryContactEmail { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction delivery contact number
      /// </summary>
      public string DeliveryContactNumber { get; set; }
   }
}
