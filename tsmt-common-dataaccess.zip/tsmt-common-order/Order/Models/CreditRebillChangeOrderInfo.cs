// <copyright file="CreditRebillChangeOrderInfo.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   /// Class for credit rebill change order info
   /// </summary>
   public class CreditRebillChangeOrderInfo
   {
      /// <summary>
      /// Gets or sets change type
      /// </summary>
      public string ChangeType { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether the change order has been transmitted.
      /// </summary>
      public bool IsTransmitted { get; set; }

      /// <summary>
      /// Gets or sets transmitted date time in utc
      /// </summary>
      public DateTime? TransmittedDateTimeUtc { get; set; }

      /// <summary>
      /// Gets or sets status
      /// </summary>
      public string Status { get; set; }
   }
}
