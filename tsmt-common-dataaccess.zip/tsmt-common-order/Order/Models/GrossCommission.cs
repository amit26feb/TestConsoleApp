// <copyright file="GrossCommission.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for gross commission
   /// </summary>
   public class GrossCommission : IDataEntity
   {
      /// <summary>
      /// Gets or sets credit job number
      /// </summary>
      public string CREDIT_JOB_NUMBER { get; set; }

      /// <summary>
      /// Gets or sets the credit job name
      /// </summary>
      public string CREDIT_JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets sales order number
      /// </summary>
      public string SALES_ORDER_NUMBER { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SALES_ORDER_ID { get; set; }

      /// <summary>
      /// Gets or sets planned shipment number
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets product code
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets transaction reason
      /// </summary>
      public string TRANS_REASON { get; set; }

      /// <summary>
      /// Gets or sets order status code
      /// </summary>
      public string ORD_STATUS_CODE { get; set; }

      /// <summary>
      /// Gets or sets ship date
      /// </summary>
      public DateTime? SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets split id
      /// </summary>
      public int? SPLIT_ID { get; set; }

      /// <summary>
      /// Gets or sets commission percent
      /// </summary>
      public decimal COMM_PCT { get; set; }

      /// <summary>
      /// Gets or sets sales office id
      /// </summary>
      public int? SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets comm code
      /// </summary>
      public string COMM_CODE { get; set; }

      /// <summary>
      /// Gets or sets employee id
      /// </summary>
      public string EMPLOYEE_ID { get; set; }

      /// <summary>
      /// Gets or sets sell price
      /// </summary>
      public decimal SELLING_PRICE { get; set; }

      /// <summary>
      /// Gets or sets entered comm rate
      /// </summary>
      public decimal? ENTERED_COMM_RATE { get; set; }

      /// <summary>
      /// Gets or sets gross commission
      /// </summary>
      public decimal COMM_DLR { get; set; }

      /// <summary>
      /// Gets or sets net price
      /// </summary>
      public decimal? NET_PRICE { get; set; }

      /// <summary>
      /// Gets or sets net commission
      /// </summary>
      public decimal? NET_COMM_DLR { get; set; }

      /// <summary>
      /// Gets or sets bonus commission
      /// </summary>
      public decimal? BONUS_COMM_DLR { get; set; }

      /// <summary>
      /// Gets or sets claim number
      /// </summary>
      public string CLAIM_NUMBER { get; set; }

      /// <summary>
      /// Gets or sets snapshot id
      /// </summary>
      public int? SNAPSHOT_ID { get; set; }

      /// <summary>
      /// Gets or sets pricing policy multiplier
      /// </summary>
      public decimal? PRICING_POLICY_MULTIPLIER { get; set; }

      /// <summary>
      /// Gets or sets invoice type
      /// </summary>
      public string INVOICE_TYPE { get; set; }

      /// <summary>
      /// Gets or sets created date
      /// </summary>
      public DateTime CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets currency code
      /// </summary>
      public string CURRENCY_CODE { get; set; }

      /// <summary>
      /// Gets or sets header id
      /// </summary>
      public int HEADER_ID { get; set; }

      /// <summary>
      /// Gets or sets reversal commission cms header id
      /// </summary>
      public int? COMM_CMS_HEADER_ID_REV { get; set; }

      /// <summary>
      /// Gets or sets selected pricing parm id
      /// </summary>
      public int? SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets quantity
      /// </summary>
      public int QTY { get; set; }
   }
}
