// <copyright file="ChangeOrderDetail.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for change order detail
   /// </summary>
   public class ChangeOrderDetail : IDataEntity
   {
      /// <summary>
      /// Gets or sets CO_ID
      /// </summary>
      public int CO_ID { get; set; }

      /// <summary>
      /// Gets or sets CO_STATUS
      /// </summary>
      public string CO_STATUS { get; set; }

      /// <summary>
      /// Gets or sets CO_TYPE_ID
      /// </summary>
      public int CO_TYPE_ID { get; set; }

      /// <summary>
      /// Gets or sets CO_CHANGE_TYPE
      /// </summary>
      public string CO_CHANGE_TYPE { get; set; }

      /// <summary>
      /// Gets or sets CO_TYPE_SEQ
      /// </summary>
      public int CO_TYPE_SEQ { get; set; }

      /// <summary>
      /// Gets or sets CO_PO_NBR
      /// </summary>
      public string CO_PO_NBR { get; set; }

      /// <summary>
      /// Gets or sets CO_SOLD_TO
      /// </summary>
      public string CO_SOLD_TO { get; set; }
   }
}
