// <copyright file="CreditJobHistory.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for credit job history
   /// </summary>
   public class CreditJobHistory : IDataEntity
   {
      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_NAME
      /// </summary>
      public string CREDIT_JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_JOB_NBR
      /// </summary>
      public string LEGACY_JOB_NBR { get; set; }

      /// <summary>
      /// Gets or sets DATE_ENTERED
      /// </summary>
      public DateTime DATE_ENTERED { get; set; }

      /// <summary>
      /// Gets or sets TEXT_MESSAGE
      /// </summary>
      public string TEXT_MESSAGE { get; set; }

      /// <summary>
      /// Gets or sets EVENT_TEXT_1
      /// </summary>
      public string EVENT_TEXT_1 { get; set; }

      /// <summary>
      /// Gets or sets EVENT_TEXT_2
      /// </summary>
      public string EVENT_TEXT_2 { get; set; }

      /// <summary>
      /// Gets or sets SOURCE_USER_ID
      /// </summary>
      public string SOURCE_USER_ID { get; set; }

      /// <summary>
      /// Gets or sets PROCESS_NAME
      /// </summary>
      public string PROCESS_NAME { get; set; }

      /// <summary>
      /// Gets or sets HISTORY_EVENT_CODE
      /// </summary>
      public string HISTORY_EVENT_CODE { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_RECORDS
      /// </summary>
      public int TOTAL_RECORDS { get; set; }

      /// <summary>
      /// Gets or sets NAME_LAST
      /// </summary>
      public string NAME_LAST { get; set; }

      /// <summary>
      /// Gets or sets EVENT_TEXT_MESSAGE
      /// </summary>
      public string EVENT_TEXT_MESSAGE { get; set; }
   }
}
