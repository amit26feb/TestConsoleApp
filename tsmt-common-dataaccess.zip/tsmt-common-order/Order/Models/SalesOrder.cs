// <copyright file="SalesOrder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for sales order
   /// </summary>
   public class SalesOrder : IDataEntity
   {
      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_ORD_NBR
      /// </summary>
      public string LEGACY_ORD_NBR { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets ORD_EQUIP_DESCR
      /// </summary>
      public string ORD_EQUIP_DESCR { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_STATUS
      /// </summary>
      public string SALES_ORD_STATUS { get; set; }

      /// <summary>
      /// Gets or sets PS_PROJECT_ID
      /// </summary>
      public string PS_PROJECT_ID { get; set; }

      /// <summary>
      /// Gets or sets SERVICE_LIT_QTY
      /// </summary>
      public int? SERVICE_LIT_QTY { get; set; }

      /// <summary>
      /// Gets or sets LIT_EMAIL_1
      /// </summary>
      public string LIT_EMAIL_1 { get; set; }

      /// <summary>
      /// Gets or sets LIT_EMAIL_2
      /// </summary>
      public string LIT_EMAIL_2 { get; set; }

      /// <summary>
      /// Gets or sets LIT_SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? LIT_SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets LIT_DATE
      /// </summary>
      public DateTime? LIT_DATE { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_SALES_ORDERS
      /// </summary>
      public int TOTAL_SALES_ORDERS { get; set; }

      /// <summary>
      /// Gets or sets INVOICE_TYPE
      /// </summary>
      public string INVOICE_TYPE { get; set; }

      /// <summary>
      /// Gets or sets BU_MFG_LOC_ID
      /// </summary>
      public int BU_MFG_LOC_ID { get; set; }

      /// <summary>
      /// Gets or sets CO_STATUS
      /// </summary>
      public string CO_STATUS { get; set; }

      /// <summary>
      /// Gets or sets LOCK_APPLICATION
      /// </summary>
      public string LOCK_APPLICATION { get; set; }

      /// <summary>
      /// Gets or sets HQTR_SALES_ORDER_ID
      /// </summary>
      public int? HQTR_SALES_ORDER_ID { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_CATG
      /// </summary>
      public string SALES_ORD_CATG { get; set; }

      /// <summary>
      /// Gets or sets DATE_CREATED
      /// </summary>
      public DateTime DATE_CREATED { get; set; }

      /// <summary>
      /// Gets or sets ECS_TRANSACTION_TYPE
      /// </summary>
      public string ECS_TRANSACTION_TYPE { get; set; }

      /// <summary>
      ///  Gets or sets headquarter credit job id
      /// </summary>
      public int? HQTR_CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets change allowed indicator
      /// </summary>
      public char CHG_ALLOWED_IND { get; set; }

      /// <summary>
      /// Gets or sets ship status
      /// </summary>
      public string SHIP_STATUS { get; set; }
   }
}
