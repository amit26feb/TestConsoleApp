// <copyright file="PlannedShipmentDetail.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for planned shipment details
   /// </summary>
   public class PlannedShipmentDetail : IDataEntity
   {
      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets PLANNED_SHIPMENT_NBR
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_STATUS
      /// </summary>
      public string SALES_ORD_STATUS { get; set; }

      /// <summary>
      /// Gets or sets SHIP_STATUS
      /// </summary>
      public string SHIP_STATUS { get; set; }

      /// <summary>
      /// Gets or sets MFG_LOC
      /// </summary>
      public string MFG_LOC { get; set; }

      /// <summary>
      /// Gets or sets NAME
      /// </summary>
      public string NAME { get; set; }

      /// <summary>
      /// Gets or sets SHIP_INSTRUCT_DESCR
      /// </summary>
      public string SHIP_INSTRUCT_DESCR { get; set; }

      /// <summary>
      /// Gets or sets SHIP_FROM_CODE
      /// </summary>
      public string SHIP_FROM_CODE { get; set; }

      /// <summary>
      /// Gets or sets OP_RULE_ID
      /// </summary>
      public int? OP_RULE_ID { get; set; }

      /// <summary>
      /// Gets or sets BU_OP_RULE_SEQ
      /// </summary>
      public int BU_OP_RULE_SEQ { get; set; }

      /// <summary>
      /// Gets or sets REQS_SHIP_DATE
      /// </summary>
      public DateTime? ESTIMATED_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets Actual Shipment Date
      /// </summary>
      public DateTime? SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_PROD_AMT
      /// </summary>
      public decimal? TOTAL_PROD_AMT { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_NET_AMT
      /// </summary>
      public decimal? TOTAL_NET_AMT { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_VARIATION_AMT
      /// </summary>
      public decimal? TOTAL_VARIATION_AMT { get; set; }

      /// <summary>
      /// Gets or sets BU_MFG_LOC_ID
      /// </summary>
      public int? BU_MFG_LOC_ID { get; set; }

      /// <summary>
      /// Gets or sets SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether gets or sets FINAL_FINISHER_IND
      /// </summary>
      public bool FINAL_FINISHER_IND { get; set; }

      /// <summary>
      /// Gets or sets OP_DESCR
      /// </summary>
      public string OP_DESCR { get; set; }

      /// <summary>
      /// Gets or sets STATE_CODE
      /// </summary>
      public string STATE_CODE { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_SHIPMENTS
      /// </summary>
      public int TOTAL_SHIPMENTS { get; set; }

      /// <summary>
      /// Gets or sets ORD_STATUS_CODE
      /// </summary>
      public string ORD_STATUS_CODE { get; set; }

      /// <summary>
      /// Gets or sets BU_ORDER_STATUS
      /// </summary>
      public string BU_ORDER_STATUS { get; set; }

      /// <summary>
      /// Gets or sets DELIVERY_DATE
      /// </summary>
      public DateTime? DELIVERY_DATE { get; set; }

      /// <summary>
      /// Gets or sets EBS_ORD_NBR
      /// </summary>
      public decimal? EBS_ORD_NBR { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_AMT
      /// Planned shipment level amount
      /// </summary>
      public decimal? TOTAL_AMT { get; set; }

      /// <summary>
      /// Gets or sets NO_PARTIAL_SHIPMENT_INDICATOR
      /// </summary>
      public char NO_PARTIAL_SHIPMENT_INDICATOR { get; set; }

      /// <summary>
      /// Gets or sets AS_BILL_OF_LADING_NBR
      /// </summary>
      public string AS_BILL_OF_LADING_NBR { get; set; }

      /// <summary>
      /// Gets or sets AS_SHIPPING_CONTRACT_NBR
      /// </summary>
      public string AS_SHIPPING_CONTRACT_NBR { get; set; }

      /// <summary>
      /// Gets or sets FFS_BILL_OF_LADING_NBR
      /// </summary>
      public string FFS_BILL_OF_LADING_NBR { get; set; }

      /// <summary>
      /// Gets or sets FFS_SHIPPING_CONTRACT_NBR
      /// </summary>
      public string FFS_SHIPPING_CONTRACT_NBR { get; set; }

      /// <summary>
      /// Gets or sets FREIGHT_VENDOR_DESC
      /// </summary>
      public string FREIGHT_VENDOR_DESC { get; set; }

      /// <summary>
      /// Gets or sets STREET_ADDRESS_1
      /// </summary>
      public string STREET_ADDRESS_1 { get; set; }

      /// <summary>
      /// Gets or sets STREET_ADDRESS_2
      /// </summary>
      public string STREET_ADDRESS_2 { get; set; }

      /// <summary>
      /// Gets or sets CITY
      /// </summary>
      public string CITY { get; set; }

      /// <summary>
      /// Gets or sets PROVINCE
      /// </summary>
      public string PROVINCE { get; set; }

      /// <summary>
      /// Gets or sets COUNTRY
      /// </summary>
      public string COUNTRY { get; set; }

      /// <summary>
      /// Gets or sets ZIP_CODE
      /// </summary>
      public string ZIP_CODE { get; set; }

      /// <summary>
      /// Gets or sets ZIP_PLUS
      /// </summary>
      public string ZIP_PLUS { get; set; }

      /// <summary>
      /// Gets or sets NON_US_POSTAL_CODE
      /// </summary>
      public string NON_US_POSTAL_CODE { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_ATTENTION
      /// </summary>
      public string CALL_PRIOR_ATTENTION { get; set; }

      /// <summary>
      /// Gets or sets PRIM_CONTACT_EMAIL
      /// </summary>
      public string PRIM_CONTACT_EMAIL { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_NBR
      /// </summary>
      public string CALL_PRIOR_NBR { get; set; }

      /// <summary>
      /// Gets or sets FREIGHT_DLR
      /// </summary>
      public decimal? FREIGHT_DLR { get; set; }

      /// <summary>
      /// Gets or sets NBR_OF_PIECES
      /// </summary>
      public int? NBR_OF_PIECES { get; set; }

      /// <summary>
      /// Gets or sets WEIGHT
      /// </summary>
      public decimal? WEIGHT { get; set; }

      /// <summary>
      /// Gets or sets customer estimated ship date
      /// </summary>
      public DateTime? CUST_EST_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets final finisher processing days
      /// </summary>
      public int? FF_PROCESSING_DAYS { get; set; }

      /// <summary>
      /// Gets or sets customer shipping instruction id
      /// </summary>
      public int? CUST_SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets final finisher shipping instruction id
      /// </summary>
      public int? FF_SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets business unit comments
      /// </summary>
      public string BU_COMMENTS { get; set; }

      /// <summary>
      /// Gets or sets headquarter sales order id
      /// </summary>
      public int? HQTR_SALES_ORDER_ID { get; set; }

      /// <summary>
      ///  Gets or sets headquarter credit job id
      /// </summary>
      public int? HQTR_CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets credit decision type description
      /// </summary>
      public string CREDIT_DECISION_TYPE_DESCR { get; set; }
   }
}
