// <copyright file="SalesOrderHistory.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for sales order history data
   /// </summary>
   public class SalesOrderHistory : IDataEntity
   {
      /// <summary>
      /// Gets or sets SALES_ORDER_HISTORY_ID
      /// </summary>
      public int SALES_ORDER_HISTORY_ID { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_ORD_NBR
      /// </summary>
      public string LEGACY_ORD_NBR { get; set; }

      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets ORD_EQUIP_DESCR
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets DATE_ENTERED
      /// </summary>
      public DateTime DATE_ENTERED { get; set; }

      /// <summary>
      /// Gets or sets TEXT_MESSAGE
      /// </summary>
      public string TEXT_MESSAGE { get; set; }

      /// <summary>
      /// Gets or sets EVENT_TEXT_1
      /// </summary>
      public string EVENT_TEXT_1 { get; set; }

      /// <summary>
      /// Gets or sets EVENT_TEXT_2
      /// </summary>
      public string EVENT_TEXT_2 { get; set; }

      /// <summary>
      /// Gets or sets SOURCE_USER_ID
      /// </summary>
      public string SOURCE_USER_ID { get; set; }

      /// <summary>
      /// Gets or sets SOURCE_USER_ID
      /// </summary>
      public string PROCESS_NAME { get; set; }

      /// <summary>
      /// Gets or sets HISTORY_EVENT_CODE
      /// </summary>
      public string HISTORY_EVENT_CODE { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_RECORDS
      /// </summary>
      public int TOTAL_RECORDS { get; set; }

      /// <summary>
      /// Gets or sets NAME_LAST
      /// </summary>
      public string NAME_LAST { get; set; }

      /// <summary>
      /// Gets or sets EVENT_TEXT_MESSAGE
      /// </summary>
      public string EVENT_TEXT_MESSAGE { get; set; }
   }
}
