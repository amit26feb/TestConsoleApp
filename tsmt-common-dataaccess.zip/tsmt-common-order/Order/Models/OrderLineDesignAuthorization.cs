// <copyright file="OrderLineDesignAuthorization.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for order line design authorization data
   /// </summary>
   public class OrderLineDesignAuthorization : IDataEntity
   {
      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets planned shipment number
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets orderline number
      /// </summary>
      public int ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets design spa number
      /// </summary>
      public string DESIGN_SPA_NBR { get; set; }
   }
}
