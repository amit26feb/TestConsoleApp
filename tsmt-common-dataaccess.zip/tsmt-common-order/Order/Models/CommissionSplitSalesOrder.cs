// <copyright file="CommissionSplitSalesOrder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Sales orders for commission split sales order grid
   /// </summary>
   public class CommissionSplitSalesOrder
   {
      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_ORD_NBR
      /// </summary>
      public string LEGACY_ORD_NBR { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_STATUS
      /// </summary>
      public string SALES_ORD_STATUS { get; set; }

      /// <summary>
      /// Gets or sets CO_STATUS
      /// </summary>
      public string CO_STATUS { get; set; }

      /// <summary>
      /// Gets or sets LOCK_APPLICATION
      /// </summary>
      public string LOCK_APPLICATION { get; set; }

      /// <summary>
      /// Gets or sets HQTR_SALES_ORDER_ID
      /// </summary>
      public int HQTR_SALES_ORDER_ID { get; set; }
   }
}
