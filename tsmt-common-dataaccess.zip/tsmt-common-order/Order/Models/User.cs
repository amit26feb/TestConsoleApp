// <copyright file="User.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for User
   /// </summary>
   public class User : IDataEntity
   {
      /// <summary>
      ///  Gets or sets user id
      /// </summary>
      public string USER_ID { get; set; }

      /// <summary>
      ///  Gets or sets first name
      /// </summary>
      public string NAME_FIRST { get; set; }

      /// <summary>
      ///  Gets or sets last name
      /// </summary>
      public string NAME_LAST { get; set; }

      /// <summary>
      ///  Gets or sets phone number
      /// </summary>
      public string PHONE_NBR { get; set; }

      /// <summary>
      ///  Gets or sets sales office name
      /// </summary>
      public string SALES_OFFICE_NAME { get; set; }

      /// <summary>
      ///  Gets or sets email address
      /// </summary>
      public string EMAIL_ADDRESS { get; set; }

      /// <summary>
      ///  Gets or sets EXTENSION
      /// </summary>
      public string EXTENSION { get; set; }
   }
}
