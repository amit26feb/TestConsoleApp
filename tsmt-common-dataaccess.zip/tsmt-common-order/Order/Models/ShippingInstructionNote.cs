// <copyright file="ShippingInstructionNote.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   /// Model for shipping instruction note
   /// </summary>
   public class ShippingInstructionNote
   {
      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets NOTE_ID
      /// </summary>
      public int NOTE_ID { get; set; }

      /// <summary>
      /// Gets or sets NOTE_TEXT
      /// </summary>
      public string NOTE_TEXT { get; set; }

      /// <summary>
      /// Gets or sets HOST_UPDATE_IND
      /// </summary>
      public char? HOST_UPDATE_IND { get; set; }

      /// <summary>
      /// Gets or sets INSERT_DATE
      /// </summary>
      public DateTime? INSERT_DATE { get; set; }
   }
}
