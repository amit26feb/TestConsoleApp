// <copyright file="FinalFinisher.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for final finisher
   /// </summary>
   public class FinalFinisher : IDataEntity
   {
      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets PLANNED_SHIPMENT_NBR
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets ESTIMATED_SHIP_DATE
      /// </summary>
      public DateTime? ESTIMATED_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets FF_PROCESSING_DAYS
      /// </summary>
      public int? FF_PROCESSING_DAYS { get; set; }

      /// <summary>
      /// Gets or sets CUST_EST_SHIP_DATE
      /// </summary>
      public DateTime? CUST_EST_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets CUST_SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? CUST_SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets FF_SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? FF_SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets SHIP_DATE
      /// </summary>
      public DateTime? SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets FREIGHT_VENDOR_CODE
      /// </summary>
      public string FREIGHT_VENDOR_CODE { get; set; }

      /// <summary>
      /// Gets or sets FREIGHT_VENDOR_DESC
      /// </summary>
      public string FREIGHT_VENDOR_DESC { get; set; }

      /// <summary>
      /// Gets or sets BILL_OF_LADING_NBR
      /// </summary>
      public string BILL_OF_LADING_NBR { get; set; }

      /// <summary>
      /// Gets or sets BU_COMMENTS
      /// </summary>
      public string BU_COMMENTS { get; set; }

      /// <summary>
      /// Gets or sets SHIPPING_CONTRACT_NBR
      /// </summary>
      public string SHIPPING_CONTRACT_NBR { get; set; }

      /// <summary>
      /// Gets or sets DELIVERY_DATE
      /// </summary>
      public DateTime? DELIVERY_DATE { get; set; }

      /// <summary>
      /// Gets or sets headquarter sales order id
      /// </summary>
      public int? HQTR_SALES_ORDER_ID { get; set; }
   }
}
