// <copyright file="ShipmentDeliveryInformation.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for shipment delivery information
   /// </summary>
   public class ShipmentDeliveryInformation : IDataEntity
   {
      /// <summary>
      /// Gets or sets SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets CUST_SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? CUST_SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets FF_SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int? FF_SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets ESTIMATED_SHIP_DATE
      /// </summary>
      public DateTime? ESTIMATED_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets FINAL_FINISHER_IND
      /// </summary>
      public char? FINAL_FINISHER_IND { get; set; }

      /// <summary>
      /// Gets or sets REQS_SHIP_CODE
      /// </summary>
      public string REQS_SHIP_CODE { get; set; }

      /// <summary>
      /// Gets or sets DEMAND_CODE
      /// </summary>
      public string DEMAND_CODE { get; set; }

      /// <summary>
      /// Gets or sets FF_PROCESSING_DAYS
      /// </summary>
      public int? FF_PROCESSING_DAYS { get; set; }

      /// <summary>
      /// Gets or sets CUST_EST_SHIP_DATE
      /// </summary>
      public DateTime? CUST_EST_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets FF_EST_DELIV_DATE_EARLIEST
      /// </summary>
      public DateTime? FF_EST_DELIV_DATE_EARLIEST { get; set; }

      /// <summary>
      /// Gets or sets FF_EST_DELIV_DATE_LATEST
      /// </summary>
      public DateTime? FF_EST_DELIV_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets ORD_LINE_NBR
      /// </summary>
      public int ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets REQS_SHIP_DATE
      /// </summary>
      public DateTime? REQS_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets REQS_SHIP_DATE_LATEST
      /// </summary>
      public DateTime? REQS_SHIP_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets REQS_DELIVERY_DATE_EARLIEST
      /// </summary>
      public DateTime? REQS_DELIVERY_DATE_EARLIEST { get; set; }

      /// <summary>
      /// Gets or sets REQS_DELIVERY_DATE_LATEST
      /// </summary>
      public DateTime? REQS_DELIVERY_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets EST_DELIVERY_DATE_EARLIEST
      /// </summary>
      public DateTime? EST_DELIVERY_DATE_EARLIEST { get; set; }

      /// <summary>
      /// Gets or sets EST_DELIVERY_DATE_LATEST
      /// </summary>
      public DateTime? EST_DELIVERY_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets ACTUAL_SHIP_DATE
      /// </summary>
      public DateTime? ACTUAL_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets ACTUAL_DELIVERY_DATE
      /// </summary>
      public DateTime? ACTUAL_DELIVERY_DATE { get; set; }

      /// <summary>
      /// Gets or sets FINAL_FINISHER_SHIP_DATE
      /// </summary>
      public DateTime? FINAL_FINISHER_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets DELIVERY_DATE
      /// </summary>
      public DateTime? DELIVERY_DATE { get; set; }

      /// <summary>
      /// Gets or sets headquarter sales order id
      /// </summary>
      public int? HQTR_SALES_ORDER_ID { get; set; }
   }
}
