// <copyright file="ShipFrom.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for ship from information
   /// </summary>
   public class ShipFrom
   {
      /// <summary>
      /// Gets or sets COUNTRY_CODE
      /// </summary>
      public string COUNTRY_CODE { get; set; }

      /// <summary>
      /// Gets or sets STATE_CODE
      /// </summary>
      public string STATE_CODE { get; set; }

      /// <summary>
      /// Gets or sets PROVINCE
      /// </summary>
      public string PROVINCE { get; set; }

      /// <summary>
      /// Gets or sets SHIP_FROM_CODE
      /// </summary>
      public string SHIP_FROM_CODE { get; set; }

      /// <summary>
      /// Gets or sets SHIP_FROM_TYPE
      /// </summary>
      public string SHIP_FROM_TYPE { get; set; }
   }
}
