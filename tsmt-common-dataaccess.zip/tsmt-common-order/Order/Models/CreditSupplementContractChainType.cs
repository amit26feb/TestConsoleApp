// <copyright file="CreditSupplementContractChainType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for credit supplement contract chain type
   /// </summary>
   public class CreditSupplementContractChainType : IDataEntity
   {
      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets contract chain id
      /// </summary>
      public int CONTRACT_CHAIN_ID { get; set; }

      /// <summary>
      /// Gets or sets LEGAL_NAME
      /// </summary>
      public string LEGAL_NAME { get; set; }

      /// <summary>
      /// Gets or sets CONTRACT_CHAIN_TYPE
      /// </summary>
      public string CONTRACT_CHAIN_TYPE { get; set; }

      /// <summary>
      /// Gets or sets CONTACT_PERSON
      /// </summary>
      public string CONTACT_PERSON { get; set; }

      /// <summary>
      /// Gets or sets CUST_ACCT_NBR
      /// </summary>
      public string CUST_ACCT_NBR { get; set; }

      /// <summary>
      /// Gets or sets PHONE_NBR
      /// </summary>
      public string PHONE_NBR { get; set; }

      /// <summary>
      /// Gets or sets PHONE_EXTENSION
      /// </summary>
      public string PHONE_EXTENSION { get; set; }

      /// <summary>
      /// Gets or sets DOMESTIC_INTERNATIONL_IND
      /// </summary>
      public string DOMESTIC_INTERNATIONL_IND { get; set; }

      /// <summary>
      /// Gets or sets COUNTRY
      /// </summary>
      public string COUNTRY { get; set; }

      /// <summary>
      /// Gets or sets STREET_ADDRESS_1
      /// </summary>
      public string STREET_ADDRESS_1 { get; set; }

      /// <summary>
      /// Gets or sets STREET_ADDRESS_2
      /// </summary>
      public string STREET_ADDRESS_2 { get; set; }

      /// <summary>
      /// Gets or sets ZIP_CODE
      /// </summary>
      public string ZIP_CODE { get; set; }

      /// <summary>
      /// Gets or sets ZIP_PLUS
      /// </summary>
      public string ZIP_PLUS { get; set; }

      /// <summary>
      /// Gets or sets CITY
      /// </summary>
      public string CITY { get; set; }

      /// <summary>
      /// Gets or sets STATE_CODE
      /// </summary>
      public string STATE_CODE { get; set; }

      /// <summary>
      /// Gets or sets COUNTY_NAME
      /// </summary>
      public string COUNTY_NAME { get; set; }

      /// <summary>
      /// Gets or sets PROVINCE
      /// </summary>
      public string PROVINCE { get; set; }

      /// <summary>
      /// Gets or sets NON_US_POSTAL_CODE
      /// </summary>
      public string NON_US_POSTAL_CODE { get; set; }
   }
}
