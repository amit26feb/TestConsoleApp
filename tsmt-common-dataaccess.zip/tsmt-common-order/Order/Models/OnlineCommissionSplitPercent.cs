// <copyright file="OnlineCommissionSplitPercent.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
    using System;
    using TSMT.DataAccess;

   /// <summary>
   /// Represents data model for online commission split percent for credit job and sales order. This model represents the table COMM_CJ_EQ_BS_SPLIT_PCT for credit jobs
   /// and COMM_SO_SPLIT_PCT for sales orders.
   /// </summary>
   public class OnlineCommissionSplitPercent : IDataEntity
    {
        /// <summary>
        /// Gets or sets credit job ID
        /// </summary>
        public int? CREDIT_JOB_ID { get; set; }

        /// <summary>
        /// Gets or sets sales order ID
        /// </summary>
        public int? SALES_ORD_ID { get; set; }

        /// <summary>
        /// Gets or sets DR Address ID
        /// </summary>
        public int DR_ADDRESS_ID { get; set; }

        /// <summary>
        /// Gets or sets split id
        /// </summary>
        public int SPLIT_ID { get; set; }

        /// <summary>
        /// Gets or sets original split id
        /// </summary>
        public int? ORIG_SPLIT_ID { get; set; }

        /// <summary>
        /// Gets or sets split start date
        /// </summary>
        public DateTime SPLIT_START_DATE { get; set; }

        /// <summary>
        /// Gets or sets split end date
        /// </summary>
        public DateTime? SPLIT_END_DATE { get; set; }

        /// <summary>
        /// Gets or sets valid date range indicator
        /// </summary>
        public string VALID_DATE_RANGE_FLAG { get; set; }

        /// <summary>
        /// Gets or sets split create date
        /// </summary>
        public DateTime? CREATED_DATE { get; set; }

        /// <summary>
        /// Gets or sets user that has created the split
        /// </summary>
        public string CREATED_BY { get; set; }

        /// <summary>
        /// Gets or sets split updated date
        /// </summary>
        public DateTime? UPDATED_DATE { get; set; }

        /// <summary>
        /// Gets or sets user that has updated the split
        /// </summary>
        public string UPDATED_BY { get; set; }

        /// <summary>
        /// Gets or sets transmit indicator
        /// </summary>
        public string TRANSMIT_IND { get; set; }
    }
}
