// <copyright file="GrossCommissionSearchOptions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using System.Collections.Generic;

   /// <summary>
   /// Model for gross commission search options
   /// </summary>
   public class GrossCommissionSearchOptions
   {
      /// <summary>
      /// Gets or sets sales order ids
      /// </summary>
      public IEnumerable<int> SalesOrderIds { get; set; }

      /// <summary>
      /// Gets or sets created from date
      /// </summary>
      public DateTime? CreatedFrom { get; set; }

      /// <summary>
      /// Gets or sets created to date
      /// </summary>
      public DateTime? CreatedTo { get; set; }
   }
}
