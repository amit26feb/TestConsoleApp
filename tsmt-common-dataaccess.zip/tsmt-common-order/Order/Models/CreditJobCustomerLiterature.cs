// <copyright file="CreditJobCustomerLiterature.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   ///  Model for customer literature
   /// </summary>
   public class CreditJobCustomerLiterature
   {
      /// <summary>
      /// Gets or sets DEFAULT_LIT_DATE
      /// </summary>
      public DateTime? DEFAULT_LIT_DATE { get; set; }

      /// <summary>
      /// Gets or sets DEFAULT_LIT_PRINT_IND
      /// </summary>
      public string DEFAULT_LIT_PRINT_IND { get; set; }

      /// <summary>
      /// Gets or sets DEFAULT_LIT_QTY
      /// </summary>
      public int DEFAULT_LIT_QTY { get; set; }
   }
}
