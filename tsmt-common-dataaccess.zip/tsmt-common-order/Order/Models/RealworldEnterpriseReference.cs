// <copyright file="RealworldEnterpriseReference.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for realworld enterprise reference data
   /// </summary>
   public class RealworldEnterpriseReference
   {
      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets R12_PARTY_NO
      /// </summary>
      public int R12_PARTY_NO { get; set; }
   }
}
