// <copyright file="CustomerLiterature.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
    using System;
    using TSMT.DataAccess;

    /// <summary>
    /// Model for customer literature
    /// </summary>
    public class CustomerLiterature : IDataEntity
    {
        /// <summary>
        /// Gets or sets DEFAULT_LIT_DATE
        /// </summary>
        public DateTime? DEFAULT_LIT_DATE { get; set; }

        /// <summary>
        /// Gets or sets DEFAULT_LIT_PRINT_IND
        /// </summary>
        public string DEFAULT_LIT_PRINT_IND { get; set; }

        /// <summary>
        /// Gets or sets DEFAULT_LIT_QTY
        /// </summary>
        public int DEFAULT_LIT_QTY { get; set; }

        /// <summary>
        /// Gets or sets SHIPPING_INSTRUCTION_ID
        /// </summary>
        public int SHIPPING_INSTRUCTION_ID { get; set; }

        /// <summary>
        /// Gets or sets SHIP_INSTRUCT_DESCR
        /// </summary>
        public string SHIP_INSTRUCT_DESCR { get; set; }

        /// <summary>
        /// Gets or sets JOB_CONTACT
        /// </summary>
        public string JOB_CONTACT { get; set; }

        /// <summary>
        /// Gets or sets DEFAULT_LIT_EMAIL_1
        /// </summary>
        public string DEFAULT_LIT_EMAIL_1 { get; set; }

        /// <summary>
        /// Gets or sets DEFAULT_LIT_EMAIL_2
        /// </summary>
        public string DEFAULT_LIT_EMAIL_2 { get; set; }

        /// <summary>
        /// Gets or sets PROJECT_MGR_USERID
        /// </summary>
        public string PROJECT_MGR_USERID { get; set; }

        /// <summary>
        /// Gets or sets PROJECT_MGR
        /// </summary>
        public string PROJECT_MGR { get; set; }
    }
}
