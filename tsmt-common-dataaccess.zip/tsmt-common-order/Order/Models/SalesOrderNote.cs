// <copyright file="SalesOrderNote.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for sales order note
   /// </summary>
   public class SalesOrderNote
   {
      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets NOTE_ID
      /// </summary>
      public int NOTE_ID { get; set; }

      /// <summary>
      /// Gets or sets NOTE_TEXT
      /// </summary>
      public string NOTE_TEXT { get; set; }
   }
}
