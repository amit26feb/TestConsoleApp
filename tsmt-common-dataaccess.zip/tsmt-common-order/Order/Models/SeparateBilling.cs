// <copyright file="SeparateBilling.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for separate billing
   /// </summary>
   public class SeparateBilling
   {
      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets ORD_LINE_NBR
      /// </summary>
      public int ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets PLANNED_SHIPMENT_NBR
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets PROD_CODE
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether is SEPARATE_BILLING_IND or not
      /// </summary>
      public bool SEPARATE_BILLING_IND { get; set; }

      /// <summary>
      /// Gets or sets XREF_SALES_ORDER
      /// </summary>
      public string XREF_SALES_ORDER { get; set; }
   }
}
