// <copyright file="OrderLineLogistics.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for order line logistics data
   /// </summary>
   public class OrderLineLogistics
   {
      /// <summary>
      /// Gets or sets OP_RULE_ID
      /// </summary>
      public int OP_RULE_ID { get; set; }

      /// <summary>
      /// Gets or sets COUNTRY
      /// </summary>
      public string COUNTRY { get; set; }

      /// <summary>
      /// Gets or sets STATE_CODE
      /// </summary>
      public string STATE_CODE { get; set; }

      /// <summary>
      /// Gets or sets SHIP_TO_STATE_CODE
      /// </summary>
      public string SHIP_TO_STATE_CODE { get; set; }

      /// <summary>
      /// Gets or sets PROVINCE
      /// </summary>
      public string PROVINCE { get; set; }
   }
}
