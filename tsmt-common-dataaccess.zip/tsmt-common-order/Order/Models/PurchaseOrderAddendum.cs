// <copyright file="PurchaseOrderAddendum.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for purchase order addendum
   /// </summary>
   public class PurchaseOrderAddendum : IDataEntity
   {
      /// <summary>
      /// Gets or sets CREDIT_JOB_ADDENDUM_NBR
      /// </summary>
      public string CREDIT_JOB_ADDENDUM_NBR { get; set; }

      /// <summary>
      /// Gets or sets ADDENDUM_REFERENCE
      /// </summary>
      public string ADDENDUM_REFERENCE { get; set; }

      /// <summary>
      /// Gets or sets DATE_PO_ISSUED
      /// </summary>
      public DateTime DATE_PO_ISSUED { get; set; }

      /// <summary>
      /// Gets or sets ADDENDUM_AMT
      /// </summary>
      public decimal ADDENDUM_AMT { get; set; }

      /// <summary>
      /// Gets or sets change order status
      /// </summary>
      public string CO_STATUS { get; set; }

      /// <summary>
      /// Gets or sets purchase order number
      /// </summary>
      public string PO_NBR { get; set; }

      /// <summary>
      /// Gets or sets ORIG_PO_AMT
      /// </summary>
      public decimal ORIG_PO_AMT { get; set; }

      /// <summary>
      /// Gets or sets RUNNING_TOTAL
      /// </summary>
      public decimal RUNNING_TOTAL { get; set; }

      /// <summary>
      /// Gets or sets ADDENDUM_TYPE - Types are 'CCR' and 'Null'
      /// Type "CCR" means the dollars covered by the addendum are not to be billed to the customer automatically.
      /// </summary>
      public string ADDENDUM_TYPE { get; set; }

      /// <summary>
      /// Gets or sets TAX_AMT
      /// </summary>
      public decimal? TAX_AMT { get; set; }

      /// <summary>
      /// Gets or sets ADDENDUM_SO_COMMENTS
      /// </summary>
      public string ADDENDUM_SO_COMMENTS { get; set; }

      /// <summary>
      /// Gets or sets DATE_ACCEPTED
      /// </summary>
      public DateTime? DATE_ACCEPTED { get; set; }

      /// <summary>
      /// Gets or sets DATE_ADDENDUM_RECEIVED
      /// </summary>
      public DateTime? DATE_ADDENDUM_RECD { get; set; }

      /// <summary>
      /// Gets or sets ADDENDUM_SPECIAL_FOLLOWUP_DATE
      /// </summary>
      public DateTime? ADDENDUM_SPECIAL_FOLLOWUP_DATE { get; set; }

      /// <summary>
      /// Gets or sets DATE_ACKNOWLEDGED
      /// </summary>
      public DateTime? DATE_ACKNOWLEDGED { get; set; }

      /// <summary>
      /// Gets or sets ADDENDUM_SPECIAL_COMMENTS
      /// </summary>
      public string ADDENDUM_SPECIAL_COMMENTS { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether IS_TAXABLE
      /// </summary>
      public bool IS_TAXABLE { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether IS_TAX_INCLUDED
      /// </summary>
      public bool IS_TAX_INCLUDED { get; set; }

      /// <summary>
      /// Gets or sets total number of po addendum records for given input
      /// </summary>
      public int TOTAL_POADDENDUM_RECORDS { get; set; }

      /// <summary>
      /// Gets or sets CUST_EXEMPTION_IND
      /// </summary>
      public char CUST_EXEMPTION_IND { get; set; }

      /// <summary>
      /// Gets or sets TAX_INCLUDED_IND
      /// </summary>
      public char TAX_INCLUDED_IND { get; set; }
   }
}
