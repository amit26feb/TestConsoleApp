// <copyright file="CreditSupplement.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for credit supplement
   /// </summary>
   public class CreditSupplement : IDataEntity
   {
      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets PROTECTION_FREQUENCY
      /// </summary>
      public string PROTECTION_FREQUENCY { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether gets or sets CSS_COMPLETED
      /// </summary>
      public bool CSS_COMPLETED { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_SUPPLEMENT_COMP_DATE
      /// </summary>
      public DateTime? CREDIT_SUPPLEMENT_COMP_DATE { get; set; }

      /// <summary>
      /// Gets or sets FUNDING_TYPE
      /// </summary>
      public string FUNDING_TYPE { get; set; }

      /// <summary>
      /// Gets or sets PROTECTION_TYPE
      /// </summary>
      public string PROTECTION_TYPE { get; set; }

      /// <summary>
      /// Gets or sets PRELIMINARY_NOTICE_SENT_DATE
      /// </summary>
      public DateTime? PRELIMINARY_NOTICE_SENT_DATE { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_SUPPLEMENT_ACCEPT_DATE
      /// </summary>
      public DateTime? CREDIT_SUPPLEMENT_ACCEPT_DATE { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether gets or sets CSS_ACCEPTED
      /// </summary>
      public bool CSS_ACCEPTED { get; set; }

      /// <summary>
      /// Gets or sets PAYMENT_BOND_NBR
      /// </summary>
      public string PAYMENT_BOND_NBR { get; set; }

      /// <summary>
      /// Gets or sets DATE_FINAL_BOND_NOTICE_SENT
      /// </summary>
      public DateTime? DATE_FINAL_BOND_NOTICE_SENT { get; set; }

      /// <summary>
      /// Gets or sets TITLE_SEARCH_COMPLETE_DATE
      /// </summary>
      public DateTime? TITLE_SEARCH_COMPLETE_DATE { get; set; }
   }
}
