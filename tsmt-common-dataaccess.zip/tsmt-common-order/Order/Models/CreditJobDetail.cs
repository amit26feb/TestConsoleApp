// <copyright file="CreditJobDetail.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// credit job detail model
   /// </summary>
   public class CreditJobDetail : IDataEntity
   {
      /// <summary>
      /// Gets or sets HQTR_CREDIT_JOB_ID
      /// </summary>
      public int? HQTR_CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets ORIGINATING_DR_ADDRESS
      /// </summary>
      public int? ORIGINATING_DR_ADDRESS { get; set; }

      /// <summary>
      /// Gets or sets WATCOM_JOB_ID
      /// </summary>
      public int? WATCOM_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_JOB_NBR
      /// </summary>
      public string LEGACY_JOB_NBR { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_NAME
      /// </summary>
      public string CREDIT_JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets COUNTRY
      /// </summary>
      public string COUNTRY { get; set; }

      /// <summary>
      /// Gets or sets STATE_CODE
      /// </summary>
      public string STATE_CODE { get; set; }

      /// <summary>
      /// Gets or sets PROVINCE
      /// </summary>
      public string PROVINCE { get; set; }

      /// <summary>
      /// Gets or sets PT3PT4_CREATE_PROJECT_FLAG
      /// </summary>
      public char? PT3PT4_CREATE_PROJECT_FLAG { get; set; }

      /// <summary>
      /// Gets or sets NAME_FIRST
      /// </summary>
      public string NAME_FIRST { get; set; }

      /// <summary>
      /// Gets or sets NAME_LAST
      /// </summary>
      public string NAME_LAST { get; set; }

      /// <summary>
      /// Gets or sets USER_ID
      /// </summary>
      public string USER_ID { get; set; }

      /// <summary>
      /// Gets or sets DATE_ENTERED
      /// </summary>
      public DateTime DATE_ENTERED { get; set; }

      /// <summary>
      /// Gets or sets INSERT_DATE
      /// </summary>
      public DateTime INSERT_DATE { get; set; }

      /// <summary>
      /// Gets or sets HAS_CHANGE_ORDER
      /// </summary>
      public char HAS_CHANGE_ORDER { get; set; }

      /// <summary>
      /// Gets or sets Credit Supplement Completion Date
      /// </summary>
      public DateTime? CREDIT_SUPPLEMENT_COMP_DATE { get; set; }

      /// <summary>
      /// Gets or sets FUNDING TYPE
      /// </summary>
      public string FUNDING_TYPE { get; set; }

      /// <summary>
      /// Gets or sets JOB_TYPE
      /// </summary>
      public string JOB_TYPE { get; set; }

      /// <summary>
      /// Gets or sets JOB_NAME
      /// </summary>
      public string JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets orders created indicator in foe
      /// </summary>
      public string FOE2_CREATED_ORDERS_IND { get; set; }

      /// <summary>
      /// Gets or sets ORIG_PO_AMT
      /// </summary>
      public decimal ORIG_PO_AMT { get; set; }

      /// <summary>
      /// Gets or sets PO_NBR
      /// </summary>
      public string PO_NBR { get; set; }

      /// <summary>
      /// Gets or sets MGR_CONTACT
      /// </summary>
      public string MGR_CONTACT { get; set; }

      /// <summary>
      /// Gets or sets BID_NAME
      /// </summary>
      public string BID_NAME { get; set; }

      /// <summary>
      /// Gets or sets BID_ALTERNATE_ID
      /// </summary>
      public int? BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets HQTR_BID_ALTERNATE_ID
      /// </summary>
      public int? HQTR_BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets ORACLE_PROJECT_IND
      /// </summary>
      public char? ORACLE_PROJECT_IND { get; set; }

      /// <summary>
      /// Gets or sets CONTRACT_STG_IND
      /// </summary>
      public string CONTRACT_STG_IND { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether credit project has pending changes or not
      /// </summary>
      public bool HAS_PENDING_CHANGES { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO (aka Customer Account Number)
      /// </summary>
      public string SOLD_TO { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_CUST_CHANNEL
      /// </summary>
      public string SOLD_TO_CUST_CHANNEL { get; set; }

      /// <summary>
      /// Gets or sets Sold To (aka Customer Name)
      /// </summary>
      public string SOLD_TO_NAME { get; set; }

      /// <summary>
      /// Gets or sets SPA_NUMBER
      /// </summary>
      public string SPA_NUMBER { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int? SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_ID
      /// </summary>
      public int SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets locked user id
      /// </summary>
      public string LOCK_USER_ID { get; set; }

      /// <summary>
      /// Gets or sets locked application
      /// </summary>
      public string LOCK_APPLICATION { get; set; }

      /// <summary>
      /// Gets or sets CUST_CREDIT_CATG_CODE
      /// </summary>
      public string CUST_CREDIT_CATG_CODE { get; set; }

      /// <summary>
      /// Gets or sets R12_PROJECT_NUMBER
      /// </summary>
      public string R12_PROJECT_NUMBER { get; set; }

      /// <summary>
      /// Gets or sets planned shipment contract id
      /// </summary>
      public string PS_CONTRACT_ID { get; set; }

      /// <summary>
      /// Gets or sets revise date
      /// </summary>
      public DateTime? REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets ship instruction revise date
      /// </summary>
      public DateTime? SHIP_INSTR_REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets job revise date
      /// </summary>
      public DateTime? JOB_REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets created in oracle
      /// </summary>
      public char? CREATED_IN_ORACLE { get; set; }

      /// <summary>
      /// Gets or sets credit supplement accept date
      /// </summary>
      public DateTime? CREDIT_SUPPLEMENT_ACCEPT_DATE { get; set; }
   }
}
