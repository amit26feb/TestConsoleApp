// <copyright file="InvoiceMap.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System.Collections.Generic;

   /// <summary>
   /// Class for Invoice map
   /// </summary>
   public class InvoiceMap
   {
      /// <summary>
      /// Gets or sets old shipping instruction id
      /// </summary>
      public int OldShippingInstructionId { get; set; }

      /// <summary>
      /// Gets or sets new shipping instruction id
      /// </summary>
      public int NewShippingInstructionId { get; set; }

      /// <summary>
      /// Gets or sets shipment details
      /// </summary>
      public IEnumerable<ShipmentDetail> ShipmentDetails { get; set; }
   }
}
