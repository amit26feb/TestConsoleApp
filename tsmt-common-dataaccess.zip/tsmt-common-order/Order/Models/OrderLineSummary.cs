// <copyright file="OrderLineSummary.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for order line summary data
   /// </summary>
   public class OrderLineSummary : IDataEntity
   {
      /// <summary>
      /// Gets or sets legacy order number
      /// </summary>
      public string LEGACY_ORD_NBR { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets planned shipment number
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets order line number
      /// </summary>
      public int ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets order line type
      /// </summary>
      public string ORD_LINE_TYPE { get; set; }

      /// <summary>
      /// Gets or sets order line quantity
      /// </summary>
      public int QTY { get; set; }

      /// <summary>
      /// Gets or sets invc with order line number
      /// </summary>
      public int INVC_WITH_ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets order line item description
      /// </summary>
      public string ORD_LINE_DESCR { get; set; }

      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets order status code
      /// </summary>
      public string ORD_STATUS_CODE { get; set; }

      /// <summary>
      /// Gets or sets prod code
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets ship cycle length
      /// </summary>
      public int SHIP_CYCLE_LENGTH { get; set; }

      /// <summary>
      /// Gets or sets unit of measure
      /// </summary>
      public string UNIT_OF_MEASURE { get; set; }

      /// <summary>
      /// Gets or sets si type
      /// </summary>
      public string SI_TYPE { get; set; }

      /// <summary>
      /// Gets or sets name
      /// </summary>
      public string NAME { get; set; }

      /// <summary>
      /// Gets or sets ship instruct descr
      /// </summary>
      public string SHIP_INSTRUCT_DESCR { get; set; }

      /// <summary>
      /// Gets or sets reqs delivery date earliest
      /// </summary>
      public DateTime? REQS_DELIVERY_DATE_EARLIEST { get; set; }

      /// <summary>
      /// Gets or sets reqs delivery date latest
      /// </summary>
      public DateTime? REQS_DELIVERY_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets dinal finisher indicator
      /// </summary>
      public string FINAL_FINISHER_IND { get; set; }

      /// <summary>
      /// Gets or sets ordering number
      /// </summary>
      public string ORDERING_NBR { get; set; }

      /// <summary>
      /// Gets or sets bu order status
      /// </summary>
      public string BU_ORDER_STATUS { get; set; }

      /// <summary>
      /// Gets or sets selling price
      /// </summary>
      public decimal SELLING_PRICE { get; set; }

      /// <summary>
      /// Gets or sets net price
      /// </summary>
      public decimal NET_PRICE { get; set; }

      /// <summary>
      /// Gets or sets est ship date
      /// </summary>
      public DateTime? EST_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets shipping instruction id
      /// </summary>
      public int SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets order status date
      /// </summary>
      public DateTime? ORD_STATUS_DATE { get; set; }

      /// <summary>
      /// Gets or sets reqs ship date
      /// </summary>
      public DateTime? REQS_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets reqs ship date latest
      /// </summary>
      public DateTime? REQS_SHIP_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets total si unadj price
      /// </summary>
      public decimal TOTAL_SI_UNADJ_PRICE { get; set; }

      /// <summary>
      /// Gets or sets total da unadj price add
      /// </summary>
      public decimal TOTAL_DA_UNADJ_PRICE_ADD { get; set; }

      /// <summary>
      /// Gets or sets entd cost point lpaf
      /// </summary>
      public decimal? ENTD_COST_POINT_LPAF { get; set; }

      /// <summary>
      /// Gets or sets quick ship bpaf
      /// </summary>
      public decimal? QUICK_SHIP_BPAF { get; set; }

      /// <summary>
      /// Gets or sets qty lpaf
      /// </summary>
      public decimal? QTY_LPAF { get; set; }

      /// <summary>
      /// Gets or sets escalation lpaf
      /// </summary>
      public decimal? ESCALATION_LPAF { get; set; }

      /// <summary>
      /// Gets or sets auth cost point lpaf
      /// </summary>
      public decimal? AUTH_COST_POINT_LPAF { get; set; }

      /// <summary>
      /// Gets or sets entered multiplier
      /// </summary>
      public decimal ENTERED_MULTIPLIER { get; set; }

      /// <summary>
      /// Gets or sets liat conservation multiplier
      /// </summary>
      public decimal? LIST_CONVERSION_MULT { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether gets or sets HAS_NO_CHARGE_INDICATOR
      /// </summary>
      public bool HAS_NO_CHARGE_INDICATOR { get; set; }

      /// <summary>
      /// Gets or sets ship from code
      /// </summary>
      public string SHIP_FROM_CODE { get; set; }

      /// <summary>
      /// Gets or sets variation billing method code
      /// </summary>
      public string VARIATION_BILLING_METHOD_CODE { get; set; }

      /// <summary>
      /// Gets or sets req ship date casual code
      /// </summary>
      public string REQ_SHIP_DATE_CAUSAL_CODE { get; set; }

      /// <summary>
      /// Gets or sets total order lines
      /// </summary>
      public int TOTAL_ORDER_LINES { get; set; }

      /// <summary>
      /// Gets or sets order regular commission
      /// </summary>
      public int COMM_DLR { get; set; }

      /// <summary>
      /// Gets or sets headquarter sales order id
      /// </summary>
      public int? HQTR_SALES_ORDER_ID { get; set; }
   }
}
