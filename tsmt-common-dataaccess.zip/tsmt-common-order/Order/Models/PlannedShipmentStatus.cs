// <copyright file="PlannedShipmentStatus.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Planned shipment status
   /// </summary>
   public class PlannedShipmentStatus
   {
      /// <summary>
      /// Gets or sets BU_ORDER_STATUS
      /// </summary>
      public string BU_ORDER_STATUS { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }
   }
}
