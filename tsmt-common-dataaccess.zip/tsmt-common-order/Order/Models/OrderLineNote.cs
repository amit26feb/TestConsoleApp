// <copyright file="OrderLineNote.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for order line note
   /// </summary>
   public class OrderLineNote : IDataEntity
   {
      /// <summary>
      /// Gets or sets NOTE_ID
      /// </summary>
      public int NOTE_ID { get; set; }

      /// <summary>
      /// Gets or sets NOTE_TEXT
      /// </summary>
      public string NOTE_TEXT { get; set; }

      /// <summary>
      /// Gets or sets ORD_LINE_NBR
      /// </summary>
      public int ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }
   }
}
