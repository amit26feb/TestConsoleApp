// <copyright file="CreditJobSummaryModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for credit job summary
   /// </summary>
   public class CreditJobSummaryModel : IDataEntity
   {
      /// <summary>
      /// Gets or sets JOB_NAME
      /// </summary>
      public string JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets WATCOM_JOB_ID
      /// </summary>
      public int? WATCOM_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets ORIGINATING_DR_ADDRESS
      /// </summary>
      public int? ORIGINATING_DR_ADDRESS { get; set; }

      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_NAME
      /// </summary>
      public string CREDIT_JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets PO_NBR
      /// </summary>
      public string PO_NBR { get; set; }

      /// <summary>
      /// Gets or sets ORIG_PO_AMT
      /// </summary>
      public decimal ORIG_PO_AMT { get; set; }

      /// <summary>
      /// Gets or sets TOTAL_PO_AMOUNT
      /// </summary>
      public decimal TOTAL_PO_AMOUNT { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_JOB_NBR
      /// </summary>
      public string LEGACY_JOB_NBR { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO
      /// </summary>
      public string SOLD_TO { get; set; }

      /// <summary>
      /// Gets or sets REALWORLD_ACCT_NO
      /// </summary>
      public string REALWORLD_ACCT_NO { get; set; }

      /// <summary>
      /// Gets or sets R12_PARTY_NO
      /// </summary>
      public long? R12_PARTY_NO { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_NAME
      /// </summary>
      public string SOLD_TO_NAME { get; set; }

      /// <summary>
      /// Gets or sets NAME_FIRST
      /// </summary>
      public string NAME_FIRST { get; set; }

      /// <summary>
      /// Gets or sets NAME_LAST
      /// </summary>
      public string NAME_LAST { get; set; }

      /// <summary>
      /// Gets or sets NAME
      /// </summary>
      public string NAME { get; set; }

      /// <summary>
      /// Gets or sets total number of records for given input
      /// </summary>
      public int TOTAL_COUNT { get; set; }

      /// <summary>
      /// Gets or sets PROJECT_COMPLETION_DATE
      /// </summary>
      public DateTime? PROJECT_COMPLETION_DATE { get; set; }

      /// <summary>
      /// Gets or sets LOCK_USER_ID
      /// </summary>
      public string LOCK_USER_ID { get; set; }

      /// <summary>
      /// Gets or sets LOCK_APPLICATION
      /// </summary>
      public string LOCK_APPLICATION { get; set; }

      /// <summary>
      /// Gets or sets HQTR_CREDIT_JOB_ID
      /// </summary>
      public int? HQTR_CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets r12 project number
      /// </summary>
      public string R12_PROJECT_NUMBER { get; set; }
   }
}
