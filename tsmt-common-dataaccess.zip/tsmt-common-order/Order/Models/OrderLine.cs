// <copyright file="OrderLine.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for order line data
   /// </summary>
   public class OrderLine : IDataEntity
   {
      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets planned shipment number
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets order line number
      /// </summary>
      public int ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets order line type
      /// </summary>
      public string ORD_LINE_TYPE { get; set; }

      /// <summary>
      /// Gets or sets order line quantity
      /// </summary>
      public int QTY { get; set; }

      /// <summary>
      /// Gets or sets order line item description
      /// </summary>
      public string ORD_LINE_DESCR { get; set; }

      /// <summary>
      /// Gets or sets reqs delivery date earliest
      /// </summary>
      public DateTime? REQS_DELIVERY_DATE_EARLIEST { get; set; }

      /// <summary>
      /// Gets or sets reqs delivery date latest
      /// </summary>
      public DateTime? REQS_DELIVERY_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets bu order status
      /// </summary>
      public string BU_ORDER_STATUS { get; set; }

      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets selling price
      /// </summary>
      public decimal SELLING_PRICE { get; set; }

      /// <summary>
      /// Gets or sets net price
      /// </summary>
      public decimal NET_PRICE { get; set; }

      /// <summary>
      /// Gets or sets ordering number
      /// </summary>
      public string ORDERING_NBR { get; set; }

      /// <summary>
      /// Gets or sets est ship date
      /// </summary>
      public DateTime? EST_SHIP_DATE { get; set; }

      /// <summary>
      /// Gets or sets order status code
      /// </summary>
      public string ORD_STATUS_CODE { get; set; }

      /// <summary>
      /// Gets or sets order regular commission
      /// </summary>
      public int COMM_DLR { get; set; }

      /// <summary>
      /// Gets or sets insert date
      /// </summary>
      public DateTime? INSERT_DATE { get; set; }

      /// <summary>
      /// Gets or sets change allowed indicator
      /// </summary>
      public char CHG_ALLOWED_IND { get; set; }

      /// <summary>
      /// Gets or sets admin revise date
      /// </summary>
      public DateTime? ADMIN_REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets latest requested ship date
      /// </summary>
      public DateTime? REQS_SHIP_DATE_LATEST { get; set; }

      /// <summary>
      /// Gets or sets product family id
      /// </summary>
      public int? PROD_FAMILY_ID { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether equipment is installed by trane or not
      /// </summary>
      public char? INSTALL_CATG { get; set; }

      /// <summary>
      /// Gets or sets requested ship date casual code
      /// </summary>
      public string REQ_SHIP_DATE_CAUSAL_CODE { get; set; }

      /// <summary>
      /// Gets or sets ship revise date
      /// </summary>
      public DateTime? SHIP_REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets note revise date
      /// </summary>
      public DateTime? NOTE_REVISE_DATE { get; set; }

      /// <summary>
      /// Gets or sets variation id
      /// </summary>
      public int? VARIATION_ID { get; set; }

      /// <summary>
      /// Gets or sets authenticated multiplier
      /// </summary>
      public decimal? AUTH_MULT { get; set; }

      /// <summary>
      /// Gets or sets entered multiplier
      /// </summary>
      public decimal ENTERED_MULTIPLIER { get; set; }

      /// <summary>
      /// Gets or sets entered cost point lpaf
      /// </summary>
      public decimal? ENTD_COST_POINT_LPAF { get; set; }

      /// <summary>
      /// Gets or sets authenticated cost point lpaf
      /// </summary>
      public decimal? AUTH_COST_POINT_LPAF { get; set; }

      /// <summary>
      /// Gets or sets product code
      /// </summary>
      public string PROD_CODE { get; set; }

      /// <summary>
      /// Gets or sets si id
      /// </summary>
      public int? SI_ID { get; set; }

      /// <summary>
      /// Gets or sets selected pricing param id
      /// </summary>
      public int? SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets requested ship date
      /// </summary>
      public DateTime? REQS_SHIP_DATE { get; set; }
   }
}
