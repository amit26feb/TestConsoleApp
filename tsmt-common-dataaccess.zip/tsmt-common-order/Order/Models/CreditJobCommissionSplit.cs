// <copyright file="CreditJobCommissionSplit.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for fetching the equipment and contract commission split data
   /// </summary>
   public class CreditJobCommissionSplit : IDataEntity
   {
      /// <summary>
      /// Gets or sets COMMISSION_SEQUENCE
      /// </summary>
      public int COMMISSION_SEQUENCE { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_JOB_NBR
      /// </summary>
      public string LEGACY_JOB_NBR { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_NAME
      /// </summary>
      public string CREDIT_JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets SPLIT_ID (It is applicable only to online commission splits)
      /// </summary>
      public int SPLIT_ID { get; set; }

      /// <summary>
      /// Gets or sets SPLIT_START_DATE (It is applicable only to online commission splits)
      /// </summary>
      public DateTime SPLIT_START_DATE { get; set; }

      /// <summary>
      /// Gets or sets SPLIT_END_DATE (It is applicable only to online commission splits)
      /// </summary>
      public DateTime? SPLIT_END_DATE { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_ID
      /// </summary>
      public int SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_NAME
      /// </summary>
      public string SALES_OFFICE_NAME { get; set; }

      /// <summary>
      /// Gets or sets COMM_CODE
      /// </summary>
      public string COMM_CODE { get; set; }

      /// <summary>
      /// Gets or sets SALES_PERSON_NAME
      /// </summary>
      public string SALES_PERSON_NAME { get; set; }

      /// <summary>
      /// Gets or sets SALES_PERSON_STATUS
      /// </summary>
      public string SALES_PERSON_STATUS { get; set; }

      /// <summary>
      /// Gets or sets COMM_PCT
      /// </summary>
      public decimal COMM_PCT { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether it is ORACLE_PROJECT_IND or not
      /// </summary>
      public bool ORACLE_PROJECT_IND { get; set; }
   }
}
