// <copyright file="ShippingInstruction.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for shipping instruction
   /// </summary>
   public class ShippingInstruction
   {
      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets SHIP_INSTRUCT_DESCR
      /// </summary>
      public string SHIP_INSTRUCT_DESCR { get; set; }

      /// <summary>
      /// Gets or sets SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets MARK_BILL_LADING_TEXT
      /// </summary>
      public string MARK_BILL_LADING_TEXT { get; set; }

      /// <summary>
      /// Gets or sets DOMESTIC_INTERNATIONL_IND
      /// </summary>
      public char DOMESTIC_INTERNATIONL_IND { get; set; }

      /// <summary>
      /// Gets or sets COUNTRY
      /// </summary>
      public string COUNTRY { get; set; }

      /// <summary>
      /// Gets or sets FINAL_FINISHER_IND
      /// </summary>
      public char FINAL_FINISHER_IND { get; set; }

      /// <summary>
      /// Gets or sets NAME
      /// </summary>
      public string NAME { get; set; }

      /// <summary>
      /// Gets or sets STREET_ADDRESS_1
      /// </summary>
      public string STREET_ADDRESS_1 { get; set; }

      /// <summary>
      /// Gets or sets STREET_ADDRESS_2
      /// </summary>
      public string STREET_ADDRESS_2 { get; set; }

      /// <summary>
      /// Gets or sets CITY
      /// </summary>
      public string CITY { get; set; }

      /// <summary>
      /// Gets or sets STATE_CODE
      /// </summary>
      public string STATE_CODE { get; set; }

      /// <summary>
      /// Gets or sets PROVINCE
      /// </summary>
      public string PROVINCE { get; set; }

      /// <summary>
      /// Gets or sets NON_US_POSTAL_CODE
      /// </summary>
      public string NON_US_POSTAL_CODE { get; set; }

      /// <summary>
      /// Gets or sets ZIP_CODE
      /// </summary>
      public string ZIP_CODE { get; set; }

      /// <summary>
      /// Gets or sets ZIP_PLUS
      /// </summary>
      public string ZIP_PLUS { get; set; }

      /// <summary>
      /// Gets or sets FIPS_CODE
      /// </summary>
      public string FIPS_CODE { get; set; }

      /// <summary>
      /// Gets or sets MARK_PKGS_W_PO_IND
      /// </summary>
      public char MARK_PKGS_W_PO_IND { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int? CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_ATTENTION
      /// </summary>
      public string CALL_PRIOR_ATTENTION { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_ATTENTION_2
      /// </summary>
      public string CALL_PRIOR_ATTENTION_2 { get; set; }

      /// <summary>
      /// Gets or sets PRIM_CONTACT_EMAIL
      /// </summary>
      public string PRIM_CONTACT_EMAIL { get; set; }

      /// <summary>
      /// Gets or sets ALT_CONTACT_EMAIL
      /// </summary>
      public string ALT_CONTACT_EMAIL { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_NBR
      /// </summary>
      public string CALL_PRIOR_NBR { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_NBR_2
      /// </summary>
      public string CALL_PRIOR_NBR_2 { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_EXTENSION
      /// </summary>
      public string CALL_PRIOR_EXTENSION { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_EXTENSION_2
      /// </summary>
      public string CALL_PRIOR_EXTENSION_2 { get; set; }

      /// <summary>
      /// Gets or sets CALL_PRIOR_HRS
      /// </summary>
      public int? CALL_PRIOR_HRS { get; set; }

      /// <summary>
      /// Gets or sets SAME_AS_SOLD_TO_IND
      /// </summary>
      public char SAME_AS_SOLD_TO_IND { get; set; }

      /// <summary>
      /// Gets or sets IN_CITY_IND
      /// </summary>
      public char IN_CITY_IND { get; set; }

      /// <summary>
      /// Gets or sets CHG_ALLOWED_IND
      /// </summary>
      public char CHG_ALLOWED_IND { get; set; }

      /// <summary>
      /// Gets or sets DR_ADDRESS_ID
      /// </summary>
      public int DR_ADDRESS_ID { get; set; }

      /// <summary>
      /// Gets or sets DEFAULT_SHIPPING_IND
      /// </summary>
      public char? DEFAULT_SHIPPING_IND { get; set; }

      /// <summary>
      /// Gets or sets IN_USE_ON_LINE_ITEM_IND
      /// </summary>
      public char IN_USE_ON_LINE_ITEM_IND { get; set; }
   }
}
