// <copyright file="JobCode.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for job code
   /// </summary>
  public class JobCode
   {
      /// <summary>
      /// Gets or sets JOB_CLASS_ID
      /// </summary>
      public int JOB_CLASS_ID { get; set; }

      /// <summary>
      /// Gets or sets JOB_CODE_ID
      /// </summary>
      public int JOB_CODE_ID { get; set; }

      /// <summary>
      /// Gets or sets CODE_DESCRIPTION
      /// </summary>
      public string CODE_DESCRIPTION { get; set; }
   }
}
