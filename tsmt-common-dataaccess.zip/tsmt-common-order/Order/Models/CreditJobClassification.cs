// <copyright file="CreditJobClassification.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Credit job classification model
   /// </summary>
   public class CreditJobClassification : IDataEntity
   {
      /// <summary>
      /// Gets or sets JOB_CLASS_ID
      /// </summary>
      public int JOB_CLASS_ID { get; set; }

      /// <summary>
      /// Gets or sets JOB_CODE_ID
      /// </summary>
      public int JOB_CODE_ID { get; set; }

      /// <summary>
      /// Gets or sets CLASS_DESCRIPTION
      /// </summary>
      public string CLASS_DESCRIPTION { get; set; }

      /// <summary>
      /// Gets or sets CODE_DESCRIPTION
      /// </summary>
      public string CODE_DESCRIPTION { get; set; }

      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }
   }
}
