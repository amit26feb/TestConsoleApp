// <copyright file="OnlineCommissionSplit.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Represents data model for online commission splits. This is a consolidated model which represents the combined commission split data from commission split defenition
   /// and commission split percent.
   /// </summary>
   public class OnlineCommissionSplit : IDataEntity
   {
      /// <summary>
      /// Gets or sets sales order or credit job id
      /// </summary>
      public int ID { get; set; }

      /// <summary>
      /// Gets or sets dr address id
      /// </summary>
      public int DR_ADDRESS_ID { get; set; }

      /// <summary>
      /// Gets or sets split id
      /// </summary>
      public int SPLIT_ID { get; set; }

      /// <summary>
      /// Gets or sets split start date
      /// </summary>
      public DateTime SPLIT_START_DATE { get; set; }

      /// <summary>
      /// Gets or sets split end date
      /// </summary>
      public DateTime? SPLIT_END_DATE { get; set; }

      /// <summary>
      /// Gets or sets sales office id
      /// </summary>
      public int SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets sales office name
      /// </summary>
      public string SALES_OFFICE_NAME { get; set; }

      /// <summary>
      /// Gets or sets comm code
      /// </summary>
      public string COMM_CODE { get; set; }

      /// <summary>
      /// Gets or sets sales person name
      /// </summary>
      public string SALES_PERSON_NAME { get; set; }

      /// <summary>
      /// Gets or sets sales person status
      /// </summary>
      public string SALES_PERSON_STATUS { get; set; }

      /// <summary>
      /// Gets or sets commission percent
      /// </summary>
      public decimal COMMISSION_PERCENT { get; set; }

      /// <summary>
      /// Gets or sets base split id
      /// </summary>
      public int? BASE_SPLIT_ID { get; set; }

      /// <summary>
      /// Gets or sets transmit indicator
      /// </summary>
      public string TRANSMIT_IND { get; set; }

      /// <summary>
      /// Gets or sets valid date range flag to identify whether the credit job - split assignment active
      /// </summary>
      public string VALID_DATE_RANGE_FLAG { get; set; }

      /// <summary>
      /// Gets or sets last modified by
      /// </summary>
      public string LAST_MODIFIED_BY { get; set; }
   }
}
