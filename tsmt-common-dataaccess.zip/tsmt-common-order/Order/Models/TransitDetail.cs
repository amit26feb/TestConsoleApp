// <copyright file="TransitDetail.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for transit detail data
   /// </summary>
   public class TransitDetail
   {
      /// <summary>
      /// Gets or sets MIN_TRANSIT_DAYS
      /// </summary>
      public int MIN_TRANSIT_DAYS { get; set; }

      /// <summary>
      /// Gets or sets MAX_TRANSIT_DAYS
      /// </summary>
      public int MAX_TRANSIT_DAYS { get; set; }

      /// <summary>
      /// Gets or sets MED_TRANSIT_DAYS
      /// </summary>
      public int MED_TRANSIT_DAYS { get; set; }
   }
}
