// <copyright file="MarkBillOfLading.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   /// Model for mark bill of lading
   /// </summary>
   public class MarkBillOfLading
   {
      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets MARK_BILL_LADING_ID
      /// </summary>
      public int MARK_BILL_LADING_ID { get; set; }

      /// <summary>
      /// Gets or sets MARK_BILL_LADING_TEXT
      /// </summary>
      public string MARK_BILL_LADING_TEXT { get; set; }

      /// <summary>
      /// Gets or sets HOST_UPDATE_IND
      /// </summary>
      public char? HOST_UPDATE_IND { get; set; }

      /// <summary>
      /// Gets or sets INSERT_DATE
      /// </summary>
      public DateTime? INSERT_DATE { get; set; }
   }
}
