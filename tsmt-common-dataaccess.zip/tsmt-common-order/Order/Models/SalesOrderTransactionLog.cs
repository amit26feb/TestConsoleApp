// <copyright file="SalesOrderTransactionLog.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for sales order transaction log
   /// </summary>
   public class SalesOrderTransactionLog
   {
      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets PLANNED_SHIPMENT_NBR
      /// </summary>
      public string PLANNED_SHIPMENT_NBR { get; set; }

      /// <summary>
      /// Gets or sets EBS_ORD_NBR
      /// </summary>
      public int? EBS_ORD_NBR { get; set; }
   }
}
