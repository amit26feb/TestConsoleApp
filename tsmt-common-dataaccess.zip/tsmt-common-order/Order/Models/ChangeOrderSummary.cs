// <copyright file="ChangeOrderSummary.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for change order summary
   /// </summary>
   public class ChangeOrderSummary : IDataEntity
   {
      /// <summary>
      /// Gets or sets CO_ID
      /// </summary>
      public int CO_ID { get; set; }

      /// <summary>
      /// Gets or sets SHIP_TO_CO_ID
      /// </summary>
      public string SHIP_TO_CO_ID { get; set; }

      /// <summary>
      /// Gets or sets DATE_SUBMITTED
      /// </summary>
      public DateTime DATE_SUBMITTED { get; set; }

      /// <summary>
      /// Gets or sets CO_STATUS
      /// </summary>
      public string CO_STATUS { get; set; }

      /// <summary>
      /// Gets or sets STATUS_DATE
      /// </summary>
      public DateTime? STATUS_DATE { get; set; }

      /// <summary>
      /// Gets or sets SUBMITTED_PERSON_FIRST_NAME
      /// </summary>
      public string SUBMITTED_PERSON_FIRST_NAME { get; set; }

      /// <summary>
      /// Gets or sets SUBMITTED_PERSON_LAST_NAME
      /// </summary>
      public string SUBMITTED_PERSON_LAST_NAME { get; set; }

      /// <summary>
      /// Gets or sets PROCESSED_PERSON_FIRST_NAME
      /// </summary>
      public string PROCESSED_PERSON_FIRST_NAME { get; set; }

      /// <summary>
      /// Gets or sets PROCESSED_PERSON_LAST_NAME
      /// </summary>
      public string PROCESSED_PERSON_LAST_NAME { get; set; }

      /// <summary>
      /// Gets or sets PROCESSED_BY
      /// </summary>
      public string PROCESSED_BY { get; set; }

      /// <summary>
      /// Gets or sets SUBMITTED_BY
      /// </summary>
      public string SUBMITTED_BY { get; set; }

      /// <summary>
      /// Gets or sets BU_NOTES
      /// </summary>
      public string BU_NOTES { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_NOTES
      /// </summary>
      public string SALES_OFFICE_NOTES { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_JOB_NAME
      /// </summary>
      public string CREDIT_JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_JOB_NBR
      /// </summary>
      public string LEGACY_JOB_NBR { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_ID
      /// </summary>
      public int SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets MFG_LOC
      /// </summary>
      public string MFG_LOC { get; set; }

      /// <summary>
      /// Gets or sets NO_CHARGE_IND
      /// </summary>
      public string NO_CHARGE_IND { get; set; }

      /// <summary>
      /// Gets or sets LEGACY_ORD_NBR
      /// </summary>
      public string LEGACY_ORD_NBR { get; set; }

      /// <summary>
      /// Gets or sets SUBMITTED_PERSON
      /// </summary>
      public string SUBMITTED_PERSON { get; set; }

      /// <summary>
      /// Gets or sets RESPONSIBLE_PERSON
      /// </summary>
      public string RESPONSIBLE_PERSON { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SALES_ORD_ID { get; set; }
   }
}
