// <copyright file="CommissionSplit.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for fetching the equipment and contract commission split data
   /// </summary>
   public class CommissionSplit : IDataEntity
   {
      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_ID
      /// </summary>
      public int SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_NAME
      /// </summary>
      public string SALES_OFFICE_NAME { get; set; }

      /// <summary>
      /// Gets or sets COMMISSION_SEQUENCE
      /// </summary>
      public int COMMISSION_SEQUENCE { get; set; }

      /// <summary>
      /// Gets or sets COMMISSION_TYPE
      /// </summary>
      public string COMMISSION_TYPE { get; set; }

      /// <summary>
      /// Gets or sets COMM_CODE
      /// </summary>
      public string COMM_CODE { get; set; }

      /// <summary>
      /// Gets or sets SALES_PERSON_NAME
      /// </summary>
      public string SALES_PERSON_NAME { get; set; }

      /// <summary>
      /// Gets or sets COMM_PCT
      /// </summary>
      public decimal COMM_PCT { get; set; }
   }
}
