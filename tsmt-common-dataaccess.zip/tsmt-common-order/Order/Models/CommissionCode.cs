// <copyright file="CommissionCode.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for commission code
   /// </summary>
   public class CommissionCode
   {
      /// <summary>
      /// Gets or sets SALES_PERSON_NAME
      /// </summary>
      public string SALES_PERSON_NAME { get; set; }

      /// <summary>
      /// Gets or sets STATUS
      /// </summary>
      public string STATUS { get; set; }
   }
}
