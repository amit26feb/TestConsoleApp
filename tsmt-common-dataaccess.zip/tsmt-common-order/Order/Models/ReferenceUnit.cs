// <copyright file="ReferenceUnit.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for reference unit table data
   /// </summary>
   public class ReferenceUnit : IDataEntity
   {
      /// <summary>
      /// Gets or sets reference unit id
      /// </summary>
      public int REFERENCE_UNIT_ID { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets or sets order line number
      /// </summary>
      public int ORD_LINE_NBR { get; set; }

      /// <summary>
      /// Gets or sets tag
      /// </summary>
      public string TAG { get; set; }

      /// <summary>
      /// Gets or sets unit serial number
      /// </summary>
      public string UNIT_SERIAL_NBR { get; set; }

      /// <summary>
      /// Gets or sets tag sequence number
      /// </summary>
      public int TAG_SEQUENCE_NBR { get; set; }
   }
}
