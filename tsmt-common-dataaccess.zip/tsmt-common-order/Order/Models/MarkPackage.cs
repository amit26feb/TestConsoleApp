// <copyright file="MarkPackage.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   /// Model for mark package
   /// </summary>
   public class MarkPackage
   {
      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets SHIPPING_INSTRUCTION_ID
      /// </summary>
      public int SHIPPING_INSTRUCTION_ID { get; set; }

      /// <summary>
      /// Gets or sets MARK_PACKAGE_ID
      /// </summary>
      public int MARK_PACKAGE_ID { get; set; }

      /// <summary>
      /// Gets or sets MARK_PACKAGE_TEXT
      /// </summary>
      public string MARK_PACKAGE_TEXT { get; set; }

      /// <summary>
      /// Gets or sets HOST_UPDATE_IND
      /// </summary>
      public char? HOST_UPDATE_IND { get; set; }

      /// <summary>
      /// Gets or sets INSERT_DATE
      /// </summary>
      public DateTime? INSERT_DATE { get; set; }
   }
}
