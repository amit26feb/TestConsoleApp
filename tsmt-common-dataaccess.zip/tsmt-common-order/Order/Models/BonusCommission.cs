// <copyright file="BonusCommission.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   /// Additional Bonus Commmissions for Credit Jobs
   /// </summary>
   public class BonusCommission
   {
      /// <summary>
      /// Gets or sets Sequence Number
      /// </summary>
      public int SEQ_NBR { get; set; }

      /// <summary>
      /// Gets or sets the Credit Job Id
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets the Program Name
      /// </summary>
      public string PROGRAM_NAME { get; set; }

      /// <summary>
      /// Gets or sets the Bonus Percentage
      /// </summary>
      public decimal BONUS_PCT { get; set; }

      /// <summary>
      /// Gets or sets the Status
      /// </summary>
      public string STATUS { get; set; }

      /// <summary>
      /// Gets or sets the date the status changed
      /// </summary>
      public DateTime? STATUS_CHANGED_DATE { get; set; }

      /// <summary>
      /// Gets or sets the User who changed the status
      /// </summary>
      public string STATUS_CHANGED_BY { get; set; }

      /// <summary>
      /// Gets or sets the created date
      /// </summary>
      public DateTime? CREATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets the created by user
      /// </summary>
      public string CREATED_BY { get; set; }

      /// <summary>
      /// Gets or sets the Updated Date
      /// </summary>
      public DateTime? UPDATED_DATE { get; set; }

      /// <summary>
      /// Gets or sets the updated by user.
      /// </summary>
      public string UPDATED_BY { get; set; }

      /// <summary>
      /// Gets or sets the active flag
      /// </summary>
      public char ACTIVE_FLAG { get; set; }

      /// <summary>
      /// Gets or sets the Transmitted Indicator
      /// </summary>
      public char TRANSMIT_IND { get; set; }

      /// <summary>
      /// Gets or sets Note
      /// </summary>
      public string NOTE { get; set; }
   }
}
