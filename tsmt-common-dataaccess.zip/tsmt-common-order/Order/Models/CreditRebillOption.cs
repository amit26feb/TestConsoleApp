// <copyright file="CreditRebillOption.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   ///  Credit rebill option model
   /// </summary>
   public class CreditRebillOption
   {
      /// <summary>
      /// Gets or sets change order guid
      /// </summary>
      public string ChangeOrderGuid { get; set; }

      /// <summary>
      /// Gets or sets work flow note
      /// </summary>
      public string WorkflowNote { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether required to credit all invoices
      /// </summary>
      public bool IsRequiredCreditAllInvoices { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether required to deliver credit memos
      /// </summary>
      public bool IsRequiredDeliverCreditMemos { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether required to deliver new invoices
      /// </summary>
      public bool IsRequiredDeliverNewInvoices { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether required to credit and rebill
      /// </summary>
      public bool IsRequiredCreditRebill { get; set; }

      /// <summary>
      /// Gets or sets credit reason code
      /// </summary>
      public string CreditReasonCode { get; set; }

      /// <summary>
      /// Gets or sets credit job info
      /// </summary>
      public CreditRebillCreditJobInfo CreditJobInfo { get; set; }

      /// <summary>
      /// Gets or sets change order info
      /// </summary>
      public CreditRebillChangeOrderInfo ChangeOrderInfo { get; set; }

      /// <summary>
      /// Gets or sets invoice map
      /// </summary>
      public InvoiceMap InvoiceMap { get; set; }

      /// <summary>
      /// Gets or sets created by
      /// </summary>
      public string CreatedBy { get; set; }

      /// <summary>
      /// Gets or sets modified by
      /// </summary>
      public string ModifiedBy { get; set; }

      /// <summary>
      /// Gets or sets created date time in utc
      /// </summary>
      public DateTime CreatedDateTimeUtc { get; set; }

      /// <summary>
      /// Gets or sets modified date time in utc
      /// </summary>
      public DateTime? ModifiedDateTimeUtc { get; set; }
   }
}
