// <copyright file="ShipmentDetail.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   /// Shipment detail model
   /// </summary>
   public class ShipmentDetail
   {
      /// <summary>
      /// Gets or sets invoice number
      /// </summary>
      public string InvoiceNumber { get; set; }

      /// <summary>
      /// Gets or sets invoice date
      /// </summary>
      public DateTime? InvoiceDateUtc { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int SalesOrderId { get; set; }

      /// <summary>
      /// Gets or sets sales order number
      /// </summary>
      public string SalesOrderNumber { get; set; }

      /// <summary>
      /// Gets or sets planned shipment number
      /// </summary>
      public string PlannedShipmentNumber { get; set; }

      /// <summary>
      /// Gets or sets pretax amount
      /// </summary>
      public decimal? PreTaxAmount { get; set; }

      /// <summary>
      /// Gets or sets tax amount
      /// </summary>
      public decimal? TaxAmount { get; set; }

      /// <summary>
      /// Gets or sets invoice amount
      /// </summary>
      public decimal? InvoiceAmount { get; set; }

      /// <summary>
      /// Gets or sets invoice status
      /// </summary>
      public string InvoiceStatus { get; set; }
   }
}
