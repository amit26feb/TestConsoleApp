// <copyright file="OnlineCommissionSplitDefinition.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
    using System;

   /// <summary>
   /// Represents data model for online commission split definition. The model represents the table COMM_SPLIT_DEF in ES and TS databases.
   /// </summary>
   public class OnlineCommissionSplitDefinition
    {
        /// <summary>
        /// Gets or sets split ID
        /// </summary>
        public int SPLIT_ID { get; set; }

        /// <summary>
        /// Gets or sets sales office ID
        /// </summary>
        public int SALES_OFFICE_ID { get; set; }

        /// <summary>
        /// Gets or sets comm code
        /// </summary>
        public string COMM_CODE { get; set; }

        /// <summary>
        /// Gets or sets commission percent
        /// </summary>
        public decimal COMM_PCT { get; set; }

        /// <summary>
        /// Gets or sets split create date
        /// </summary>
        public DateTime? CREATED_DATE { get; set; }

        /// <summary>
        /// Gets or sets user that has created the split
        /// </summary>
        public string CREATED_BY { get; set; }

        /// <summary>
        /// Gets or sets split updated date
        /// </summary>
        public DateTime? UPDATED_DATE { get; set; }

        /// <summary>
        /// Gets or sets user that has updated the split
        /// </summary>
        public string UPDATED_BY { get; set; }

        /// <summary>
        /// Gets or sets transmit indicator
        /// </summary>
        public string TRANSMIT_IND { get; set; }
    }
}
