// <copyright file="ChangeOrder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace Order.Models
{
    using TSMT.DataAccess;

   /// <summary>
   /// Model for change order
   /// </summary>
   public class ChangeOrder : IDataEntity
   {
      /// <summary>
      /// Gets or sets CO_ID
      /// </summary>
      public int CO_ID { get; set; }

      /// <summary>
      /// Gets or sets CHANGE_TYPE
      /// </summary>
      public string CHANGE_TYPE { get; set; }

      /// <summary>
      /// Gets or sets ATTRIBUTE_CHANGED
      /// </summary>
      public string ATTRIBUTE_CHANGED { get; set; }

      /// <summary>
      /// Gets or sets BEFORE_VALUE
      /// </summary>
      public string BEFORE_VALUE { get; set; }

      /// <summary>
      /// Gets or sets AFTER_VALUE
      /// </summary>
      public string AFTER_VALUE { get; set; }
   }
}
