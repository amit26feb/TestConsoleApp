// <copyright file="CustomerPurchaseDocument.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using System;

   /// <summary>
   /// Model for customer purchase document
   /// </summary>
   public class CustomerPurchaseDocument
   {
      /// <summary>
      /// Gets or sets CREDIT_JOB_ID
      /// </summary>
      public int CREDIT_JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets PO_NBR
      /// </summary>
      public string PO_NBR { get; set; }

      /// <summary>
      /// Gets or sets SPA_NUMBER
      /// </summary>
      public string SPA_NUMBER { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_TERM_ID
      /// </summary>
      public string CREDIT_TERM_ID { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_TERM_DESCR
      /// </summary>
      public string CREDIT_TERM_DESCR { get; set; }

      /// <summary>
      /// Gets or sets FREIGHT_TERM_CD
      /// </summary>
      public string FREIGHT_TERM_CD { get; set; }

      /// <summary>
      /// Gets or sets TAX_INCLUDED
      /// </summary>
      public char TAX_INCLUDED { get; set; }

      /// <summary>
      /// Gets or sets CUST_EXEMPTION_IND
      /// </summary>
      public char CUST_EXEMPTION_IND { get; set; }

      /// <summary>
      /// Gets or sets ORIG_PO_AMT
      /// </summary>
      public decimal ORIG_PO_AMT { get; set; }

      /// <summary>
      /// Gets or sets AD_AMOUNT
      /// </summary>
      public decimal AD_AMOUNT { get; set; }

      /// <summary>
      /// Gets or sets TAX_AMT
      /// </summary>
      public decimal? TAX_AMT { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_DECISION_TYPE_ID
      /// </summary>
      public int CREDIT_DECISION_TYPE_ID { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_DECISION_TYPE_DESCR
      /// </summary>
      public string CREDIT_DECISION_TYPE_DESCR { get; set; }

      /// <summary>
      /// Gets or sets INVOICE_TYPE
      /// </summary>
      public string INVOICE_TYPE { get; set; }

      /// <summary>
      /// Gets or sets BILLING_METHOD
      /// </summary>
      public string BILLING_METHOD { get; set; }

      /// <summary>
      /// Gets or sets PAYMENT_TERM_ID
      /// </summary>
      public string PAYMENT_TERM_ID { get; set; }

      /// <summary>
      /// Gets or sets PAYMENT_TERM_DESCR
      /// </summary>
      public string PAYMENT_TERM_DESCR { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO
      /// </summary>
      public string SOLD_TO { get; set; }

      /// <summary>
      /// Gets or sets REALWORLD_ACCT_NO
      /// </summary>
      public string REALWORLD_ACCT_NO { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_NAME
      /// </summary>
      public string SOLD_TO_NAME { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_STREET_ADDRESS_1
      /// </summary>
      public string SOLD_TO_STREET_ADDRESS_1 { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_STREET_ADDRESS_2
      /// </summary>
      public string SOLD_TO_STREET_ADDRESS_2 { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_CITY
      /// </summary>
      public string SOLD_TO_CITY { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_COUNTRY
      /// </summary>
      public string SOLD_TO_COUNTRY { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_STATE
      /// </summary>
      public string SOLD_TO_STATE { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_ZIP_CODE
      /// </summary>
      public string SOLD_TO_ZIP_CODE { get; set; }

      /// <summary>
      /// Gets or sets COMPLETE_DATE
      /// </summary>
      public DateTime? COMPLETE_DATE { get; set; }

      /// <summary>
      /// Gets or sets DATE_CREATED
      /// </summary>
      public DateTime? DATE_CREATED { get; set; }

      /// <summary>
      /// Gets or sets project manager name.
      /// </summary>
      public string PROJECT_MGR { get; set; }

      /// <summary>
      /// Gets or sets DATE_PO_APPROVED
      /// </summary>
      public DateTime? DATE_PO_APPROVED { get; set; }

      /// <summary>
      /// Gets or sets SOLD_TO_CUST_CHANNEL
      /// </summary>
      public string SOLD_TO_CUST_CHANNEL { get; set; }

      /// <summary>
      /// Gets or sets R12_PARTY_NO
      /// </summary>
      public long? R12_PARTY_NO { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_ID
      /// </summary>
      public int SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets ORACLE_PROJECT_IND
      /// </summary>
      public char? ORACLE_PROJECT_IND { get; set; }

      /// <summary>
      /// Gets or sets CUST_CREDIT_CATG_CODE
      /// </summary>
      public string CUST_CREDIT_CATG_CODE { get; set; }

      /// <summary>
      /// Gets or sets INVOICE_DELIVERY_EMAIL
      /// </summary>
      public string INVOICE_DELIVERY_EMAIL { get; set; }

      /// <summary>
      /// Gets or sets PROJECT_COMPLETION_DATE
      /// </summary>
      public DateTime? PROJECT_COMPLETION_DATE { get; set; }

      /// <summary>
      /// Gets or sets PROTECTION_TYPE
      /// </summary>
      public string PROTECTION_TYPE { get; set; }

      /// <summary>
      /// Gets or sets ZIP_PLUS
      /// </summary>
      public string ZIP_PLUS { get; set; }

      /// <summary>
      /// Gets or sets SPECIAL_INSTRUCTIONS
      /// </summary>
      public string SPECIAL_INSTRUCTIONS { get; set; }

      /// <summary>
      /// Gets or sets INTERNAL_NOTES
      /// </summary>
      public string INTERNAL_NOTES { get; set; }

      /// <summary>
      /// Gets or sets CREDIT_DECISION_STATUS_CODE
      /// </summary>
      public string CREDIT_DECISION_STATUS_CODE { get; set; }

      /// <summary>
      /// Gets or sets override invoice delivery.
      /// </summary>
      public char OVERRIDE_INVOICE_DELIVERY { get; set; }
   }
}
