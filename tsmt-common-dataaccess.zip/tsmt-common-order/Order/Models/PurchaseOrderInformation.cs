// <copyright file="PurchaseOrderInformation.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for purchase order information
   /// </summary>
   public class PurchaseOrderInformation : IDataEntity
   {
      /// <summary>
      /// Gets or sets legacy job number
      /// </summary>
      public string LEGACY_JOB_NBR { get; set; }

      /// <summary>
      /// Gets or sets credit job name
      /// </summary>
      public string CREDIT_JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets po number
      /// </summary>
      public string PO_NBR { get; set; }

      /// <summary>
      /// Gets or sets bid name
      /// </summary>
      public string BID_NAME { get; set; }

      /// <summary>
      /// Gets or sets orig po amount
      /// </summary>
      public decimal ORIG_PO_AMT { get; set; }

      /// <summary>
      /// Gets or sets total addendum amount
      /// </summary>
      public decimal? TOTAL_ADDENDUM_AMT { get; set; }

      /// <summary>
      /// Gets or sets job name
      /// </summary>
      public string JOB_NAME { get; set; }

      /// <summary>
      /// Gets or sets planned shipment contract id
      /// </summary>
      public string PS_CONTRACT_ID { get; set; }
   }
}
