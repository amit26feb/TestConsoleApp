// <copyright file="CreditJobNote.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for credit job note
   /// </summary>
   public class CreditJobNote
   {
      /// <summary>
      /// Gets or sets NOTE_ID
      /// </summary>
      public int NOTE_ID { get; set; }

      /// <summary>
      /// Gets or sets NOTE_TEXT
      /// </summary>
      public string NOTE_TEXT { get; set; }
   }
}
