// <copyright file="SalesOrderLockApplication.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Sales order locked by which application information
   /// </summary>
   public class SalesOrderLockApplication
   {
      /// <summary>
      /// Gets or sets LOCK_APPLICATION
      /// </summary>
      public string LOCK_APPLICATION { get; set; }

      /// <summary>
      /// Gets or sets SALES_ORD_ID
      /// </summary>
      public int SALES_ORD_ID { get; set; }
   }
}
