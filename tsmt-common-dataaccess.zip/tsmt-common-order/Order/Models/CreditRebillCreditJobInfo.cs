// <copyright file="CreditRebillCreditJobInfo.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Class for credit rebill credit job info
   /// </summary>
   public class CreditRebillCreditJobInfo
   {
      /// <summary>
      /// Gets or sets credit job id
      /// </summary>
      public int CreditJobId { get; set; }

      /// <summary>
      /// Gets or sets hqtr credit job id
      /// </summary>
      public int? HqtrCreditJobId { get; set; }
   }
}
