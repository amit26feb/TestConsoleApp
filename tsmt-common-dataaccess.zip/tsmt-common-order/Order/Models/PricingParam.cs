// <copyright file="PricingParam.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Model for PricingParam
   /// </summary>
   public class PricingParam : IDataEntity
   {
      /// <summary>
      /// Gets or sets SELECTION_ID
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets SELECTED_PRICING_PARM_ID
      /// </summary>
      public int SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets HQTR_SELECTED_PRICING_PARM_ID
      /// </summary>
      public int? HQTR_SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets auth comm rate
      /// </summary>
      public decimal? AUTH_COMM_RATE { get; set; }

      /// <summary>
      /// Gets or sets base freight reserve rate
      /// </summary>
      public decimal? BASE_FREIGHT_RESERVE_RATE { get; set; }
   }
}
