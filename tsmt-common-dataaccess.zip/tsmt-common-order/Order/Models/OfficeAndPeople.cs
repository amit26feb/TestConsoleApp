// <copyright file="OfficeAndPeople.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace Order.Models
{
   /// <summary>
   /// Model for office and people
   /// </summary>
   public class OfficeAndPeople
   {
      /// <summary>
      /// Gets or sets SALES_OFFICE_NAME
      /// </summary>
      public string SALES_OFFICE_NAME { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_ID
      /// </summary>
      public int SALES_OFFICE_ID { get; set; }

      /// <summary>
      /// Gets or sets SALES_OFFICE_CODE
      /// </summary>
      public string SALES_OFFICE_CODE { get; set; }

      /// <summary>
      /// Gets or sets COUNTRY
      /// </summary>
      public string COUNTRY { get; set; }

      /// <summary>
      /// Gets or sets STATUS
      /// </summary>
      public string STATUS { get; set; }

      /// <summary>
      /// Gets or sets LOCATION_OFFICE
      /// </summary>
      public int LOCATION_OFFICE { get; set; }

      /// <summary>
      /// Gets or sets NAME
      /// </summary>
      public string NAME { get; set; }

      /// <summary>
      /// Gets or sets JOB_CONTACT
      /// </summary>
      public string JOB_CONTACT { get; set; }

      /// <summary>
      /// Gets or sets MGR_CONTACT
      /// </summary>
      public string MGR_CONTACT { get; set; }

      /// <summary>
      /// Gets or sets NAME_FIRST
      /// </summary>
      public string NAME_FIRST { get; set; }

      /// <summary>
      /// Gets or sets NAME_LAST
      /// </summary>
      public string NAME_LAST { get; set; }

      /// <summary>
      /// Gets or sets COMM_CODE
      /// </summary>
      public string COMM_CODE { get; set; }

      /// <summary>
      /// Gets or sets PROJECT_MGR
      /// </summary>
      public string PROJECT_MGR { get; set; }

      /// <summary>
      /// Gets or sets JOB_ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets BU_MFG_LOC_ID
      /// </summary>
      public int? BU_MFG_LOC_ID { get; set; }

      /// <summary>
      /// Gets or sets CHG_ALLOWED_IND (Possible CHG_ALLOWED_IND values are 'Y', 'R', 'N')
      /// </summary>
      public char CHG_ALLOWED_IND { get; set; }

      /// <summary>
      /// Gets or sets PROJECT_MGR_USERID
      /// </summary>
      public string PROJECT_MGR_USERID { get; set; }
   }
}
