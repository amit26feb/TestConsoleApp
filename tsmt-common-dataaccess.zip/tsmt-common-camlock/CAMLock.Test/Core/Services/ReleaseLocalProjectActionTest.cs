// <copyright file="ReleaseLocalProjectActionTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class ReleaseLocalProjectActionTest
    {
        private readonly ReleaseLocalProjectAction releaseLocalProjectAction;
        private readonly Mock<IReleaseServiceFactory> releaseServiceFactoryMock;
        private readonly Mock<IReleaseService> releaseServiceMock;
        private CamData camData;
        private LockStatus lockStatus;


        /// <summary>
        /// Initializes a new instance of the <see cref="ReleaseLocalProjectActionTest"/> class.
        /// Constructor.
        /// </summary>
        public ReleaseLocalProjectActionTest()
        {

            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.releaseServiceMock = new Mock<IReleaseService>();
            this.releaseServiceFactoryMock = new Mock<IReleaseServiceFactory>();
            this.releaseServiceFactoryMock.Setup(x => x.GetReleaseServiceInstance(ReleaseService.LocalProjectReleaseService)).Returns(this.releaseServiceMock.Object);
            this.releaseLocalProjectAction = new ReleaseLocalProjectAction(this.releaseServiceFactoryMock.Object);
        }

        [Fact]
        public async Task ExecuteAction_ReleaseIsIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.releaseServiceMock.Setup(x => x.Release(It.IsAny<CamData>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.releaseLocalProjectAction.ExecuteAction(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.releaseServiceMock.Verify(x => x.Release(this.camData), Times.Once);
        }
    }
}

