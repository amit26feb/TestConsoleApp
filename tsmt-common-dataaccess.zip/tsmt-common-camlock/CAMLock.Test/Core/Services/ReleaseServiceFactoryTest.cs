namespace CAMLock.Test.Core.Services
{
    using System.Collections.Generic;
    using Moq;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class ReleaseServiceFactoryTest
    {
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private readonly Mock<IJobApiClient> jobApiClientMock;
        private readonly ReleaseServiceFactory releaseServiceFactory;
        private readonly IEnumerable<IReleaseService> releaseServices;
        private readonly IReleaseService localReleaseService;
        private readonly IReleaseService localJobReleaseService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReleaseServiceFactoryTest"/> class.
        /// Constructor.
        /// </summary>
        public ReleaseServiceFactoryTest()
        {
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.jobApiClientMock = new Mock<IJobApiClient>();
            this.localReleaseService = new LocalReleaseService(this.jobApiClientMock.Object, this.orderingApiClientMock.Object);
            this.localJobReleaseService = new LocalJobReleaseService(this.jobApiClientMock.Object);
            this.releaseServices = new List<IReleaseService>()
            {
                this.localJobReleaseService,
                this.localReleaseService
            };

            this.releaseServiceFactory = new ReleaseServiceFactory(this.releaseServices);
        }

        [Fact]
        public void GetReleaseService_LocalReleaseServiceIsImplemented_ReturnsLocalReleaseService()
        {
            // Act
            var actualResult = this.releaseServiceFactory.GetReleaseServiceInstance(ReleaseService.LocalReleaseService);

            // Assert
            Assert.Equal(ReleaseService.LocalReleaseService, actualResult.ReleaseService);
        }

        [Fact]
        public void GetReleaseService_LocalJobReleaseServiceIsImplemented_ReturnsLocalJobReleaseService()
        {
            // Act
            var actualResult = this.releaseServiceFactory.GetReleaseServiceInstance(ReleaseService.LocalJobRelaseService);

            // Assert
            Assert.Equal(ReleaseService.LocalJobRelaseService, actualResult.ReleaseService);
        }
    }
}

