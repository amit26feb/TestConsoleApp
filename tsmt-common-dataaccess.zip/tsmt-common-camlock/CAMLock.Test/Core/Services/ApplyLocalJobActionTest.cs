// <copyright file="ApplyLocalJobActionTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class ApplyLocalJobActionTest
    {
        private readonly ApplyLocalJobAction applyLocalJobAction;
        private readonly Mock<ILockServiceFactory> lockServiceFactoryMock;
        private readonly Mock<ILockService> lockServiceMock;
        private CamData camData;
        private LockStatus lockStatus;


        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyLocalJobActionTest"/> class.
        /// Constructor.
        /// </summary>
        public ApplyLocalJobActionTest()
        {

            this.lockStatus = new LockStatus() { IsSuccessful = true};
            this.camData = Helper.GetCamData();
            this.lockServiceMock = new Mock<ILockService>();
            this.lockServiceFactoryMock = new Mock<ILockServiceFactory>();
            this.lockServiceFactoryMock.Setup(x => x.GetLockServiceInstance(LockService.LocalJobLockService)).Returns(this.lockServiceMock.Object);
            this.applyLocalJobAction = new ApplyLocalJobAction(this.lockServiceFactoryMock.Object);
        }

        [Fact]
        public async Task ExecuteAction_LockIsIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.lockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.applyLocalJobAction.ExecuteAction(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.lockServiceMock.Verify(x => x.Lock(this.camData), Times.Once);
        }
    }
}
