// <copyright file="LocalLockServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class LocalReleaseServiceTest
    {
        private readonly LocalReleaseService localReleaseService;
        private readonly Mock<IJobApiClient> jobApiClientMock;
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private CamData camData;
        private LockStatus jobLockStatus;
        private LockStatus creditJobStatus;
        private CreditJobLockInput creditJobLockInput;

        public LocalReleaseServiceTest()
        {
            this.jobLockStatus = new LockStatus() { IsSuccessful = true };
            this.creditJobStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.creditJobLockInput = new CreditJobLockInput()
            {
                AllowLockOverride = false,
                DrAddressId = this.camData.DrAddressId,
                UserId = this.camData.UserId,
                CreditJobId = this.camData.LocalLock.CreditProjectLocks.First().CreditJobId
            };

            this.jobApiClientMock = new Mock<IJobApiClient>();
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.localReleaseService = new LocalReleaseService(this.jobApiClientMock.Object, this.orderingApiClientMock.Object);
        }

        [Fact]
        public async Task Release_ReleaseIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.creditJobStatus));

            // Act
            var actualResult = await this.localReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Release_JobReleaseFails_DoNotReleaseCreditJob()
        {
            // Arrange
            this.jobLockStatus.IsSuccessful = false;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));

            // Act
            var actualResult = await this.localReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_JobReleaseConflicts_DoNotReleaseCreditJob()
        {
            // Arrange
            this.jobLockStatus = new LockStatus() { IsSuccessful = false };
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));

            // Act
            var actualResult = await this.localReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_CreditJobReleaseFails_LockJob()
        {
            // Arrange
            this.creditJobStatus.IsSuccessful = false;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.creditJobStatus));

            // Act
            var actualResult = await this.localReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Release_CreditJobReleaseSuccess_ReleaseJob()
        {
            // Arrange
            this.creditJobStatus.IsSuccessful = true;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.creditJobStatus));

            // Act
            var actualResult = await this.localReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Once);
        }
    }
}
