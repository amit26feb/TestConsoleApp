// <copyright file="HostReleaseServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    /// <summary>
    /// Host release service test
    /// </summary>
    public class HostReleaseServiceTest
    {
        private readonly HostReleaseService hostReleaseService;
        private readonly Mock<IOrderApiClient> orderApiClientMock;
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="HostReleaseServiceTest"/> class.
        /// </summary>
        public HostReleaseServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.orderApiClientMock = new Mock<IOrderApiClient>();
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.hostReleaseService = new HostReleaseService(this.orderApiClientMock.Object, this.orderingApiClientMock.Object);
        }

        [Fact]
        public async Task Release_ReleaseCreditProjectLockFalied_ReturnsFailureStatus()
        {
            // Arrange
            this.camData.LocalLock = null;
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.ReleaseCreditJobLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ReleaseCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.ReleaseSalesOrderLock(It.IsAny<int>()), Times.Never);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_ReleaseSalesOrderLockFalied_ReturnsFailureStatus()
        {
            // Arrange
            this.camData.LocalLock = null;
            this.orderApiClientMock.Setup(x => x.ReleaseCreditJobLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.ReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ReleaseCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.ReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_JobReleaseLockFalied_ReturnsFailureStatus()
        {
            // Arrange
            this.camData.LocalLock = null;
            this.orderApiClientMock.Setup(x => x.ReleaseCreditJobLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.ReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ReleaseCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.ReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_JobReleaseLockFaliedWithLocalLockData_ReturnsFailureStatus()
        {
            // Arrange
            this.orderApiClientMock.Setup(x => x.ReleaseCreditJobLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.ReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ReleaseCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.ReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_AllReleaseLockSuccessHasNoLocalLockData_ReturnsSuccessStatus()
        {
            // Arrange
            this.camData.LocalLock = null;
            this.orderApiClientMock.Setup(x => x.ReleaseCreditJobLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.ReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ReleaseCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.ReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_AllReleaseLockSuccessHasLocalLockData_ReturnsSuccessStatus()
        {
            // Arrange
            this.orderApiClientMock.Setup(x => x.ReleaseCreditJobLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.ReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ReleaseCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.ReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Once);
        }
    }
}
