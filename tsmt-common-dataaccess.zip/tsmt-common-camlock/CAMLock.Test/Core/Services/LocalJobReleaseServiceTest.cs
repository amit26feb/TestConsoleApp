// <copyright file="LocalJobReleaseServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class LocalJobReleaseServiceTest
    {
        private readonly LocalJobReleaseService localJobReleaseService;
        private readonly Mock<IJobApiClient> jobApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalJobReleaseServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public LocalJobReleaseServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.jobApiClientMock = new Mock<IJobApiClient>();
            this.localJobReleaseService = new LocalJobReleaseService(this.jobApiClientMock.Object);
        }

        [Fact]
        public async Task Release_ReleaseIsIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localJobReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
        }

        [Fact]
        public async Task Release_ReleaseIsDenied_ReturnsFailureStatus()
        {
            // Arrange
            this.lockStatus.IsSuccessful = false;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localJobReleaseService.Release(camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
        }

        [Fact]
        public async Task Release_ReleaseIsConflict_ReturnsFailureStatus()
        {
            // Arrange
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localJobReleaseService.Release(camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
        }
    }
}
