// <copyright file="HostTransmitReleaseServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    /// <summary>
    /// Host transmit release service test
    /// </summary>
    public class HostTransmitReleaseServiceTest
    {
        private readonly HostTransmitReleaseService hostTransmitReleaseService;
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private readonly Mock<IOrderApiClient> orderApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalProjectReleaseServiceTest"/> class.
        /// </summary>
        public HostTransmitReleaseServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.orderApiClientMock = new Mock<IOrderApiClient>();
            this.hostTransmitReleaseService = new HostTransmitReleaseService(this.orderingApiClientMock.Object, this.orderApiClientMock.Object);
        }

        [Fact]
        public async Task Release_ResetCreditProjectLockFalied_ReturnsFailureStatus()
        {
            // Arrange
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()), Times.Never);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_TransmitReleaseLockFalied_ReturnsFailureStatus()
        {
            // Arrange
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_JobReleaseLockFalied_ReturnsFailureStatus()
        {
            // Arrange
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_RemnantLockReleaseFalied_ReturnsFailureStatus()
        {
            // Arrange
            this.camData.LocalLock.CreditProjectLocks.ElementAt(0).HqtrCreditJobId = 26753;
            this.camData.HostLock.CreditProjectLocks.ElementAt(0).LockedApplication = "testApp1";
            this.camData.HostLock.CreditProjectLocks.ElementAt(0).LockUserId = "SERVER";
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Release_RemnantLockReleaseSuccess_ReturnsSuccessStatus()
        {
            // Arrange
            this.camData.LocalLock.CreditProjectLocks.ElementAt(0).HqtrCreditJobId = 26753;
            this.camData.HostLock.CreditProjectLocks.ElementAt(0).LockedApplication = "testApp";
            this.camData.HostLock.CreditProjectLocks.ElementAt(0).LockUserId = "SERVER";
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(false, It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Release_ReleaseSuccessWithoutRemnant_ReturnsSuccessStatus()
        {
            // Arrange
            this.camData.LocalLock.CreditProjectLocks.ElementAt(0).HqtrCreditJobId = 0;
            this.camData.HostLock.CreditProjectLocks.ElementAt(0).LockedApplication = "FOE";
            this.camData.HostLock.CreditProjectLocks.ElementAt(0).LockUserId = "dummy";
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_ReleaseSuccessWithoutLocalCreditProject_ReturnsSuccessStatus()
        {
            // Arrange
            this.camData.LocalLock.CreditProjectLocks = null;
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Release_ReleaseSuccessWithEmptyLocalCreditProject_ReturnsSuccessStatus()
        {
            // Arrange
            this.camData.LocalLock.CreditProjectLocks = new List<CreditProjectLock>();
            this.orderApiClientMock.Setup(x => x.ResetHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.TransmitReleaseSalesOrderLock(It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostTransmitReleaseService.Release(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ResetHostLock(It.IsAny<HostLockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.Is<LockInput>(y => (bool)y.GetType().GetProperty("AllowLockOverride").GetValue(y) == true)), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }
    }
}
