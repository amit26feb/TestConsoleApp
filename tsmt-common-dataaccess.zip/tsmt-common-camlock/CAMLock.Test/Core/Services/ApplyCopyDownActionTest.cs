// <copyright file="ApplyCopyDownLockTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class ApplyCopyDownActionTest
    {
        private readonly ApplyCopyDownAction applyCopyDownLock;
        private readonly Mock<ILockServiceFactory> lockServiceFactoryMock;
        private readonly Mock<ILockService> localLockServiceMock;
        private readonly Mock<ILockService> hostLockServiceMock;
        private CamData camData;
        private LockStatus jobLockStatus;
        private LockStatus hostLockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyCopyDownActionTest"/> class.
        /// Constructor.
        /// </summary>
        public ApplyCopyDownActionTest()
        {
            this.camData = Helper.GetCamData();
            this.jobLockStatus = new LockStatus() { IsSuccessful = false, Messages = new List<string>() { "sample test" } };
            this.hostLockStatus = new LockStatus() { IsSuccessful = false, Messages = new List<string>() { "sample test" } };
            this.lockServiceFactoryMock = new Mock<ILockServiceFactory>();
            this.localLockServiceMock = new Mock<ILockService>();
            this.hostLockServiceMock = new Mock<ILockService>();
            this.lockServiceFactoryMock.Setup(x => x.GetLockServiceInstance(LockService.LocalJobLockService)).Returns(this.localLockServiceMock.Object);
            this.lockServiceFactoryMock.Setup(x => x.GetLockServiceInstance(LockService.HostLockService)).Returns(this.hostLockServiceMock.Object);            
            this.applyCopyDownLock = new ApplyCopyDownAction(this.lockServiceFactoryMock.Object);
        }

        [Fact]
        public async Task ExecuteAction_LockIsIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.jobLockStatus.IsSuccessful = true;
            this.hostLockStatus.IsSuccessful = true;
            this.localLockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>())).Returns(Task.FromResult(this.jobLockStatus));
            this.hostLockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>())).Returns(Task.FromResult(this.hostLockStatus));

            // Act
            var actualResult = await this.applyCopyDownLock.ExecuteAction(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.localLockServiceMock.Verify(x => x.Lock(this.camData), Times.Once);
            this.hostLockServiceMock.Verify(x => x.Lock(this.camData), Times.Once);
        }

        [Fact]
        public async Task ExecuteAction_JobLockFails_DoNotLockHost()
        {
            // Arrange            
            this.hostLockStatus.IsSuccessful = true;
            this.localLockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>())).Returns(Task.FromResult(this.jobLockStatus));
            this.hostLockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>())).Returns(Task.FromResult(this.hostLockStatus));

            // Act
            var actualResult = await this.applyCopyDownLock.ExecuteAction(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.localLockServiceMock.Verify(x => x.Lock(this.camData), Times.Once);
            this.hostLockServiceMock.Verify(x => x.Lock(this.camData), Times.Never);
        }

        [Fact]
        public async Task ExecuteAction_JobLocksHostFails_ReturnFailureStatus()
        {
            // Arrange            
            this.jobLockStatus.IsSuccessful = true;
            this.localLockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>())).Returns(Task.FromResult(this.jobLockStatus));
            this.hostLockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>())).Returns(Task.FromResult(this.hostLockStatus));

            // Act
            var actualResult = await this.applyCopyDownLock.ExecuteAction(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.localLockServiceMock.Verify(x => x.Lock(this.camData), Times.Once);
            this.hostLockServiceMock.Verify(x => x.Lock(this.camData), Times.Once);
        }
    }
}
