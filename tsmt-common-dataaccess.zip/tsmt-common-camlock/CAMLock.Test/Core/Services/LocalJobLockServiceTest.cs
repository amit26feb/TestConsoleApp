// <copyright file="LocalJobLockServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class LocalJobLockServiceTest
    {
        private readonly LocalJobLockService localJobLockService;
        private readonly Mock<IJobApiClient> jobApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalJobLockServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public LocalJobLockServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.jobApiClientMock = new Mock<IJobApiClient>();
            this.localJobLockService = new LocalJobLockService(this.jobApiClientMock.Object);
        }

        [Fact]
        public async Task Lock_LockIsIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localJobLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_LockIsDenied_ReturnsFailureStatus()
        {
            // Arrange
            this.lockStatus.IsSuccessful = false;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localJobLockService.Lock(camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_LockIsConflict_ReturnsFailureStatus()
        {
            // Arrange
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localJobLockService.Lock(camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
        }
    }
}
