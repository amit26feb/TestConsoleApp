// <copyright file="ReleaseHostTransmitActionTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    /// <summary>
    /// Release host transmit action test
    /// </summary>
    public class ReleaseHostTransmitActionTest
    {
        private readonly ReleaseHostTransmitAction releaseHostTransmitAction;
        private readonly Mock<IReleaseServiceFactory> releaseServiceFactoryMock;
        private readonly Mock<IReleaseService> releaseServiceMock;
        private CamData camData;
        private LockStatus lockStatus;


        /// <summary>
        /// Initializes a new instance of the <see cref="ReleaseLocalActionTest"/> class.
        /// Constructor.
        /// </summary>
        public ReleaseHostTransmitActionTest()
        {

            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.releaseServiceMock = new Mock<IReleaseService>();
            this.releaseServiceFactoryMock = new Mock<IReleaseServiceFactory>();
            this.releaseServiceFactoryMock.Setup(x => x.GetReleaseServiceInstance(ReleaseService.HostTransmitReleaseService)).Returns(this.releaseServiceMock.Object);
            this.releaseHostTransmitAction = new ReleaseHostTransmitAction(this.releaseServiceFactoryMock.Object);
        }

        [Fact]
        public async Task ExecuteAction_ReleaseHostTransmitSuccess_ReturnsSuccessStatus()
        {
            // Arrange
            this.releaseServiceMock.Setup(x => x.Release(It.IsAny<CamData>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.releaseHostTransmitAction.ExecuteAction(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.releaseServiceMock.Verify(x => x.Release(this.camData), Times.Once);
        }
    }
}
