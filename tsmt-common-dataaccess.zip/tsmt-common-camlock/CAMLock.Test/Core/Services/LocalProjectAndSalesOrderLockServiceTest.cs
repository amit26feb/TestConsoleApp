// <copyright file="LocalProjectAndSalesOrderLockServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    /// <summary>
    /// Local project and sales order lock service test
    /// </summary>
    public class LocalProjectAndSalesOrderLockServiceTest
    {
        private readonly LocalProjectAndSalesOrderLockService localProjectAndSalesOrderReleaseService;
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalProjectReleaseServiceTest"/> class.
        /// </summary>
        public LocalProjectAndSalesOrderLockServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.localProjectAndSalesOrderReleaseService = new LocalProjectAndSalesOrderLockService(this.orderingApiClientMock.Object);
        }

        [Fact]
        public async Task Lock_CreditJobLockFalied_ReturnsLockFailedStatus()
        {
            // Arrange
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localProjectAndSalesOrderReleaseService.Lock(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
            this.orderingApiClientMock.Verify(x => x.SalesOrderLock(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task Lock_SalesOrderLockFalied_ReturnsLockFailedStatus()
        {
            // Arrange
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderingApiClientMock.Setup(x => x.SalesOrderLock(It.IsAny<int>(), It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localProjectAndSalesOrderReleaseService.Lock(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
            this.orderingApiClientMock.Verify(x => x.SalesOrderLock(
                this.camData.DrAddressId,
                this.camData.LocalLock.CreditProjectLocks.First().CreditJobId), Times.Once);
        }

        [Fact]
        public async Task Lock_CreditJobAndSalesOrderLockSuccess_ReturnsLockSuccessStatus()
        {
            // Arrange
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderingApiClientMock.Setup(x => x.SalesOrderLock(It.IsAny<int>(), It.IsAny<int>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localProjectAndSalesOrderReleaseService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
            this.orderingApiClientMock.Verify(x => x.SalesOrderLock(
                this.camData.DrAddressId,
                this.camData.LocalLock.CreditProjectLocks.First().CreditJobId), Times.Once);
        }
    }
}
