// <copyright file="ActionFactoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Collections.Generic;
    using Moq;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;
    
    public class ActionFactoryTest
    {
        private readonly ActionFactory actionFactory;
        private readonly IEnumerable<IAction> actionsMock;
        private readonly IAction applyHostLock;
        private readonly IAction applyLocalJobLock;
        private readonly Mock<ILockServiceFactory> lockServiceFactoryMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="ActionFactoryTest"/> class.
        /// Constructor.
        /// </summary>
        public ActionFactoryTest()
        {
            this.lockServiceFactoryMock = new Mock<ILockServiceFactory>();
            this.applyHostLock = new ApplyHostAction(this.lockServiceFactoryMock.Object);
            this.applyLocalJobLock = new ApplyLocalJobAction(this.lockServiceFactoryMock.Object);            
            this.actionsMock = new List<IAction>()
            {
                this.applyHostLock,
                this.applyLocalJobLock
            };

            this.actionFactory = new ActionFactory(this.actionsMock);
        }

        [Fact]
        public void GetAction_ApplyHostLockIsImplemented_ReturnsApplyHostLock()
        {
            // Act
            var actualResult = this.actionFactory.GetActionInstance(ActionType.ApplyHostAction);

            // Assert
            Assert.Equal(ActionType.ApplyHostAction, actualResult.ActionType);
        }

        [Fact]
        public void GetAction_ApplyLocalJobLockIsImplemented_ReturnsApplyLocalJobLock()
        {
            // Act
            var actualResult = this.actionFactory.GetActionInstance(ActionType.ApplyLocalJobAction);

            // Assert
            Assert.Equal(ActionType.ApplyLocalJobAction, actualResult.ActionType);
        }            
    }
}
