// <copyright file="LocalLockServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class LocalLockServiceTest
    {
        private readonly LocalLockService localLockService;
        private readonly Mock<IJobApiClient> jobApiClientMock;
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private CamData camData;
        private LockStatus jobLockStatus;
        private LockStatus creditJobLockStatus;
        private CreditJobLockInput creditJobLockInput;

        public LocalLockServiceTest()
        {
            this.jobLockStatus = new LockStatus() { IsSuccessful = true };
            this.creditJobLockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.creditJobLockInput = new CreditJobLockInput()
            {
                AllowLockOverride = false,
                DrAddressId = this.camData.DrAddressId,
                UserId = this.camData.UserId,
                CreditJobId = this.camData.LocalLock.CreditProjectLocks.First().CreditJobId
            };

            this.jobApiClientMock = new Mock<IJobApiClient>();
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.localLockService = new LocalLockService(this.jobApiClientMock.Object, this.orderingApiClientMock.Object);
        }

        [Fact]
        public async Task Lock_AllLocksIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.creditJobLockStatus));

            // Act
            var actualResult = await this.localLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true,It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_JobLockFails_DoNotLockCreditJob()
        {
            // Arrange
            this.jobLockStatus.IsSuccessful = false;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));

            // Act
            var actualResult = await this.localLockService.Lock(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Lock_JobLockConflicts_DoNotLockCreditJob()
        {
            // Arrange
            this.jobLockStatus = new LockStatus() { IsSuccessful = false };
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));

            // Act
            var actualResult = await this.localLockService.Lock(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Never);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()), Times.Never);
        }

        [Fact]
        public async Task Lock_CreditJobLockFails_UnlockJob()
        {
            // Arrange
            this.creditJobLockStatus.IsSuccessful = false;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.creditJobLockStatus));

            // Act
            var actualResult = await this.localLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_CreditJobLockFailsAndRetrunsNull_UnlockJob()
        {
            // Arrange
            this.creditJobLockStatus.IsSuccessful = false;
            this.jobApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.jobLockStatus));
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.creditJobLockStatus));

            // Act
            var actualResult = await this.localLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.jobApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
        }
    }
}
