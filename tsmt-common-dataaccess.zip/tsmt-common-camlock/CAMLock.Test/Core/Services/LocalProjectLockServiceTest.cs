// <copyright file="LocalJobLockServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class LocalProjectLockServiceTest
    {
        private readonly LocalProjectLockService localProjectLockService;
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalProjectLockServiceTest"/> class.
        /// </summary>
        public LocalProjectLockServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.localProjectLockService = new LocalProjectLockService(this.orderingApiClientMock.Object);
        }

        [Fact]
        public async Task Lock_LockIsIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localProjectLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_LockIsDenied_ReturnsFailureStatus()
        {
            // Arrange
            this.lockStatus.IsSuccessful = false;
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localProjectLockService.Lock(camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_LockIsConflict_ReturnsFailureStatus()
        {
            // Arrange
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderingApiClientMock.Setup(x => x.LockOrUnlockCreditJob(It.IsAny<bool>(), It.IsAny<CreditJobLockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.localProjectLockService.Lock(camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderingApiClientMock.Verify(x => x.LockOrUnlockCreditJob(true, It.IsAny<CreditJobLockInput>()), Times.Once);
        }
    }
}
