// <copyright file="HostLockServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class HostLockServiceTest
    {
        private readonly HostLockService hostLockService;
        private readonly Mock<IOrderApiClient> orderApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;
        private HostLockInput hostLockInput;
        private LockStatus hostLockStatus;

        public HostLockServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.hostLockInput = new HostLockInput()
            {
                Application = Constants.LockFromApplication,
                CanProcessChangeOrder = true,
                CanProcessDbCommit = true,
                CanProcessSalesOrder = true,
                CreditJobId = this.camData.HostLock.CreditProjectLocks.First().CreditJobId
            };
            this.hostLockStatus = new LockStatus() { IsSuccessful = true };
            this.orderApiClientMock = new Mock<IOrderApiClient>();
            this.hostLockService = new HostLockService(this.orderApiClientMock.Object);
        }

        [Fact]
        public async Task Lock_AllLocksIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.AllHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.hostLockStatus));

            // Act
            var actualResult = await this.hostLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Never);
            this.orderApiClientMock.Verify(x => x.AllHostLock(It.IsAny<HostLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_JobLockFails_DoNotLockCreditJob()
        {
            // Arrange
            this.lockStatus.IsSuccessful = false;
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.hostLockService.Lock(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.AllHostLock(It.IsAny<HostLockInput>()), Times.Never);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Never);
        }

        [Fact]
        public async Task Lock_JobLockConflicts_DoNotLockCreditJob()
        {
            // Arrange
            this.lockStatus = new LockStatus() { IsSuccessful = false };
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.AllHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.hostLockStatus));

            // Act
            var actualResult = await this.hostLockService.Lock(this.camData);

            // Assert
            Assert.False(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.AllHostLock(It.IsAny<HostLockInput>()), Times.Never);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Never);
        }

        [Fact]
        public async Task Lock_CreditJobLockFails_UnlockJob()
        {
            // Arrange
            this.hostLockStatus.IsSuccessful = false;
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.AllHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.hostLockStatus));

            // Act
            var actualResult = await this.hostLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.AllHostLock(It.IsAny<HostLockInput>()), Times.Once);
        }

        [Fact]
        public async Task Lock_CreditJobLockFailsAndRetrunsFalse_UnlockJob()
        {
            // Arrange
            this.hostLockStatus.IsSuccessful = false;
            this.orderApiClientMock.Setup(x => x.LockOrUnlockJob(It.IsAny<bool>(), It.IsAny<LockInput>()))
                .Returns(Task.FromResult(this.lockStatus));
            this.orderApiClientMock.Setup(x => x.AllHostLock(It.IsAny<HostLockInput>()))
                .Returns(Task.FromResult(this.hostLockStatus));

            // Act
            var actualResult = await this.hostLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(true, It.IsAny<LockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.LockOrUnlockJob(false, It.IsAny<LockInput>()), Times.Once);
            this.orderApiClientMock.Verify(x => x.AllHostLock(It.IsAny<HostLockInput>()), Times.Once);
        }
    }
}
