// <copyright file="ApplyLocalActionTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class ApplyLocalActionTest
    {
        private readonly ApplyLocalAction applyAllLocalLock;
        private readonly Mock<ILockService> lockServiceMock;
        private readonly Mock<ILockServiceFactory> lockServiceFactoryMock;
        private CamData camData;
        private LockStatus lockStatus;


        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyHostActionTest"/> class.
        /// Constructor.
        /// </summary>
        public ApplyLocalActionTest()
        {
            this.camData = Helper.GetCamData();
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.lockServiceFactoryMock = new Mock<ILockServiceFactory>();
            this.lockServiceMock = new Mock<ILockService>();
            this.lockServiceFactoryMock.Setup(x => x.GetLockServiceInstance(LockService.LocalLockService)).Returns(this.lockServiceMock.Object);
            this.applyAllLocalLock = new ApplyLocalAction(this.lockServiceFactoryMock.Object);
        }

        [Fact]
        public async Task ExecuteAction_AllLocksIssued_ReturnsSuccessStatus()
        {
            // Arrange
            this.lockServiceMock.Setup(x => x.Lock(It.IsAny<CamData>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            var actualResult = await this.applyAllLocalLock.ExecuteAction(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.lockServiceMock.Verify(x => x.Lock(this.camData), Times.Once);
        }
    }
}
