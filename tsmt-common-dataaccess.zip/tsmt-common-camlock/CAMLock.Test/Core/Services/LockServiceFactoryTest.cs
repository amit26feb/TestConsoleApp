// <copyright file="LockServiceFactoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Collections.Generic;
    using Moq;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class LockServiceFactoryTest
    {
        private readonly Mock<IOrderApiClient> orderApiClientMock;
        private readonly Mock<IJobApiClient> jobApiClientMock;
        private readonly LockServiceFactory lockServiceFactory;
        private readonly IEnumerable<ILockService> lockServices;
        private readonly ILockService localLockService;
        private readonly ILockService hostLockService;

        /// <summary>
        /// Initializes a new instance of the <see cref="LockServiceFactoryTest"/> class.
        /// Constructor.
        /// </summary>
        public LockServiceFactoryTest()
        {
            this.orderApiClientMock = new Mock<IOrderApiClient>();
            this.jobApiClientMock = new Mock<IJobApiClient>();
            this.localLockService = new LocalJobLockService(this.jobApiClientMock.Object);
            this.hostLockService = new HostLockService(this.orderApiClientMock.Object);
            this.lockServices = new List<ILockService>()
            {
                this.localLockService,
                this.hostLockService
            };

            this.lockServiceFactory = new LockServiceFactory(this.lockServices);
        }

        [Fact]
        public void GetLockService_LocalLockServiceIsImplemented_ReturnsLocalLockService()
        {
            // Act
            var actualResult = this.lockServiceFactory.GetLockServiceInstance(LockService.LocalJobLockService);

            // Assert
            Assert.Equal(LockService.LocalJobLockService, actualResult.LockService);
        }

        [Fact]
        public void GetLockService_HostLockServiceIsImplemented_ReturnsHostLockService()
        {
            // Act
            var actualResult = this.lockServiceFactory.GetLockServiceInstance(LockService.HostLockService);

            // Assert
            Assert.Equal(LockService.HostLockService, actualResult.LockService);
        }
    }
}
