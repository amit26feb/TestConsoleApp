// <copyright file="HostSalesOrderLockServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CAMLock.Test.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants;
    using TSMT.CAM.Locks.Core.Services;
    using Xunit;

    public class ApplyHostSalesOrderLockServiceTest
    {
        private readonly ApplyHostSalesOrderLockService applyHostSalesOrderLockService;
        private readonly Mock<IOrderApiClient> orderApiClientMock;
        private CamData camData;
        private LockStatus lockStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyHostSalesOrderLockServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public ApplyHostSalesOrderLockServiceTest()
        {
            this.lockStatus = new LockStatus() { IsSuccessful = true };
            this.camData = Helper.GetCamData();
            this.orderApiClientMock = new Mock<IOrderApiClient>();
            this.applyHostSalesOrderLockService = new ApplyHostSalesOrderLockService(this.orderApiClientMock.Object);
        }

        [Fact]
        public async Task Lock_LockIsIssued_ReturnsSuccessStatus()
        {
            // Arrange
            bool applyLock = true;
            IEnumerable<int> salesOrderIds = this.camData.HostLock.CreditProjectLocks.First().SalesOrderLocks.Select(x => x.SalesOrderId);
            this.orderApiClientMock.Setup(x => x.ApplyHostSalesOrderLockOrUnlock(It.IsAny<IEnumerable<int>>(), It.IsAny<string>(), It.IsAny<bool>()))
                .Returns(Task.FromResult(this.lockStatus));

            // Act
            LockStatus actualResult = await this.applyHostSalesOrderLockService.Lock(this.camData);

            // Assert
            Assert.True(actualResult.IsSuccessful);
            this.orderApiClientMock.Verify(x => x.ApplyHostSalesOrderLockOrUnlock(salesOrderIds, Constants.HostSalesOrderLockApplication, applyLock), Times.Once);
        }
    }
}
