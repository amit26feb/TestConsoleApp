// <copyright file="Helper.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMLock.Test.Common
{
    using System.Collections.Generic;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Defines the <see cref="Helper" />
    /// </summary>
    public class Helper
    {
        /// <summary>
        /// Format CAMData
        /// </summary>
        /// <returns></returns>
        public static CamData GetCamData()
        {
            return new CamData()
            {
                DrAddressId = 1,
                UserId = "ABC",
                LocalLock = new LockData()
                {
                    JobId = 1234,
                    LockUserId = "ABC",
                    CreditProjectLocks = new List<CreditProjectLock>()
                    {
                        new CreditProjectLock()
                        {
                            LockUserId = "ABC",
                            ChangeAllowedIndicator = 'Y',
                            ChangeOrderDecisionStatus = 5,
                            ChangeOrderStatus = "Pending",
                            CreditJobId = 12343545,
                            LegacyCreditJobNumber = "CR01",
                            SalesOrderLocks = new List<SalesOrderLock>()
                            {
                                new SalesOrderLock()
                                {
                                    SalesOrderId = 98656,
                                    ChangeOrderStatus = "XX",
                                    LockUserId = "ABC"
                                }
                            }
                        }
                    }
                },
                HostLock = new LockData()
                {
                    JobId = 1234,
                    LockUserId = "ABC",
                    CreditProjectLocks = new List<CreditProjectLock>()
                    {
                        new CreditProjectLock()
                        {
                            LockUserId = "ABC",
                            ChangeAllowedIndicator = 'Y',
                            ChangeOrderDecisionStatus = 5,
                            ChangeOrderStatus = "Pending",
                            CreditJobId = 12343545,
                            LegacyCreditJobNumber = "CR01",
                            SalesOrderLocks = new List<SalesOrderLock>()
                            {
                                new SalesOrderLock()
                                {
                                    SalesOrderId = 98656,
                                    ChangeOrderStatus = "XX",
                                    LockUserId = "ABC"
                                }
                            }
                        }
                    }
                }
            };
        }
    }
}
