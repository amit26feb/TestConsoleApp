// <copyright file="LocalReleaseService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Local release lock service
    /// </summary>
    public class LocalReleaseService : IReleaseService
    {
        private readonly IJobApiClient jobApiClient;
        private readonly IOrderingApiClient orderingApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalReleaseService"/> class.
        /// </summary>
        /// <param name="jobApiClient">Job api</param>
        /// <param name="orderingApiClient">Ordering api</param>
        public LocalReleaseService(IJobApiClient jobApiClient, IOrderingApiClient orderingApiClient)
        {
            this.jobApiClient = jobApiClient;
            this.orderingApiClient = orderingApiClient;
            this.ReleaseService = ReleaseService.LocalReleaseService;
        }

        /// <summary>
        /// Gets release service
        /// </summary>
        public ReleaseService ReleaseService { get; }

        /// <summary>
        /// Executes release local lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release local lock execution</returns>
        public async Task<LockStatus> Release(CamData camData)
        {
            // Release the local job lock
            LockStatus localLockStatus = await this.LocalJobRelease(false, camData.LocalLock.JobId, camData.DrAddressId, camData.UserId);
            if (localLockStatus.IsSuccessful)
            {
                // If job release lock is successful, release lock local credit job.
                // we will always have one credit job id in this case
                localLockStatus = await this.LocalCreditJobRelease(camData.LocalLock.CreditProjectLocks.First().CreditJobId, camData.DrAddressId, camData.UserId);

                // If all local release lock is failure, lock the job
                if (!localLockStatus.IsSuccessful)
                {
                    localLockStatus = await this.LocalJobRelease(true, camData.LocalLock.JobId, camData.DrAddressId, camData.LocalLock.LockUserId);
                }
            }

            return localLockStatus;
        }

        /// <summary>
        /// Lock/Unlock job in local environment
        /// </summary>
        /// <param name="isJobLock">Flag to indiacate whether the Lock/Unlcok is requested</param>
        /// <param name="jobId">Job id to lock</param>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="userToLock">User to lock the job</param>
        /// <returns>Job lock status</returns>
        private async Task<LockStatus> LocalJobRelease(bool isJobLock, int jobId, int drAddressId, string userToLock)
        {
            LockInput lockInput = new LockInput()
            {
                AllowLockOverride = false,
                JobId = jobId,
                UserId = userToLock,
                DrAddressId = drAddressId
            };

            return await this.jobApiClient.LockOrUnlockJob(isJobLock, lockInput);
        }

        /// <summary>
        /// Apply release lock on the credit job local environment
        /// </summary>
        /// <param name="creditJobId">Credit job to lock</param>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="userToLock">User to lock the job</param>
        /// <returns>Credit job release lock status</returns>
        private async Task<LockStatus> LocalCreditJobRelease(int creditJobId, int drAddressId, string userToLock)
        {
            CreditJobLockInput lockInput = new CreditJobLockInput()
            {
                AllowLockOverride = false,
                DrAddressId = drAddressId,
                CreditJobId = creditJobId,
                UserId = userToLock
            };

            return await this.orderingApiClient.LockOrUnlockCreditJob(false, lockInput);
        }
    }
}
