// <copyright file="ReleaseHostAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Release host action
    /// This will release host(ES db) job, credit job and sales order lock
    /// </summary>
    public class ReleaseHostAction : IAction
    {
        private readonly IReleaseService releaseService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReleaseHostAction"/> class.
        /// </summary>
        /// <param name="releaseServiceFactory">Contains implementation to issue release job lock and credit job in local</param>
        public ReleaseHostAction(IReleaseServiceFactory releaseServiceFactory)
        {
            this.releaseService = releaseServiceFactory.GetReleaseServiceInstance(ReleaseService.HostReleaseService);
            this.ActionType = ActionType.ReleaseHostAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute action
        /// Release host job, credit job, sales order
        /// After successful delete of an credit job
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            return await this.releaseService.Release(camData);
        }
    }
}
