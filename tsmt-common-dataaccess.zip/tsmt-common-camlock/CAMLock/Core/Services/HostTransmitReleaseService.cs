// <copyright file="HostTransmitReleaseService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Host transmit release service
    /// </summary>
    public class HostTransmitReleaseService : IReleaseService
    {
        private readonly IOrderingApiClient orderingApiClient;
        private readonly IOrderApiClient orderApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="HostTransmitReleaseService"/> class.
        /// </summary>
        /// <param name="orderingApiClient">Ordering api client</param>
        /// <param name="orderApiClient">Order api client</param>
        public HostTransmitReleaseService(IOrderingApiClient orderingApiClient, IOrderApiClient orderApiClient)
        {
            this.orderingApiClient = orderingApiClient;
            this.orderApiClient = orderApiClient;
            this.ReleaseService = ReleaseService.HostTransmitReleaseService;
        }

        /// <summary>
        /// Gets release service
        /// </summary>
        public ReleaseService ReleaseService { get; }

        /// <summary>
        /// Execute release after successful transmit
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release transmit lock execution</returns>
        public async Task<LockStatus> Release(CamData camData)
        {
            // we will always have one credit job id in this case
            LockStatus hostLockStatus = await this.ResetCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId);

            // If release credit job lock success then call the sales order transmit release
            if (hostLockStatus.IsSuccessful)
            {
                hostLockStatus = await this.orderApiClient.TransmitReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId);

                // Sales order lock is success then call host job release lock
                if (hostLockStatus.IsSuccessful)
                {
                    hostLockStatus = await this.HostJobRelease(camData.HostLock.JobId, camData.HostLock.LockUserId, false);

                    // If job lock success then check remnant exist
                    // If exist then release local project lock
                    if (hostLockStatus.IsSuccessful)
                    {
                        return await this.LocalRemnantLockRelease(camData);
                    }
                }
            }

            return hostLockStatus;
        }

        /// <summary>
        /// Release lock on the credit job
        /// </summary>
        /// <param name="creditJobId">Credit job to lock</param>
        /// <returns>Lock status</returns>
        private async Task<LockStatus> ResetCreditJobLock(int creditJobId)
        {
            HostLockInput lockInput = new HostLockInput()
            {
                Application = Constants.LockFromApplication,
                CanProcessChangeOrder = false,
                CanProcessDbCommit = true,
                CanProcessSalesOrder = true,
                CreditJobId = creditJobId,
                UserId = "SERVER",
                SalesOrder = "ACO X"
            };

            return await this.orderApiClient.ResetHostLock(lockInput);
        }

        /// <summary>
        /// Lock/Unlock job in host environment
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="userToLock">User to lock the job</param>
        /// <param name="isJobLock">Flag to indiacate whether the Lock/Unlcok is requested</param>
        /// <returns>Job lock status</returns>
        private async Task<LockStatus> HostJobRelease(int jobId, string userToLock, bool isJobLock)
        {
            LockInput lockInput = new LockInput()
            {
                AllowLockOverride = true,
                JobId = jobId,
                UserId = userToLock
            };

            return await this.orderApiClient.LockOrUnlockJob(isJobLock, lockInput);
        }

        /// <summary>
        /// Check is there an local remnant data available
        /// If local remnant data available then call local project lock release
        /// Else returns true
        /// </summary>
        /// <param name="camData">Cam data</param>
        /// <returns>Lock status</returns>
        private async Task<LockStatus> LocalRemnantLockRelease(CamData camData)
        {
            // Find is there an remnant data present in local
            int? localHqtrCreditJobId = camData.LocalLock?.CreditProjectLocks?.FirstOrDefault()?.HqtrCreditJobId;

            // If remnant persent then call local credit job lock realese
            // Why not checking the host lock application and lock user condition here
            // Just before this execution for the host data we have set the lock user to SERVER and application FOE
            // So if we still have the local data avaialble then we have to consider this as an remnant data
            if (localHqtrCreditJobId > 0)
            {
                CreditJobLockInput lockInput = new CreditJobLockInput()
                {
                    AllowLockOverride = false,
                    CreditJobId = camData.LocalLock.CreditProjectLocks.First().CreditJobId,
                    UserId = camData.UserId,
                    DrAddressId = camData.DrAddressId
                };

                return await this.orderingApiClient.LockOrUnlockCreditJob(false, lockInput);
            }

            return new LockStatus { IsSuccessful = true };
        }
    }
}
