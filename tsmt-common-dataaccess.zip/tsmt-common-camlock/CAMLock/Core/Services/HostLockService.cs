// <copyright file="HostLockService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Host lock service
    /// </summary>
    public class HostLockService : ILockService
    {
        private readonly IOrderApiClient orderApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="HostLockService"/> class.
        /// </summary>
        /// <param name="orderApiClient">Job api</param>
        public HostLockService(IOrderApiClient orderApiClient)
        {
            this.orderApiClient = orderApiClient;
            this.LockService = LockService.HostLockService;
        }

        /// <summary>
        /// Gets lock service
        /// </summary>
        public LockService LockService { get; }

        /// <summary>
        /// Executes host lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the lock execution</returns>
        public async Task<LockStatus> Lock(CamData camData)
        {
            // Lock the job
            LockStatus hostLockStatus = await this.JobLock(true, camData.HostLock.JobId, camData.DrAddressId, camData.UserId);
            if (hostLockStatus.IsSuccessful)
            {
                // If job lock is successful, lock host credit job and sales orders associated with it.
                // we will always have one credit job id in this case
                hostLockStatus = await this.ApplyCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId, camData.UserId);

                // If all host lock is failure, unlock the job
                if (!hostLockStatus.IsSuccessful)
                {
                    hostLockStatus = await this.JobLock(false, camData.HostLock.JobId, camData.DrAddressId, camData.HostLock.LockUserId);
                }
            }

            return hostLockStatus;
        }

        /// <summary>
        /// Lock/Unlock job in host environment
        /// </summary>
        /// <param name="isJobLock">Flag to indiacate whether the Lock/Unlcok is requested</param>
        /// <param name="jobId">Job id to lock</param>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="userToLock">User to lock the job</param>
        /// <returns>Lock status</returns>
        private async Task<LockStatus> JobLock(bool isJobLock, int jobId, int drAddressId, string userToLock)
        {
            LockInput lockInput = new LockInput()
            {
                AllowLockOverride = false,
                JobId = jobId,
                UserId = userToLock,
                DrAddressId = drAddressId
            };

            return await this.orderApiClient.LockOrUnlockJob(isJobLock, lockInput);
        }

        /// <summary>
        /// Apply lock on the credit job and sales orders associated
        /// </summary>
        /// <param name="creditJobId">Credit job to lock</param>
        /// <param name="userToLock">User to lock the job</param>
        /// <returns>Lock status</returns>
        private async Task<LockStatus> ApplyCreditJobLock(int creditJobId, string userToLock)
        {
            HostLockInput lockInput = new HostLockInput()
            {
                Application = Constants.LockFromApplication,
                CanProcessChangeOrder = true,
                CanProcessDbCommit = true,
                CanProcessSalesOrder = true,
                CreditJobId = creditJobId,
                UserId = userToLock,
                SalesOrder = "ACO X"
            };

            return await this.orderApiClient.AllHostLock(lockInput);
        }
    }
}
