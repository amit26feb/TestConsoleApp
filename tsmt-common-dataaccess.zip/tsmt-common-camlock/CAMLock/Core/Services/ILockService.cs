// <copyright file="ILockService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Interface for lock service
    /// </summary>
    public interface ILockService
    {
        /// <summary>
        /// Gets lock service context
        /// </summary>
        LockService LockService { get; }

        /// <summary>
        /// Executes Lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the lock execution</returns>
        Task<LockStatus> Lock(CamData camData);
    }
}
