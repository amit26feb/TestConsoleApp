// <copyright file="LocalProjectAndSalesOrderLockService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Local project and sales order lock service
    /// </summary>
    public class LocalProjectAndSalesOrderLockService : ILockService
    {
        private readonly IOrderingApiClient orderingApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalProjectAndSalesOrderLockService"/> class.
        /// </summary>
        /// <param name="orderingApiClient">Ordering api</param>
        public LocalProjectAndSalesOrderLockService(IOrderingApiClient orderingApiClient)
        {
            this.orderingApiClient = orderingApiClient;
            this.LockService = LockService.LocalProjectAndSalesOrderLockService;
        }

        /// <summary>
        /// Gets lock service
        /// </summary>
        public LockService LockService { get; }

        /// <summary>
        /// Executes local lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the local lock execution</returns>
        public async Task<LockStatus> Lock(CamData camData)
        {
            // we will always have one credit job id in this case
            LockStatus localLockStatus = await this.LocalCreditJobLock(camData.LocalLock.CreditProjectLocks.First().CreditJobId, camData.DrAddressId, camData.UserId);

            // If credit job lock success then call the sales order lock
            if (localLockStatus.IsSuccessful)
            {
                return await this.orderingApiClient.SalesOrderLock(camData.DrAddressId, camData.LocalLock.CreditProjectLocks.First().CreditJobId);
            }

            return localLockStatus;
        }

        /// <summary>
        /// Apply lock on the credit job local environment
        /// </summary>
        /// <param name="creditJobId">Credit job to lock</param>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="userToLock">User to lock the job</param>
        /// <returns>Credit job lock status</returns>
        private async Task<LockStatus> LocalCreditJobLock(int creditJobId, int drAddressId, string userToLock)
        {
            CreditJobLockInput lockInput = new CreditJobLockInput()
            {
                AllowLockOverride = false,
                DrAddressId = drAddressId,
                CreditJobId = creditJobId,
                UserId = userToLock
            };

            return await this.orderingApiClient.LockOrUnlockCreditJob(true, lockInput);
        }
    }
}
