// <copyright file="LocalProjectReleaseService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Local project release lock service
    /// </summary>
    public class LocalProjectReleaseService : IReleaseService
    {
        private readonly IOrderingApiClient orderingApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalProjectReleaseService"/> class.
        /// </summary>
        /// <param name="orderingApiClient">Ordering api</param>
        public LocalProjectReleaseService(IOrderingApiClient orderingApiClient)
        {
            this.orderingApiClient = orderingApiClient;
            this.ReleaseService = ReleaseService.LocalProjectReleaseService;
        }

        /// <summary>
        /// Gets release service
        /// </summary>
        public ReleaseService ReleaseService { get; }

        /// <summary>
        /// Execute release local project lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release local project lock execution</returns>
        public async Task<LockStatus> Release(CamData camData)
        {
            CreditJobLockInput lockInput = new CreditJobLockInput()
            {
                AllowLockOverride = false,
                CreditJobId = camData.LocalLock.CreditProjectLocks.First().CreditJobId,
                UserId = camData.UserId,
                DrAddressId = camData.DrAddressId
            };

            return await this.orderingApiClient.LockOrUnlockCreditJob(false, lockInput);
        }
    }
}
