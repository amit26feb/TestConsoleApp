// <copyright file="HostReleaseService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Host release service
    /// This will release lock in host(ES db) job, credit job and sales order
    /// </summary>
    public class HostReleaseService : IReleaseService
    {
        private readonly IOrderApiClient orderApiClient;
        private readonly IOrderingApiClient orderingApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="HostReleaseService"/> class.
        /// </summary>
        /// <param name="orderApiClient">Order api client</param>
        /// <param name="orderingApiClient">Ordering api client</param>
        public HostReleaseService(IOrderApiClient orderApiClient, IOrderingApiClient orderingApiClient)
        {
            this.orderApiClient = orderApiClient;
            this.orderingApiClient = orderingApiClient;
            this.ReleaseService = ReleaseService.HostReleaseService;
        }

        /// <summary>
        /// Gets release service
        /// </summary>
        public ReleaseService ReleaseService { get; }

        /// <summary>
        /// Execute release after successful delete of an credit job
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release host lock execution</returns>
        public async Task<LockStatus> Release(CamData camData)
        {
            // we will always have one credit job id in this case
            LockStatus hostLockStatus = await this.orderApiClient.ReleaseCreditJobLock(camData.HostLock.CreditProjectLocks.First().CreditJobId);

            // If release credit job lock success then call the sales order lock release
            if (hostLockStatus.IsSuccessful)
            {
                hostLockStatus = await this.orderApiClient.ReleaseSalesOrderLock(camData.HostLock.CreditProjectLocks.First().CreditJobId);

                // Sales order lock is success then call host job release lock
                if (hostLockStatus.IsSuccessful)
                {
                    LockInput lockInput = new LockInput()
                    {
                        AllowLockOverride = true,
                        JobId = camData.HostLock.JobId,
                        UserId = camData.HostLock.LockUserId
                    };

                    hostLockStatus = await this.orderApiClient.LockOrUnlockJob(false, lockInput);

                    // Check if we have the local lock data exist
                    CreditProjectLock localCreditProjectLock = camData.LocalLock?.CreditProjectLocks?.FirstOrDefault();
                    if (hostLockStatus.IsSuccessful && localCreditProjectLock != null)
                    {
                        // Afet the successful relase lock of an host
                        // Call the ordering service to relase the credit job local lock
                        // if the remnant exist this will release the lock
                        CreditJobLockInput creditJobLockInput = new CreditJobLockInput()
                        {
                            DrAddressId = camData.DrAddressId,
                            AllowLockOverride = true,
                            CreditJobId = localCreditProjectLock.CreditJobId,
                            UserId = localCreditProjectLock.LockUserId
                        };

                        await this.orderingApiClient.LockOrUnlockCreditJob(false, creditJobLockInput);
                    }
                }
            }

            return hostLockStatus;
        }
    }
}
