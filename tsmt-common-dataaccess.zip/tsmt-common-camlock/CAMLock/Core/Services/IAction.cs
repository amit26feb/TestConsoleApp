// <copyright file="IAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Defines the methods that are used in locks
    /// </summary>
    public interface IAction
    {
        /// <summary>
        /// Gets action type
        /// </summary>
        ActionType ActionType { get; }

        /// <summary>
        /// Execute Lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the execute action</returns>
        Task<LockStatus> ExecuteAction(CamData camData);
    }
}
