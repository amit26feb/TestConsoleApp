// <copyright file="ApplyLocalOrderAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Apply local order action
    /// </summary>
    public class ApplyLocalOrderAction : IAction
    {
        private readonly ILockService lockService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyLocalOrderAction"/> class.
        /// </summary>
        /// <param name="lockServiceFactory">Contains implementation to issue all locks in Host</param>
        public ApplyLocalOrderAction(ILockServiceFactory lockServiceFactory)
        {
            this.lockService = lockServiceFactory.GetLockServiceInstance(LockService.LocalProjectAndSalesOrderLockService);
            this.ActionType = ActionType.ApplyLocalOrderAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the lock execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            return await this.lockService.Lock(camData);
        }
    }
}
