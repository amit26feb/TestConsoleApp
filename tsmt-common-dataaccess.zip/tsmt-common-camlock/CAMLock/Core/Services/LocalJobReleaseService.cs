// <copyright file="LocalJobReleaseService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Local job release lock service
    /// </summary>
    public class LocalJobReleaseService : IReleaseService
    {
        private readonly IJobApiClient jobApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalJobReleaseService"/> class.
        /// </summary>
        /// <param name="jobApiClient">Job api</param>
        public LocalJobReleaseService(IJobApiClient jobApiClient)
        {
            this.jobApiClient = jobApiClient;
            this.ReleaseService = ReleaseService.LocalJobRelaseService;
        }

        /// <summary>
        /// Gets release service
        /// </summary>
        public ReleaseService ReleaseService { get; }

        /// <summary>
        /// Execute local job release lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the local job release lock execution</returns>
        public async Task<LockStatus> Release(CamData camData)
        {
            LockInput lockInput = new LockInput()
            {
                AllowLockOverride = true,
                JobId = camData.LocalLock.JobId,
                UserId = camData.UserId,
                DrAddressId = camData.DrAddressId
            };

            return await this.jobApiClient.LockOrUnlockJob(false, lockInput);
        }
    }
}
