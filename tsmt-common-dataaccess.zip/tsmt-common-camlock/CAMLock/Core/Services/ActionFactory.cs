// <copyright file="ActionFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Class to get action instance
    /// </summary>
    public class ActionFactory : IActionFactory
    {
        private readonly IEnumerable<IAction> actions;

        /// <summary>
        /// Initializes a new instance of the <see cref="ActionFactory"/> class.
        /// </summary>
        /// <param name="actions">List of conditions available</param>
        public ActionFactory(IEnumerable<IAction> actions)
        {
            this.actions = actions;
        }

        /// <summary>
        /// Creates the instance of the action based on the action type
        /// </summary>
        /// <param name="actionType">Specifies the action type</param>
        /// <returns>Action instance based on the action context</returns>
        public IAction GetActionInstance(ActionType actionType)
        {
            return this.actions.FirstOrDefault(x => x.ActionType == actionType);
        }
    }
}
