// <copyright file="ApplyHostSalesOrderLockService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Host sales order lock service
    /// </summary>
    public class ApplyHostSalesOrderLockService : ILockService
    {
        private readonly IOrderApiClient orderApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyHostSalesOrderLockService"/> class.
        /// </summary>
        /// <param name="orderApiClient">Job api</param>
        public ApplyHostSalesOrderLockService(IOrderApiClient orderApiClient)
        {
            this.orderApiClient = orderApiClient;
            this.LockService = LockService.ApplyHostSalesOrderLockService;
        }

        /// <summary>
        /// Gets lock service
        /// </summary>
        public LockService LockService { get; }

        /// <summary>
        /// Executes host lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the lock execution</returns>
        public async Task<LockStatus> Lock(CamData camData)

        {
            IEnumerable<int> salesOrderIds = camData.HostLock.CreditProjectLocks.First().SalesOrderLocks.Select(x => x.SalesOrderId);

            // applyLock indicates if the sales order id(s) is to be locked or unlocked
            bool applyLock = true;

            return await this.orderApiClient.ApplyHostSalesOrderLockOrUnlock(salesOrderIds, Constants.HostSalesOrderLockApplication, applyLock);
        }
    }
}
