// <copyright file="ReleaseServiceFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Release service factory
    /// </summary>
    public class ReleaseServiceFactory : IReleaseServiceFactory
    {
        private readonly IEnumerable<IReleaseService> releaseServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReleaseServiceFactory"/> class.
        /// </summary>
        /// <param name="releaseServices">List of possible release services available</param>
        public ReleaseServiceFactory(IEnumerable<IReleaseService> releaseServices)
        {
            this.releaseServices = releaseServices;
        }

        /// <summary>
        /// Creates the instance of the release service based on the release context
        /// </summary>
        /// <param name="releaseService">Specifies the release service type</param>
        /// <returns>Release service instance based on the release context</returns>
        public IReleaseService GetReleaseServiceInstance(ReleaseService releaseService)
        {
            return this.releaseServices.FirstOrDefault(x => x.ReleaseService == releaseService);
        }
    }
}
