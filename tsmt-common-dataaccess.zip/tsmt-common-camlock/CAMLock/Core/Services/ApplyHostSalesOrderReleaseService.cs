// <copyright file="ApplyHostSalesOrderReleaseService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Host sales order release service
    /// </summary>
    public class ApplyHostSalesOrderReleaseService : IReleaseService
    {
        private readonly IOrderApiClient orderApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyHostSalesOrderReleaseService"/> class.
        /// </summary>
        /// <param name="orderApiClient">Order api client</param>
        public ApplyHostSalesOrderReleaseService(IOrderApiClient orderApiClient)
        {
            this.orderApiClient = orderApiClient;
            this.ReleaseService = ReleaseService.ApplyHostSalesOrderReleaseService;
        }

        /// <summary>
        /// Gets release service
        /// </summary>
        public ReleaseService ReleaseService { get; }

        /// <summary>
        /// Executes release lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the unlock/release execution</returns>
        public async Task<LockStatus> Release(CamData camData)
        {
            IEnumerable<int> salesOrderIds = camData.HostLock.CreditProjectLocks.First().SalesOrderLocks.Select(x => x.SalesOrderId);

            // applyLock indicates if the sales order id(s) is to be locked or unlocked
            bool applyLock = false;

            return await this.orderApiClient.ApplyHostSalesOrderLockOrUnlock(salesOrderIds, Constants.HostSalesOrderLockApplication, applyLock);
        }
    }
}
