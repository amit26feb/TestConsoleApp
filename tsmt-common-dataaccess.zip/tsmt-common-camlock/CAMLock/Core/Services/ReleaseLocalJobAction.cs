// <copyright file="ReleaseLocalJobAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Class to issue action for release local job action
    /// </summary>
    public class ReleaseLocalJobAction : IAction
    {
        private readonly IReleaseService releaseService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReleaseLocalJobAction"/> class.
        /// </summary>
        /// <param name="releaseServiceFactory">Contains implementation to issue release job lock in local</param>
        public ReleaseLocalJobAction(IReleaseServiceFactory releaseServiceFactory)
        {
            this.releaseService = releaseServiceFactory.GetReleaseServiceInstance(ReleaseService.LocalJobRelaseService);
            this.ActionType = ActionType.ReleaseLocalJobAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute action
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            return await this.releaseService.Release(camData);
        }
    }
}
