// <copyright file="LockServiceFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Lock service factory
    /// </summary>
    public class LockServiceFactory : ILockServiceFactory
    {
        private readonly IEnumerable<ILockService> lockServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="LockServiceFactory"/> class.
        /// </summary>
        /// <param name="lockServices">List of possible lock services available</param>
        public LockServiceFactory(IEnumerable<ILockService> lockServices)
        {
            this.lockServices = lockServices;
        }

        /// <summary>
        /// Creates the instance of the lock service based on the lock context
        /// </summary>
        /// <param name="lockService">Specifies the lock service type</param>
        /// <returns>Lock service instance based on the lock context</returns>
        public ILockService GetLockServiceInstance(LockService lockService)
        {
            return this.lockServices.FirstOrDefault(x => x.LockService == lockService);
        }
    }
}
