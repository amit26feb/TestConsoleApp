// <copyright file="ApplyLocalAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Class to issue action for local job and credit job process
    /// </summary>
    public class ApplyLocalAction : IAction
    {
        private readonly ILockService lockService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyLocalAction"/> class.
        /// </summary>
        /// <param name="lockServiceFactory">Service to issue all locks in Host</param>
        public ApplyLocalAction(ILockServiceFactory lockServiceFactory)
        {
            this.lockService = lockServiceFactory.GetLockServiceInstance(LockService.LocalLockService);
            this.ActionType = ActionType.ApplyLocalAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute local lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the local lock execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            return await this.lockService.Lock(camData);
        }
    }
}
