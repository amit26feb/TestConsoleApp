// <copyright file="ReleaseHostTransmitAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Release host transmit action
    /// </summary>
    public class ReleaseHostTransmitAction : IAction
    {
        private readonly IReleaseService releaseService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReleaseHostTransmitAction"/> class.
        /// </summary>
        /// <param name="releaseServiceFactory">Contains implementation to issue release job lock and credit job in local</param>
        public ReleaseHostTransmitAction(IReleaseServiceFactory releaseServiceFactory)
        {
            this.releaseService = releaseServiceFactory.GetReleaseServiceInstance(ReleaseService.HostTransmitReleaseService);
            this.ActionType = ActionType.ReleaseHostTransmitAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute action
        /// Release host job, credit job, sales order and remanat
        /// After successful transmit of an credit job
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            return await this.releaseService.Release(camData);
        }
    }
}
