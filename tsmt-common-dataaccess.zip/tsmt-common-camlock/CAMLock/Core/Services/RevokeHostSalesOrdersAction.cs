// <copyright file="RevokeHostSalesOrdersAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Release host action
    /// This will release host(ES db) sales order lock
    /// </summary>
    public class RevokeHostSalesOrdersAction : IAction
    {
        private readonly IReleaseService releaseService;

        /// <summary>
        /// Initializes a new instance of the <see cref="RevokeHostSalesOrdersAction"/> class.
        /// </summary>
        /// <param name="releaseServiceFactory">Contains implementation to issue release job lock and credit job in local</param>
        public RevokeHostSalesOrdersAction(IReleaseServiceFactory releaseServiceFactory)
        {
            this.releaseService = releaseServiceFactory.GetReleaseServiceInstance(ReleaseService.ApplyHostSalesOrderReleaseService);
            this.ActionType = ActionType.RevokeHostSalesOrdersAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute action
        /// Release host sales order ids
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the release execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            return await this.releaseService.Release(camData);
        }
    }
}
