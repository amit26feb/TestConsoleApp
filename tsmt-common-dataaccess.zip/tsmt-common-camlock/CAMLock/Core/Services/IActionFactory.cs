// <copyright file="IActionFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Defines the methods that are used in action factory
    /// </summary>
    public interface IActionFactory
    {
        /// <summary>
        /// Creates the instance of the action based on the type
        /// </summary>
        /// <param name="actionType">Specifies the action type</param>
        /// <returns>Action instance</returns>
        IAction GetActionInstance(ActionType actionType);
    }
}
