// <copyright file="LocalJobLockService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Local job lock service
    /// </summary>
    public class LocalJobLockService : ILockService
    {
        private readonly IJobApiClient jobApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocalJobLockService"/> class.
        /// </summary>
        /// <param name="jobApiClient">Job api</param>
        public LocalJobLockService(IJobApiClient jobApiClient)
        {
            this.jobApiClient = jobApiClient;
            this.LockService = LockService.LocalJobLockService;
        }

        /// <summary>
        /// Gets lock service
        /// </summary>
        public LockService LockService { get; }

        /// <summary>
        /// Execute local job lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the local job lock execution</returns>
        public async Task<LockStatus> Lock(CamData camData)
        {
            LockInput lockInput = new LockInput()
            {
                AllowLockOverride = true,
                JobId = camData.LocalLock.JobId,
                UserId = camData.UserId,
                DrAddressId = camData.DrAddressId
            };

            return await this.jobApiClient.LockOrUnlockJob(true, lockInput);
        }
    }
}
