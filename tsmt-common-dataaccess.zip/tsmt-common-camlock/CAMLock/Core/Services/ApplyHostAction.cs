// <copyright file="ApplyHostAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Class to issue action for apply job and credit job host lock
    /// </summary>
    public class ApplyHostAction : IAction
    {
        private readonly ILockService lockService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyHostAction"/> class.
        /// </summary>
        /// <param name="lockServiceFactory">Service to issue all locks in Host</param>
        public ApplyHostAction(ILockServiceFactory lockServiceFactory)
        {
            this.lockService = lockServiceFactory.GetLockServiceInstance(LockService.HostLockService);
            this.ActionType = ActionType.ApplyHostAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the lock execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            return await this.lockService.Lock(camData);
        }
    }
}
