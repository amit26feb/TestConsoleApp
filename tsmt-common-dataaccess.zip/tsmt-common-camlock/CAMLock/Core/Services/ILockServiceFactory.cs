// <copyright file="ILockServiceFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Lock service factory
    /// </summary>
    public interface ILockServiceFactory
    {
        /// <summary>
        /// Gets lock service instance
        /// </summary>
        /// <param name="lockService">Lock service type</param>
        /// <returns>Lock service instance</returns>
        ILockService GetLockServiceInstance(LockService lockService);
    }
}
