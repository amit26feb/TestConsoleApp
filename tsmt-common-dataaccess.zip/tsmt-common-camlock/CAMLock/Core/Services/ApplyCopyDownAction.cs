// <copyright file="ApplyCopyDownAction.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Class to issue action for copy down process
    /// </summary>
    public class ApplyCopyDownAction : IAction
    {
        private readonly ILockService localService;
        private readonly ILockService hostService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplyCopyDownAction"/> class.
        /// </summary>
        /// <param name="lockServiceFactory">Apply local job lock service</param>
        public ApplyCopyDownAction(ILockServiceFactory lockServiceFactory)
        {
            this.localService = lockServiceFactory.GetLockServiceInstance(LockService.LocalJobLockService);
            this.hostService = lockServiceFactory.GetLockServiceInstance(LockService.HostLockService);

            this.ActionType = ActionType.ApplyCopyDownAction;
        }

        /// <summary>
        /// Gets action type
        /// </summary>
        public ActionType ActionType { get; }

        /// <summary>
        /// Execute lock
        /// </summary>
        /// <param name="camData">Request data</param>
        /// <returns>Status of the lock execution</returns>
        public async Task<LockStatus> ExecuteAction(CamData camData)
        {
            LockStatus lockStatus = await this.localService.Lock(camData);

            if (lockStatus.IsSuccessful)
            {
                lockStatus = await this.hostService.Lock(camData);
            }

            return lockStatus;
        }
    }
}
