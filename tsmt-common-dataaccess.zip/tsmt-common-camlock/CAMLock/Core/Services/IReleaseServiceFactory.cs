// <copyright file="IReleaseServiceFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Core.Services
{
    using TSMT.CAM.Locks.Common.Constants.Enumerator;

    /// <summary>
    /// Release service factory
    /// </summary>
    public interface IReleaseServiceFactory
    {
        /// <summary>
        /// Creates the instance of the release service based on the release context
        /// </summary>
        /// <param name="releaseService">Specifies the release service type</param>
        /// <returns>Release service instance based on the release context</returns>
        IReleaseService GetReleaseServiceInstance(ReleaseService releaseService);
    }
}
