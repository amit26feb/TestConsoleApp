// <copyright file="Constants.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Common.Constants
{
    /// <summary>
    /// Constants
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Lock not implemented message
        /// </summary>
        public const string LockNotImplemented = "Lock is not implemented";

        /// <summary>
        /// Credit job local lock failed
        /// </summary>
        public const string LocalProjectLockFailed = "Local lock failed for the credit job";

        /// <summary>
        /// Job is locked message
        /// </summary>
        public const string JobLocked = "Job is locked by other user";

        /// <summary>
        /// Lock from Application
        /// </summary>
        public const string LockFromApplication = "FOE";

        /// <summary>
        /// Locked by server
        /// </summary>
        public const string LockedByServer = "SERVER";

        /// <summary>
        /// Host lock failed
        /// </summary>
        public const string HostLockFailed = "Host lock failed for the credit job";

        /// <summary>
        /// Bad request
        /// </summary>
        public const string BadRequest = "Bad Request";

        /// <summary>
        /// Host sales order lock application
        /// </summary>
        public const string HostSalesOrderLockApplication = "BuomTemp";
    }
}
