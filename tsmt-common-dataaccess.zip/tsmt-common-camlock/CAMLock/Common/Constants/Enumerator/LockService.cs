// <copyright file="LockService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Common.Constants.Enumerator
{
    /// <summary>
    /// Contains possible values for lock service
    /// </summary>
    public enum LockService
    {
        /// <summary>
        /// Local job lock service
        /// This will olny lock the local job
        /// </summary>
        LocalJobLockService,

        /// <summary>
        /// Host lock service
        /// This will lock both job and credit job for the host
        /// </summary>
        HostLockService,

        /// <summary>
        /// Local project lock service
        /// This will olny lock the local credit project
        /// </summary>
        LocalProjectLockService,

        /// <summary>
        /// Local lock service
        /// This will lock both job and credit job for the local
        /// </summary>
        LocalLockService,

        /// <summary>
        /// Local lock service
        /// This will lock both credit job and sales order for the local
        /// </summary>
        LocalProjectAndSalesOrderLockService,

        /// <summary>
        /// Apply host sales order lock service
        /// This will lock sales order ids for the host
        /// </summary>
        ApplyHostSalesOrderLockService
    }
}
