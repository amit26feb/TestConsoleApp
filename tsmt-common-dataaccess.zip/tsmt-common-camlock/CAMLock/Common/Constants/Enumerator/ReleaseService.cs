// <copyright file="ReleaseService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Common.Constants.Enumerator
{
    /// <summary>
    /// Contains possible values for release service
    /// </summary>
    public enum ReleaseService
    {
        /// <summary>
        /// Local job release service
        /// This will olny release lock in the local job
        /// </summary>
        LocalJobRelaseService,

        /// <summary>
        /// Local project release service
        /// This will olny release lock the local credit project
        /// </summary>
        LocalProjectReleaseService,

        /// <summary>
        /// Local release lock service
        /// This will release lock both job and credit job for the local
        /// </summary>
        LocalReleaseService,

        /// <summary>
        /// Host release lock service
        /// This will release locks on job, credit job, sales order and remnant
        /// </summary>
        HostTransmitReleaseService,

        /// <summary>
        /// Host release lock service
        /// This will release job, credit job and sales order for the host
        /// </summary>
        HostReleaseService,

        /// <summary>
        /// Apply host sales order release service
        /// This will unlock sales order ids for the host
        /// </summary>
        ApplyHostSalesOrderReleaseService
    }
}
