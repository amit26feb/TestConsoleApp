// <copyright file="ActionType.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Locks.Common.Constants.Enumerator
{
    /// <summary>
    /// Action types to be used to set the context in respective action components
    /// </summary>
    public enum ActionType
    {
        /// <summary>
        /// Copy down action
        /// </summary>
        ApplyCopyDownAction,

        /// <summary>
        /// Local job action
        /// Action only apply for job
        /// </summary>
        ApplyLocalJobAction,

        /// <summary>
        /// Host action
        /// Action apply for both job and credit job in host db
        /// </summary>
        ApplyHostAction,

        /// <summary>
        /// Local action
        /// Action apply for both job and credit job in local db
        /// </summary>
        ApplyLocalAction,

        /// <summary>
        /// Local project and sales orders
        /// Action apply for both credit job and sales order
        /// </summary>
        ApplyLocalOrderAction,

        /// <summary>
        /// Local job action
        /// Action only release for job in local db
        /// </summary>
        ReleaseLocalJobAction,

        /// <summary>
        /// Local project action
        /// Action only release for credit job in local db
        /// </summary>
        ReleaseLocalProjectAction,

        /// <summary>
        /// Local action
        /// Action release for both job and credit job in local db
        /// </summary>
        ReleaseLocalAction,

        /// <summary>
        /// Release host transmit action
        /// After successful transmit action will be called
        /// Action release job, credit job, sales order and remnant
        /// </summary>
        ReleaseHostTransmitAction,

        /// <summary>
        /// Release host action
        /// After successful untransmitted delete action will be called
        /// Action release job, credit job and sales order
        /// </summary>
        ReleaseHostAction,

        /// <summary>
        /// Host action
        /// Action apply for sales orders in host db
        /// </summary>
        ApplyHostSalesOrdersAction,

        /// <summary>
        /// Revoke host sales order action
        /// Action release for sales order ids
        /// </summary>
        RevokeHostSalesOrdersAction
    }
}
