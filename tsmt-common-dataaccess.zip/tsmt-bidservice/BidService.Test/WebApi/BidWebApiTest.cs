// <copyright file="BidWebApiTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.WebApi
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using AutoMapper;
   using BidService.Controllers;
   using BidService.Core.Command;
   using BidService.Core.Commands;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using BidService.Test.Common;
   using MediatR;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class BidWebApiTest
   {
      private readonly Mock<IBidService> bidServiceMock;
      private readonly Mock<ILogger<JobsController>> logger;
      private readonly Mock<IMediator> mediatorMock;
      private readonly JobsController controller;

      public BidWebApiTest()
      {
         this.bidServiceMock = new Mock<IBidService>();
         this.logger = new Mock<ILogger<JobsController>>();
         this.mediatorMock = new Mock<IMediator>();
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<global::BidService.Configurations.AutoMapperConfiguration.AutoMapperProfile>();
         });
         this.controller = new JobsController(this.bidServiceMock.Object, this.logger.Object, this.mediatorMock.Object);
      }

      [Fact]
      public async Task GetBidList_ValidJobId_ReturnsListOfBidDetails()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidViewModel> bidList = new List<BidViewModel>
            {
                    new BidViewModel()
                    {
                      BidAlternateId = 657058,
                      CurrentBidInd = "Y",
                      BidName = "Alt Bid",
                      Description = null,
                      CreditJobNumber = "F516048",
                      PurchaseOrderNumber = "2015-19",
                      HqtrBidAlternateId = 241840,
                      HqtrCreditJobId = 232221,
                      BaseBidYesNo = 1,
                      Foe2CreatedOrdersInd = "Y"
                    }
            };
         this.bidServiceMock.Setup(x => x.GetBidList(jobId, It.IsAny<bool>())).Returns(Task.FromResult(bidList));

         // Act
         var result = await this.controller.GetBidList(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, bidList);
         this.bidServiceMock.Verify(x => x.GetBidList(jobId, true), Times.Once);
      }

      [Fact]
      public async Task GetBidList_ValidJobId_HasNoBidDetails_ReturnsNoContent()
      {
         // Arrange
         int jobId = 856;
         IEnumerable<BidViewModel> bidList = new List<BidViewModel>();
         this.bidServiceMock.Setup(x => x.GetBidList(jobId, It.IsAny<bool>())).Returns(Task.FromResult(bidList));

         // Act
         var result = await this.controller.GetBidList(jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidList(jobId, true), Times.Once);
      }

      [Fact]
      public async Task GetBidList_InValidJobId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         IEnumerable<BidViewModel> bidList = new List<BidViewModel>();
         this.bidServiceMock.Setup(x => x.GetBidList(jobId, It.IsAny<bool>())).Returns(Task.FromResult(bidList));

         // Act
         var result = await this.controller.GetBidList(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidList(jobId, true), Times.Never);
      }

      [Fact]
      public async Task GetBid_InValidParameters_ReturnsBadRequest()
      {
         // Arrange         

         // Act
         IActionResult bothBadResult = await this.controller.GetBid(0, 0);
         IActionResult badJobIdResult = await this.controller.GetBid(0, 1);
         IActionResult badBidIdResult = await this.controller.GetBid(1, 0);

         // Assert
         Assert.IsType<BadRequestObjectResult>(bothBadResult);
         BadRequestObjectResult typed = bothBadResult as BadRequestObjectResult;
         Assert.Equal("Invalid Request. JobId/BidAlternate '0/0' is not valid", typed.Value);
         Assert.IsType<BadRequestObjectResult>(badJobIdResult);
         typed = badJobIdResult as BadRequestObjectResult;
         Assert.Equal("Invalid Request. JobId/BidAlternate '0/1' is not valid", typed.Value);
         Assert.IsType<BadRequestObjectResult>(badBidIdResult);
         typed = badBidIdResult as BadRequestObjectResult;
         Assert.Equal("Invalid Request. JobId/BidAlternate '1/0' is not valid", typed.Value);
         this.bidServiceMock.Verify(x => x.GetBid(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task GetBid_ValidParametersAndBid_ReturnsOk()
      {
         // Arrange
         int validJob = 123;
         int validBid = 456;
         BidViewModel ourBlessedBid = new BidViewModel();
         this.bidServiceMock.Setup(b => b.GetBid(validJob, validBid)).Returns(Task.FromResult(ourBlessedBid));

         // Act
         IActionResult result = await this.controller.GetBid(validJob, validBid);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         OkObjectResult typedResult = result as OkObjectResult;
         Assert.Equal(ourBlessedBid, typedResult.Value);
         this.bidServiceMock.Verify(x => x.GetBid(validJob, validBid), Times.Once);
      }

      [Fact]
      public async Task GetBid_ValidParametersAndNoBid_ReturnsNoContent()
      {
         // Arrange
         int validJob = 123;
         int validBid = 456;
         this.bidServiceMock.Setup(b => b.GetBid(validJob, validBid)).Returns(Task.FromResult<BidViewModel>(null));

         // Act
         IActionResult result = await this.controller.GetBid(validJob, validBid);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify(x => x.GetBid(validJob, validBid), Times.Once);
      }

      [Fact]
      public async Task UpdateCurrentBidStatus_ValidInput_ReturnsOkResult()
      {
         // Arrange
         int jobId = 11466;
         int bidAlternateId = 1432;
         int updateStatus = 1;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateCurrentBidCommand>(), default(CancellationToken)))
               .Returns(Task.FromResult(updateStatus));

         // Act
         var result = await this.controller.UpdateCurrentBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, updateStatus);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateCurrentBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task UpdateCurrentBidStatus_ValidInput_RecordsNotUpdated_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 11466;
         int bidAlternateId = 1432;
         int updateStatus = 0;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateCurrentBidCommand>(), default(CancellationToken)))
               .Returns(Task.FromResult(updateStatus));

         // Act
         var result = await this.controller.UpdateCurrentBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateCurrentBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Theory]
      [InlineData(0, 500)]
      [InlineData(500, 0)]
      [InlineData(0, 0)]
      public async Task UpdateCurrentBidStatus_InvalidInput_ReturnsBadRequest(int jobId, int bidAlternateId)
      {
         // Arrange
         int updateStatus = 0;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateCurrentBidCommand>(), default(CancellationToken)))
               .Returns(Task.FromResult(updateStatus));

         // Act
         var result = await this.controller.UpdateCurrentBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateCurrentBidCommand>(), default(CancellationToken)), Times.Never);
      }

      [Fact]
      public async Task CreateBid_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         int result = 1;
         var bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 178456,
            BidName = "LO",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "LO Desc",
            IncludeInCJ = 0,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(1)).Verifiable();

         // Act
         var actionResult = await this.controller.CreateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal(((ObjectResult)actionResult).Value, result);
         Assert.IsType<OkObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task CreateBid_EmptyRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         global::BidService.Core.ViewModels.BidCreateModel bidList = null;

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.CreateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.False(((BadRequestObjectResult)actionResult).Value.Equals(result));
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)), Times.Never);
      }

      [Fact]
      public async Task CreateBid_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         global::BidService.Core.ViewModels.BidCreateModel bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 1212,
            BidName = string.Empty,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.CreateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_ValidInput_ReturnsOkResult()
      {
         // Arrange
         int jobId = 1212;
         int bidAlternateId = 1421;
         var deletedStatus = 1;
         this.bidServiceMock.Setup(x => x.DeleteBid(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));

         // Act
         var result = await this.controller.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.bidServiceMock.Verify(x => x.DeleteBid(jobId, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_ValidInput_HasNoRecords_ReturnsNotFound()
      {
         // Arrange
         int jobId = 7654;
         int bidAlternateId = 79230;
         var deletedStatus = 0;
         this.bidServiceMock.Setup(x => x.DeleteBid(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));

         // Act
         var result = await this.controller.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.bidServiceMock.Verify(x => x.DeleteBid(jobId, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_InvalidInput_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         int bidAlternateId = 0;
         var deletedStatus = 0;
         this.bidServiceMock.Setup(x => x.DeleteBid(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));

         // Act
         var result = await this.controller.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.DeleteBid(jobId, bidAlternateId), Times.Never);
      }

      [Fact]
      public async Task UpdateBid_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         int result = 1;
         var bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 27671,
            BidName = "Air Bids",
            BaseBidYesNo = 0,
            BidAlternateId = 657347,
            CurrentBidInd = "N",
            Description = "Air Bids Desc",
            IncludeInCJ = 0,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(1)).Verifiable();

         // Act
         var actionResult = await this.controller.UpdateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal(((ObjectResult)actionResult).Value, result);
         Assert.IsType<OkObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task UpdateBid_EmptyRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         var bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 27671,
            BidName = "Airs Bids",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "Airs Bids Desc",
            IncludeInCJ = 0,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.UpdateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.False(((BadRequestObjectResult)actionResult).Value.Equals(result));
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)), Times.Never);
      }

      [Fact]
      public async Task UpdateBid_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         global::BidService.Core.ViewModels.BidCreateModel bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 1212,
            BidName = string.Empty,
            BidAlternateId = 657347
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.UpdateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task GetBidSelections_ValidJobId_ReturnsBidSelections()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidSelectionsViewModel> bidSelections = new List<BidSelectionsViewModel>
            {
                    new BidSelectionsViewModel()
                    {
                      BidAlternateId = 657058,
                    }
            };
         this.bidServiceMock.Setup(x => x.GetBidSelections(jobId)).Returns(Task.FromResult(bidSelections)).Verifiable();

         // Act
         var result = await this.controller.GetBidSelections(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, bidSelections);
         this.bidServiceMock.Verify();
      }

      [Fact]
      public async Task GetBidSelections_ValidJobId_ReturnsNoContent()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidSelectionsViewModel> bidSelections = new List<BidSelectionsViewModel>();
         this.bidServiceMock.Setup(x => x.GetBidSelections(jobId)).Returns(Task.FromResult(bidSelections)).Verifiable();

         // Act
         var result = await this.controller.GetBidSelections(jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify();
      }

      [Fact]
      public async Task GetBidSelections_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;

         // Act
         var result = await this.controller.GetBidSelections(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidSelections(It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task AddSelections_ValidRequest_ReturnsOk()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         List<SeparatelyBiddableViewModel> separatelyBiddableIds = new List<SeparatelyBiddableViewModel>()
            {
                new SeparatelyBiddableViewModel()
                {
                    SeparatelyBiddableId = 3
                }
            };
         List<VariationViewModel> variationIds = new List<VariationViewModel>()
            {
                new VariationViewModel()
                {
                    VariationId = 7
                }
            };
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>()
            {
                new SelectionDetailsViewModel()
                {
                    SelectionId = 34,
                    ExcludeSelection = false,
                    SeparatelyBiddableViewModel = separatelyBiddableIds,
                    VariationViewModel = variationIds
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<AddSelectionsCommand>(), default))
             .Returns(Task.FromResult(true)).Verifiable();

         // Act
         var result = await this.controller.AddSelections(jobId, bidAlternateId, addSelection);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.mediatorMock.Verify();
      }

      [Fact]
      public async Task AddSelections_RecordNotInserted_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         List<SeparatelyBiddableViewModel> separatelyBiddableIds = new List<SeparatelyBiddableViewModel>()
            {
                new SeparatelyBiddableViewModel()
                {
                    SeparatelyBiddableId = 3
                }
            };
         List<VariationViewModel> variationIds = new List<VariationViewModel>()
            {
                new VariationViewModel()
                {
                    VariationId = 7
                }
            };
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>()
            {
                new SelectionDetailsViewModel()
                {
                    SelectionId = 34,
                    ExcludeSelection = false,
                    SeparatelyBiddableViewModel = separatelyBiddableIds,
                    VariationViewModel = variationIds
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<AddSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false)).Verifiable();

         // Act
         var result = await this.controller.AddSelections(jobId, bidAlternateId, addSelection);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify();
      }

      /// <summary>
      /// Verifies the ok response when the request is valid
      /// </summary>
      /// <returns>Ok response</returns>
      [Fact]
      public async Task AddJobVariation_ValidRequest_ReturnsOk()
      {
         // Arrange
         int jobId = 5487;
         List<JobVariationViewModel> jobVariations = new List<JobVariationViewModel>()
            {
                new JobVariationViewModel()
                {
                    VariationId = 11,
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            JobVariations = jobVariations
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<AddSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(true));

         // Act
         var result = await this.controller.AddJobVariation(jobId, addSelection);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<AddSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      /// <summary>
      /// Verifies the bad request response when request is null
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task AddSelections_NullRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         AddSelectionViewModel addSelection = null;

         // Act
         var result = await this.controller.AddSelections(jobId, bidAlternateId, addSelection);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<AddSelectionsCommand>(), default), Times.Never);
      }

      /// <summary>
      /// Verifies the bad request response when command returns false
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task AddJobVariation_CommandReturnsFalse_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 5487;
         List<JobVariationViewModel> jobVariations = new List<JobVariationViewModel>()
            {
                new JobVariationViewModel()
                {
                    VariationId = 11,
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            JobVariations = jobVariations
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<AddSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false));

         // Act
         var result = await this.controller.AddJobVariation(jobId, addSelection);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<AddSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      /// <summary>
      /// Verifies the bad request response when null request
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task AddJobVariation_NullRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 6489;
         AddSelectionViewModel addSelection = null;

         // Act
         var result = await this.controller.AddJobVariation(jobId, addSelection);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<AddSelectionsCommand>(), default(CancellationToken)), Times.Never);
      }

      [Fact]
      public async Task DeleteSelections_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
         List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
         int jobId = 28643;
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
         {
            RemoveSelectionsRequest = removeSelectionsRequest,
            RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest
         };
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(true));

         // Act
         var result = await this.controller.DeleteSelections(jobId, bidAlternateId, removeAllSelectionsRequest);

         // Assert
         Assert.True((bool)((ObjectResult)result).Value);
         Assert.IsType<OkObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteSelections_ValidRequest_HasNoRecordsToDelete_ReturnsNotFound()
      {
         // Arrange
         List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
         List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
         int jobId = 28643;
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
         {
            RemoveSelectionsRequest = removeSelectionsRequest,
            RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest
         };
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false));

         // Act
         var result = await this.controller.DeleteSelections(jobId, bidAlternateId, removeAllSelectionsRequest);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteSelections_InValidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 28643;
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = null;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false));

         // Act
         var result = await this.controller.DeleteSelections(jobId, bidAlternateId, removeAllSelectionsRequest);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Never);
      }

      /// <summary>
      /// Verifies for the Ok response when the request is valid and records exist for the requested job id
      /// </summary>
      /// <returns>Ok response</returns>
      [Fact]
      public async Task GetBidsForCoodination_ValidRequestWithBidData_ReturnsOkResponse()
      {
         // Arrange
         int jobId = 574777;
         IEnumerable<CoordinationJobBidViewModel> bidsForCoordination = new List<CoordinationJobBidViewModel>
            {
                CommonHelper.GetCoordinationJobBidViewModel(967914, "Base bid", true, true, true)
            };
         this.bidServiceMock.Setup(x => x.GetBidsForCoordination(jobId)).Returns(Task.FromResult(bidsForCoordination));

         // Act
         var result = await this.controller.GetBidsForCoodination(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, bidsForCoordination);
         this.bidServiceMock.Verify(x => x.GetBidsForCoordination(jobId), Times.Once);
      }

      /// <summary>
      /// Verifies for the no content response when the request is valid and no records exist for the requested job id
      /// </summary>
      /// <returns>No content response</returns>
      [Fact]
      public async Task GetBidsForCoodination_ValidRequestWithoutBidData_ReturnsNoContentResponse()
      {
         // Arrange
         int jobId = 57;
         IEnumerable<CoordinationJobBidViewModel> bidsForCoordination = Enumerable.Empty<CoordinationJobBidViewModel>();
         this.bidServiceMock.Setup(x => x.GetBidsForCoordination(jobId)).Returns(Task.FromResult(bidsForCoordination));

         // Act
         var result = await this.controller.GetBidsForCoodination(jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidsForCoordination(jobId), Times.Once);
      }

      /// <summary>
      /// Verifies for the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task GetBidsForCoodination_InvalidRequest_ReturnsBadRequestResponse()
      {
         // Arrange
         int jobId = 0;

         // Act
         var result = await this.controller.GetBidsForCoodination(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidsForCoordination(jobId), Times.Never);
      }

      /// <summary>
      /// Update the job coordination status for bids - Success
      /// </summary>
      /// <returns>No content</returns>
      [Fact]
      public async Task UpdateJobCoordinationStatusForBids_ValidRequest_ReturnsNoContent()
      {
         // Arrange
         IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsView = new List<JobCoordinationStatusForBidsViewModel>()
            {
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 1,
                    DrAddressId = 101,
                    BidAlternateId = 1,
                    IsBidInCoordinationJob = true
                },
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 2,
                    DrAddressId = 101,
                    BidAlternateId = 0,
                    IsBidInCoordinationJob = false
                }
            };

         UpdateJobCoordinationStatusForBidsCommand updateJobCoordinationStatusForBids = new UpdateJobCoordinationStatusForBidsCommand(jobCoordinationStatusForBidsView);
         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateJobCoordinationStatusForBidsCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(true));

         // Act
         var actionResult = await this.controller.UpdateJobCoordinationStatusForBids(updateJobCoordinationStatusForBids);

         // Assert
         Assert.IsType<NoContentResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateJobCoordinationStatusForBidsCommand>(), default(CancellationToken)), Times.Once);
      }

      /// <summary>
      /// Update the job coordination status for bids - Failure
      /// </summary>
      /// <returns>Bad Request</returns>
      [Fact]
      public async Task UpdateJobCoordinationStatusForBids_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         UpdateJobCoordinationStatusForBidsCommand updateJobCoordinationStatusForBids = null;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateJobCoordinationStatusForBidsCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(true));

         // Act
         var actionResult = await this.controller.UpdateJobCoordinationStatusForBids(updateJobCoordinationStatusForBids);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateJobCoordinationStatusForBidsCommand>(), default(CancellationToken)), Times.Never);
      }

      /// <summary>
      /// Update the job coordination status for bids - Failure
      /// </summary>
      /// <returns>Bad Request</returns>
      [Fact]
      public async Task UpdateJobCoordinationStatusForBids_ValidRequestWithInvalidInput_ReturnsBadRequest()
      {
         // Arrange
         IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsView = new List<JobCoordinationStatusForBidsViewModel>()
            {
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 0,
                    DrAddressId = 0,
                    BidAlternateId = 0,
                    IsBidInCoordinationJob = false
                }
            };

         UpdateJobCoordinationStatusForBidsCommand updateJobCoordinationStatusForBids = new UpdateJobCoordinationStatusForBidsCommand(jobCoordinationStatusForBidsView);
         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateJobCoordinationStatusForBidsCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(false));

         // Act
         var actionResult = await this.controller.UpdateJobCoordinationStatusForBids(updateJobCoordinationStatusForBids);

         // Assert
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateJobCoordinationStatusForBidsCommand>(), default(CancellationToken)), Times.Once);
      }

      /// <summary>
      /// Verifies the ok response when the request is valid and contains the bid selection details
      /// </summary>
      /// <returns>Ok response</returns>
      [Fact]
      public async Task GetBidSelectionDetails_ValidRequestHasBidSelectionDetails_ReturnsOkResponse()
      {
         // Arrange
         IEnumerable<int> bidIds = new List<int>()
            {
               188619, 188630, 188631
            };
         IEnumerable<BidSelectionDetailsViewModel> bidSelectionDetails = new List<BidSelectionDetailsViewModel>()
            {
               CommonHelper.GetBidSelectionDetailsViewModel()
            };
         this.bidServiceMock.Setup(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(bidSelectionDetails));

         // Act
         var result = await this.controller.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, bidSelectionDetails);
         this.bidServiceMock.Verify(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>()), Times.Once);
      }

      /// <summary>
      /// Verifies the no content response when the request is valid and contains no bid selection details
      /// </summary>
      /// <returns>No content response</returns>
      [Fact]
      public async Task GetBidSelectionDetails_ValidRequestHasNoBidSelectionDetails_ReturnsNoContentResponse()
      {
         // Arrange
         IEnumerable<int> bidIds = new List<int>()
            {
               1886
            };
         IEnumerable<BidSelectionDetailsViewModel> bidSelectionDetails = Enumerable.Empty<BidSelectionDetailsViewModel>();
         this.bidServiceMock.Setup(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(bidSelectionDetails));

         // Act
         var result = await this.controller.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>()), Times.Once);
      }

      /// <summary>
      /// Verifies the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task GetBidSelectionDetails_InvalidRequest_ReturnsBadRequestResponse()
      {
         // Arrange
         IEnumerable<int> bidIds = Enumerable.Empty<int>();

         // Act
         var result = await this.controller.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>()), Times.Never);
      }

      [Fact]
      public async Task DeleteJobVariation_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         List<RemoveVariationsRequestViewModel> removeVariationRequest = new List<RemoveVariationsRequestViewModel>
            {
                new RemoveVariationsRequestViewModel() { VariationId = 195687 },
            };
         int jobId = 28643;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
         {
            RemoveVariationsRequest = removeVariationRequest
         };
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(true));

         // Act
         var result = await this.controller.DeleteJobVariation(jobId, removeAllSelectionsRequest);

         // Assert
         Assert.True((bool)((ObjectResult)result).Value);
         Assert.IsType<OkObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteJobVariation_ValidRequestWithNoRecords_ReturnsNotFound()
      {
         // Arrange
         List<RemoveVariationsRequestViewModel> removeVariationRequest = new List<RemoveVariationsRequestViewModel>
            {
                new RemoveVariationsRequestViewModel() { VariationId = 197821 },
            };
         int jobId = 28792;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
         {
            RemoveVariationsRequest = removeVariationRequest
         };
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false));

         // Act
         var result = await this.controller.DeleteJobVariation(jobId, removeAllSelectionsRequest);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteJobVariation_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 28643;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = null;

         // Act
         var result = await this.controller.DeleteJobVariation(jobId, removeAllSelectionsRequest);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }
   }
}