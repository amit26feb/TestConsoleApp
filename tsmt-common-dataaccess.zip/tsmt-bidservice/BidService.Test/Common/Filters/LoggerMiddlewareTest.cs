﻿// <copyright file="LoggerMiddlewareTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Common.Filters
{
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using BidService.Common.Middlewares;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Logger middleware test
    /// </summary>
    public class LoggerMiddlewareTest
    {
        /// <summary>
        /// Logger middleware mock
        /// </summary>
        private readonly Mock<ILogger<LoggerMiddleware>> loggerMock;

        /// <summary>
        /// Http request mock
        /// </summary>
        private readonly Mock<HttpRequest> requestMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggerMiddlewareTest"/> class.
        /// Logger middleware test
        /// </summary>
        public LoggerMiddlewareTest()
        {
            this.loggerMock = new Mock<ILogger<LoggerMiddleware>>();
            this.requestMock = new Mock<HttpRequest>();
        }

        /// <summary>
        /// It should log request
        /// </summary>
        [Fact]
        public async void It_Should_Log_Request()
        {
            this.requestMock.Setup(x => x.Scheme).Returns("http");
            this.requestMock.Setup(x => x.Host).Returns(new HostString("localhost"));
            this.requestMock.Setup(x => x.Path).Returns(new PathString("/test"));
            this.requestMock.Setup(x => x.PathBase).Returns(new PathString("/"));
            this.requestMock.Setup(x => x.Method).Returns("GET");
            this.requestMock.Setup(x => x.Body).Returns(new MemoryStream());
            this.requestMock.Setup(x => x.QueryString).Returns(new QueryString("?param1=1"));
            var contextMock = new Mock<HttpContext>();
            var claims = new List<Claim>()
            {
                new Claim("samAccountName", "user")
            };
            contextMock.Setup(x => x.Response.Body).Returns(new MemoryStream());
            contextMock.Setup(x => x.Request).Returns(this.requestMock.Object);
            contextMock.Setup(x => x.User.Claims).Returns(claims);
            contextMock.Setup(x => x.Response.StatusCode).Returns(200);
            var loggerMiddleware = new LoggerMiddleware(next: (innerHttpContext) => Task.FromResult(0), logger: this.loggerMock.Object);
            await loggerMiddleware.Invoke(contextMock.Object);

            Assert.NotNull(contextMock);
            this.requestMock.Verify();
        }
    }
}
