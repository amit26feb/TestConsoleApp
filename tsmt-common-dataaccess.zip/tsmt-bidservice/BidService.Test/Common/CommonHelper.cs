﻿// <copyright file="CommonHelper.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Common
{
   using System.Collections.Generic;
   using BidService.Core.Models;
   using BidService.Core.ViewModels;

   public static class CommonHelper
   {
      /// <summary>
      /// Gets coordination job bid view model
      /// </summary>
      /// <param name="bidId">Bid alternate id</param>
      /// <param name="bidName">Bid name</param>
      /// <param name="isCurrentBid">Indicates whether the bid is current or not</param>
      /// <param name="isBaseBid">Indicates whether this is the base bid</param>
      /// <param name="isBidInCoordinationJob">Indicates whether the bid is included for job coordination</param>
      /// <returns>Coordination job bid view model</returns>
      public static CoordinationJobBidViewModel GetCoordinationJobBidViewModel(int bidId, string bidName, bool isCurrentBid, bool isBaseBid, bool? isBidInCoordinationJob)
      {
         return new CoordinationJobBidViewModel()
         {
            BidAlternateId = bidId,
            BidName = bidName,
            IsCurrentBid = isCurrentBid,
            IsBaseBid = isBaseBid,
            IsBidInCoordinationJob = isBidInCoordinationJob
         };
      }

      /// <summary>
      /// Gets coordination job bid
      /// </summary>
      /// <param name="bidId">Bid alternate id</param>
      /// <param name="bidName">Bid name</param>
      /// <param name="isCurrentBid">Indicates whether the bid is current or not</param>
      /// <param name="isBaseBid">Indicates whether the bid is considered the base bid</param>
      /// <param name="isBidInCoordinationJob">Indicates whether the bid is included for job coordination</param>
      /// <returns>Coordination job bid</returns>
      public static CoordinationJobBid GetCoordinationJobBid(int bidId, string bidName, string isCurrentBid, int isBaseBid, int? isBidInCoordinationJob)
      {
         return new CoordinationJobBid()
         {
            BID_ALTERNATE_ID = bidId,
            BID_NAME = bidName,
            CURRENT_BID_IND = isCurrentBid,
            BASE_BID_YES_NO = isBaseBid,
            INCLUDE_IN_CJ = isBidInCoordinationJob
         };
      }

      /// <summary>
      /// Gets the bid selection details view model
      /// </summary>
      /// <returns>Bid selection details view model</returns>
      public static BidSelectionDetailsViewModel GetBidSelectionDetailsViewModel()
      {
         return new BidSelectionDetailsViewModel()
         {
            BidAlternateId = 1234,
            BidName = "Rebid",
            SelectionIds = new List<int> { 230733, 319529 }
         };
      }

      /// <summary>
      /// Get bid selection details
      /// </summary>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="selectionId">Selection id</param>
      /// <param name="selectionType">Selection type</param>
      /// <returns>Bid selection details</returns>
      public static BidSelectionDetails GetBidSelectionDetails(int bidAlternateId, int selectionId, string selectionType)
      {
         return new BidSelectionDetails()
         {
            BID_ALTERNATE_ID = bidAlternateId,
            BID_NAME = "Rebid",
            SELECTION_ID = selectionId,
            SELECTION_TYPE = selectionType
         };
      }
   }
}
