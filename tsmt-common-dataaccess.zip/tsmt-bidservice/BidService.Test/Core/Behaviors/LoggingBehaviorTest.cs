﻿// <copyright file="LoggingBehaviorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Behaviors
{
    using System.Threading;
    using System.Threading.Tasks;
    using BidService.Core.Behaviors;
    using MediatR;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    /// <summary>
    /// Logging behavior test
    /// </summary>
    public class LoggingBehaviorTest
    {
        /// <summary>
        /// Logger mock
        /// </summary>
        private readonly Mock<ILogger<LoggingBehavior<Request, Response>>> mockLogger;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggingBehaviorTest"/> class.
        /// Logging behavior test
        /// </summary>
        public LoggingBehaviorTest()
        {
            this.mockLogger = new Mock<ILogger<LoggingBehavior<Request, Response>>>();
        }

        /// <summary>
        /// Success task
        /// </summary>
        /// <returns>Logging behavior</returns>
        [Fact]
        public async Task Success()
        {
            LoggingBehavior<Request, Response> loggingBehavior = new LoggingBehavior<Request, Response>(this.mockLogger.Object);

            Request ping = new Request
            {
                Message = "test request"
            };
            Response pong = new Response
            {
                Message = "test response"
            };
            CancellationToken cancellationToken = default(CancellationToken);
            var response = await loggingBehavior.Handle(ping, cancellationToken, next: () => Task.FromResult(pong));

            Assert.NotNull(response);
            Assert.Equal(response.Message, pong.Message);
        }
    }

    #pragma warning disable SA1402 // File may only contain a single class
    /// <summary>
    /// Request details
    /// </summary>
    public class Request : IRequest<Response>
    #pragma warning restore SA1402 // File may only contain a single class
    {
        /// <summary>
        /// Gets or sets the request message
        /// </summary>
        public string Message { get; set; }
    }

    #pragma warning disable SA1402 // File may only contain a single class
    /// <summary>
    /// Response details
    /// </summary>
    public class Response
    #pragma warning restore SA1402 // File may only contain a single class
    {
        /// <summary>
        /// Gets or sets the response message
        /// </summary>
        public string Message { get; set; }
    }
}
