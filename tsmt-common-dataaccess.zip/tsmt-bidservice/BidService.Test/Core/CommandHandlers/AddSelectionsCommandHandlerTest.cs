﻿// <copyright file="AddSelectionsCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.CommandHandlers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using BidService.Common.Constants;
   using BidService.Core.Command;
   using BidService.Core.CommandHandlers;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class AddSelectionsCommandHandlerTest
   {
      private readonly Mock<ILogger<AddSelectionsCommand>> loggerMock;
      private readonly Mock<IBidService> bidServiceMock;
      private readonly Mock<IJobsUpdateNotifier> jobsUpdateNotifierMock;

      /// <summary>
      /// Initializes a new instance of the <see cref="AddSelectionsCommandHandlerTest"/> class.
      /// </summary>
      public AddSelectionsCommandHandlerTest()
      {
         this.loggerMock = new Mock<ILogger<AddSelectionsCommand>>();
         this.bidServiceMock = new Mock<IBidService>();
         this.jobsUpdateNotifierMock = new Mock<IJobsUpdateNotifier>();
      }

      /// <summary>
      /// Test if selection is successfully added to bid
      /// </summary>
      /// <returns>True</returns>
      [Fact]
      public async Task Handle_AddSelections_Success()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         bool isBidAlternateIdValidationRequired = true;
         List<SeparatelyBiddableViewModel> separatelyBiddableIds = new List<SeparatelyBiddableViewModel>()
            {
                new SeparatelyBiddableViewModel()
                {
                    SeparatelyBiddableId = 3
                }
            };
         List<VariationViewModel> variationIds = new List<VariationViewModel>()
            {
                new VariationViewModel()
                {
                    VariationId = 7
                }
            };
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>()
            {
                new SelectionDetailsViewModel()
                {
                    SelectionId = 34,
                    ExcludeSelection = false,
                    SeparatelyBiddableViewModel = separatelyBiddableIds,
                    VariationViewModel = variationIds
                }
            };
         List<JobVariationViewModel> jobVariationViewModel = new List<JobVariationViewModel>()
            {
                new JobVariationViewModel()
                {
                    VariationId = 11,
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails,
            JobVariations = jobVariationViewModel
         };

         var fakeAddSelectionCommand = new AddSelectionsCommand(jobId, bidAlternateId, addSelection, isBidAlternateIdValidationRequired);

         bool returnResult = true;

         this.bidServiceMock.Setup(x => x.AddSelections(jobId, bidAlternateId, It.IsAny<AddSelectionViewModel>()))
            .Returns(Task.FromResult(returnResult)).Verifiable();
         this.jobsUpdateNotifierMock.Setup(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()))
            .Returns(Task.FromResult(Task.CompletedTask));
         var handler = new AddSelectionsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifierMock.Object);
         var cltToken = default(System.Threading.CancellationToken);

         // Act
         var result = await handler.Handle(fakeAddSelectionCommand, cltToken);

         // Assert
         Assert.Equal(returnResult, result);
         this.bidServiceMock.Verify();
         this.jobsUpdateNotifierMock.Verify(x => x.NotifyJobsUpdateRequestAsync(jobId, BidNotificationType.Edit, bidAlternateId, null), Times.Once);
      }

      /// <summary>
      /// Test if selection is not added to bid
      /// </summary>
      /// <returns>False</returns>
      [Fact]
      public async Task Handle_AddSelections_Failure()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         bool isBidAlternateIdValidationRequired = true;
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>()
            {
                new SelectionDetailsViewModel()
                {
                    SelectionId = 34,
                    ExcludeSelection = false
                }
            };

         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails
         };

         var fakeAddSelectionCommand = new AddSelectionsCommand(jobId, bidAlternateId, addSelection, isBidAlternateIdValidationRequired);

         bool returnResult = false;

         this.bidServiceMock.Setup(x => x.AddSelections(jobId, bidAlternateId, It.IsAny<AddSelectionViewModel>()))
             .Returns(Task.FromResult(returnResult)).Verifiable();
         var handler = new AddSelectionsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifierMock.Object);
         var cltToken = default(System.Threading.CancellationToken);

         // Act
         var result = await handler.Handle(fakeAddSelectionCommand, cltToken);

         // Assert
         Assert.Equal(returnResult, result);
         this.bidServiceMock.Verify();
         this.jobsUpdateNotifierMock.Verify(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
      }

      [Fact]
      public async Task Handle_IsBidAlternateIdValidationRequiredFlagIsFalse_NotifyJobsUpdateRequestAsyncNotCalled()
      {
         // Arrange
         int jobId = 6784;
         int bidAlternateId = 3738;
         bool isBidAlternateIdValidationRequired = false;
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = new List<SelectionDetailsViewModel>()
         };

         this.bidServiceMock.Setup(x => x.AddSelections(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<AddSelectionViewModel>()))
             .Returns(Task.FromResult(true));
         var fakeAddSelectionCommand = new AddSelectionsCommand(jobId, bidAlternateId, addSelection, isBidAlternateIdValidationRequired);
         var handler = new AddSelectionsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifierMock.Object);
         var cltToken = default(System.Threading.CancellationToken);

         // Act
         var result = await handler.Handle(fakeAddSelectionCommand, cltToken);

         // Assert
         Assert.True(result);
         this.bidServiceMock.Verify(x => x.AddSelections(jobId, bidAlternateId, It.IsAny<AddSelectionViewModel>()), Times.Once);
         this.jobsUpdateNotifierMock.Verify(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
      }
   }
}