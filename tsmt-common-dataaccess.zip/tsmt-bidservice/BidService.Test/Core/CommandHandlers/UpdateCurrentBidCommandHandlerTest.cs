﻿// <copyright file="UpdateCurrentBidCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.CommandHandlers
{
   using System.Threading.Tasks;
   using BidService.Common.Constants;
   using BidService.Core.CommandHandlers;
   using BidService.Core.Commands;
   using BidService.Core.Services;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class UpdateCurrentBidCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateCurrentBidCommand>> loggerMock;
        private readonly Mock<IBidService> bidServiceMock;
        private readonly Mock<IJobsUpdateNotifier> jobsUpdateNotifier;

        public UpdateCurrentBidCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateCurrentBidCommand>>();
            this.bidServiceMock = new Mock<IBidService>();
            this.jobsUpdateNotifier = new Mock<IJobsUpdateNotifier>();
        }

        /// <summary>
        /// Tests successful updation of current status
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task Handle_UpdateCurrentBid_Success()
        {
            // Arrange
            int jobId = 1238;
            int bidAlternateId = 1432;
            var fakeUpdateCurrentBidCommand = new UpdateCurrentBidCommand(jobId, bidAlternateId);

            int updateStatus = 1;

            this.bidServiceMock.Setup(x => x.UpdateCurrentBid(It.IsAny<int>(), It.IsAny<int>()))
                .Returns(Task.FromResult(updateStatus));
            this.jobsUpdateNotifier.Setup(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()))
                .Returns(Task.FromResult(Task.CompletedTask));

            // Act
            var handler = new UpdateCurrentBidCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifier.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeUpdateCurrentBidCommand, cltToken);

            // Assert
            Assert.Equal(updateStatus, result);
            this.bidServiceMock.Verify(x => x.UpdateCurrentBid(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
            this.jobsUpdateNotifier.Verify(x => x.NotifyJobsUpdateRequestAsync(jobId, BidNotificationType.Edit, bidAlternateId, null), Times.Once);
        }

        /// <summary>
        /// Tests unsuccessful updation of current bid status for invalid input
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task Handle_UpdateJobGeneral_InvalidId()
        {
            // Arrange
            int jobId = 1238;
            int bidAlternateId = 0;
            var fakeUpdateCurrentBidCommand = new UpdateCurrentBidCommand(jobId, bidAlternateId);

            int updateStatus = 0;

            this.bidServiceMock.Setup(x => x.UpdateCurrentBid(It.IsAny<int>(), It.IsAny<int>()))
                .Returns(Task.FromResult(updateStatus));

            // Act
            var handler = new UpdateCurrentBidCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifier.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeUpdateCurrentBidCommand, cltToken);

            // Assert
            Assert.Equal(updateStatus, result);
            this.bidServiceMock.Verify(x => x.UpdateCurrentBid(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
            this.jobsUpdateNotifier.Verify(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
        }
    }
}
