﻿// <copyright file="UpdateJobCoordinationStatusForBidsCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.CommandHandlers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;
    using BidService.Core.Command;
    using BidService.Core.CommandHandlers;
    using BidService.Core.Commands;
    using BidService.Core.Services;
    using BidService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class UpdateJobCoordinationStatusForBidsCommandHandlerTest
    {
        private readonly Mock<ILogger<UpdateJobCoordinationStatusForBidsCommand>> loggerMock;
        private readonly Mock<IBidService> bidServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref=UpdateJobCoordinationStatusForBidsCommandHandlerTest"/> class.
        /// </summary>
        public UpdateJobCoordinationStatusForBidsCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<UpdateJobCoordinationStatusForBidsCommand>>();
            this.bidServiceMock = new Mock<IBidService>();
        }

        /// <summary>
        /// Update job coordination status for bids - Success
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task UpdateJobCoordinationStatusForBidsCommandHandler_ValidInput_ReturnsTrue()
        {
            // Arrange
            IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsView = new List<JobCoordinationStatusForBidsViewModel>()
            {
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 1,
                    DrAddressId = 101,
                    BidAlternateId = 1,
                    IsBidInCoordinationJob = true
                },
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 2,
                    DrAddressId = 101,
                    BidAlternateId = 0,
                    IsBidInCoordinationJob = true
                }
            };
            var fakeBidUpdateCommand = new UpdateJobCoordinationStatusForBidsCommand(jobCoordinationStatusForBidsView);

            this.bidServiceMock.Setup(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBidsViewModel>>()))
                .Returns(Task.FromResult(true));
            var handler = new UpdateJobCoordinationStatusForBidsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);

            // Act
            var result = await handler.Handle(fakeBidUpdateCommand, cltToken);

            // Assert
            Assert.True(result);
            this.bidServiceMock.Verify(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBidsViewModel>>()), Times.Once);
        }

        /// <summary>
        /// Update job coordination status for bids - Failure
        /// </summary>
        /// <returns>False</returns>
        [Fact]
        public async Task UpdateJobCoordinationStatusForBidsCommandHandler_InvalidInput_ReturnsFalse()
        {
            // Arrange
            IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsView = null;
            var fakeBidUpdateCommand = new UpdateJobCoordinationStatusForBidsCommand(jobCoordinationStatusForBidsView);

            this.bidServiceMock.Setup(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBidsViewModel>>()))
                .Returns(Task.FromResult(false));
            var handler = new UpdateJobCoordinationStatusForBidsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object);
            var cltToken = default(System.Threading.CancellationToken);

            // Act
            var result = await handler.Handle(fakeBidUpdateCommand, cltToken);

            // Assert
            Assert.False(result);
            this.bidServiceMock.Verify(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBidsViewModel>>()), Times.Once);
        }
    }
}