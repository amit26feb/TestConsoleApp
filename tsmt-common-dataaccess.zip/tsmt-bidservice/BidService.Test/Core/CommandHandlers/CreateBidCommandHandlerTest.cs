﻿// <copyright file="CreateBidCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.CommandHandlers
{
   using System.Threading.Tasks;
   using BidService.Common.Constants;
   using BidService.Core.Command;
   using BidService.Core.CommandHandlers;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class CreateBidCommandHandlerTest
    {
        private readonly Mock<ILogger<CreateBidCommand>> loggerMock;
        private readonly Mock<IBidService> bidServiceMock;
        private readonly Mock<IJobsUpdateNotifier> jobsUpdateNotifier;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateBidCommandHandlerTest"/> class.
        /// </summary>
        public CreateBidCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<CreateBidCommand>>();
            this.bidServiceMock = new Mock<IBidService>();
            this.jobsUpdateNotifier = new Mock<IJobsUpdateNotifier>();
        }

        /// <summary>
        /// Test successful creation of bid
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_CreateBid_Success()
        {
            // Arrange
            var bid = new BidCreateModel()
            {
                JobId = 178456,
                BidName = "LO",
                BaseBidYesNo = 0,
                BidAlternateId = 0,
                CurrentBidInd = "N",
                Description = "LO Desc",
                IncludeInCJ = 0,
            };

            var fakeBidCreateCommand = new CreateBidCommand(bid);

            int returnResult = 1;

            this.bidServiceMock.Setup(x => x.CreateBid(It.IsAny<BidCreateModel>()))
                .Returns(Task.FromResult(returnResult));
            this.jobsUpdateNotifier.Setup(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()))
                .Returns(Task.FromResult(Task.CompletedTask));

            // Act
            var handler = new CreateBidCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifier.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakeBidCreateCommand, cltToken);

            // Assert
            Assert.Equal(returnResult, result);
            this.bidServiceMock.Verify(x => x.CreateBid(It.IsAny<BidCreateModel>()), Times.Once);
            this.jobsUpdateNotifier.Verify(x => x.NotifyJobsUpdateRequestAsync(bid.JobId, BidNotificationType.Create, bid.BidAlternateId, bid.BidName), Times.Once);
        }

        /// <summary>
        /// Test unsuccessful creation of bid for invalid jobid
        /// </summary>
        /// <returns>Assertion Status</returns>
        [Fact]
        public async Task Handle_CreateJob_Invalid_JobId()
        {
            // Arrange
            var bidDetails = new BidCreateModel
            {
                JobId = 0
            };

            var fakecCreateJobCommand = new CreateBidCommand(bidDetails);

            int returnResult = 0;

            this.bidServiceMock.Setup(x => x.CreateBid(It.IsAny<BidCreateModel>()))
                .Returns(Task.FromResult(returnResult));

            // Act
            var handler = new CreateBidCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifier.Object);
            var cltToken = default(System.Threading.CancellationToken);
            var result = await handler.Handle(fakecCreateJobCommand, cltToken);

            // Assert
            Assert.Equal(returnResult, result);
            this.bidServiceMock.Verify(x => x.CreateBid(It.IsAny<BidCreateModel>()), Times.Once);
            this.jobsUpdateNotifier.Verify(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
        }
    }
}
