﻿// <copyright file="RemoveSelectionsCommandHandlerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.CommandHandlers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using BidService.Common.Constants;
    using BidService.Core.CommandHandlers;
    using BidService.Core.Commands;
    using BidService.Core.Services;
    using BidService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Moq;
    using Xunit;

    public class RemoveSelectionsCommandHandlerTest
    {
        private readonly Mock<ILogger<RemoveSelectionsCommand>> loggerMock;
        private readonly Mock<IBidService> bidServiceMock;
        private readonly Mock<IJobsUpdateNotifier> jobsUpdateNotifierMock;

        public RemoveSelectionsCommandHandlerTest()
        {
            this.loggerMock = new Mock<ILogger<RemoveSelectionsCommand>>();
            this.bidServiceMock = new Mock<IBidService>();
            this.jobsUpdateNotifierMock = new Mock<IJobsUpdateNotifier>();
        }

        /// <summary>
        /// Tests successful removal of selections
        /// </summary>
        /// <returns>Assertion status</returns>
        [Fact]
        public async Task Handle_RemoveSelections_Success()
        {
            // Arrange
            List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
            List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddableRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                 new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
            List<RemoveVariationsRequestViewModel> removeVariationRequest = new List<RemoveVariationsRequestViewModel>
            {
                 new RemoveVariationsRequestViewModel() { VariationId = 657589 },
            };
          int jobId = 28643;
          int bidAlternateId = 346545;
          bool isBidAlternateIdValidationRequired = true;
          RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
          {
             RemoveSelectionsRequest = removeSelectionsRequest,
             RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddableRequest,
             RemoveVariationsRequest = removeVariationRequest
          };
          var fakeRemoveSelectionsCommand = new RemoveSelectionsCommand(jobId, bidAlternateId, removeAllSelectionsRequest, isBidAlternateIdValidationRequired);

          bool isDeleted = true;

          this.bidServiceMock.Setup(x => x.DeleteSelections(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()))
              .Returns(Task.FromResult(isDeleted));
          this.jobsUpdateNotifierMock.Setup(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()))
  .Returns(Task.FromResult(Task.CompletedTask));
          var handler = new RemoveSelectionsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifierMock.Object);
          var cltToken = default(System.Threading.CancellationToken);

          // Act
          var result = await handler.Handle(fakeRemoveSelectionsCommand, cltToken);

          // Assert
          Assert.Equal(isDeleted, result);
          this.bidServiceMock.Verify(x => x.DeleteSelections(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()), Times.Once);
          this.jobsUpdateNotifierMock.Verify(x => x.NotifyJobsUpdateRequestAsync(jobId, BidNotificationType.Edit, bidAlternateId, null), Times.Once);
       }

       /// <summary>
       /// Tests unsuccessful removal of selections for invalid input
       /// </summary>
       /// <returns>Assertion status</returns>
       [Fact]
       public async Task Handle_RemoveSelections_Failure()
       {
          // Arrange
          List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>();
          List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>();
          List<RemoveVariationsRequestViewModel> removeVariationsRequest = new List<RemoveVariationsRequestViewModel>();

          int jobId = 28643;
          int bidAlternateId = 346545;
          bool isBidAlternateIdValidationRequired = true;
          RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
          {
             RemoveSelectionsRequest = removeSelectionsRequest,
             RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest,
             RemoveVariationsRequest = removeVariationsRequest
          };
          var fakeRemoveSelectionsCommand = new RemoveSelectionsCommand(jobId, bidAlternateId, removeAllSelectionsRequest, isBidAlternateIdValidationRequired);

          bool isDeleted = false;

          this.bidServiceMock.Setup(x => x.DeleteSelections(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()))
              .Returns(Task.FromResult(isDeleted));
          var handler = new RemoveSelectionsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifierMock.Object);
          var cltToken = default(System.Threading.CancellationToken);

          // Act
          var result = await handler.Handle(fakeRemoveSelectionsCommand, cltToken);

           // Assert
           Assert.Equal(isDeleted, result);
           this.bidServiceMock.Verify(x => x.DeleteSelections(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()), Times.Once);
           this.jobsUpdateNotifierMock.Verify(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
        }

      [Fact]
      public async Task Handle_IsBidAlternateIdValidationRequiredFlagIsFalse_NotifyJobsUpdateRequestAsyncNotCalled()
      {
         // Arrange
         int jobId = 6784;
         int bidAlternateId = 3738;
         bool isBidAlternateIdValidationRequired = false;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel();

         this.bidServiceMock.Setup(x => x.DeleteSelections(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()))
             .Returns(Task.FromResult(true));
         var fakeAddSelectionCommand = new RemoveSelectionsCommand(jobId, bidAlternateId, removeAllSelectionsRequest, isBidAlternateIdValidationRequired);
         var handler = new RemoveSelectionsCommandHandler(this.loggerMock.Object, this.bidServiceMock.Object, this.jobsUpdateNotifierMock.Object);
         var cltToken = default(System.Threading.CancellationToken);

         // Act
         var result = await handler.Handle(fakeAddSelectionCommand, cltToken);

         // Assert
         Assert.True(result);
         this.bidServiceMock.Verify(x => x.DeleteSelections(bidAlternateId, It.IsAny<RemoveAllSelectionsRequestViewModel>()), Times.Once);
         this.jobsUpdateNotifierMock.Verify(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>()), Times.Never);
      }
   }
}
