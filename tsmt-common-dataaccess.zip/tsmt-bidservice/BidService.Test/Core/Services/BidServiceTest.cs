// <copyright file="BidServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using BidService.Common.Constants;
   using BidService.Core.Models;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using BidService.Repository;
   using BidService.Test.Common;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using Xunit;

   public class BidServiceTest
   {
      private readonly Mock<IBidRepository> bidRepository;
      private readonly Mock<IHttpContextAccessor> contextAccessor;
      private readonly Mock<IJobsUpdateNotifier> jobsUpdateNotifier;
      private readonly IBidService bidService;

      public BidServiceTest()
      {
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<global::BidService.Configurations.AutoMapperConfiguration.AutoMapperProfile>();
         });
         var mapper = config.CreateMapper();

         this.bidRepository = new Mock<IBidRepository>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.jobsUpdateNotifier = new Mock<IJobsUpdateNotifier>();

         this.bidService = new BidService(this.bidRepository.Object, this.contextAccessor.Object, mapper, this.jobsUpdateNotifier.Object);
      }

      [Fact]
      public async Task GetBidList_ValidInput_HasEmptyCreditJobList_ReturnsBidList()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidViewModel> creditJobList = new List<BidViewModel>();

         IEnumerable<BidAlternate> bids = new List<BidAlternate>
         {
              new BidAlternate()
              {
                  BID_ALTERNATE_ID = 657058,
                  CURRENT_BID_IND = "Y",
                  BID_NAME = "Alt Bid",
                  DESCR = null,
                  HQTR_BID_ALTERNATE_ID = 3801159,
                  FOE2_CREATED_ORDERS_IND = "Y",
                  INCLUDE_IN_CJ = 1,
                  SELLING_PRICE = 0,
                  BASE_BID_YES_NO = 1
              }
         };

         this.bidRepository.Setup(x => x.GetBidListAsync(jobId))
             .Returns(Task.FromResult(bids));
         this.bidRepository.Setup(x => x.GetCreditJobListAsync(jobId))
             .Returns(Task.FromResult(creditJobList));

         // Act
         var result = await this.bidService.GetBidList(jobId, true);

         // Assert
         Assert.Equal(bids.Count(), result.Count());
         this.bidRepository.Verify(x => x.GetBidListAsync(jobId), Times.Once);
         this.bidRepository.Verify(x => x.GetCreditJobListAsync(jobId), Times.Once);
      }

      [Theory]
      [InlineData(false, 2)]
      [InlineData(true, 3)]
      public async Task GetBidList_GivenBidExistsWithMultipleCreditJobs_ReturnsBids(bool includeDuplicates, int expectedRecords)
      {
         // Arrange
         int jobId = 11555;
         IEnumerable<BidViewModel> creditJobList = new List<BidViewModel>
         {
              new BidViewModel()
              {
                   BidAlternateId = 657058,
                   CurrentBidInd = "Y",
                   BidName = "Alt Bid",
                   Description = null,
                   CreditJobNumber = "primary credit job",
                   SpaNumber = null,
                   PurchaseOrderNumber = "TEST567",
                   SellingPrice = 0,
                   BaseBidYesNo = 1,
                   HqtrCreditJobId = 2187875,
                   Foe2CreatedOrdersInd = "Y"
              },
              new BidViewModel()
              {
                   BidAlternateId = 657058,
                   CurrentBidInd = "Y",
                   BidName = "Alt Bid",
                   Description = null,
                   CreditJobNumber = "secondary credit job",
                   SpaNumber = null,
                   PurchaseOrderNumber = "TEST567",
                   SellingPrice = 0,
                   BaseBidYesNo = 1,
                   HqtrCreditJobId = 2187875,
                   Foe2CreatedOrdersInd = "Y"
              }
         };

         IEnumerable<BidAlternate> bids = new List<BidAlternate>
         {
            new BidAlternate()
            {
               BID_ALTERNATE_ID = 657058,
               CURRENT_BID_IND = "Y",
               BID_NAME = "Base Bid",
               DESCR = null,
               HQTR_BID_ALTERNATE_ID = 3801159,
               FOE2_CREATED_ORDERS_IND = "Y",
               LEGACY_JOB_NBR = "primary credit job",
               INCLUDE_IN_CJ = 0,
               SELLING_PRICE = 0,
               BASE_BID_YES_NO = 1
            },
            new BidAlternate()
            {
               BID_ALTERNATE_ID = 657059,
               CURRENT_BID_IND = "Y",
               BID_NAME = "Base Bid",
               DESCR = "Bid without a credit job",
               HQTR_BID_ALTERNATE_ID = 3801159,
               FOE2_CREATED_ORDERS_IND = "Y",
               LEGACY_JOB_NBR = null,
               INCLUDE_IN_CJ = 0,
               SELLING_PRICE = 0,
               BASE_BID_YES_NO = 1
            }
         };

         this.bidRepository.Setup(x => x.GetBidListAsync(jobId))
             .Returns(Task.FromResult(bids));
         this.bidRepository.Setup(x => x.GetCreditJobListAsync(jobId))
             .Returns(Task.FromResult(creditJobList));

         // Act
         var result = await this.bidService.GetBidList(jobId, includeDuplicates);

         // Assert
         Assert.Equal(expectedRecords, result.Count());
         this.bidRepository.Verify(x => x.GetCreditJobListAsync(It.IsAny<int>()), includeDuplicates ? Times.Once() : Times.Never());
      }

      [Fact]
      public async Task GetBidList_InValidInput_ReturnsEmptyList()
      {
         // Arrange
         int jobId = 2385;
         IEnumerable<BidAlternate> bidList = new List<BidAlternate>();

         this.bidRepository.Setup(x => x.GetBidListAsync(jobId))
             .Returns(Task.FromResult(bidList));

         IEnumerable<BidViewModel> creditJobList = new List<BidViewModel>();

         this.bidRepository.Setup(x => x.GetCreditJobListAsync(jobId))
             .Returns(Task.FromResult(creditJobList));

         // Act
         var result = await this.bidService.GetBidList(jobId, true);

         // Assert
         Assert.Empty(result);
         this.bidRepository.Verify(x => x.GetBidListAsync(jobId), Times.Once);
         this.bidRepository.Verify(x => x.GetCreditJobListAsync(jobId), Times.Never);
      }

      [Fact]
      public async Task GetBidList_GivenSearchCriteria_ReturnsBidList()
      {
         // Arrange
         BidSearchModel search = new BidSearchModel();
         IEnumerable<BidViewModel> expectedResults = new BidViewModel[] { new BidViewModel() };
         this.bidRepository.Setup(r => r.GetBidListAsync(It.IsAny<BidSearchModel>())).Returns(Task.FromResult(expectedResults));

         // Act
         var result = await this.bidService.GetBidList(search);

         // Assert
         Assert.Equal(expectedResults, result);
         this.bidRepository.Verify(x => x.GetBidListAsync(search), Times.Once);
      }

      [Fact]
      public async Task GetBid_RepoHasBidAndCreditJob_ReturnsThem()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;
         BidViewModel bid = new BidViewModel();
         this.bidRepository.Setup(x => x.GetBidAsync(jobId, bidId)).Returns(Task.FromResult(bid)).Verifiable();
         CreditJob creditJob1 = new CreditJob() { CreditJobNumber = "123", HqtrCreditJobId = 345, PurchaseOrderNumber = "foo" };
         CreditJob creditJob2 = new CreditJob() { CreditJobNumber = "456", HqtrCreditJobId = 655, PurchaseOrderNumber = "bar" };
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>() { creditJob1, creditJob2 };
         this.bidRepository.Setup(b => b.GetCreditJobsAsync(jobId, bidId)).Returns(Task.FromResult(creditJobs)).Verifiable();

         // Act
         BidViewModel result = await this.bidService.GetBid(jobId, bidId);

         // Assert
         Assert.Equal(bid, result);
         Assert.Equal(2, result.CreditJobs.Count);
         Assert.Contains(result.CreditJobs, cj => cj.CreditJobNumber == creditJob1.CreditJobNumber && cj.HqtrCreditJobId == creditJob1.HqtrCreditJobId && cj.PurchaseOrderNumber == creditJob1.PurchaseOrderNumber);
         Assert.Contains(result.CreditJobs, cj => cj.CreditJobNumber == creditJob2.CreditJobNumber && cj.HqtrCreditJobId == creditJob2.HqtrCreditJobId && cj.PurchaseOrderNumber == creditJob2.PurchaseOrderNumber);
         this.bidRepository.Verify();
      }

      [Fact]
      public async Task GetBid_RepoHasBidAndNoCreditJob_ReturnsBid()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;
         BidViewModel bid = new BidViewModel();
         this.bidRepository.Setup(x => x.GetBidAsync(jobId, bidId)).Returns(Task.FromResult(bid)).Verifiable();
         IEnumerable<CreditJob> creditJobs = new List<CreditJob>();
         this.bidRepository.Setup(b => b.GetCreditJobsAsync(jobId, bidId)).Returns(Task.FromResult(creditJobs)).Verifiable();

         // Act
         BidViewModel result = await this.bidService.GetBid(jobId, bidId);

         // Assert
         Assert.Equal(bid, result);
         Assert.Empty(result.CreditJobs);
         this.bidRepository.Verify();
      }

      [Fact]
      public async Task UpdateCurrentBidStatus_ValidInput_ReturnsUpdatedRows()
      {
         // Arrange
         int jobId = 11466;
         int bidAlternateId = 1423;
         int updatedRows = 1;
         this.bidRepository.Setup(x => x.UpdateCurrentBidAsync(jobId, bidAlternateId))
         .Returns(Task.FromResult(updatedRows));

         // Act
         var result = await this.bidService.UpdateCurrentBid(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, updatedRows);
         this.bidRepository.Verify(x => x.UpdateCurrentBidAsync(jobId, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task UpdateCurrentBidStatus_InvalidInput_ReturnsZero()
      {
         // Arrange
         int jobId = 11466;
         int bidAlternateId = 1;
         int updatedRows = 0;
         this.bidRepository.Setup(x => x.UpdateCurrentBidAsync(jobId, bidAlternateId))
         .Returns(Task.FromResult(updatedRows));

         // Act
         var result = await this.bidService.UpdateCurrentBid(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, updatedRows);
         this.bidRepository.Verify(x => x.UpdateCurrentBidAsync(jobId, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task CreateBid_ValidRequest_ReturnsValidData()
      {
         // Arrange
         int bidAlternateId = 0;
         int createdRows = 1;
         var bidList = new BidCreateModel()
         {
            JobId = 178456,
            BidName = "LO",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "LO Desc",
            IncludeInCJ = 0,
         };

         this.bidRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
             .Returns(Task.FromResult(bidAlternateId));

         this.bidRepository.Setup(x => x.CreateBidAsync(It.IsAny<BidAlternate>()))
             .Returns(Task.FromResult(createdRows));

         // Act
         var result = await this.bidService.CreateBid(bidList);

         // Assert
         Assert.Equal(result, createdRows);
         this.bidRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(1));
         this.bidRepository.Verify(x => x.CreateBidAsync(It.IsAny<BidAlternate>()), Times.Once);
      }

      [Fact]
      public async Task CreateBid_InvalidInput_ReturnsZero()
      {
         // Arrange
         int bidAlternateId = 0;
         int createdRows = 0;
         var bidList = new BidCreateModel()
         {
            JobId = 0,
            BidName = string.Empty,
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = string.Empty,
            IncludeInCJ = 0,
         };

         this.bidRepository.Setup(x => x.GetSequenceNumber("BID_ALTERNATE"))
             .Returns(Task.FromResult(bidAlternateId));

         this.bidRepository.Setup(x => x.CreateBidAsync(It.IsAny<BidAlternate>()))
             .Returns(Task.FromResult(createdRows));

         // Act
         var result = await this.bidService.CreateBid(bidList);

         // Assert
         Assert.Equal(result, createdRows);
         this.bidRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>()), Times.Exactly(1));
         this.bidRepository.Verify(x => x.CreateBidAsync(It.IsAny<BidAlternate>()), Times.Once);
      }

      [Fact]
      public async Task ValidateDuplicateBidName_ValidInput_ReturnsFalse()
      {
         // Arrange
         int jobId = 11466;
         string bidName = "Base Bid";
         bool isDuplicateBidName = false;
         int bidAlternateId = 0;
         this.bidRepository.Setup(x => x.ValidateBidName(jobId, bidName, bidAlternateId))
         .Returns(Task.FromResult(isDuplicateBidName));

         // Act
         var result = await this.bidService.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.bidRepository.Verify(x => x.ValidateBidName(jobId, bidName, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task ValidateDuplicateBidName_ValidInput_ReturnsTrue()
      {
         // Arrange
         int jobId = 1212;
         string bidName = "Air Bid";
         bool isDuplicateBidName = true;
         int bidAlternateId = 0;

         this.bidRepository.Setup(x => x.ValidateBidName(jobId, bidName, bidAlternateId))
         .Returns(Task.FromResult(isDuplicateBidName));

         // Act
         var result = await this.bidService.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.bidRepository.Verify(x => x.ValidateBidName(jobId, bidName, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task UpdateBid_ValidRequest_ReturnsValidData()
      {
         // Arrange
         int updatedRows = 1;
         var bidList = new BidCreateModel()
         {
            JobId = 178456,
            BidName = "LO",
            BaseBidYesNo = 0,
            BidAlternateId = 434344,
            CurrentBidInd = "N",
            Description = "LO Desc",
            IncludeInCJ = 0,
         };

         this.bidRepository.Setup(x => x.UpdateBidAsync(It.IsAny<BidAlternate>()))
             .Returns(Task.FromResult(updatedRows));

         // Act
         var result = await this.bidService.UpdateBid(bidList);

         // Assert
         Assert.Equal(result, updatedRows);
         this.bidRepository.Verify(x => x.UpdateBidAsync(It.IsAny<BidAlternate>()), Times.Once);
      }

      [Fact]
      public async Task UpdateBid_InvalidInput_ReturnsZero()
      {
         // Arrange
         int updatedRows = 0;
         var bidList = new BidCreateModel()
         {
            JobId = 0,
            BidName = string.Empty,
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = string.Empty,
            IncludeInCJ = 0,
         };

         this.bidRepository.Setup(x => x.UpdateBidAsync(It.IsAny<BidAlternate>()))
             .Returns(Task.FromResult(updatedRows));

         // Act
         var result = await this.bidService.UpdateBid(bidList);

         // Assert
         Assert.Equal(result, updatedRows);
         this.bidRepository.Verify(x => x.UpdateBidAsync(It.IsAny<BidAlternate>()), Times.Once);
      }

      [Fact]
      public async Task ValidateDuplicateUpdateBidName_ValidInput_ReturnsFalse()
      {
         // Arrange
         int jobId = 11466;
         string bidName = "Base Bid";
         bool isDuplicateBidName = false;
         int bidAlternateId = 434344;
         this.bidRepository.Setup(x => x.ValidateBidName(jobId, bidName, bidAlternateId))
         .Returns(Task.FromResult(isDuplicateBidName));

         // Act
         var result = await this.bidService.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.bidRepository.Verify(x => x.ValidateBidName(jobId, bidName, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task ValidateDuplicateUpdateBidName_ValidInput_ReturnsTrue()
      {
         // Arrange
         int jobId = 1212;
         string bidName = "Air Bid";
         bool isDuplicateBidName = true;
         int bidAlternateId = 54534;

         this.bidRepository.Setup(x => x.ValidateBidName(jobId, bidName, bidAlternateId))
         .Returns(Task.FromResult(isDuplicateBidName));

         // Act
         var result = await this.bidService.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.bidRepository.Verify(x => x.ValidateBidName(jobId, bidName, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_IsCurrentBid_UpdateBaseBidAsCurrentBidAndReturnsDeletedStatus()
      {
         // Arrange
         int jobId = 1212;
         int bidAlternateId = 1421;
         int baseBidAlternateId = 1691;
         int updateAndDeleteStatus = 1;
         int deletedStatus = 0;
         BidViewModel bidViewModel = new BidViewModel()
         {
            BidName = "Base Bid"
         };
         this.bidRepository.Setup(x => x.GetBidAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(bidViewModel));
         this.bidRepository.Setup(x => x.IsBidCurrentAsync(bidAlternateId)).Returns(Task.FromResult(true));
         this.bidRepository.Setup(x => x.GetBaseBidAlternateIdAsync(jobId)).Returns(Task.FromResult(baseBidAlternateId));
         this.bidRepository.Setup(x => x.UpdateAndDeleteBidAsync(jobId, bidAlternateId, baseBidAlternateId)).Returns(Task.FromResult(updateAndDeleteStatus));
         this.bidRepository.Setup(x => x.DeleteBidAsync(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));
         this.jobsUpdateNotifier.Setup(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>())).Returns(Task.FromResult(Task.CompletedTask));

         // Act
         var result = await this.bidService.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, updateAndDeleteStatus);
         this.bidRepository.Verify(x => x.IsBidCurrentAsync(bidAlternateId), Times.Once);
         this.bidRepository.Verify(x => x.GetBaseBidAlternateIdAsync(jobId), Times.Once);
         this.bidRepository.Verify(x => x.UpdateAndDeleteBidAsync(jobId, bidAlternateId, baseBidAlternateId), Times.Once);
         this.bidRepository.Verify(x => x.DeleteBidAsync(jobId, bidAlternateId), Times.Never);
         this.bidRepository.Verify(x => x.GetBidAsync(jobId, bidAlternateId), Times.Once);
         this.jobsUpdateNotifier.Verify(x => x.NotifyJobsUpdateRequestAsync(jobId, BidNotificationType.Delete, bidAlternateId, bidViewModel.BidName), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_IsNotCurrentBid_ReturnsDeletedStatus()
      {
         // Arrange
         int jobId = 5935;
         int bidAlternateId = 7896;
         int baseBidAlternateId = 8635;
         int updateAndDeleteStatus = 0;
         int deletedStatus = 1;
         BidViewModel bidViewModel = new BidViewModel()
         {
            BidName = "Base Bid"
         };
         this.bidRepository.Setup(x => x.GetBidAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(bidViewModel));
         this.bidRepository.Setup(x => x.IsBidCurrentAsync(bidAlternateId)).Returns(Task.FromResult(false));
         this.bidRepository.Setup(x => x.GetBaseBidAlternateIdAsync(jobId)).Returns(Task.FromResult(baseBidAlternateId));
         this.bidRepository.Setup(x => x.UpdateAndDeleteBidAsync(jobId, bidAlternateId, baseBidAlternateId)).Returns(Task.FromResult(updateAndDeleteStatus));
         this.bidRepository.Setup(x => x.DeleteBidAsync(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));
         this.jobsUpdateNotifier.Setup(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>())).Returns(Task.FromResult(Task.CompletedTask));

         // Act
         var result = await this.bidService.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, deletedStatus);
         this.bidRepository.Verify(x => x.IsBidCurrentAsync(bidAlternateId), Times.Once);
         this.bidRepository.Verify(x => x.GetBaseBidAlternateIdAsync(jobId), Times.Never);
         this.bidRepository.Verify(x => x.UpdateAndDeleteBidAsync(jobId, bidAlternateId, baseBidAlternateId), Times.Never);
         this.bidRepository.Verify(x => x.DeleteBidAsync(jobId, bidAlternateId), Times.Once);
         this.bidRepository.Verify(x => x.GetBidAsync(jobId, bidAlternateId), Times.Once);
         this.jobsUpdateNotifier.Verify(x => x.NotifyJobsUpdateRequestAsync(jobId, BidNotificationType.Delete, bidAlternateId, bidViewModel.BidName), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_IsNotCurrentBid_ReturnsNotDeletedStatus()
      {
         // Arrange
         int jobId = 5935;
         int bidAlternateId = 7896;
         int baseBidAlternateId = 8635;
         int updateAndDeleteStatus = 0;
         int deletedStatus = 0;
         BidViewModel bidViewModel = new BidViewModel()
         {
            BidName = "Base Bid"
         };
         this.bidRepository.Setup(x => x.GetBidAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(bidViewModel));
         this.bidRepository.Setup(x => x.IsBidCurrentAsync(bidAlternateId)).Returns(Task.FromResult(false));
         this.bidRepository.Setup(x => x.GetBaseBidAlternateIdAsync(jobId)).Returns(Task.FromResult(baseBidAlternateId));
         this.bidRepository.Setup(x => x.UpdateAndDeleteBidAsync(jobId, bidAlternateId, baseBidAlternateId)).Returns(Task.FromResult(updateAndDeleteStatus));
         this.bidRepository.Setup(x => x.DeleteBidAsync(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));
         this.jobsUpdateNotifier.Setup(x => x.NotifyJobsUpdateRequestAsync(It.IsAny<int>(), It.IsAny<BidNotificationType>(), It.IsAny<int>(), It.IsAny<string>())).Returns(Task.FromResult(Task.CompletedTask));

         // Act
         var result = await this.bidService.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, deletedStatus);
         this.bidRepository.Verify(x => x.IsBidCurrentAsync(bidAlternateId), Times.Once);
         this.bidRepository.Verify(x => x.GetBaseBidAlternateIdAsync(jobId), Times.Never);
         this.bidRepository.Verify(x => x.UpdateAndDeleteBidAsync(jobId, bidAlternateId, baseBidAlternateId), Times.Never);
         this.bidRepository.Verify(x => x.DeleteBidAsync(jobId, bidAlternateId), Times.Once);
         this.bidRepository.Verify(x => x.GetBidAsync(jobId, bidAlternateId), Times.Once);
         this.jobsUpdateNotifier.Verify(x => x.NotifyJobsUpdateRequestAsync(jobId, BidNotificationType.Delete, bidAlternateId, bidViewModel.BidName), Times.Never);
      }

      [Fact]
      public async Task GetBidSelections_ValidInput_ReturnsBidSelections()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidSelections> bidSelections = new List<BidSelections>
            {
                    new BidSelections()
                    {
                        BID_ALTERNATE_ID = 11
                    }
            };
         this.bidRepository.Setup(x => x.GetBidSelectionsQuery(jobId))
         .Returns(Task.FromResult(bidSelections));

         // Act
         var result = await this.bidService.GetBidSelections(jobId);

         // Assert
         Assert.Equal(result.Count(), bidSelections.Count());
         Assert.True(result.Select(a => a.BidAlternateId == 11).Any());
         this.bidRepository.Verify(x => x.GetBidSelectionsQuery(jobId), Times.Once);
      }

      [Fact]
      public async Task GetBidSelections_ValidInput_ReturnsEmptyList()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidSelections> bidSelections = new List<BidSelections>();
         this.bidRepository.Setup(x => x.GetBidSelectionsQuery(jobId))
         .Returns(Task.FromResult(bidSelections));

         // Act
         var result = await this.bidService.GetBidSelections(jobId);

         // Assert
         Assert.Equal(result.Count(), bidSelections.Count());
         this.bidRepository.Verify(x => x.GetBidSelectionsQuery(jobId), Times.Once);
      }

      [Fact]
      public async Task DeleteSelections_ValidSelectionRequest_ReturnsDeletedStatus()
      {
         // Arrange
         bool isDeleted = true;

         List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
         List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>();
         List<RemoveVariationsRequestViewModel> removeVariationsRequest = new List<RemoveVariationsRequestViewModel>();
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequestViewModel = new RemoveAllSelectionsRequestViewModel
         {
            RemoveSelectionsRequest = removeSelectionsRequest,
            RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest,
            RemoveVariationsRequest = removeVariationsRequest
         };
         this.bidRepository.Setup(x => x.DeleteAllSelectionsAsync(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()))
            .Returns(Task.FromResult(isDeleted));

         // Act
         var result = await this.bidService.DeleteSelections(bidAlternateId, removeAllSelectionsRequestViewModel);

         // Assert
         Assert.Equal(isDeleted, result);
         this.bidRepository.Verify(x => x.DeleteAllSelectionsAsync(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()), Times.Once);
      }

      [Fact]
      public async Task DeleteSelections_ValidSeparatelyBiddableRequest_ReturnsDeletedStatus()
      {
         // Arrange
         bool isDeleted = true;

         List<RemoveSelectionsRequestViewModel> removeSelectionRequest = new List<RemoveSelectionsRequestViewModel>();
         List<RemoveVariationsRequestViewModel> removeVariationRequest = new List<RemoveVariationsRequestViewModel>();
         List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddableRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                 new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionRequest = new RemoveAllSelectionsRequestViewModel
         {
            RemoveSelectionsRequest = removeSelectionRequest,
            RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddableRequest,
            RemoveVariationsRequest = removeVariationRequest
         };
         this.bidRepository.Setup(x => x.DeleteAllSelectionsAsync(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()))
            .Returns(Task.FromResult(isDeleted));

         // Act
         var result = await this.bidService.DeleteSelections(bidAlternateId, removeAllSelectionRequest);

         // Assert
         Assert.Equal(isDeleted, result);
         this.bidRepository.Verify(x => x.DeleteAllSelectionsAsync(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()), Times.Once);
      }

      /// <summary>
      /// Verify add selections - success
      /// </summary>
      /// <returns>True</returns>
      [Fact]
      public async Task AddSelection_ValidRequest_ReturnsTrue()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         List<SeparatelyBiddableViewModel> separatelyBiddableIds = new List<SeparatelyBiddableViewModel>()
            {
                new SeparatelyBiddableViewModel()
                {
                    SeparatelyBiddableId = 3
                }
            };
         List<VariationViewModel> variationIds = new List<VariationViewModel>()
            {
                new VariationViewModel()
                {
                    VariationId = 7
                }
            };
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>()
            {
                new SelectionDetailsViewModel()
                {
                    SelectionId = 34,
                    ExcludeSelection = false,
                    SeparatelyBiddableViewModel = separatelyBiddableIds,
                    VariationViewModel = variationIds
                }
            };
         List<JobVariationViewModel> jobVariationViewModel = new List<JobVariationViewModel>()
            {
                new JobVariationViewModel()
                {
                    VariationId = 11,
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails,
            JobVariations = jobVariationViewModel
         };
         bool isInserted = true;
         this.bidRepository.Setup(x => x.InsertSelections(It.IsAny<IEnumerable<BidSelections>>())).Returns(Task.FromResult(isInserted));
         this.bidRepository.SetupSequence(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()))
             .Returns(Task.FromResult(17854));

         // Act
         var result = await this.bidService.AddSelections(jobId, bidAlternateId, addSelection);

         // Assert
         Assert.True(result);
         Assert.True(addSelection.SelectionDetails != null);
         this.bidRepository.Verify(x => x.InsertSelections(It.IsAny<IEnumerable<BidSelections>>()), Times.Once);
         this.bidRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
         this.bidRepository.Verify(x => x.GetCurrentBidAlternateIdAsync(jobId), Times.Never);
      }

      /// <summary>
      /// Verify add selections when inserted job variation alone - success
      /// </summary>
      /// <returns>True</returns>
      [Fact]
      public async Task AddSelection_OnlyWithJobVariation_ReturnsTrue()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;

         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            JobVariations = new List<JobVariationViewModel>()
            {
                new JobVariationViewModel()
                {
                    VariationId = 11
                }
            }
         };

         bool isInserted = true;
         this.bidRepository.Setup(x => x.InsertSelections(It.IsAny<IEnumerable<BidSelections>>())).Returns(Task.FromResult(isInserted));
         this.bidRepository.SetupSequence(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()))
             .Returns(Task.FromResult(17854));

         // Act
         var result = await this.bidService.AddSelections(jobId, bidAlternateId, addSelection);

         // Assert
         Assert.True(result);
         Assert.True(addSelection.SelectionDetails == null);
         this.bidRepository.Verify(x => x.InsertSelections(It.IsAny<IEnumerable<BidSelections>>()), Times.Once);
         this.bidRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
         this.bidRepository.Verify(x => x.GetCurrentBidAlternateIdAsync(jobId), Times.Never);
      }

      /// <summary>
      /// Verify add selections while creating non trane item(variation)- success
      /// </summary>
      /// <returns>True</returns>
      [Fact]
      public async Task AddSelection_WhileCreatingNonTraneItem_ReturnsTrue()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 0;
         int currentBidAlternateId = 7897;
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>();
         List<JobVariationViewModel> jobVariations = new List<JobVariationViewModel>()
            {
                new JobVariationViewModel()
                {
                    VariationId = 11,
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails,
            JobVariations = jobVariations
         };

         bool isInserted = true;
         this.bidRepository.Setup(x => x.InsertSelections(It.IsAny<IEnumerable<BidSelections>>()))
            .Returns(Task.FromResult(isInserted));
         this.bidRepository.SetupSequence(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()))
            .Returns(Task.FromResult(17854));
         this.bidRepository.Setup(x => x.GetCurrentBidAlternateIdAsync(jobId))
            .Returns(Task.FromResult(currentBidAlternateId));

         // Act
         var result = await this.bidService.AddSelections(jobId, bidAlternateId, addSelection);

         // Assert
         Assert.True(result);
         this.bidRepository.Verify(x => x.InsertSelections(It.IsAny<IEnumerable<BidSelections>>()), Times.Once);
         this.bidRepository.Verify(x => x.GetSequenceNumber(It.IsAny<string>(), It.IsAny<int>()), Times.Once);
         this.bidRepository.Verify(x => x.GetCurrentBidAlternateIdAsync(jobId), Times.Once);
      }

      /// <summary>
      /// Verifies the base and alternate bid data for the requested job id
      /// </summary>
      /// <returns>Bids for coordination from repository</returns>
      [Fact]
      public async Task GetBidsForCoodination_HasRecords_ReturnsBidData()
      {
         // Arrange
         int jobId = 574777;
         IEnumerable<CoordinationJobBid> bidsForCoordination = new List<CoordinationJobBid>
            {
                CommonHelper.GetCoordinationJobBid(967914, "Base bid", "Y", 1, 1),
                CommonHelper.GetCoordinationJobBid(967915, "Alt bid", "N", 0, 0),
                CommonHelper.GetCoordinationJobBid(967916, "Fancy", "Y", 0, null)
            };
         IEnumerable<CoordinationJobBidViewModel> coordinationJobBids = new List<CoordinationJobBidViewModel>
            {
                CommonHelper.GetCoordinationJobBidViewModel(967914, "Base bid", true, true, true),
                CommonHelper.GetCoordinationJobBidViewModel(967915, "Alt bid", false, false, false),
                CommonHelper.GetCoordinationJobBidViewModel(967916, "Fancy", true, false, null)
            };
         this.bidRepository.Setup(x => x.GetBidsForCoordination(jobId)).Returns(Task.FromResult(bidsForCoordination));

         // Act
         var actualResult = await this.bidService.GetBidsForCoordination(jobId);

         // Assert
         Assert.Equal(coordinationJobBids.First().BidAlternateId, actualResult.First().BidAlternateId);
         Assert.True(actualResult.First().IsBaseBid);
         Assert.Equal(coordinationJobBids.First().IsBaseBid, actualResult.First().IsBaseBid);
         Assert.Equal(coordinationJobBids.Last().BidAlternateId, actualResult.Last().BidAlternateId);
         Assert.False(actualResult.Last().IsBaseBid);
         Assert.Equal(coordinationJobBids.Last().IsBaseBid, actualResult.Last().IsBaseBid);
         this.bidRepository.Verify(x => x.GetBidsForCoordination(jobId), Times.Once);
      }

      /// <summary>
      /// Verifies the coordinate is bid updated - Success
      /// </summary>
      /// <returns>True</returns>
      [Fact]
      public async Task UpdateJobCoordinationStatusForBids_ValidInput_ReturnsTrue()
      {
         // Arrange
         IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsView = new List<JobCoordinationStatusForBidsViewModel>()
         {
               new JobCoordinationStatusForBidsViewModel()
               {
                  JobId = 1,
                  DrAddressId = 101,
                  BidAlternateId = 1,
                  IsBidInCoordinationJob = true
               },
               new JobCoordinationStatusForBidsViewModel()
               {
                  JobId = 2,
                  DrAddressId = 101,
                  BidAlternateId = 0,
                  IsBidInCoordinationJob = false
               }
         };
         this.bidRepository.Setup(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBids>>()))
             .Returns(Task.FromResult(true));

         // Act
         var result = await this.bidService.UpdateJobCoordinationStatusForBids(jobCoordinationStatusForBidsView);

         // Assert
         Assert.True(result);
         this.bidRepository.Verify(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBids>>()), Times.Once);
      }

      /// <summary>
      /// Verifies the coordinate is bid updated - Failure
      /// </summary>
      /// <returns>False</returns>
      [Fact]
      public async Task UpdateJobCoordinationStatusForBids_InvalidInput_ReturnsFalse()
      {
         // Arrange
         IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsView = new List<JobCoordinationStatusForBidsViewModel>()
            {
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 0,
                    DrAddressId = 0,
                    BidAlternateId = 0,
                    IsBidInCoordinationJob = false
                }
            };
         this.bidRepository.Setup(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBids>>()))
             .Returns(Task.FromResult(false));

         // Act
         var result = await this.bidService.UpdateJobCoordinationStatusForBids(jobCoordinationStatusForBidsView);

         // Assert
         Assert.False(result);
         this.bidRepository.Verify(x => x.UpdateJobCoordinationStatusForBids(It.IsAny<IEnumerable<JobCoordinationStatusForBids>>()), Times.Once);
      }

      /// <summary>
      /// Verifies the bid selection details
      /// </summary>
      /// <returns>Bid selection details</returns>
      [Fact]
      public async Task GetBidSelectionDetails_HasRecords_ReturnsBidSelectionDetails()
      {
         // Arrange
         IEnumerable<int> bidIds = new List<int>()
         {
            188619, 188630, 188631
         };
         IEnumerable<BidSelectionDetails> bidSelectionDetails = new List<BidSelectionDetails>()
         {
               CommonHelper.GetBidSelectionDetails(1, 1, "Selection"),
               CommonHelper.GetBidSelectionDetails(1, 1, "SelectedPricingParm"),
               CommonHelper.GetBidSelectionDetails(1, 2, "SelectedPricingParm")
         };
         IEnumerable<int> expectedParentSelectionIds = new List<int>() { 1 };
         IEnumerable<int> expectedSelectedPricingParmParentSelectionIds = new List<int>() { 1, 2 };
         IEnumerable<int> expectedSeparatelyBiddableSelectionIds = new List<int>() { 2 };
         this.bidRepository.Setup(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(bidSelectionDetails));

         // Act
         var result = await this.bidService.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.Equal(result.First().BidAlternateId, bidSelectionDetails.First().BID_ALTERNATE_ID);
         Assert.Equal(result.First().ParentSelectionIds, expectedParentSelectionIds);
         Assert.Equal(result.First().SelectedPricingParmParentSelectionIds, expectedSelectedPricingParmParentSelectionIds);
         Assert.Equal(result.First().SeparatelyBiddableSelectionIds, expectedSeparatelyBiddableSelectionIds);
         this.bidRepository.Verify(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>()), Times.Once);
      }
   }
}