// <copyright file="JobsUpdateNotifierTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Security.Claims;
   using System.Threading.Tasks;
   using Amazon.SimpleNotificationService.Model;
   using AWS.MessagingWrapper.Contracts;
   using BidService.Common.Constants;
   using BidService.Core.Models;
   using BidService.Core.Repository;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using BidService.Repository;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using Newtonsoft.Json;
   using TSMT.Settings;
   using Xunit;

   /// <summary>
   /// Provides various methods to interact with SNS
   /// </summary>
   public class JobsUpdateNotifierTest
   {
      private readonly Mock<IMessagePublisher> snsPublisher;
      private readonly Mock<IOptions<TSMTSettings>> tsmtSettings;
      private readonly Mock<IHttpContextAccessor> contextAccessor;
      private readonly Mock<IJobsUpdateDynamoDBRepository> jobsUpdateDynamoDBRepository;
      private readonly Mock<IJobsUpdateNotifier> jobsUpdateNotifier;
      private readonly Mock<ILogger<JobsUpdateNotifier>> logger;
      private readonly Mock<IBidRepository> bidRepository;
      private readonly int jobId = 1267;
      private readonly int bidId = 33480;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobsUpdateNotifierTest"/> class.
      /// </summary>
      public JobsUpdateNotifierTest()
      {
         this.snsPublisher = new Mock<IMessagePublisher>();
         this.logger = new Mock<ILogger<JobsUpdateNotifier>>();
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.tsmtSettings = new Mock<IOptions<TSMTSettings>>();
         this.jobsUpdateNotifier = new Mock<IJobsUpdateNotifier>();
         this.jobsUpdateDynamoDBRepository = new Mock<IJobsUpdateDynamoDBRepository>();
         this.bidRepository = new Mock<IBidRepository>();
      }

      /// <summary>
      /// Verify that request message will be stored in dynamo db and message id will be stored in SQS.
      /// </summary>
      [Fact]
      public void NotifyJobsUpdateRequestAsync_ValidRequest_Success()
      {
         // Arrange
         string bidName = "Base Bid";
         var messageId = "67890-2b9d-5488-9d28-45a5d2f59876";

         TSMTSettings app = new TSMTSettings() { SnsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsUpdateNotifier" };
         this.tsmtSettings.Setup(ap => ap.Value).Returns(app);

         var context = new DefaultHttpContext
         {
            TraceIdentifier = "67890-2b9d-5488-9d28-45a5d2f59876",
         };
         List<Claim> claims = new List<Claim>()
            {
                new Claim("samAccountName", "User1"),
                new Claim("firstname", "Cassie"),
                new Claim("lastname", "DeWaay")
            };
         ClaimsIdentity appIdentity = new ClaimsIdentity(claims);
         context.User.AddIdentity(appIdentity);
         this.bidRepository.Setup(x => x.GetDbDate()).Returns(Task.FromResult(new DateTime(2021, 1, 1)));
         this.snsPublisher.Setup(x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()))
.Returns(Task.FromResult(messageId));
         this.contextAccessor.Setup(x => x.HttpContext).Returns(context);
         this.jobsUpdateDynamoDBRepository.Setup(x => x.SaveJobsUpdateRequest(It.IsAny<JobsUpdateDynamoDBMessage>()))
            .Returns(Task.FromResult(true));
         JobsUpdateRequest jobsUpdateRequest = new JobsUpdateRequest
         {
            DR_ADDRESSID_ID = 0,
            JOB_ID = this.jobId,
            LAST_UPDATE = new DateTime(2021, 1, 1),
            BID_NAME = bidName,
            BID_NOTIFICATION_TYPE = BidNotificationType.Edit,
            USER_NAME = "Cassie DeWaay",
            USER_ID = "user1"
         };
         string jobsUpdateRequestMessage = JsonConvert.SerializeObject(jobsUpdateRequest);
         var jobsUpdateNotifier = new JobsUpdateNotifier(this.snsPublisher.Object, this.logger.Object, this.tsmtSettings.Object, this.jobsUpdateDynamoDBRepository.Object, this.contextAccessor.Object, this.bidRepository.Object);

         // Act
         Task result = jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(this.jobId, BidNotificationType.Edit, this.bidId, bidName);

         // Assert
         Assert.True(result.IsCompletedSuccessfully);
         this.snsPublisher.Verify(x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()), Times.Once);
         this.jobsUpdateDynamoDBRepository.Verify(x => x.SaveJobsUpdateRequest(It.Is<JobsUpdateDynamoDBMessage>(x => x.Message == jobsUpdateRequestMessage)), Times.Once);
         this.bidRepository.Verify(x => x.GetDbDate(), Times.Once);
      }

      [Fact]
      public void NotifyJobsUpdateRequestAsync_BidNameIsNull_GetsBidNameAndJobsUpdateRequestNotifiedSuccessfully()
      {
         // Arrange
         var messageId = "67890-2b9d-5488-9d28-45a5d2f59876";
         BidViewModel bidViewModel = new BidViewModel()
         {
            BidName = "Test Bid"
         };
         TSMTSettings app = new TSMTSettings() { SnsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsUpdateNotifier" };
         this.tsmtSettings.Setup(ap => ap.Value).Returns(app);

         var context = new DefaultHttpContext
         {
            TraceIdentifier = "67890-2b9d-5488-9d28-45a5d2f59876"
         };
         this.bidRepository.Setup(x => x.GetBidAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(bidViewModel));
         this.bidRepository.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Parse("01/01/2021")));
         this.snsPublisher.Setup(
            x => x.PublishToTopicAsync(
            It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()))
            .Returns(Task.FromResult(messageId));
         this.contextAccessor.Setup(x => x.HttpContext).Returns(context);
         this.jobsUpdateDynamoDBRepository.Setup(x => x.SaveJobsUpdateRequest(It.IsAny<JobsUpdateDynamoDBMessage>()))
            .Returns(Task.FromResult(true));
         JobsUpdateRequest jobsUpdateRequest = new JobsUpdateRequest
         {
            DR_ADDRESSID_ID = 0,
            JOB_ID = this.jobId,
            LAST_UPDATE = DateTime.Parse("01/01/2021"),
            BID_NAME = bidViewModel.BidName,
            BID_NOTIFICATION_TYPE = BidNotificationType.Create,
            USER_NAME = " "
         };
         string jobsUpdateRequestMessage = JsonConvert.SerializeObject(jobsUpdateRequest);
         var jobsUpdateNotifier = new JobsUpdateNotifier(this.snsPublisher.Object, this.logger.Object, this.tsmtSettings.Object, this.jobsUpdateDynamoDBRepository.Object, this.contextAccessor.Object, this.bidRepository.Object);

         // Act
         Task result = jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(this.jobId, BidNotificationType.Create, this.bidId, null);

         // Assert
         Assert.True(result.IsCompletedSuccessfully);
         this.snsPublisher.Verify(
             x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()),
             Times.Once);
         this.jobsUpdateDynamoDBRepository.Verify(x => x.SaveJobsUpdateRequest(It.Is<JobsUpdateDynamoDBMessage>(x => x.Message == jobsUpdateRequestMessage)), Times.Once);
         this.bidRepository.Verify(x => x.GetDbDate(), Times.Once);
         this.bidRepository.Verify(x => x.GetBidAsync(this.jobId, this.bidId), Times.Once);
      }

      [Fact]
      public void GetUserNameFromHttpContext_HttpContextIsNull_ReturnsEmptyUserName()
      {
         // Arrange
         DefaultHttpContext context = null;
         this.contextAccessor.Setup(x => x.HttpContext).Returns(context);
         var jobsUpdateNotifier = new JobsUpdateNotifier(this.snsPublisher.Object, this.logger.Object, this.tsmtSettings.Object, this.jobsUpdateDynamoDBRepository.Object, this.contextAccessor.Object, this.bidRepository.Object);

         // Act
         string userName = jobsUpdateNotifier.GetUserNameFromHttpContext();

         // Assert
         Assert.Equal(string.Empty, userName);
      }

      [Fact]
      public void NotifyJobsUpdateRequestAsync_GetBidAsyncReturnsNull_JobsUpdateRequestNotifiedSuccessfully()
      {
         // Arrange
         var messageId = "67890-2b9d-5488-9d28-45a5d2f59876";
         BidViewModel bidViewModel = null;
         TSMTSettings app = new TSMTSettings() { SnsServiceUrl = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsUpdateNotifier" };
         this.tsmtSettings.Setup(ap => ap.Value).Returns(app);

         var context = new DefaultHttpContext
         {
            TraceIdentifier = "67890-2b9d-5488-9d28-45a5d2f59876"
         };
         this.bidRepository.Setup(x => x.GetBidAsync(It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(bidViewModel));
         this.bidRepository.Setup(x => x.GetDbDate()).Returns(Task.FromResult(DateTime.Parse("01/01/2021")));
         this.snsPublisher.Setup(
            x => x.PublishToTopicAsync(
            It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()))
            .Returns(Task.FromResult(messageId));
         this.contextAccessor.Setup(x => x.HttpContext).Returns(context);
         this.jobsUpdateDynamoDBRepository.Setup(x => x.SaveJobsUpdateRequest(It.IsAny<JobsUpdateDynamoDBMessage>()))
            .Returns(Task.FromResult(true));
         JobsUpdateRequest jobsUpdateRequest = new JobsUpdateRequest
         {
            DR_ADDRESSID_ID = 0,
            JOB_ID = this.jobId,
            LAST_UPDATE = DateTime.Parse("01/01/2021"),
            BID_NAME = string.Empty,
            BID_NOTIFICATION_TYPE = BidNotificationType.Create,
            USER_NAME = " "
         };
         string jobsUpdateRequestMessage = JsonConvert.SerializeObject(jobsUpdateRequest);
         var jobsUpdateNotifier = new JobsUpdateNotifier(this.snsPublisher.Object, this.logger.Object, this.tsmtSettings.Object, this.jobsUpdateDynamoDBRepository.Object, this.contextAccessor.Object, this.bidRepository.Object);

         // Act
         Task result = jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(this.jobId, BidNotificationType.Create, this.bidId, null);

         // Assert
         Assert.True(result.IsCompletedSuccessfully);
         this.snsPublisher.Verify(
             x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()),
             Times.Once);
         this.jobsUpdateDynamoDBRepository.Verify(x => x.SaveJobsUpdateRequest(It.Is<JobsUpdateDynamoDBMessage>(x => x.Message == jobsUpdateRequestMessage)), Times.Once);
         this.bidRepository.Verify(x => x.GetDbDate(), Times.Once);
         this.bidRepository.Verify(x => x.GetBidAsync(this.jobId, this.bidId), Times.Once);
      }

      [Fact]
      public void GetUserIdFromHttpContext_HttpContextIsNull_ReturnsEmptyUserId()
      {
         // Arrange
         DefaultHttpContext context = null;
         this.contextAccessor.Setup(x => x.HttpContext).Returns(context);
         var jobsUpdateNotifier = new JobsUpdateNotifier(this.snsPublisher.Object, this.logger.Object, this.tsmtSettings.Object, this.jobsUpdateDynamoDBRepository.Object, this.contextAccessor.Object, this.bidRepository.Object);

         // Act
         string userId = jobsUpdateNotifier.GetUserIdFromHttpContext();

         // Assert
         Assert.Equal(string.Empty, userId);
      }
   }
}
