﻿// <copyright file="AddSelectionsCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Validators
{
   using System.Linq;
   using BidService.Core.Command;
   using BidService.Core.Validators;
   using BidService.Core.ViewModels;
   using Xunit;

   public class AddSelectionsCommandValidatorTest
   {
      /// <summary>
      /// Tests add selection validation with valid inputs
      /// </summary>
      [Fact]
      public void AddSelectionsCommandValidator_ValidInput_ThrowsNoError()
      {
         int jobId = 4325;
         int bidAlternateId = 34;
         bool isBidAlternateIdValidationRequired = true;
         AddSelectionViewModel addSelection = new AddSelectionViewModel();

         // Act
         var selectionDetails = new AddSelectionsCommandValidator().Validate(new AddSelectionsCommand(jobId, bidAlternateId, addSelection, isBidAlternateIdValidationRequired));

         // Assert
         Assert.True(selectionDetails.IsValid);
      }

      /// <summary>
      /// Tests add selection validation with invalid inputs
      /// </summary>
      [Fact]
      public void AddSelectionsCommandValidatorTest_InvalidInputs_ThrowError()
      {
         int jobId = 0;
         int bidAlternateId = 0;
         bool isBidAlternateIdValidationRequired = true;
         AddSelectionViewModel addSelection = new AddSelectionViewModel();

         // Act
         var selectionDetails = new AddSelectionsCommandValidator().Validate(new AddSelectionsCommand(jobId, bidAlternateId, addSelection, isBidAlternateIdValidationRequired));

         // Assert
         Assert.Contains("Job id should be greater than 0", selectionDetails.Errors.Select(a => a.ErrorMessage));
         Assert.Contains("Bid alternate id should be greater than 0", selectionDetails.Errors.Select(a => a.ErrorMessage));
         Assert.False(selectionDetails.IsValid);
      }

      /// <summary>
      /// Tests add selection validation with valid inputs and without bid alternate id validation
      /// </summary>
      [Fact]
      public void AddSelectionsCommandValidatorTest_ValidationNotRequiredForBidAlternateId_ThrowsNoError()
      {
         int jobId = 4325;
         int bidAlternateId = 0;
         bool isBidAlternateIdValidationRequired = false;
         AddSelectionViewModel addSelection = new AddSelectionViewModel();

         // Act
         var selectionDetails = new AddSelectionsCommandValidator().Validate(new AddSelectionsCommand(jobId, bidAlternateId, addSelection, isBidAlternateIdValidationRequired));

         // Assert
         Assert.True(selectionDetails.IsValid);
      }
   }
}