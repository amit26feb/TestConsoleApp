﻿// <copyright file="UpdateBidCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Validators
{
    using System.Linq;
    using System.Threading.Tasks;
    using BidService.Core.Command;
    using BidService.Core.Services;
    using BidService.Core.Validators;
    using BidService.Core.ViewModels;
    using Moq;
    using Xunit;

    public class UpdateBidCommandValidatorTest
    {
        /// <summary>
        /// Tests update bid validation with valid inputs
        /// </summary>
        private readonly Mock<IBidService> bidService;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateBidCommandValidatorTest"/> class.
        /// UpdateBidCommandValidatorTest
        /// </summary>
        public UpdateBidCommandValidatorTest()
        {
            this.bidService = new Mock<IBidService>();
        }

        /// <summary>
        /// Tests update bid validation with valid inputs
        /// </summary>
        [Fact]
        public void UpdateBidCommandValidator_ValidInput_ReturnIsValidTrue()
        {
            // Arrange
            var updateBid = new BidCreateModel()
            {
                JobId = 178456,
                BidName = "Air",
                BaseBidYesNo = 0,
                BidAlternateId = 33322,
                CurrentBidInd = "N",
                Description = "Air Desc",
                IncludeInCJ = 0,
            };

            this.bidService.Setup(x => x.ValidateBidName(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>()))
               .Returns(Task.FromResult(true));

            // Act
            var bidDetails = new UpdateBidCommandValidator().Validate(new UpdateBidCommand(updateBid));

            // Assert
            Assert.True(bidDetails.IsValid);
        }

        /// <summary>
        /// Test update bid validation with invalid bid alternate id
        /// </summary>
        [Fact]
        public void UpdateBidCommandValidator_BidAlternateIdZero_ReturnErrorMessage()
        {
            // Arrange
            var updateBid = new BidCreateModel()
            {
                JobId = 178456,
                BidName = "Base Bid",
                BaseBidYesNo = 0,
                BidAlternateId = 0,
                CurrentBidInd = "N",
                Description = "Air Desc",
                IncludeInCJ = 0,
            };

            // Act
            var bid = new UpdateBidCommandValidator().Validate(new UpdateBidCommand(updateBid));

            // Assert
            Assert.NotNull(bid);
            Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Bid Alternate Id should be greater than 0").FirstOrDefault());
            Assert.False(bid.IsValid);
        }

        /// <summary>
        /// Test update bid validation with invalid BidName
        /// </summary>
        [Fact]
        public void UpdateBidCommandValidator_EmptyBidName_ReturnErrorMessage()
        {
            // Arrange
            var updateBid = new BidCreateModel()
            {
                JobId = 178456,
                BidName = string.Empty,
                BaseBidYesNo = 0,
                BidAlternateId = 33445,
                CurrentBidInd = "N",
                Description = "LO Desc",
                IncludeInCJ = 0,
            };

            // Act
            var bid = new UpdateBidCommandValidator().Validate(new UpdateBidCommand(updateBid));

            // Assert
            Assert.NotNull(bid);
            Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Bid Name cannot be Empty").FirstOrDefault());
            Assert.False(bid.IsValid);
        }

        /// <summary>
        /// Test update bid validation with invalid Base Bid
        /// </summary>
        [Fact]
        public void UpdateBidCommandValidator_InvalidBaseBid_ReturnErrorMessage()
        {
            // Arrange
            var updateBid = new BidCreateModel()
            {
                JobId = 178456,
                BidName = "Base-Bid",
                BaseBidYesNo = 0,
                BidAlternateId = 43344,
                CurrentBidInd = "N",
                Description = "Air Desc",
                IncludeInCJ = 0,
            };

            // Act
            var bid = new UpdateBidCommandValidator().Validate(new UpdateBidCommand(updateBid));

            // Assert
            Assert.NotNull(bid);
            Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Update Bid: Bid name cannot be Base-Bid or BaseBid or Base_Bid").FirstOrDefault());
            Assert.False(bid.IsValid);
        }

        /// <summary>
        /// Test update bid validation with invalid job id
        /// </summary>
        [Fact]
        public void UpdateBidCommandValidator_JobIdZero_ReturnErrorMessage()
        {
            // Arrange
            var updateBid = new BidCreateModel()
            {
                JobId = 0,
                BidName = "Base Bid",
                BaseBidYesNo = 0,
                BidAlternateId = 43434,
                CurrentBidInd = "N",
                Description = "Air Desc",
                IncludeInCJ = 0,
            };

            // Act
            var bid = new UpdateBidCommandValidator().Validate(new UpdateBidCommand(updateBid));

            // Assert
            Assert.NotNull(bid);
            Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Job Id should be greater than 0").FirstOrDefault());
            Assert.False(bid.IsValid);
        }

        /// <summary>
        /// Test update bid validation with invalid Base_Bid
        /// </summary>
        [Fact]
        public void UpdateBidCommandValidator_InvalidBase_Bid_ReturnErrorMessage()
        {
            // Arrange
            var updateBid = new BidCreateModel()
            {
                JobId = 178457,
                BidName = "Base_Bid",
                BaseBidYesNo = 0,
                BidAlternateId = 43345,
                CurrentBidInd = "N",
                Description = "Alt Desc",
                IncludeInCJ = 0,
            };

            // Act
            var bid = new UpdateBidCommandValidator().Validate(new UpdateBidCommand(updateBid));

            // Assert
            Assert.NotNull(bid);
            Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Update Bid: Bid name cannot be Base-Bid or BaseBid or Base_Bid").FirstOrDefault());
            Assert.False(bid.IsValid);
        }
    }
}
