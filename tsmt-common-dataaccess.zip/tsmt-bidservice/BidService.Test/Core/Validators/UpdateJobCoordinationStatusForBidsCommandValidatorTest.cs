﻿// <copyright file="UpdateJobCoordinationStatusForBidsCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Validators
{
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using BidService.Core.Command;
    using BidService.Core.CommandValidator;
    using BidService.Core.Services;
    using BidService.Core.Validators;
    using BidService.Core.ViewModels;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using Xunit;

    public class UpdateJobCoordinationStatusForBidsCommandValidatorTest
    {
        /// <summary>
        /// Update bid whether included for job coordination or not validation with valid inputs
        /// </summary>
        [Fact]
        public void UpdateJobCoordinationStatusForBidsCommandValidator_ValidInput_ReturnsTrue()
        {
            IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBids = new List<JobCoordinationStatusForBidsViewModel>()
            {
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 10,
                    BidAlternateId = 10,
                    DrAddressId = 101,
                    IsBidInCoordinationJob = true
                }
            };

            // Act
            var jobCoordinationStatus = new UpdateJobCoordinationStatusForBidsCommandValidator().Validate(new UpdateJobCoordinationStatusForBidsCommand(jobCoordinationStatusForBids));

            // Assert
            Assert.True(jobCoordinationStatus.IsValid);
        }

        /// <summary>
        /// Update bid whether included for job coordination or not validation with empty value as input
        /// </summary>
        [Fact]
        public void UpdateJobCoordinationStatusForBidsCommandValidator_InavlidInputWithEmptyValue_ReturnsFalse()
        {
            IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBids = new List<JobCoordinationStatusForBidsViewModel>()
            {
            };

            // Act
            var jobCoordinationStatus = new UpdateJobCoordinationStatusForBidsCommandValidator().Validate(new UpdateJobCoordinationStatusForBidsCommand(jobCoordinationStatusForBids));

            // Assert
            Assert.False(jobCoordinationStatus.IsValid);
        }

        /// <summary>
        /// Update bid whether included for job coordination or not validation with invalid inputs
        /// </summary>
        [Fact]
        public void UpdateJobCoordinationStatusForBidsCommandValidator_InvalidInput_ReturnsFalse()
        {
            IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBids = new List<JobCoordinationStatusForBidsViewModel>()
            {
                new JobCoordinationStatusForBidsViewModel()
                {
                    JobId = 0,
                    BidAlternateId = 0,
                    DrAddressId = 0,
                    IsBidInCoordinationJob = true
                }
            };

            // Act
            var jobCoordinationStatus = new UpdateJobCoordinationStatusForBidsCommandValidator().Validate(new UpdateJobCoordinationStatusForBidsCommand(jobCoordinationStatusForBids));

            // Assert
            Assert.False(jobCoordinationStatus.IsValid);
        }
    }
}