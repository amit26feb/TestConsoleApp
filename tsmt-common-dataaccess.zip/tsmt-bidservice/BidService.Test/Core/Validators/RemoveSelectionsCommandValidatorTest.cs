﻿// <copyright file="RemoveSelectionsCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Validators
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using BidService.Core.Commands;
    using BidService.Core.Services;
    using BidService.Core.Validators;
    using BidService.Core.ViewModels;
    using Microsoft.AspNetCore.Http;
    using Moq;
    using Xunit;

    public class RemoveSelectionsCommandValidatorTest
    {
        /// <summary>
        /// Tests remove selections validation
        private readonly Mock<IBidService> bidService;
        private readonly IHttpContextAccessor contextAccessor = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="RemoveSelectionsCommandValidatorTest"/> class.
        /// RemoveSelectionsCommandValidatorTest
        /// </summary>
        public RemoveSelectionsCommandValidatorTest()
        {
            this.bidService = new Mock<IBidService>();
        }

        /// <summary>
        /// Tests remove selections validation with valid inputs
        /// </summary>
        [Fact]
        public void RemoveSelectionsCommandValidator_ValidInput_ReturnIsValidTrue()
        {
            // Arrange
            List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
            List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
            int jobId = 28643;
            int bidAlternateId = 346545;
            bool isBidAlternateIdValidationRequired = true;
            RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
            {
                RemoveSelectionsRequest = removeSelectionsRequest,
                RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest
            };

            this.bidService.Setup(x => x.DeleteSelections(It.IsAny<int>(), It.IsAny<RemoveAllSelectionsRequestViewModel>()))
               .Returns(Task.FromResult(true));

            // Act
            var removeSelectionRequest = new RemoveSelectionsCommandValidator(this.bidService.Object, this.contextAccessor).Validate(new RemoveSelectionsCommand(jobId, bidAlternateId, removeAllSelectionsRequest, isBidAlternateIdValidationRequired));

            // Assert
            Assert.True(removeSelectionRequest.IsValid);
        }

        /// <summary>
        /// Tests remove selections validation with invalid bid alternate id
        /// </summary>
        [Fact]
        public void RemoveSelectionsCommandValidator_BidAlternateIdZero_ReturnErrorMessage()
        {
            // Arrange
            List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
            List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
            int jobId = 28643;
            int bidAlternateId = 0;
            bool isBidAlternateIdValidationRequired = true;
            RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
            {
                RemoveSelectionsRequest = removeSelectionsRequest,
                RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest
            };

            // Act
            var removeSelectionRequest = new RemoveSelectionsCommandValidator(this.bidService.Object, this.contextAccessor).Validate(new RemoveSelectionsCommand(jobId, bidAlternateId, removeAllSelectionsRequest, isBidAlternateIdValidationRequired));

            // Assert
            Assert.True(removeSelectionRequest.Errors.Select(a => a.ErrorMessage == "Bid Alternate Id must be greater than 0").FirstOrDefault());
            Assert.False(removeSelectionRequest.IsValid);
        }
    }
}
