﻿// <copyright file="CreateBidCommandValidatorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Validators
{
   using System.Linq;
   using System.Threading.Tasks;
   using BidService.Core.Command;
   using BidService.Core.Services;
   using BidService.Core.Validators;
   using BidService.Core.ViewModels;
   using Moq;
   using Xunit;

   public class CreateBidCommandValidatorTest
   {
      /// <summary>
      /// Tests create bid validation with valid inputs
      /// </summary>
      private readonly Mock<IBidService> bidService;

      /// <summary>
      /// Initializes a new instance of the <see cref="CreateBidCommandValidatorTest"/> class.
      /// CreateBidCommandValidatorTest
      /// </summary>
      public CreateBidCommandValidatorTest()
      {
         this.bidService = new Mock<IBidService>();
      }

      /// <summary>
      /// Tests create bid validation with valid inputs
      /// </summary>
      [Fact]
      public void CreateBidCommandValidator_Success()
      {
         // Arrange
         var createBid = new BidCreateModel()
         {
            JobId = 178456,
            BidName = "LO",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "LO Desc",
            IncludeInCJ = 0,
         };

         this.bidService.Setup(x => x.ValidateBidName(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>()))
            .Returns(Task.FromResult(true));

         // Act
         var bidDetails = new CreateBidCommandValidator(this.bidService.Object).Validate(new CreateBidCommand(createBid));

         // Assert
         Assert.True(bidDetails.IsValid);
      }

      /// <summary>
      /// Test create bid validation with invalid BidName
      /// </summary>
      [Fact]
      public void CreateBidCommandValidator_InvalidBidName()
      {
         // Arrange
         var createBid = new BidCreateModel()
         {
            JobId = 178456,
            BidName = string.Empty,
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "LO Desc",
            IncludeInCJ = 0,
         };

         // Act
         var bid = new CreateBidCommandValidator(this.bidService.Object).Validate(new CreateBidCommand(createBid));

         // Assert
         Assert.NotNull(bid);
         Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Bid Name cannot be Empty").FirstOrDefault());
         Assert.False(bid.IsValid);
      }

      /// <summary>
      /// Test create bid validation with invalid Base Bid
      /// </summary>
      [Fact]
      public void CreateBidCommandValidator_InvalidBaseBid()
      {
         // Arrange
         var createBid = new BidCreateModel()
         {
            JobId = 178456,
            BidName = "Base Bid",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "Air Desc",
            IncludeInCJ = 0,
         };

         // Act
         var bid = new CreateBidCommandValidator(this.bidService.Object).Validate(new CreateBidCommand(createBid));

         // Assert
         Assert.NotNull(bid);
         Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Create Bid: Bid name cannot be Base Bid or Base-Bid or BaseBid or Base_Bid").FirstOrDefault());
         Assert.False(bid.IsValid);
      }

      /// <summary>
      /// Test create bid validation with invalid Base_Bid
      /// </summary>
      [Fact]
      public void CreateBidCommandValidator_InvalidBase_Bid()
      {
         // Arrange
         var createBid = new BidCreateModel()
         {
            JobId = 178453,
            BidName = "Base_Bid",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "Air Desc",
            IncludeInCJ = 0,
         };

         // Act
         var bid = new CreateBidCommandValidator(this.bidService.Object).Validate(new CreateBidCommand(createBid));

         // Assert
         Assert.NotNull(bid);
         Assert.True(bid.Errors.Select(a => a.ErrorMessage == "Create Bid: Bid name cannot be Base Bid or Base-Bid or BaseBid or Base_Bid").FirstOrDefault());
         Assert.False(bid.IsValid);
      }

      /// <summary>
      /// Test bid creation validation with different bid ids
      /// </summary>
      /// <param name="bidId">The bid id to put on the test model.</param>
      /// <param name="expectedValidity">The expected IsValid value.</param>
      [Theory]
      [InlineData(0, true)]
      [InlineData(-1, false)]
      [InlineData(1, false)]
      public void CreateBidCommandValidator_ValidatesBidId(int bidId, bool expectedValidity)
      {
         // Arrange
         this.bidService.Setup(c => c.ValidateBidName(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>())).Returns(Task.FromResult(true));
         var createBid = new BidCreateModel()
         {
            JobId = 178453,
            BidName = "Biddy McBidderson",
            BaseBidYesNo = 0,
            BidAlternateId = bidId,
            CurrentBidInd = "N",
            Description = "Help I'm trapped inside a unit test!",
            IncludeInCJ = 0,
         };

         // Act
         var bid = new CreateBidCommandValidator(this.bidService.Object).Validate(new CreateBidCommand(createBid));

         // Assert
         Assert.Equal(expectedValidity, bid.IsValid);
      }
   }
}
