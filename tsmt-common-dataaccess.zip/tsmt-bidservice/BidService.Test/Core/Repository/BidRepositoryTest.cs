// <copyright file="BidRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Test.Core.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using BidService.Common.Constants;
   using BidService.Core.Models;
   using BidService.Core.ViewModels;
   using BidService.Repository;
   using BidService.Test.Common;
   using DataAccess.Core.Abstractions;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   public class BidRepositoryTest
   {
      private readonly Mock<IRepository<BidService.Core.Models.BidAlternate>> repository;
      private readonly Mock<IConnectionFactory> connectionFactory;

      /// <summary>
      /// Initializes a new instance of the <see cref="BidRepositoryTest"/> class.
      /// Bid Repository Test
      /// </summary>
      public BidRepositoryTest()
      {
         this.connectionFactory = new Mock<IConnectionFactory>();
         this.repository = new Mock<IRepository<BidService.Core.Models.BidAlternate>>();
      }

      [Fact]
      public async Task GetBidListAsync_ValidInput_ReturnsValidData()
      {
         // Arrange
         var jobId = 11466;
         IEnumerable<BidAlternate> bids = new List<BidAlternate>
         {
              new BidAlternate()
              {
                  BID_ALTERNATE_ID = 657058,
                  CURRENT_BID_IND = "Y",
                  BID_NAME = "Alt Bid",
                  DESCR = null,
                  HQTR_BID_ALTERNATE_ID = 3801159,
                  FOE2_CREATED_ORDERS_IND = "Y",
                  INCLUDE_IN_CJ = 1
              }
         };

         this.repository.Setup(x => x.GetListAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()))
             .Returns(Task.FromResult(bids));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetBidListAsync(jobId);

         // Assert
         Assert.Equal(result.Count(), bids.Count());
         Assert.Contains(result, a => a.BID_ALTERNATE_ID == 657058);
         Assert.Contains(result, a => a.BID_NAME == "Alt Bid");
         Assert.Contains(result, a => a.INCLUDE_IN_CJ == 1);
         Assert.Contains(result, a => a.HQTR_BID_ALTERNATE_ID == 3801159);
         this.repository.Verify(x => x.GetListAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetBidAsync_HasData_ReturnsIt()
      {
         // Arrange
         BidViewModel bid = new BidViewModel();
         this.repository.Setup(x => x.GetAsync<BidViewModel>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(bid));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetBidAsync(123, 456);

         // Assert
         Assert.Equal(bid, result);
         this.repository.Verify(x => x.GetAsync<BidViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetCreditJobListAsync_ValidInput_ReturnsValidData()
      {
         // Arrange
         var jobId = 11487;
         IEnumerable<BidViewModel> creditJobList = new List<BidViewModel>
            {
                    new BidViewModel()
                    {
                      BidAlternateId = 657072,
                      CurrentBidInd = "N",
                      BidName = "Duct & Heate",
                      Description = null,
                      CreditJobNumber = "Y120435",
                      PurchaseOrderNumber = "TEST534",
                      HqtrCreditJobId = 2187321,
                      Foe2CreatedOrdersInd = "Y",
                      HqtrBidAlternateId = 10,
                     }
               };
         this.repository.Setup(x => x.GetListAsync<BidViewModel>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(creditJobList));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetCreditJobListAsync(jobId);

         // Assert
         Assert.Equal(result.Count(), creditJobList.Count());
         Assert.Contains(result, a => a.BidAlternateId == 657072);
         Assert.Contains(result, a => a.BidName == "Duct & Heate");
         Assert.Contains(result, a => a.CreditJobNumber == "Y120435");
         Assert.Contains(result, a => a.PurchaseOrderNumber == "TEST534");
         Assert.Contains(result, a => a.HqtrBidAlternateId == 10);
         this.repository.Verify(x => x.GetListAsync<BidViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetCreditJobListAsync_InvalidInput_ReturnsNoData()
      {
         // Arrange
         var jobId = 25567;
         IEnumerable<BidViewModel> creditJobList = new List<BidViewModel>();
         this.repository.Setup(x => x.GetListAsync<BidViewModel>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(creditJobList));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetCreditJobListAsync(jobId);

         // Assert
         Assert.Empty(result);
         this.repository.Verify(x => x.GetListAsync<BidViewModel>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public void HonorDrAddressId_Execution()
      {
         // Arrange
         var drAddressId = 12;
         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int?>()));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         repo.HonorDrAddressId(drAddressId);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(It.IsAny<int?>()), Times.Once);
      }

      [Fact]
      public async Task UpdateCurrentBidStatus_ValidInput_ReturnsUpdatedRows()
      {
         // Arrange
         int jobId = 11466;
         int bidAlternateId = 1423;
         int updatedRows = 2;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(updatedRows));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.UpdateCurrentBidAsync(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, updatedRows);
         this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task UpdateCurrentBidStatus_InvalidInput_ReturnsZero()
      {
         // Arrange
         int jobId = 11466;
         int bidAlternateId = 1;
         int updatedRows = 0;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(updatedRows));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.UpdateCurrentBidAsync(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, updatedRows);
         this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task DeleteBidAsync_ValidInput_ReturnsDeletedStatus()
      {
         // Arrange
         int jobId = 1212;
         int bidAlternateId = 1432;
         int deletedStatus = 1;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(deletedStatus));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.DeleteBidAsync(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, deletedStatus);
         this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task DeleteBidAsync_InvalidInput_ReturnsZero()
      {
         // Arrange
         int jobId = 1000;
         int bidAlternateId = 999999999;
         int deletedStatus = 0;
         this.repository.Setup(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(deletedStatus));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.DeleteBidAsync(jobId, bidAlternateId);

         // Assert
         Assert.Equal(result, deletedStatus);
         this.repository.Verify(x => x.ExecuteAsync<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task CreateBidAsync_ValidInput_ReturnsCreatedRows()
      {
         // Arrange
         int createdRow = 1;
         var bidList = new BidAlternate()
         {
            JOB_ID = 178456,
            BID_NAME = "LO",
            BASE_BID_YES_NO = 0,
            BID_ALTERNATE_ID = 1345,
            CURRENT_BID_IND = "N",
            DESCR = "LO Desc",
            INCLUDE_IN_CJ = 0,
            SELLING_PRICE = 0
         };

         this.repository.Setup(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(createdRow));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.CreateBidAsync(bidList);

         // Assert
         Assert.Equal(createdRow, result);
         this.repository.Verify(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
      }

      [Fact]
      public async Task CreateBidAsync_InvalidInput_ReturnsNoRows()
      {
         // Arrange
         int createdRow = 0;
         var bidList = new BidAlternate()
         {
            JOB_ID = 178456,
            BID_NAME = string.Empty,
            BASE_BID_YES_NO = 0,
            BID_ALTERNATE_ID = 1345,
            CURRENT_BID_IND = "N",
            DESCR = string.Empty,
            INCLUDE_IN_CJ = 0,
            SELLING_PRICE = 0
         };

         this.repository.Setup(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(createdRow));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.CreateBidAsync(bidList);

         // Assert
         Assert.Equal(createdRow, result);
         this.repository.Verify(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task ValidateBidName_InValidInput_ReturnsFalse()
      {
         // Arrange
         int jobId = 1212;
         string bidName = "Base Bid";
         bool isDuplicateBidName = false;
         int bidAlternateId = 0;

         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(1)).Verifiable();

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task ValidateBidName_ValidInput_ReturnsTrue()
      {
         // Arrange
         int jobId = 45674;
         string bidName = "Air Bid";
         bool isDuplicateBidName = true;
         int bidAlternateId = 0;

         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(0)).Verifiable();

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSequenceNumber_InValidInput_ReturnsZero()
      {
         // Arrange
         string tableName = "Bid";
         int id = 0;

         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(id)).Verifiable();

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetSequenceNumber(tableName);

         // Assert
         Assert.Equal(result, id);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetSequenceNumber_ValidInput_ReturnsValid_Id()
      {
         // Arrange
         string tableName = "Bid_Alternate";
         int id = 12567;

         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(id)).Verifiable();

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetSequenceNumber(tableName);

         // Assert
         Assert.Equal(result, id);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task IsBidCurrentAsync_CurrentIndIsY_ReturnsTrue()
      {
         // Arrange
         int bidAlternateId = 1241;
         string currentBidInd = "Y";
         this.repository.Setup(x => x.ExecuteQuery<string>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(currentBidInd));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.IsBidCurrentAsync(bidAlternateId);

         // Assert
         Assert.True(result);
         this.repository.Verify(x => x.ExecuteQuery<string>(BidRepositoryQueries.GetBidCurrentIndQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task IsBidCurrentAsync_CurrentIndIsN_ReturnsFalse()
      {
         // Arrange
         int bidAlternateId = 1241;
         string currentBidInd = "N";
         this.repository.Setup(x => x.ExecuteQuery<string>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(currentBidInd));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.IsBidCurrentAsync(bidAlternateId);

         // Assert
         Assert.False(result);
         this.repository.Verify(x => x.ExecuteQuery<string>(BidRepositoryQueries.GetBidCurrentIndQuery, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetBaseBidAlternateIdAsync_ValidInput_ReturnsValidData()
      {
         // Arrange
         int jobId = 1212;
         int baseBidAlternateId = 1167;
         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(baseBidAlternateId));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetBaseBidAlternateIdAsync(jobId);

         // Assert
         Assert.Equal(result, baseBidAlternateId);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task UpdateBidAsync_ValidInput_ReturnsUpdatedRows()
      {
         // Arrange
         int updatedRow = 1;
         var bidList = new BidAlternate()
         {
            JOB_ID = 178456,
            BID_NAME = "LO",
            BASE_BID_YES_NO = 0,
            BID_ALTERNATE_ID = 1345,
            CURRENT_BID_IND = "N",
            DESCR = "LO Desc",
            INCLUDE_IN_CJ = 0,
         };

         this.repository.Setup(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(updatedRow));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.UpdateBidAsync(bidList);

         // Assert
         Assert.Equal(updatedRow, result);
         this.repository.Verify(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
      }

      [Fact]
      public async Task UpdateBidAsync_InvalidInput_ReturnsNoRows()
      {
         // Arrange
         int updatedRow = 0;
         var bidList = new BidAlternate()
         {
            JOB_ID = 178456,
            BID_NAME = string.Empty,
            BASE_BID_YES_NO = 0,
            BID_ALTERNATE_ID = 1345,
            CURRENT_BID_IND = "N",
            DESCR = string.Empty,
            INCLUDE_IN_CJ = 0,
         };

         this.repository.Setup(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(updatedRow));

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.UpdateBidAsync(bidList);

         // Assert
         Assert.Equal(updatedRow, result);
         this.repository.Verify(x => x.ExecuteAsync<BidAlternate>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task ValidateBidName_DuplicateInput_ReturnsFalse()
      {
         // Arrange
         int jobId = 1212;
         string bidName = "Base Bid";
         bool isDuplicateBidName = false;
         int bidAlternateId = 43442;

         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(1)).Verifiable();

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task ValidateBidName_ValidInputBidName_ReturnsTrue()
      {
         // Arrange
         int jobId = 45674;
         string bidName = "Air Bid";
         bool isDuplicateBidName = true;
         int bidAlternateId = 45455;

         this.repository.Setup(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()))
         .Returns(Task.FromResult(0)).Verifiable();

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.ValidateBidName(jobId, bidName, bidAlternateId);

         // Assert
         Assert.Equal(result, isDuplicateBidName);
         this.repository.Verify(x => x.ExecuteQuery<int>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetBidSelectionsQuery_ValidInput_ReturnsValidData()
      {
         // Arrange
         var jobId = 11466;
         IEnumerable<BidSelections> bidSelections = new List<BidSelections>
            {
                    new BidSelections()
                    {
                        BID_ALTERNATE_ID = 1,
                    }
            };
         this.repository.Setup(x => x.ExecuteListQuery<BidSelections>(It.IsAny<string>(), It.IsAny<object>()))
          .Returns(Task.FromResult(bidSelections)).Verifiable();

         // Act
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);
         var result = await repo.GetBidSelectionsQuery(jobId);

         // Assert
         Assert.IsAssignableFrom<IEnumerable<BidSelections>>(result);
         Assert.Equal(result.Count(), bidSelections.Count());
         Assert.Contains(result, a => a.BID_ALTERNATE_ID == 1);
         this.repository.Verify();
      }

      /// <summary>
      /// Verifies getting date from database
      /// </summary>
      /// <returns>Database date</returns>
      [Fact]
      public async Task GetDbDate_ReturnsDBDate()
      {
         // Arrange
         DateTime dateTime = DateTime.Parse("09/30/2019");
         this.repository.Setup(x => x.ExecuteQuery<DateTime>(It.IsAny<string>())).Returns(Task.FromResult(dateTime));
         var bidRepository = new BidRepository(this.repository.Object, this.connectionFactory.Object);

         // Act
         var result = await bidRepository.GetDbDate();

         // Assert
         Assert.Equal(result, dateTime);
         this.repository.Verify(x => x.ExecuteQuery<DateTime>(It.IsAny<string>()), Times.Once);
      }

      /// <summary>
      /// Verifies the base and alternate bid data for the requested job id
      /// </summary>
      /// <returns>Bids for coordination from repository</returns>
      [Fact]
      public async Task GetBidsForCoordination_HasRecords_ReturnsBidData()
      {
         // Arrange
         int jobId = 574777;
         IEnumerable<CoordinationJobBid> coordinationJobBids = new List<CoordinationJobBid>()
            {
               CommonHelper.GetCoordinationJobBid(967914, "Base bid", "Y", 1, 1),
               CommonHelper.GetCoordinationJobBid(967915, "Alternate bid", "N", 0, 1)
            };
         this.repository.Setup(x => x.ExecuteListQuery<CoordinationJobBid>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(coordinationJobBids));
         var bidRepository = new BidRepository(this.repository.Object, this.connectionFactory.Object);

         // Act
         var actualResult = await bidRepository.GetBidsForCoordination(jobId);

         // Assert
         Assert.Equal(actualResult.First().BID_ALTERNATE_ID, coordinationJobBids.First().BID_ALTERNATE_ID);
         Assert.Equal(actualResult.First().BASE_BID_YES_NO, coordinationJobBids.First().BASE_BID_YES_NO);
         Assert.Equal(actualResult.Last().BID_ALTERNATE_ID, coordinationJobBids.Last().BID_ALTERNATE_ID);
         Assert.Equal(actualResult.Last().BASE_BID_YES_NO, coordinationJobBids.Last().BASE_BID_YES_NO);
         this.repository.Verify(x => x.ExecuteListQuery<CoordinationJobBid>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Verifies the bid selection details
      /// </summary>
      /// <returns>Bid selection details</returns>
      [Fact]
      public async Task GetBidSelectionDetails_ValidInput_ReturnsBidSelectionDetails()
      {
         // Arrange
         IEnumerable<int> bidIds = new List<int>()
            {
               188619, 188630, 188631
            };
         IEnumerable<BidSelectionDetails> bidSelectionDetails = new List<BidSelectionDetails>()
            {
                CommonHelper.GetBidSelectionDetails(1, 1, "Selection")
            };
         this.repository.Setup(x => x.ExecuteListQuery<BidSelectionDetails>(It.IsAny<string>(), It.IsAny<object>())).Returns(Task.FromResult(bidSelectionDetails));
         var bidRepository = new BidRepository(this.repository.Object, this.connectionFactory.Object);

         // Act
         var actualResult = await bidRepository.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.Equal(actualResult.First().BID_ALTERNATE_ID, bidSelectionDetails.First().BID_ALTERNATE_ID);
         this.repository.Verify(x => x.ExecuteListQuery<BidSelectionDetails>(It.IsAny<string>(), It.IsAny<object>()), Times.Once);
      }

      /// <summary>
      /// Verifies getting current bid alternate id
      /// </summary>
      /// <returns>Current bid alternate id</returns>
      [Fact]
      public async Task GetCurrentBidAlternateIdAsync_HasRecord_ReturnsCurrentBidAlternateId()
      {
         // Arrange
         int jobId = 1212;
         int bidAlternateId = 4982;

         this.repository.Setup(x => x.ExecuteQuery<int>(BidRepositoryQueries.GetCurrentBidAlternateIdQuery, It.IsAny<object>()))
                        .Returns(Task.FromResult(bidAlternateId));
         var repository = new BidRepository(this.repository.Object, this.connectionFactory.Object);

         // Act
         var result = await repository.GetCurrentBidAlternateIdAsync(jobId);

         // Assert
         Assert.Equal(result, bidAlternateId);
         this.repository.Verify(x => x.ExecuteQuery<int>(BidRepositoryQueries.GetCurrentBidAlternateIdQuery, It.IsAny<object>()), Times.Once);
      }
      
      [Fact]
      public async Task GetBidListAsync_GivenSearch_CallsGetListAsync()
      {
         // Arrange
         BidSearchModel model = new BidSearchModel();
         var repo = new BidRepository(this.repository.Object, this.connectionFactory.Object);

         // Act
         var result = await repo.GetBidListAsync(model);

         // Assert
         this.repository.Verify(r => r.GetListAsync<BidViewModel>(It.IsAny<string>(), model), Times.Once);
      }
   }
}
