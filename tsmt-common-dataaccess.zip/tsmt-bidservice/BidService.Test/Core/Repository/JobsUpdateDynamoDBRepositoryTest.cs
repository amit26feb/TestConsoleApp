// <copyright file="JobsUpdateDynamoDBRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>
namespace BidService.Test.Core.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Amazon.DynamoDBv2.DocumentModel;
    using BidService.Common.Constants;
    using BidService.Core.Models;
    using BidService.Core.Repository;
    using DynamoDBWrapper;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using TSMT.Settings;
    using Xunit;

    /// <summary>
    /// Provides methods that interacts with DynamoDB
    /// </summary>
    public class JobsUpdateDynamoDBRepositoryTest
    {
        private readonly Mock<ILogger<DynamoDBRepository>> logger;
        private readonly Mock<IDynamoDBRepository> dynamoDBRepository;
        private IDynamoTableConfig dynamoTableConfig;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsUpdateDynamoDBRepositoryTest"/> class.
        /// </summary>
        public JobsUpdateDynamoDBRepositoryTest()
        {
            this.logger = new Mock<ILogger<DynamoDBRepository>>();
            this.dynamoDBRepository = new Mock<IDynamoDBRepository>();
        }

        /// <summary>
        /// Verify the update process in dynamo db
        /// </summary>
        /// <returns>Document which contains collection of attribute key-value pairs for update process status</returns>
        [Fact]
        public async Task UpdateProcessStatus_Updated_Successfully()
        {
            // Arrange
            JobsUpdateDynamoDBMessage jobsUpdateMessage = new JobsUpdateDynamoDBMessage()
            {
                CreatedDateTime = "3/13/2019 7:39:15 AM",
                Status = "Success",
                ErrorMessage = string.Empty,
                MessageId = "0HLLDPLUFAJ2N:00000001",
                StatusUpdatedDateTime = DateTime.UtcNow.ToString()
            };
            Document doc = jobsUpdateMessage.ToDocument();
            this.dynamoTableConfig = new DynamoTableConfig { TableName = "TSMT-JobsUpdateData", ReadCapacityUnits = 3, WriteCapacityUnits = 1, KeyName = "MessageId", KeyType = typeof(string) };
            TSMTSettings appSetting = new TSMTSettings() { SqsServiceUrl = "arn:aws:sqs:us-east-1:611998158124:TSMT-JobsUpdateNotifier", MessageHidingTimeInMinutes = 2, DynamoRegion = "US-East-1", DynamoJobTableName = "TSMT-JobsUpdateData", DynamoJobKeyName = "MessageId" };

            var tsmtSettings = new Mock<IOptions<TSMTSettings>>();
            tsmtSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.dynamoDBRepository.Setup(x => x.PartialUpdateCommandAsync(It.IsAny<JobsUpdateDynamoDBMessage>(), It.IsAny<ReturnValues>())).Returns(Task.FromResult(doc));
            var jobsUpdateDynamoDBRepository = new JobsUpdateDynamoDBRepository(this.logger.Object, tsmtSettings.Object, this.dynamoTableConfig)
            {
                DynamoDBRepository = this.dynamoDBRepository.Object
            };

            // Act
            var result = await jobsUpdateDynamoDBRepository.UpdateProcessStatus(jobsUpdateMessage);

            // Assert
            Assert.IsType<Document>(result);
            Assert.Equal(doc, result);
            this.dynamoDBRepository.Verify(x => x.PartialUpdateCommandAsync(It.IsAny<JobsUpdateDynamoDBMessage>(), It.IsAny<ReturnValues>()), Times.Once);
        }

        /// <summary>
        /// Verify the save jobs update data in dynamo db
        /// </summary>
        /// <returns>True</returns>
        [Fact]
        public async Task SaveJobsUpdateRequest_Execute()
        {
            // Arrange
            JobsUpdateDynamoDBMessage jobsUpdateMessage = new JobsUpdateDynamoDBMessage()
            {
                CreatedDateTime = "3/13/2019 7:39:15 AM",
                Status = JobsUpdateStatus.Pending,
                ErrorMessage = string.Empty,
                MessageId = "0HLLDPLUFAJ2N:00000001",
                StatusUpdatedDateTime = DateTime.UtcNow.ToString()
            };

            this.dynamoTableConfig = new DynamoTableConfig { TableName = "TSMT-JobsUpdateData", ReadCapacityUnits = 3, WriteCapacityUnits = 1, KeyName = "MessageId", KeyType = typeof(string) };
            TSMTSettings appSetting = new TSMTSettings() { SqsServiceUrl = "arn: aws: sns: us - east - 1:611998158124:TSMT-JobsUpdateNotifier", MessageHidingTimeInMinutes = 2, DynamoRegion = "US-East-1", DynamoJobTableName = "TSMT-JobsUpdateData", DynamoJobKeyName = "MessageId" };

            var tsmtSettings = new Mock<IOptions<TSMTSettings>>();
            tsmtSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.dynamoDBRepository.Setup(x => x.InsertAsync(It.IsAny<JobsUpdateDynamoDBMessage>())).Returns(Task.FromResult(true));
            var jobsUpdateDynamoDBRepository = new JobsUpdateDynamoDBRepository(this.logger.Object, tsmtSettings.Object, this.dynamoTableConfig)
            {
                DynamoDBRepository = this.dynamoDBRepository.Object
            };

            // Act
            var insertStatus = await jobsUpdateDynamoDBRepository.SaveJobsUpdateRequest(jobsUpdateMessage);

            // Assert
            Assert.True(insertStatus);
            this.dynamoDBRepository.Verify(x => x.InsertAsync(It.IsAny<JobsUpdateDynamoDBMessage>()), Times.Once);
        }

        /// <summary>
        /// Verifies that getting message from dynamo db
        /// </summary>
        /// <returns>Jobs update message</returns>
        [Fact]
        public async Task GetMessage_ValidRequest_ReturnsData()
        {
            // Arrange
            string messageId = "0HLLDPLUFAJ2N:00000001";
            JobsUpdateDynamoDBMessage jobsUpdateMessage = new JobsUpdateDynamoDBMessage()
            {
                CreatedDateTime = "3/13/2019 7:39:15 AM",
                Status = JobsUpdateStatus.Pending.ToString(),
                ErrorMessage = string.Empty,
                MessageId = messageId,
                StatusUpdatedDateTime = DateTime.UtcNow.ToString(),
                Message = "[{\"DR_ADDRESS_ID\":78,\"JOB_ID\":106751}]"
            };

            this.dynamoTableConfig = new DynamoTableConfig { TableName = "TSMT-JobsUpdateData", ReadCapacityUnits = 3, WriteCapacityUnits = 1, KeyName = "MessageId", KeyType = typeof(string) };
            TSMTSettings appSetting = new TSMTSettings() { SqsServiceUrl = "arn: aws: sns: us - east - 1:611998158124:TSMT-JobsUpdateNotifier", MessageHidingTimeInMinutes = 2, DynamoRegion = "US-East-1", DynamoJobTableName = "TSMT-JobsUpdateData", DynamoJobKeyName = "MessageId" };

            var tsmtSettings = new Mock<IOptions<TSMTSettings>>();
            tsmtSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.dynamoDBRepository.Setup(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()))
 .Returns(Task.FromResult(jobsUpdateMessage));
            var jobsUpdateDynamoDBRepository = new JobsUpdateDynamoDBRepository(this.logger.Object, tsmtSettings.Object, this.dynamoTableConfig)
            {
                DynamoDBRepository = this.dynamoDBRepository.Object
            };

            // Act
            var result = await jobsUpdateDynamoDBRepository.GetMessage(messageId);

            // Assert
            Assert.Equal(result.MessageId, jobsUpdateMessage.MessageId);
            Assert.Equal(result.Message, jobsUpdateMessage.Message);
            this.dynamoDBRepository.Verify(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()), Times.Once);
        }

        /// <summary>
        /// Verify that returning empty message from dynamo db
        /// </summary>
        /// <returns>Empty jobs update message</returns>
        [Fact]
        public async Task GetMessage_InvalidRequest_ReturnsEmpty()
        {
            // Arrange
            string messageId = string.Empty;
            JobsUpdateDynamoDBMessage jobsUpdateMessage = new JobsUpdateDynamoDBMessage();

            this.dynamoTableConfig = new DynamoTableConfig { TableName = "TSMT-JobsUpdateData", ReadCapacityUnits = 3, WriteCapacityUnits = 1, KeyName = "MessageId", KeyType = typeof(string) };
            TSMTSettings appSetting = new TSMTSettings() { SqsServiceUrl = "arn: aws: sns: us - east - 1:611998158124:TSMT-JobsUpdateNotifier", MessageHidingTimeInMinutes = 2, DynamoRegion = "US-East-1", DynamoJobTableName = "TSMT-JobsUpdateData", DynamoJobKeyName = "MessageId" };

            var tsmtSettings = new Mock<IOptions<TSMTSettings>>();
            tsmtSettings.Setup(ap => ap.Value).Returns(appSetting);
            this.dynamoDBRepository.Setup(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()))
 .Returns(Task.FromResult(jobsUpdateMessage));
            var jobsUpdateDynamoDBRepository = new JobsUpdateDynamoDBRepository(this.logger.Object, tsmtSettings.Object, this.dynamoTableConfig)
            {
                DynamoDBRepository = this.dynamoDBRepository.Object
            };

            // Act
            var result = await jobsUpdateDynamoDBRepository.GetMessage(messageId);

            // Assert
            Assert.Equal(result, jobsUpdateMessage);
            this.dynamoDBRepository.Verify(x => x.GetAsync<JobsUpdateDynamoDBMessage>(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<bool>(), It.IsAny<List<string>>()), Times.Once);
        }
    }
}
