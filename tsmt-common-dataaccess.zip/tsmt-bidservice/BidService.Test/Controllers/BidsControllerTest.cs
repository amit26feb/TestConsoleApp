// <copyright file="BidsControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using AutoMapper;
   using BidService.Configurations.AutoMapperConfiguration;
   using BidService.Core.Command;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;
   using BidViewModelV2 = BidService.Core.ViewModels.V2.BidViewModel;

   public class BidsControllerTest
   {
      private readonly Mock<IBidService> bidServiceMock;
      private readonly Mock<ILogger<BidsController>> logger;
      private readonly Mock<IMediator> mediatorMock;
      private readonly IMapper mapper;
      private readonly BidsController controller;

      public BidsControllerTest()
      {
         this.bidServiceMock = new Mock<IBidService>();
         this.logger = new Mock<ILogger<BidsController>>();
         this.mediatorMock = new Mock<IMediator>();
         var config = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<AutoMapperProfile>();
         });
         this.mapper = new Mapper(config);
         this.controller = new BidsController(this.bidServiceMock.Object, this.logger.Object, this.mediatorMock.Object, this.mapper);
      }

      [Fact]
      public async Task Search_GivenValidCriteria_CallsBidService()
      {
         // Arrange
         var search = new BidSearchModel() { HqtrCreditJobId = 1 };
         IEnumerable<BidViewModel> bidList = new[] { new BidViewModel() };
         this.bidServiceMock.Setup(s => s.GetBidList(It.IsAny<BidSearchModel>())).Returns(Task.FromResult(bidList));

         // Act
         var result = await this.controller.Search(search);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidList(search), Times.Once);
      }

      [Fact]
      public async Task Search_GivenInvalidCriteria_ReturnsBadRequest()
      {
         // Arrange
         var search = new BidSearchModel() { };
         IEnumerable<BidViewModel> bidList = new[] { new BidViewModel() };
         this.bidServiceMock.Setup(s => s.GetBidList(It.IsAny<BidSearchModel>())).Returns(Task.FromResult(bidList));

         // Act
         var result = await this.controller.Search(search);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidList(search), Times.Never);
      }

      [Fact]
      public async Task GetBid_InValidParameters_ReturnsBadRequest()
      {
         // Arrange         

         // Act
         IActionResult bothBadResult = await this.controller.GetBid(0, 0);
         IActionResult badJobIdResult = await this.controller.GetBid(0, 1);
         IActionResult badBidIdResult = await this.controller.GetBid(1, 0);

         // Assert
         Assert.IsType<BadRequestObjectResult>(bothBadResult);
         BadRequestObjectResult typed = bothBadResult as BadRequestObjectResult;
         Assert.Equal("Invalid Request. JobId/BidAlternate '0/0' is not valid", typed.Value);
         Assert.IsType<BadRequestObjectResult>(badJobIdResult);
         typed = badJobIdResult as BadRequestObjectResult;
         Assert.Equal("Invalid Request. JobId/BidAlternate '0/1' is not valid", typed.Value);
         Assert.IsType<BadRequestObjectResult>(badBidIdResult);
         typed = badBidIdResult as BadRequestObjectResult;
         Assert.Equal("Invalid Request. JobId/BidAlternate '1/0' is not valid", typed.Value);
         this.bidServiceMock.Verify(x => x.GetBid(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task GetBid_ValidParametersAndBid_ReturnsOk()
      {
         // Arrange
         int validJob = 123;
         int validBid = 456;
         BidViewModel ourBlessedBid = new BidViewModel();
         this.bidServiceMock.Setup(b => b.GetBid(validJob, validBid)).Returns(Task.FromResult(ourBlessedBid));

         // Act
         IActionResult result = await this.controller.GetBid(validJob, validBid);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         OkObjectResult typedResult = result as OkObjectResult;
         this.bidServiceMock.Verify(x => x.GetBid(validJob, validBid), Times.Once);
      }

      [Fact]
      public async Task GetBid_ValidParametersAndNoBid_ReturnsNoContent()
      {
         // Arrange
         int validJob = 123;
         int validBid = 456;
         this.bidServiceMock.Setup(b => b.GetBid(validJob, validBid)).Returns(Task.FromResult<BidViewModel>(null));

         // Act
         IActionResult result = await this.controller.GetBid(validJob, validBid);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify(x => x.GetBid(validJob, validBid), Times.Once);
      }

      [Fact]
      public async Task GetBids_GivenInvalidJobId_ReturnsBadRequest()
      {
         // Arrange

         // Act
         var result = await this.controller.GetBids(-1);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task GetBids_GivenValidJobIdAndNoBids_ReturnsNoContent()
      {
         // Arrange
         IEnumerable<BidViewModel> bidList = new BidViewModel[] { };
         this.bidServiceMock.Setup(m => m.GetBidList(It.IsAny<int>(), It.IsAny<bool>())).Returns(Task.FromResult(bidList));

         // Act
         var result = await this.controller.GetBids(1);

         // Assert
         this.bidServiceMock.Verify(m => m.GetBidList(It.IsAny<int>(), false), Times.Once);
         Assert.IsType<NoContentResult>(result);
      }

      [Fact]
      public async Task GetBids_GivenBidResults_ReturnsOK()
      {
         // Arrange
         IEnumerable<BidViewModel> bidList = new[]
         {
            new BidViewModel(),
            new BidViewModel(),
            new BidViewModel()
         };
         this.bidServiceMock.Setup(m => m.GetBidList(It.IsAny<int>(), It.IsAny<bool>())).Returns(Task.FromResult(bidList));

         // Act
         var result = await this.controller.GetBids(1);

         // Assert
         Assert.IsType<OkObjectResult>(result);
      }

      [Fact]
      public async Task GetBids_GivenBidResults_ReturnsV2Models()
      {
         // Arrange
         IEnumerable<BidViewModel> moqBidList = new[]
         {
            new BidViewModel(),
            new BidViewModel(),
            new BidViewModel()
         };
         this.bidServiceMock.Setup(m => m.GetBidList(It.IsAny<int>(), It.IsAny<bool>())).Returns(Task.FromResult(moqBidList));

         // Act
         OkObjectResult objectResult = (OkObjectResult)(await this.controller.GetBids(1));

         // Assert
         var bids = (IEnumerable<BidViewModelV2>)objectResult.Value;
         Assert.NotNull(bids);
         Assert.Equal(moqBidList.Count(), bids.Count());
      }

      [Fact]
      public async Task CreateBid_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         int result = 1;
         var bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 178456,
            BidName = "LO",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "LO Desc",
            IncludeInCJ = 0,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(1)).Verifiable();

         // Act
         var actionResult = await this.controller.CreateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal(((ObjectResult)actionResult).Value, result);
         Assert.IsType<OkObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task CreateBid_EmptyRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         global::BidService.Core.ViewModels.BidCreateModel bidList = null;

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.CreateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.False(((BadRequestObjectResult)actionResult).Value.Equals(result));
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)), Times.Never);
      }

      [Fact]
      public async Task CreateBid_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         global::BidService.Core.ViewModels.BidCreateModel bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 1212,
            BidName = string.Empty,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.CreateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<CreateBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_ValidInput_ReturnsOkResult()
      {
         // Arrange
         int jobId = 1212;
         int bidAlternateId = 1421;
         var deletedStatus = 1;
         this.bidServiceMock.Setup(x => x.DeleteBid(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));

         // Act
         var result = await this.controller.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.bidServiceMock.Verify(x => x.DeleteBid(jobId, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_ValidInput_HasNoRecords_ReturnsNotFound()
      {
         // Arrange
         int jobId = 7654;
         int bidAlternateId = 79230;
         var deletedStatus = 0;
         this.bidServiceMock.Setup(x => x.DeleteBid(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));

         // Act
         var result = await this.controller.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.bidServiceMock.Verify(x => x.DeleteBid(jobId, bidAlternateId), Times.Once);
      }

      [Fact]
      public async Task DeleteBid_InvalidInput_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;
         int bidAlternateId = 0;
         var deletedStatus = 0;
         this.bidServiceMock.Setup(x => x.DeleteBid(jobId, bidAlternateId)).Returns(Task.FromResult(deletedStatus));

         // Act
         var result = await this.controller.DeleteBid(jobId, bidAlternateId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.DeleteBid(jobId, bidAlternateId), Times.Never);
      }

      [Fact]
      public async Task UpdateBid_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         int result = 1;
         var bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 27671,
            BidName = "Air Bids",
            BaseBidYesNo = 0,
            BidAlternateId = 657347,
            CurrentBidInd = "N",
            Description = "Air Bids Desc",
            IncludeInCJ = 0,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(1)).Verifiable();

         // Act
         var actionResult = await this.controller.UpdateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.Equal(((ObjectResult)actionResult).Value, result);
         Assert.IsType<OkObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task UpdateBid_EmptyRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         var bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 27671,
            BidName = "Airs Bids",
            BaseBidYesNo = 0,
            BidAlternateId = 0,
            CurrentBidInd = "N",
            Description = "Airs Bids Desc",
            IncludeInCJ = 0,
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.UpdateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         Assert.False(((BadRequestObjectResult)actionResult).Value.Equals(result));
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)), Times.Never);
      }

      [Fact]
      public async Task UpdateBid_InvalidRequest_ReturnsBadRequest()
      {
         // Arrange
         int result = 0;
         global::BidService.Core.ViewModels.BidCreateModel bidList = new global::BidService.Core.ViewModels.BidCreateModel()
         {
            JobId = 1212,
            BidName = string.Empty,
            BidAlternateId = 657347
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(result)).Verifiable();

         // Act
         var actionResult = await this.controller.UpdateBid(bidList);

         // Assert
         Assert.NotNull(actionResult);
         Assert.IsType<BadRequestObjectResult>(actionResult);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<UpdateBidCommand>(), default(CancellationToken)), Times.Once);
      }
   }
}