// <copyright file="SelectionControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Controllers
{
   using System.Collections.Generic;
   using System.Threading;
   using System.Threading.Tasks;
   using BidService.Core.Command;
   using BidService.Core.Commands;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class SelectionControllerTest
   {
      private readonly Mock<IBidService> bidServiceMock;
      private readonly Mock<ILogger<SelectionsController>> logger;
      private readonly Mock<IMediator> mediatorMock;
      private readonly SelectionsController controller;

      public SelectionControllerTest()
      {
         this.bidServiceMock = new Mock<IBidService>();
         this.logger = new Mock<ILogger<SelectionsController>>();
         this.mediatorMock = new Mock<IMediator>();
         this.controller = new SelectionsController(this.bidServiceMock.Object, this.logger.Object, this.mediatorMock.Object);
      }

      /// <summary>
      /// Verifies the bad request response when request is null
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task AddSelections_NullRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         AddSelectionViewModel addSelection = null;

         // Act
         var result = await this.controller.AddSelections(jobId, addSelection, bidAlternateId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<AddSelectionsCommand>(), default), Times.Never);
      }

      [Fact]
      public async Task AddSelections_ValidRequest_ReturnsOk()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         List<SeparatelyBiddableViewModel> separatelyBiddableIds = new List<SeparatelyBiddableViewModel>()
            {
                new SeparatelyBiddableViewModel()
                {
                    SeparatelyBiddableId = 3
                }
            };
         List<VariationViewModel> variationIds = new List<VariationViewModel>()
            {
                new VariationViewModel()
                {
                    VariationId = 7
                }
            };
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>()
            {
                new SelectionDetailsViewModel()
                {
                    SelectionId = 34,
                    ExcludeSelection = false,
                    SeparatelyBiddableViewModel = separatelyBiddableIds,
                    VariationViewModel = variationIds
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<AddSelectionsCommand>(), default))
             .Returns(Task.FromResult(true)).Verifiable();

         // Act
         var result = await this.controller.AddSelections(jobId, addSelection, bidAlternateId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.mediatorMock.Verify();
      }

      [Fact]
      public async Task AddSelections_RecordNotInserted_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 3456;
         int bidAlternateId = 23;
         List<SeparatelyBiddableViewModel> separatelyBiddableIds = new List<SeparatelyBiddableViewModel>()
            {
                new SeparatelyBiddableViewModel()
                {
                    SeparatelyBiddableId = 3
                }
            };
         List<VariationViewModel> variationIds = new List<VariationViewModel>()
            {
                new VariationViewModel()
                {
                    VariationId = 7
                }
            };
         List<SelectionDetailsViewModel> selectionDetails = new List<SelectionDetailsViewModel>()
            {
                new SelectionDetailsViewModel()
                {
                    SelectionId = 34,
                    ExcludeSelection = false,
                    SeparatelyBiddableViewModel = separatelyBiddableIds,
                    VariationViewModel = variationIds
                }
            };
         AddSelectionViewModel addSelection = new AddSelectionViewModel()
         {
            SelectionDetails = selectionDetails
         };

         this.mediatorMock.Setup(x => x.Send(It.IsAny<AddSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false)).Verifiable();

         // Act
         var result = await this.controller.AddSelections(jobId, addSelection, bidAlternateId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify();
      }

      [Fact]
      public async Task GetBidSelections_ValidJobId_ReturnsBidSelections()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidSelectionsViewModel> bidSelections = new List<BidSelectionsViewModel>
            {
                    new BidSelectionsViewModel()
                    {
                      BidAlternateId = 657058,
                    }
            };
         this.bidServiceMock.Setup(x => x.GetBidSelections(jobId)).Returns(Task.FromResult(bidSelections)).Verifiable();

         // Act
         var result = await this.controller.GetBidSelections(jobId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, bidSelections);
         this.bidServiceMock.Verify();
      }

      [Fact]
      public async Task GetBidSelections_ValidJobId_ReturnsNoContent()
      {
         // Arrange
         int jobId = 11466;
         IEnumerable<BidSelectionsViewModel> bidSelections = new List<BidSelectionsViewModel>();
         this.bidServiceMock.Setup(x => x.GetBidSelections(jobId)).Returns(Task.FromResult(bidSelections)).Verifiable();

         // Act
         var result = await this.controller.GetBidSelections(jobId);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify();
      }

      [Fact]
      public async Task GetBidSelections_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 0;

         // Act
         var result = await this.controller.GetBidSelections(jobId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidSelections(It.IsAny<int>()), Times.Never);
      }

      [Fact]
      public async Task DeleteSelections_ValidRequest_ReturnsOkResult()
      {
         // Arrange
         List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
         List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
         int jobId = 28643;
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
         {
            RemoveSelectionsRequest = removeSelectionsRequest,
            RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest
         };
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(true));

         // Act
         var result = await this.controller.DeleteSelections(jobId, removeAllSelectionsRequest, bidAlternateId);

         // Assert
         Assert.True((bool)((ObjectResult)result).Value);
         Assert.IsType<OkObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteSelections_ValidRequest_HasNoRecordsToDelete_ReturnsNotFound()
      {
         // Arrange
         List<RemoveSelectionsRequestViewModel> removeSelectionsRequest = new List<RemoveSelectionsRequestViewModel>
            {
                new RemoveSelectionsRequestViewModel() { SelectionId = 354354 },
            };
         List<RemoveSeparatelyBiddablesRequestViewModel> removeSeparatelyBiddablesRequest = new List<RemoveSeparatelyBiddablesRequestViewModel>
            {
                new RemoveSeparatelyBiddablesRequestViewModel() { SelectedPricingParmId = 195687 },
            };
         int jobId = 28643;
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = new RemoveAllSelectionsRequestViewModel
         {
            RemoveSelectionsRequest = removeSelectionsRequest,
            RemoveSeparatelyBiddablesRequest = removeSeparatelyBiddablesRequest
         };
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false));

         // Act
         var result = await this.controller.DeleteSelections(jobId, removeAllSelectionsRequest, bidAlternateId);

         // Assert
         Assert.IsType<NotFoundResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Once);
      }

      [Fact]
      public async Task DeleteSelections_InValidRequest_ReturnsBadRequest()
      {
         // Arrange
         int jobId = 28643;
         int bidAlternateId = 346545;
         RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest = null;
         this.mediatorMock.Setup(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)))
             .Returns(Task.FromResult(false));

         // Act
         var result = await this.controller.DeleteSelections(jobId, removeAllSelectionsRequest, bidAlternateId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.mediatorMock.Verify(x => x.Send(It.IsAny<RemoveSelectionsCommand>(), default(CancellationToken)), Times.Never);
      }
   }
}