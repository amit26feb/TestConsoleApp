// <copyright file="SelectionDetailsControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using BidService.Test.Common;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using Xunit;

   public class SelectionDetailsControllerTest
   {
      private readonly Mock<IBidService> bidServiceMock;
      private readonly Mock<ILogger<SelectionDetailsController>> logger;
      private readonly SelectionDetailsController controller;

      public SelectionDetailsControllerTest()
      {
         this.bidServiceMock = new Mock<IBidService>();
         this.logger = new Mock<ILogger<SelectionDetailsController>>();
         this.controller = new SelectionDetailsController(this.bidServiceMock.Object, this.logger.Object);
      }

      /// <summary>
      /// Verifies the ok response when the request is valid and contains the bid selection details
      /// </summary>
      /// <returns>Ok response</returns>
      [Fact]
      public async Task GetBidSelectionDetails_ValidRequestHasBidSelectionDetails_ReturnsOkResponse()
      {
         // Arrange
         IEnumerable<int> bidIds = new List<int>()
            {
               188619, 188630, 188631
            };
         IEnumerable<BidSelectionDetailsViewModel> bidSelectionDetails = new List<BidSelectionDetailsViewModel>()
            {
               CommonHelper.GetBidSelectionDetailsViewModel()
            };
         this.bidServiceMock.Setup(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(bidSelectionDetails));

         // Act
         var result = await this.controller.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         Assert.Equal(((OkObjectResult)result).Value, bidSelectionDetails);
         this.bidServiceMock.Verify(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>()), Times.Once);
      }

      /// <summary>
      /// Verifies the no content response when the request is valid and contains no bid selection details
      /// </summary>
      /// <returns>No content response</returns>
      [Fact]
      public async Task GetBidSelectionDetails_ValidRequestHasNoBidSelectionDetails_ReturnsNoContentResponse()
      {
         // Arrange
         IEnumerable<int> bidIds = new List<int>()
            {
               1886
            };
         IEnumerable<BidSelectionDetailsViewModel> bidSelectionDetails = Enumerable.Empty<BidSelectionDetailsViewModel>();
         this.bidServiceMock.Setup(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>())).Returns(Task.FromResult(bidSelectionDetails));

         // Act
         var result = await this.controller.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.IsType<NoContentResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>()), Times.Once);
      }

      /// <summary>
      /// Verifies the bad request response when the request is invalid
      /// </summary>
      /// <returns>Bad request response</returns>
      [Fact]
      public async Task GetBidSelectionDetails_InvalidRequest_ReturnsBadRequestResponse()
      {
         // Arrange
         IEnumerable<int> bidIds = Enumerable.Empty<int>();

         // Act
         var result = await this.controller.GetBidSelectionDetails(bidIds);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.bidServiceMock.Verify(x => x.GetBidSelectionDetails(It.IsAny<IEnumerable<int>>()), Times.Never);
      }
   }
}