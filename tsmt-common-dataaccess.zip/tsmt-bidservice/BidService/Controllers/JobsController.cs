﻿// <copyright file="JobsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Controllers
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using BidService.Common.Exceptions;
   using BidService.Core.Command;
   using BidService.Core.Commands;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Controller for bids
   /// </summary>
   [ApiVersion("1", Deprecated = true)]
   [Obsolete("v1 is deprecated as of v2.")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/Bids")]
   [Authorize]
   [ApiController]
   public class JobsController : Controller
   {
      private readonly IMediator mediator;
      private readonly ILogger<JobsController> logger;
      private readonly IBidService bidService;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobsController"/> class.
      /// </summary>
      /// <param name="bidService">Bid service</param>
      /// <param name="logger">Bid logger</param>
      /// <param name="mediator">Bid mediator</param>
      public JobsController(IBidService bidService, ILogger<JobsController> logger, IMediator mediator)
      {
         this.bidService = bidService;
         this.logger = logger;
         this.mediator = mediator;
      }

      /// <summary>
      /// Get BidList
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<BidViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetBidList(int jobId)
      {
         if (jobId > 0)
         {
            IEnumerable<BidViewModel> bidResults = await this.bidService.GetBidList(jobId, true);
            if (bidResults.Any())
            {
               return this.Ok(bidResults);
            }
            else
            {
               string message = $"No Bids available for Job Id: {jobId}";
               this.logger.LogError(message);
               return this.NoContent();
            }
         }
         else
         {
            string message = $"Invalid Request. Job Id '{jobId}' is not valid";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Get Bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>A bid view</returns>
      [Route("{bidAlternateId}")]
      [HttpGet]
      [ProducesResponseType(typeof(BidViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
      public async Task<IActionResult> GetBid(int jobId, int bidAlternateId)
      {
         if (jobId > 0 && bidAlternateId > 0)
         {
            BidViewModel bid = await this.bidService.GetBid(jobId, bidAlternateId);
            if (bid != null)
            {
               return this.Ok(bid);
            }
            else
            {
               string message = $"No bid found for Job Id: {jobId} Bid Alternate Id: {bidAlternateId}";
               this.logger.LogError(message);
               return this.NoContent();
            }
         }
         else
         {
            string message = $"Invalid Request. JobId/BidAlternate '{jobId}/{bidAlternateId}' is not valid";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Update current bid status
      /// </summary>
      /// <param name="jobId">Job Id</param>
      /// <param name="bidAlternateId">Bidalternate Id</param>
      /// <returns>Updated status</returns>
      [Route("{bidAlternateId}/Status")]
      [HttpPost]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> UpdateCurrentBid(int jobId, int bidAlternateId)
      {
         string errorMessage;
         if (jobId > 0 && bidAlternateId > 0)
         {
            var recordsUpdated = await this.mediator.Send(new UpdateCurrentBidCommand(jobId, bidAlternateId));
            if (recordsUpdated > 0)
            {
               this.logger.LogTrace("Current bid updated successfully");
               return (IActionResult)this.Ok(recordsUpdated);
            }
            else
            {
               errorMessage = $"Unexpected error occurred while updating the current bid - BidAlternateId: {bidAlternateId} and JobId: {jobId}";
            }
         }
         else
         {
            errorMessage = $"Invalid request, please check the request parameter - JobId: {jobId} and BidAlternateId: {bidAlternateId}";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Create Bid for Job
      /// </summary>
      /// <param name="request">Insert request payload</param>
      /// <returns>Created status</returns>
      [HttpPost]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> CreateBid([FromBody] BidCreateModel request)
      {
         string errorMessage;
         if (request != null && request.JobId > 0)
         {
            // create a Bid
            var createBidCommand = new CreateBidCommand(request);
            int commandResult = await this.mediator.Send(createBidCommand);

            // Check if the command has returned True(Inserted data in database)
            if (commandResult == 1)
            {
               this.logger.LogTrace("Bid created successfully");
               return (IActionResult)this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Unexpected error occurred while create bid on -jobId:{request.JobId}";
            }
         }
         else
         {
            errorMessage = $"Invalid request, please check the request parameter";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Deleting the bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id</param>
      /// <returns>Deleted status</returns>
      [Route("{bidAlternateId}")]
      [HttpDelete]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> DeleteBid(int jobId, int bidAlternateId)
      {
         if (jobId > 0 && bidAlternateId > 0)
         {
            var deletedRecords = await this.bidService.DeleteBid(jobId, bidAlternateId);
            if (deletedRecords == 1)
            {
               this.logger.LogTrace("Bid deleted successfully");
               return (IActionResult)this.Ok(deletedRecords);
            }

            this.logger.LogTrace($"Selected bid does not exist or it can't be deleted for - BidAlternateId: {bidAlternateId} and JobId: {jobId}");
            return (IActionResult)this.NotFound();
         }

         string errorMessage = $"Invalid request, please check the request parameter - BidAlternateId: {bidAlternateId} and JobId: {jobId}";
         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Update bid for bidAlternateId
      /// </summary>
      /// <param name="request">Update request payload</param>
      /// <returns>Updated status</returns>
      [Route("{bidAlternateId}")]
      [HttpPut]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> UpdateBid([FromBody] BidCreateModel request)
      {
         string errorMessage;
         if (request.JobId > 0 && request.BidAlternateId > 0)
         {
            // Update a Bid
            var commandResult = await this.mediator.Send(new UpdateBidCommand(request));

            // Check if the command has returned row count(Updated data in database)
            if (commandResult == 1)
            {
               this.logger.LogTrace("Current bid updated successfully");
               return (IActionResult)this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Unexpected error occurred while updating the bid - BidAlternateId: {request.BidAlternateId} and JobId: {request.JobId}";
            }
         }
         else
         {
            errorMessage = $"Invalid request, please check the request parameter - BidAlternateId: {request.BidAlternateId} and JobId: {request.JobId}";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Gets list of bid selections for a given job id
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <returns>List of bid selections</returns>
      [Route("Selections")]
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<BidSelectionsViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetBidSelections(int jobId)
      {
         string message;
         if (jobId > 0)
         {
            IEnumerable<BidSelectionsViewModel> bidSelectionResults = await this.bidService.GetBidSelections(jobId);
            if (bidSelectionResults.Any())
            {
               return this.Ok(bidSelectionResults);
            }
            else
            {
               message = $"No Bid selections available for Job Id: {jobId}";
               this.logger.LogError(message);
               return this.NoContent();
            }
         }
         else
         {
            message = $"Invalid Request. Job Id is not valid";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Adds selection/separately biddable/selection variation/job variation to bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name= "request">Add selections request payload</param>
      /// <returns>True if records inserted else false</returns>
      [Route("{bidAlternateId}/Selections")]
      [HttpPost]
      [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> AddSelections(int jobId, int bidAlternateId, [FromBody] AddSelectionViewModel request)
      {
         string errorMessage;
         bool isBidAlternateIdValidationRequired = true;
         if (request != null)
         {
            var addSelectionCommand = new AddSelectionsCommand(jobId, bidAlternateId, request, isBidAlternateIdValidationRequired);
            var commandResult = await this.mediator.Send(addSelectionCommand);

            // Check if the command has returned True(Inserted data in database)
            if (commandResult)
            {
               this.logger.LogTrace($"Selections added succesfully for job id:{jobId} and bid alternate id:{bidAlternateId}");
               return this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Error occurred while adding selections for job id:{jobId} and bid alternate id:{bidAlternateId}";
            }
         }
         else
         {
            errorMessage = $"Invalid request parameters with job id: {jobId} and bid alternate id:{bidAlternateId}";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Add job variation to bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name= "request">Add selections request payload</param>
      /// <returns>True if records inserted else false</returns>
      [Route("Selections")]
      [HttpPost]
      [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> AddJobVariation(int jobId, [FromBody] AddSelectionViewModel request)
      {
         string errorMessage;
         if (request != null)
         {
            // Here bid alternate id is zero since current bid alternate id of job will be added to
            // creating non trane item(variation) in service
            int bidAlternateId = 0;

            var addSelectionCommand = new AddSelectionsCommand(jobId, bidAlternateId, request, false);
            var commandResult = await this.mediator.Send(addSelectionCommand);

            // Check if the command has returned True(Inserted data in database)
            if (commandResult)
            {
               this.logger.LogTrace($"Job variation added succesfully for job id:{jobId}");
               return this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Error occurred while adding job variation for job id:{jobId}";
            }
         }
         else
         {
            errorMessage = "Invalid request, please check the request parameter";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Delete selections from a bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="removeSelectionsRequest">Request for removing selections</param>
      /// <returns>Deleted status</returns>
      [Route("{bidAlternateId}/Selections")]
      [HttpDelete]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> DeleteSelections(int jobId, int bidAlternateId, [FromBody] RemoveAllSelectionsRequestViewModel removeSelectionsRequest)
      {
         bool isBidAlternateIdValidationRequired = true;
         if (removeSelectionsRequest != null)
         {
            var isRecordsDeleted = await this.mediator.Send(new RemoveSelectionsCommand(jobId, bidAlternateId, removeSelectionsRequest, isBidAlternateIdValidationRequired));
            if (isRecordsDeleted)
            {
               this.logger.LogTrace("Selections deleted successfully");
               return (IActionResult)this.Ok(isRecordsDeleted);
            }

            this.logger.LogError("Selections does not exists");
            return (IActionResult)this.NotFound();
         }

         string errorMessage = $"Invalid request, please check the request parameter";
         this.logger.LogError(errorMessage);
         return (IActionResult)this.BadRequest(errorMessage);
      }

      /// <summary>
      /// Delete variaton of a bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="removeSelectionsRequest">Request for removing selections</param>
      /// <returns>Deleted status</returns>
      [Route("Variations")]
      [HttpDelete]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> DeleteJobVariation(int jobId, [FromBody] RemoveAllSelectionsRequestViewModel removeSelectionsRequest)
      {
         if (removeSelectionsRequest != null)
         {
            var isRecordsDeleted = await this.mediator.Send(new RemoveSelectionsCommand(jobId, 0, removeSelectionsRequest, false));
            if (isRecordsDeleted)
            {
               this.logger.LogTrace("Variation deleted successfully");
               return (IActionResult)this.Ok(isRecordsDeleted);
            }

            this.logger.LogWarning("Variation does not exists");
            return (IActionResult)this.NotFound();
         }

         string errorMessage = $"Invalid request, please check the request parameter";
         this.logger.LogError(errorMessage);
         return (IActionResult)this.BadRequest(errorMessage);
      }

      /// <summary>
      /// Get bids for coordination
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Bids for coordination</returns>
      [Route("BidsForCoordination")]
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<CoordinationJobBidViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetBidsForCoodination(int jobId)
      {
         if (jobId > 0)
         {
            IEnumerable<CoordinationJobBidViewModel> bidsForCoordination = await this.bidService.GetBidsForCoordination(jobId);
            if (bidsForCoordination.Any())
            {
               return this.Ok(bidsForCoordination);
            }
            else
            {
               this.logger.LogWarning($"No Bids available for Job Id: {jobId}");
               return this.NoContent();
            }
         }
         else
         {
            string message = $"Invalid Request. Job Id '{jobId}' is not valid";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Update bid whether included for job coordination or not
      /// </summary>
      /// <param name="updateJobCoordinationStatusForBidsCommand">Update job coordination status for bids command</param>
      /// <returns>No content if the job status is updated,
      /// Bad request response if the job status is not updated</returns>
      [Route("JobCoordinationStatus")]
      [HttpPut]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<ActionResult> UpdateJobCoordinationStatusForBids([FromBody] UpdateJobCoordinationStatusForBidsCommand updateJobCoordinationStatusForBidsCommand)
      {
         if (updateJobCoordinationStatusForBidsCommand != null)
         {
            this.logger.LogTrace("Bid update process has been started");
            bool result = await this.mediator.Send(updateJobCoordinationStatusForBidsCommand);
            if (result)
            {
               this.logger.LogTrace("Bids updated successfully");
               return this.NoContent();
            }
         }

         this.logger.LogTrace("Bids update failed");
         return this.BadRequest("Error while updating bids");
      }

      /// <summary>
      /// Gets the bid selection details
      /// </summary>
      /// <param name="bidIds">Bid ids</param>
      /// <returns>Bid selection details</returns>
      [Route("BidSelectionDetails")]
      [HttpPost]
      [ProducesResponseType(typeof(IEnumerable<BidSelectionDetailsViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetBidSelectionDetails([FromBody] IEnumerable<int> bidIds)
      {
         if (bidIds.Any() && bidIds.All(x => x > 0))
         {
            var bidSelectionDetails = await this.bidService.GetBidSelectionDetails(bidIds);
            return bidSelectionDetails.Any() ? (IActionResult)this.Ok(bidSelectionDetails) : this.NoContent();
         }

         string errorMessage = "Empty bid id list / Invalid bid id";
         this.logger.LogError(errorMessage);
         return this.BadRequest(errorMessage);
      }
   }
}
