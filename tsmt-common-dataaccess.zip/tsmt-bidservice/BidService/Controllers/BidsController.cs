﻿// <copyright file="BidsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using AutoMapper;
   using BidService.Common.Exceptions;
   using BidService.Core.Command;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Controller for bids
   /// </summary>
   [ApiVersion("1", Deprecated = true)]
   [ApiVersion("2")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/Bids")]
   [Authorize]
   [ApiController]
   public class BidsController : Controller
   {
      private readonly IMediator mediator;
      private readonly IMapper mapper;
      private readonly ILogger<BidsController> logger;
      private readonly IBidService bidService;

      /// <summary>
      /// Initializes a new instance of the <see cref="BidsController"/> class.
      /// </summary>
      /// <param name="bidService">Bid service</param>
      /// <param name="logger">Bid logger</param>
      /// <param name="mediator">Bid mediator</param>
      /// <param name="mapper">Automapper!!!</param>
      public BidsController(IBidService bidService, ILogger<BidsController> logger, IMediator mediator, IMapper mapper)
      {
         this.bidService = bidService;
         this.logger = logger;
         this.mediator = mediator;
         this.mapper = mapper;
      }

      /// <summary>
      /// Get BidList
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      [HttpGet]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(IEnumerable<Core.ViewModels.V2.BidViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public virtual async Task<IActionResult> GetBids(int jobId)
      {
         if (jobId > 0)
         {
            List<BidViewModel> bidResults = (await this.bidService.GetBidList(jobId)).ToList();
            if (bidResults.Count > 0)
            {
               Core.ViewModels.V2.BidViewModel[] v2Results = this.mapper.Map<IEnumerable<BidViewModel>, Core.ViewModels.V2.BidViewModel[]>(bidResults);
               return this.Ok(v2Results);
            }
            else
            {
               string message = $"No Bids available for Job Id: {jobId}";
               this.logger.LogError(message);
               return this.NoContent();
            }
         }
         else
         {
            string message = $"Invalid Request. Job Id '{jobId}' is not valid";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Get Bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>A bid view</returns>
      [Route("{bidAlternateId}")]
      [HttpGet]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(Core.ViewModels.V2.BidViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
      public async Task<IActionResult> GetBid(int jobId, int bidAlternateId)
      {
         if (jobId > 0 && bidAlternateId > 0)
         {
            BidViewModel bid = await this.bidService.GetBid(jobId, bidAlternateId);
            if (bid != null)
            {
               return this.Ok(this.mapper.Map<Core.ViewModels.V2.BidViewModel>(bid));
            }
            else
            {
               string message = $"No bid found for Job Id: {jobId} Bid Alternate Id: {bidAlternateId}";
               this.logger.LogError(message);
               return this.NoContent();
            }
         }
         else
         {
            string message = $"Invalid Request. JobId/BidAlternate '{jobId}/{bidAlternateId}' is not valid";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Searches bids by the criteria provided.  <see cref="BidSearchModel"/>
      /// </summary>
      /// <param name="criteria">The search criteria</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      [HttpPost]
      [Route("Search")]
      [MapToApiVersion("1")]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(IEnumerable<Core.ViewModels.V2.BidViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> Search([FromBody]BidSearchModel criteria)
      {
         if (criteria.IsValid())
         {
            var bidResults = await this.bidService.GetBidList(criteria);
            Core.ViewModels.V2.BidViewModel[] v2Results = this.mapper.Map<IEnumerable<BidViewModel>, Core.ViewModels.V2.BidViewModel[]>(bidResults);
            return this.Ok(v2Results);
         }
         else
         {
            string message = $"Invalid Request. At least one search criteria is required.";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Create Bid for Job
      /// </summary>
      /// <param name="request">Insert request payload</param>
      /// <returns>Created status</returns>
      [HttpPost]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> CreateBid([FromBody]BidCreateModel request)
      {
         string errorMessage;
         if (request != null && request.JobId > 0)
         {
            // create a Bid
            var createBidCommand = new CreateBidCommand(request);
            int commandResult = await this.mediator.Send(createBidCommand);

            // Check if the command has returned True(Inserted data in database)
            if (commandResult == 1)
            {
               this.logger.LogTrace("Bid created successfully");
               return (IActionResult)this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Unexpected error occurred while create bid on -jobId:{request.JobId}";
            }
         }
         else
         {
            errorMessage = $"Invalid request, please check the request parameter";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Deleting the bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id</param>
      /// <returns>Deleted status</returns>
      [Route("{bidAlternateId}")]
      [HttpDelete]
      [MapToApiVersion("2")]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> DeleteBid(int jobId, int bidAlternateId)
      {
         if (jobId > 0 && bidAlternateId > 0)
         {
            var deletedRecords = await this.bidService.DeleteBid(jobId, bidAlternateId);
            if (deletedRecords == 1)
            {
               this.logger.LogTrace("Bid deleted successfully");
               return (IActionResult)this.Ok(deletedRecords);
            }

            this.logger.LogTrace($"Selected bid does not exist or it can't be deleted for - BidAlternateId: {bidAlternateId} and JobId: {jobId}");
            return (IActionResult)this.NotFound();
         }

         string errorMessage = $"Invalid request, please check the request parameter - BidAlternateId: {bidAlternateId} and JobId: {jobId}";
         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Update bid for bidAlternateId
      /// </summary>
      /// <param name="request">Update request payload</param>
      /// <returns>Updated status</returns>
      [Route("{bidAlternateId}")]
      [HttpPut]
      [MapToApiVersion("2")]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> UpdateBid([FromBody]BidCreateModel request)
      {
         string errorMessage;
         if (request.JobId > 0 && request.BidAlternateId > 0)
         {
            // Update a Bid
            var commandResult = await this.mediator.Send(new UpdateBidCommand(request));

            // Check if the command has returned row count(Updated data in database)
            if (commandResult == 1)
            {
               this.logger.LogTrace("Current bid updated successfully");
               return (IActionResult)this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Unexpected error occurred while updating the bid - BidAlternateId: {request.BidAlternateId} and JobId: {request.JobId}";
            }
         }
         else
         {
            errorMessage = $"Invalid request, please check the request parameter - BidAlternateId: {request.BidAlternateId} and JobId: {request.JobId}";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }
   }
}