﻿// <copyright file="SelectionsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using BidService.Common.Exceptions;
   using BidService.Core.Command;
   using BidService.Core.Commands;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using MediatR;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Controller for bids
   /// </summary>
   [ApiVersion("2")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/Selections")]
   [Authorize]
   [ApiController]
   public class SelectionsController : Controller
   {
      private readonly IMediator mediator;
      private readonly ILogger<SelectionsController> logger;
      private readonly IBidService bidService;

      /// <summary>
      /// Initializes a new instance of the <see cref="SelectionsController"/> class.
      /// </summary>
      /// <param name="bidService">Bid service</param>
      /// <param name="logger">Bid logger</param>
      /// <param name="mediator">Bid mediator</param>
      public SelectionsController(IBidService bidService, ILogger<SelectionsController> logger, IMediator mediator)
      {
         this.bidService = bidService;
         this.logger = logger;
         this.mediator = mediator;
      }

      /// <summary>
      /// Gets list of bid selections for a given job id
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <returns>List of bid selections</returns>
      [HttpGet]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(IEnumerable<BidSelectionsViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetBidSelections(int jobId)
      {
         string message;
         if (jobId > 0)
         {
            IEnumerable<BidSelectionsViewModel> bidSelectionResults = await this.bidService.GetBidSelections(jobId);
            if (bidSelectionResults.Any())
            {
               return this.Ok(bidSelectionResults);
            }
            else
            {
               message = $"No Bid selections available for Job Id: {jobId}";
               this.logger.LogError(message);
               return this.NoContent();
            }
         }
         else
         {
            message = $"Invalid Request. Job Id is not valid";
            this.logger.LogError(message);
            return this.BadRequest(message);
         }
      }

      /// <summary>
      /// Adds selection/separately biddable/selection variation/job variation to bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// /// <param name= "request">Add selections request payload</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>True if records inserted else false</returns>
      [HttpPost]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> AddSelections(int jobId, [FromBody]AddSelectionViewModel request, int? bidAlternateId = null)
      {
         string errorMessage;
         if (request != null)
         {
            var addSelectionCommand = new AddSelectionsCommand(jobId, bidAlternateId.GetValueOrDefault(0), request, bidAlternateId.HasValue);
            var commandResult = await this.mediator.Send(addSelectionCommand);

            // Check if the command has returned True(Inserted data in database)
            if (commandResult)
            {
               this.logger.LogTrace($"Selections added succesfully for job id:{jobId} and bid alternate id:{bidAlternateId}");
               return this.Ok(commandResult);
            }
            else
            {
               errorMessage = $"Error occurred while adding selections for job id:{jobId} and bid alternate id:{bidAlternateId}";
            }
         }
         else
         {
            errorMessage = $"Invalid request parameters with job id: {jobId} and bid alternate id:{bidAlternateId}";
         }

         this.logger.LogError(errorMessage);
         return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
      }

      /// <summary>
      /// Delete selections from a bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="removeSelectionsRequest">Request for removing selections</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <returns>Deleted status</returns>
      [HttpDelete]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.NotFound)]
      public async Task<IActionResult> DeleteSelections(int jobId, [FromBody]RemoveAllSelectionsRequestViewModel removeSelectionsRequest, int? bidAlternateId = null)
      {
         if (removeSelectionsRequest != null)
         {
            var isRecordsDeleted = await this.mediator.Send(new RemoveSelectionsCommand(jobId, bidAlternateId.GetValueOrDefault(0), removeSelectionsRequest, bidAlternateId.HasValue));
            if (isRecordsDeleted)
            {
               this.logger.LogTrace("Selections deleted successfully");
               return (IActionResult)this.Ok(isRecordsDeleted);
            }

            this.logger.LogError("Selections does not exists");
            return (IActionResult)this.NotFound();
         }

         string errorMessage = $"Invalid request, please check the request parameter";
         this.logger.LogError(errorMessage);
         return (IActionResult)this.BadRequest(errorMessage);
      }
   }
}