// <copyright file="SelectionDetailsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Controllers
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using BidService.Core.Services;
   using BidService.Core.ViewModels;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Controller for bids
   /// </summary>
   [ApiVersion("2")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/SelectionDetails")]
   [Authorize]
   [ApiController]
   public class SelectionDetailsController : Controller
   {
      private readonly ILogger<SelectionDetailsController> logger;
      private readonly IBidService bidService;

      /// <summary>
      /// Initializes a new instance of the <see cref="SelectionDetailsController"/> class.
      /// </summary>
      /// <param name="bidService">Bid service</param>
      /// <param name="logger">Bid logger</param>
      public SelectionDetailsController(IBidService bidService, ILogger<SelectionDetailsController> logger)
      {
         this.bidService = bidService;
         this.logger = logger;
      }

      /// <summary>
      /// Gets the bid selection details
      /// </summary>
      /// <param name="bidIds">Bid ids</param>
      /// <returns>Bid selection details</returns>
      [HttpPost]
      [MapToApiVersion("2")]
      [ProducesResponseType(typeof(IEnumerable<BidSelectionDetailsViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.NoContent)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetBidSelectionDetails([FromBody]IEnumerable<int> bidIds)
      {
         if (bidIds.Any() && bidIds.All(x => x > 0))
         {
            var bidSelectionDetails = await this.bidService.GetBidSelectionDetails(bidIds);
            return bidSelectionDetails.Any() ? (IActionResult)this.Ok(bidSelectionDetails) : this.NoContent();
         }

         string errorMessage = "Empty bid id list / Invalid bid id";
         this.logger.LogError(errorMessage);
         return this.BadRequest(errorMessage);
      }
   }
}