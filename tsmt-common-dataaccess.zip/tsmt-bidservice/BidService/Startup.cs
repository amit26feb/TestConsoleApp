﻿// <copyright file="Startup.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService
{
   using System;
   using System.IO;
   using System.Linq;
   using System.Reflection;
   using App.Metrics;
   using Autofac;
   using Autofac.Extensions.DependencyInjection;
   using AutoMapper;
   using BidService.Common.Configurations.AutofacModules;
   using BidService.Common.Filters;
   using BidService.Common.Middlewares;
   using BidService.Configurations.AutoMapperConfiguration;
   using BidService.Configurations.Swagger;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Builder;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.AspNetCore.Mvc.ApiExplorer;
   using Microsoft.AspNetCore.Mvc.Authorization;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.Extensions.Options;
   using Microsoft.Extensions.PlatformAbstractions;
   using NLog.Web;
   using Okta.AspNetCore;
   using Swashbuckle.AspNetCore.SwaggerGen;
   using TraneSalesTools.Middlewares;
   using TSMT.Settings;

   /// <summary>
   /// Startup
   /// </summary>
   public class Startup
   {
      private readonly string repositoryTag;

      /// <summary>
      /// Initializes a new instance of the <see cref="Startup"/> class.
      /// </summary>
      /// <param name="configuration">configuration</param>
      /// <param name="env">env</param>
      public Startup(IConfiguration configuration, IWebHostEnvironment env)
      {
         this.Configuration = configuration;
         this.HostingEnvironment = env;
         if (!env.EnvironmentName.Contains("UnitTest"))
         {
            NLogBuilder.ConfigureNLog($"nlog.{env.EnvironmentName}.config");
         }

         this.repositoryTag = Environment.GetEnvironmentVariable("REPOSITORY_TAG");
         if (string.IsNullOrWhiteSpace(this.repositoryTag))
         {
            this.repositoryTag = "localhost";
         }
      }

      /// <summary>
      /// Gets Configuration
      /// </summary>
      public IConfiguration Configuration { get; }

      /// <summary>
      /// Gets the Web host Environment.
      /// </summary>
      public IWebHostEnvironment HostingEnvironment { get; }

      private static string XmlCommentsFilePath
      {
         get
         {
            var basePath = PlatformServices.Default.Application.ApplicationBasePath;
            var fileName = typeof(Startup).GetTypeInfo().Assembly.GetName().Name + ".xml";
            return Path.Combine(basePath, fileName);
         }
      }

      /// <summary>
      /// Initializes a new instance of the <see cref="IServiceProvider"/> class.
      /// </summary>
      /// <param name="services">configuration</param>
      /// <returns>Config</returns>
      public IServiceProvider ConfigureServices(IServiceCollection services)
      {
         var metrics = AppMetrics.CreateDefaultBuilder()

                     .Configuration.Configure(
                         options =>
                         {
                            options.AddEnvTag(this.HostingEnvironment.EnvironmentName);
                         })
                       .Report.ToInfluxDb(options =>
                       {
                          options.InfluxDb.BaseUri = new Uri(this.Configuration["InfluxDbUrl"]);
                          options.InfluxDb.Database = this.Configuration["InfluxDb"];
                          options.InfluxDb.UserName = this.Configuration["InfluxDbUserName"];
                          options.InfluxDb.Password = this.Configuration["InfluxDbPassword"];
                          options.InfluxDb.CreateDataBaseIfNotExists = true;
                       }).Build();

         services.AddMetrics(metrics);
         services.AddMetricsReportingHostedService();
         services.AddMetricsEndpoints();
         services.AddMetricsTrackingMiddleware();

         // Add framework services.
         services.AddMvc(options =>
         {
            options.Filters.Add(typeof(HttpGlobalExceptionFilter));
            AuthorizationPolicy policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
            options.Filters.Add(new AuthorizeFilter(policy));
         }).AddControllersAsServices().AddMetrics().AddNewtonsoftJson();

         services.AddMvcCore(options =>
         {
            options.Filters.Add(typeof(HttpGlobalExceptionFilter));
         }).AddControllersAsServices();

         services.Configure<TSMTSettings>(this.Configuration);
         services.AddSingleton<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>(provider =>
         {
            return new ConfigureSwaggerOptions(provider.GetService<IApiVersionDescriptionProvider>(), this.HostingEnvironment.ApplicationName, this.repositoryTag);
         });
         services.AddSwaggerGen(options =>
         {
            options.OperationFilter<SwaggerDefaultValues>();
            options.IncludeXmlComments(XmlCommentsFilePath);
         });

         services.AddApiVersioning(options =>
         {
            options.ReportApiVersions = true;
            options.DefaultApiVersion = new ApiVersion(2, 0);
         });

         services.AddVersionedApiExplorer(
            options =>
            {
               // add the versioned api explorer, which also adds IApiVersionDescriptionProvider service
               // note: the specified format code will format the version as "'v'major[.minor][-status]"
               options.GroupNameFormat = "'v'VVV";

               // note: this option is only necessary when versioning by url segment. the SubstitutionFormat
               // can also be used to control the format of the API version in route templates
               options.SubstituteApiVersionInUrl = true;
            });

         services.AddAuthentication(options =>
         {
            options.DefaultAuthenticateScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultChallengeScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultSignInScheme = OktaDefaults.ApiAuthenticationScheme;
         })
         .AddOktaWebApi(new OktaWebApiOptions()
         {
            OktaDomain = this.Configuration["OktaDomain"],
            AuthorizationServerId = this.Configuration["OktaAuthorizationServerID"]
         });

         services.AddCors(options =>
         {
            options.AddPolicy(
                   "CorsPolicy",
                   builder => builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader());
         });

         services.AddOptions();

         services.AddAutoMapper(typeof(AutoMapperProfile));

         // configure autofac
         var container = new ContainerBuilder();
         container.Populate(services);

         // The mediator module uses the pipeline, notification and Request/Response Command handler
         // This is stored as a separate Module
         container.RegisterModule(new MediatorModule());

         return new AutofacServiceProvider(container.Build());
      }

      /// <summary>
      /// Configures the application using the provided builder, hosting environment, and API version description provider.
      /// </summary>
      /// <param name="app">The current application builder.</param>
      /// <param name="provider">The API version descriptor provider used to enumerate defined API versions.</param>
      public void Configure(IApplicationBuilder app, IApiVersionDescriptionProvider provider)
      {
         var pathBase = this.Configuration["PATH_BASE"];

         if (!string.IsNullOrEmpty(pathBase))
         {
            app.UsePathBase(pathBase);
         }

         app.UseLogger();
         app.UseMetricsAllMiddleware();
         app.UseMetricsAllEndpoints();
         app.UseRouting();
         app.UseCors("CorsPolicy");
         app.UseAuthentication();
         app.UseAuthorization();
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
            {
               appBuilder.UseDrAddressIdResolver();
            });
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseVPDAuthenticator();
         });

#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
         app.Map("/liveness", lapp => lapp.Run(async ctx => ctx.Response.StatusCode = 200));
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously

         app.UseEndpoints(endpoints =>
         {
            endpoints.MapControllers();
         });

         app.UseSwagger()
            .UseSwaggerUI(options =>
            {
               // build a swagger endpoint for each discovered API version
               foreach (var description in provider.ApiVersionDescriptions.OrderByDescending(v => v.ApiVersion.MajorVersion))
               {
                  options.SwaggerEndpoint($"{(!string.IsNullOrEmpty(pathBase) ? pathBase : string.Empty)}/swagger/{description.GroupName}/swagger.json", description.GroupName.ToLowerInvariant());
               }
            });
      }
   }
}
