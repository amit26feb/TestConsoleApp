﻿// <copyright file="BidSelectionDetails.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Models
{
   /// <summary>
   /// Represents the bid selection details
   /// </summary>
   public class BidSelectionDetails
   {
      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets bid name
      /// </summary>
      public string BID_NAME { get; set; }

      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets selection type
      /// </summary>
      public string SELECTION_TYPE { get; set; }
   }
}
