﻿// <copyright file="CoordinationJobBid.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Models
{
   /// <summary>
   /// Represents the coordination job bid
   /// </summary>
   public class CoordinationJobBid
   {
      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets bid name
      /// </summary>
      public string BID_NAME { get; set; }

      /// <summary>
      /// Gets or sets indicator which shows whether the bid is included for job coordination
      /// </summary>
      public int? INCLUDE_IN_CJ { get; set; }

      /// <summary>
      /// Gets or sets current bid indicator
      /// </summary>
      public string CURRENT_BID_IND { get; set; }

      /// <summary>
      /// Gets or sets base bid indicator
      /// </summary>
      public int BASE_BID_YES_NO { get; set; }
   }
}
