// <copyright file="BidAlternate.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Models
{
   using System.ComponentModel.DataAnnotations.Schema;
   using TSMT.DataAccess;

   /// <summary>
   /// Bid Alternate
   /// </summary>
   [Table("BID_ALTERNATE")]
   public class BidAlternate : IDataEntity
   {
      /// <summary>
      /// Gets or sets JOB ID
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets BID ALTERNATE ID
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets BASE BID YES NO
      /// </summary>
      public int BASE_BID_YES_NO { get; set; }

      /// <summary>
      /// Gets or sets BID NAME
      /// </summary>
      public string BID_NAME { get; set; }

      /// <summary>
      /// Gets or sets CURRENT BID IND
      /// </summary>
      public string CURRENT_BID_IND { get; set; }

      /// <summary>
      /// Gets or sets INCLUDE IN CJ
      /// </summary>
      public int? INCLUDE_IN_CJ { get; set; }

      /// <summary>
      /// Gets or sets DESCR
      /// </summary>
      public string DESCR { get; set; }

      /// <summary>
      /// Gets or sets SELLING_PRICE
      /// </summary>
      public int? SELLING_PRICE { get; set; }

      /// <summary>
      /// Gets or sets hqtr bid alternate id
      /// </summary>
      public int? HQTR_BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets legacy job number
      /// </summary>
      public string LEGACY_JOB_NBR { get; set; }

      /// <summary>
      /// Gets or sets foe2 created orders indicator
      /// </summary>
      public string FOE2_CREATED_ORDERS_IND { get; set; }
   }
}
