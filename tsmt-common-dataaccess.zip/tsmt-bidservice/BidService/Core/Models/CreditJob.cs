﻿// <copyright file="CreditJob.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Models
{
   /// <summary>
   /// Database model for a credit job
   /// </summary>
   public class CreditJob
   {
      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets purchase order number
      /// </summary>
      public string PurchaseOrderNumber { get; set; }

      /// <summary>
      /// Gets or sets credit job number
      /// </summary>
      public string CreditJobNumber { get; set; }

      /// <summary>
      /// Gets or sets headquarter credit job id
      /// </summary>
      public int? HqtrCreditJobId { get; set; }
   }
}
