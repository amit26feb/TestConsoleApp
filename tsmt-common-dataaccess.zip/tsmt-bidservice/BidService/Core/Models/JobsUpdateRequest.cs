// <copyright file="JobsUpdateRequest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Models
{
   using System;
   using System.ComponentModel.DataAnnotations;
   using BidService.Common.Constants;
   using TSMT.DataAccess;

   /// <summary>
   /// Model for jobs update request
   /// </summary>
   public class JobsUpdateRequest : IDataEntity
   {
      /// <summary>
      /// Gets or sets DrAddressId
      /// </summary>
      [Range(1, int.MaxValue)]
      public int DR_ADDRESSID_ID { get; set; }

      /// <summary>
      /// Gets or sets JobId
      /// </summary>
      [Range(1, int.MaxValue)]
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets LastUpdate
      /// </summary>
      public DateTime LAST_UPDATE { get; set; }

      /// <summary>
      /// Gets or sets bid name
      /// </summary>
      public string BID_NAME { get; set; }

      /// <summary>
      /// Gets or sets notification type
      /// </summary>
      public BidNotificationType BID_NOTIFICATION_TYPE { get; set; }

      /// <summary>
      /// Gets or sets user name
      /// </summary>
      public string USER_NAME { get; set; }

      /// <summary>
      /// Gets or sets user id
      /// </summary>
      public string USER_ID { get; set; }
   }
}
