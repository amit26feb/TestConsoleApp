﻿// <copyright file="BidSelections.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Models
{
   using TSMT.DataAccess;

   /// <summary>
   /// Bid Selections
   /// </summary>
   public class BidSelections : IDataEntity
   {
      /// <summary>
      /// Gets or sets Bid Alternate Id
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets Bid Alternate Xref Id
      /// </summary>
      public int BID_ALTERNATE_XREF_ID { get; set; }

      /// <summary>
      /// Gets or sets Selected Pricing Parm Id
      /// </summary>
      public int? SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets Selection Id
      /// </summary>
      public int? SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets Variation Id
      /// </summary>
      public int? VARIATION_ID { get; set; }

      /// <summary>
      /// Gets or sets Bid Name
      /// </summary>
      public string BID_NAME { get; set; }
   }
}
