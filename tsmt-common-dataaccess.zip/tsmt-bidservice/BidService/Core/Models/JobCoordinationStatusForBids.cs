﻿// <copyright file="JobCoordinationStatusForBids.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// Model for update coordination status for bids
   /// </summary>
   public class JobCoordinationStatusForBids
   {
      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JOB_ID { get; set; }

      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BID_ALTERNATE_ID { get; set; }

      /// <summary>
      /// Gets or sets include in cj
      /// </summary>
      public int INCLUDE_IN_CJ { get; set; }

      /// <summary>
      /// Gets or sets dr address id
      /// </summary>
      public int DR_ADDRESS_ID { get; set; }
   }
}
