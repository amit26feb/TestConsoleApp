// <copyright file="BidSearchModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// Search model for bids
   /// </summary>
   public class BidSearchModel
   {
      /// <summary>
      /// Gets or sets CurrentBidInd
      /// </summary>
      public string CurrentBidInd { get; set; }

      /// <summary>
      /// Gets or sets BidName
      /// </summary>
      public string BidName { get; set; }

      /// <summary>
      /// Gets or sets Description
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets CreditJobNumber
      /// </summary>
      public string CreditJobNumber { get; set; }

      /// <summary>
      /// Gets or sets SellingPrice
      /// </summary>
      public int? SellingPrice { get; set; }

      /// <summary>
      /// Gets or sets BaseBidYesNo
      /// </summary>
      public int? BaseBidYesNo { get; set; }

      /// <summary>
      /// Gets or sets HqtrBidAlternateId
      /// </summary>
      public int? HqtrBidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets HqtrCreditJobId
      /// </summary>
      public int? HqtrCreditJobId { get; set; }

      /// <summary>
      /// Gets or sets FOE2CreatedOrdersInd
      /// </summary>
      public string Foe2CreatedOrdersInd { get; set; }

      /// <summary>
      /// Verifies at least one search criteria has been provided
      /// </summary>
      /// <returns>True if valid, false otherwise.</returns>
      internal bool IsValid()
      {
         return !string.IsNullOrEmpty(this.CurrentBidInd)
            || !string.IsNullOrEmpty(this.BidName)
            || !string.IsNullOrEmpty(this.Description)
            || !string.IsNullOrEmpty(this.CreditJobNumber)
            || this.SellingPrice.HasValue
            || this.BaseBidYesNo.HasValue
            || this.HqtrBidAlternateId.HasValue
            || this.HqtrCreditJobId.HasValue
            || !string.IsNullOrEmpty(this.Foe2CreatedOrdersInd);
      }
   }
}
