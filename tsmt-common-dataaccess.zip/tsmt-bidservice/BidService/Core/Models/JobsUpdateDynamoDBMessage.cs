// <copyright file="JobsUpdateDynamoDBMessage.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Models
{
   /// <summary>
   /// Model for jobs update dynamo db message
   /// </summary>
   public class JobsUpdateDynamoDBMessage
   {
      /// <summary>
      /// Gets or sets MessageId
      /// </summary>
      public string MessageId { get; set; }

      /// <summary>
      /// Gets or sets Message
      /// </summary>
      public string Message { get; set; }

      /// <summary>
      /// Gets or sets CreatedDateTime
      /// </summary>
      public string CreatedDateTime { get; set; }

      /// <summary>
      /// Gets or sets Status
      /// </summary>
      public string Status { get; set; }

      /// <summary>
      /// Gets or sets StatusUpdatedDateTime
      /// </summary>
      public string StatusUpdatedDateTime { get; set; }

      /// <summary>
      /// Gets or sets ErrorMessage
      /// </summary>
      public string ErrorMessage { get; set; }

      /// <summary>
      /// Gets or sets ProcessStartTime
      /// </summary>
      public string ProcessStartTime { get; set; }
   }
}
