﻿// <copyright file="LoggingBehavior.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Behaviors
{
    using System.Threading;
    using System.Threading.Tasks;
    using MediatR;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Logging behavior
    /// </summary>
    /// <typeparam name="TRequest">TRequest details</typeparam>
    /// <typeparam name="TResponse">TResponse details</typeparam>
    public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    {
        private readonly ILogger<LoggingBehavior<TRequest, TResponse>> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggingBehavior{TRequest, TResponse}"/> class.
        /// </summary>
        /// <param name="logger">Logger details</param>
        public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> logger) => this.logger = logger;

        /// <summary>
        /// Handle Request
        /// </summary>
        /// <param name="request">Request details</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <param name="next">Next request handler delegate</param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {
            this.logger.LogTrace($"Handling {typeof(TRequest).Name}");
            var response = await next();
            this.logger.LogTrace($"Handled {typeof(TResponse).Name}");
            return response;
        }
    }
}
