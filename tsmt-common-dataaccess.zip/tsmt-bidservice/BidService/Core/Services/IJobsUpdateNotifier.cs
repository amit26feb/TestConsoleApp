// <copyright file="IJobsUpdateNotifier.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Services
{
    using System.Threading.Tasks;
   using global::BidService.Common.Constants;

   /// <summary>
   /// Provides methods that interacts with SNS and SQS
   /// </summary>
   public interface IJobsUpdateNotifier
    {
      /// <summary>
      /// Request message will be stored in DynamoDB and message id will be stored in SQS.
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidNotificationType">Indicates type of notification needs to be sent based on actions</param>
      /// <param name="bidId">Bid id</param>
      /// <param name="bidName">Bid name</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      Task NotifyJobsUpdateRequestAsync(int jobId, BidNotificationType bidNotificationType, int bidId, string bidName = null);

      /// <summary>
      /// Gets user name
      /// </summary>
      /// <returns>User name</returns>
      string GetUserNameFromHttpContext();
    }
}
