// <copyright file="BidService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using global::BidService.Common.Constants;
   using global::BidService.Core.Models;
   using global::BidService.Core.ViewModels;
   using global::BidService.Repository;
   using Microsoft.AspNetCore.Http;

   /// <summary>
   /// Service for bid operations
   /// </summary>
   public class BidService : IBidService
   {
      private readonly IBidRepository bidRepository;
      private readonly IMapper mapper;
      private readonly IJobsUpdateNotifier jobsUpdateNotifier;

      /// <summary>
      /// Initializes a new instance of the <see cref="BidService"/> class.
      /// </summary>
      /// <param name="bidRepository">bidRepository</param>
      /// <param name="contextAccessor">contextAccessor</param>
      /// <param name="mapper">mapper</param>
      /// <param name="jobsUpdateNotifier">Notifier to jobs update request</param>
      public BidService(IBidRepository bidRepository, IHttpContextAccessor contextAccessor, IMapper mapper, IJobsUpdateNotifier jobsUpdateNotifier)
      {
         this.mapper = mapper;

         // We know this microservice has told the ConnectionFactory that it needs to produce connections that honor a DrAddressId.
         // By putting this responsibility on the ConnectionFactory, we greatly reduce the chance that we accidentally introduce a database interaction that doesn't honor a DrAddressId (VPD) when it should.

         // So these repositories should be honoring a DrAddressId, because they are utilizing the ConnectionFactory.
         this.bidRepository = bidRepository;
         this.jobsUpdateNotifier = jobsUpdateNotifier;

         // The DrAddressId to honor is stored in the HttpContext.
         if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
             contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") &&
             int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.bidRepository.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.bidRepository.HonorDrAddressId(null);
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<BidViewModel>> GetBidList(int jobId, bool includeCreditJobs = false)
      {
         var bidList = await this.bidRepository.GetBidListAsync(jobId);
         var bids = this.mapper.Map<IEnumerable<BidAlternate>, IEnumerable<BidViewModel>>(bidList).ToList();

         if (bidList.Any() && includeCreditJobs)
         {
            var creditJobList = await this.bidRepository.GetCreditJobListAsync(jobId);
            if (creditJobList.Any())
            {
               // Adding Credit job numbers from credit job detail to bid alternate detail
               this.AddCreditJobNumbers(bids, creditJobList);

               // Updating purchase order numbers from credit job detail to bid alternate detail
               this.UpdatePONumbers(bids, creditJobList);
            }
         }

         return bids;
      }

      /// <inheritdoc />
      public Task<IEnumerable<BidViewModel>> GetBidList(BidSearchModel criteria)
      {
         return this.bidRepository.GetBidListAsync(criteria);
      }

      /// <inheritdoc/>
      public async Task<BidViewModel> GetBid(int jobId, int bidAlternateId)
      {
         BidViewModel bid = await this.bidRepository.GetBidAsync(jobId, bidAlternateId);
         if (bid != null)
         {
            IEnumerable<CreditJob> creditJobs = await this.bidRepository.GetCreditJobsAsync(jobId, bidAlternateId);
            foreach (CreditJob creditJob in creditJobs)
            {
               bid.CreditJobs.Add(this.mapper.Map<CreditJobViewModel>(creditJob));
            }
         }

         return bid;
      }

      /// <summary>
      /// Update current bid status
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be assigned as current bid</param>
      /// <returns>A <see cref="Task"/>Update status</returns>
      public async Task<int> UpdateCurrentBid(int jobId, int bidAlternateId)
      {
         var returnVal = await this.bidRepository.UpdateCurrentBidAsync(jobId, bidAlternateId);
         return returnVal;
      }

      /// <summary>
      /// Service method to create a bid
      /// </summary>
      /// <param name="bid">bid view model</param>
      /// <returns>Create status</returns>
      public async Task<int> CreateBid(ViewModels.BidCreateModel bid)
      {
         var bidAlternateId = await this.bidRepository.GetSequenceNumber("BID_ALTERNATE");
         bid.BidAlternateId = bidAlternateId;
         Models.BidAlternate bidEntity = this.mapper.Map<ViewModels.BidCreateModel, Models.BidAlternate>(bid);
         return await this.bidRepository.CreateBidAsync(bidEntity);
      }

      /// <summary>
      /// Validate bid name duplication when create or update bid
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <param name="bidName">bidName</param>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <returns>If bid name has more than one record, should return false otherwise return true</returns>
      public async Task<bool> ValidateBidName(int jobId, string bidName, int bidAlternateId)
      {
         return await this.bidRepository.ValidateBidName(jobId, bidName, bidAlternateId);
      }

      /// <summary>
      /// Service method to update a bid
      /// </summary>
      /// <param name="bid">bid view model</param>
      /// <returns>Updated row count</returns>
      public async Task<int> UpdateBid(ViewModels.BidCreateModel bid)
      {
         Models.BidAlternate bidEntity = this.mapper.Map<ViewModels.BidCreateModel, Models.BidAlternate>(bid);
         return await this.bidRepository.UpdateBidAsync(bidEntity);
      }

      /// <summary>
      /// Deleting a bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be deleted</param>
      /// <returns>Deleted status</returns>
      public async Task<int> DeleteBid(int jobId, int bidAlternateId)
      {
         int deletedRecords;
         var bidName = this.bidRepository.GetBidAsync(jobId, bidAlternateId).Result.BidName;
         bool isCurrentBid = await this.bidRepository.IsBidCurrentAsync(bidAlternateId);
         if (isCurrentBid)
         {
            var baseBidAlternateId = await this.bidRepository.GetBaseBidAlternateIdAsync(jobId);
            deletedRecords = await this.bidRepository.UpdateAndDeleteBidAsync(jobId, bidAlternateId, baseBidAlternateId);
         }
         else
         {
            deletedRecords = await this.bidRepository.DeleteBidAsync(jobId, bidAlternateId);
         }

         // Notify the request of jobs last modified date to SQS for delete bid
         if (deletedRecords == 1)
         {
            await this.jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(jobId, BidNotificationType.Delete, bidAlternateId, bidName);
         }

         return deletedRecords;
      }

      /// <summary>
      /// Gets list of bid selections for a given job id
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <returns>List of bid selections</returns>
      public async Task<IEnumerable<BidSelectionsViewModel>> GetBidSelections(int jobId)
      {
         var selections = await this.bidRepository.GetBidSelectionsQuery(jobId);
         IEnumerable<BidSelectionsViewModel> selectionList = this.mapper.Map<IEnumerable<BidSelections>, IEnumerable<BidSelectionsViewModel>>(selections);
         return selectionList;
      }

      /// <summary>
      /// Adds selection/separately biddable/selection variation/job variation to bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="addSelection">Add selection view model</param>
      /// <returns>True if records inserted else false</returns>
      public async Task<bool> AddSelections(int jobId, int bidAlternateId, AddSelectionViewModel addSelection)
      {
         List<BidSelectionsViewModel> bidSelectionsViewModel = new List<BidSelectionsViewModel>();
         if (addSelection.SelectionDetails != null)
         {
            foreach (var selection in addSelection.SelectionDetails)
            {
               BidSelectionsViewModel bidSelections = new BidSelectionsViewModel();
               if (!selection.ExcludeSelection)
               {
                  bidSelections.SelectionId = selection.SelectionId;
                  bidSelections.BidAlternateId = bidAlternateId;

                  // Adding selection id and bid alternate id in bidSelectionsViewModel for inserting selection into BidAlternateXref table
                  bidSelectionsViewModel.Add(bidSelections);
               }

               if (selection.SeparatelyBiddableViewModel != null && selection.SeparatelyBiddableViewModel.Any())
               {
                  foreach (var separatelyBiddable in selection.SeparatelyBiddableViewModel)
                  {
                     BidSelectionsViewModel bidSeparateBiddable = new BidSelectionsViewModel
                     {
                        SelectedPricingParmId = separatelyBiddable.SeparatelyBiddableId,
                        BidAlternateId = bidAlternateId
                     };

                     // Adding separatelyBiddable id and bid alternate id in bidSelectionsViewModel for inserting separately biddable into BidAlternateXref table
                     bidSelectionsViewModel.Add(bidSeparateBiddable);
                  }
               }

               // Calling AddSelectionsVariations for adding selection variation in bidSelectionsViewModel
               bidSelectionsViewModel = bidSelectionsViewModel.Concat(this.AddSelectionVariation(selection, bidAlternateId)).ToList();
            }
         }

         // Get current bid alternate id of job for creating non trane item
         if (bidAlternateId == 0)
         {
            bidAlternateId = await this.bidRepository.GetCurrentBidAlternateIdAsync(jobId);
         }

         // Calling AddJobVariations for adding job variation in bidSelectionsViewModel
         bidSelectionsViewModel = bidSelectionsViewModel.Concat(this.AddJobVariation(addSelection, bidAlternateId)).ToList();

         int count = bidSelectionsViewModel.Count;
         var referenceId = await this.bidRepository.GetSequenceNumber("BID_ALTERNATE_XREF", count);

         foreach (var record in bidSelectionsViewModel)
         {
            // Adding bidAlternateXrefId for each of the record in bidSelectionsViewModel
            record.BidAlternateXrefId = referenceId++;
         }

         IEnumerable<BidSelections> bidSelectionList = this.mapper.Map<IEnumerable<BidSelectionsViewModel>, IEnumerable<BidSelections>>(bidSelectionsViewModel);
         return await this.bidRepository.InsertSelections(bidSelectionList);
      }

      /// <summary>
      /// Delete selections from a bid
      /// </summary>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="removeSelectionsRequest">Request for removing selections</param>
      /// <returns>Deleted status</returns>
      public async Task<bool> DeleteSelections(int bidAlternateId, RemoveAllSelectionsRequestViewModel removeSelectionsRequest)
      {
         return await this.bidRepository.DeleteAllSelectionsAsync(bidAlternateId, removeSelectionsRequest);
      }

      /// <summary>
      /// Get bids for coordination
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Bids for coordination</returns>
      public async Task<IEnumerable<CoordinationJobBidViewModel>> GetBidsForCoordination(int jobId)
      {
         var bidsForCoordination = await this.bidRepository.GetBidsForCoordination(jobId);
         return this.mapper.Map<IEnumerable<CoordinationJobBid>, IEnumerable<CoordinationJobBidViewModel>>(bidsForCoordination);
      }

      /// <summary>
      /// Update bids whether included for job coordination or not
      /// </summary>
      /// <param name="jobCoordinationStatusForBidsViewModel">Job coordination status for bids view model</param>
      /// <returns>Boolean</returns>
      public async Task<bool> UpdateJobCoordinationStatusForBids(IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsViewModel)
      {
         IEnumerable<JobCoordinationStatusForBids> jobCoordinationStatusForBids = this.mapper.Map<IEnumerable<JobCoordinationStatusForBidsViewModel>, IEnumerable<JobCoordinationStatusForBids>>(jobCoordinationStatusForBidsViewModel);
         return await this.bidRepository.UpdateJobCoordinationStatusForBids(jobCoordinationStatusForBids);
      }

      /// <summary>
      /// Gets the bid selection details
      /// </summary>
      /// <param name="bidIds">Bid ids</param>
      /// <returns>Bid selection details</returns>
      public async Task<IEnumerable<BidSelectionDetailsViewModel>> GetBidSelectionDetails(IEnumerable<int> bidIds)
      {
         var bidSelectionDetails = await this.bidRepository.GetBidSelectionDetails(bidIds);
         var bidSelectionDetailsViewModel = from bidSelections in bidSelectionDetails
                                            group bidSelections by new { bidSelections.BID_ALTERNATE_ID, bidSelections.BID_NAME } into bs
                                            select new BidSelectionDetailsViewModel()
                                            {
                                               BidAlternateId = bs.Key.BID_ALTERNATE_ID,
                                               BidName = bs.Key.BID_NAME,
                                               SelectionIds = bs.Select(x => x.SELECTION_ID),
                                               SelectedPricingParmParentSelectionIds = bs.Where(x => x.SELECTION_TYPE == "SelectedPricingParm")
                                                                                        .Select(x => x.SELECTION_ID),
                                               ParentSelectionIds = bs.Where(x => x.SELECTION_TYPE == "Selection")
                                                                        .Select(x => x.SELECTION_ID)
                                            };

         // Selecting the separately biddable selection ids based on selected pricing param's parent selection id
         // and parent selection ids
         return from bidSelectionDetail in bidSelectionDetailsViewModel
                select new BidSelectionDetailsViewModel()
                {
                   BidAlternateId = bidSelectionDetail.BidAlternateId,
                   BidName = bidSelectionDetail.BidName,
                   SelectionIds = bidSelectionDetail.SelectionIds,
                   ParentSelectionIds = bidSelectionDetail.ParentSelectionIds,
                   SelectedPricingParmParentSelectionIds = bidSelectionDetail.SelectedPricingParmParentSelectionIds,
                   SeparatelyBiddableSelectionIds = bidSelectionDetail.SelectedPricingParmParentSelectionIds.Except(bidSelectionDetail.ParentSelectionIds)
                };
      }

      /// <summary>
      ///  Adding Credit job numbers from credit job detail to bid alternate detail
      /// </summary>
      /// <param name="bidList">list of bids</param>
      /// <param name="creditJobList">list of credit Job</param>
      private void AddCreditJobNumbers(IList<BidViewModel> bidList, IEnumerable<BidViewModel> creditJobList)
      {
         foreach (BidViewModel creditJob in creditJobList.Where(creditJob => !string.IsNullOrWhiteSpace(creditJob.CreditJobNumber)))
         {
            // legacy supports multiple credit jobs on a single bid.
            // check if we have any credit job records where
            // credit_job.legacy_ord_nbr for a bid id doesn't match any existing bid in our list
            if (!bidList.Any(bid =>
               bid.BidAlternateId == creditJob.BidAlternateId &&
               bid.CreditJobNumber == creditJob.CreditJobNumber))
            {
               bidList.Add(creditJob);
            }
         }
      }

      /// <summary>
      ///  Updating purchase order numbers from credit job detail to bid alternate detail
      /// </summary>
      /// <param name="bidList">list of bids</param>
      /// <param name="creditJobList">list of credit Job</param>
      private void UpdatePONumbers(IEnumerable<BidViewModel> bidList, IEnumerable<BidViewModel> creditJobList)
      {
         foreach (BidViewModel bid in bidList.Where(bids => !string.IsNullOrWhiteSpace(bids.CreditJobNumber) && string.IsNullOrWhiteSpace(bids.PurchaseOrderNumber)))
         {
            // look to match Credit Job-Bid records credit job table to bid alternate table
            var creditJobBid = creditJobList.FirstOrDefault(creditJob => bid.BidAlternateId == creditJob.BidAlternateId && bid.CreditJobNumber == creditJob.CreditJobNumber && !string.IsNullOrWhiteSpace(creditJob.PurchaseOrderNumber));
            if (creditJobBid != null)
            {
               bid.PurchaseOrderNumber = creditJobBid.PurchaseOrderNumber;
            }
         }
      }

      /// <summary>
      /// Adding selection variation and job variation in bidSelectionsViewModel
      /// </summary>
      /// <param name="addSelection">AddSelection view model</param>
      /// <param name="bidAlternateId">BidAlternateId</param>
      /// <returns>BidSelectionsViewModel with variations</returns>
      private List<BidSelectionsViewModel> AddJobVariation(AddSelectionViewModel addSelection, int bidAlternateId)
      {
         List<BidSelectionsViewModel> bidSelectionsViewModel = new List<BidSelectionsViewModel>();

         foreach (var variation in addSelection.JobVariations)
         {
            BidSelectionsViewModel bidSelections = new BidSelectionsViewModel
            {
               VariationId = variation.VariationId,
               BidAlternateId = bidAlternateId
            };

            // Adding variation id and bid alternate id in bidSelectionsViewModel for inserting job variation into BidAlternateXref table
            bidSelectionsViewModel.Add(bidSelections);
         }

         return bidSelectionsViewModel;
      }

      /// <summary>
      /// Adding selection variation in bidSelectionsViewModel
      /// </summary>
      /// <param name="selection">Selection Details View Model</param>
      /// <param name="bidAlternateId">BidAlternateId</param>
      /// <returns>BidSelectionsViewModel with variations</returns>
      private List<BidSelectionsViewModel> AddSelectionVariation(SelectionDetailsViewModel selection, int bidAlternateId)
      {
         List<BidSelectionsViewModel> bidSelectionsViewModel = new List<BidSelectionsViewModel>();
         if (selection.VariationViewModel != null && selection.VariationViewModel.Any())
         {
            foreach (var variation in selection.VariationViewModel)
            {
               BidSelectionsViewModel bidVariation = new BidSelectionsViewModel
               {
                  VariationId = variation.VariationId,
                  BidAlternateId = bidAlternateId
               };

               // Adding variation id and bid alternate id in bidSelectionsViewModel for inserting selection variation into BidAlternateXref table
               bidSelectionsViewModel.Add(bidVariation);
            }
         }

         return bidSelectionsViewModel;
      }
   }
}
