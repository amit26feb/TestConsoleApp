// <copyright file="JobsUpdateNotifier.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Amazon.SimpleNotificationService.Model;
    using AWS.MessagingWrapper.Contracts;
    using global::BidService.Common.Constants;
    using global::BidService.Core.Models;
    using global::BidService.Core.Repository;
    using global::BidService.Repository;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using TSMT.Settings;

    /// <summary>
    /// Provides methods that interacts with SNS and SQS
    /// </summary>
    public class JobsUpdateNotifier : IJobsUpdateNotifier
    {
        private const int RetryAttemptCount = 3;
        private readonly IMessagePublisher snsPublisher;
        private readonly IJobsUpdateDynamoDBRepository jobsUpdateDynamoDBRepository;
        private readonly ILogger<JobsUpdateNotifier> logger;
        private readonly IOptions<TSMTSettings> appSettings;
        private readonly IHttpContextAccessor contextAccessor;
        private readonly int drAddressId = 0;
        private readonly IBidRepository bidRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsUpdateNotifier"/> class.
        /// </summary>
        /// <param name="snsPublisher">Interaction with SNS</param>
        /// <param name="logger">Captures the logging messages</param>
        /// <param name="appSettings">Configurations from app setting</param>
        /// <param name="jobsUpdateDynamoDBRepository">Repository to interact with dynamo db</param>
        /// <param name="contextAccessor">ContextAccessor for fetching http context values</param>
        /// <param name="bidRepository">Repository for bid operation</param>
        public JobsUpdateNotifier(IMessagePublisher snsPublisher, ILogger<JobsUpdateNotifier> logger, IOptions<TSMTSettings> appSettings, IJobsUpdateDynamoDBRepository jobsUpdateDynamoDBRepository, IHttpContextAccessor contextAccessor, IBidRepository bidRepository)
        {
            this.snsPublisher = snsPublisher;
            this.logger = logger;
            this.appSettings = appSettings;
            this.jobsUpdateDynamoDBRepository = jobsUpdateDynamoDBRepository;
            this.contextAccessor = contextAccessor;
            this.bidRepository = bidRepository;

            if (contextAccessor.HttpContext != null && contextAccessor.HttpContext.Items != null &&
                contextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID") && int.TryParse(contextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out this.drAddressId))
            {
                this.bidRepository.HonorDrAddressId(this.drAddressId);
            }
            else
            {
                this.bidRepository.HonorDrAddressId(null);
            }
        }

      /// <summary>
      /// Request message will be stored in DynamoDB and message id will be stored in SQS.
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidNotificationType">Indicates type of notification needs to be sent based on actions</param>
      /// <param name="bidId">Bid id</param>
      /// <param name="bidName">Bid name</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      public async Task NotifyJobsUpdateRequestAsync(int jobId, BidNotificationType bidNotificationType, int bidId, string bidName = null)
        {
            this.logger.LogInformation($"Start notify jobs update request for job id: {jobId} and dr address id: {this.drAddressId} ");
            string snsArn = this.appSettings.Value.SnsServiceUrl;
            DateTime dbDateTime = await this.bidRepository.GetDbDate();

            JobsUpdateRequest jobsUpdateRequest = new JobsUpdateRequest
            {
                DR_ADDRESSID_ID = this.drAddressId,
                JOB_ID = jobId,
                LAST_UPDATE = dbDateTime,
                BID_NAME = await this.GetBidName(jobId, bidId, bidName),
                BID_NOTIFICATION_TYPE = bidNotificationType,
                USER_NAME = this.GetUserNameFromHttpContext(),
                USER_ID = this.GetUserIdFromHttpContext()
            };

            string jobsUpdateRequestMessage = JsonConvert.SerializeObject(jobsUpdateRequest);
            JobsUpdateDynamoDBMessage jobsUpdateMessage = new JobsUpdateDynamoDBMessage
            {
                MessageId = this.contextAccessor.HttpContext.TraceIdentifier,
                Message = jobsUpdateRequestMessage,
                CreatedDateTime = dbDateTime.ToString(),
                StatusUpdatedDateTime = dbDateTime.ToString(),
                Status = JobsUpdateStatus.Pending,
                ErrorMessage = string.Empty
            };

            this.logger.LogInformation($"Generated message id : {jobsUpdateMessage.MessageId}");
            bool dbInsertStatus = await this.jobsUpdateDynamoDBRepository.SaveJobsUpdateRequest(jobsUpdateMessage);
            if (dbInsertStatus)
            {
                this.logger.LogInformation($"Saved jobs update request message in dynamo db for message id : {jobsUpdateMessage.MessageId}");
                await this.SendMessageToSNS(jobsUpdateMessage.MessageId, snsArn, SnsFilterRecipients.JobsUpdate);
                this.logger.LogInformation($"Saved message id in SQS: {jobsUpdateMessage.MessageId}");
            }
        }

      /// <summary>
      /// Gets user name
      /// </summary>
      /// <returns>User name</returns>
      public string GetUserNameFromHttpContext()
      {
         string userName = string.Empty;
         if (this.contextAccessor.HttpContext?.User.Claims != null)
         {
            string firstName = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "firstname")?.Value;
            string lastName = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "lastname")?.Value;
            userName = firstName + " " + lastName;
         }

         return userName;
      }

      /// <summary>
      /// Gets user id from http context
      /// </summary>
      /// <returns>User id</returns>
      public string GetUserIdFromHttpContext()
      {
         string userId = string.Empty;
         if (this.contextAccessor.HttpContext?.User.Claims != null)
         {
            userId = this.contextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
         }

         return userId;
      }

      /// <summary>
      /// Request message id will be stored in SQS via SNS.
      /// </summary>
      /// <param name="requestId">Request id of jobs update request</param>
      /// <param name="snsArn">Sns service url to connect SQS via SNS</param>
      /// <param name="recipientName">Recipient name(message attribute name) for subscription filter of SQS message</param>
      /// <returns>MessageId from SNS</returns>
      private async Task<string> SendMessageToSNS(string requestId, string snsArn, string recipientName)
        {
            return await this.snsPublisher.PublishToTopicAsync(requestId, snsArn, RetryAttemptCount, this.GetRecipientAttribute(recipientName));
        }

        /// <summary>
        /// Gets bid name from database if the provided bid name is null
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="bidId">Bid id</param>
        /// <param name="bidName">Bid name</param>
        /// <returns>Valid bid name</returns>
        private async Task<string> GetBidName(int jobId, int bidId, string bidName)
        {
            if (!string.IsNullOrWhiteSpace(bidName))
            {
               return bidName;
            }
            else
            {
               var bid = await this.bidRepository.GetBidAsync(jobId, bidId);
               return bid != null ? bid.BidName : string.Empty;
            }
        }

        /// <summary>
        /// Gets recipient attribute for subscription filter of SQS message
        /// </summary>
        /// <param name="recipient">Recipient name(message attribute name) for subscription filter of SQS message</param>
        /// <returns>Dictionary which contains message attribute name and value</returns>
        private Dictionary<string, MessageAttributeValue> GetRecipientAttribute(string recipient)
        {
            return new Dictionary<string, MessageAttributeValue>()
            {
                {
                  "Recipient",
                  new MessageAttributeValue() { DataType = "String", StringValue = recipient }
               }
         };
        }
   }
}
