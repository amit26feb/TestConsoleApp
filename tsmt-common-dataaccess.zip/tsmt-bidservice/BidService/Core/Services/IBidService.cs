// <copyright file="IBidService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using global::BidService.Core.ViewModels;

   /// <summary>
   /// IBidService
   /// </summary>
   public interface IBidService
   {
      /// <summary>
      /// Gets list of bid details based on job id
      /// </summary>
      /// <param name="jobId">job id</param>
      /// <param name="includeCreditJobs">if [true] populates creditJobs collection.  Nothing besides v1 API should call this with TRUE.</param>
      /// <returns>List of bids for a corresponding job id</returns>
      Task<IEnumerable<BidViewModel>> GetBidList(int jobId, bool includeCreditJobs = false);

      /// <summary>
      /// Gets the bids by search criteria provided.
      /// </summary>
      /// <param name="criteria">The search criteria</param>
      /// <returns>List of matching bids</returns>
      Task<IEnumerable<BidViewModel>> GetBidList(BidSearchModel criteria);

      /// <summary>
      /// Gets a bids for a given jobId and bidAlternateId
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <returns>BidViewModel</returns>
      Task<BidViewModel> GetBid(int jobId, int bidAlternateId);

      /// <summary>
      /// Update current bid status
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be assigned as current bid</param>
      /// <returns>A <see cref="Task"/>Update status</returns>
      Task<int> UpdateCurrentBid(int jobId, int bidAlternateId);

      /// <summary>
      /// <see cref="CreateBid"/>
      /// </summary>
      /// <param name="bid">bid</param>
      /// <returns>Create status</returns>
      Task<int> CreateBid(ViewModels.BidCreateModel bid);

      /// <summary>
      /// Validate bid name duplication when create or update bid
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <param name="bidName">bidName</param>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <returns>If bid name has more than one record, should return false otherwise return true</returns>
      Task<bool> ValidateBidName(int jobId, string bidName, int bidAlternateId);

      /// <summary>
      /// Deleting a bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be deleted</param>
      /// <returns>Deleted status</returns>
      Task<int> DeleteBid(int jobId, int bidAlternateId);

      /// <summary>
      /// <see cref="UpdateBid"/>
      /// </summary>
      /// <param name="bid">bid</param>
      /// <returns>Updated row count</returns>
      Task<int> UpdateBid(ViewModels.BidCreateModel bid);

      /// <summary>
      /// Gets list of bid selections for a given job id
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <returns>List of bid selections</returns>
      Task<IEnumerable<BidSelectionsViewModel>> GetBidSelections(int jobId);

      /// <summary>
      /// Adds selection/separately biddable/selection variation/job variation to bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="addSelection">Add selection view model</param>
      /// <returns>True if records inserted else false</returns>
      Task<bool> AddSelections(int jobId, int bidAlternateId, AddSelectionViewModel addSelection);

      /// <summary>
      /// Delete selections from a bid
      /// </summary>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="removeSelectionsRequest">Request for removing selections</param>
      /// <returns>Deleted status</returns>
      Task<bool> DeleteSelections(int bidAlternateId, RemoveAllSelectionsRequestViewModel removeSelectionsRequest);

      /// <summary>
      /// Get bids for coordination
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Bids for coordination</returns>
      Task<IEnumerable<CoordinationJobBidViewModel>> GetBidsForCoordination(int jobId);

      /// <summary>
      /// Update bid whether included for job coordination or not
      /// </summary>
      /// <param name="jobCoordinationStatusForBidsViewModel">Job coordination status for bids view model</param>
      /// <returns>Boolean</returns>
      Task<bool> UpdateJobCoordinationStatusForBids(IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsViewModel);

      /// <summary>
      /// Gets the bid selection details
      /// </summary>
      /// <param name="bidIds">Bid ids</param>
      /// <returns>Bid selection details</returns>
      Task<IEnumerable<BidSelectionDetailsViewModel>> GetBidSelectionDetails(IEnumerable<int> bidIds);
   }
}
