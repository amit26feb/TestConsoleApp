﻿// <copyright file="RemoveSelectionsCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using BidService.Common.Constants;
    using BidService.Core.Commands;
    using BidService.Core.Services;
    using MediatR;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Handler which processes the command for removing selections
    /// </summary>
    public class RemoveSelectionsCommandHandler : IRequestHandler<RemoveSelectionsCommand, bool>
    {
        private readonly ILogger<RemoveSelectionsCommand> logger;
        private readonly IBidService bidService;
        private readonly IJobsUpdateNotifier jobsUpdateNotifier;

        /// <summary>
        /// Initializes a new instance of the <see cref="RemoveSelectionsCommandHandler"/> class.
        /// </summary>
        /// <param name="logger">Remove selections Command logger</param>
        /// <param name="bidService">Bid Service</param>
        /// <param name="jobsUpdateNotifier">Notifier to jobs update request</param>
        public RemoveSelectionsCommandHandler(ILogger<RemoveSelectionsCommand> logger, IBidService bidService, IJobsUpdateNotifier jobsUpdateNotifier)
        {
            this.logger = logger;
            this.logger.LogTrace("Remove selections command handler called");
            this.bidService = bidService;
            this.jobsUpdateNotifier = jobsUpdateNotifier;
        }

        /// <summary>
        /// Handler which processes the remove selections
        /// </summary>
        /// <param name="request">Remove selections command request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Return upd</returns>
        public async Task<bool> Handle(RemoveSelectionsCommand request, CancellationToken cancellationToken)
        {
            var isSelectionsDeleted = await this.bidService.DeleteSelections(request.BidAlternateId, request.RemoveAllSelectionsRequest);

            // Notify the request of jobs last modified date to SQS
            if (isSelectionsDeleted && request.IsBidAlternateIdValidationRequired)
            {
                await this.jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(request.JobId, BidNotificationType.Edit, request.BidAlternateId);
            }

            this.logger.LogTrace($"Return {isSelectionsDeleted} from remove selections command handler");
            return isSelectionsDeleted;
        }
    }
}
