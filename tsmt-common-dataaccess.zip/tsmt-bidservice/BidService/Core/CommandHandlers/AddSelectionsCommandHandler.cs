﻿// <copyright file="AddSelectionsCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using BidService.Common.Constants;
    using BidService.Core.Command;
    using BidService.Core.Services;
    using MediatR;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Handler which processes the command for adding selections to a bid
    /// </summary>
    public class AddSelectionsCommandHandler : IRequestHandler<AddSelectionsCommand, bool>
    {
        private readonly ILogger<AddSelectionsCommand> logger;
        private readonly IBidService bidService;
        private readonly IJobsUpdateNotifier jobsUpdateNotifier;

        /// <summary>
        /// Initializes a new instance of the <see cref="AddSelectionsCommandHandler"/> class.
        /// </summary>
        /// <param name="logger">AddSelectionsCommand logger</param>
        /// <param name="bidService">Bid Service</param>
        /// <param name="jobsUpdateNotifier">Notifier to jobs update request</param>
        public AddSelectionsCommandHandler(ILogger<AddSelectionsCommand> logger, IBidService bidService, IJobsUpdateNotifier jobsUpdateNotifier)
        {
            this.logger = logger;
            this.logger.LogTrace("Add Bid Selections Command Handler called");
            this.bidService = bidService;
            this.jobsUpdateNotifier = jobsUpdateNotifier;
        }

        /// <summary>
        /// Handler processes for adding a selection to a bid
        /// </summary>
        /// <param name="request">Add selections request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>True if records inserted else false</returns>
        public async Task<bool> Handle(AddSelectionsCommand request, CancellationToken cancellationToken)
        {
            var isSelectionsAdded = await this.bidService.AddSelections(request.JobId, request.BidAlternateId, request.AddSelections);

            // Notify the request of jobs last modified date to SQS
            if (isSelectionsAdded && request.IsBidAlternateIdValidationRequired)
            {
                await this.jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(request.JobId, BidNotificationType.Edit, request.BidAlternateId);
            }

            this.logger.LogTrace($"Return {isSelectionsAdded} from add selections command handler");
            return isSelectionsAdded;
        }
    }
}
