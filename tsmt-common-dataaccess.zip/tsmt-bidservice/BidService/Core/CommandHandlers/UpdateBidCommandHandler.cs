﻿// <copyright file="UpdateBidCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using BidService.Common.Constants;
    using BidService.Core.Command;
    using BidService.Core.Services;
    using MediatR;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Handler which processes the command for updating bid
    /// </summary>
    public class UpdateBidCommandHandler : IRequestHandler<UpdateBidCommand, int>
    {
        private readonly ILogger<UpdateBidCommand> logger;
        private readonly IBidService bidService;
        private readonly IJobsUpdateNotifier jobsUpdateNotifier;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateBidCommandHandler"/> class.
        /// </summary>
        /// <param name="logger">Update Bid Command logger</param>
        /// <param name="bidService">Bid Service</param>
        /// <param name="jobsUpdateNotifier">Notifier to jobs update request</param>
        public UpdateBidCommandHandler(ILogger<UpdateBidCommand> logger, IBidService bidService, IJobsUpdateNotifier jobsUpdateNotifier)
        {
            this.logger = logger;
            this.logger.LogTrace("Update bid command handler called");
            this.bidService = bidService;
            this.jobsUpdateNotifier = jobsUpdateNotifier;
        }

        /// <summary>
        /// Handler which processes the update bid
        /// </summary>
        /// <param name="request">Update command request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Returns updated row count</returns>
        public async Task<int> Handle(UpdateBidCommand request, CancellationToken cancellationToken)
        {
            var result = await this.bidService.UpdateBid(request.Bid);

            // Notify the request of jobs last modified date to SQS
            if (result > 0)
            {
                await this.jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(request.Bid.JobId, BidNotificationType.Edit, request.Bid.BidAlternateId, request.Bid.BidName);
            }

            this.logger.LogTrace($"Return {result} from update bid command handler");
            return result;
        }
    }
}
