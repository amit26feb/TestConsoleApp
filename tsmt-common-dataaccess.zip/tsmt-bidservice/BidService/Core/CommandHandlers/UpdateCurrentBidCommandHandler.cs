// <copyright file="UpdateCurrentBidCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.CommandHandlers
{
   using System.Threading;
   using System.Threading.Tasks;
   using BidService.Common.Constants;
   using BidService.Core.Commands;
   using BidService.Core.Services;
   using MediatR;
   using Microsoft.Extensions.Logging;

   /// <summary>
   ///  Handles the command for updating current bid
   /// </summary>
   public class UpdateCurrentBidCommandHandler : IRequestHandler<UpdateCurrentBidCommand, int>
   {
      private readonly ILogger<UpdateCurrentBidCommand> logger;
      private readonly IBidService bidService;
      private readonly IJobsUpdateNotifier jobsUpdateNotifier;

      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateCurrentBidCommandHandler"/> class.
      /// </summary>
      /// <param name="logger">Update Assigned Customer Command logger</param>
      /// <param name="bidService">bidService</param>
      /// <param name="jobsUpdateNotifier">Notifier to jobs update request</param>
      public UpdateCurrentBidCommandHandler(ILogger<UpdateCurrentBidCommand> logger, IBidService bidService, IJobsUpdateNotifier jobsUpdateNotifier)
      {
         this.logger = logger;
         this.logger.LogTrace("Update current bid command handler called");
         this.bidService = bidService;
         this.jobsUpdateNotifier = jobsUpdateNotifier;
      }

      /// <summary>
      /// Handler which processes the command for update assigned customer when select bidder, winner, job role type
      /// </summary>
      /// <param name="request">Update assign command request</param>
      /// <param name="cancellationToken">Cancellation token</param>
      /// <returns>customer assigned successfully updated return true otherwise false</returns>
      public async Task<int> Handle(UpdateCurrentBidCommand request, CancellationToken cancellationToken)
      {
         var result = await this.bidService.UpdateCurrentBid(request.JobId, request.BidAlternateId);

         // Notify the request of jobs last modified date to SQS
         if (result > 0)
         {
            await this.jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(request.JobId, BidNotificationType.Edit, request.BidAlternateId);
         }

         this.logger.LogTrace($"Return {result} from update current bid command handler");
         return result;
      }
   }
}
