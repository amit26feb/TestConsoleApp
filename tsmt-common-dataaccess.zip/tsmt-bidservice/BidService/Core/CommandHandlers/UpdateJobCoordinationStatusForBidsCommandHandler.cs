﻿// <copyright file="UpdateJobCoordinationStatusForBidsCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using BidService.Core.Command;
    using BidService.Core.Services;
    using MediatR;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Handler which processes the command for updating the job coordination status for bids
    /// </summary>
    public class UpdateJobCoordinationStatusForBidsCommandHandler : IRequestHandler<UpdateJobCoordinationStatusForBidsCommand, bool>
    {
        private readonly ILogger<UpdateJobCoordinationStatusForBidsCommand> logger;
        private readonly IBidService bidService;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateJobCoordinationStatusForBidsCommandHandler"/> class.
        /// </summary>
        /// <param name="logger">Update coordination status for bid command logger</param>
        /// <param name="bidService">Bid service</param>
        public UpdateJobCoordinationStatusForBidsCommandHandler(ILogger<UpdateJobCoordinationStatusForBidsCommand> logger, IBidService bidService)
        {
            this.logger = logger;
            this.logger.LogTrace("Update bid coordination command handler called");
            this.bidService = bidService;
        }

        /// <summary>
        /// Handler which processes the update job coordination status for bids
        /// </summary>
        /// <param name="request">Update job coordination status for bids command</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Boolean</returns>
        public async Task<bool> Handle(UpdateJobCoordinationStatusForBidsCommand request, CancellationToken cancellationToken)
        {
            bool result = await Task.Run(
               () =>
                   this.bidService.UpdateJobCoordinationStatusForBids(request.JobCoordinationStatusForBidsViewModel),
               cancellationToken);
            this.logger.LogTrace($"Return {result} from update bid coordination command handler");
            return result;
        }
    }
}