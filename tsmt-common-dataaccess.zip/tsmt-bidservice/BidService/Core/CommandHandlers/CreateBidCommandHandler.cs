﻿// <copyright file="CreateBidCommandHandler.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using BidService.Common.Constants;
    using BidService.Core.Command;
    using BidService.Core.Services;
    using MediatR;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Handler which processes the command for creating bid
    /// </summary>
    public class CreateBidCommandHandler : IRequestHandler<CreateBidCommand, int>
    {
        private readonly ILogger<CreateBidCommand> logger;
        private readonly IBidService bidService;
        private readonly IJobsUpdateNotifier jobsUpdateNotifier;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateBidCommandHandler"/> class.
        /// </summary>
        /// <param name="logger">Create Bid Command logger</param>
        /// <param name="bidService">Bid Service</param>
        /// <param name="jobsUpdateNotifier">Notifier to jobs update request</param>
        public CreateBidCommandHandler(ILogger<CreateBidCommand> logger, IBidService bidService, IJobsUpdateNotifier jobsUpdateNotifier)
        {
            this.logger = logger;
            this.logger.LogTrace("Create bid command handler called");
            this.bidService = bidService;
            this.jobsUpdateNotifier = jobsUpdateNotifier;
        }

        /// <summary>
        /// Handler which processes the create bid
        /// </summary>
        /// <param name="request">Create command request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Bid Alternative Id of the created bid </returns>
        public async Task<int> Handle(CreateBidCommand request, CancellationToken cancellationToken)
        {
            var result = await this.bidService.CreateBid(request.Bid);

            // Notify the request of jobs last modified date to SQS
            if (result > 0)
            {
                await this.jobsUpdateNotifier.NotifyJobsUpdateRequestAsync(request.Bid.JobId, BidNotificationType.Create, request.Bid.BidAlternateId, request.Bid.BidName);
            }

            this.logger.LogTrace($"Return {result} from create bid command handler");
            return result;
        }
    }
}
