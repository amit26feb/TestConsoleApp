﻿// <copyright file="UpdateBidCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Command
{
    using System.Runtime.Serialization;
    using MediatR;
    using ViewModels;

    /// <summary>
    /// Handles command to update bid
    /// </summary>
    [DataContract]
    public class UpdateBidCommand : IRequest<int>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateBidCommand"/> class.
        /// </summary>
        /// <param name="bid">Bid Create View</param>
        public UpdateBidCommand(BidCreateModel bid)
        {
            this.Bid = bid;
        }

        /// <summary>
        /// Gets viewModel Property
        /// </summary>
        [DataMember]
        public BidCreateModel Bid { get; private set; }
    }
}
