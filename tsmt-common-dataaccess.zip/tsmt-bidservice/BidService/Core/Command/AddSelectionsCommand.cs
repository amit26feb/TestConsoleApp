﻿// <copyright file="AddSelectionsCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Command
{
   using System.Runtime.Serialization;
   using MediatR;
   using ViewModels;

   /// <summary>
   /// Handles command to add selection to bid
   /// </summary>
   [DataContract]
   public class AddSelectionsCommand : IRequest<bool>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="AddSelectionsCommand"/> class.
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="isBidAlternateIdValidationRequired">Indicating whether bid alternate id validation required or not</param>
      /// <param name="addSelections">View model for add selections</param>
      public AddSelectionsCommand(int jobId, int bidAlternateId, AddSelectionViewModel addSelections, bool isBidAlternateIdValidationRequired)
      {
         this.JobId = jobId;
         this.BidAlternateId = bidAlternateId;
         this.AddSelections = addSelections;
         this.IsBidAlternateIdValidationRequired = isBidAlternateIdValidationRequired;
      }

      /// <summary>
      /// Gets view model for add selections
      /// </summary>
      [DataMember]
      public AddSelectionViewModel AddSelections { get; private set; }

      /// <summary>
      /// Gets job id
      /// </summary>
      [DataMember]
      public int JobId { get; private set; }

      /// <summary>
      /// Gets bid alternate id
      /// </summary>
      [DataMember]
      public int BidAlternateId { get; private set; }

      /// <summary>
      /// Gets a value indicating whether bid alternate id validation required or not
      /// </summary>
      [DataMember]
      public bool IsBidAlternateIdValidationRequired { get; private set; }
   }
}
