﻿// <copyright file="UpdateJobCoordinationStatusForBidsCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Command
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;
    using BidService.Core.ViewModels;
    using MediatR;

    /// <summary>
    /// Handles command to update job coordination status for bids
    /// </summary>
    [DataContract]
    public class UpdateJobCoordinationStatusForBidsCommand : IRequest<bool>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateJobCoordinationStatusForBidsCommand"/> class.
        /// </summary>
        /// <param name="jobCoordinationStatusForBidsViewModel">Job coordination status for bids view model</param>
        public UpdateJobCoordinationStatusForBidsCommand(IEnumerable<JobCoordinationStatusForBidsViewModel> jobCoordinationStatusForBidsViewModel)
        {
            this.JobCoordinationStatusForBidsViewModel = jobCoordinationStatusForBidsViewModel;
        }

        /// <summary>
        /// Gets job coordination status for bids view model
        /// </summary>
        [DataMember]
        public IEnumerable<JobCoordinationStatusForBidsViewModel> JobCoordinationStatusForBidsViewModel { get; private set; }
    }
}
