﻿// <copyright file="RemoveSelectionsCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Commands
{
   using System.Runtime.Serialization;
   using MediatR;
   using ViewModels;

   /// <summary>
   /// Handles command to update bid
   /// </summary>
   [DataContract]
   public class RemoveSelectionsCommand : IRequest<bool>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="RemoveSelectionsCommand"/> class.
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="isBidAlternateIdValidationRequired">Indicating whether bid alternate id validation required or not</param>
      /// <param name="removeAllSelectionsRequest">Remove selection view model</param>
      public RemoveSelectionsCommand(int jobId, int bidAlternateId, RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest, bool isBidAlternateIdValidationRequired)
      {
         this.JobId = jobId;
         this.RemoveAllSelectionsRequest = removeAllSelectionsRequest;
         this.BidAlternateId = bidAlternateId;
         this.IsBidAlternateIdValidationRequired = isBidAlternateIdValidationRequired;
      }

      /// <summary>
      /// Gets view model Property
      /// </summary>
      [DataMember]
      public RemoveAllSelectionsRequestViewModel RemoveAllSelectionsRequest { get; private set; }

      /// <summary>
      /// Gets job id
      /// </summary>
      [DataMember]
      public int JobId { get; private set; }

      /// <summary>
      /// Gets bid alternate id
      /// </summary>
      [DataMember]
      public int BidAlternateId { get; private set; }

      /// <summary>
      /// Gets a value indicating whether bid alternate id validation required or not
      /// </summary>
      [DataMember]
      public bool IsBidAlternateIdValidationRequired { get; private set; }
   }
}
