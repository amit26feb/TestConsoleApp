// <copyright file="UpdateCurrentBidCommand.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Commands
{
   using System.Runtime.Serialization;
   using MediatR;

   /// <summary>
   /// Handles command to update current bid
   /// </summary>
   [DataContract]
   public class UpdateCurrentBidCommand : IRequest<int>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateCurrentBidCommand"/> class.
      /// UpdateCurrentBidCommand
      /// </summary>
      /// <param name="jobId">job id</param>
      /// <param name="bidAlternateId">Bid alternate id</param>
      public UpdateCurrentBidCommand(int jobId, int bidAlternateId)
      {
         this.JobId = jobId;
         this.BidAlternateId = bidAlternateId;
      }

      /// <summary>
      /// Gets JobId
      /// </summary>
      [DataMember]
      public int JobId { get; private set; }

      /// <summary>
      /// Gets BidAlternateId
      /// </summary>
      [DataMember]
      public int BidAlternateId { get; private set; }
   }
}
