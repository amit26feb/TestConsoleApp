﻿// <copyright file="UpdateBidCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Validators
{
   using BidService.Core.Command;
   using FluentValidation;

   /// <summary>
   /// Validates fields that are required for updating bid
   /// </summary>
   public class UpdateBidCommandValidator : AbstractValidator<UpdateBidCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateBidCommandValidator"/> class.
      /// </summary>
      public UpdateBidCommandValidator()
      {
         this.RuleFor(command => command.Bid.BidAlternateId).NotEqual(0).WithMessage("Bid Alternate Id should be greater than 0");
         this.RuleFor(command => command.Bid.BidName).NotEmpty().WithMessage("Bid Name cannot be Empty");
         this.RuleFor(command => command.Bid.JobId).GreaterThan(0).WithMessage("Job Id should be greater than 0");
         this.RuleFor(command => command.Bid).NotEmpty().Must((bid, ct) => this.ValidateBaseBidName(bid.Bid.BidName))
            .WithMessage("Update Bid: Bid name cannot be Base-Bid or BaseBid or Base_Bid");
      }

      private bool ValidateBaseBidName(string bidName)
      {
         return bidName != "Base-Bid" && bidName != "BaseBid" && bidName != "Base_Bid";
      }
   }
}
