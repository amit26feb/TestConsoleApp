﻿// <copyright file="UpdateJobCoordinationStatusForBidsCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.CommandValidator
{
   using BidService.Core.Command;
   using FluentValidation;

   /// <summary>
   /// Validates fields that are required for update job coordination status for bids
   /// </summary>
   public class UpdateJobCoordinationStatusForBidsCommandValidator : AbstractValidator<UpdateJobCoordinationStatusForBidsCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="UpdateJobCoordinationStatusForBidsCommandValidator"/> class.
      /// </summary>
      public UpdateJobCoordinationStatusForBidsCommandValidator()
      {
         this.RuleFor(command => command.JobCoordinationStatusForBidsViewModel).NotEmpty().WithMessage("Bids for Coordination cannot be empty");
         this.RuleForEach(command => command.JobCoordinationStatusForBidsViewModel)
       .Must((command, jobCoordinationStatusForBidsViewModel) => jobCoordinationStatusForBidsViewModel.JobId > 0)
       .WithMessage("Job id cannot be zero");
         this.RuleForEach(command => command.JobCoordinationStatusForBidsViewModel)
       .Must((command, jobCoordinationStatusForBidsViewModel) => jobCoordinationStatusForBidsViewModel.DrAddressId > 0)
       .WithMessage("DR address id cannot be zero");
         this.RuleForEach(command => command.JobCoordinationStatusForBidsViewModel)
       .Must((command, jobCoordinationStatusForBidsViewModel) => jobCoordinationStatusForBidsViewModel.BidAlternateId > 0)
       .WithMessage("Bid alternate id cannot be zero");
      }
   }
}