﻿// <copyright file="AddSelectionsCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Validators
{
   using BidService.Core.Command;
   using FluentValidation;

   /// <summary>
   /// Validates fields that are required for adding selections to a bid
   /// </summary>
   public class AddSelectionsCommandValidator : AbstractValidator<AddSelectionsCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="AddSelectionsCommandValidator"/> class.
      /// </summary>
      public AddSelectionsCommandValidator()
      {
         this.RuleFor(command => command.JobId).NotEqual(0).WithMessage("Job id should be greater than 0");
         this.When(command => command.IsBidAlternateIdValidationRequired, () =>
         {
            this.RuleFor(command => command.BidAlternateId).NotEqual(0).WithMessage("Bid alternate id should be greater than 0");
         });
      }
   }
}
