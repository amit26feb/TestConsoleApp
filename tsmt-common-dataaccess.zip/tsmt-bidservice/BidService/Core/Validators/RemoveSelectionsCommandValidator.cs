﻿// <copyright file="RemoveSelectionsCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Validators
{
   using BidService.Core.Commands;
   using BidService.Core.Services;
   using FluentValidation;
   using Microsoft.AspNetCore.Http;

   /// <summary>
   /// Validates fields that are required for removing selections
   /// </summary>
   public class RemoveSelectionsCommandValidator : AbstractValidator<RemoveSelectionsCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="RemoveSelectionsCommandValidator"/> class.
      /// </summary>
      /// <param name="bidService">bidService</param>
      /// <param name="contextAccessor">contextAccessor</param>
      public RemoveSelectionsCommandValidator(IBidService bidService, IHttpContextAccessor contextAccessor)
      {
         this.When(command => command.IsBidAlternateIdValidationRequired, () =>
         {
            this.RuleFor(command => command.BidAlternateId).GreaterThan(0).WithMessage("Bid Alternate Id must be greater than 0");
         });
      }
   }
}
