﻿// <copyright file="CreateBidCommandValidator.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Validators
{
   using BidService.Core.Command;
   using BidService.Core.Services;
   using FluentValidation;

   /// <summary>
   /// Validates fields that are required for creating bid
   /// </summary>
   public class CreateBidCommandValidator : AbstractValidator<CreateBidCommand>
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="CreateBidCommandValidator"/> class.
      /// </summary>
      /// <param name="bidService">bidService</param>
      public CreateBidCommandValidator(IBidService bidService)
      {
         this.RuleFor(command => command.Bid.BidAlternateId).Equal(0).WithMessage("Bid Alternate Id must be 0");
         this.RuleFor(command => command.Bid.BidName).NotEmpty().WithMessage("Bid Name cannot be Empty");
         this.RuleFor(command => command.Bid.JobId).GreaterThan(0).WithMessage("Job Id should be greater than 0");

         this.RuleFor(command => command.Bid).NotEmpty().Must((bid, ct) => this.ValidateBaseBidName(bid.Bid.BidName))
            .WithMessage("Create Bid: Bid name cannot be Base Bid or Base-Bid or BaseBid or Base_Bid");

         this.RuleFor(command => command.Bid).NotEmpty().MustAsync(async (bid, ct) =>
            await bidService.ValidateBidName(bid.JobId, bid.BidName, bid.BidAlternateId))
            .WithMessage("Create Bid: Duplicate Bid Name");
      }

      private bool ValidateBaseBidName(string bidName)
      {
         return bidName != "Base Bid" && bidName != "Base-Bid" && bidName != "BaseBid" && bidName != "Base_Bid";
      }
   }
}
