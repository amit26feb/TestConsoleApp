// <copyright file="BidViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels.V2
{
   /// <summary>
   /// View model for bids
   /// </summary>
   public class BidViewModel
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="BidViewModel"/> class.
      /// </summary>
      public BidViewModel()
      {
      }

      /// <summary>
      /// Gets or sets BidAlternateId
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets CurrentBidInd
      /// </summary>
      public string CurrentBidInd { get; set; }

      /// <summary>
      /// Gets or sets BidName
      /// </summary>
      public string BidName { get; set; }

      /// <summary>
      /// Gets or sets Description
      /// </summary>
      public string Description { get; set; }

      /// <summary>
      /// Gets or sets SPA number
      /// </summary>
      public string SpaNumber { get; set; }

      /// <summary>
      /// Gets or sets SellingPrice
      /// </summary>
      public int? SellingPrice { get; set; }

      /// <summary>
      /// Gets or sets BaseBidYesNo
      /// </summary>
      public int BaseBidYesNo { get; set; }

      /// <summary>
      /// Gets or sets HqtrBidAlternateId
      /// </summary>
      public int? HqtrBidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets HqtrCreditJobId
      /// </summary>
      public int? HqtrCreditJobId { get; set; }

      /// <summary>
      /// Gets or sets FOE2CreatedOrdersInd
      /// </summary>
      public string Foe2CreatedOrdersInd { get; set; }

      /// <summary>
      /// Gets or sets legacy job number
      /// </summary>
      public string LegacyJobNumber { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether gets or sets IsIncludeInCoordinatedJob
      /// </summary>
      public bool IsIncludeInCoordinatedJob { get; set; }
   }
}