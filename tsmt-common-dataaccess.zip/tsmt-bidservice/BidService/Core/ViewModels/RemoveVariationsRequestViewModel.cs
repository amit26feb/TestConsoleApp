﻿// <copyright file="RemoveVariationsRequestViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View model for removing variations
   /// </summary>
   public class RemoveVariationsRequestViewModel
   {
      /// <summary>
      /// Gets or sets SellingPrice
      /// </summary>
      public int? VariationId { get; set; }
   }
}
