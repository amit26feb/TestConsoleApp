﻿// <copyright file="SeparatelyBiddableViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View Model for separately biddable Id
   /// </summary>
   public class SeparatelyBiddableViewModel
   {
      /// <summary>
      /// Gets or sets separately Biddable Id
      /// </summary>
      public int SeparatelyBiddableId { get; set; }
   }
}
