﻿// <copyright file="BidSelectionsViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View model for Bid Selections
   /// </summary>
   public class BidSelectionsViewModel
   {
      /// <summary>
      /// Gets or sets Bid Alternate Id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets Bid Alternate Xref Id
      /// </summary>
      public int BidAlternateXrefId { get; set; }

      /// <summary>
      /// Gets or sets Selected Pricing Parm Id
      /// </summary>
      public int? SelectedPricingParmId { get; set; }

      /// <summary>
      /// Gets or sets Selection Id
      /// </summary>
      public int? SelectionId { get; set; }

      /// <summary>
      /// Gets or sets Variation Id
      /// </summary>
      public int? VariationId { get; set; }

      /// <summary>
      /// Gets or sets Bid Name
      /// </summary>
      public string BidName { get; set; }
   }
}
