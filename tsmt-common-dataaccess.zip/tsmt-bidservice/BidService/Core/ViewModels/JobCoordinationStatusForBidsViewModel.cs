﻿// <copyright file="JobCoordinationStatusForBidsViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View model for update coordination status for bids
   /// </summary>
   public class JobCoordinationStatusForBidsViewModel
   {
      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets credit job number
      /// </summary>
      public bool? IsBidInCoordinationJob { get; set; }

      /// <summary>
      /// Gets or sets dr address id
      /// </summary>
      public int DrAddressId { get; set; }
   }
}
