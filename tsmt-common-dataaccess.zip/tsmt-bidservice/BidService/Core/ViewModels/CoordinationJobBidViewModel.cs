﻿// <copyright file="CoordinationJobBidViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// Represents the bids for coordination
   /// </summary>
   public class CoordinationJobBidViewModel
   {
      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets bid name
      /// </summary>
      public string BidName { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether bid is current or not
      /// </summary>
      public bool IsCurrentBid { get; set; }

      /// <summary>
      /// Gets or sets indicator which shows whether the bid is included for job coordination
      /// </summary>
      public bool? IsBidInCoordinationJob { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether this is the base bid
      /// </summary>
      public bool IsBaseBid { get; set; }
   }
}
