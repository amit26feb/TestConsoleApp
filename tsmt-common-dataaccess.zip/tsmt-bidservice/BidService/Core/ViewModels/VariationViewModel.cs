﻿// <copyright file="VariationViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View Model for selection variation
   /// </summary>
   public class VariationViewModel
   {
      /// <summary>
      /// Gets or sets variation Id
      /// </summary>
      public int VariationId { get; set; }
   }
}
