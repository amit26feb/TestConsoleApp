﻿// <copyright file="CreditJobViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// Credit job api model
   /// </summary>
   public class CreditJobViewModel
   {
      /// <summary>
      /// Gets or sets purchase order number
      /// </summary>
      public string PurchaseOrderNumber { get; set; }

      /// <summary>
      /// Gets or sets credit job number
      /// </summary>
      public string CreditJobNumber { get; set; }

      /// <summary>
      /// Gets or sets headquarter credit job id
      /// </summary>
      public int? HqtrCreditJobId { get; set; }
   }
}
