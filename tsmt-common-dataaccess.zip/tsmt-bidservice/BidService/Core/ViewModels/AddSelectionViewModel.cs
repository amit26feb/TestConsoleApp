﻿// <copyright file="AddSelectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// View model for add bid selection
   /// </summary>
   public class AddSelectionViewModel
   {
      /// <summary>
      /// Gets or sets list of bid selections
      /// </summary>
      public List<SelectionDetailsViewModel> SelectionDetails { get; set; }

      /// <summary>
      /// Gets or sets list of job variations
      /// </summary>
      public List<JobVariationViewModel> JobVariations { get; set; }
   }
}