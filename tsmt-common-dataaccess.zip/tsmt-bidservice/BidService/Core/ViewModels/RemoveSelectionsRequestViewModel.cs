﻿// <copyright file="RemoveSelectionsRequestViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View model for removing selections from a bid
   /// </summary>
   public class RemoveSelectionsRequestViewModel
   {
      /// <summary>
      /// Gets or sets Selected Pricing Parm Id
      /// </summary>
      public int? SelectionId { get; set; }
   }
}
