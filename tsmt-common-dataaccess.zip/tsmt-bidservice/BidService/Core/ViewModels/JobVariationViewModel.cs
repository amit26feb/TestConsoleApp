﻿// <copyright file="JobVariationViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View model for job variation
   /// </summary>
   public class JobVariationViewModel
   {
      /// <summary>
      /// Gets or sets variation Id
      /// </summary>
      public int VariationId { get; set; }
   }
}