﻿// <copyright file="SelectionDetailsViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// View model for selection details
   /// </summary>
   public class SelectionDetailsViewModel
   {
      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SelectionId { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether to add selection to a a bid or not
      /// </summary>
      public bool ExcludeSelection { get; set; }

      /// <summary>
      /// Gets or sets list of separately biddables
      /// </summary>
      public List<SeparatelyBiddableViewModel> SeparatelyBiddableViewModel { get; set; }

      /// <summary>
      /// Gets or sets list of selection variations
      /// </summary>
      public List<VariationViewModel> VariationViewModel { get; set; }
   }
}
