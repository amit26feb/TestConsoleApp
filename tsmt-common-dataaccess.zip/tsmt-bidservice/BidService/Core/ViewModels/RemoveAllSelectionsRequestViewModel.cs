﻿// <copyright file="RemoveAllSelectionsRequestViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// View model for removing all selections from the bid
   /// </summary>
   public class RemoveAllSelectionsRequestViewModel
   {
      /// <summary>
      /// Gets or sets list of selections
      /// </summary>
      public List<RemoveSelectionsRequestViewModel> RemoveSelectionsRequest { get; set; }

      /// <summary>
      /// Gets or sets list of PricingParams
      /// </summary>
      public List<RemoveSeparatelyBiddablesRequestViewModel> RemoveSeparatelyBiddablesRequest { get; set; }

      /// <summary>
      /// Gets or sets list of variations
      /// </summary>
      public List<RemoveVariationsRequestViewModel> RemoveVariationsRequest { get; set; }
   }
}
