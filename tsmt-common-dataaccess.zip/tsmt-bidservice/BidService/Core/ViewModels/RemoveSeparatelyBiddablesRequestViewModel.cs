﻿// <copyright file="RemoveSeparatelyBiddablesRequestViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   /// <summary>
   /// View model for removing separately biddable from the bid
   /// </summary>
   public class RemoveSeparatelyBiddablesRequestViewModel
   {
      /// <summary>
      /// Gets or sets SellingPrice
      /// </summary>
      public int? SelectedPricingParmId { get; set; }
   }
}
