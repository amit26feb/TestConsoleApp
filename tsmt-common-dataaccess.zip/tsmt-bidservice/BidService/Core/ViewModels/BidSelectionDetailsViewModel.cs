﻿// <copyright file="BidSelectionDetailsViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// Represents the bid selection details view model
   /// </summary>
   public class BidSelectionDetailsViewModel
   {
      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets bid name
      /// </summary>
      public string BidName { get; set; }

      /// <summary>
      /// Gets or sets selection ids
      /// </summary>
      public IEnumerable<int> SelectionIds { get; set; }

      /// <summary>
      /// Gets or sets selected pricing parameter's parent selection ids
      /// </summary>
      public IEnumerable<int> SelectedPricingParmParentSelectionIds { get; set; }

      /// <summary>
      /// Gets or sets parent selection ids
      /// </summary>
      public IEnumerable<int> ParentSelectionIds { get; set; }

      /// <summary>
      /// Gets or sets separately biddable selection ids
      /// </summary>
      public IEnumerable<int> SeparatelyBiddableSelectionIds { get; set; }
   }
}
