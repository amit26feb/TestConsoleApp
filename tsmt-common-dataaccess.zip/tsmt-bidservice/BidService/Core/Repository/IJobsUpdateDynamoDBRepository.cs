// <copyright file="IJobsUpdateDynamoDBRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using Amazon.DynamoDBv2.DocumentModel;
   using BidService.Core.Models;

   /// <summary>
   /// Provides methods that interacts with DynamoDB
   /// </summary>
   public interface IJobsUpdateDynamoDBRepository
   {
      /// <summary>
      /// Insert the jobs update request message into DynamoDB
      /// </summary>
      /// <param name="jobsUpdateMessage">Jobs update message to insert</param>
      /// <returns>True/False</returns>
      Task<bool> SaveJobsUpdateRequest(JobsUpdateDynamoDBMessage jobsUpdateMessage);

      /// <summary>
      /// Update process status for specific message id into DynamoDB
      /// </summary>
      /// <param name="jobsUpdateMessage">Jobs update message to update</param>
      /// <returns>Document which contains collection of attribute key-value pairs for update process status</returns>
      Task<Document> UpdateProcessStatus(JobsUpdateDynamoDBMessage jobsUpdateMessage);

      /// <summary>
      /// Gets the message details from dynamo db
      /// </summary>
      /// <param name="messageId">Message id</param>
      /// <param name="attributesToGet">optional; can be used to limit the attributes retrieved, which can be efficient when there are large attributes that can be ignored</param>
      /// <returns>Message details</returns>
      Task<JobsUpdateDynamoDBMessage> GetMessage(string messageId, List<string> attributesToGet = null);
   }
}
