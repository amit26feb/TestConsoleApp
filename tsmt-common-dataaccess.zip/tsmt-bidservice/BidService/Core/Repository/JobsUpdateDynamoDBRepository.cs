// <copyright file="JobsUpdateDynamoDBRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using Amazon;
   using Amazon.DynamoDBv2;
   using Amazon.DynamoDBv2.DocumentModel;
   using BidService.Core.Models;
   using DynamoDBWrapper;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using TSMT.Settings;

   /// <summary>
   /// Provides methods that interacts with DynamoDB
   /// </summary>
   public class JobsUpdateDynamoDBRepository : IJobsUpdateDynamoDBRepository
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="JobsUpdateDynamoDBRepository"/> class.
      /// </summary>
      /// <param name="logger">Defines methods that captures the logging messages</param>
      /// <param name="appSettings">App settings for fetching environment details</param>
      /// <param name="dynamoTableConfig">Dynamo table details</param>
      public JobsUpdateDynamoDBRepository(ILogger<DynamoDBRepository> logger, IOptions<TSMTSettings> appSettings, IDynamoTableConfig dynamoTableConfig)
      {
         this.Logger = logger;
         this.AppSettings = appSettings;
         this.DynamoTableConfig = dynamoTableConfig;
         dynamoTableConfig.TableName = appSettings.Value.DynamoJobTableName;
         dynamoTableConfig.KeyName = appSettings.Value.DynamoJobKeyName;
         dynamoTableConfig.KeyType = typeof(string);
         var config = new AmazonDynamoDBConfig
         {
            RegionEndpoint = RegionEndpoint.GetBySystemName(appSettings.Value.DynamoRegion)
         };

         this.DynamoDBRepository = new DynamoDBRepository(new AmazonDynamoDBClient(config), dynamoTableConfig, this.Logger);
      }

      /// <summary>
      /// Gets or sets DynamoDBRepository
      /// </summary>
      public IDynamoDBRepository DynamoDBRepository { get; set; }

      /// <summary>
      /// Gets or sets logger
      /// </summary>
      private ILogger<DynamoDBRepository> Logger { get; set; }

      /// <summary>
      /// Gets or sets AppSettings
      /// </summary>
      private IOptions<TSMTSettings> AppSettings { get; set; }

      /// <summary>
      /// Gets or sets DynamoTableConfig
      /// </summary>
      private IDynamoTableConfig DynamoTableConfig { get; set; }

      /// <summary>
      /// Insert the jobs update request message into DynamoDB
      /// </summary>
      /// <param name="jobsUpdateMessage">Jobs update message to insert</param>
      /// <returns>True</returns>
      public async Task<bool> SaveJobsUpdateRequest(JobsUpdateDynamoDBMessage jobsUpdateMessage)
      {
         await this.DynamoDBRepository.InsertAsync(jobsUpdateMessage);
         return true;
      }

      /// <summary>
      /// Update process status for specific message id into DynamoDB
      /// </summary>
      /// <param name="jobsUpdateMessage">Jobs update message to update</param>
      /// <returns>Document which contains collection of attribute key-value pairs for update process status</returns>
      public async Task<Document> UpdateProcessStatus(JobsUpdateDynamoDBMessage jobsUpdateMessage)
      {
         return await this.DynamoDBRepository.PartialUpdateCommandAsync(jobsUpdateMessage);
      }

      /// <summary>
      /// Gets the message from dynamo db
      /// </summary>
      /// <param name="messageId">Message id</param>
      /// <param name="attributesToGet">optional; can be used to limit the attributes retrieved, which can be efficient when there are large attributes that can be ignored</param>
      /// <returns>Message details</returns>
      public async Task<JobsUpdateDynamoDBMessage> GetMessage(string messageId, List<string> attributesToGet = null)
      {
         return await this.DynamoDBRepository.GetAsync<JobsUpdateDynamoDBMessage>(messageId, null, true, attributesToGet);
      }
   }
}
