// <copyright file="IBidRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using BidService.Core.Models;
   using BidService.Core.ViewModels;

   /// <summary>
   /// Repository for bids operations
   /// </summary>
   public interface IBidRepository
   {
      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Gets the list of bids having credit job details in bid alternate table
      /// </summary>
      /// <param name="jobId"> Id of the corresponding Job</param>
      /// <returns> List of bid details</returns>
      Task<IEnumerable<BidAlternate>> GetBidListAsync(int jobId);

      /// <summary>
      /// Gets the list of bids by the search criteria provided.
      /// </summary>
      /// <param name="criteria">The search criteria</param>
      /// <returns>IEnumerable of <see cref="BidViewModel"/></returns>
      Task<IEnumerable<BidViewModel>> GetBidListAsync(BidSearchModel criteria);

      /// <summary>
      /// Gets a bid detail record
      /// </summary>
      /// <param name="jobId">job id</param>
      /// <param name="bidAlternateId">bid alternate id</param>
      /// <returns>Bid detail record</returns>
      Task<BidViewModel> GetBidAsync(int jobId, int bidAlternateId);

      /// <summary>
      /// Gets the list of bids having credit job details in credit job table
      /// </summary>
      /// <param name="jobId"> Id of the corresponding Job</param>
      /// <returns> List of bid details </returns>
      Task<IEnumerable<BidViewModel>> GetCreditJobListAsync(int jobId);

      /// <summary>
      /// Gets the list of credit jobs
      /// </summary>
      /// <param name="jobId"> Id of the corresponding Job</param>
      /// <param name="bidAlternateId"> Id of the bid alternate record</param>
      /// <returns> List of bid details </returns>
      Task<IEnumerable<CreditJob>> GetCreditJobsAsync(int jobId, int bidAlternateId);

      /// <summary>
      /// Update current bid status
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be assigned as current bid</param>
      /// <returns>A <see cref="Task"/>Update status</returns>
      Task<int> UpdateCurrentBidAsync(int jobId, int bidAlternateId);

      /// <summary>
      /// Assigns the Id for the corresponding table
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <returns>Maximum value of Id</returns>
      Task<int> GetSequenceNumber(string tableName);

      /// <summary>
      /// Method to generate sequence number
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <param name="howManyToReserve">How many blocks of new IDs to reserve for a table</param>
      /// <returns>Maximum sequence number of specific table</returns>
      Task<int> GetSequenceNumber(string tableName, int howManyToReserve);

      /// <summary>
      /// Create a new bid
      /// </summary>
      /// <param name="bid">Model of the bid alternate table</param>
      /// <returns>Create Status</returns>
      Task<int> CreateBidAsync(BidService.Core.Models.BidAlternate bid);

      /// <summary>
      /// Validate bid name duplication when create or update bid
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <param name="bidName">bidName</param>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <returns>If bid name has more than one record, should return false otherwise return true</returns>
      Task<bool> ValidateBidName(int jobId, string bidName, int bidAlternateId);

      /// <summary>
      /// Deleting a bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be deleted</param>
      /// <returns>Deleted status</returns>
      Task<int> DeleteBidAsync(int jobId, int bidAlternateId);

      /// <summary>
      /// Identify if defined bid is marked as current
      /// </summary>
      /// <param name="bidAlternateId">Bidalternate id</param>
      /// <returns>TRUE, if bid is identified as current</returns>
      Task<bool> IsBidCurrentAsync(int bidAlternateId);

      /// <summary>
      /// Gets the bidalternate id for a base bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>bidalternate id value for a base bid</returns>
      Task<int> GetBaseBidAlternateIdAsync(int jobId);

      /// <summary>
      /// Gets the current bid alternate id for a job
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Bid alternate id for a job</returns>
      Task<int> GetCurrentBidAlternateIdAsync(int jobId);

      /// <summary>
      /// Update the base bid as current bid if current bid needs to be deleted
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the current bid to be deleted</param>
      /// <param name="baseBidAlternateId">Bidalternate id of the base bid to be updated</param>
      /// <returns>Update status</returns>
      Task<int> UpdateAndDeleteBidAsync(int jobId, int bidAlternateId, int baseBidAlternateId);

      /// <summary>
      /// Update a bid
      /// </summary>
      /// <param name="bid">Model of the bid alternate table</param>
      /// <returns>Updaed row count</returns>
      Task<int> UpdateBidAsync(BidService.Core.Models.BidAlternate bid);

      /// <summary>
      /// Gets list of bid selections for a given job id
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <returns>List of bid selections</returns>
      Task<IEnumerable<BidSelections>> GetBidSelectionsQuery(int jobId);

      /// <summary>
      /// Inserts selectionId/separatelyBiddableId/variationId into BidAlternateXref table
      /// </summary>
      /// <param name= "bidSelectionList">list of bid selections</param>
      /// <returns>True if records inserted else false</returns>
      Task<bool> InsertSelections(IEnumerable<BidSelections> bidSelectionList);

      /// <summary>
      ///  Delete all selections from a bid
      /// </summary>
      /// <param name="bidAlternateId">Bid alternate id</param>
      /// <param name="removeAllSelectionsRequest">Request for removing all selections</param>
      /// <returns>Deleted status</returns>
      Task<bool> DeleteAllSelectionsAsync(int bidAlternateId, RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest);

      /// <summary>
      /// Getting database date
      /// </summary>
      /// <returns>Database date</returns>
      Task<DateTime> GetDbDate();

      /// <summary>
      /// Get bids for coordination
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Bids for coordination</returns>
      Task<IEnumerable<CoordinationJobBid>> GetBidsForCoordination(int jobId);

      /// <summary>
      /// Update bid whether included for job coordination or not
      /// </summary>
      /// <param name="jobCoordinationStatusForBids">Job coordination status for bids model</param>
      /// <returns>Boolean</returns>
      Task<bool> UpdateJobCoordinationStatusForBids(IEnumerable<JobCoordinationStatusForBids> jobCoordinationStatusForBids);

      /// <summary>
      /// Gets the bid selection details
      /// </summary>
      /// <param name="bidIds">Bid ids</param>
      /// <returns>Bid selection details</returns>
      Task<IEnumerable<BidSelectionDetails>> GetBidSelectionDetails(IEnumerable<int> bidIds);
   }
}
