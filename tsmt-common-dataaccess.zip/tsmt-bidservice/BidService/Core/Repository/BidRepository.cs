// <copyright file="BidRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Repository
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Linq;
   using System.Threading.Tasks;
   using BidService.Common.Constants;
   using BidService.Common.Exceptions;
   using BidService.Core.Models;
   using BidService.Core.ViewModels;
   using Dapper;
   using DataAccess.Core.Abstractions;
   using Oracle.ManagedDataAccess.Client;
   using TSMT.DataAccess;

   /// <summary>
   /// Repository for bid operations
   /// </summary>
   public class BidRepository : IBidRepository
   {
      // Limiting the count of input to delete for avoiding the orcale exception(maximum number of expression in a list is 1000)
      private const int OracleMaxListSize = 1000;
      private readonly IRepository<BidAlternate> repository;
      private readonly IConnectionFactory connectionFactory;

      private int? drAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="BidRepository"/> class.
      /// </summary>
      /// <param name="repository">Repository</param>
      /// <param name="connectionFactory">Connection factory</param>
      public BidRepository(IRepository<BidAlternate> repository, IConnectionFactory connectionFactory)
      {
         this.repository = repository;
         this.connectionFactory = connectionFactory;
      }

      /// <summary>
      /// Gets a database connection.
      /// Pays attention to a specific DrAddressId if we have been told to do so.
      /// </summary>
      private IDbConnection GetConnection
      {
         get
         {
            if (this.drAddressId.HasValue)
            {
               return this.connectionFactory.GetOpenConnectionForDrAddressId(this.drAddressId.Value);
            }
            else
            {
               return this.connectionFactory.GetConnection();
            }
         }
      }

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      public void HonorDrAddressId(int? drAddressId)
      {
         // Keep track of it, in case we have the ConnectionFactory generate a new connection in this repository.
         this.drAddressId = drAddressId;

         // Tell all IRepository instances about it.
         this.repository.HonorDrAddressId(drAddressId);
      }

      /// <summary>
      /// Gets the list of bids having credit job details in bid alternate table
      /// </summary>
      /// <param name="jobId"> Id of the corresponding job</param>
      /// <returns> List of bid details </returns>
      public async Task<IEnumerable<BidAlternate>> GetBidListAsync(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         return await this.repository.GetListAsync<BidAlternate>(BidRepositoryQueries.GetBidListQuery, param);
      }

      /// <inheritdoc/>
      public Task<IEnumerable<BidViewModel>> GetBidListAsync(BidSearchModel criteria)
      {
         return this.repository.GetListAsync<BidViewModel>(BidRepositoryQueries.GetBidListSearch, criteria);
      }

      /// <inheritdoc/>
      public async Task<BidViewModel> GetBidAsync(int jobId, int bidAlternateId)
      {
         var param = new
         {
            JOB_ID = jobId,
            BID_ALTERNATE_ID = bidAlternateId
         };

         return await this.repository.GetAsync<BidViewModel>(BidRepositoryQueries.GetBidQuery, param);
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<CreditJob>> GetCreditJobsAsync(int jobId, int bidAlternateId)
      {
         var param = new
         {
            JOB_ID = jobId,
            BID_ALTERNATE_ID = bidAlternateId
         };

         return await this.repository.GetListAsync<CreditJob>(BidRepositoryQueries.CreditJobQuery, param);
      }

      /// <summary>
      /// Gets the list of bids having credit job details in credit job table
      /// </summary>
      /// <param name="jobId"> Id of the corresponding job </param>
      /// <returns> List of bid details </returns>
      public async Task<IEnumerable<BidViewModel>> GetCreditJobListAsync(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         return await this.repository.GetListAsync<BidViewModel>(BidRepositoryQueries.CreditJobListQuery, param);
      }

      /// <summary>
      /// Update current bid status
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be assigned as current bid</param>
      /// <returns>A <see cref="Task"/>Update status</returns>
      public async Task<int> UpdateCurrentBidAsync(int jobId, int bidAlternateId)
      {
         var param = new
         {
            JOB_ID = jobId,
            bid_alternate_id = bidAlternateId
         };
         return await this.repository.ExecuteAsync<int>(BidRepositoryQueries.CurrentBidUpdateQuery, param);
      }

      /// <summary>
      /// Deleting a bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the bid to be deleted</param>
      /// <returns>Deleted status</returns>
      public async Task<int> DeleteBidAsync(int jobId, int bidAlternateId)
      {
         var param = new
         {
            JOB_ID = jobId,
            bid_alternate_id = bidAlternateId
         };
         return await this.repository.ExecuteAsync<int>(BidRepositoryQueries.DeleteBidAlternateQuery, param);
      }

      /// <summary>
      /// Identify if defined bid is marked as current
      /// </summary>
      /// <param name="bidAlternateId">Bidalternate id</param>
      /// <returns>TRUE, if bid is identified as current</returns>
      public async Task<bool> IsBidCurrentAsync(int bidAlternateId)
      {
         var param = new
         {
            bid_alternate_id = bidAlternateId
         };

         string currentBidInd = await this.repository.ExecuteQuery<string>(BidRepositoryQueries.GetBidCurrentIndQuery, param);
         return currentBidInd == "Y";
      }

      /// <summary>
      /// Update the base bid as current bid if current bid needs to be deleted
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <param name="bidAlternateId">Bidalternate id of the current bid to be deleted</param>
      /// <param name="baseBidAlternateId">Bidalternate id of the base bid to be updated</param>
      /// <returns>Update status</returns>
      public async Task<int> UpdateAndDeleteBidAsync(int jobId, int bidAlternateId, int baseBidAlternateId)
      {
         var deleteParam = new
         {
            JOB_ID = jobId,
            bid_alternate_id = bidAlternateId
         };
         var updateParam = new
         {
            JOB_ID = jobId,
            bid_alternate_id = baseBidAlternateId
         };
         int recordDeleted = 0;
         using (IDbConnection connection = this.GetConnection)
         {
            IDbTransaction transaction = connection.BeginTransaction();
            try
            {
               await connection.ExecuteAsync(BidRepositoryQueries.CurrentBidUpdateQuery, updateParam, transaction);
               recordDeleted = await connection.ExecuteAsync(BidRepositoryQueries.DeleteBidAlternateQuery, deleteParam, transaction);

               transaction.Commit();
            }
            catch (Exception e)
            {
               transaction.Rollback();
               throw new BidServiceDomainException(e.Message);
            }
         }

         return recordDeleted;
      }

      /// <summary>
      /// Gets the bidalternate id for a base bid
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>bidalternate id value for a base bid</returns>
      public async Task<int> GetBaseBidAlternateIdAsync(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         return await this.repository.ExecuteQuery<int>(BidRepositoryQueries.GetBaseBidAlternateIdQuery, param);
      }

      /// <summary>
      /// Gets the current bid alternate id for a job
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Bid alternate id for a job</returns>
      public async Task<int> GetCurrentBidAlternateIdAsync(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         return await this.repository.ExecuteQuery<int>(BidRepositoryQueries.GetCurrentBidAlternateIdQuery, param);
      }

      /// <summary>
      /// Inserts new Bid into Table
      /// </summary>
      /// <param name="bid">Model of the Bid Alternate table</param>
      /// <returns>Create Status</returns>
      public async Task<int> CreateBidAsync(BidService.Core.Models.BidAlternate bid)
      {
         var param = new
         {
            bid.BID_ALTERNATE_ID,
            bid.JOB_ID,
            bid.BASE_BID_YES_NO,
            bid.BID_NAME,
            bid.INCLUDE_IN_CJ,
            bid.DESCR,
            bid.CURRENT_BID_IND,
            bid.SELLING_PRICE
         };

         return await this.repository.ExecuteAsync<BidService.Core.Models.BidAlternate>(BidRepositoryQueries.CreateBidQuery, param);
      }

      /// <summary>
      /// Validate bid name duplication when create or update bid
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <param name="bidName">bidName</param>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <returns>If bid name has more than one record, should return false otherwise return true</returns>
      public async Task<bool> ValidateBidName(int jobId, string bidName, int bidAlternateId)
      {
         string query;
         var param = new
         {
            job_Id = jobId,
            bid_Name = bidName,
            bid_Alternate_Id = bidAlternateId
         };

         if (bidAlternateId == 0)
         {
            query = BidRepositoryQueries.ValidateBidNameQueryForInvalidBidAlternateId;
         }
         else
         {
            query = BidRepositoryQueries.ValidateBidNameQueryForValidBidAlternateId;
         }

         int bidNameCount = await this.repository.ExecuteQuery<int>(query, param);
         return bidNameCount == 0;
      }

      /// <summary>
      /// Update a Bid into Table based on Bid Alternate Id
      /// </summary>
      /// <param name="bid">Model of the Bid Alternate table</param>
      /// <returns>Updated rows count</returns>
      public async Task<int> UpdateBidAsync(BidService.Core.Models.BidAlternate bid)
      {
         var param = new
         {
            bid.BID_ALTERNATE_ID,
            bid.JOB_ID,
            bid.BID_NAME,
            bid.DESCR,
         };

         return await this.repository.ExecuteAsync<BidService.Core.Models.BidAlternate>(BidRepositoryQueries.UpdateBidQuery, param);
      }

      /// <summary>
      /// Gets list of bid selections for a given job id
      /// </summary>
      /// <param name="jobId">jobId</param>
      /// <returns>List of bid selections</returns>
      public async Task<IEnumerable<BidSelections>> GetBidSelectionsQuery(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         return await this.repository.ExecuteListQuery<BidSelections>(BidRepositoryQueries.GetBidSelectionsQuery, param);
      }

      /// <summary>
      /// Inserts selectionId/separatelyBiddableId/variationId into BidAlternateXref table
      /// </summary>
      /// <param name= "bidSelectionList">list of bid selection</param>
      /// <returns>True if records inserted else false</returns>
      public async Task<bool> InsertSelections(IEnumerable<BidSelections> bidSelectionList)
      {
         int recordsInserted = await this.InsertSelectionsAsync(bidSelectionList);
         return recordsInserted > 0;
      }

      /// <summary>
      ///  Delete all selections from a bid
      /// </summary>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <param name="removeAllSelectionsRequest">Request for removing all selections</param>
      /// <returns>Deleted status</returns>
      public async Task<bool> DeleteAllSelectionsAsync(int bidAlternateId, RemoveAllSelectionsRequestViewModel removeAllSelectionsRequest)
      {
         int skip;
         using (IDbConnection connection = this.GetConnection)
         {
            IDbTransaction transaction = connection.BeginTransaction();
            try
            {
               if (removeAllSelectionsRequest.RemoveSelectionsRequest != null && removeAllSelectionsRequest.RemoveSelectionsRequest.Any())
               {
                  var selectionIdList = removeAllSelectionsRequest.RemoveSelectionsRequest.Select(selection => selection.SelectionId);
                  skip = 0;
                  while (skip < selectionIdList.Count())
                  {
                     var selectionIdListToBeDeleted = selectionIdList.Skip(skip).Take(OracleMaxListSize);
                     var selectionParam = new
                     {
                        bid_alternate_id = bidAlternateId,
                        selection_id_list = selectionIdListToBeDeleted
                     };
                     await connection.ExecuteAsync(BidRepositoryQueries.RemoveSelectionQuery, selectionParam, transaction);
                     skip += OracleMaxListSize;
                  }
               }

               if (removeAllSelectionsRequest.RemoveSeparatelyBiddablesRequest != null && removeAllSelectionsRequest.RemoveSeparatelyBiddablesRequest.Any())
               {
                  var selectedPricingParmIdList = removeAllSelectionsRequest.RemoveSeparatelyBiddablesRequest.Select(separatelyBiddable => separatelyBiddable.SelectedPricingParmId);
                  skip = 0;
                  while (skip < selectedPricingParmIdList.Count())
                  {
                     var selectedPricingParamIdListToBeDeleted = selectedPricingParmIdList.Skip(skip).Take(OracleMaxListSize);
                     var selectedPricingParmParam = new
                     {
                        bid_alternate_id = bidAlternateId,
                        spp_id_list = selectedPricingParamIdListToBeDeleted
                     };
                     await connection.ExecuteAsync(BidRepositoryQueries.RemoveSeparatlyBiddableQuery, selectedPricingParmParam, transaction);
                     skip += OracleMaxListSize;
                  }
               }

               if (removeAllSelectionsRequest.RemoveVariationsRequest != null && removeAllSelectionsRequest.RemoveVariationsRequest.Any())
               {
                  var variationIdList = removeAllSelectionsRequest.RemoveVariationsRequest.Select(variation => variation.VariationId);
                  await this.DeleteVariation(bidAlternateId, variationIdList, connection, transaction);
               }

               transaction.Commit();
            }
            catch (Exception e)
            {
               transaction.Rollback();
               throw new BidServiceDomainException(e.Message);
            }
         }

         return true;
      }

      /// <summary>
      /// Method to generate sequence number
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <param name="howManyToReserve">How many blocks of new IDs to reserve for a table</param>
      /// <returns>Maximum sequence number of specific table</returns>
      public async Task<int> GetSequenceNumber(string tableName, int howManyToReserve)
      {
         var param = new
         {
            TABLENAME = tableName,
            HOWMANYTORESERVE = howManyToReserve
         };

         int sequenceNumber = await this.repository.ExecuteQuery<int>(BidRepositoryQueries.GenerateSequenceNumberQuery, param);
         return sequenceNumber;
      }

      /// <summary>
      /// Getting Sequence Number from Package
      /// </summary>
      /// <param name="tableName">Name of the table</param>
      /// <returns>Maximum value of Id</returns>
      public async Task<int> GetSequenceNumber(string tableName)
      {
         var param = new
         {
            TABLENAME = tableName
         };

         int id = await this.repository.ExecuteQuery<int>(BidRepositoryQueries.GetSequenceNumberQuery, param);
         return id;
      }

      /// <summary>
      /// Getting database date
      /// </summary>
      /// <returns>Database date</returns>
      public async Task<DateTime> GetDbDate()
      {
         return await this.repository.ExecuteQuery<DateTime>(BidRepositoryQueries.GetDbDateQuery);
      }

      /// <summary>
      /// Get bids for coordination
      /// </summary>
      /// <param name="jobId">Job id</param>
      /// <returns>Bids for coordination</returns>
      public async Task<IEnumerable<CoordinationJobBid>> GetBidsForCoordination(int jobId)
      {
         var bidQueryParameter = new
         {
            JOB_ID = jobId
         };
         return await this.repository.ExecuteListQuery<CoordinationJobBid>(BidRepositoryQueries.BidQuery, bidQueryParameter);
      }

      /// <summary>
      /// Update bids whether included for job coordination or not
      /// </summary>
      /// <param name="jobCoordinationStatusForBids">Job coordination status for bids model</param>
      /// <returns>Boolean</returns>
      public async Task<bool> UpdateJobCoordinationStatusForBids(IEnumerable<JobCoordinationStatusForBids> jobCoordinationStatusForBids)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            IDbTransaction transaction = connection.BeginTransaction();
            try
            {
               await connection.ExecuteAsync(BidRepositoryQueries.UpdateBidsSelectionQuery, jobCoordinationStatusForBids, transaction);
               transaction.Commit();
               return true;
            }
            catch (Exception)
            {
               transaction.Rollback();
               return false;
            }
            finally
            {
               connection.Close();
            }
         }
      }

      /// <summary>
      /// Gets the bid selection details
      /// </summary>
      /// <param name="bidIds">Bid ids</param>
      /// <returns>Bid selection details</returns>
      public async Task<IEnumerable<BidSelectionDetails>> GetBidSelectionDetails(IEnumerable<int> bidIds)
      {
         var bidSelectionDetailsQueryParameter = new
         {
            BID_ID_LIST = bidIds,
         };
         return await this.repository.ExecuteListQuery<BidSelectionDetails>(BidRepositoryQueries.BidSelectionDetailsQuery, bidSelectionDetailsQueryParameter);
      }

      /// <summary>
      /// Inserts selectionId/separatelyBiddableId/variationId into BidAlternateXref table
      /// </summary>
      /// <param name= "bidSelectionList">list of bid selection</param>
      /// <returns>Number of records inserted</returns>
      private Task<int> InsertSelectionsAsync(IEnumerable<BidSelections> bidSelectionList)
      {
         IDbConnection oDPconnection = this.GetConnection;
         var command = (OracleCommand)oDPconnection.CreateCommand();
         command.CommandText = BidRepositoryQueries.InsertSelectionsQuery;
         command.CommandType = CommandType.Text;
         command.ArrayBindCount = bidSelectionList.Count();
         command.BindByName = true;
         command.Parameters.Add(":BID_ALTERNATE_XREF_ID", OracleDbType.Int64, bidSelectionList.Select(selecton => selecton.BID_ALTERNATE_XREF_ID).ToArray(), ParameterDirection.Input);
         command.Parameters.Add(":BID_ALTERNATE_ID", OracleDbType.Int64, bidSelectionList.Select(selecton => selecton.BID_ALTERNATE_ID).ToArray(), ParameterDirection.Input);
         command.Parameters.Add(":VARIATION_ID", OracleDbType.Int64, bidSelectionList.Select(selecton => selecton.VARIATION_ID).ToArray(), ParameterDirection.Input);
         command.Parameters.Add(":SELECTION_ID", OracleDbType.Int64, bidSelectionList.Select(selecton => selecton.SELECTION_ID).ToArray(), ParameterDirection.Input);
         command.Parameters.Add(":SELECTED_PRICING_PARM_ID", OracleDbType.Int64, bidSelectionList.Select(selecton => selecton.SELECTED_PRICING_PARM_ID).ToArray(), ParameterDirection.Input);
         return command.ExecuteNonQueryAsync();
      }

      /// <summary>
      /// Delete variations from BidAlternateXref table
      /// </summary>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <param name="variationIdList">Request for removing all variations</param>
      /// <param name= "connection">Db connection</param>
      /// <param name= "transaction">Db transaction</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      private async Task DeleteVariation(int bidAlternateId, IEnumerable<int?> variationIdList, IDbConnection connection, IDbTransaction transaction)
      {
         int skip = 0;
         while (skip < variationIdList.Count())
         {
            var variationIdListToBeDeleted = variationIdList.Skip(skip).Take(OracleMaxListSize);
            var variationParam = new
            {
               bid_alternate_id = bidAlternateId,
               variation_id_list = variationIdListToBeDeleted
            };
            await connection.ExecuteAsync(BidRepositoryQueries.DeleteVariation(bidAlternateId), variationParam, transaction);
            skip += OracleMaxListSize;
         }
      }
   }
}