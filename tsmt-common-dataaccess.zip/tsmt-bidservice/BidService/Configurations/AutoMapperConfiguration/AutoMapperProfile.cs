﻿// <copyright file="AutoMapperProfile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Configurations.AutoMapperConfiguration
{
   using AutoMapper;
   using BidService.Core.Models;
   using BidService.Core.ViewModels;
   using Models = Core.Models;
   using ViewModels = Core.ViewModels;

   /// <summary>
   /// Auto mapper profile
   /// </summary>
   public class AutoMapperProfile : Profile
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="AutoMapperProfile"/> class.
      /// </summary>
      public AutoMapperProfile()
      {
         this.MapForViewing();
         this.MapForAdding();
         this.MapForVersion2();
      }

      /// <summary>
      /// Maps v1 models to v2.
      /// </summary>
      private void MapForVersion2()
      {
         this.CreateMap<BidViewModel, ViewModels.V2.BidViewModel>();
      }

      /// <summary>
      /// Maps the domain models to the view models that are used for viewing in UI
      /// </summary>
      private void MapForViewing()
      {
         this.CreateMap<CoordinationJobBid, CoordinationJobBidViewModel>()
             .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
             .ForMember(dest => dest.BidName, opt => opt.MapFrom(src => src.BID_NAME))
             .ForMember(dest => dest.IsCurrentBid, opt => opt.MapFrom(src => src.CURRENT_BID_IND == "Y"))
             .ForMember(dest => dest.IsBidInCoordinationJob, opt => opt.MapFrom(src => this.MapIntToBool(src.INCLUDE_IN_CJ)))
             .ForMember(dest => dest.IsBaseBid, opt => opt.MapFrom(src => this.MapIntToBool(src.BASE_BID_YES_NO)))
             .ReverseMap();

         this.CreateMap<BidAlternate, BidViewModel>()
             .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
             .ForMember(dest => dest.BidName, opt => opt.MapFrom(src => src.BID_NAME))
             .ForMember(dest => dest.CurrentBidInd, opt => opt.MapFrom(src => src.CURRENT_BID_IND))
             .ForMember(dest => dest.IsIncludeInCoordinatedJob, opt => opt.MapFrom(src => this.MapIntToBool(src.INCLUDE_IN_CJ)))
             .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.DESCR))
             .ForMember(dest => dest.SellingPrice, opt => opt.MapFrom(src => src.SELLING_PRICE))
             .ForMember(dest => dest.HqtrBidAlternateId, opt => opt.MapFrom(src => src.HQTR_BID_ALTERNATE_ID))
             .ForMember(dest => dest.BaseBidYesNo, opt => opt.MapFrom(src => src.BASE_BID_YES_NO))
             .ForMember(dest => dest.Foe2CreatedOrdersInd, opt => opt.MapFrom(src => src.FOE2_CREATED_ORDERS_IND))
             .ForMember(dest => dest.CreditJobNumber, opt => opt.MapFrom(src => src.LEGACY_JOB_NBR))
             .ReverseMap();
      }

      /// <summary>
      /// Maps the Domain Moelds to the view models and viceversa for Add scenarios
      /// </summary>
      private void MapForAdding()
      {
         // CreateBid Mapping
         this.CreateMap<Models.BidAlternate, ViewModels.BidCreateModel>()
             .ForMember(dest => dest.JobId, opt => opt.MapFrom(src => src.JOB_ID))
             .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
             .ForMember(dest => dest.BaseBidYesNo, opt => opt.MapFrom(src => src.BASE_BID_YES_NO))
             .ForMember(dest => dest.BidName, opt => opt.MapFrom(src => src.BID_NAME))
             .ForMember(dest => dest.CurrentBidInd, opt => opt.MapFrom(src => src.CURRENT_BID_IND))
             .ForMember(dest => dest.IncludeInCJ, opt => opt.MapFrom(src => src.INCLUDE_IN_CJ))
             .ForMember(dest => dest.Description, opt => opt.MapFrom(src => src.DESCR))
             .ForMember(dest => dest.SellingPrice, opt => opt.MapFrom(src => src.SELLING_PRICE))
             .ReverseMap();

         // Selections Mapping
         this.CreateMap<Models.BidSelections, ViewModels.BidSelectionsViewModel>()
             .ForMember(dest => dest.BidAlternateXrefId, opt => opt.MapFrom(src => src.BID_ALTERNATE_XREF_ID))
             .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
             .ForMember(dest => dest.SelectedPricingParmId, opt => opt.MapFrom(src => src.SELECTED_PRICING_PARM_ID))
             .ForMember(dest => dest.VariationId, opt => opt.MapFrom(src => src.VARIATION_ID))
             .ForMember(dest => dest.SelectionId, opt => opt.MapFrom(src => src.SELECTION_ID))
             .ForMember(dest => dest.BidName, opt => opt.MapFrom(src => src.BID_NAME)).ReverseMap();

         // Update Bids Selection Mapping
         this.CreateMap<JobCoordinationStatusForBids, JobCoordinationStatusForBidsViewModel>()
             .ForMember(dest => dest.BidAlternateId, opt => opt.MapFrom(src => src.BID_ALTERNATE_ID))
             .ForMember(dest => dest.JobId, opt => opt.MapFrom(src => src.JOB_ID))
             .ForMember(dest => dest.IsBidInCoordinationJob, opt => opt.MapFrom(src => this.MapIntToBool(src.INCLUDE_IN_CJ)))
             .ForMember(dest => dest.DrAddressId, opt => opt.MapFrom(src => src.DR_ADDRESS_ID))
             .ReverseMap();
      }

      /// <summary>
      /// Maps integer to boolean
      /// </summary>
      /// <param name="isBidInCoordinationJob">Indicates if the bid is included for job coordination</param>
      /// <returns>True, if the bid is included for job coordination. False, if it is not included for coordination. Null, otherwise</returns>
      private bool? MapIntToBool(int? isBidInCoordinationJob)
      {
         switch (isBidInCoordinationJob)
         {
            case 1: return true;
            case 0: return false;
            default: return null;
         }
      }
   }
}
