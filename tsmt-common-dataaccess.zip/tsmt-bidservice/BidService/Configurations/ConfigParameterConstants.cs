﻿// <copyright file="ConfigParameterConstants.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Configurations
{
   /// <summary>
   /// ConfigParameterConstants. The Property names on this constant file need to be same as the TSMTSetttings file propety names.
   /// </summary>
   public class ConfigParameterConstants
   {
      /// <summary>
      /// Gets TSMT Connection String Parameter name
      /// </summary>
      public static string VPNDBConnectionString => "tsmt-tstrn-JobService-v2";

      /// <summary>
      /// Gets InfluxDb Parameter name
      /// </summary>
      public static string InfluxDb => "tsmt-influxdb-db";

      /// <summary>
      /// Gets InfluxDb Url Parameter name
      /// </summary>
      public static string InfluxDbUrl => "tsmt-influxdb-url";

      /// <summary>
      /// Gets InfluxDb UserName Parameter name
      /// </summary>
      public static string InfluxDbUserName => "tsmt-influxdb-user";

      /// <summary>
      /// Gets InfluxDb Password Parameter name
      /// </summary>
      public static string InfluxDbPassword => "tsmt-influxdb-password";

      /// <summary>
      /// Gets SecretKeyJob Parameter name
      /// </summary>
      public static string SecretKeyJob => "tsmt-secretkey-JobService";

      /// <summary>
      /// Gets RedisEndpoint Parameter name
      /// </summary>
      public static string RedisEndpoint => "tsmt-redisendpoint-BidService-v2";
   }
}
