﻿// <copyright file="ConfigureSwaggerOptions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Configurations.Swagger
{
   using System.Collections.Generic;
   using Microsoft.AspNetCore.Mvc.ApiExplorer;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.Extensions.Options;
   using Microsoft.OpenApi.Models;
   using Swashbuckle.AspNetCore.SwaggerGen;

   /// <summary>
   /// Configures the Swagger generation options.
   /// </summary>
   /// <remarks>This allows API versioning to define a Swagger document per API version after the
   /// <see cref="IApiVersionDescriptionProvider"/> service has been resolved from the service container.</remarks>
   public class ConfigureSwaggerOptions : IConfigureOptions<SwaggerGenOptions>
   {
      private readonly IApiVersionDescriptionProvider provider;
      private readonly string serviceName;
      private readonly string applicationVersion;

      /// <summary>
      /// Initializes a new instance of the <see cref="ConfigureSwaggerOptions"/> class.
      /// </summary>
      /// <param name="provider">The <see cref="IApiVersionDescriptionProvider">provider</see> used to generate Swagger documents.</param>
      /// <param name="serviceName">The name of the microservice.</param>
      /// <param name="applicationVersion">The application version (Image/Build Tag).</param>
      public ConfigureSwaggerOptions(IApiVersionDescriptionProvider provider, string serviceName, string applicationVersion)
      {
         this.provider = provider;
         this.serviceName = serviceName;
         this.applicationVersion = applicationVersion;
      }

      /// <inheritdoc />
      public void Configure(SwaggerGenOptions options)
      {
         options.CustomSchemaIds(x => x.FullName);

         // add a swagger document for each discovered API version
         // note: you might choose to skip or document deprecated API versions differently
         foreach (var description in this.provider.ApiVersionDescriptions)
         {
            options.SwaggerDoc(description.GroupName, CreateInfoForApiVersion(description, this.serviceName, this.applicationVersion));
         }

         OpenApiSecurityScheme apiKeyScheme = new OpenApiSecurityScheme()
         {
            Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
            Name = "Authorization",
            In = ParameterLocation.Header,
            Type = SecuritySchemeType.ApiKey,
            Scheme = "Bearer",
            BearerFormat = "JWT"
         };

         options.AddSecurityDefinition("Bearer", apiKeyScheme);

         var security = new OpenApiSecurityRequirement()
         {
            {
               new OpenApiSecurityScheme
               {
                  Reference = new OpenApiReference
                  {
                     Type = ReferenceType.SecurityScheme,
                     Id = "Bearer",
                  },
                  Scheme = "OAuth2",
                  Name = "Bearer",
                  In = ParameterLocation.Header
               }, new List<string>()
            }
         };
         options.AddSecurityRequirement(security);
      }

      private static OpenApiInfo CreateInfoForApiVersion(ApiVersionDescription description, string serviceName, string applicationVersion)
      {
         var info = new OpenApiInfo()
         {
            Title = $"{serviceName} HTTP API {applicationVersion}",
            Version = description.ApiVersion.ToString(),
            Description = $"The {serviceName} HTTP API {applicationVersion}",
         };

         if (description.IsDeprecated)
         {
            info.Description += " This API version has been deprecated.  Please check the version options for a newer version.";
         }

         return info;
      }
   }
}
