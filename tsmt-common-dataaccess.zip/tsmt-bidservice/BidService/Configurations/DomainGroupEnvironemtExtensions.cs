// <copyright file="DomainGroupEnvironemtExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Configurations
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Hosting;

    /// <summary>
    /// Domain group environment extensions
    /// </summary>
    public static class DomainGroupEnvironemtExtensions
    {
        /// <summary>
        /// Checks and return the web host environment name
        /// </summary>
        /// <param name="hostingEnvironment">Web host environment</param>
        /// <returns>Environment Name</returns>
        public static string DomainGroupEnvironmentName(this IWebHostEnvironment hostingEnvironment)
        {
            if (hostingEnvironment.IsDevelopment())
            {
               return TraneSalesTools.EnvNameEnum.DEV.ToString();
            }
            else if (hostingEnvironment.IsProduction())
            {
                return TraneSalesTools.EnvNameEnum.PROD.ToString();
            }
            else if (hostingEnvironment.IsStaging() || hostingEnvironment.IsUAT())
            {
                return TraneSalesTools.EnvNameEnum.STAGING.ToString();
            }
            else
            {
                return TraneSalesTools.EnvNameEnum.TEST.ToString();
            }
        }
    }
}
