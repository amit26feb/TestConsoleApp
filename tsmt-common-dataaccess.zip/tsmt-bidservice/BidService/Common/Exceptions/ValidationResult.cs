// <copyright file="ValidationResult.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Exceptions
{
    using System.Collections.Generic;

    /// <summary>
    /// Validation result
    /// </summary>
    public static class ValidationResult
    {
        /// <summary>
        /// To assign the error messages in Json response format
        /// </summary>
        /// <param name="errorMessages">Error message</param>
        /// <returns>Error messages in Json response</returns>
        public static JsonErrorResponse ValidationMessage(IEnumerable<string> errorMessages)
        {
            var response = new JsonErrorResponse
            {
                Messages = errorMessages,
                DeveloperMessage = string.Empty
            };
            return response;
        }
    }
}
