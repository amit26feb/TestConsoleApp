﻿// <copyright file="BidServiceDomainException.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Exceptions
{
    using System;
    using System.Runtime.Serialization;

    /// <summary>
    /// Exception type for app exceptions
    /// </summary>
    [Serializable]
    public class BidServiceDomainException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BidServiceDomainException"/> class.
        /// </summary>
        public BidServiceDomainException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BidServiceDomainException"/> class.
        /// </summary>
        /// <param name="message">message</param>
        public BidServiceDomainException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BidServiceDomainException"/> class.
        /// </summary>
        /// <param name="message">Message detatails</param>
        /// <param name="innerException">inner exception</param>
        public BidServiceDomainException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BidServiceDomainException"/> class.
        /// </summary>
        /// <param name="info">The serialization info</param>
        /// <param name="context">The streaming context</param>
        protected BidServiceDomainException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}