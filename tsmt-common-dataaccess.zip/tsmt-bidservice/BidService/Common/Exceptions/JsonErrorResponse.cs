// <copyright file="JsonErrorResponse.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Exceptions
{
    using System.Collections.Generic;

    /// <summary>
    /// The json error response.
    /// </summary>
    public class JsonErrorResponse
    {
        /// <summary>
        /// Gets or sets the messages.
        /// </summary>
        public IEnumerable<string> Messages { get; set; }

        /// <summary>
        /// Gets or sets the developer message.
        /// </summary>
        public dynamic DeveloperMessage { get; set; }
    }
}
