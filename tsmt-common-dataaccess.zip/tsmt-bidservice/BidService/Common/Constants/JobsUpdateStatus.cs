﻿// <copyright file="JobsUpdateStatus.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Constants
{
    /// <summary>
    /// Jobs update status
    /// </summary>
    public static class JobsUpdateStatus
    {
        /// <summary>
        /// Pending status type
        /// </summary>
        public const string Pending = "Pending";

        /// <summary>
        /// Completed status type
        /// </summary>
        public const string Completed = "Completed";

        /// <summary>
        /// Failed status type
        /// </summary>
        public const string Failed = "Failed";

        /// <summary>
        /// None status type
        /// </summary>
        public const string None = "None";
    }
}
