﻿// <copyright file="BidNotificationType.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Constants
{
   /// <summary>
   /// Type of notification based on action on bids
   /// </summary>
   public enum BidNotificationType
   {
      /// <summary>
      /// Indicates notification on successful create
      /// </summary>
      Create,

      /// <summary>
      /// Indicates notification on successful edit
      /// </summary>
      Edit,

      /// <summary>
      /// Indicates notification on successful delete
      /// </summary>
      Delete,

      /// <summary>
      /// None
      /// </summary>
      None
   }
}
