﻿// <copyright file="SnsFilterRecipients.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Constants
{
    /// <summary>
    /// SNS filter Recipients for filter the SQS messages
    /// </summary>
    public static class SnsFilterRecipients
    {
        /// <summary>
        /// Jobs update recipient type
        /// </summary>
        public const string JobsUpdate = "TSMT-SQS-Filter-Jobs-Update";
    }
}
