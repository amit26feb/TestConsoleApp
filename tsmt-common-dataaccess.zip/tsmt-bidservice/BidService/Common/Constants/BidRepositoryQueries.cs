﻿// <copyright file="BidRepositoryQueries.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Constants
{
   using System.Text;

   /// <summary>
   /// Constant file for bid repository queries
   /// </summary>
   public static class BidRepositoryQueries
   {
      /// <summary>
      /// Query to get the bids based on job id
      /// </summary>
      public const string BidQuery = @"SELECT BID_ALTERNATE_ID,
                                                BID_NAME,
                                                CURRENT_BID_IND,
                                                INCLUDE_IN_CJ,
                                                BASE_BID_YES_NO
                                         FROM BID_ALTERNATE
                                         WHERE JOB_ID = :JOB_ID
                                         ORDER BY CURRENT_BID_IND DESC,
                                                  BID_NAME";

      /// <summary>
      /// Query to update the coordinate bids for job coordination
      /// </summary>
      public const string UpdateBidsSelectionQuery = @"UPDATE
                                                      BID_ALTERNATE 
                                                   SET
                                                      INCLUDE_IN_CJ = :INCLUDE_IN_CJ 
                                                   WHERE
                                                      JOB_ID = :JOB_ID 
                                                      AND BID_ALTERNATE_ID = :BID_ALTERNATE_ID";

      /// <summary>
      /// Query to get bid selection details
      /// </summary>
      public const string BidSelectionDetailsQuery = @"WITH BIDSELECTION AS
                                                                  (SELECT DISTINCT V.SELECTION_ID,
                                                                                   BA.BID_NAME,
                                                                                   BA.BID_ALTERNATE_ID,
                                                                                   'Variation' AS SELECTION_TYPE
                                                                   FROM BID_ALTERNATE_XREF BAX
                                                                   INNER JOIN BID_ALTERNATE BA ON BA.BID_ALTERNATE_ID = BAX.BID_ALTERNATE_ID
                                                                   INNER JOIN VARIATION V ON V.VARIATION_ID = BAX.VARIATION_ID
                                                                   WHERE BA.BID_ALTERNATE_ID IN :BID_ID_LIST
                                                                         AND V.SELECTION_ID IS NOT NULL
                                                                   UNION 
                                                                   SELECT DISTINCT S.SELECTION_ID,
                                                                                   BA.BID_NAME,
                                                                                   BA.BID_ALTERNATE_ID,
                                                                                   'Selection' AS SELECTION_TYPE
                                                                   FROM SELECTION S
                                                                   INNER JOIN BID_ALTERNATE_XREF BAX ON S.SELECTION_ID = BAX.SELECTION_ID
                                                                   INNER JOIN BID_ALTERNATE BA ON BA.BID_ALTERNATE_ID = BAX.BID_ALTERNATE_ID
                                                                   WHERE BA.BID_ALTERNATE_ID IN :BID_ID_LIST
                                                                         AND S.SELECTION_ID IS NOT NULL
                                                                   UNION 
                                                                   SELECT DISTINCT SPP.SELECTION_ID,
                                                                                   BA.BID_NAME,
                                                                                   BA.BID_ALTERNATE_ID,
                                                                                   'SelectedPricingParm' AS SELECTION_TYPE
                                                                   FROM SELECTED_PRICING_PARM SPP
                                                                   INNER JOIN BID_ALTERNATE_XREF BAX ON BAX.SELECTED_PRICING_PARM_ID = SPP.SELECTED_PRICING_PARM_ID
                                                                   INNER JOIN BID_ALTERNATE BA ON BA.BID_ALTERNATE_ID = BAX.BID_ALTERNATE_ID
                                                                   WHERE BA.BID_ALTERNATE_ID IN :BID_ID_LIST
                                                                         AND SPP.SELECTION_ID IS NOT NULL)
                                                             SELECT BS.BID_ALTERNATE_ID,
                                                                    BS.BID_NAME,
                                                                    BS.SELECTION_ID,
                                                                    BS.SELECTION_TYPE
                                                             FROM BIDSELECTION BS
                                                             ORDER BY BS.BID_NAME";

      /// <summary>
      /// Query to update the current bid
      /// </summary>
      public const string CurrentBidUpdateQuery = @"UPDATE bid_alternate
                                    SET current_bid_ind = CASE   
                                    WHEN bid_alternate_id = :bid_alternate_id THEN 'Y'  
                                    WHEN bid_alternate_id !=:bid_alternate_id THEN 'N'  
                                    END
                                    where  job_id = :JOB_ID";

      /// <summary>
      /// Query to delete the bid alternate
      /// </summary>
      public const string DeleteBidAlternateQuery = @"DELETE FROM bid_alternate
                                                WHERE bid_alternate_id = :bid_alternate_id AND base_bid_yes_no !=1";

      /// <summary>
      /// Query to remove the separatly biddable
      /// </summary>
      public const string RemoveSeparatlyBiddableQuery = @"DELETE FROM bid_alternate_xref 
                                                WHERE bid_alternate_id =:bid_alternate_id AND selected_pricing_parm_id IN :spp_id_list";

      /// <summary>
      /// Query to remove the selection
      /// </summary>
      public const string RemoveSelectionQuery = "DELETE FROM bid_alternate_xref WHERE bid_alternate_id =:bid_alternate_id AND selection_id IN :selection_id_list";

      /// <summary>
      /// Query to get the bid list
      /// </summary>
      public const string GetBidListQuery = @"SELECT DISTINCT b.bid_alternate_id,
                                                              b.current_bid_ind,
                                                              b.bid_name,
                                                              b.descr,
                                                              b.selling_price,
                                                              b.hqtr_bid_alternate_id,
                                                              b.legacy_job_nbr,
                                                              b.base_bid_yes_no,
                                                              j.foe2_created_orders_ind,
                                                              b.include_in_cj
                                              FROM job j
                                              INNER JOIN bid_alternate b ON j.job_id = b.job_id
                                              WHERE b.job_id = :JOB_ID
                                                ORDER  BY b.current_bid_ind DESC, b.bid_name ASC";

      /// <summary>
      /// Query to get the credit job
      /// </summary>
      public const string CreditJobQuery = @"SELECT c.po_nbr             AS PurchaseOrderNumber,
                     c.legacy_job_nbr     AS CreditJobNumber, 
                     c.hqtr_credit_job_id AS HqtrCreditJobId 
              FROM   credit_job c 
              WHERE  c.job_id = :JOB_ID AND c.bid_alternate_id = :BID_ALTERNATE_ID
              AND  (c.po_nbr IS NOT NULL OR c.legacy_job_nbr IS NOT NULL OR c.hqtr_credit_job_id IS NOT NULL)";

      /// <summary>
      /// Query to get the credit job list
      /// </summary>
      public const string CreditJobListQuery = @"SELECT DISTINCT b.bid_alternate_id        AS BidAlternateId, 
                                        b.current_bid_ind         AS CurrentBidInd, 
                                        b.bid_name                AS BidName, 
                                        b.descr                   AS Description, 
                                        b.selling_price           AS SellingPrice,
                                        c.po_nbr                  AS PurchaseOrderNumber,
                                        c.legacy_job_nbr          AS CreditJobNumber, 
                                        c.hqtr_credit_job_id      AS HqtrCreditJobId, 
                                        b.base_bid_yes_no         AS BaseBidYesNo,
                                        b.hqtr_bid_alternate_id   AS HqtrBidAlternateId,
                                        j.foe2_created_orders_ind AS FOE2CreatedOrdersInd 
                        FROM   job j 
                               INNER JOIN bid_alternate b 
                                       ON j.job_id = b.job_id 
                               INNER JOIN credit_job c 
                                      ON b.bid_alternate_id = c.bid_alternate_id 
                        WHERE  b.job_id = :JOB_ID 
                        ORDER  BY b.current_bid_ind DESC, 
                                  b.bid_name ASC";

      /// <summary>
      /// Query to get the current bid indicator
      /// </summary>
      public const string GetBidCurrentIndQuery = @"SELECT current_bid_ind FROM bid_alternate
                                WHERE bid_alternate_id = :bid_alternate_id";

      /// <summary>
      /// Query to get the base bid alternate id
      /// </summary>
      public const string GetBaseBidAlternateIdQuery = @"SELECT bid_alternate_id 
                               FROM   bid_alternate 
                               WHERE  job_id = :JOB_ID 
                               AND base_bid_yes_no = 1 ";

      /// <summary>
      /// Query to get the current bid alternate id
      /// </summary>
      public const string GetCurrentBidAlternateIdQuery = @"SELECT BID_ALTERNATE_ID 
                                                            FROM   BID_ALTERNATE 
                                                            WHERE  JOB_ID = :JOB_ID 
                                                                   AND CURRENT_BID_IND = 'Y'";

      /// <summary>
      /// Query to get the sequence number
      /// </summary>
      public const string GetSequenceNumberQuery = @"select 
                              PKG_SEQUENCE_NUMBER.GET_NEXT_SEQUENCE(: TABLENAME, 1) 
                             from 
                              dual";

      /// <summary>
      /// Query to insert new Bid
      /// </summary>
      public const string CreateBidQuery = @"insert into BID_ALTERNATE(
                      BID_ALTERNATE_ID, JOB_ID, BASE_BID_YES_NO, 
                      BID_NAME, INCLUDE_IN_CJ, DESCR, 
                      CURRENT_BID_IND, SELLING_PRICE
                    ) 
                    values 
                      (
                        : BID_ALTERNATE_ID,                        
                        : JOB_ID, 
                        : BASE_BID_YES_NO, 
                        : BID_NAME, 
                        : INCLUDE_IN_CJ, 
                        : DESCR, 
                        : CURRENT_BID_IND,
                        : SELLING_PRICE
                    )";

      /// <summary>
      /// Query to get the bid name if bid alternate id is zero
      /// </summary>
      public const string ValidateBidNameQueryForInvalidBidAlternateId = @"Select COUNT(*) FROM BID_ALTERNATE Where job_Id = :job_Id and bid_Name = :bid_Name";

      /// <summary>
      /// Query to get the bid name if bid alternate id is non-zero
      /// </summary>
      public const string ValidateBidNameQueryForValidBidAlternateId = @"Select COUNT(*) FROM BID_ALTERNATE Where job_Id = :job_Id and (bid_Name = :bid_Name and bid_Alternate_Id != :bid_Alternate_Id)";

      /// <summary>
      /// Query to update the bid
      /// </summary>
      public const string UpdateBidQuery = @"UPDATE BID_ALTERNATE
                  SET BID_NAME = :BID_NAME, DESCR = :DESCR
                  WHERE BID_ALTERNATE_ID = :BID_ALTERNATE_ID and JOB_ID = :JOB_ID";

      /// <summary>
      /// Query to get the bid selection
      /// </summary>
      public const string GetBidSelectionsQuery = @"SELECT bidxref.BID_ALTERNATE_XREF_ID, 
                                           bidxref.BID_ALTERNATE_ID, 
                                           bidxref.SELECTION_ID, 
                                           bidxref.VARIATION_ID,
                                           bidxref.SELECTED_PRICING_PARM_ID,
                                           bid.BID_NAME
                                    FROM   BID_ALTERNATE_XREF bidxref 
                                           inner join BID_ALTERNATE bid 
                                                   ON bidxref.BID_ALTERNATE_ID = bid.BID_ALTERNATE_ID 
                                    WHERE  ( bid.JOB_ID = :JOB_ID ) 
                                    ORDER  BY bidxref.BID_ALTERNATE_ID ";

      /// <summary>
      /// Query to generate the sequence number
      /// </summary>
      public const string GenerateSequenceNumberQuery = @"SELECT 
                          PKG_SEQUENCE_NUMBER.GET_NEXT_SEQUENCE(: TABLENAME, : HOWMANYTORESERVE) 
                        FROM 
                          dual
                        ";

      /// <summary>
      /// Query to get the Db date
      /// </summary>
      public const string GetDbDateQuery = @"SELECT f_dbdate() 
                              FROM   dual";

      /// <summary>
      /// Query to insert the selection
      /// </summary>
      public const string InsertSelectionsQuery = @"INSERT INTO bid_alternate_xref 
                                    (
                                                bid_alternate_xref_id,
                                                bid_alternate_id,
                                                variation_id,
                                                selection_id,
                                                selected_pricing_parm_id
                                    )
                                    VALUES
                                    ( 
                                                : BID_ALTERNATE_XREF_ID,
                                                : BID_ALTERNATE_ID,
                                                : VARIATION_ID,
                                                : SELECTION_ID,
                                                : SELECTED_PRICING_PARM_ID
                                    )";

      /// <summary>
      /// Query to remove the variation
      /// </summary>
      private const string RemoveVariationQuery = "DELETE FROM BID_ALTERNATE_XREF WHERE VARIATION_ID IN :VARIATION_ID_LIST";

      /// <summary>
      /// Gets query to get the a bid by bid alternate id
      /// </summary>
      public static string GetBidQuery
      {
         get
         {
            return $@"{BidSelect} WHERE j.job_id = :JOB_ID AND b.bid_alternate_id = :BID_ALTERNATE_ID";
         }
      }

      /// <summary>
      /// Gets the bid list query
      /// </summary>
      public static string GetBidListSearch
      {
         get
         {
            return $@"{BidSelect} 
            WHERE (:CurrentBidInd is NULL OR b.current_bid_ind = :CurrentBidInd)                     
               OR (:BidName is NULL OR b.bid_name = :BidName)
               OR (:Description is NULL OR b.descr = :Description)                  
               OR (:SellingPrice is NULL OR b.selling_price = :SellingPrice)
               OR (:HqtrBidAlternateId is NULL OR b.hqtr_bid_alternate_id = :HqtrBidAlternateId)
               OR (:CreditJobNumber is NULL OR b.legacy_job_nbr = :CreditJobNumber)
               OR (:BaseBidYesNo is NULL OR b.base_bid_yes_no = :BaseBidYesNo)
               OR (:FOE2CreatedOrdersInd is NULL OR j.foe2_created_orders_ind = :FOE2CreatedOrdersInd)";
         }
      }

      private static string BidSelect
      {
         get
         {
            return @"SELECT 
                  b.bid_alternate_id        AS BidAlternateId, 
                  b.current_bid_ind         AS CurrentBidInd, 
                  b.bid_name                AS BidName, 
                  b.descr                   AS Description, 
                  b.selling_price           AS SellingPrice,
                  b.hqtr_bid_alternate_id   AS HqtrBidAlternateId,
                  b.legacy_job_nbr          AS CreditJobNumber, 
                  b.base_bid_yes_no         AS BaseBidYesNo, 
                  b.legacy_job_nbr          AS LegacyJobNumber,
                  j.foe2_created_orders_ind AS FOE2CreatedOrdersInd
               FROM   job j 
               JOIN   bid_alternate b ON j.job_id = b.job_id and j.dr_address_id = b.dr_address_id";
         }
      }

      /// <summary>
      /// Retrieve the query based on bidalternate id
      /// If bidalternate id greater than zero , delete the variations of the specific bid
      /// else delete the variation of the bids
      /// </summary>
      /// <param name="bidAlternateId">bidAlternateId</param>
      /// <returns>Query string</returns>
      public static string DeleteVariation(int bidAlternateId)
      {
         var query = new StringBuilder();
         query.Append(RemoveVariationQuery);
         if (bidAlternateId > 0)
         {
            query.Append(
                $" AND BID_ALTERNATE_ID =:BID_ALTERNATE_ID");
         }

         return query.ToString();
      }
   }
}
