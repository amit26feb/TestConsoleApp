// <copyright file="LoggerExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace BidService.Common.Middlewares
{
    using Microsoft.AspNetCore.Builder;

    /// <summary>
    /// LoggerExtensions
    /// </summary>
    public static class LoggerExtensions
    {
        /// <summary>
        /// IApplicationBuilder
        /// </summary>
        /// <param name="builder">builder</param>
        /// <returns>LoggerMiddleware</returns>
        public static IApplicationBuilder UseLogger(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<LoggerMiddleware>();
        }
    }
}
