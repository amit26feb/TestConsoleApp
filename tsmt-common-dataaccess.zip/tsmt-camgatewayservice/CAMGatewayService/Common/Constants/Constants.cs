// <copyright file="Constants.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Common.Constants
{
    /// <summary>
    /// Constants
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Conditions
        /// </summary>
        public const string Conditions = "Conditions";

        /// <summary>
        /// Contexts
        /// </summary>
        public const string Contexts = "Contexts";

        /// <summary>
        /// Conditions file
        /// </summary>
        public const string ConditionsFile = "ConditionsFile";

        /// <summary>
        /// Contexts file
        /// </summary>
        public const string ContextsFile = "ContextsFile";

        /// <summary>
        /// Cam data not available error
        /// </summary>
        public const string CamDataNotAvailable = "CamLock info is not loaded for the request";

        /// <summary>
        /// Lock failed
        /// </summary>
        public const string LockFailed = "Failure while issuing lock";

        /// <summary>
        /// Invalid request
        /// </summary>
        public const string InvalidRequest = "Invalid request, please check the request parameter";

        /// <summary>
        /// Context not implemented message
        /// </summary>
        public const string ContextNotImplemented = "Context not implemented";

        /// <summary>
        /// Condition not implemented message
        /// </summary>
        public const string ConditionNotImplemented = "Condition not implemented";

        /// <summary>
        /// Lock type not implemented message
        /// </summary>
        public const string LockTypeNotImplemented = "Lock type not implemented";

        /// <summary>
        /// Error message for apply lock
        /// </summary>
        public const string CheckAndApplyLockError = "Error while checking and applying locks";

        /// <summary>
        /// Retry attempt count for sns
        /// </summary>
        public const int RetryAttemptCount = 3;
    }
}
