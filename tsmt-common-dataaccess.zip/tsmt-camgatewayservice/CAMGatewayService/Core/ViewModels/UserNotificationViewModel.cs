// <copyright file="UserNotificationViewModel.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.ViewModels
{
    using System;

    /// <summary>
    /// User notification view
    /// </summary>
    public class UserNotificationViewModel
    {
        /// <summary>
        /// Gets or sets message id
        /// </summary>
        public string MessageId { get; set; }

        /// <summary>
        /// Gets or sets user id
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets application
        /// </summary>
        public string Application { get; set; }

        /// <summary>
        /// Gets or sets created date
        /// </summary>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets long message
        /// </summary>
        public string LongMessage { get; set; }

        /// <summary>
        /// Gets or sets short message
        /// </summary>
        public string ShortMessage { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether notification was read or not
        /// </summary>
        public bool IsNotificationRead { get; set; }

        /// <summary>
        /// Gets or sets redirect url or download url
        /// </summary>
        public string UrlPath { get; set; }

        /// <summary>
        /// Gets or sets url type either redirect or download or message
        /// </summary>
        public string UrlType { get; set; }

        /// <summary>
        /// Gets or sets updated date
        /// </summary>
        public DateTime UpdatedDate { get; set; }
    }
}
