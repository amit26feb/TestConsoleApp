// <copyright file="IDocumentDbRepository.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Interface for DocumentDbRepository
    /// </summary>
    public interface IDocumentDbRepository
    {
        /// <summary>
        /// Get the context info based on the given context name
        /// </summary>
        /// <param name="context">Context</param>
        /// <returns>Context info</returns>
        Task<AccessContext> GetContext(string context);

        /// <summary>
        /// Get conditions based on the context
        /// </summary>
        /// <param name="context">context</param>
        /// <returns>Conditions</returns>
        Task<IEnumerable<ContextCondition>> GetConditions(string context);
    }
}
