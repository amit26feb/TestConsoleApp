// <copyright file="DocumentDbRepository.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CAMGatewayService.Common.Constants;
    using CAMGatewayService.Configurations;
    using DocumentDBWrapper;
    using Microsoft.Extensions.Caching.Memory;
    using Microsoft.Extensions.Options;
    using MongoDB.Driver;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Repository to get context and conditions for cam lock check
    /// </summary>
    public class DocumentDbRepository : IDocumentDbRepository
    {
        private readonly IDocumentDBCollection<AccessContext> documentDBContextCollection;
        private readonly IDocumentDBCollection<ContextCondition> documentDBContextConditionCollection;
        private readonly IMemoryCache cache;

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentDbRepository"/> class.
        /// </summary>
        /// <param name="documentDBConnectionFactory">Document database connection factory.</param>
        /// <param name="serviceSettings">Service configuration settings.</param>
        /// <param name="cache">cache</param>
        public DocumentDbRepository(
            IDocumentDBConnectionFactory documentDBConnectionFactory,
            IOptions<ServiceSettings> serviceSettings,
            IMemoryCache cache)
        {
            this.documentDBContextCollection = documentDBConnectionFactory.GetCollection<AccessContext>(serviceSettings.Value.DocumentDBContextCollectionName);
            this.documentDBContextConditionCollection = documentDBConnectionFactory.GetCollection<ContextCondition>(serviceSettings.Value.DocumentDBContextConditionCollectionName);
            this.cache = cache;
        }

        /// <summary>
        /// Get the context info based on the given context name
        /// </summary>
        /// <param name="context">Context</param>
        /// <returns>Context info</returns>
        public async Task<AccessContext> GetContext(string context)
        {
            return (await this.GetAllContexts()).FirstOrDefault(x => x.Context == context);
        }

        /// <summary>
        /// Get conditions based on the context
        /// </summary>
        /// <param name="context">context</param>
        /// <returns>Conditions</returns>
        public async Task<IEnumerable<ContextCondition>> GetConditions(string context)
        {
            return (await this.GetAllConditions()).Where(x => x.Context == context);
        }

        private async Task<IEnumerable<AccessContext>> GetAllContexts()
        {
            IEnumerable<AccessContext> contexts = this.cache.Get<List<AccessContext>>(Constants.Contexts);

            if (contexts == null)
            {
                var entryOptions = new MemoryCacheEntryOptions().SetPriority(CacheItemPriority.NeverRemove);
                FilterDefinition<AccessContext> filterDefinition = Builders<AccessContext>.Filter.Empty;
                contexts = await this.documentDBContextCollection.FindAsync(filterDefinition);
                this.cache.Set(Constants.Contexts, contexts, entryOptions);
            }

            return contexts;
        }

        private async Task<IEnumerable<ContextCondition>> GetAllConditions()
        {
            IEnumerable<ContextCondition> contextCondtions = this.cache.Get<List<ContextCondition>>(Constants.Conditions);

            if (contextCondtions == null)
            {
                var entryOptions = new MemoryCacheEntryOptions().SetPriority(CacheItemPriority.NeverRemove);
                FilterDefinition<ContextCondition> filterDefinition = Builders<ContextCondition>.Filter.Empty;
                contextCondtions = await this.documentDBContextConditionCollection.FindAsync(filterDefinition);
                this.cache.Set(Constants.Conditions, contextCondtions, entryOptions);
            }

            return contextCondtions;
        }
    }
}
