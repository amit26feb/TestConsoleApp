// <copyright file="CheckAndApplyLocksCommandHandler.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.CommandHandlers
{
    using System.Threading;
    using System.Threading.Tasks;
    using CAMGatewayService.Core.Commands;
    using CAMGatewayService.Core.Services;
    using MediatR;
    using TSMT.CAMContext.Conditions.Core.Model;

    /// <summary>
    /// Command Handler for checking and applying lock
    /// </summary>
    public class CheckAndApplyLocksCommandHandler : IRequestHandler<CheckAndApplyLocksCommand, ExecutionStatus>
    {
        private readonly ICamService camService;

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckAndApplyLocksCommandHandler"/> class.
        /// </summary>
        /// <param name="camService">Cam service</param>
        public CheckAndApplyLocksCommandHandler(ICamService camService)
        {
            this.camService = camService;
        }

        /// <summary>
        /// Processes the command to check and apply the lock
        /// </summary>
        /// <param name="request">Check and apply lock command</param>
        /// <param name="cancellationToken">Notification that operations should be canceled</param>
        /// <returns>Execution status</returns>
        public async Task<ExecutionStatus> Handle(CheckAndApplyLocksCommand request, CancellationToken cancellationToken)
        {
            return await this.camService.CheckAndApplyLocks(request.CamInput, request.IsLockRequired);
        }
    }
}
