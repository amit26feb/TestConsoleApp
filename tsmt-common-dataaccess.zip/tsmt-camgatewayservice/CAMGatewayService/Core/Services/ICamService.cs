// <copyright file="ICamService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Core.Model;

    /// <summary>
    /// Cam service interface
    /// </summary>
    public interface ICamService
    {
        /// <summary>
        /// Check lock status and apply lock if available context is available to lock
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <param name="isLockRequired">Indicate whether the lock needs to executed</param>
        /// <returns>Lock status of the context</returns>
        Task<ExecutionStatus> CheckAndApplyLocks(CamInput camInput, bool isLockRequired);
    }
}
