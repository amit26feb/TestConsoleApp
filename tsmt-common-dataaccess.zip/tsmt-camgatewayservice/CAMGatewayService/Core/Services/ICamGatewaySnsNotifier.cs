// <copyright file="ICamGatewaySnsNotifier.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Services
{
    using System.Threading.Tasks;

    /// <summary>
    /// Camgateway SNS notifier
    /// </summary>
    public interface ICamGatewaySnsNotifier
    {
        /// <summary>
        /// Request message will be sent to sqs via sns.
        /// </summary>
        /// <param name="message">Message to be sent</param>
        /// <param name="snsArn">Sns service url to connect sqs via sns</param>
        /// <returns>Message id from sns</returns>
        Task<string> SendMessageToSNS(string message, string snsArn);
    }
}
