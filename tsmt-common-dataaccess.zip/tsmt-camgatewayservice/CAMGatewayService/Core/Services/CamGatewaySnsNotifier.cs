// <copyright file="CamGatewaySnsNotifier.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Services
{
    using System.Threading.Tasks;
    using AWS.MessagingWrapper.Contracts;
    using CAMGatewayService.Common.Constants;

    /// <summary>
    /// Camgateway SNS notifier
    /// </summary>
    public class CamGatewaySnsNotifier : ICamGatewaySnsNotifier
    {
        private readonly IMessagePublisher snsPublisher;

        /// <summary>
        /// Initializes a new instance of the <see cref="CamGatewaySnsNotifier"/> class.
        /// </summary>
        /// <param name="snsPublisher">Interaction with AWS SNS</param>
        public CamGatewaySnsNotifier(IMessagePublisher snsPublisher)
        {
            this.snsPublisher = snsPublisher;
        }

        /// <summary>
        /// Request message will be sent to sqs via sns.
        /// </summary>
        /// <param name="message">Message to be sent</param>
        /// <param name="snsArn">Sns service url to connect sqs via sns</param>
        /// <returns>Message id from sns</returns>
        public async Task<string> SendMessageToSNS(string message, string snsArn)
        {
            return await this.snsPublisher.PublishToTopicAsync(message, snsArn, Constants.RetryAttemptCount);
        }
    }
}
