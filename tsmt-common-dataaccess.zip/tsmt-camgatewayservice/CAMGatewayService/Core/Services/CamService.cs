// <copyright file="CamService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CAMGatewayService.Core.Repository;
    using CAMGatewayService.Core.ViewModels;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using TSMT.CAMContext.Conditions.Common.Constants;
    using TSMT.CAMContext.Conditions.Common.Enumerator;
    using TSMT.CAMContext.Conditions.Core.Model;
    using TSMT.Settings;

    /// <summary>
    /// Class contains the methods to check lock status and apply if required
    /// </summary>
    public class CamService : ICamService
    {
        private readonly IContextFactory contextFactory;
        private readonly IActionFactory actionFactory;
        private readonly IDocumentDbRepository documentDbRepository;
        private readonly ILogger<CamService> logger;
        private readonly ICamGatewaySnsNotifier camGatewaySnsNotifier;
        private readonly IOptions<TSMTSettings> tsmtSettings;
        private string userId;

        /// <summary>
        /// Initializes a new instance of the <see cref="CamService"/> class.
        /// </summary>
        /// <param name="contextFactory">Context factory</param>
        /// <param name="actionFactory">Action factory</param>
        /// <param name="documentDbRepository">Document db repository</param>
        /// <param name="logger">Logger of errors</param>
        /// <param name="camGatewaySnsNotifier">Camgateway SNS notifier</param>
        /// <param name="tsmtSettings">TSMT Settings</param>
        public CamService(
            IContextFactory contextFactory,
            IActionFactory actionFactory,
            IDocumentDbRepository documentDbRepository,
            ILogger<CamService> logger,
            ICamGatewaySnsNotifier camGatewaySnsNotifier,
            IOptions<TSMTSettings> tsmtSettings)
        {
            this.contextFactory = contextFactory;
            this.actionFactory = actionFactory;
            this.documentDbRepository = documentDbRepository;
            this.logger = logger;
            this.camGatewaySnsNotifier = camGatewaySnsNotifier;
            this.tsmtSettings = tsmtSettings;
        }

        /// <summary>
        /// Check lock status and apply lock if available context is available to lock
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <param name="isLockRequired">Indicate whether the lock needs to executed</param>
        /// <returns>Lock status of the context</returns>
        public async Task<ExecutionStatus> CheckAndApplyLocks(CamInput camInput, bool isLockRequired)
        {
            // Get context details
            this.userId = camInput.UserId;
            AccessContext accessContext = await this.documentDbRepository.GetContext(camInput.Context);
            IEnumerable<ContextCondition> contextConditions = await this.documentDbRepository.GetConditions(camInput.Context);
            ExecutionStatus executionStatus = await this.Validate(accessContext, contextConditions);

            if (executionStatus.Status == Status.DENY)
            {
                return executionStatus;
            }

            IContext context = this.contextFactory.GetContextInstance((Context)Enum.Parse(typeof(Context), accessContext.AccessFeasibilityCheckerComponent));

            try
            {
                await context.GetEnrichedCamInputData(contextConditions, camInput);

                // Get camlock info
                CamData camData = await context.GetCamData(contextConditions, camInput);

                if (camData != null)
                {
                    // Get unique priorities
                    IEnumerable<int> priorities = await context.GetPriorities(contextConditions);

                    // Execute conditions by priority
                    foreach (int priority in priorities.ToList())
                    {
                        ExecutionStatus executionStatusByPriority = await context
                            .ExecuteConditions(contextConditions.Where(y => y.Priority == priority), camData);

                        // Exit condition processing if Deny
                        if (executionStatusByPriority.Status == Status.DENY)
                        {
                            return await this.FormExecutionResponse(accessContext, Status.DENY, executionStatusByPriority.Messages);
                        }
                    }

                    if (isLockRequired)
                    {
                        LockStatus lockStatus = await this.actionFactory
                            .GetActionInstance((ActionType)Enum.Parse(typeof(ActionType), accessContext.ActionComponent))
                            .ExecuteAction(camData);

                        if (!lockStatus.IsSuccessful)
                        {
                            return await this.FormExecutionResponse(accessContext, Status.DENY, lockStatus.Messages);
                        }
                    }
                }
                else
                {
                    this.logger.LogInformation($"{Constants.CamDataNotAvailable} {JsonConvert.SerializeObject(camInput)}");
                    return await this.FormExecutionResponse(accessContext, Status.DENY, new List<string>() { Common.Constants.Constants.CamDataNotAvailable });
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError($"An error occurred while executing the cam gateway status for context {accessContext.Context}: ", ex.ToString());
                return await this.FormExecutionResponse(accessContext, Status.DENY, new List<string>() { Common.Constants.Constants.CheckAndApplyLockError });
            }

            return await this.FormExecutionResponse(accessContext, Status.ALLOW, new List<string>());
        }

        private async Task<ExecutionStatus> Validate(AccessContext accessContext, IEnumerable<ContextCondition> contextConditions)
        {
            IEnumerable<string> errorMessages = new List<string>();
            if (!Enum.IsDefined(typeof(Context), accessContext.AccessFeasibilityCheckerComponent))
            {
                errorMessages = errorMessages.Concat(new[] { $"{Common.Constants.Constants.ContextNotImplemented} - {accessContext.AccessFeasibilityCheckerComponent}" });
            }

            if (accessContext.ActionComponent != null && !Enum.IsDefined(typeof(ActionType), accessContext.ActionComponent))
            {
                errorMessages = errorMessages.Concat(new[] { $"{Common.Constants.Constants.LockTypeNotImplemented} - {accessContext.ActionComponent}" });
            }

            foreach (ContextCondition contextCondition in contextConditions)
            {
                if (!Enum.IsDefined(typeof(Condition), contextCondition.ConditionCheckerComponent))
                {
                    errorMessages = errorMessages.Concat(new[] { $"{Common.Constants.Constants.ConditionNotImplemented} - {contextCondition.ConditionCheckerComponent}" });
                }
            }

            if (errorMessages.Any())
            {
                return await this.FormExecutionResponse(accessContext, Status.DENY, errorMessages);
            }

            return await this.FormExecutionResponse(accessContext, Status.ALLOW, new List<string>());
        }

        /// <summary>
        /// Form execution status response based on the status
        /// </summary>
        /// <param name="accessContext">Access context</param>
        /// <param name="status">Status allow/deny</param>
        /// <param name="errorMessages">Error messages</param>
        /// <returns>Execution status</returns>
        private async Task<ExecutionStatus> FormExecutionResponse(AccessContext accessContext, Status status, IEnumerable<string> errorMessages)
        {
            bool isNotificationRequired = !string.IsNullOrWhiteSpace(accessContext.NotificationHeaderMessage) && !string.IsNullOrWhiteSpace(accessContext.ToasterMessage);
            if (isNotificationRequired && status == Status.DENY)
            {
                string messages = accessContext.NotificationHeaderMessage + " " + string.Join(", ", errorMessages);
                await this.SendNotificationMessage(messages, accessContext.Context);
                errorMessages = new List<string>();
            }

            return new ExecutionStatus
            {
                Status = status,
                Messages = isNotificationRequired && status == Status.DENY ? new List<string> { accessContext.ToasterMessage } : errorMessages,
            };
        }

        /// <summary>
        /// Send notification message to sns
        /// </summary>
        /// <param name="message">Message</param>
        /// <param name="context">Context</param>
        /// <returns>Notification message</returns>
        private async Task SendNotificationMessage(string message, string context)
        {
            try
            {
                UserNotificationViewModel userNotification = new UserNotificationViewModel()
                {
                    MessageId = Guid.NewGuid().ToString(),
                    UserId = this.userId,
                    CreatedDate = DateTime.UtcNow,
                    LongMessage = message,
                    ShortMessage = "Failure",
                    IsNotificationRead = false,
                    Application = "SalesWeb",
                    UrlPath = string.Empty,
                    UrlType = "Message",
                    UpdatedDate = DateTime.UtcNow
                };
                string serializedUserNotificationMessage = JsonConvert.SerializeObject(userNotification);
                await this.camGatewaySnsNotifier.SendMessageToSNS(serializedUserNotificationMessage, this.tsmtSettings.Value.SnsServiceUrlForNotifications);
            }
            catch (Exception)
            {
                this.logger.LogInformation($"Exception occured while sending notification message to SQS for the context: {context}");
            }
        }
    }
}
