// <copyright file="CheckAndApplyLocksCommandValidator.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Validators
{
    using CAMGatewayService.Core.Commands;
    using FluentValidation;

    /// <summary>
    /// Validates fields that are required for checking and applying lock
    /// </summary>
    public class CheckAndApplyLocksCommandValidator : AbstractValidator<CheckAndApplyLocksCommand>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckAndApplyLocksCommandValidator"/> class.
        /// </summary>
        public CheckAndApplyLocksCommandValidator()
        {
            this.RuleFor(command => command.CamInput.Context).NotEmpty().WithMessage("Context cannot be empty");
            this.RuleFor(command => command.CamInput.DrAddressId).GreaterThan(0).WithMessage("Dr Address Id must be greater than 0");
            this.RuleFor(command => command.CamInput.UserId).NotEmpty().WithMessage("User Id cannot be empty");
        }
    }
}
