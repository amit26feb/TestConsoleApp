// <copyright file="CheckAndApplyLocksCommand.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Core.Commands
{
    using System.Runtime.Serialization;
    using MediatR;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Core.Model;

    /// <summary>
    /// Command to check and apply lock
    /// </summary>
    [DataContract]
    public class CheckAndApplyLocksCommand : IRequest<ExecutionStatus>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckAndApplyLocksCommand"/> class.
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <param name="isLockRequired">Is lock required flag</param>
        public CheckAndApplyLocksCommand(CamInput camInput, bool isLockRequired)
        {
            this.CamInput = camInput;
            this.IsLockRequired = isLockRequired;
        }

        /// <summary>
        /// Gets or sets cam input
        /// </summary>
        [DataMember]
        public CamInput CamInput { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the lock should be applied or not
        /// </summary>
        [DataMember]
        public bool IsLockRequired { get; set; }
    }
}
