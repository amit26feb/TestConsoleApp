// <copyright file="ConfigParameterConstants.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Configurations
{
    /// <summary>
    /// A class for configuration parameter constants
    /// </summary>
    public class ConfigParameterConstants
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigParameterConstants"/> class.
        /// </summary>
        protected ConfigParameterConstants()
        {
        }

        /// <summary>
        /// Gets InfluxDb Parameter name
        /// </summary>
        public static string InfluxDb => "tsmt-influxdb-db";

        /// <summary>
        /// Gets InfluxDb Url Parameter name
        /// </summary>
        public static string InfluxDbUrl => "tsmt-influxdb-url";

        /// <summary>
        /// Gets InfluxDb UserName Parameter name
        /// </summary>
        public static string InfluxDbUserName => "tsmt-influxdb-user";

        /// <summary>
        /// Gets InfluxDb Password Parameter name
        /// </summary>
        public static string InfluxDbPassword => "tsmt-influxdb-password";

        /// <summary>
        /// Gets okta client id.
        /// </summary>
        public static string OktaClientIdForMicroServiceAccess => "tsmt-okta-clientid-Microservice-access";

        /// <summary>
        /// Gets okta client secret key.
        /// </summary>
        public static string OktaClientSecretKeyForMicroServiceAccess => "tsmt-okta-clientsecret-MicroService-access";

        /// <summary>
        /// Gets DocDb Connection String Parameter name
        /// </summary>
        public static string DocDbConnectionString => "tsmt-docdb-CAMGatewayService";
    }
}
