// <copyright file="ServiceSettings.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Configurations
{
    /// <summary>
    /// ServiceSettings. The Property names to be used in cam gateway service.
    /// </summary>
    public class ServiceSettings
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceSettings"/> class.
        /// Config parameter constants
        /// </summary>
        public ServiceSettings()
        {
        }

        /// <summary>
        /// Gets or sets document db collection name for contexts
        /// </summary>
        public string DocumentDBContextCollectionName { get; set; }

        /// <summary>
        /// Gets or sets document db collection name for context conditions
        /// </summary>
        public string DocumentDBContextConditionCollectionName { get; set; }
    }
}
