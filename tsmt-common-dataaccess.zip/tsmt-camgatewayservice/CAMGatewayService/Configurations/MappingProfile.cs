// <copyright file="MappingProfile.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Configurations
{
    /// <summary>
    /// A profile for configuring object mapping
    /// </summary>
    public class MappingProfile : AutoMapper.Profile
    {
    }
}
