// <copyright file="Program.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService
{
    using System.IO;
    using CAMGatewayService.Configurations;
    using Microsoft.AspNetCore;
    using Microsoft.AspNetCore.Hosting;
    using NLog.Web;
    using TSMT.Settings;

    /// <summary>
    /// Program
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args">args</param>
        public static void Main(string[] args)
        {
            BuildWebHost(args).Build().Run();
        }

        /// <summary>
        /// BuildWebHost
        /// </summary>
        /// <param name="args">args</param>
        /// <returns>WebHost</returns>
        public static IWebHostBuilder BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .ConfigureAppConfiguration((builderContext, configBuilder) =>
                {
                    var environment = builderContext.HostingEnvironment.EnvironmentName;
                    var awsRegion = configBuilder.Build()["AWSRegion"].ToString();
                    configBuilder.Add(new TsmtConfigurationSource<ConfigParameterConstants>(environment, awsRegion));
                })
                .UseNLog();
    }
}