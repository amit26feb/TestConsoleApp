// <copyright file="CamGatewayController.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Controllers
{
    using System.Collections.Generic;
    using System.Net;
    using System.Threading.Tasks;
    using CAMGatewayService.Common.Constants;
    using CAMGatewayService.Core.Commands;
    using CrossCuttingServices.Common.Exceptions;
    using MediatR;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Core.Model;

    /// <summary>
    /// Cam GateWay Controller
    /// </summary>
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Authorize]
    public class CamGatewayController : Controller
    {
        private readonly ILogger<CamGatewayController> logger;
        private readonly IMediator mediator;

        /// <summary>
        /// Initializes a new instance of the <see cref="CamGatewayController"/> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mediator">Mediator</param>
        public CamGatewayController(ILogger<CamGatewayController> logger, IMediator mediator)
        {
            this.logger = logger;
            this.mediator = mediator;
        }

        /// <summary>
        /// Return ok Status
        /// </summary>
        /// <returns>Status</returns>
        [Route("Status")]
        [HttpGet]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        public IActionResult Status()
        {
            return (IActionResult)this.Ok();
        }

        /// <summary>
        /// Check the contexts and conditions
        /// </summary>
        /// <param name="camInput">The request with cam input</param>
        /// <returns>Execution status</returns>
        [Route("Check")]
        [HttpPost]
        [ProducesResponseType(typeof(ExecutionStatus), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> CheckCam([FromBody] CamInput camInput)
        {
            if (camInput != null && this.ModelState.IsValid)
            {
                CheckAndApplyLocksCommand command = new CheckAndApplyLocksCommand(camInput, false);
                ExecutionStatus commandResult = await this.mediator.Send(command);
                return this.Ok(commandResult);
            }

            string message = Constants.InvalidRequest;
            this.logger.LogTrace(message);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { message }));
        }

        /// <summary>
        /// Check and apply cam locks
        /// </summary>
        /// <param name="camInput">The request with cam input</param>
        /// <returns>Lock execution status</returns>
        [Route("Locks")]
        [HttpPost]
        [ProducesResponseType(typeof(ExecutionStatus), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> CheckAndApplyLocks([FromBody] CamInput camInput)
        {
            if (camInput != null && this.ModelState.IsValid)
            {
                CheckAndApplyLocksCommand command = new CheckAndApplyLocksCommand(camInput, true);
                ExecutionStatus commandResult = await this.mediator.Send(command);
                return this.Ok(commandResult);
            }

            string message = Constants.InvalidRequest;
            this.logger.LogTrace(message);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { message }));
        }
    }
}
