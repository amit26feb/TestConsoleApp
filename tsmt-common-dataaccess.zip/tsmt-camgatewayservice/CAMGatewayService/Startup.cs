// <copyright file="Startup.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService
{
    using System;
    using System.IO;
    using System.Reflection;
    using System.Text.Json.Serialization;
    using App.Metrics;
    using Autofac;
    using Autofac.Extensions.DependencyInjection;
    using AutoMapper;
    using CAMGatewayService.Configurations;
    using CrossCuttingServices.Common.Exceptions;
    using CrossCuttingServices.Common.Filters;
    using CrossCuttingServices.Common.Middlewares;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Authorization;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.OpenApi.Models;
    using NLog.Web;
    using Okta.AspNetCore;
    using TSMT.Settings;

    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup"/> class.
        /// </summary>
        /// <param name="configuration">Configuration</param>
        /// <param name="environment">Environment</param>
        public Startup(IConfiguration configuration, IWebHostEnvironment environment)
        {
            this.Configuration = configuration;
            this.HostingEnvironment = environment;
            if (this.HostingEnvironment != null
               && !string.IsNullOrEmpty(this.HostingEnvironment.EnvironmentName)
               && !this.HostingEnvironment.EnvironmentName.Contains("UnitTest", StringComparison.Ordinal))
            {
                NLogBuilder.ConfigureNLog($"nlog.{environment.EnvironmentName}.config");
                this.RepositoryTag = Environment.GetEnvironmentVariable("REPOSITORY_TAG");
                if (string.IsNullOrWhiteSpace(this.RepositoryTag))
                {
                    this.RepositoryTag = "localhost";
                }
            }
        }

        /// <summary>
        /// Gets or sets application title
        /// </summary>
        public string ApplicationTitle { get; set; }

        /// <summary>
        /// Gets or sets repository tag
        /// </summary>
        public string RepositoryTag { get; set; }

        /// <summary>
        /// Gets configuration.
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// Gets the hosting environment
        /// </summary>
        public IWebHostEnvironment HostingEnvironment { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="IServiceProvider"/> class.
        /// </summary>
        /// <param name="services">IServiceCollection.</param>
        /// <returns>AutofacServiceProvider.</returns>
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            this.ApplicationTitle = this.Configuration["Title"];
            string termsOfService = "https://www.trane.com/content/dam/Trane/Commercial/global/terms-and-conditions-of-use.pdf";
            var metrics = AppMetrics.CreateDefaultBuilder()

             .Configuration.Configure(
               options =>
               {
                   options.AddEnvTag(this.HostingEnvironment.EnvironmentName);
               })
                 .Report.ToInfluxDb(options =>
                 {
                     options.InfluxDb.BaseUri = new Uri(this.Configuration["InfluxDbUrl"]);
                     options.InfluxDb.Database = this.Configuration["InfluxDb"];
                     options.InfluxDb.UserName = this.Configuration["InfluxDbUserName"];
                     options.InfluxDb.Password = this.Configuration["InfluxDbPassword"];
                     options.InfluxDb.CreateDataBaseIfNotExists = true;
                 }).Build();
            services.AddMetrics(metrics);
            services.AddMetricsReportingHostedService();
            services.AddMetricsEndpoints();
            services.AddMetricsTrackingMiddleware();
            services.Configure<TSMTSettings>(this.Configuration);

            services.AddMvc(options =>
            {
                AuthorizationPolicy policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser().Build();
                options.Filters.Add(new AuthorizeFilter(policy));
                options.Filters.Add(typeof(HttpGlobalExceptionFilter<DomainException>));
            }).AddControllersAsServices().AddMetrics().AddJsonOptions(options => options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

            services.AddApiVersioning();

            services.AddSwaggerGen(options =>
            {
                OpenApiInfo apiInfo = new OpenApiInfo
                {
                    Title = $"{this.ApplicationTitle} HTTP API ({this.RepositoryTag})",
                    Version = "v1",
                    Description = $"The {this.ApplicationTitle} HTTP API.",
                    TermsOfService = new Uri(termsOfService)
                };
                options.SwaggerDoc("v1", apiInfo);

                var apiKeyScheme = new OpenApiSecurityScheme()
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT"
                };
                options.AddSecurityDefinition("Bearer", apiKeyScheme);

                var apiSecurityRequirement = new OpenApiSecurityRequirement()
                {
                   {
                      new OpenApiSecurityScheme
                      {
                         Reference = new OpenApiReference
                         {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer",
                         },
                         Scheme = "OAuth2",
                         Name = "Bearer",
                         In = ParameterLocation.Header
                      }, new string[0]
                   }
                };
                options.AddSecurityRequirement(apiSecurityRequirement);

                var xmlFile = $"{Assembly.GetEntryAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

                if (File.Exists(xmlFile))
                {
                    options.IncludeXmlComments(xmlPath);
                }
            });

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = OktaDefaults.ApiAuthenticationScheme;
                options.DefaultChallengeScheme = OktaDefaults.ApiAuthenticationScheme;
                options.DefaultSignInScheme = OktaDefaults.ApiAuthenticationScheme;
            })
                .AddOktaWebApi(new OktaWebApiOptions
                {
                    OktaDomain = this.Configuration["OktaDomain"],
                    AuthorizationServerId = this.Configuration["OktaAuthorizationServerID"]
                });

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });
            services.AddHealthChecks();
            services.AddApiVersioning();
            services.AddOptions();
            services.AddHttpClient();

            services.AddAutoMapper(typeof(MappingProfile));
            services.AddMemoryCache();
            services.Configure<ServiceSettings>(this.Configuration);
            var autofacContainer = new ContainerBuilder();
            autofacContainer.Populate(services);
            autofacContainer.RegisterModule(new InjectionModule(this.Configuration));
            return new AutofacServiceProvider(autofacContainer.Build());
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="application">Application builder</param>
        /// <param name="environment">Hosting environment</param>
        public void Configure(IApplicationBuilder application, IWebHostEnvironment environment)
        {
            string pathBase = this.Configuration["PATH_BASE"];
            if (!string.IsNullOrEmpty(pathBase))
            {
                application.UsePathBase(pathBase);
            }

            application.UseCors("CorsPolicy");
            application.UseMiddleware<LoggerMiddleware>();
            application.UseRouting();
            application.UseAuthentication();
            application.UseAuthorization();

#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
            application.Map("/liveness", lapp => lapp.Run(async ctx => ctx.Response.StatusCode = 200));
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously

            application.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            application.UseSwagger()
               .UseSwaggerUI(c =>
               {
                   c.SwaggerEndpoint($"{pathBase}/swagger/v1/swagger.json", $"{this.ApplicationTitle}.API V1");
               });
        }
    }
}
