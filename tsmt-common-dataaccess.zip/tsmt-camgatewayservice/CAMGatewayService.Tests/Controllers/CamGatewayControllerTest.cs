// <copyright file="CamGatewayControllerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Controllers
{
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using CAMGatewayService.Controllers;
    using CAMGatewayService.Core.Commands;
    using CAMGatewayService.Core.Services;
    using CAMGatewayService.Tests.Common;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Common.Constants;
    using TSMT.CAMContext.Conditions.Core.Model;
    using Xunit;

    public class CamGatewayControllerTest
    {
        private readonly CamGatewayController controller;
        private readonly Mock<ILogger<CamGatewayController>> loggerMock;
        private readonly Mock<IMediator> mediatorMock;
        private CamInput validRequest;
        private CamInput invalidRequest;

        /// <summary>
        /// Initializes a new instance of the <see cref="CamGatewayControllerTest"/> class.
        /// Cam gateway Controller test
        /// </summary>
        public CamGatewayControllerTest()
        {
            this.loggerMock = new Mock<ILogger<CamGatewayController>>();
            this.mediatorMock = new Mock<IMediator>();
            this.controller = new CamGatewayController(this.loggerMock.Object, this.mediatorMock.Object);
            this.validRequest = Helper.GetCamInput();
            this.invalidRequest = null;
        }

        /// <summary>
        /// Controller execution status.
        /// </summary>
        [Fact]
        public void Status_SuccessfulTransaction_ThrowsNotException()
        {
            // Act
            var result = this.controller.Status();

            // Assert
            Assert.IsType<OkResult>(result);
        }

        [Fact]
        public async Task CheckCam_ResponseFromService_ReturnsOkResult()
        {
            // Arrange
            var executionStatus = new ExecutionStatus() { Status = Status.ALLOW, Messages = new List<string>() { } };
            this.mediatorMock.Setup(x => x.Send(It.IsAny<CheckAndApplyLocksCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(executionStatus));

            // Act
            var actionResult = await this.controller.CheckCam(this.validRequest);

            // Assert
            Assert.IsType<OkObjectResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<CheckAndApplyLocksCommand>(), default(CancellationToken)), Times.Once);
        }

        [Fact]
        public async Task CheckCam_InvalidCamInput_ReturnsBadRequest()
        {
            // Act
            var actionResult = await this.controller.CheckCam(this.invalidRequest);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<CheckAndApplyLocksCommand>(), default(CancellationToken)), Times.Never);
        }

        [Fact]
        public async Task CheckAndApplyCamLocks_ResponseFromService_ReturnsOkResult()
        {
            // Arrange
            var executionStatus = new ExecutionStatus() { Status = Status.DENY, Messages = new List<string>() { "Job is locked by user ABCD" } };

            this.mediatorMock.Setup(x => x.Send(It.IsAny<CheckAndApplyLocksCommand>(), default(CancellationToken)))
                .Returns(Task.FromResult(executionStatus));

            // Act
            var actionResult = await this.controller.CheckAndApplyLocks(this.validRequest);

            // Assert
            Assert.IsType<OkObjectResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<CheckAndApplyLocksCommand>(), default(CancellationToken)), Times.Once);
        }

        [Fact]
        public async Task CheckAndApplyCamLocks_InvalidCamInput_ReturnsBadRequest()
        {
            // Act
            var actionResult = await this.controller.CheckAndApplyLocks(this.invalidRequest);

            // Assert
            Assert.IsType<BadRequestObjectResult>(actionResult);
            this.mediatorMock.Verify(x => x.Send(It.IsAny<CheckAndApplyLocksCommand>(), default(CancellationToken)), Times.Never);
        }
    }
}
