// <copyright file="ConfigParameterConstantsTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Configurations
{
    using CAMGatewayService.Configurations;
    using Xunit;

    /// <summary>
    /// Test class for config parameter constants test
    /// </summary>
    public class ConfigParameterConstantsTest : ConfigParameterConstants
    {
        [Fact]
        public void ConfigParameterConstants_HasKeys_ShouldReturnValues()
        {
            Assert.Equal("tsmt-influxdb-db", InfluxDb);
            Assert.Equal("tsmt-influxdb-url", InfluxDbUrl);
            Assert.Equal("tsmt-influxdb-user", InfluxDbUserName);
            Assert.Equal("tsmt-influxdb-password", InfluxDbPassword);
            Assert.Equal("tsmt-okta-clientid-Microservice-access", OktaClientIdForMicroServiceAccess);
            Assert.Equal("tsmt-okta-clientsecret-MicroService-access", OktaClientSecretKeyForMicroServiceAccess);
        }
    }
}
