// <copyright file="MappingProfileTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Configurations
{
    using AutoMapper;
    using CAMGatewayService.Configurations;
    using Xunit;

    public class MappingProfileTest
    {
        private readonly MapperConfiguration mapperConfig;

        public MappingProfileTest()
        {
            this.mapperConfig = new MapperConfiguration(cfg => { cfg.AddProfile<MappingProfile>(); });
        }

        [Fact]
        public void ConfigurationIsValid()
        {
            this.mapperConfig.AssertConfigurationIsValid();
        }
    }
}
