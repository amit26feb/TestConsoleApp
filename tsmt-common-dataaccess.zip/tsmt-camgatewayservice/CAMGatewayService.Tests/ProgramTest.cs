// <copyright file="ProgramTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Test
{
    using System;
    using System.IO;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.TestHost;
    using Xunit;

    /// <summary>
    /// Program test
    /// </summary>
    public class ProgramTest
    {
        [Fact]
        public async Task ShouldBuildWebHost()
        {
            // Arrange
            Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
            string appRootPath = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory,
                "..",
                "..",
                "..",
                "..",
                "CAMGatewayService"));

            // Act
            var webHostBuilder = Program.BuildWebHost(Array.Empty<string>())
                .UseContentRoot(appRootPath);
            var server = new TestServer(webHostBuilder);
            var client = server.CreateClient();
            var response = await client.GetAsync("/api/v1/support/Items/abcd?searchValue='test'");

            // Assert
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }
    }
}
