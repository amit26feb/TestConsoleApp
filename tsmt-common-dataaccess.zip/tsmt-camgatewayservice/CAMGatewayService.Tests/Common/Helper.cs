// <copyright file="Helper.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Common
{
    using System.Collections.Generic;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Common.Constants;
    using TSMT.CAMContext.Conditions.Core.Model;

    /// <summary>
    /// Helper class includes the methods that can be used across the test project.
    /// </summary>
    public static class Helper
    {
        /// <summary>
        /// Method to get the list of conditions.
        /// </summary>
        /// <returns>List of conditions</returns>
        public static List<ContextCondition> GetConditions()
        {
            return new List<ContextCondition>()
            {
                new ContextCondition()
                {
                    Id = "1",
                    Context = "CopyDown",
                    Priority = 1,
                    Source = "Job",
                    ConditionCheckerComponent = "CheckLocalJobAvailableConditionChecker",
                },
                new ContextCondition()
                {
                    Id = "2",
                    Context = "CopyDown",
                    Priority = 2,
                    Source = "Ordering",
                    ConditionCheckerComponent = "CheckLocalNoProjectRecordConditionChecker",
                },
                new ContextCondition()
                {
                    Id = "3",
                    Context = "CopyDown",
                    Priority = 2,
                    Source = "Order",
                    ConditionCheckerComponent = "CheckHostProjectLockConditionChecker",
                },
                new ContextCondition()
                {
                    Id = "4",
                    Context = "Transmit",
                    Priority = 1,
                    Source = "Ordering",
                    ConditionCheckerComponent = "CheckLocalNoProjectRecordConditionChecker",
                },
                new ContextCondition()
                {
                    Id = "5",
                    Context = "Transmit",
                    Priority = 2,
                    Source = "Order",
                    ConditionCheckerComponent = "CheckHostProjectLockConditionChecker",
                },
            };
        }

        /// <summary>
        /// Method to get the list of contexts.
        /// </summary>
        /// <returns>List of contexts</returns>
        public static IEnumerable<AccessContext> GetContexts()
        {
            return new List<AccessContext>()
            {
                new AccessContext()
                {
                    Id = "1",
                    Context = "CopyDown",
                    AccessFeasibilityCheckerComponent = "CopyDownAccessFeasibilityChecker",
                    ActionComponent = "ApplyCopyDownAction",
                    ToasterMessage = "Job could not be opened for editing",
                    NotificationHeaderMessage = "Editing is not allowed due to the following reasons:",
                },
                new AccessContext()
                {
                    Id = "2",
                    Context = "Transmit",
                    AccessFeasibilityCheckerComponent = "TransmitAccessFeasibilityChecker",
                    ActionComponent = "ApplyTransmitAction",
                    ToasterMessage = "There was an issue with locking the Credit Project",
                    NotificationHeaderMessage = "Transmit is not allowed due to the following reasons:",
                },
            };
        }

        /// <summary>
        /// Method to get copy down context component.
        /// </summary>
        /// <returns>Default context.</returns>
        public static AccessContext GetCopyDownContext()
        {
            return new AccessContext()
            {
                Id = "1",
                Context = "CopyDown",
                AccessFeasibilityCheckerComponent = "CopyDownAccessFeasibilityChecker",
                ActionComponent = "ApplyCopyDownAction",
                ToasterMessage = "Job could not be opened for editing",
                NotificationHeaderMessage = "Editing is not allowed due to the following reasons:",
            };
        }

        /// <summary>
        /// Method to get copy down conditions.
        /// </summary>
        /// <returns>Conditions.</returns>
        public static List<ContextCondition> GetCopyDownConditions()
        {
            return new List<ContextCondition>()
            {
                new ContextCondition()
                {
                    Id = "1",
                    Context = "CopyDown",
                    Priority = 1,
                    Source = "Job",
                    ConditionCheckerComponent = "CheckLocalJobAvailableConditionChecker",
                },
                new ContextCondition()
                {
                    Id = "2",
                    Context = "CopyDown",
                    Priority = 2,
                    Source = "Ordering",
                    ConditionCheckerComponent = "CheckLocalNoProjectRecordConditionChecker",
                },
                new ContextCondition()
                {
                    Id = "3",
                    Context = "CopyDown",
                    Priority = 2,
                    Source = "Order",
                    ConditionCheckerComponent = "CheckHostProjectLockConditionChecker",
                },
            };
        }

        /// <summary>
        /// Gets lock status.
        /// </summary>
        /// <returns>Lock status.</returns>
        public static LockStatus GetLockStatus()
        {
            return new LockStatus()
            {
                IsSuccessful = false,
                Messages = new List<string>() { "Sample Error" },
            };
        }

        /// <summary>
        /// Gets execution status.
        /// </summary>
        /// <returns>Execution status of condition.</returns>
        public static ExecutionStatus GetExecutionStatus()
        {
            return new ExecutionStatus()
            {
                Status = Status.DENY,
                Messages = new List<string>() { "Sample Error" },
            };
        }

        /// <summary>
        /// Gets context conditions.
        /// </summary>
        /// <returns>Cam input.</returns>
        public static CamInput GetCamInput()
        {
            return new CamInput()
            {
                Context = "CopyDown",
                HostData = new CamInputMetaData()
                {
                    JobId = 456,
                    CreditJobId = 123,
                },
                LocalData = new CamInputMetaData()
                {
                    JobId = 123,
                    CreditJobId = 456,
                },
                DrAddressId = 1,
                UserId = "ABC",
            };
        }

        /// <summary>
        /// Gets CAM Data.
        /// </summary>
        /// <returns>Cam data.</returns>
        public static CamData GetCamData()
        {
            return new CamData()
            {
                DrAddressId = 1,
                UserId = "ABC",
                LocalLock = new LockData()
                {
                    JobId = 1234,
                    LockUserId = "ABC",
                    CreditProjectLocks = new List<CreditProjectLock>()
                    {
                        new CreditProjectLock()
                        {
                            LockUserId = "ABC",
                            ChangeAllowedIndicator = 'Y',
                            ChangeOrderDecisionStatus = 5,
                            ChangeOrderStatus = "Pending",
                            CreditJobId = 12343545,
                            LegacyCreditJobNumber = "CR01",
                            SalesOrderLocks = new List<SalesOrderLock>()
                            {
                                new SalesOrderLock()
                                {
                                    SalesOrderId = 98656,
                                    ChangeOrderStatus = "XX",
                                    LockUserId = "ABC",
                                },
                            },
                        },
                    },
                },
                HostLock = new LockData()
                {
                    JobId = 1234,
                    LockUserId = "ABC",
                    CreditProjectLocks = new List<CreditProjectLock>()
                    {
                        new CreditProjectLock()
                        {
                            LockUserId = "ABC",
                            ChangeAllowedIndicator = 'Y',
                            ChangeOrderDecisionStatus = 5,
                            ChangeOrderStatus = "Pending",
                            CreditJobId = 12343545,
                            LegacyCreditJobNumber = "CR01",
                            SalesOrderLocks = new List<SalesOrderLock>()
                            {
                                new SalesOrderLock()
                                {
                                    SalesOrderId = 98656,
                                    ChangeOrderStatus = "XX",
                                    LockUserId = "ABC",
                                },
                            },
                        },
                    },
                },
            };
        }
    }
}
