// <copyright file="CheckAndApplyLocksCommandValidatorTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Core.Validators
{
    using CAMGatewayService.Core.Commands;
    using CAMGatewayService.Core.Validators;
    using CAMGatewayService.Tests.Common;
    using Xunit;

    /// <summary>
    /// Check and apply locks command validator test
    /// </summary>
    public class CheckAndApplyLocksCommandValidatorTest
    {
        [Fact]
        public void CheckAndApplyLocksCommandValidator_ValidInput_Success()
        {
            // Arrange
            var request = Helper.GetCamInput();

            // Act
            var validationResult = new CheckAndApplyLocksCommandValidator().Validate(new CheckAndApplyLocksCommand(request, true));

            // Assert
            Assert.True(validationResult.IsValid);
        }

        [Fact]
        public void CheckAndApplyLocksCommandValidator_InvalidContext_Failure()
        {
            // Arrange
            var request = Helper.GetCamInput();
            request.Context = string.Empty;

            // Act
            var validationResult = new CheckAndApplyLocksCommandValidator().Validate(new CheckAndApplyLocksCommand(request, false));

            // Assert
            Assert.False(validationResult.IsValid);
        }

        [Fact]
        public void CheckAndApplyLocksCommandValidator_InvalidDrAddressId_Failure()
        {
            // Arrange
            var request = Helper.GetCamInput();
            request.DrAddressId = 0;

            // Act
            var validationResult = new CheckAndApplyLocksCommandValidator().Validate(new CheckAndApplyLocksCommand(request, false));

            // Assert
            Assert.False(validationResult.IsValid);
        }

        [Fact]
        public void CheckAndApplyLocksCommandValidator_InvalidUserId_Failure()
        {
            // Arrange
            var request = Helper.GetCamInput();
            request.UserId = string.Empty;

            // Act
            var validationResult = new CheckAndApplyLocksCommandValidator().Validate(new CheckAndApplyLocksCommand(request, true));

            // Assert
            Assert.False(validationResult.IsValid);
        }
    }
}
