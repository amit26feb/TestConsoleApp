// <copyright file="DocumentDbRepositoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Core.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CAMGatewayService.Configurations;
    using CAMGatewayService.Core.Repository;
    using CAMGatewayService.Tests.Common;
    using DocumentDBWrapper;
    using Microsoft.Extensions.Caching.Memory;
    using Microsoft.Extensions.Options;
    using MongoDB.Driver;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using Xunit;

    /// <summary>
    /// Contains tests to verify document db repository.
    /// </summary>
    public class DocumentDbRepositoryTest
    {
        private readonly Mock<IDocumentDBConnectionFactory> documentDBConnectionFactoryMock;
        private readonly Mock<IOptions<ServiceSettings>> serviceSettingsMock;
        private readonly Mock<IDocumentDBCollection<AccessContext>> documentDBContextCollectionMock;
        private readonly Mock<IDocumentDBCollection<ContextCondition>> documentDBContextConditionCollectionMock;
        private readonly DocumentDbRepository documentDbRepository;
        private readonly Mock<IMemoryCache> mockCache;
        private readonly ICacheEntry mockCacheEntry;
        private readonly IEnumerable<AccessContext> contexts;
        private readonly IEnumerable<ContextCondition> conditions;
        private readonly IEnumerable<ContextCondition> copyDownConditions;
        private readonly FilterDefinition<AccessContext> contextFilterDefinition;
        private readonly FilterDefinition<ContextCondition> conditionFilterDefinition;
        private readonly AccessContext copyDownContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentDbRepositoryTest"/> class.
        /// Constructor.
        /// </summary>
        public DocumentDbRepositoryTest()
        {
            this.documentDBConnectionFactoryMock = new Mock<IDocumentDBConnectionFactory>();
            this.serviceSettingsMock = new Mock<IOptions<ServiceSettings>>();
            ServiceSettings appSetting = new ServiceSettings()
            {
                DocumentDBContextCollectionName = "Contexts",
                DocumentDBContextConditionCollectionName = "Conditions",
            };
            this.serviceSettingsMock.Setup(app => app.Value).Returns(appSetting);
            this.documentDBContextCollectionMock = new Mock<IDocumentDBCollection<AccessContext>>();
            this.documentDBContextConditionCollectionMock = new Mock<IDocumentDBCollection<ContextCondition>>();
            this.mockCache = new Mock<IMemoryCache>();
            this.mockCacheEntry = Mock.Of<ICacheEntry>();
            this.documentDBConnectionFactoryMock.Setup(x => x.GetCollection<AccessContext>(appSetting.DocumentDBContextCollectionName)).Returns(this.documentDBContextCollectionMock.Object);
            this.documentDBConnectionFactoryMock.Setup(x => x.GetCollection<ContextCondition>(appSetting.DocumentDBContextConditionCollectionName)).Returns(this.documentDBContextConditionCollectionMock.Object);
            this.contexts = Helper.GetContexts();
            this.conditions = Helper.GetConditions();
            this.copyDownContext = Helper.GetCopyDownContext();
            this.copyDownConditions = Helper.GetCopyDownConditions();
            this.contextFilterDefinition = Builders<AccessContext>.Filter.Empty;
            this.conditionFilterDefinition = Builders<ContextCondition>.Filter.Empty;
            this.documentDbRepository = new DocumentDbRepository(
                this.documentDBConnectionFactoryMock.Object,
                this.serviceSettingsMock.Object,
                this.mockCache.Object);
        }

        [Fact]
        public void GetContext_ContextNotInCache_ReturnsContextFromDocumentDb()
        {
            // Arrange
            object contextFromCache = null;

            this.mockCache.Setup(x => x.TryGetValue(It.IsAny<object>(), out contextFromCache)).Returns(true);
            this.mockCache.Setup(x => x.CreateEntry(It.IsAny<object>())).Returns(this.mockCacheEntry);
            this.documentDBContextCollectionMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<AccessContext>>(), It.IsAny<FindOptions<AccessContext>>())).Returns(Task.FromResult(this.contexts));

            // Act
            var result = this.documentDbRepository.GetContext("CopyDown").Result;

            // Assert
            Assert.Equal(this.copyDownContext.Context, result.Context);
            Assert.Equal(this.copyDownContext.AccessFeasibilityCheckerComponent, result.AccessFeasibilityCheckerComponent);
            Assert.Equal(this.copyDownContext.ActionComponent, result.ActionComponent);
            this.mockCache.Verify(x => x.TryGetValue(It.IsAny<object>(), out contextFromCache), Times.Once);
            this.mockCache.Verify(x => x.CreateEntry(It.IsAny<object>()), Times.Once);
            this.documentDBContextCollectionMock.Verify(x => x.FindAsync(this.contextFilterDefinition, null), Times.Once);
        }

        [Fact]
        public void GetContext_ContextInCache_ReturnsContextFromCache()
        {
            // Arrange
            object contextFromCache = this.contexts;
            this.mockCache.Setup(x => x.TryGetValue(It.IsAny<object>(), out contextFromCache)).Returns(true);

            // Act
            var result = this.documentDbRepository.GetContext("CopyDown").Result;

            // Assert
            Assert.Equal(this.copyDownContext.Context, result.Context);
            Assert.Equal(this.copyDownContext.AccessFeasibilityCheckerComponent, result.AccessFeasibilityCheckerComponent);
            Assert.Equal(this.copyDownContext.ActionComponent, result.ActionComponent);
            this.mockCache.Verify(x => x.TryGetValue(It.IsAny<object>(), out contextFromCache), Times.Once);
            this.mockCache.Verify(x => x.CreateEntry(It.IsAny<object>()), Times.Never);
            this.documentDBContextCollectionMock.Verify(x => x.FindAsync(this.contextFilterDefinition, null), Times.Never);
        }

        [Fact]
        public void GetConditions_ConditionsNotInCache_ReturnsConditionsFromDocumentDb()
        {
            // Arrange
            object conditionsFromCache = null;

            this.mockCache.Setup(x => x.TryGetValue(It.IsAny<object>(), out conditionsFromCache)).Returns(true);
            this.mockCache.Setup(x => x.CreateEntry(It.IsAny<object>())).Returns(this.mockCacheEntry);
            this.documentDBContextConditionCollectionMock.Setup(x => x.FindAsync(It.IsAny<FilterDefinition<ContextCondition>>(), It.IsAny<FindOptions<ContextCondition>>()))
                .Returns(Task.FromResult(this.conditions));

            // Act
            var result = this.documentDbRepository.GetConditions("CopyDown").Result;

            // Assert
            Assert.True(result.Count() > 0);
            Assert.Equal(this.copyDownConditions.Count(), result.Count());
            this.mockCache.Verify(x => x.TryGetValue(It.IsAny<object>(), out conditionsFromCache), Times.Once);
            this.mockCache.Verify(x => x.CreateEntry(It.IsAny<object>()), Times.Once);
            this.documentDBContextConditionCollectionMock.Verify(x => x.FindAsync(this.conditionFilterDefinition, null), Times.Once);
        }

        [Fact]
        public void GetConditions_ConditionstInCache_ReturnsConditionsFromCache()
        {
            // Arrange
            object conditionsFromCache = this.conditions;
            this.mockCache.Setup(x => x.TryGetValue(It.IsAny<object>(), out conditionsFromCache)).Returns(true);

            // Act
            var result = this.documentDbRepository.GetConditions("CopyDown").Result;

            // Assert
            Assert.True(result.Count() > 0);
            Assert.Equal(this.copyDownConditions.Count(), result.Count());
            this.mockCache.Verify(x => x.TryGetValue(It.IsAny<object>(), out conditionsFromCache), Times.Once);
            this.mockCache.Verify(x => x.CreateEntry(It.IsAny<object>()), Times.Never);
            this.documentDBContextConditionCollectionMock.Verify(x => x.FindAsync(this.conditionFilterDefinition, null), Times.Never);
        }
    }
}
