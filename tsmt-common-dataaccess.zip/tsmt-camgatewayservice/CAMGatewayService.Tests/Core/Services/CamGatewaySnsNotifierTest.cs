// <copyright file="CamGatewaySnsNotifierTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Core.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Amazon.SimpleNotificationService.Model;
    using AWS.MessagingWrapper.Contracts;
    using CAMGatewayService.Core.Services;
    using Moq;
    using Xunit;

    public class CamGatewaySnsNotifierTest
    {
        private readonly Mock<IMessagePublisher> snsPublisher;
        private readonly CamGatewaySnsNotifier camGatewaySnsNotifier;

        public CamGatewaySnsNotifierTest()
        {
            this.snsPublisher = new Mock<IMessagePublisher>();
            this.camGatewaySnsNotifier = new CamGatewaySnsNotifier(this.snsPublisher.Object);
        }

        [Fact]
        public async Task SendMessageToSns_ValidRequest_ReturnsMessageId()
        {
            // Arrange
            string snsMessageId = "67890-2b9d-5488-9d28-45a5d2f59876";
            string snsArn = "arn:aws:sns:us-east-1:611998158124:TSMT-JobsSaveToLynx";

            this.snsPublisher.Setup(x => x.PublishToTopicAsync(It.IsAny<object>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Dictionary<string, MessageAttributeValue>>()))
                .Returns(Task.FromResult(snsMessageId));

            // Act
            string result = await this.camGatewaySnsNotifier.SendMessageToSNS(snsMessageId, snsArn);

            // Assert
            Assert.Equal(snsMessageId, result);
            this.snsPublisher.Verify(x => x.PublishToTopicAsync(snsMessageId, snsArn, 3, null), Times.Once);
        }
    }
}
