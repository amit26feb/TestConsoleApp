// <copyright file="CamServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Core.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CAMGatewayService.Core.Repository;
    using CAMGatewayService.Core.Services;
    using CAMGatewayService.Tests.Common;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Moq;
    using TSMT.CAM.Context.Core.Services;
    using TSMT.CAM.Context.Enumerator;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Locks.Common.Constants.Enumerator;
    using TSMT.CAM.Locks.Core.Services;
    using TSMT.CAMContext.Conditions.Common.Constants;
    using TSMT.CAMContext.Conditions.Core.Model;
    using TSMT.Settings;
    using Xunit;

    public class CamServiceTest
    {
        private readonly Mock<IContextFactory> contextFactoryMock;
        private readonly Mock<IActionFactory> actionFactoryMock;
        private readonly Mock<IContext> copyDownContextMock;
        private readonly Mock<IAction> applyCopyDownActionMock;
        private readonly Mock<IDocumentDbRepository> documentDbRepositoryMock;
        private readonly Mock<ILogger<CamService>> loggerMock;
        private readonly Mock<ICamGatewaySnsNotifier> camGatewaySnsNotifierMock;
        private readonly Mock<IOptions<TSMTSettings>> tsmtSettingMock;
        private readonly CamService camService;
        private readonly DefaultHttpContext httpContext = new DefaultHttpContext();
        private readonly string messageId = "46932a2a-de14-4b4e-bcb1-4566257fedaa";
        private CamData camData;
        private CamInput camInput;
        private AccessContext accessContext;
        private IEnumerable<ContextCondition> contextConditions;
        private LockStatus lockStatus;
        private IEnumerable<int> priorityList;
        private ExecutionStatus executionStatus;

        /// <summary>
        /// Initializes a new instance of the <see cref="CamServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public CamServiceTest()
        {
            this.contextFactoryMock = new Mock<IContextFactory>();
            this.actionFactoryMock = new Mock<IActionFactory>();
            this.copyDownContextMock = new Mock<IContext>();
            this.applyCopyDownActionMock = new Mock<IAction>();
            this.documentDbRepositoryMock = new Mock<IDocumentDbRepository>();
            this.loggerMock = new Mock<ILogger<CamService>>();
            this.camGatewaySnsNotifierMock = new Mock<ICamGatewaySnsNotifier>();
            this.tsmtSettingMock = new Mock<IOptions<TSMTSettings>>();
            this.copyDownContextMock.Setup(x => x.Context).Returns(Context.CopyDownAccessFeasibilityChecker);
            this.applyCopyDownActionMock.Setup(x => x.ActionType).Returns(ActionType.ApplyCopyDownAction);
            this.contextFactoryMock.Setup(x => x.GetContextInstance(It.IsAny<Context>()))
                .Returns(this.copyDownContextMock.Object);
            this.actionFactoryMock.Setup(x => x.GetActionInstance(It.IsAny<ActionType>()))
                .Returns(this.applyCopyDownActionMock.Object);
            TSMTSettings app = new TSMTSettings() { SnsServiceUrlForNotifications = "mock-url" };
            this.tsmtSettingMock.Setup(ap => ap.Value).Returns(app);
            this.camService = new CamService(
                this.contextFactoryMock.Object,
                this.actionFactoryMock.Object,
                this.documentDbRepositoryMock.Object,
                this.loggerMock.Object,
                this.camGatewaySnsNotifierMock.Object,
                this.tsmtSettingMock.Object);
            this.camData = Helper.GetCamData();
            this.camInput = Helper.GetCamInput();
            this.accessContext = Helper.GetCopyDownContext();
            this.contextConditions = Helper.GetCopyDownConditions();
            this.lockStatus = Helper.GetLockStatus();
            this.executionStatus = Helper.GetExecutionStatus();
            this.priorityList = new List<int>() { 1, 2 };
            this.copyDownContextMock.Setup(x => x.GetEnrichedCamInputData(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamInput>())).Returns(Task.FromResult(this.camInput));
            this.copyDownContextMock.Setup(x => x.GetCamData(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamInput>())).Returns(Task.FromResult(this.camData));
            this.copyDownContextMock.Setup(x => x.GetPriorities(It.IsAny<IEnumerable<ContextCondition>>())).Returns(Task.FromResult(this.priorityList));
        }

        [Fact]
        public async Task CheckAndApplyLocks_AllConditionsAllowAndLock_ReturnsAllow()
        {
            // Arrange
            this.executionStatus.Status = Status.ALLOW;
            this.lockStatus.IsSuccessful = true;
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.copyDownContextMock.Setup(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamData>())).Returns(Task.FromResult(this.executionStatus));
            this.applyCopyDownActionMock.Setup(x => x.ExecuteAction(It.IsAny<CamData>())).Returns(Task.FromResult(this.lockStatus));

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, true);

            // Assert
            Assert.Equal(Status.ALLOW, result.Status);
            Assert.Empty(result.Messages);
            this.copyDownContextMock.Verify(x => x.GetEnrichedCamInputData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetPriorities(this.contextConditions), Times.Once);
            this.copyDownContextMock.Verify(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), this.camData), Times.Exactly(2));
            this.applyCopyDownActionMock.Verify(x => x.ExecuteAction(this.camData), Times.Once);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public async Task CheckAndApplyLocks_ConditionsDeny_DoNotRunLock()
        {
            // Arrange
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.copyDownContextMock.Setup(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamData>())).Returns(Task.FromResult(this.executionStatus));
            this.camGatewaySnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(this.messageId));

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, true);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.Equal(new List<string> { this.accessContext.ToasterMessage }, result.Messages);
            this.documentDbRepositoryMock.Verify(x => x.GetContext(this.accessContext.Context), Times.Once);
            this.documentDbRepositoryMock.Verify(x => x.GetConditions(this.accessContext.Context), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetEnrichedCamInputData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetPriorities(this.contextConditions), Times.Once);
            this.copyDownContextMock.Verify(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), this.camData), Times.Once);
            this.applyCopyDownActionMock.Verify(x => x.ExecuteAction(this.camData), Times.Never);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task CheckAndApplyLocks_CamDataEmpty_DoNotExecuteConditions()
        {
            // Arrange
            this.camData = null;
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.copyDownContextMock.Setup(x => x.GetCamData(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamInput>())).Returns(Task.FromResult(this.camData));
            this.camGatewaySnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(this.messageId));

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, true);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.Equal(new List<string> { this.accessContext.ToasterMessage }, result.Messages);
            this.copyDownContextMock.Verify(x => x.GetEnrichedCamInputData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetPriorities(this.contextConditions), Times.Never);
            this.copyDownContextMock.Verify(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), this.camData), Times.Never);
            this.applyCopyDownActionMock.Verify(x => x.ExecuteAction(this.camData), Times.Never);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task CheckAndApplyLocks_AllConditionsAllowAndLock_LockFails()
        {
            // Arrange
            this.executionStatus.Status = Status.ALLOW;
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.copyDownContextMock.Setup(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamData>())).Returns(Task.FromResult(this.executionStatus));
            this.applyCopyDownActionMock.Setup(x => x.ExecuteAction(It.IsAny<CamData>())).Returns(Task.FromResult(this.lockStatus));
            this.camGatewaySnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(this.messageId));

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, true);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.Equal(new List<string> { this.accessContext.ToasterMessage }, result.Messages);
            this.copyDownContextMock.Verify(x => x.GetEnrichedCamInputData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetPriorities(this.contextConditions), Times.Once);
            this.copyDownContextMock.Verify(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), this.camData), Times.Exactly(2));
            this.applyCopyDownActionMock.Verify(x => x.ExecuteAction(this.camData), Times.Once);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task CheckAndApplyLocks_AllConditionsAllowAndNoLock_DoNotRunLock()
        {
            // Arrange
            this.executionStatus.Status = Status.ALLOW;
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.copyDownContextMock.Setup(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamData>())).Returns(Task.FromResult(this.executionStatus));

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, false);

            // Assert
            Assert.Equal(Status.ALLOW, result.Status);
            Assert.Empty(result.Messages);
            this.copyDownContextMock.Verify(x => x.GetEnrichedCamInputData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetPriorities(this.contextConditions), Times.Once);
            this.copyDownContextMock.Verify(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), this.camData), Times.Exactly(2));
            this.applyCopyDownActionMock.Verify(x => x.ExecuteAction(this.camData), Times.Never);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public async Task CheckAndApplyLocks_InvalidValueForContextOrConditionOrLockType_ReturnsDenyStatus()
        {
            // Arrange
            this.accessContext.AccessFeasibilityCheckerComponent = "Invalid";
            this.accessContext.ActionComponent = "Invalid";
            this.contextConditions.First().ConditionCheckerComponent = "Invalid";
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.camGatewaySnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(this.messageId));

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, true);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.Equal(new List<string> { this.accessContext.ToasterMessage }, result.Messages);
            this.copyDownContextMock.Verify(x => x.GetEnrichedCamInputData(this.contextConditions, this.camInput), Times.Never);
            this.copyDownContextMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Never);
            this.copyDownContextMock.Verify(x => x.GetPriorities(this.contextConditions), Times.Never);
            this.copyDownContextMock.Verify(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), this.camData), Times.Never);
            this.applyCopyDownActionMock.Verify(x => x.ExecuteAction(this.camData), Times.Never);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task CheckAndApplyLocks_Exception_ReturnsDenyStatus()
        {
            // Arrange
            this.copyDownContextMock.Setup(x => x.GetCamData(It.IsAny<IEnumerable<ContextCondition>>(), It.IsAny<CamInput>())).Throws<Exception>();
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.camGatewaySnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(this.messageId));

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, true);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.Equal(new List<string> { this.accessContext.ToasterMessage }, result.Messages);
            this.copyDownContextMock.Verify(x => x.GetEnrichedCamInputData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetCamData(this.contextConditions, this.camInput), Times.Once);
            this.copyDownContextMock.Verify(x => x.GetPriorities(this.contextConditions), Times.Never);
            this.copyDownContextMock.Verify(x => x.ExecuteConditions(It.IsAny<IEnumerable<ContextCondition>>(), this.camData), Times.Never);
            this.applyCopyDownActionMock.Verify(x => x.ExecuteAction(this.camData), Times.Never);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            this.loggerMock.Verify(
                    x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().StartsWith("An error occurred while executing the cam gateway status for context")),
                    It.IsAny<Exception>(),
                    It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)), Times.Once);
        }

        [Fact]
        public async Task CheckAndApplyLocks_ExceptionOccuredWhileSendingMessageToSns_ReturnsDenyStatus()
        {
            // Arrange
            this.accessContext.AccessFeasibilityCheckerComponent = "Invalid";
            this.accessContext.ActionComponent = "Invalid";
            this.contextConditions.First().ConditionCheckerComponent = "Invalid";
            this.documentDbRepositoryMock.Setup(x => x.GetContext(It.IsAny<string>())).Returns(Task.FromResult(this.accessContext));
            this.documentDbRepositoryMock.Setup(x => x.GetConditions(It.IsAny<string>())).Returns(Task.FromResult(this.contextConditions));
            this.camGatewaySnsNotifierMock.Setup(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>())).Throws<Exception>();

            // Act
            var result = await this.camService.CheckAndApplyLocks(this.camInput, true);

            // Assert
            Assert.Equal(Status.DENY, result.Status);
            Assert.Equal(new List<string> { this.accessContext.ToasterMessage }, result.Messages);
            this.camGatewaySnsNotifierMock.Verify(x => x.SendMessageToSNS(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }
    }
}
