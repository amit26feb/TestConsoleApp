// <copyright file="CheckAndApplyLocksCommandHandlerTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Tests.Core.CommandHandlers
{
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using CAMGatewayService.Core.CommandHandlers;
    using CAMGatewayService.Core.Commands;
    using CAMGatewayService.Core.Services;
    using CAMGatewayService.Tests.Common;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAMContext.Conditions.Common.Constants;
    using TSMT.CAMContext.Conditions.Core.Model;
    using Xunit;

    /// <summary>
    /// Check and apply lock command handler test
    /// </summary>
    public class CheckAndApplyLocksCommandHandlerTest
    {
        private readonly Mock<ICamService> camService;
        private readonly CheckAndApplyLocksCommandHandler commandHandler;
        private readonly CamInput request;
        private CheckAndApplyLocksCommand checkAndApplyLocksCommand;
        private CancellationToken cancellationToken;

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckAndApplyLocksCommandHandlerTest"/> class.
        /// </summary>
        public CheckAndApplyLocksCommandHandlerTest()
        {
            this.camService = new Mock<ICamService>();
            this.commandHandler = new CheckAndApplyLocksCommandHandler(this.camService.Object);
            this.cancellationToken = default;

            this.request = Helper.GetCamInput();
        }

        [Fact]
        public async Task Handle_CheckAndApplyLock_ReturnsExecutionStatus()
        {
            // Arrange
            this.checkAndApplyLocksCommand = new CheckAndApplyLocksCommand(this.request, true);
            var executionStatus = new ExecutionStatus() { Status = Status.ALLOW, Messages = new List<string>() { } };
            this.camService.Setup(x => x.CheckAndApplyLocks(It.IsAny<CamInput>(), It.IsAny<bool>()))
                        .Returns(Task.FromResult(executionStatus));

            // Act
            var result = await this.commandHandler.Handle(this.checkAndApplyLocksCommand, this.cancellationToken);

            // Assert
            Assert.Equal(executionStatus, result);
            this.camService.Verify(x => x.CheckAndApplyLocks(this.request, true), Times.Once);
        }
    }
}
