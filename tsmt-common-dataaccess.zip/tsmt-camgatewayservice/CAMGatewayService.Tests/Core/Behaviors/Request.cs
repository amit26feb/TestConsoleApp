// <copyright file="Request.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Test.Core.Behaviors
{
    using MediatR;

    public class Request : IRequest<Response>
    {
        /// <summary>
        /// Gets or sets message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets error
        /// </summary>
        public string Errors { get; set; }
    }
}
