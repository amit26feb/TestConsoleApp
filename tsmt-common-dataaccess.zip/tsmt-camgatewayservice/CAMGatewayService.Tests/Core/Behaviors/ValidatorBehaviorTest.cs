// <copyright file="ValidatorBehaviorTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMGatewayService.Test.Core.Behaviors
{
    using System.Threading;
    using System.Threading.Tasks;
    using CAMGatewayService.Core.Behaviors;
    using FluentValidation;
    using MediatR;
    using Xunit;

    /// <summary>
    /// Validator behavior test
    /// </summary>
    public class ValidatorBehaviorTest
    {
        /// <summary>
        /// Logging behavior request response
        /// </summary>
        private readonly IValidator<Request>[] validators;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatorBehaviorTest"/> class.
        /// ValidatorBehaviorTest
        /// </summary>
        public ValidatorBehaviorTest()
        {
            this.validators = new IValidator<Request>[0];
        }

        /// <summary>
        /// Success validator behavior
        /// </summary>
        /// <returns>Success</returns>
        [Fact]
        public async Task ValidatorBehavior_ValidInput_ReturnsMessage()
        {
            ValidatorBehavior<Request, Response> validatorBehavior = new ValidatorBehavior<Request, Response>(this.validators);

            Request ping = new Request
            {
                Message = "test request"
            };
            Response pong = new Response
            {
                Message = "test response"
            };

            CancellationToken cancellationToken = default(CancellationToken);

            var response = await validatorBehavior.Handle(ping, cancellationToken, next: () => Task.FromResult(pong));

            Assert.NotNull(response);
            Assert.Equal(response.Message, pong.Message);
        }
    }
}
