// <copyright file="PropertyInfoExtension.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Reflection;

   /// <summary>
   /// Extensions for the PropertyInfo class
   /// </summary>
   public static class PropertyInfoExtension
   {
      /// <summary>
      /// Determine if the Attribute has an AllowEdit key and return its boolean state
      /// fake the funk and try to mimick EditableAttribute in System.ComponentModel.DataAnnotations
      /// This allows use of the DataAnnotations property in the model and have the SimpleCRUD engine just figure it out without a reference
      /// </summary>
      /// <param name="pi">property info</param>
      /// <returns>bool</returns>
      public static bool IsEditable(this PropertyInfo pi)
      {
         var attributes = pi.GetCustomAttributes(false);
         if (attributes.Length > 0)
         {
            dynamic write = attributes.FirstOrDefault(x => x.GetType().Name == "EditableAttribute");
            if (write != null)
            {
               return write.AllowEdit;
            }
         }

         return false;
      }

      /// <summary>
      /// Determine if the Attribute has an IsReadOnly key and return its boolean state
      /// fake the funk and try to mimick ReadOnlyAttribute in System.ComponentModel
      /// This allows use of the DataAnnotations property in the model and have the SimpleCRUD engine just figure it out without a reference
      /// </summary>
      /// <param name="pi">property info</param>
      /// <returns>bool</returns>
      public static bool IsReadOnly(this PropertyInfo pi)
      {
         var attributes = pi.GetCustomAttributes(false);
         if (attributes.Length > 0)
         {
            dynamic write = attributes.FirstOrDefault(x => x.GetType().Name == "ReadOnlyAttribute");
            if (write != null)
            {
               return write.IsReadOnly;
            }
         }

         return false;
      }

      /// <summary>
      /// Gets the column name for a propertyInfo object
      /// </summary>
      /// <param name="propertyInfo">PropertyInfo</param>
      /// <returns>column name string</returns>
      public static string GetColumnName(this PropertyInfo propertyInfo)
      {
         var columnName = propertyInfo.Name;

         var columnattr = propertyInfo.GetCustomAttributes(true).SingleOrDefault(attr => attr.GetType().Name == "ColumnAttribute") as dynamic;
         if (columnattr?.Name != null)
         {
            columnName = columnattr.Name;
         }

         return columnName;
      }

      /// <summary>
      /// Get all properties in an entity
      /// </summary>
      /// <param name="entity">entity to get props for</param>
      /// <returns>enumeration of prop infos</returns>
      public static IEnumerable<PropertyInfo> GetAllProperties(object entity)
      {
         if (entity == null)
         {
            entity = new { };
         }

         return entity.GetType().GetProperties();
      }

      /// <summary>
      /// Get all properties that are named Id or have the Key attribute
      /// For Inserts and updates we have a whole entity so this method is used
      /// </summary>
      /// <param name="entity">entity to get props for</param>
      /// <returns>enumeration of prop infos</returns>
      public static IEnumerable<PropertyInfo> GetIdProperties(object entity)
      {
         var type = entity.GetType();
         return GetIdProperties(type);
      }

      /// <summary>
      /// Get all properties that are named Id or have the Key attribute
      /// For Get(id) and Delete(id) we don't have an entity, just the type so this method is used
      /// </summary>
      /// <param name="type">Type to get props for</param>
      /// <returns>enumeration of prop infos</returns>
      public static IEnumerable<PropertyInfo> GetIdProperties(Type type)
      {
         return type.GetProperties().Where(p => p.Name == "Id" || p.GetCustomAttributes(true).Any(attr => attr.GetType().Name == "KeyAttribute" || p.GetCustomAttributes(true).Any(x => x.GetType().Name == "ForeignKeyAttribute")));
      }
   }
}
