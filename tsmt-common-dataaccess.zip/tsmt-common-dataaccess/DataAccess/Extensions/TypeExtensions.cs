// <copyright file="TypeExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System;
   using System.Collections.Generic;

   /// <summary>
   /// TypeExtensions class
   /// </summary>
   public static class TypeExtensions
   {
      /// <summary>
      /// Determine if a type is "simple" since complex types cannot be inserted.
      /// </summary>
      /// <param name="type">The type to check</param>
      /// <returns>True if simple, else false</returns>
      public static bool IsSimpleType(this Type type)
      {
         var underlyingType = Nullable.GetUnderlyingType(type);
         type = underlyingType ?? type;
         var simpleTypes = new List<Type>
                               {
                                   typeof(byte),
                                   typeof(sbyte),
                                   typeof(short),
                                   typeof(ushort),
                                   typeof(int),
                                   typeof(uint),
                                   typeof(long),
                                   typeof(ulong),
                                   typeof(float),
                                   typeof(double),
                                   typeof(decimal),
                                   typeof(bool),
                                   typeof(string),
                                   typeof(char),
                                   typeof(Guid),
                                   typeof(DateTime),
                                   typeof(DateTimeOffset),
                                   typeof(byte[])
                               };
         return simpleTypes.Contains(type) || type.IsEnum;
      }
   }
}
