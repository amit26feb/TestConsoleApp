﻿// <copyright file="ProcedureParameterAttribute.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Attributes
{
   using System;
   using System.Data;
   using Oracle.ManagedDataAccess.Client;

   /// <summary>
   /// An attribute for denoting a procedure parameter
   /// </summary>
   public class ProcedureParameterAttribute : Attribute
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="ProcedureParameterAttribute"/> class.
      /// </summary>
      /// <param name="name">The parameter name</param>
      public ProcedureParameterAttribute(string name)
      {
         this.Name = name;
         this.Type = null;
         this.Size = null;
         this.Direction = ParameterDirection.Input;
      }

      /// <summary>
      /// Initializes a new instance of the <see cref="ProcedureParameterAttribute"/> class.
      /// </summary>
      /// <param name="name">The parameter name</param>
      /// <param name="type">The parameter data type</param>
      /// <param name="size">The parameter data size</param>
      public ProcedureParameterAttribute(string name, OracleDbType type, int size)
      {
         this.Name = name;
         this.Type = type;
         this.Size = size;
         this.Direction = ParameterDirection.Input;
      }

      /// <summary>
      /// Initializes a new instance of the <see cref="ProcedureParameterAttribute"/> class.
      /// </summary>
      /// <param name="name">The parameter name</param>
      /// <param name="type">The parameter data type</param>
      /// <param name="size">The parameter data size</param>
      /// <param name="direction">The parameter direction</param>
      public ProcedureParameterAttribute(string name, OracleDbType type, int size, ParameterDirection direction)
      {
         this.Name = name;
         this.Type = type;
         this.Size = size;
         this.Direction = direction;
      }

      /// <summary>
      /// Gets the name of the parameter
      /// </summary>
      public string Name { get; }

      /// <summary>
      /// Gets the data type of the parameter
      /// </summary>
      public OracleDbType? Type { get; }

      /// <summary>
      /// Gets the data size of the parameter
      /// </summary>
      public int? Size { get; }

      /// <summary>
      /// Gets the direction of the parameter
      /// </summary>
      public ParameterDirection Direction { get; }
   }
}
