﻿// <copyright file="ProcedureAttribute.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Attributes
{
   using System;

   /// <summary>
   /// An attribute for denoting a procedure model
   /// </summary>
   public class ProcedureAttribute : Attribute
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="ProcedureAttribute"/> class.
      /// </summary>
      /// <param name="name">The procedure name</param>
      public ProcedureAttribute(string name)
      {
         this.Name = name;
      }

      /// <summary>
      /// Gets the name of the procedure
      /// </summary>
      public string Name { get; }
   }
}
