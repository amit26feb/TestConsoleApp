// <copyright file="FilterOperators.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Paging
{
   /// <summary>
   /// Filter operators
   /// </summary>
   public enum FilterOperators
   {
      /// <summary>
      /// equal to
      /// </summary>
      Eq,

      /// <summary>
      /// not equal to
      /// </summary>
      Neq,

      /// <summary>
      /// is equal to null
      /// </summary>
      IsNull,

      /// <summary>
      /// is not equal to null
      /// </summary>
      IsNotNull,

      /// <summary>
      /// less than
      /// </summary>
      Lt,

      /// <summary>
      /// less than or equal to
      /// </summary>
      Lte,

      /// <summary>
      /// greater than
      /// </summary>
      Gt,

      /// <summary>
      /// greater than or equal to
      /// </summary>
      Gte,

      /// <summary>
      /// Startswith
      /// </summary>
      Startswith,

      /// <summary>
      /// Endswith
      /// </summary>
      Endswith,

      /// <summary>
      /// Contains
      /// </summary>
      Contains,

      /// <summary>
      /// Doesnotcontain
      /// </summary>
      Doesnotcontain,

      /// <summary>
      /// IsEmpty
      /// </summary>
      IsEmpty,

      /// <summary>
      /// IsNotEmpty
      /// </summary>
      IsNotEmpty
   }
}
