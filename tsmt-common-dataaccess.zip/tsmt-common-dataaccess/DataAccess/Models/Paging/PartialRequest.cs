// <copyright file="PartialRequest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   /// <summary>
   /// PartialRequest class
   /// </summary>
   public class PartialRequest
   {
      /// <summary>
      /// Gets or sets the start index
      /// </summary>
      public int StartIndex { get; set; }

      /// <summary>
      /// Gets or sets the end index
      /// </summary>
      public int EndIndex { get; set; }

      /// <summary>
      /// Gets or sets the sort object
      /// </summary>
      public Sort Sort { get; set; }
   }
}
