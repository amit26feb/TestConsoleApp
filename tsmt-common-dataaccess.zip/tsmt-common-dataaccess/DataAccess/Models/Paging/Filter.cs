// <copyright file="Filter.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   /// <summary>
   /// Filter class
   /// </summary>
   public class Filter
   {
      /// <summary>
      /// Gets or sets field by which column
      /// </summary>
      public string Field { get; set; }

      /// <summary>
      /// Gets or sets operator to apply
      /// </summary>
      public string Operator { get; set; }

      /// <summary>
      /// Gets or sets value for filter
      /// </summary>
      public string Value { get; set; }
   }
}
