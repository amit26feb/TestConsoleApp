﻿// <copyright file="FilterOperatorUtility.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Paging
{
   /// <summary>
   /// Utility class for FilterOperator enum
   /// </summary>
   public static class FilterOperatorUtility
   {
      /// <summary>
      /// Get string equivalent of filter operator values
      /// </summary>
      /// <param name="operatorValue">operatorValue</param>
      /// <returns>string equiv</returns>
      public static string GetOperatorConversion(FilterOperators operatorValue)
      {
         string returnValue = string.Empty;
         switch (operatorValue)
         {
            case FilterOperators.Eq:
               returnValue = "=";
               break;
            case FilterOperators.Neq:
               returnValue = "!=";
               break;
            case FilterOperators.Contains:
               returnValue = "like";
               break;
            case FilterOperators.Doesnotcontain:
               returnValue = "not like";
               break;
            case FilterOperators.Gt:
               returnValue = ">";
               break;
            case FilterOperators.Gte:
               returnValue = ">=";
               break;
            case FilterOperators.Lt:
               returnValue = "<";
               break;
            case FilterOperators.Lte:
               returnValue = "<=";
               break;
            case FilterOperators.Startswith:
            case FilterOperators.Endswith:
               returnValue = "%";
               break;
            case FilterOperators.IsNull:
            case FilterOperators.IsEmpty:
               returnValue = "null";
               break;

            case FilterOperators.IsNotNull:
            case FilterOperators.IsNotEmpty:
               returnValue = "not null";
               break;
         }

         return returnValue;
      }
   }
}
