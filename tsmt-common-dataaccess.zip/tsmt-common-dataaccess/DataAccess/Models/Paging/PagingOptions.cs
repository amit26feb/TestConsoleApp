// <copyright file="PagingOptions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System.Collections.Generic;
   using System.ComponentModel.DataAnnotations;
   using global::DataAccess.Paging;

   /// <summary>
   /// Class for PagingOptions
   /// </summary>
   public class PagingOptions
   {
      /// <summary>
      /// Gets or sets number of records to be skipped
      /// </summary>
      public int Skip { get; set; }

      /// <summary>
      /// Gets or sets number of records to be take
      /// </summary>
      [Required(ErrorMessage = "Take should not be 0")]
      [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "Take must be numeric")]
      public int Take { get; set; }

      /// <summary>
      /// Gets or sets the sort type
      /// </summary>
      public List<Sort> Sort { get; set; }

      /// <summary>
      /// Gets or sets filters
      /// </summary>
      public List<FilterCollection> Filters { get; set; }
   }
}
