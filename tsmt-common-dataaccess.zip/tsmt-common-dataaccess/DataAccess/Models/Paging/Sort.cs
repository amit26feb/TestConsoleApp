// <copyright file="Sort.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   /// <summary>
   /// Sort class
   /// </summary>
   public class Sort
   {
      /// <summary>
      /// Gets or sets sort by string
      /// </summary>
      public string SortBy { get; set; }

      /// <summary>
      /// Gets or sets sort direction
      /// </summary>
      public SortDirection SortDirection { get; set; }
   }
}
