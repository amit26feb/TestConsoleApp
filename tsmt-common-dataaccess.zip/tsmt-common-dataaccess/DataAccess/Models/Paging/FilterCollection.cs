// <copyright file="FilterCollection.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Paging
{
   using System.Collections.Generic;
   using TSMT.DataAccess;

   /// <summary>
   /// FilterCollection class
   /// </summary>
   public class FilterCollection
   {
      /// <summary>
      /// Gets or sets ColumnFilters
      /// </summary>
      public List<Filter> Filters { get; set; }

      /// <summary>
      /// Gets or sets Logic
      /// </summary>
      public string Logic { get; set; }
   }
}
