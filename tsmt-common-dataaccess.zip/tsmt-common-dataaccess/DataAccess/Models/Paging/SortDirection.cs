// <copyright file="SortDirection.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   /// <summary>
   /// Sort directions
   /// </summary>
   public enum SortDirection
   {
      /// <summary>
      /// Sort in ascending order.
      /// </summary>
      Ascending,

      /// <summary>
      /// Sort in descending order.
      /// </summary>
      Descending
   }
}
