﻿// <copyright file="QueryResult.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Models
{
    using Dapper;

    /// <summary>
    /// Class for query and dynamic parameters
    /// </summary>
    public class QueryResult
    {
        /// <summary>
        /// Gets or sets the query string
        /// </summary>
        public string Query { get; set; }

        /// <summary>
        /// Gets or sets the dynamic parameters object
        /// </summary>
        public DynamicParameters Parameters { get; set; }
    }
}
