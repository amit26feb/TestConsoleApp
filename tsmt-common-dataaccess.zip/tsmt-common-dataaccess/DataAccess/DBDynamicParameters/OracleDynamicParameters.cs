﻿// <copyright file="OracleDynamicParameters.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.DBDynamicParameters
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Linq;
   using Dapper;
   using Oracle.ManagedDataAccess.Client;

   /// <summary>
   /// Composes db specific set of parameters
   /// </summary>
   public class OracleDynamicParameters : SqlMapper.IDynamicParameters
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="OracleDynamicParameters"/> class.
      /// construct a dynamic parameter bag
      /// </summary>
      public OracleDynamicParameters()
      {
         this.Parameters = new Dictionary<string, ParamInfo>();
      }

      /// <summary>
      /// Gets parameters dictionary
      /// </summary>
      protected Dictionary<string, ParamInfo> Parameters { get; private set; }

      /// <summary>
      /// Adds a parameter to the dynamic parameter list
      /// </summary>
      /// <param name="name">Name of the parameter</param>
      /// <param name="value">Represents the parameter value</param>
      /// <param name="dbType">DB type of the given parameter</param>
      /// <param name="direction">Parameter direction (Input, Output, InputOutput, ReturnValue)</param>
      /// <param name="size">Field Size</param>
      public void Add(string name, object value = null, OracleDbType? dbType = null, ParameterDirection? direction = null, int? size = null)
      {
         this.Parameters[Clean(name)] = new ParamInfo() { Name = name, Value = value, ParameterDirection = direction ?? ParameterDirection.Input, DbType = dbType, Size = size };
      }

      /// <summary>
      /// Get parameter
      /// </summary>
      /// <param name="paramName">Param name</param>
      /// <returns>Parameter's value</returns>
      public ParamInfo GetParameter(string paramName)
      {
         return this.Parameters.FirstOrDefault(x => x.Key == paramName).Value;
      }

      /// <summary>
      /// Adds all the parameters needed to the command just before it executes
      /// </summary>
      /// <param name="command">The raw command prior to execution</param>
      /// <param name="identity">Information about the query</param>
      void SqlMapper.IDynamicParameters.AddParameters(IDbCommand command, SqlMapper.Identity identity)
      {
         foreach (var param in this.Parameters.Values)
         {
            string name = Clean(param.Name);
            bool add = !((OracleCommand)command).Parameters.Contains(name);
            OracleParameter parameter;
            if (add)
            {
               parameter = ((OracleCommand)command).CreateParameter();
               parameter.ParameterName = name;
            }
            else
            {
               parameter = ((OracleCommand)command).Parameters[name];
            }

            var val = param.Value;
            parameter.Value = val ?? DBNull.Value;
            parameter.Direction = param.ParameterDirection;
            var s = val as string;
            if (s != null && s.Length <= 4000)
            {
               parameter.Size = 4000;
            }

            if (param.Size != null)
            {
               parameter.Size = param.Size.Value;
            }

            if (param.DbType != null)
            {
               parameter.OracleDbType = param.DbType.Value;
            }

            if (add)
            {
               command.Parameters.Add(parameter);
            }

            param.AttachedParam = parameter;
         }
      }

      private static string Clean(string name)
      {
         if (!string.IsNullOrEmpty(name))
         {
            switch (name[0])
            {
               case '@':
               case ':':
               case '?':
                  return name.Substring(1);
            }
         }

         return name;
      }
   }
}
