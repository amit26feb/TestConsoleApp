﻿// <copyright file="ParamInfo.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.DBDynamicParameters
{
    using System.Data;
    using Oracle.ManagedDataAccess.Client;

    /// <summary>
    /// Represents the properties of the dynamic parameter
    /// </summary>
    public class ParamInfo
    {
        /// <summary>
        /// Gets or sets parameter name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets parameter value
        /// </summary>
        public object Value { get; set; }

        /// <summary>
        /// Gets or sets parameter direction
        /// </summary>
        public ParameterDirection ParameterDirection { get; set; }

        /// <summary>
        /// Gets or sets parameter data type
        /// </summary>
        public OracleDbType? DbType { get; set; }

        /// <summary>
        /// Gets or sets parameter size
        /// </summary>
        public int? Size { get; set; }

        /// <summary>
        /// Gets or sets a parameter to a command object
        /// </summary>
        public IDbDataParameter AttachedParam { get; set; }
    }
}
