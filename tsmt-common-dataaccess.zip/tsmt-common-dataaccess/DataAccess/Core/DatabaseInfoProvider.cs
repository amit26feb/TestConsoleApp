// <copyright file="DatabaseInfoProvider.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Core.Infrastructure
{
   using DataAccess.Core.Abstractions;
   using Microsoft.Extensions.Options;
   using TSMT.Settings;

   /// <summary>
   /// DefaultConnectionStringProvider utilizes the connection string stored in TSMTSettings.VPNDBConnectionString.
   /// </summary>
   public class DatabaseInfoProvider : IDatabaseInfoProvider
   {
      private readonly TSMTSettings settings;

      /// <summary>
      /// Initializes a new instance of the <see cref="DatabaseInfoProvider"/> class.
      /// </summary>
      /// <param name="connectionString">The consumer's configuration settings.</param>
      public DatabaseInfoProvider(string connectionString)
      {
         this.ConnectionString = connectionString;
      }

      /// <inheritdoc/>
      public string ConnectionString { get; private set; }
   }
}
