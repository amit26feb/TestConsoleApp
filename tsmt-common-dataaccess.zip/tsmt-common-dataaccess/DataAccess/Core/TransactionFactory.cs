// <copyright file="TransactionFactory.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System.Data;
   using global::DataAccess.Core.Abstractions;

   /// <inheritdoc/>
   public class TransactionFactory : ITransactionFactory
   {
      private readonly IConnectionFactory connectionfactory;
      private int? drAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="TransactionFactory"/> class.
      /// </summary>
      /// <param name="connectionFactory">The connection factory</param>
      public TransactionFactory(IConnectionFactory connectionFactory)
      {
         this.connectionfactory = connectionFactory;
      }

      /// <inheritdoc/>
      public void HonorDrAddressId(int? drAddressId)
      {
         this.drAddressId = drAddressId;
      }

      /// <inheritdoc/>
      public ITransaction CreateTransaction()
      {
         IDbConnection connection = this.ResolveConnection();
         IDbTransaction transaction = connection.BeginTransaction();
         return new Transaction(connection, transaction);
      }

      /// <summary>
      /// Returns a connection for a DRAID or creates a new one
      /// </summary>
      /// <returns>A connection</returns>
      private IDbConnection ResolveConnection()
      {
         if (this.drAddressId.HasValue)
         {
            return this.connectionfactory.GetOpenConnectionForDrAddressId(this.drAddressId.Value);
         }
         else
         {
            return this.connectionfactory.GetConnection();
         }
      }
   }
}
