// <copyright file="Transaction.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System;
   using System.Collections.Generic;
   using System.ComponentModel.DataAnnotations;
   using System.ComponentModel.DataAnnotations.Schema;
   using System.Data;
   using System.Linq;
   using System.Reflection;
   using System.Runtime.InteropServices;
   using System.Threading.Tasks;
   using Dapper;
   using global::DataAccess.DBDynamicParameters;
   using Microsoft.Win32.SafeHandles;

   /// <inheritdoc/>
   public class Transaction : ITransaction
   {
      // Instantiate a SafeHandle instance.
      private readonly SafeHandle handle = new SafeFileHandle(IntPtr.Zero, true);

      // Flag: Has Dispose already been called?
      private bool disposed = false;

      /// <summary>
      /// Initializes a new instance of the <see cref="Transaction"/> class.
      /// </summary>
      /// <param name="connection">The DB connection</param>
      /// <param name="transaction">The DB transaction</param>
      public Transaction(IDbConnection connection, IDbTransaction transaction)
      {
         this.DbConnection = connection;
         this.DbTransaction = transaction;
      }

      /// <summary>
      /// Gets the underlying connection
      /// </summary>
      public IDbConnection DbConnection { get; }

      /// <summary>
      /// Gets the underlying transaction
      /// </summary>
      public IDbTransaction DbTransaction { get; }

      /// <inheritdoc/>
      public void Dispose()
      {
         this.Dispose(true);
         GC.SuppressFinalize(this);
      }

      /// <inheritdoc/>
      public void Commit() => this.DbTransaction.Commit();

      /// <inheritdoc/>
      public void Rollback() => this.DbTransaction.Rollback();

      /// <inheritdoc/>
      public async Task ReserveKeyAsync(object insertModel)
      {
         Type modelType = insertModel.GetType();

         // Determine the table and key property
         string tableName = modelType.GetCustomAttribute<TableAttribute>()?.Name ?? modelType.Name;

         PropertyInfo keyProperty = insertModel.GetType().GetProperties()
            .Single(p => p.GetCustomAttribute<KeyAttribute>() != null);

         // Reserve a new key based on the key property type
         if (keyProperty.PropertyType.Equals(typeof(Guid)))
         {
            // For a GUID, just generate a new one
            keyProperty.SetValue(insertModel, Guid.NewGuid());
         }
         else if (keyProperty.PropertyType.Equals(typeof(int)))
         {
            // For an Integer, use the next sequence index
            string sql = @"SELECT PKG_SEQUENCE_NUMBER.GET_NEXT_SEQUENCE(:table, 1) FROM DUAL";
            DynamicParameters dynParms = new DynamicParameters();
            dynParms.Add(":table", tableName);
            int key = await this.CallQuerySingle<int>(new CommandDefinition(sql, dynParms, this.DbTransaction));
            keyProperty.SetValue(insertModel, key);
         }
         else
         {
            throw new NotSupportedException($"The key property ${keyProperty.Name} uses an unsupported type");
         }
      }

      /// <inheritdoc/>
      public async Task<int> InsertAsync(object insertModel)
      {
         var sql = QueryBuilder.GenerateInsertWithoutKeyQueryAsync(insertModel);
         return await this.CallNonQuery(new CommandDefinition(sql, insertModel, this.DbTransaction));
      }

      /// <inheritdoc/>
      public Task<int> UpdateAsync(object updateModel)
      {
         string sql = QueryBuilder.GenerateUpdateQueryAsync(updateModel);
         return this.CallNonQuery(new CommandDefinition(sql, updateModel, this.DbTransaction));
      }

      /// <inheritdoc/>
      public Task<int> DeleteAsync(object deleteModel)
      {
         string sql = QueryBuilder.GenerateDeleteQueryAsync(deleteModel);
         return this.CallNonQuery(new CommandDefinition(sql, deleteModel, this.DbTransaction));
      }

      /// <inheritdoc/>
      public Task<int> ExecuteProcedureAsync(object procedureModel)
      {
         QueryBuilder.BuildStoreProcedureArguments(procedureModel, out var procName, out var procParams);

         OracleDynamicParameters dynamicParameters = new OracleDynamicParameters();
         foreach (ParamInfo param in procParams)
         {
            dynamicParameters.Add(param.Name, param.Value, param.DbType, param.ParameterDirection, param.Size);
         }

         return this.CallNonQuery(new CommandDefinition(
            procName, dynamicParameters, this.DbTransaction, commandType: CommandType.StoredProcedure));
      }

      /// <summary>
      /// A wrapper around the Dapper extension so arguments can be intercepted when testing
      /// </summary>
      /// <param name="command">The command definition</param>
      /// <returns>Count of affected rows</returns>
      public virtual Task<int> CallNonQuery(CommandDefinition command)
      {
         return this.DbConnection.ExecuteAsync(command);
      }

      /// <summary>
      /// A wrapper around the Dapper extension so arguments can be intercepted when testing
      /// </summary>
      /// <typeparam name="TResult">The type of result returned</typeparam>
      /// <param name="command">The command definition</param>
      /// <returns>The command result</returns>
      public virtual Task<IEnumerable<TResult>> CallQuery<TResult>(CommandDefinition command)
      {
         return this.DbConnection.QueryAsync<TResult>(command);
      }

      /// <summary>
      /// A wrapper around the Dapper extension so arguments can be intercepted when testing
      /// </summary>
      /// <typeparam name="TResult">The type of result returned</typeparam>
      /// <param name="command">The command definition</param>
      /// <returns>The command result</returns>
      public virtual Task<TResult> CallQuerySingle<TResult>(CommandDefinition command)
      {
         return this.DbConnection.QuerySingleAsync<TResult>(command);
      }

      /// <summary>
      /// Protected implementation of Dispose pattern.
      /// </summary>
      /// <param name="disposing">bool to signify if we are disposing</param>
      protected virtual void Dispose(bool disposing)
      {
         if (this.disposed)
         {
            return;
         }

         if (disposing)
         {
            this.handle.Dispose();

            // Free any other managed objects here.
            this.DbTransaction?.Dispose();
            this.DbConnection?.Dispose();
         }

         this.disposed = true;
      }
   }
}
