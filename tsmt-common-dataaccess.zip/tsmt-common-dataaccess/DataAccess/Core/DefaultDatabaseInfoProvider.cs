// <copyright file="DefaultDatabaseInfoProvider.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Core.Infrastructure
{
   using DataAccess.Core.Abstractions;
   using Microsoft.Extensions.Options;
   using TSMT.Settings;

   /// <summary>
   /// DefaultConnectionStringProvider utilizes the connection string stored in TSMTSettings.VPNDBConnectionString.
   /// </summary>
   public class DefaultDatabaseInfoProvider : IDatabaseInfoProvider
   {
      private readonly TSMTSettings settings;

      /// <summary>
      /// Initializes a new instance of the <see cref="DefaultDatabaseInfoProvider"/> class.
      /// </summary>
      /// <param name="options">The consumer's configuration settings.</param>
      public DefaultDatabaseInfoProvider(IOptions<TSMTSettings> options)
      {
         this.settings = options.Value;
      }

      /// <inheritdoc/>
      public string ConnectionString => this.settings.VPNDBConnectionString;
   }
}
