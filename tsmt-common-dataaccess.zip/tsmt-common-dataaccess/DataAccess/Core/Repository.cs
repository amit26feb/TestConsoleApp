// <copyright file="Repository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System.Collections.Generic;
   using System.Data;
   using System.Linq;
   using System.Reflection;
   using System.Text;
   using System.Threading.Tasks;
   using Dapper;
   using global::DataAccess.Core.Abstractions;
   using global::DataAccess.DBDynamicParameters;
   using global::DataAccess.Paging;
   using TSMT.DataAccess.Models;
   using static Dapper.SqlMapper;

   /// <summary>
   /// An Oracle implementation of a repository
   /// </summary>
   /// <typeparam name="TEntity">The type of data in the repository</typeparam>
   public class Repository<TEntity> : IRepository<TEntity>
       where TEntity : IDataEntity
   {
      private readonly IConnectionFactory connectionfactory;
      private int? drAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="Repository{TEntity}"/> class.
      /// </summary>
      /// <param name="connectionFactory">The connection factory</param>
      public Repository(IConnectionFactory connectionFactory)
      {
         this.connectionfactory = connectionFactory;
      }

      /// <summary>
      /// Gets a database connection.
      /// Pays attention to a specific DrAddressId if we have been told to do so.
      /// </summary>
      private IDbConnection GetConnection
      {
         get
         {
            if (this.drAddressId.HasValue)
            {
               return this.connectionfactory.GetOpenConnectionForDrAddressId(this.drAddressId.Value);
            }
            else
            {
               return this.connectionfactory.GetConnection();
            }
         }
      }

      /// <inheritdoc/>
      public async Task<T> GetAsync<T>(object id)
      {
         var sql = QueryBuilder.GenerateGetQueryAsync<T>();
         DynamicParameters dynParms = new DynamicParameters();
         dynParms.Add(":id", id);
         using (IDbConnection connection = this.GetConnection)
         {
            var query = await connection.QueryFirstOrDefaultAsync<T>(sql, dynParms);
            return query;
         }
      }

      /// <inheritdoc/>
      public async Task<T> GetAsync<T>(string sql, object parameters)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            var query = await connection.QueryFirstOrDefaultAsync<T>(sql, parameters);
            return query;
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> GetListAsync<T>(object whereConditions)
      {
         string sql = QueryBuilder.GenerateGetListQueryAsync<T>(whereConditions);

         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.QueryAsync<T>(sql, whereConditions);
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> GetListAsync<T>(string conditions)
      {
         string sql = QueryBuilder.GenerateGetListQueryAsync<T>(conditions);

         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.QueryAsync<T>(sql);
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> GetListAsync<T>()
      {
         string sql = QueryBuilder.GenerateGetListQueryAsync<T>();

         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.QueryAsync<T>(sql);
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> GetListAsync<T>(string sql, object parameters)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.QueryAsync<T>(sql, parameters);
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> GetListAsync<T>(PagingOptions pagingOptions)
      {
         QueryResult filterQuery = QueryBuilder.GenerateGetListQueryAsync<T>(pagingOptions);

         using (IDbConnection connection = this.GetConnection)
         {
            if (filterQuery.Parameters.ParameterNames.Any())
            {
               return await connection.QueryAsync<T>(filterQuery.Query, filterQuery.Parameters);
            }

            return await connection.QueryAsync<T>(filterQuery.Query);
         }
      }

      /// <inheritdoc/>
      public async Task<int?> InsertAsync(object entityToInsert)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            return await this.InsertAsync<int?>(entityToInsert);
         }
      }

      /// <inheritdoc/>
      public async Task<bool> InsertAsync<TKey>(IEnumerable<object> entitiesToInsert)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            foreach (var entityToInsert in entitiesToInsert)
            {
               ////Figure out the new primary key value for the entity being inserted
               var name = QueryBuilder.GetTableName(entityToInsert.GetType());
               var nextValQuery = new StringBuilder();
               nextValQuery.AppendFormat("Select {0}_seq.nextval from dual", name);
               var nextVal = await connection.QueryAsync<int>(nextValQuery.ToString());
               string sql = QueryBuilder.GenerateInsertQueryAsync<TKey>(entityToInsert, name, nextVal.First());
               await connection.QueryAsync(sql, entityToInsert);
            }
         }

         return true;
      }

      /// <inheritdoc/>
      public async Task<TKey> InsertAsync<TKey>(object entityToInsert)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            var name = QueryBuilder.GetTableName(entityToInsert.GetType());
            ////Figure out the new primary key value for the entity being inerted

            var nextValQuery = new StringBuilder();
            nextValQuery.AppendFormat("Select {0}_seq.nextval from dual", name);
            var nextVal = connection.QueryAsync<int>(nextValQuery.ToString()).Result.First();
            IEnumerable<PropertyInfo> idProps;
            var sql = QueryBuilder.GenerateInsertQueryAsync<TKey>(entityToInsert, name, nextVal, out idProps);

            await connection.ExecuteAsync(sql, entityToInsert);

            return (TKey)idProps.First().GetValue(entityToInsert, null);
         }
      }

      /// <inheritdoc/>
      public async Task<bool> InsertWithoutKeyAsync<TKey>(object entityToInsert)
      {
         string sql = QueryBuilder.GenerateInsertWithoutKeyQueryAsync(entityToInsert);

         using (IDbConnection connection = this.GetConnection)
         {
            var returnValue = await connection.ExecuteAsync(sql, entityToInsert);
            return returnValue > 0;
         }
      }

      /// <inheritdoc/>
      public Task<int> UpdateAsync(object entityToUpdate)
      {
         string sql = QueryBuilder.GenerateUpdateQueryAsync(entityToUpdate);

         using (IDbConnection connection = this.GetConnection)
         {
            return connection.ExecuteAsync(new CommandDefinition(sql, entityToUpdate));
         }
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateAsync(IEnumerable<object> entitiesToUpdate)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            foreach (var entityToUpdate in entitiesToUpdate)
            {
               string sql = QueryBuilder.GenerateUpdateQueryAsync(entityToUpdate);

               await connection.ExecuteAsync(new CommandDefinition(sql, entityToUpdate));
            }
         }

         return true;
      }

      /// <inheritdoc/>
      public Task<int> DeleteAsync<T>(T entityToDelete)
      {
         string sql = QueryBuilder.GenerateDeleteQueryAsync(entityToDelete);

         using (IDbConnection connection = this.GetConnection)
         {
            return connection.ExecuteAsync(sql, entityToDelete);
         }
      }

      /// <summary>
      /// <para>Deletes a record or records in the database by ID asynchronously</para>
      /// <para>By default deletes records in the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Deletes records where the Id property and properties with the [Key] attribute match those in the database</para>
      /// <para>The number of records effected</para>
      /// <para>Supports transaction and command timeout</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table name.</typeparam>
      /// <param name="id">Deletes records where the Id property and properties with the [Key] attribute match those in the database</param>
      /// <returns>The number of records effected</returns>
      public async Task<int> DeleteAsync<T>(object id)
      {
         var sql = QueryBuilder.GenerateDeleteQueryAsync<T>();

         DynamicParameters dynParms = new DynamicParameters();
         dynParms.Add("Id", id);

         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.ExecuteAsync(sql, dynParms);
         }
      }

      /// <inheritdoc/>
      public async Task<int> ExecuteAsync<T>(string sql, object parameters)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.ExecuteAsync(sql, parameters);
         }
      }

      /// <inheritdoc/>
      public async Task<T> ExecuteQuery<T>(string query)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            var result = await connection.QueryFirstOrDefaultAsync<T>(query);
            return result;
         }
      }

      /// <inheritdoc/>
      public async Task<T> ExecuteQuery<T>(string query, object parameters)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            var result = await connection.QueryFirstOrDefaultAsync<T>(query, parameters);
            return result;
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> ExecuteListQuery<T>(string query)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.QueryAsync<T>(query);
         }
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> ExecuteListQuery<T>(string query, object parameters)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.QueryAsync<T>(query, parameters);
         }
      }

      /// <inheritdoc/>
      public async Task<bool> UpdateAsyncWithoutKey(object entityToUpdate, string condition)
      {
         string sql = QueryBuilder.GenerateUpdateWithoutKeyQueryAsync(entityToUpdate, condition);

         using (IDbConnection connection = this.GetConnection)
         {
            var returnValue = await connection.ExecuteAsync(sql, entityToUpdate);
            return returnValue > 0;
         }
      }

      /// <inheritdoc/>
      public async Task<int> GetListCountAsync<T>(PagingOptions pagingOptions)
      {
         QueryResult filterResult = QueryBuilder.GenerateGetListCountQueryAsync<T>(pagingOptions);

         using (IDbConnection connection = this.GetConnection)
         {
            if (filterResult.Parameters.ParameterNames.Any())
            {
               return await connection.ExecuteScalarAsync<int>(filterResult.Query, filterResult.Parameters);
            }

            return await connection.ExecuteScalarAsync<int>(filterResult.Query);
         }
      }

      /// <inheritdoc/>
      public async Task<int?> GetListCountAsync<T>(string conditions)
      {
         string sql = QueryBuilder.GenerateGetListCountQueryAsync<T>(conditions);

         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.ExecuteScalarAsync<int>(sql);
         }
      }

      /// <inheritdoc/>
      public async Task<int?> GetListCountAsync<T>(string sql, object parameters)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            return await connection.ExecuteScalarAsync<int>(sql, parameters);
         }
      }

      /// <inheritdoc/>
      public QueryResult BuildFilterClause<T>(List<FilterCollection> filters, string paramName = "")
      {
         return QueryBuilder.BuildFilterClause<T>(filters, paramName);
      }

      /// <inheritdoc/>
      public string BuildSortClause<T>(List<Sort> sortList)
      {
         return QueryBuilder.BuildSortClause<T>(sortList);
      }

      /// <inheritdoc/>
      public void HonorDrAddressId(int? drAddressId)
      {
         this.drAddressId = drAddressId;
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<T>> QueryStoredProcedureAsync<T>(string procedureName, List<ParamInfo> parameters)
      {
         using (IDbConnection connection = this.connectionfactory.GetConnection())
         {
            var dynamicParameters = new OracleDynamicParameters();
            parameters.ToList().ForEach(param =>
            {
               dynamicParameters.Add(param.Name, param.Value, dbType: param.DbType, direction: param.ParameterDirection);
            });

            var result = await connection.QueryAsync<T>(procedureName, param: dynamicParameters, commandType: CommandType.StoredProcedure);

            parameters.ForEach(param =>
            {
               if (param.ParameterDirection == ParameterDirection.Output || param.ParameterDirection == ParameterDirection.InputOutput)
               {
                  ParamInfo parameter = dynamicParameters.GetParameter(param.Name);
                  param.Value = parameter?.AttachedParam?.Value?.ToString();
               }
            });

            return result;
         }
      }

      /// <inheritdoc/>
      public async Task<int> ExecuteStoredProcedureAsync(string procedureName, List<ParamInfo> parameters)
      {
         using (IDbConnection connection = this.GetConnection)
         {
            OracleDynamicParameters dynamicParameters = new OracleDynamicParameters();
            foreach (ParamInfo param in parameters)
            {
               dynamicParameters.Add(param.Name, param.Value, dbType: param.DbType, direction: param.ParameterDirection, param.Size);
            }

            var result = await connection.ExecuteAsync(procedureName, param: dynamicParameters, commandType: CommandType.StoredProcedure);

            parameters.ForEach(param =>
            {
               if (param.ParameterDirection == ParameterDirection.Output || param.ParameterDirection == ParameterDirection.InputOutput)
               {
                  ParamInfo parameter = dynamicParameters.GetParameter(param.Name);
                  param.Value = parameter?.AttachedParam?.Value?.ToString();
               }
            });

            return result;
         }
      }

      /// <inheritdoc/>
      public async Task<int> ExecuteStoredProcedureAsync(object procedureModel)
      {
         QueryBuilder.BuildStoreProcedureArguments(procedureModel, out var procName, out var procParams);

         OracleDynamicParameters dynamicParameters = new OracleDynamicParameters();
         foreach (ParamInfo param in procParams)
         {
            dynamicParameters.Add(param.Name, param.Value, dbType: param.DbType, direction: param.ParameterDirection, param.Size);
         }

         using (IDbConnection connection = this.GetConnection)
         {
            var result = await connection.ExecuteAsync(procName, param: dynamicParameters, commandType: CommandType.StoredProcedure);

            procParams.ToList().ForEach(param =>
            {
               if (param.ParameterDirection == ParameterDirection.Output || param.ParameterDirection == ParameterDirection.InputOutput)
               {
                  ParamInfo parameter = dynamicParameters.GetParameter(param.Name);
                  param.Value = parameter?.AttachedParam?.Value?.ToString();
               }
            });

            return result;
         }
      }
   }
}
