// <copyright file="QueryBuilder.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Globalization;
   using System.Linq;
   using System.Reflection;
   using System.Text;
   using Dapper;
   using global::DataAccess.DBDynamicParameters;
   using global::DataAccess.Paging;
   using Paging;
   using TSMT.DataAccess.Attributes;
   using TSMT.DataAccess.Models;

   /// <summary>
   /// Class for Query Builder
   /// </summary>
   public static class QueryBuilder
   {
      public static string GenerateGetQueryAsync<T>()
      {
         var currenttype = typeof(T);
         var idProps = PropertyInfoExtension.GetIdProperties(currenttype).ToList();

         if (!idProps.Any())
         {
            throw new ArgumentException("Get<T> only supports an entity with a [Key] or Id property");
         }

         if (idProps.Count > 1)
         {
            throw new ArgumentException("Get<T> only supports an entity with a single [Key] or Id property");
         }

         var onlyKey = idProps.First();
         var name = GetTableName(currenttype);

         var sb = new StringBuilder();
         sb.Append("Select ");
         ////create a new empty instance of the type to get the base properties
         BuildSelect(sb, GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray());
         sb.AppendFormat(" from {0}", name);
         sb.Append(" where " + onlyKey.GetColumnName() + " = :Id");
         return sb.ToString();
      }

      public static string GenerateGetListQueryAsync<T>(object whereConditions)
      {
         var currenttype = typeof(T);
         var idProps = PropertyInfoExtension.GetIdProperties(currenttype).ToList();

         if (!idProps.Any())
         {
            throw new ArgumentException("Entity must have at least one [Key] property");
         }

         var name = GetTableName(currenttype);

         var sb = new StringBuilder();
         var whereprops = PropertyInfoExtension.GetAllProperties(whereConditions).ToArray();
         sb.Append("Select ");
         ////create a new empty instance of the type to get the base properties
         BuildSelect(sb, GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray());
         sb.AppendFormat(" from {0}", name);

         if (whereprops.Any())
         {
            sb.Append(" where ");
            BuildWhere(sb, whereprops, (T)Activator.CreateInstance(typeof(T)));
         }

         return sb.ToString();
      }

      public static string GenerateGetListQueryAsync<T>(string conditions)
      {
         var currenttype = typeof(T);
         var idProps = PropertyInfoExtension.GetIdProperties(currenttype).ToList();
         if (!idProps.Any())
         {
            throw new ArgumentException("Entity must have at least one [Key] property");
         }

         var name = GetTableName(currenttype);

         var sb = new StringBuilder();
         sb.Append("Select ");

         // create a new empty instance of the type to get the base properties
         BuildSelect(sb, GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray());
         sb.AppendFormat(" from {0}", name);

         sb.Append(" " + conditions);

         return sb.ToString();
      }

      public static string GenerateGetListQueryAsync<T>()
      {
         var currenttype = typeof(T);
         var name = GetTableName(currenttype);
         var sb = new StringBuilder();
         sb.Append("Select ");
         BuildSelect(sb, GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray());
         sb.AppendFormat(" from {0}", name);
         return sb.ToString();
      }

      /// <summary>
      /// Builds the query and parameters based on the paging options filter and sort list
      /// </summary>
      /// <typeparam name="T">The object type</typeparam>
      /// <param name="pagingOptions">The paging options containing the filter, sort, skip and take parameters</param>
      /// <returns>The query result object with the parameterised query and dynamic parameters</returns>
      public static QueryResult GenerateGetListQueryAsync<T>(PagingOptions pagingOptions)
      {
         QueryResult filterQuery = new QueryResult();
         if (pagingOptions.Sort == null)
         {
            pagingOptions.Sort = new List<Sort>();
         }

         var currenttype = typeof(T);
         var idProps = PropertyInfoExtension.GetIdProperties(currenttype).ToList();

         if (!idProps.Any())
         {
            throw new ArgumentException("Entity must have at least one [Key] property");
         }

         var name = GetTableName(currenttype);

         var sb = new StringBuilder();
         sb.Append("SELECT * FROM (SELECT b.*, rownum AS rnum FROM(SELECT ");
         ////create a new empty instance of the type to get the base properties

         var props = GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray();

         var propertyInfos = props as IList<PropertyInfo> ?? props.ToList();
         for (var i = 0; i < propertyInfos.Count(); i++)
         {
            sb.Append("a." + propertyInfos.ElementAt(i).GetColumnName());
            ////if there is a custom column name add an "as customcolumnname" to the item so it maps properly
            if (propertyInfos.ElementAt(i).GetCustomAttributes(true).SingleOrDefault(attr => attr.GetType().Name == "ColumnAttribute") != null)
            {
               sb.Append(" as " + propertyInfos.ElementAt(i).Name + " ");
            }

            if (i < propertyInfos.Count() - 1)
            {
               sb.Append(",");
            }
         }

         sb.AppendFormat(" from {0} a", name);

         if (pagingOptions.Filters != null && pagingOptions.Filters.Count > 0)
         {
            filterQuery = BuildFilterClause<T>(pagingOptions.Filters);
            if (!string.IsNullOrEmpty(filterQuery.Query))
            {
               sb.Append(filterQuery.Query);
            }
         }

         if (pagingOptions.Sort != null && pagingOptions.Sort.Count > 0)
         {
            string sort = BuildSortClause<T>(pagingOptions.Sort);
            if (!string.IsNullOrEmpty(sort))
            {
               sb.Append(" order by " + sort + " NULLS LAST");
            }
         }

         sb.Append(") b");
         sb.Append($" WHERE rownum <= :Take) c");
         filterQuery.Parameters.Add($"Take", pagingOptions.Take + pagingOptions.Skip);
         sb.Append($" WHERE rnum >= :Skip");
         filterQuery.Parameters.Add($"Skip", pagingOptions.Skip + 1);
         filterQuery.Query = sb.ToString();
         return filterQuery;
      }

      public static string GenerateInsertWithoutKeyQueryAsync(object entityToInsert)
      {
         var name = GetTableName(entityToInsert.GetType());
         var sb = new StringBuilder();
         sb.AppendFormat("insert into {0}", name);
         sb.Append(" (");
         BuildInsertParameters(entityToInsert, sb);
         sb.Append(") ");
         sb.Append("values");
         sb.Append(" (");
         BuildInsertValuesWithOutKey(entityToInsert, sb);
         sb.Append(")");
         return sb.ToString();
      }

      public static string GenerateUpdateQueryAsync(object entityToUpdate)
      {
         var idProps = PropertyInfoExtension.GetIdProperties(entityToUpdate).ToList();

         if (!idProps.Any())
         {
            throw new ArgumentException("Entity must have at least one [Key] or Id property");
         }

         var name = GetTableName(entityToUpdate.GetType());

         var sb = new StringBuilder();
         sb.AppendFormat("update {0}", name);

         sb.Append(" set ");
         BuildUpdateSet(entityToUpdate, sb);
         sb.Append(" where ");
         BuildWhere(sb, idProps, entityToUpdate);
         return sb.ToString();
      }

      public static string GenerateDeleteQueryAsync<T>(T entityToDelete)
      {
         var idProps = PropertyInfoExtension.GetIdProperties(entityToDelete).ToList();

         if (!idProps.Any())
         {
            throw new ArgumentException("Entity must have at least one [Key] or Id property");
         }

         var name = GetTableName(entityToDelete.GetType());

         var sb = new StringBuilder();
         sb.AppendFormat("delete from {0}", name);

         sb.Append(" where ");
         BuildWhere(sb, idProps, entityToDelete);

         return sb.ToString();
      }

      public static string GenerateDeleteQueryAsync<T>()
      {
         var currenttype = typeof(T);
         var idProps = PropertyInfoExtension.GetIdProperties(currenttype).ToList();

         if (!idProps.Any())
         {
            throw new ArgumentException("Delete<T> only supports an entity with a [Key] or Id property");
         }

         if (idProps.Count > 1)
         {
            throw new ArgumentException("Delete<T> only supports an entity with a single [Key] or Id property");
         }

         var onlyKey = idProps.First();
         var name = GetTableName(currenttype);

         var sb = new StringBuilder();
         sb.AppendFormat("Delete from {0}", name);
         sb.Append(" where " + onlyKey.GetColumnName() + " = :Id");
         return sb.ToString();
      }

      public static string GenerateUpdateWithoutKeyQueryAsync(object entityToUpdate, string condition)
      {
         var name = GetTableName(entityToUpdate.GetType());

         var sb = new StringBuilder();
         sb.AppendFormat("update {0}", name);

         sb.Append(" set ");
         BuildUpdateSet(entityToUpdate, sb);
         sb.Append(" where ");
         sb.Append(condition);

         return sb.ToString();
      }

      public static QueryResult GenerateGetListCountQueryAsync<T>(PagingOptions pagingOptions)
      {
         var currenttype = typeof(T);
         var name = GetTableName(currenttype);
         var sb = new StringBuilder();
         QueryResult filterQuery = new QueryResult();
         sb.AppendFormat("Select count(*) from {0}", name);

         if (pagingOptions.Filters != null && pagingOptions.Filters.Count > 0)
         {
            filterQuery = BuildFilterClause<T>(pagingOptions.Filters);
            if (!string.IsNullOrEmpty(filterQuery.Query))
            {
               sb.Append(filterQuery.Query);
            }
         }

         filterQuery.Query = sb.ToString();
         return filterQuery;
      }

      public static string GenerateGetListCountQueryAsync<T>(string conditions)
      {
         var currenttype = typeof(T);
         var name = GetTableName(currenttype);

         var sb = new StringBuilder();
         sb.Append("Select count(*) ");
         ////create a new empty instance of the type to get the base properties
         BuildSelect(sb, GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray());
         sb.AppendFormat(" from {0}", name);
         sb.Append(" " + conditions);
         return sb.ToString();
      }

      public static string GenerateInsertQueryAsync<TKey>(object entityToInsert, object name, int nextVal)
      {
         var idProps = PropertyInfoExtension.GetIdProperties(entityToInsert).ToList();
         if (!idProps.Any())
         {
            throw new ArgumentException("Insert<T> only supports an entity with a [Key] or Id property");
         }

         if (idProps.Count > 1)
         {
            throw new ArgumentException("Insert<T> only supports an entity with a single [Key] or Id property");
         }

         var baseType = typeof(TKey);
         var underlyingType = Nullable.GetUnderlyingType(baseType);
         var keytype = underlyingType ?? baseType;
         if (keytype != typeof(int) && keytype != typeof(uint) && keytype != typeof(long) && keytype != typeof(ulong) && keytype != typeof(short) && keytype != typeof(ushort) && keytype != typeof(Guid))
         {
            throw new System.Data.DataException("Invalid return type");
         }

         var sb = new StringBuilder();
         sb.AppendFormat("insert into {0}", name);
         sb.Append(" (");
         BuildInsertParameters(entityToInsert, sb);
         sb.Append(") ");
         sb.Append("values");
         sb.Append(" (");

         BuildInsertValues(entityToInsert, sb, nextVal);

         sb.Append(")");
         return sb.ToString();
      }

      public static string GenerateInsertQueryAsync<TKey>(object entityToInsert, object name, int nextVal, out IEnumerable<PropertyInfo> idProps)
      {
         idProps = PropertyInfoExtension.GetIdProperties(entityToInsert).ToList();
         if (!idProps.Any())
         {
            throw new ArgumentException("Insert<T> only supports an entity with a [Key] or Id property");
         }

         if (idProps.Count() > 1)
         {
            throw new ArgumentException("Insert<T> only supports an entity with a single [Key] or Id property");
         }

         var baseType = typeof(TKey);
         var underlyingType = Nullable.GetUnderlyingType(baseType);
         var keytype = underlyingType ?? baseType;
         if (keytype != typeof(int) && keytype != typeof(uint) && keytype != typeof(long) && keytype != typeof(ulong) && keytype != typeof(short) && keytype != typeof(ushort) && keytype != typeof(Guid))
         {
            throw new System.Data.DataException("Invalid return type");
         }

         var sb = new StringBuilder();
         sb.AppendFormat("insert into {0}", name);
         sb.Append(" (");
         BuildInsertParameters(entityToInsert, sb);
         sb.Append(") ");
         sb.Append("values");
         sb.Append(" (");

         BuildInsertValues(entityToInsert, sb, nextVal);

         sb.Append(")");

         return sb.ToString();
      }

      ////Gets the table name for this type
      ////For Get(id) and Delete(id) we don't have an entity, just the type so this method is used
      ////Use dynamic type to be able to handle both our Table-attribute and the DataAnnotation
      ////Uses class name by default and overrides if the class has a Table attribute
      public static string GetTableName(Type type)
      {
         var tableName = string.Format("{0}", type.Name);

         var tableattr = type.GetCustomAttributes(true).SingleOrDefault(attr => attr.GetType().Name == "TableAttribute") as dynamic;
         if (tableattr != null)
         {
            tableName = string.Format("{0}", tableattr.Name);
         }

         return tableName;
      }

      /// <summary>
      /// Build Filter Clause
      /// </summary>
      /// <param name="filters">Filter Keys</param>
      /// <param name="paramName">Optional name for the parameter in parameterized query</param>
      /// <typeparam name="T">Generic param</typeparam>
      /// <returns>Query result</returns>
      public static QueryResult BuildFilterClause<T>(List<FilterCollection> filters, string paramName = "")
      {
         QueryResult filterQuery = new QueryResult();
         if (filters.Any())
         {
            StringBuilder sb = new StringBuilder();
            sb.Append(" where ");
            var props = QueryBuilder.GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray();
            var propertyInfos = props as IList<PropertyInfo> ?? props.ToList();
            int loopCount = 0;
            filterQuery.Parameters = new DynamicParameters();
            foreach (var filter in filters)
            {
               BuildFilterString(sb, filter, loopCount, propertyInfos, ref filterQuery, paramName);
               loopCount++;
            }

            filterQuery.Query = sb.ToString();
         }

         return filterQuery;
      }

      /// <summary>
      /// Method to build the order by string based on the sort object
      /// </summary>
      /// <param name="sorts">The list of sort objects</param>
      /// <typeparam name="T">generic param</typeparam>
      /// <returns>the order by string</returns>
      public static string BuildSortClause<T>(List<Sort> sorts)
      {
         string sortQuery = string.Empty;
         if (sorts.Any())
         {
            StringBuilder stringBuilder = new StringBuilder();
            var props = QueryBuilder.GetScaffoldableProperties((T)Activator.CreateInstance(typeof(T))).ToArray();
            var propertyInfos = props as IList<PropertyInfo> ?? props.ToList();
            int loopCount = 0;
            foreach (Sort sort in sorts)
            {
               // Get the formatted sort query for the sort object
               BuildSortString(stringBuilder, sort, loopCount, propertyInfos);
               loopCount++;
            }

            sortQuery = stringBuilder.ToString();
         }

         return sortQuery;
      }

      /// <summary>
      /// Builds arguments used to execute a stored procedure
      /// </summary>
      /// <param name="procModel">The procedure model</param>
      /// <param name="procName">The outgoing procedure name</param>
      /// <param name="procParams">The outgoing procedure params</param>
      public static void BuildStoreProcedureArguments(object procModel, out string procName, out IEnumerable<ParamInfo> procParams)
      {
         Type modelType = procModel.GetType();

         // Set the procedure name to the value in the model's procedure attribute.
         // If that is null use the name of the class.
         ProcedureAttribute procAttr = modelType.GetCustomAttribute<ProcedureAttribute>();
         procName = procAttr?.Name ?? modelType.Name;

         // Set the procedure parameters from the model's properties.
         List<ParamInfo> procParamsList = new List<ParamInfo>();
         foreach (PropertyInfo property in modelType.GetProperties())
         {
            // Set the procedure name to the value in the property's parameter attribute.
            // If that is null use the name of the property.
            ProcedureParameterAttribute paramAttr = property.GetCustomAttribute<ProcedureParameterAttribute>();
            string paramName = paramAttr?.Name ?? property.Name;
            object paramValue = property.GetValue(procModel);

            procParamsList.Add(new ParamInfo
            {
               Name = paramName,
               Value = paramValue,
               DbType = paramAttr?.Type,
               Size = paramAttr?.Size,
               ParameterDirection = paramAttr?.Direction ?? ParameterDirection.Input
            });
         }

         procParams = procParamsList;
      }

      ////Get all properties that are not decorated with the Editable(false) attribute
      private static IEnumerable<PropertyInfo> GetScaffoldableProperties(object entity)
      {
         var props = entity.GetType().GetProperties().Where(p => !p.GetCustomAttributes(true).Any(attr => attr.GetType().Name == "EditableAttribute" && !p.IsEditable()));
         return props.Where(p => p.PropertyType.IsSimpleType() || p.IsEditable());
      }

      ////Get all properties that are NOT named Id, DO NOT have the Key attribute, and are not marked ReadOnly
      private static IEnumerable<PropertyInfo> GetUpdateableProperties(object entity)
      {
         var updateableProperties = GetScaffoldableProperties(entity);
         ////remove ones with ID
         updateableProperties = updateableProperties.Where(p => p.Name != "Id");
         ////remove ones with key attribute
         updateableProperties = updateableProperties.Where(p => !p.GetCustomAttributes(true).Any(attr => attr.GetType().Name == "KeyAttribute"));
         ////remove ones that are readonly
         updateableProperties = updateableProperties.Where(p => !p.GetCustomAttributes(true).Any(attr => (attr.GetType().Name == "ReadOnlyAttribute") && p.IsReadOnly()));

         return updateableProperties;
      }

      ////build select clause based on list of properties
      private static void BuildSelect(StringBuilder sb, IEnumerable<PropertyInfo> props)
      {
         var propertyInfos = props as IList<PropertyInfo> ?? props.ToList();
         for (var i = 0; i < propertyInfos.Count(); i++)
         {
            sb.Append(propertyInfos.ElementAt(i).GetColumnName());
            ////if there is a custom column name add an "as customcolumnname" to the item so it maps properly
            if (propertyInfos.ElementAt(i).GetCustomAttributes(true).SingleOrDefault(attr => attr.GetType().Name == "ColumnAttribute") != null)
            {
               sb.Append(" as " + propertyInfos.ElementAt(i).Name + " ");
            }

            if (i < propertyInfos.Count() - 1)
            {
               sb.Append(",");
            }
         }
      }

      ////build where clause based on list of properties
      private static void BuildWhere(StringBuilder sb, IEnumerable<PropertyInfo> idProps, object sourceEntity)
      {
         var propertyInfos = idProps.ToArray();
         for (var i = 0; i < propertyInfos.Count(); i++)
         {
            ////match up generic properties to source entity properties to allow fetching of the column attribute
            ////the anonymous object used for search doesn't have the custom attributes attached to them so this allows us to build the correct where clause
            ////by converting the model type to the database column name via the column attribute
            var propertyToUse = propertyInfos.ElementAt(i);
            var sourceProperties = GetScaffoldableProperties(sourceEntity).ToArray();
            for (var x = 0; x < sourceProperties.Count(); x++)
            {
               if (sourceProperties.ElementAt(x).Name == propertyInfos.ElementAt(i).Name)
               {
                  propertyToUse = sourceProperties.ElementAt(x);
               }
            }

            sb.AppendFormat("{0} = :{1}", propertyToUse.GetColumnName(), propertyInfos.ElementAt(i).Name);
            if (i < propertyInfos.Count() - 1)
            {
               sb.Append(" and ");
            }
         }
      }

      /// <summary>
      /// Method to build the order by string based on the sort object
      /// </summary>
      /// <param name="stringBuilder">String builder</param>
      /// <param name="sort">Sort object</param>
      /// <param name="loopCount">Loop count</param>
      /// <param name="propertyInfos">Property info</param>
      private static void BuildSortString(StringBuilder stringBuilder, Sort sort, int loopCount, IList<PropertyInfo> propertyInfos)
      {
         // Check the loop count to whether add a comma delimited between sort values
         if (loopCount != 0)
         {
            stringBuilder.Append(", ");
         }

         // Get the data type of the sortby property
         Type sortDataType = propertyInfos.FirstOrDefault(x => x.Name.ToLower() == sort.SortBy?.ToLower())?.PropertyType;
         string sortDirection = sort.SortDirection == SortDirection.Ascending ? "asc" : "desc";

         // Check the sort by data type
         // If sort by data type string then add a upper to the sort property to avoid sorting issues on string data type
         stringBuilder.Append(sortDataType == typeof(string) ? $"upper({sort.SortBy}) {sortDirection}" : sort.SortBy + " " + sortDirection);
      }

      private static void BuildFilterString(StringBuilder sb, FilterCollection filter, int loopCount, IList<PropertyInfo> propertyInfos, ref QueryResult filterQuery, string paramName = "")
      {
         if (loopCount != 0)
         {
            sb.Append(" AND");
         }

         if (filter.Filters.Count > 1)
         {
            sb.Append(" (");
            var last = filter.Filters.Last();
            foreach (var item in filter.Filters)
            {
               Type fieldType = propertyInfos.FirstOrDefault(x => x.Name.ToLower() == item.Field?.ToLower())?.PropertyType;
               BuildFilterString(sb, item.Field, item.Operator, item.Value, fieldType, ref filterQuery, paramName);

               if (!item.Equals(last))
               {
                  sb.AppendFormat(" {0}", filter.Logic);
               }
            }

            sb.Append(")");
         }

         // Only one filter is available. Pass the filter parameters without the filter.Logic and sb.append "(" and sb.append ")"
         else
         {
            Type fieldType = propertyInfos.FirstOrDefault(x => x.Name.ToLower() == filter.Filters.FirstOrDefault()?.Field.ToLower())?.PropertyType;
            BuildFilterString(sb, filter.Filters[0].Field ?? string.Empty, filter.Filters[0].Operator ?? string.Empty, filter.Filters[0].Value ?? string.Empty, fieldType, ref filterQuery, paramName);
         }
      }

      private static void BuildFilterString(StringBuilder sb, string field, string operant, string value, Type fieldType, ref QueryResult filterQuery, string paramName = "")
      {
         bool isDateTimeString = false;
         bool isEscapeSqe = false;
         int count = filterQuery.Parameters.ParameterNames.Count();
         string param = string.IsNullOrWhiteSpace(paramName) ? $":Field{count}" : ":" + paramName + count;
         string paramValue = string.Empty;
         if (fieldType == typeof(DateTime) || fieldType == typeof(DateTime?))
         {
            isDateTimeString = true;
            value = DateTime.Parse(value).ToString("dd-MMM-yy", CultureInfo.InvariantCulture);
         }

         FilterOperators enumOperant = (FilterOperators)Enum.Parse(typeof(FilterOperators), operant, true);
         string sqlOperant = FilterOperatorUtility.GetOperatorConversion(enumOperant);

         if (fieldType == typeof(string) && value != null && (value.Contains(@"_") || value.Contains(@"%")) && sqlOperant != "=" && sqlOperant != "!=")
         {
            isEscapeSqe = true;
            value = value.Replace("_", @"\_");
            value = value.Replace("%", @"\%");
         }

         string operantAsLower = operant.ToLower();
         if (operantAsLower.Equals(FilterOperators.IsNull.ToString().ToLower()) || operantAsLower.Equals(FilterOperators.IsNotNull.ToString().ToLower())
             || operantAsLower.Equals(FilterOperators.IsEmpty.ToString().ToLower()) || operantAsLower.Equals(FilterOperators.IsNotEmpty.ToString().ToLower()))
         {
            sb.AppendFormat($" {field} is {sqlOperant}");
         }
         else if (operantAsLower.Equals(FilterOperators.Startswith.ToString().ToLower()))
         {
            paramValue = value.ToLower() + sqlOperant;
            sb.Append($" lower({field}) like {param}");
         }
         else if (operantAsLower.Equals(FilterOperators.Endswith.ToString().ToLower()))
         {
            paramValue = sqlOperant + value.ToLower();
            sb.Append($" lower({field}) like {param}");
         }
         else if (operantAsLower.Equals(FilterOperators.Contains.ToString().ToLower()) || operantAsLower.Equals(FilterOperators.Doesnotcontain.ToString().ToLower()))
         {
            paramValue = "%" + value.ToLower() + "%";
            sb.Append($" lower({field}) {sqlOperant} {param}");
         }
         else if (!(fieldType == typeof(string) || fieldType == typeof(DateTime) || fieldType == typeof(DateTime?)))
         {
            paramValue = value;
            sb.Append($" {field} {sqlOperant} {param}");
         }
         else
         {
            if (isDateTimeString)
            {
               paramValue = value;
               sb.Append($" TRUNC({field}) {sqlOperant} {param}");
            }
            else
            {
               paramValue = value.ToLower();
               sb.Append($" lower({field}) {sqlOperant} {param}");
            }
         }

         if (!string.IsNullOrEmpty(paramValue))
         {
            filterQuery.Parameters.Add(param.Remove(0, 1), paramValue);
         }

         if (isEscapeSqe)
         {
            sb.Append(@" ESCAPE '\'");
         }
      }

      ////build insert values which include all properties in the class that are not marked with the Editable(false) attribute,
      ////are not marked with the [Key] attribute, and are not named Id
      private static void BuildInsertValues(object entityToInsert, StringBuilder sb, int nextVal)
      {
         var props = GetScaffoldableProperties(entityToInsert).ToArray();
         for (var i = 0; i < props.Count(); i++)
         {
            var property = props.ElementAt(i);
            if (property.PropertyType != typeof(Guid) && property.GetCustomAttributes(true).Any(attr => attr.GetType().Name == "KeyAttribute"))
            {
               property.SetValue(entityToInsert, nextVal);
            }

            sb.AppendFormat(":{0}", property.Name);
            if (i < props.Count() - 1)
            {
               sb.Append(", ");
            }
         }

         if (sb.ToString().EndsWith(", "))
         {
            sb.Remove(sb.Length - 2, 2);
         }
      }

      ////build insert values which include all properties in the class that are not marked with the Editable(false) attribute
      private static void BuildInsertValuesWithOutKey(object entityToInsert, StringBuilder sb)
      {
         var props = GetScaffoldableProperties(entityToInsert).ToArray();
         for (var i = 0; i < props.Count(); i++)
         {
            var property = props.ElementAt(i);
            sb.AppendFormat(":{0}", property.Name);
            if (i < props.Count() - 1)
            {
               sb.Append(", ");
            }
         }

         if (sb.ToString().EndsWith(", "))
         {
            sb.Remove(sb.Length - 2, 2);
         }
      }

      ////build insert parameters which include all properties in the class that are not marked with the Editable(false) attribute,
      ////are not marked with the [Key] attribute, and are not named Id
      private static void BuildInsertParameters(object entityToInsert, StringBuilder sb)
      {
         var props = GetScaffoldableProperties(entityToInsert).ToArray();

         for (var i = 0; i < props.Count(); i++)
         {
            var property = props.ElementAt(i);
            ////if (property.PropertyType != typeof(Guid) && property.GetCustomAttributes(true).Any(attr => attr.GetType().Name == "KeyAttribute")) continue;
            ////if (property.Name == "Id") continue;
            sb.Append(property.GetColumnName());
            if (i < props.Count() - 1)
            {
               sb.Append(", ");
            }
         }

         if (sb.ToString().EndsWith(", "))
         {
            sb.Remove(sb.Length - 2, 2);
         }
      }

      ////build update statement based on list on an entity
      private static void BuildUpdateSet(object entityToUpdate, StringBuilder sb)
      {
         var nonIdProps = GetUpdateableProperties(entityToUpdate).ToArray();

         for (var i = 0; i < nonIdProps.Length; i++)
         {
            var property = nonIdProps[i];

            sb.AppendFormat("{0} = :{1}", property.GetColumnName(), property.Name);
            if (i < nonIdProps.Length - 1)
            {
               sb.Append(", ");
            }
         }
      }
   }
}
