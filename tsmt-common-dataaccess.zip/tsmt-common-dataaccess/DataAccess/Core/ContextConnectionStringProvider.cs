// <copyright file="ContextConnectionStringProvider.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Core
{
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using TSMT.Settings;

   /// <summary>
   /// Configuration Wrapper
   /// </summary>
   public class ContextConnectionStringProvider : DataAccess.Core.Abstractions.IDatabaseInfoProvider
   {
      private readonly HttpContext context;
      private readonly IHttpContextAccessor httpContextAccessor;
      private readonly TSMTSettings settings;
      private readonly ILogger<ContextConnectionStringProvider> logger;

      /// <summary>
      /// Initializes a new instance of the <see cref="ContextConnectionStringProvider"/> class.
      /// </summary>
      /// <param name="options">The application settings</param>
      /// <param name="httpContextAccessor">Access to HttpContext</param>
      /// <param name="logger">Class logger.</param>
      public ContextConnectionStringProvider(IOptions<TSMTSettings> options, IHttpContextAccessor httpContextAccessor, ILogger<ContextConnectionStringProvider> logger)
      {
         this.httpContextAccessor = httpContextAccessor;
         this.settings = options.Value;
         this.logger = logger;
      }

      /// <summary>
      /// Gets the name of the HTTP Header utilized for context switching.
      /// </summary>
      public static string HeaderName
      {
         get { return "X-API-DB-ID"; }
      }

      /// <inheritdoc/>
      public string ConnectionString
      {
         get
         {
            string connectionString = null;
            string headerValue = this.httpContextAccessor.HttpContext?.Request.Headers[HeaderName];
            if (string.IsNullOrWhiteSpace(headerValue))
            {
               connectionString = this.settings.VPNDBConnectionString;
            }
            else
            {
               switch (headerValue.ToLowerInvariant())
               {
                  case "bupd":
                     connectionString = this.settings.BUPDConnectionString;
                     break;
                  case "d9":
                     connectionString = this.settings.ESTRND9ConnectionString;
                     break;
                  case "t3":
                     connectionString = this.settings.ESTRNT3ConnectionString;
                     break;
                  case "t7":
                     connectionString = this.settings.ESTRNT7ConnectionString;
                     break;
                  case "s":
                     connectionString = this.settings.ESTRNSConnectionString;
                     break;
                  case "t":
                     connectionString = this.settings.ESTRNTConnectionString;
                     break;
                  case "d8":
                     connectionString = this.settings.ESTRND8ConnectionString;
                     break;
                  case "d":
                     connectionString = this.settings.ESTRNDConnectionString;
                     break;
                  case "": // header not set
                     connectionString = this.settings.VPNDBConnectionString;
                     break;
                  default:
                     this.logger.LogWarning($"An unexpected value for {HeaderName} was provided: [{headerValue}].  The header will be ignored.");
                     break;
               }

               if (string.IsNullOrWhiteSpace(connectionString))
               {
                  this.logger.LogInformation($"{HeaderName} was set to [{headerValue}] but the corresponding connection string is not configured.  The header will be ignored.");
                  connectionString = this.settings.VPNDBConnectionString;
               }
            }

            return connectionString;
         }
      }
   }
}
