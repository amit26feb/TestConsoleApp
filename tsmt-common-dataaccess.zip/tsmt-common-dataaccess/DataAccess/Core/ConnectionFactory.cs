// <copyright file="ConnectionFactory.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Core.Infrastructure
{
   using System;
   using System.Data;
   using DataAccess.Core.Abstractions;
   using Oracle.ManagedDataAccess.Client;

   /// <summary>
   /// Connection Factory
   /// </summary>
   public class ConnectionFactory : IConnectionFactory
   {
      private readonly IDatabaseInfoProvider dbInfoProvider;
      private readonly bool doHonorDrAddressId;

      /// <summary>
      /// Initializes a new instance of the <see cref="ConnectionFactory"/> class.
      /// connection factory constructor
      /// </summary>
      /// <param name="dbInfoProvider">interface for getting the connection string</param>
      /// <param name="doHonorDrAddressId">indicates whether the generated connections should honor a DrAddressId</param>
      public ConnectionFactory(IDatabaseInfoProvider dbInfoProvider, bool doHonorDrAddressId = false)
      {
         this.dbInfoProvider = dbInfoProvider;
         this.doHonorDrAddressId = doHonorDrAddressId;
      }

      /// <inheritdoc/>
      public IDbConnection GetConnection()
      {
         // Ensure that we are not supposed to be honoring a DrAddressId.
         if (this.doHonorDrAddressId)
         {
            throw new InvalidOperationException("The ConnectionFactory is configured to require a DrAddressId to honor when generating a new connection.");
         }

         return new OracleConnection(this.dbInfoProvider.ConnectionString);
      }

      /// <inheritdoc/>
      public IDbConnection GetOpenConnectionForDrAddressId(int drAddressId)
      {
         // Ensure that we are supposed to be honoring a DrAddressId.
         if (!this.doHonorDrAddressId)
         {
            throw new InvalidOperationException("The ConnectionFactory is not expecting a DrAddressId to honor when generating a new connection.");
         }

         var cn = new OracleConnection(this.dbInfoProvider.ConnectionString);

         // The DrAddressId is conveyed to the database server via the ClientInfo.
         // Unfortunately, the connection has to actually be open, before we can set the ClientInfo.
         cn.Open();
         cn.ClientInfo = string.Format("dra:{0}", drAddressId);

         return cn;
      }

      /// <inheritdoc/>
      public bool IsHonoringDrAddressId()
      {
         return this.doHonorDrAddressId;
      }
   }
}
