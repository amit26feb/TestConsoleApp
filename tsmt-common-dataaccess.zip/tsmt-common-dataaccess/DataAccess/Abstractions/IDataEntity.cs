// <copyright file="IDataEntity.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   /// <summary>
   /// Interface class for DataEntity
   /// </summary>
   public interface IDataEntity
    {
    }
}
