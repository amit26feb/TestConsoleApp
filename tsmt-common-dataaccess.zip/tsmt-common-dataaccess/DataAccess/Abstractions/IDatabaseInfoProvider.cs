// <copyright file="IDatabaseInfoProvider.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Core.Abstractions
{
   /// <summary>
   /// Defines the contract for providing database information.
   /// </summary>
   public interface IDatabaseInfoProvider
   {
      /// <summary>
      /// Gets the connection string
      /// </summary>
      string ConnectionString { get; }
   }
}
