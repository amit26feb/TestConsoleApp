// <copyright file="IConnectionFactory.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Core.Abstractions
{
   using System.Data;

   /// <summary>
   /// Interface class for ConnectionFactory
   /// </summary>
   public interface IConnectionFactory
   {
      /// <summary>
      /// Gets a database connection.
      /// </summary>
      /// <returns>A connection to the database.</returns>
      IDbConnection GetConnection();

      /// <summary>
      /// Returns an open database connection that will honor a given DrAddressId.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor</param>
      /// <returns>Open database connection</returns>
      IDbConnection GetOpenConnectionForDrAddressId(int drAddressId);

      /// <summary>
      /// Indicates whether generated connections are expected to honor a DrAddressId.
      /// </summary>
      /// <returns>Boolean indicator</returns>
      bool IsHonoringDrAddressId();
   }
}
