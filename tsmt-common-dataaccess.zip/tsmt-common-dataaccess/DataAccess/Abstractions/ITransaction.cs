﻿// <copyright file="ITransaction.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System;
   using System.Threading.Tasks;

   /// <summary>
   /// A general purpose transaction wrapper.
   /// This supports CRUD operations like a repository --
   /// But with the added benefit of being able to commit/rollback.
   /// </summary>
   public interface ITransaction : IDisposable
   {
      /// <summary>
      /// Applies all operations that have occured since the transaction was created
      /// </summary>
      void Commit();

      /// <summary>
      /// Reverts all operations that have occured since the transaction was created
      /// </summary>
      void Rollback();

      /// <summary>
      /// Reserves a key and stores it on the decorated model.
      /// </summary>
      /// <param name="insertModel">The model of the item that gets a key</param>
      /// <returns>The task</returns>
      Task ReserveKeyAsync(object insertModel);

      /// <summary>
      /// Inserts an item defined by an attribute decorated model.
      /// </summary>
      /// <param name="insertModel">The model of the item to insert</param>
      /// <returns>Count of affected rows</returns>
      Task<int> InsertAsync(object insertModel);

      /// <summary>
      /// Updates an item defined by an attribute decorated model.
      /// </summary>
      /// <param name="updateModel">The model of the item to update</param>
      /// <returns>Count of affected rows</returns>
      Task<int> UpdateAsync(object updateModel);

      /// <summary>
      /// Deletes an item defined by an attribute decorated model.
      /// </summary>
      /// <param name="deleteModel">The model of the item to delete</param>
      /// <returns>Count of affected rows</returns>
      Task<int> DeleteAsync(object deleteModel);

      /// <summary>
      /// Executes a stored procedure defined by an attribute decorated model.
      /// </summary>
      /// <param name="procedureModel">The model of the procedure to execute</param>
      /// <returns>Count of affected rows</returns>
      Task<int> ExecuteProcedureAsync(object procedureModel);
   }
}
