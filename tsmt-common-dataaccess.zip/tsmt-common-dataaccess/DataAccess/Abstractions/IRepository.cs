// <copyright file="IRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using global::DataAccess.DBDynamicParameters;
   using global::DataAccess.Paging;
   using TSMT.DataAccess.Models;

   /// <summary>
   /// Interface class for Repository
   /// </summary>
   /// <typeparam name="TEntity">The type of data in the repository</typeparam>
   public interface IRepository<TEntity>
       where TEntity : IDataEntity
   {
      /// <summary>
      /// <para>By default queries the table matching the class name asynchronously </para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>By default filters on the Id column</para>
      /// <para>-Id column name can be overridden by adding an attribute on your primary key property [Key]</para>
      /// <para>Returns a single entity by a single id from table T</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table name.</typeparam>
      /// <param name="id">By default filters on the Id column.</param>
      /// <returns>Returns a single entity by a single id from table T.</returns>
      Task<T> GetAsync<T>(object id);

      /// <summary>
      /// <para>By default queries the table matching the class name asynchronously </para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>By default filters on the Id column</para>
      /// <para>-Id column name can be overridden by adding an attribute on your primary key property [Key]</para>
      /// <para>Returns a single entity by a single id from table T</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table name.</typeparam>
      /// <param name="sql">Sql query to be executed against the parameters.</param>
      /// <param name="parameters">An anonymous type to filter the results ex: new {Category = 1, SubCategory=2}.</param>
      /// <returns>Returns a single entity by a single id from table T.</returns>
      Task<T> GetAsync<T>(string sql, object parameters);

      /// <summary>
      /// <para>By default queries the table matching the class name asynchronously</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>whereConditions is an anonymous type to filter the results ex: new {Category = 1, SubCategory=2}</para>
      /// <para>Returns a list of entities that match where conditions</para>
      /// </summary>
      /// <typeparam name="T">The class name matching the table name.</typeparam>
      /// <param name="whereConditions">An anonymous type to filter the results ex: new {Category = 1, SubCategory=2}.</param>
      /// <returns>Gets a list of entities</returns>
      Task<IEnumerable<T>> GetListAsync<T>(object whereConditions);

      /// <summary>
      /// <para>By default queries the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>conditions is an SQL where clause and/or order by clause ex: "where name='bob'"</para>
      /// <para>Returns a list of entities that match where conditions</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table name.</typeparam>
      /// <param name="conditions">An SQL where clause and/or order by clause ex: "where name='bob'"</param>
      /// <returns>Gets a list of entities with optional SQL where conditions</returns>
      Task<IEnumerable<T>> GetListAsync<T>(string conditions);

      /// <summary>
      /// <para>By default queries the table matching the class name asynchronously</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Returns a list of all entities</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table.</typeparam>
      /// <returns>Gets a list of all entities</returns>
      Task<IEnumerable<T>> GetListAsync<T>();

      /// <summary>
      /// <para>By default queries the table matching the class name asynchronously</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Returns a list of all entities</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table.</typeparam>
      /// <param name="sql">Query to be executed</param>
      /// <param name="parameters">An anonymous type to filter the results ex: new {Category = 1, SubCategory=2}.</param>
      /// <returns>Gets a list of all entities</returns>
      Task<IEnumerable<T>> GetListAsync<T>(string sql, object parameters);

      /// <summary>
      /// <para>By default queries the table matching the class name asynchronously</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>whereConditions is an anonymous type to filter the results ex: new {Category = 1, SubCategory=2}</para>
      /// <para>Returns a list of entities that match where conditions</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table.</typeparam>
      /// <param name="pagingOptions">Paging options.</param>
      /// <returns>Gets a list of entities with optional exact match where conditions</returns>
      Task<IEnumerable<T>> GetListAsync<T>(PagingOptions pagingOptions);

      /// <summary>
      /// <para>Inserts a row into the database asynchronously</para>
      /// <para>By default inserts into the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Insert filters out Id column and any columns with the [Key] attribute</para>
      /// <para>Properties marked with attribute [Editable(false)] and complex types are ignored</para>
      /// <para>Supports transaction and command timeout</para>
      /// <para>Returns the ID (primary key) of the newly inserted record if it is identity using the int? type, otherwise null</para>
      /// </summary>
      /// <param name="entityToInsert">Entity matching the class name</param>
      /// <returns>The ID (primary key) of the newly inserted record if it is identity using the int? type, otherwise null</returns>
      Task<int?> InsertAsync(object entityToInsert);

      /// <summary>
      /// <para>Inserts a row into the database asynchronously</para>
      /// <para>By default inserts into the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Insert filters out Id column and any columns with the [Key] attribute</para>
      /// <para>Properties marked with attribute [Editable(false)] and complex types are ignored</para>
      /// <para>Supports transaction and command timeout</para>
      /// <para>Returns the ID (primary key) of the newly inserted record if it is identity using the int? type, otherwise null</para>
      /// </summary>
      /// <typeparam name="TKey">The type of the (primary key)</typeparam>
      /// <param name="entitiesToInsert">Entities matching the table name.</param>
      /// <returns>The ID (primary key) of the newly inserted record if it is identity using the int? type, otherwise null</returns>
      Task<bool> InsertAsync<TKey>(IEnumerable<object> entitiesToInsert);

      /// <summary>
      /// <para>Inserts a row into the database asynchronously</para>
      /// <para>By default inserts into the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Insert filters out Id column and any columns with the [Key] attribute</para>
      /// <para>Properties marked with attribute [Editable(false)] and complex types are ignored</para>
      /// <para>Supports transaction and command timeout</para>
      /// <para>Returns the ID (primary key) of the newly inserted record if it is identity using the defined type, otherwise null</para>
      /// </summary>
      /// <typeparam name="TKey">The type of the (primary key)</typeparam>
      /// <param name="entityToInsert">Entity matching the table name.</param>
      /// <returns>The ID (primary key) of the newly inserted record if it is identity using the defined type, otherwise null</returns>
      Task<TKey> InsertAsync<TKey>(object entityToInsert);

      /// <summary>
      /// <para>Inserts a row into the database asynchronously</para>
      /// <para>By default inserts into the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Properties marked with attribute [Editable(false)] and complex types are ignored</para>
      /// <para>Supports transaction and command timeout</para>
      /// </summary>
      /// <param name="entityToInsert">Entity object to be inserted</param>
      /// <returns>return a boolean</returns>
      Task<bool> InsertWithoutKeyAsync<Tkey>(object entityToInsert);

      /// <summary>
      ///  <para>Updates a record or records in the database asynchronously</para>
      ///  <para>By default updates records in the table matching the class name</para>
      ///  <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      ///  <para>Updates records where the Id property and properties with the [Key] attribute match those in the database.</para>
      ///  <para>Properties marked with attribute [Editable(false)] and complex types are ignored</para>
      ///  <para>Supports transaction and command timeout</para>
      ///  <para>Returns number of rows effected</para>
      ///  </summary>
      /// <param name="entityToUpdate">Entity matching the table name.</param>
      /// <returns>The number of effected records</returns>
      Task<int> UpdateAsync(object entityToUpdate);

      /// <summary>
      ///  <para>Updates a record or records in the database asynchronously</para>
      ///  <para>By default updates records in the table matching the class name</para>
      ///  <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      ///  <para>Updates records where the Id property and properties with the [Key] attribute match those in the database.</para>
      ///  <para>Properties marked with attribute [Editable(false)] and complex types are ignored</para>
      ///  <para>Supports transaction and command timeout</para>
      ///  <para>Returns number of rows effected</para>
      ///  </summary>
      /// <param name="entitiesToUpdate">List of entities to be deleted.</param>
      /// <returns>The number of effected records</returns>
      Task<bool> UpdateAsync(IEnumerable<object> entitiesToUpdate);

      /// <summary>
      /// <para>Deletes a record or records in the database that match the object passed in asynchronously</para>
      /// <para>-By default deletes records in the table matching the class name</para>
      /// <para>Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Supports transaction and command timeout</para>
      /// <para>Returns the number of records effected</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table name.</typeparam>
      /// <param name="entityToDelete">Entity name matching the table name.</param>
      /// <returns>The number of records effected</returns>
      Task<int> DeleteAsync<T>(T entityToDelete);

      /// <summary>
      /// <para>Deletes a record or records in the database by ID asynchronously</para>
      /// <para>By default deletes records in the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Deletes records where the Id property and properties with the [Key] attribute match those in the database</para>
      /// <para>The number of records effected</para>
      /// <para>Supports transaction and command timeout</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table name.</typeparam>
      /// <param name="id">Deletes records where the Id property and properties with the [Key] attribute match those in the database</param>
      /// <returns>The number of records effected</returns>
      Task<int> DeleteAsync<T>(object id);

      /// <summary>
      /// <para>Execute a record or records in the database by ID asynchronously</para>
      /// <para>By default deletes records in the table matching the class name</para>
      /// <para>-Table name can be overridden by adding an attribute on your class [Table("YourTableName")]</para>
      /// <para>Execute records where the Id property and properties with the [Key] attribute match those in the database</para>
      /// <para>The number of records effected</para>
      /// <para>Supports transaction and command timeout</para>
      /// </summary>
      /// <typeparam name="T">Class name matching the table name.</typeparam>
      /// <param name="sql">Sql query to be executed</param>
      /// <param name="parameters">An anonymous type to filter the results ex: new {Category = 1, SubCategory=2}</param>
      /// <returns>The number of records effected</returns>
      Task<int> ExecuteAsync<T>(string sql, object parameters);

      /// <summary>
      /// Metho to update the entity for the tables without primary key
      /// </summary>
      /// <param name="entityToUpdate">entityToUpdate</param>
      /// <param name="condition">condition</param>
      /// <returns>int</returns>
      Task<bool> UpdateAsyncWithoutKey(object entityToUpdate, string condition);

      /// <summary>
      /// Method to execute the passed query
      /// </summary>
      /// <typeparam name="T">T</typeparam>
      /// <param name="query">query</param>
      /// <returns>IEnumerable<T></T></returns>
      Task<T> ExecuteQuery<T>(string query);

      /// <summary>
      /// Method to execute the passed query
      /// </summary>
      /// <typeparam name="T">T</typeparam>
      /// <param name="query">query</param>
      /// <param name="parameters">An anonymous type to filter the results ex: new {Category = 1, SubCategory=2}.</param>
      /// <returns>IEnumerable<T></T></returns>
      Task<T> ExecuteQuery<T>(string query, object parameters);

      /// <summary>
      /// ExecuteListQuery
      /// </summary>
      /// <typeparam name="T">generic paran</typeparam>
      /// <param name="query">query</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      Task<IEnumerable<T>> ExecuteListQuery<T>(string query);

      /// <summary>
      /// ExecuteListQuery
      /// </summary>
      /// <typeparam name="T">generic paran</typeparam>
      /// <param name="query">query</param>
      /// <param name="parameters">An anonymous type to filter the results ex: new {Category = 1, SubCategory=2}.</param>
      /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
      Task<IEnumerable<T>> ExecuteListQuery<T>(string query, object parameters);

      /// <summary>
      /// Get the count of change control
      /// as per the filter conditions
      /// </summary>
      /// <typeparam name="T">T</typeparam>
      /// <param name="pagingOptions">Search string</param>
      /// <returns>Total count of the records</returns>
      Task<int> GetListCountAsync<T>(PagingOptions pagingOptions);

      /// <summary>
      /// Method to get the count
      /// </summary>
      /// <typeparam name="T"> T </typeparam>
      /// <param name="conditions"> conditions </param>
      /// <returns> count of items </returns>
      Task<int?> GetListCountAsync<T>(string conditions);

      /// <summary>
      /// Method to get the count
      /// </summary>
      /// <typeparam name="T"> T </typeparam>
      /// <param name="sql">Sql to be executed</param>
      /// <param name="parameters">An anonymous type to filter the results ex: new {Category = 1, SubCategory=2}.</param>
      /// <returns> count of items </returns>
      Task<int?> GetListCountAsync<T>(string sql, object parameters);

      /// <summary>
      /// Build Filter Clause
      /// </summary>
      /// <param name="filters">Filter provided by the users</param>
      /// <param name="paramName">optional name for the parameter in parameterized query</param>
      /// <typeparam name="T">generic param</typeparam>
      /// <returns>parameterised filter by with dynamic paramters</returns>
      QueryResult BuildFilterClause<T>(List<FilterCollection> filters, string paramName = "");

      /// <summary>
      /// Method to build the order by string based on the sort object
      /// </summary>
      /// <param name="sortList">The list of sort objects</param>
      /// <typeparam name="T">generic param</typeparam>
      /// <returns>the order by string</returns>
      string BuildSortClause<T>(List<Sort> sortList);

      /// <summary>
      /// Method to indicate a particular DrAddressId to honor when interacting with the database.
      /// </summary>
      /// <param name="drAddressId">DrAddressId to honor; null indicates a DrAddressId should not be honored</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Executes the given Stored Procedure against the given parameter(s)
      /// </summary>
      /// <typeparam name="T">Domain model to which the resultset to be mapped</typeparam>
      /// <param name="procedureName">Name of the stored procedure or function</param>
      /// <param name="parameters">List of parameters</param>
      /// <returns>Domain model</returns>
      Task<IEnumerable<T>> QueryStoredProcedureAsync<T>(string procedureName, List<ParamInfo> parameters);

      /// <summary>
      /// Executes a stored procedure with parameters.
      /// </summary>
      /// <param name="procedureName">Name of the stored procedure</param>
      /// <param name="parameters">List of parameters</param>
      /// <returns>Count of affected rows</returns>
      Task<int> ExecuteStoredProcedureAsync(string procedureName, List<ParamInfo> parameters);

      /// <summary>
      /// Executes a stored procedure with parameters.
      /// </summary>
      /// <param name="procedureModel">A model of the procedure</param>
      /// <returns>Count of affected rows</returns>
      Task<int> ExecuteStoredProcedureAsync(object procedureModel);
   }
}
