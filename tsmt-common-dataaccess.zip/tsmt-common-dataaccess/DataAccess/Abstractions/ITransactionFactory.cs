﻿// <copyright file="ITransactionFactory.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess
{
   /// <summary>
   /// A factory that creates transactions.
   /// They supports CRUD operations like a repository --
   /// But with the added benefit of being able to commit/rollback.
   /// </summary>
   public interface ITransactionFactory
   {
      /// <summary>
      /// Sets the DRAID used to restrict usable data
      /// </summary>
      /// <param name="drAddressId">the DRAID</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Creates a transaction using a resolved connection
      /// </summary>
      /// <returns>A transaction</returns>
      ITransaction CreateTransaction();
   }
}
