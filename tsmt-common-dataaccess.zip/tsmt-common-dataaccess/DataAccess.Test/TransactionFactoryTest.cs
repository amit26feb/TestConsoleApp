// <copyright file="TransactionFactoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Test
{
   using System.Data;
   using DataAccess.Core.Abstractions;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   public class TransactionFactoryTest
   {
      private readonly TransactionFactory factoryUnderTest;
      private readonly Mock<IDbConnection> mockDraidConnection;
      private readonly Mock<IDbConnection> mockNonDraidConnection;
      private readonly Mock<IConnectionFactory> mockConnectionFactory;

      public TransactionFactoryTest()
      {
         this.mockDraidConnection = new Mock<IDbConnection>();
         this.mockDraidConnection.SetupGet(c => c.ConnectionString).Returns("Draid");
         this.mockNonDraidConnection = new Mock<IDbConnection>();
         this.mockNonDraidConnection.SetupGet(c => c.ConnectionString).Returns("NonDraid");

         this.mockConnectionFactory = new Mock<IConnectionFactory>();
         this.mockConnectionFactory
            .Setup(x => x.GetOpenConnectionForDrAddressId(It.IsAny<int>()))
            .Returns(this.mockDraidConnection.Object);
         this.mockConnectionFactory
            .Setup(x => x.GetConnection())
            .Returns(this.mockNonDraidConnection.Object);

         this.factoryUnderTest = new TransactionFactory(this.mockConnectionFactory.Object);
      }

      [Fact]
      public void CreateTransaction_WithDraid_ReturnsTransactionForDraid()
      {
         this.factoryUnderTest.HonorDrAddressId(920);
         Transaction transaction = this.factoryUnderTest.CreateTransaction() as Transaction;
         Assert.NotNull(transaction);
         Assert.Equal("Draid", transaction.DbConnection.ConnectionString);
      }

      [Fact]
      public void CreateTransaction_WithoutDraid_ReturnsTransactionNotForDraid()
      {
         Transaction transaction = this.factoryUnderTest.CreateTransaction() as Transaction;
         Assert.NotNull(transaction);
         Assert.Equal("NonDraid", transaction.DbConnection.ConnectionString);
      }
   }
}
