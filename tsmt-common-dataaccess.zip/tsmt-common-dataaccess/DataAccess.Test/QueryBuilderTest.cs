// <copyright file="QueryBuilderTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Reflection;
   using global::DataAccess.Paging;
   using Oracle.ManagedDataAccess.Client;
   using TSMT.DataAccess.Models;
   using Xunit;

   public class QueryBuilderTest
   {
      [Fact]
      public void BuildFilterClause_ValidFilterObject_ReturnsQueryResult()
      {
         // Arrange
         List<FilterCollection> filterCollections = new List<FilterCollection>()
            {
                new FilterCollection()
                {
                    Filters = new List<Filter>()
                    {
                        new Filter()
                        {
                            Field = "Skip",
                            Operator = "Eq",
                            Value = "5"
                        }
                    },
                    Logic = "And"
                }
            };

         // Act
         QueryResult result = QueryBuilder.BuildFilterClause<PagingOptions>(filterCollections, "test");

         // Assert
         Assert.NotEmpty(result.Query);
         Assert.Contains(":test0", result.Query);
         Assert.Contains(result.Parameters.ParameterNames, x => x == "test0");
      }

      [Fact]
      public void BuildFilterClause_ModelWithDate_ReturnsQueryResult()
      {
         // Arrange
         List<FilterCollection> filterCollections = new List<FilterCollection>()
            {
                new FilterCollection()
                {
                    Filters = new List<Filter>()
                    {
                        new Filter()
                        {
                            Field = "SOME_DATE_PROP",
                            Operator = "Eq",
                            Value = "1/1/2001"
                        }
                    },
                    Logic = "And"
                }
            };

         // Act
         QueryResult result = QueryBuilder.BuildFilterClause<TestDateModel>(filterCollections, "test");

         // Assert
         Assert.NotEmpty(result.Query);
         Assert.Contains(":test0", result.Query);
         Assert.Contains(result.Parameters.ParameterNames, x => x == "test0");
      }

      [Fact]
      public void BuildFilterClause_ModelWithSpecialStringChars_ReturnsQueryResult()
      {
         // Arrange
         List<FilterCollection> filterCollections = new List<FilterCollection>()
            {
                new FilterCollection()
                {
                    Filters = new List<Filter>()
                    {
                        new Filter()
                        {
                            Field = "SOME_PROP",
                            Operator = "Gt",
                            Value = "A_B_C"
                        }
                    },
                    Logic = "And"
                }
            };

         // Act
         QueryResult result = QueryBuilder.BuildFilterClause<TestModel>(filterCollections, "test");

         // Assert
         Assert.NotEmpty(result.Query);
         Assert.Contains(":test0", result.Query);
         Assert.Contains(result.Parameters.ParameterNames, x => x == "test0");
      }

      [Fact]
      public void BuildFilterClause_TwoFilters_ReturnsQueryResult()
      {
         // Arrange
         List<FilterCollection> filterCollections = new List<FilterCollection>()
            {
                new FilterCollection()
                {
                    Filters = new List<Filter>()
                    {
                        new Filter()
                        {
                            Field = "Skip",
                            Operator = "Eq",
                            Value = "5",
                        },
                        new Filter()
                        {
                            Field = "Bo",
                            Operator = "Eq",
                            Value = "4"
                        }
                    },
                    Logic = "And"
                }
            };

         // Act
         QueryResult result = QueryBuilder.BuildFilterClause<PagingOptions>(filterCollections, "test");

         // Assert
         Assert.NotEmpty(result.Query);
         Assert.Contains(":test0", result.Query);
         Assert.Contains(result.Parameters.ParameterNames, x => x == "test0");
      }

      [Fact]
      public void BuildFilterClause_KitchenSink_ReturnsQueryResult()
      {
         // Arrange
         List<FilterCollection> filterCollections = new List<FilterCollection>()
            {
                new FilterCollection()
                {
                    Filters = new List<Filter>()
                    {
                        new Filter()
                        {
                            Field = "SOME_OTHER_PROP",
                            Operator = "IsNull",
                            Value = "5",
                        },
                        new Filter()
                        {
                            Field = "SOME_OTHER_PROP",
                            Operator = "Startswith",
                            Value = "4"
                        },
                        new Filter()
                        {
                            Field = "SOME_OTHER_PROP",
                            Operator = "Endswith",
                            Value = "4"
                        }
                    },
                    Logic = "And"
                }
            };

         // Act
         QueryResult result = QueryBuilder.BuildFilterClause<TestModel>(filterCollections, "test");

         // Assert
         Assert.NotEmpty(result.Query);
         Assert.Contains(":test0", result.Query);
         Assert.Contains(result.Parameters.ParameterNames, x => x == "test0");
      }

      [Fact]
      public void BuildSortClause_ValidSortObject_ReturnsOrderByString()
      {
         // Arrange
         List<Sort> sortList = new List<Sort>()
            {
                new Sort()
                {
                    SortBy = "Skip",
                    SortDirection = SortDirection.Ascending
                }
            };

         // Act
         string result = QueryBuilder.BuildSortClause<PagingOptions>(sortList);

         // Assert
         Assert.NotEmpty(result);
         Assert.Contains("Skip", result);
      }

      [Fact]
      public void BuildSortClause_TwoSortObjects_Ah_Ah_Ah_ReturnsOrderByString()
      {
         // Arrange
         List<Sort> sortList = new List<Sort>()
            {
                new Sort()
                {
                    SortBy = "Skip",
                    SortDirection = SortDirection.Ascending
                },
                new Sort()
                {
                    SortBy = "Bo",
                    SortDirection = SortDirection.Descending
                }
            };

         // Act
         string result = QueryBuilder.BuildSortClause<PagingOptions>(sortList);

         // Assert
         Assert.NotEmpty(result);
         Assert.Contains("Skip", result);
      }

      [Fact]
      public void GenerateInsertWithoutKeyQueryAsync_HappyPath_Works()
      {
         string result = QueryBuilder.GenerateInsertWithoutKeyQueryAsync(new TestModel());
         Assert.Equal("insert into Test_Model (SOME_ID, SOME_OTHER_PROP) values (:SOME_ID, :SOME_OTHER_PROP)", result);
      }

      [Fact]
      public void GenerateUpdateWithoutKeyQueryAsync_HappyPath_Works()
      {
         string result = QueryBuilder.GenerateUpdateWithoutKeyQueryAsync(new TestModel() { SOME_ID = 1, SOME_OTHER_PROP = "Hallo" }, "something");
         Assert.Equal("update Test_Model set SOME_OTHER_PROP = :SOME_OTHER_PROP where something", result);
      }

      [Fact]
      public void GenerateGetListCountQueryAsync_PagingOptions_Works()
      {
         PagingOptions pagingWithFilters = new PagingOptions()
         {
            Filters = new List<FilterCollection>()
            {
               new FilterCollection()
               {
                  Filters = new List<Filter>()
                  {
                     new Filter() { Field = "hi", Operator = "Eq", Value = "1" }
                  }
               }
            }
         };
         QueryResult result = QueryBuilder.GenerateGetListCountQueryAsync<object>(pagingWithFilters);
         Assert.Equal("Select count(*) from Object where  hi = :Field0", result.Query);
      }

      [Fact]
      public void GenerateGetListCountQueryAsync_Conditions_Works()
      {
         string result = QueryBuilder.GenerateGetListCountQueryAsync<object>("something");
         Assert.Equal("Select count(*)  from Object something", result);
      }

      [Fact]
      public void GenerateInsertQueryAsync_HappyPath_Works()
      {
         string result = QueryBuilder.GenerateInsertQueryAsync<int>(new TestModel() { SOME_ID = 1, SOME_OTHER_PROP = "two" }, "something else", 1);
         Assert.Equal("insert into something else (SOME_ID, SOME_OTHER_PROP) values (:SOME_ID, :SOME_OTHER_PROP)", result);
      }

      [Fact]
      public void GenerateInsertQueryAsync_IdPropertiesOut_Works()
      {
         IEnumerable<PropertyInfo> idProps;
         string result = QueryBuilder.GenerateInsertQueryAsync<int>(new TestModel(), "something else", 1, out idProps);
         Assert.Equal("insert into something else (SOME_ID, SOME_OTHER_PROP) values (:SOME_ID, :SOME_OTHER_PROP)", result);
      }

      [Fact]
      public void GenerateGetQueryAsync_NoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateGetQueryAsync<object>(); });
      }

      [Fact]
      public void GenerateGetQueryAsync_MultipleIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateGetQueryAsync<InvalidModel>(); });
      }

      [Fact]
      public void GenerateGetQueryAsync_HappyPath_Works()
      {
         string result = QueryBuilder.GenerateGetQueryAsync<TestModel>();

         Assert.Equal("Select SOME_ID,SOME_OTHER_PROP as SOME_OTHER_PROP  from Test_Model where SOME_ID = :Id", result);
      }

      [Fact]
      public void GenerateGetListQueryAsync_WhereCondtionionsNoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateGetListQueryAsync<object>(new object()); });
      }

      [Fact]
      public void GenerateGetListQueryAsync_StringConditionsNoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateGetListQueryAsync<object>("something"); });
      }

      [Fact]
      public void GenerateGetListQueryAsync_PagingOptionsNoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateGetListQueryAsync<object>(new PagingOptions()); });
      }

      [Fact]
      public void GenerateGetListQueryAsync_HappyPath_Works()
      {
         List<FilterCollection> filterCollections = new List<FilterCollection>()
            {
                new FilterCollection()
                {
                    Filters = new List<Filter>()
                    {
                        new Filter()
                        {
                            Field = "SOME_OTHER_PROP",
                            Operator = "IsNull",
                            Value = "5",
                        }
                    }
                }
         };

         QueryResult result = QueryBuilder.GenerateGetListQueryAsync<TestModel>(new PagingOptions() { Filters = filterCollections });

         Assert.Equal("SELECT * FROM (SELECT b.*, rownum AS rnum FROM(SELECT a.SOME_ID,a.SOME_OTHER_PROP as SOME_OTHER_PROP  from Test_Model a where  SOME_OTHER_PROP is null) b WHERE rownum <= :Take) c WHERE rnum >= :Skip", result.Query);
      }

      [Fact]
      public void GenerateUpdateQueryAsync_NoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateUpdateQueryAsync(new object()); });
      }

      [Fact]
      public void GenerateDeleteQueryAsync_ObjectNoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateDeleteQueryAsync(new object()); });
      }

      [Fact]
      public void GenerateDeleteQueryAsync_NoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateDeleteQueryAsync<object>(); });
      }

      [Fact]
      public void GenerateDeleteQueryAsync_MultipleIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateDeleteQueryAsync<InvalidModel>(); });
      }

      [Fact]
      public void GenerateInsertQueryAsync_NoIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateInsertQueryAsync<int>(new object(), "asdf", 1); });
      }

      [Fact]
      public void GenerateInsertQueryAsync_MultIdProps_ThrowsException()
      {
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateInsertQueryAsync<int>(new InvalidModel(), "asdf", 1); });
      }

      [Fact]
      public void GenerateInsertQueryAsync_InvalidKey_ThrowsException()
      {
         Assert.Throws<System.Data.DataException>(() => { QueryBuilder.GenerateInsertQueryAsync<InvalidModel>(new TestModel(), "asdf", 1); });
      }

      [Fact]
      public void GenerateInsertQueryAsync_OutPropsNoIdProps_ThrowsException()
      {
         IEnumerable<PropertyInfo> idProps;
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateInsertQueryAsync<int>(new object(), "asdf", 1, out idProps); });
      }

      [Fact]
      public void GenerateInsertQueryAsync_OutPropsMultIdProps_ThrowsException()
      {
         IEnumerable<PropertyInfo> idProps;
         Assert.Throws<System.ArgumentException>(() => { QueryBuilder.GenerateInsertQueryAsync<int>(new InvalidModel(), "asdf", 1, out idProps); });
      }

      [Fact]
      public void GenerateInsertQueryAsync_OutPropsInvalidKey_ThrowsException()
      {
         IEnumerable<PropertyInfo> idProps;
         Assert.Throws<System.Data.DataException>(() => { QueryBuilder.GenerateInsertQueryAsync<InvalidModel>(new TestModel(), "asdf", 1, out idProps); });
      }

      [Fact]
      public void BuildStoreProcedureArguments_GivenProcModelWithAttrs_ReturnsProcArgs()
      {
         var procModel = new TestProcedureModel { TestParam = 123, TestParamWithDirection = 0 };

         QueryBuilder.BuildStoreProcedureArguments(procModel, out var procName, out var procParams);

         Assert.Equal("TEST_PROC", procName);
         Assert.Equal(2, procParams.Count());

         var procParam = procParams.ElementAt(0);
         Assert.Equal("TEST_PARAM", procParam.Name);
         Assert.Equal(123, procParam.Value);
         Assert.Equal(OracleDbType.Decimal, procParam.DbType);
         Assert.Equal(9, procParam.Size);
         Assert.Equal(System.Data.ParameterDirection.Input, procParam.ParameterDirection); // Input is default direction when not specified.

         var procParamWithDirection = procParams.ElementAt(1);
         Assert.Equal("TEST_PARAM_WITH_DIRECTION", procParamWithDirection.Name);
         Assert.Equal(0, procParamWithDirection.Value);
         Assert.Equal(OracleDbType.Decimal, procParamWithDirection.DbType);
         Assert.Equal(9, procParamWithDirection.Size);
         Assert.Equal(System.Data.ParameterDirection.Output, procParamWithDirection.ParameterDirection);
      }

      [Fact]
      public void BuildStoreProcedureArguments_GivenProcModelWithoutAttrs_ReturnsProcArgs()
      {
         var procModel = new TestProcedureModelNoAttrs { TestParam = 123 };

         QueryBuilder.BuildStoreProcedureArguments(procModel, out var procName, out var procParams);

         Assert.Equal("TEST_PROC", procName);

         var procParam = procParams.Single();
         Assert.Equal("TEST_PARAM", procParam.Name);
         Assert.Equal(123, procParam.Value);
         Assert.Null(procParam.DbType);
         Assert.Null(procParam.Size);
      }
   }
}
