﻿// <copyright file="TestDateModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System;
   using System.ComponentModel.DataAnnotations;
   using System.ComponentModel.DataAnnotations.Schema;

   /// <summary>
   /// A class which represents the Prod_Family table.
   /// </summary>
   [Table("Test_Date_Model")]
   public class TestDateModel : IDataEntity
   {
      [Key]
      public int SOME_ID { get; set; }

      [Column]
      public DateTime SOME_DATE_PROP { get; set; }
   }
}
