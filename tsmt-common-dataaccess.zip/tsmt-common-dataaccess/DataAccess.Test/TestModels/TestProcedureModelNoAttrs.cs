// <copyright file="TestProcedureModelNoAttrs.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using TSMT.DataAccess.Attributes;

   /// <summary>
   /// A test procedure model
   /// </summary>
   [Procedure("TEST_PROC")]
   public class TestProcedureModelNoAttrs
   {
      [ProcedureParameter("TEST_PARAM")]
      public int TestParam { get; set; }
   }
}
