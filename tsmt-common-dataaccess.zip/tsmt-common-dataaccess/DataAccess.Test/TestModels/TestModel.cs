﻿// <copyright file="TestModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System.ComponentModel.DataAnnotations;
   using System.ComponentModel.DataAnnotations.Schema;

   /// <summary>
   /// A class which represents the Prod_Family table.
   /// </summary>
   [Table("Test_Model")]
   public class TestModel : IDataEntity
   {
      [Key]
      public int SOME_ID { get; set; }

      [Column]
      public string SOME_OTHER_PROP { get; set; }
   }
}
