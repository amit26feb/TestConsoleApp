﻿// <copyright file="TestProcedureModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using Oracle.ManagedDataAccess.Client;
   using TSMT.DataAccess.Attributes;

   /// <summary>
   /// A test procedure model
   /// </summary>
   [Procedure("TEST_PROC")]
   public class TestProcedureModel
   {
      [ProcedureParameter("TEST_PARAM", OracleDbType.Decimal, 9)]
      public int TestParam { get; set; }

      [ProcedureParameter("TEST_PARAM_WITH_DIRECTION", OracleDbType.Decimal, 9, System.Data.ParameterDirection.Output)]
      public int TestParamWithDirection { get; set; }
   }
}
