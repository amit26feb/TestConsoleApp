﻿// <copyright file="TestModelWithFloatKey.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Test.TestModels
{
   using System;
   using System.ComponentModel.DataAnnotations;
   using System.ComponentModel.DataAnnotations.Schema;

   /// <summary>
   /// A test model
   /// </summary>
   [Table("Test_Model")]
   public class TestModelWithFloatKey
   {
      [Key]
      public float MyKey { get; set; }

      [Column]
      public string MyProp { get; set; }
   }
}