﻿// <copyright file="PropertyInfoExtensionTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Test
{
   using System.Collections.Generic;
   using System.ComponentModel;
   using System.ComponentModel.DataAnnotations;
   using System.ComponentModel.DataAnnotations.Schema;
   using System.Linq;
   using System.Reflection;
   using Moq;
   using TSMT.DataAccess;
   using TSMT.DataAccess.Test;
   using Xunit;

   public class PropertyInfoExtensionTest
   {
      [Fact]
      public void IsEditable_HasEditableAttribute_ReturnsTrue()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { new EditableAttribute(true) });
         bool result = mockPi.Object.IsEditable();
         Assert.True(result);
      }

      [Fact]
      public void IsEditable_NotEditableAttribute_ReturnsFalse()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { new EditableAttribute(false) });
         bool result = mockPi.Object.IsEditable();
         Assert.False(result);
      }

      [Fact]
      public void IsEditable_NoAttribute_ReturnsFalse()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { });
         bool result = mockPi.Object.IsEditable();
         Assert.False(result);
      }

      [Fact]
      public void IsEditable_NoEditAttribute_ReturnsFalse()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { new ReadOnlyAttribute(true) });
         bool result = mockPi.Object.IsEditable();
         Assert.False(result);
      }

      [Fact]
      public void IsReadOnly_ReadOnlyAttribute_ReturnsTrue()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { new ReadOnlyAttribute(true) });
         bool result = mockPi.Object.IsReadOnly();
         Assert.True(result);
      }

      [Fact]
      public void IsReadOnly_NotReadOnlyAttribute_ReturnsTrue()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { new ReadOnlyAttribute(false) });
         bool result = mockPi.Object.IsReadOnly();
         Assert.False(result);
      }

      [Fact]
      public void IsReadOnly_NoAttributes_ReturnsFalse()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { });
         bool result = mockPi.Object.IsReadOnly();
         Assert.False(result);
      }

      [Fact]
      public void IsReadOnly_NoReadOnlyAttribute_ReturnsFalse()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(false)).Returns(new object[] { new ColumnAttribute("SomeName") });
         bool result = mockPi.Object.IsReadOnly();
         Assert.False(result);
      }

      [Fact]
      public void GetColumnName_ColumnAttribute_ReturnsName()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(true)).Returns(new object[] { new ColumnAttribute("SomeName") });
         string result = mockPi.Object.GetColumnName();
         Assert.Equal("SomeName", result);
      }

      [Fact]
      public void GetColumnName_NoAttributes_ReturnsPropInfoName()
      {
         Mock<PropertyInfo> mockPi = new Mock<PropertyInfo>();
         mockPi.Setup(m => m.GetCustomAttributes(true)).Returns(new object[] { });
         mockPi.Setup(m => m.Name).Returns("SomeName");
         string result = mockPi.Object.GetColumnName();
         Assert.Equal("SomeName", result);
      }

      [Fact]
      public void GetAllProperties_Null_ReturnsNothin()
      {
         IEnumerable<PropertyInfo> result = PropertyInfoExtension.GetAllProperties(null);
         Assert.Empty(result);
      }

      [Fact]
      public void GetAllProperties_HasProperties_ReturnsThem()
      {
         IEnumerable<PropertyInfo> result = PropertyInfoExtension.GetAllProperties(new TestModel());
         Assert.Equal(2, result.Count());
         Assert.Contains(result, r => r.Name == "SOME_ID");
         Assert.Contains(result, r => r.Name == "SOME_OTHER_PROP");
      }

      [Fact]
      public void GetIdProperties_GivenAnObject_ReturnsIdProperties()
      {
         IEnumerable<PropertyInfo> result = PropertyInfoExtension.GetIdProperties(new TestModel());
         Assert.Single(result);
         Assert.Contains(result, r => r.Name == "SOME_ID");
      }

      [Fact]
      public void GetIdProperties_GivenAType_ReturnsIdProperties()
      {
         IEnumerable<PropertyInfo> result = PropertyInfoExtension.GetIdProperties(typeof(TestModel));
         Assert.Single(result);
         Assert.Contains(result, r => r.Name == "SOME_ID");
      }
   }
}
