// <copyright file="PartialRequestTests.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using Xunit;

   [Trait("Category", "TSMT Data Access")]
   public class PartialRequestTests
   {
      [Fact]
      public void PropertyStartIndex_StoresCorrectly()
      {
         var partialRequest = new PartialRequest();
         partialRequest.StartIndex = 1;
         Assert.Equal(1, partialRequest.StartIndex);
      }

      [Fact]
      public void PropertyEndIndex_StoresCorrectly()
      {
         var partialRequest = new PartialRequest();
         partialRequest.EndIndex = 9;
         Assert.Equal(9, partialRequest.EndIndex);
      }

      [Fact]
      public void PropertySort_StoresCorrectly()
      {
         var partialRequest = new PartialRequest();
         partialRequest.Sort = new Sort();
         partialRequest.Sort.SortBy = "blah";
         partialRequest.Sort.SortDirection = SortDirection.Ascending;
         Assert.Equal("blah", partialRequest.Sort.SortBy);
         Assert.Equal(SortDirection.Ascending, partialRequest.Sort.SortDirection);
      }
   }
}
