﻿// <copyright file="FilterOperatorUtilityTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Test
{
   using TSMT.DataAccess.Paging;
   using Xunit;

   public class FilterOperatorUtilityTest
   {
      [Fact]
      public void GetOperatorConversion_Works()
      {
         Assert.Equal("=", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Eq));
         Assert.Equal("!=", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Neq));
         Assert.Equal("like", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Contains));
         Assert.Equal("not like", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Doesnotcontain));
         Assert.Equal(">", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Gt));
         Assert.Equal(">=", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Gte));
         Assert.Equal("<", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Lt));
         Assert.Equal("<=", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Lte));
         Assert.Equal("%", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Startswith));
         Assert.Equal("%", FilterOperatorUtility.GetOperatorConversion(FilterOperators.Endswith));
         Assert.Equal("null", FilterOperatorUtility.GetOperatorConversion(FilterOperators.IsNull));
         Assert.Equal("null", FilterOperatorUtility.GetOperatorConversion(FilterOperators.IsEmpty));
         Assert.Equal("not null", FilterOperatorUtility.GetOperatorConversion(FilterOperators.IsNotNull));
         Assert.Equal("not null", FilterOperatorUtility.GetOperatorConversion(FilterOperators.IsNotEmpty));
      }
   }
}