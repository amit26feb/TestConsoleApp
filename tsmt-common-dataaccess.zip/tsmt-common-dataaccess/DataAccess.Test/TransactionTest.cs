// <copyright file="TransactionFactoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Test
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Linq;
   using System.Threading.Tasks;
   using Dapper;
   using DataAccess.Test.TestModels;
   using Moq;
   using TSMT.DataAccess;
   using TSMT.DataAccess.Test;
   using Xunit;

   public class TransactionTest
   {
      private readonly Transaction transactionUnderTest;
      private readonly Mock<Transaction> mockTransaction;
      private readonly Mock<IDbConnection> mockDbConnection;
      private readonly Mock<IDbTransaction> mockDbTransaction;

      public TransactionTest()
      {
         this.mockDbConnection = new Mock<IDbConnection>();
         this.mockDbTransaction = new Mock<IDbTransaction>();

         this.mockTransaction = new Mock<Transaction>(this.mockDbConnection.Object, this.mockDbTransaction.Object);
         this.mockTransaction.CallBase = true;

         this.transactionUnderTest = this.mockTransaction.Object;
      }

      [Fact]
      public void Dispose_ReleasesConnectionAndTransaction()
      {
         this.transactionUnderTest.Dispose();
         this.mockDbConnection.Verify(x => x.Dispose(), Times.Once);
         this.mockDbTransaction.Verify(x => x.Dispose(), Times.Once);
      }

      [Fact]
      public void CallQueryAndNonQuery_GetTestCoverage()
      {
         this.transactionUnderTest.CallNonQuery(default(CommandDefinition));
         this.transactionUnderTest.CallQuery<int>(default(CommandDefinition));
         this.transactionUnderTest.CallQuerySingle<int>(default(CommandDefinition));
      }

      [Fact]
      public void Commit_CallsUnderlyingTransaction()
      {
         this.transactionUnderTest.Commit();
         this.mockDbTransaction.Verify(x => x.Commit(), Times.Once);
      }

      [Fact]
      public void Rollback_CallsUnderlyingTransaction()
      {
         this.transactionUnderTest.Rollback();
         this.mockDbTransaction.Verify(x => x.Rollback(), Times.Once);
      }

      [Fact]
      public async Task ReserveKeyAsync_WithFloatKeyModel_ThrowsAnException()
      {
         await Assert.ThrowsAsync<NotSupportedException>(async () =>
         {
            try
            {
               var model = new TestModelWithFloatKey();
               await this.transactionUnderTest.ReserveKeyAsync(model);
            }
            catch (NotSupportedException e)
            {
               Assert.Contains("unsupported type", e.Message);
               throw;
            }
         });
      }

      [Fact]
      public async Task ReserveKeyAsync_WithGuidKeyModel_PopulatesTheModel()
      {
         // Arrange
         var model = new TestModelWithGuidKey();
         model.MyKey = default;

         // Act
         await this.transactionUnderTest.ReserveKeyAsync(model);

         // Assert
         Assert.NotEqual(default, model.MyKey);
      }

      [Fact]
      public async Task ReserveKeyAsync_WithIntegerKeyModel_PopulatesTheModel()
      {
         // Arrange
         CommandDefinition command = default;
         this.mockTransaction.Setup(x => x.CallQuerySingle<int>(It.IsAny<CommandDefinition>()))
            .Returns(Task.FromResult(7))
            .Callback<CommandDefinition>(c => command = c);

         var model = new TestModelWithIntKey();
         model.MyKey = default;

         // Act
         await this.transactionUnderTest.ReserveKeyAsync(model);

         // Assert
         Assert.Equal(7, model.MyKey);
      }

      [Fact]
      public async Task ReserveKeyAsync_WithIntegerKeyModel_UsesTransaction()
      {
         // Arrange
         CommandDefinition command = default;
         this.mockTransaction.Setup(x => x.CallQuerySingle<int>(It.IsAny<CommandDefinition>()))
            .Returns(Task.FromResult(7))
            .Callback<CommandDefinition>(c => command = c);

         var model = new TestModelWithIntKey();
         model.MyKey = default;

         // Act
         await this.transactionUnderTest.ReserveKeyAsync(model);

         // Assert
         Assert.Equal(this.mockDbTransaction.Object, command.Transaction);
      }

      [Fact]
      public async Task InsertAsync_WithModel_UsesTransaction()
      {
         // Arrange
         CommandDefinition command = default;
         this.mockTransaction.Setup(x => x.CallQuery<int>(It.IsAny<CommandDefinition>()))
            .Returns(Task.FromResult(new List<int> { 1 }.AsEnumerable()))
            .Callback<CommandDefinition>(c => command = c);

         this.mockTransaction.Setup(x => x.CallNonQuery(It.IsAny<CommandDefinition>()))
            .Returns(Task.FromResult(1))
            .Callback<CommandDefinition>(c => command = c);

         var model = new TestModel();

         // Act
         await this.transactionUnderTest.InsertAsync(model);

         // Assert
         Assert.Equal(this.mockDbTransaction.Object, command.Transaction);
      }

      [Fact]
      public async Task UpdateAsync_WithModel_UsesTransaction()
      {
         // Arrange
         CommandDefinition command = default;

         this.mockTransaction.Setup(x => x.CallNonQuery(It.IsAny<CommandDefinition>()))
            .Returns(Task.FromResult(1))
            .Callback<CommandDefinition>(c => command = c);

         var model = new TestModel();

         // Act
         await this.transactionUnderTest.UpdateAsync(model);

         // Assert
         Assert.Equal(this.mockDbTransaction.Object, command.Transaction);
      }

      [Fact]
      public async Task DeleteAsync_WithModel_UsesTransaction()
      {
         // Arrange
         CommandDefinition command = default;

         this.mockTransaction.Setup(x => x.CallNonQuery(It.IsAny<CommandDefinition>()))
            .Returns(Task.FromResult(1))
            .Callback<CommandDefinition>(c => command = c);

         var model = new TestModel();

         // Act
         await this.transactionUnderTest.DeleteAsync(model);

         // Assert
         Assert.Equal(this.mockDbTransaction.Object, command.Transaction);
      }

      [Fact]
      public async Task ExecuteProcedureAsync_WithModel_UsesTransaction()
      {
         // Arrange
         CommandDefinition command = default;

         this.mockTransaction.Setup(x => x.CallNonQuery(It.IsAny<CommandDefinition>()))
            .Returns(Task.FromResult(1))
            .Callback<CommandDefinition>(c => command = c);

         var model = new TestProcedureModel();

         // Act
         await this.transactionUnderTest.ExecuteProcedureAsync(model);

         // Assert
         Assert.Equal(this.mockDbTransaction.Object, command.Transaction);
      }
   }
}
