// <copyright file="DataAccessTestBase.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using global::DataAccess.Core.Abstractions;
   using global::DataAccess.Core.Infrastructure;
   using Moq;
   using TSMT.DataAccess;
   using Xunit;

   [Collection("DataAccessTestBase")]
   public abstract class DataAccessTestBase
   {
      protected IRepository<ProductFamily> ExceptionRepositoryExpectingDrAddressId { get; set; }

      protected IRepository<ProductFamily> ExceptionRepository { get; set; }

      public DataAccessTestBase(DataAccessFixture fixture)
      {
         Mock<IDatabaseInfoProvider> dbInfo;
         IConnectionFactory connectionFactory;
         IConnectionFactory connectionFactoryHonoringDrAddressId;
         dbInfo = new Mock<IDatabaseInfoProvider>();
         dbInfo.Setup(c => c.ConnectionString).Returns("sumpinweirdhere");

         connectionFactory = new ConnectionFactory(dbInfo.Object);
         this.ExceptionRepository = new Repository<ProductFamily>(connectionFactory);

         connectionFactoryHonoringDrAddressId = new ConnectionFactory(dbInfo.Object, true);
         this.ExceptionRepositoryExpectingDrAddressId = new Repository<ProductFamily>(connectionFactoryHonoringDrAddressId);
      }
   }
}
