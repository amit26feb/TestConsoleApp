﻿// <copyright file="InsertTestAsync.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Net;
   using Xunit;

   [Trait("Category", "TSMT Data Access")]
   public sealed class InsertTestAsync : DataAccessTestBase
   {
      public InsertTestAsync(DataAccessFixture fixture)
          : base(fixture)
      {
      }

      [Fact]
      public async void Test_InsertTestAsync_InvalidConnectionConfig()
      {
         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.InsertAsync(entity));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }

      [Fact]
      public async void Test_InsertTestAsync_NotExpectingDrAddressId()
      {
         // Tell the repository to honor a DrAddressId, when we know the ConnectionFactory will not be expecting it.
         this.ExceptionRepository.HonorDrAddressId(1);

         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<InvalidOperationException>(()
             => this.ExceptionRepository.InsertAsync(entity));
         Assert.Equal("The ConnectionFactory is not expecting a DrAddressId to honor when generating a new connection.", ex.Message);
      }

      [Fact]
      public async void Test_InsertTestAsync_RequiringDrAddressId()
      {
         // With the repository that works against the ConnectionFactory that honors a DrAddressId, clear out the DrAddressId to honor.
         // This should result in an exception when the repository tries to retrieve a connection to use.
         this.ExceptionRepositoryExpectingDrAddressId.HonorDrAddressId(null);

         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<InvalidOperationException>(()
             => this.ExceptionRepositoryExpectingDrAddressId.InsertAsync(entity));
         Assert.Equal("The ConnectionFactory is configured to require a DrAddressId to honor when generating a new connection.", ex.Message);
      }

      [Fact]
      public async void Test_InsertTestAsync_Primary_Key_InvalidConnectionConfig()
      {
         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.InsertAsync<int>(entity));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }

      [Fact]
      public async void Test_InsertMultipleTestAsync_InvalidConnectionConfig()
      {
         List<ProductFamily> list = new List<ProductFamily>();
         list.Add(new ProductFamily { DR_STATUS = "Open" });

         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.InsertAsync(list));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }
   }
}
