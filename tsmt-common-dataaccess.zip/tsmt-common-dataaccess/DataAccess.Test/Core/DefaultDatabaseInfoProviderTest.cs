using DataAccess.Core.Infrastructure;
using Microsoft.Extensions.Options;
using Moq;
using TSMT.Settings;
using Xunit;

namespace DataAccess.Core
{
   public class DatabaseInfoProviderTest
   {
      [Fact]
      public void ConnectionString_ReturnsVPNDBConnectionString()
      {
         // Arrange                  
         var provider = new DatabaseInfoProvider("yo");

         // Act
         var connectionString = provider.ConnectionString;

         // Assert
         Assert.Equal("yo", connectionString);
      }
   }
}
