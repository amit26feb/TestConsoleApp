using DataAccess.Core.Infrastructure;
using Microsoft.Extensions.Options;
using Moq;
using TSMT.Settings;
using Xunit;

namespace DataAccess.Core
{
   public class DefaultDatabaseInfoProviderTest
   {
      private readonly Mock<IOptions<TSMTSettings>> optionsMock;

      public DefaultDatabaseInfoProviderTest()
      {
         this.optionsMock = new Mock<IOptions<TSMTSettings>>();
      }

      [Fact]
      public void ConnectionString_ReturnsVPNDBConnectionString()
      {
         // Arrange
         TSMTSettings settings = new TSMTSettings()
         {
            VPNDBConnectionString = "booties"
         };
         this.optionsMock.Setup(o => o.Value).Returns(settings);
         var provider = new DefaultDatabaseInfoProvider(this.optionsMock.Object);

         // Act
         var connectionString = provider.ConnectionString;

         // Assert
         Assert.Equal(settings.VPNDBConnectionString, connectionString);
      }
   }
}
