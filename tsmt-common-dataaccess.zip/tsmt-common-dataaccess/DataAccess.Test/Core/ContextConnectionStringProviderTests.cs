using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using TSMT.Settings;
using Xunit;

namespace DataAccess.Core
{
   public class ContextConnectionStringProviderTests
   {
      private readonly Mock<IHttpContextAccessor> contextAccessor;
      private readonly Mock<IOptions<TSMTSettings>> optionsMock;
      private readonly Mock<ILogger<ContextConnectionStringProvider>> loggerMock;
      private readonly Mock<HttpContext> contextMock;
      private readonly Mock<HttpRequest> httpRequestMock;
      private readonly Mock<IHeaderDictionary> headerDictionaryMock;

      public ContextConnectionStringProviderTests()
      {
         this.optionsMock = new Mock<IOptions<TSMTSettings>>();
         this.loggerMock = new Mock<ILogger<ContextConnectionStringProvider>>();
         this.headerDictionaryMock = new Mock<IHeaderDictionary>();
         this.httpRequestMock = new Mock<HttpRequest>();
         this.httpRequestMock.Setup(h => h.Headers).Returns(this.headerDictionaryMock.Object);
         this.contextMock = new Mock<HttpContext>();
         this.contextMock.Setup(c => c.Request).Returns(this.httpRequestMock.Object);
         this.contextAccessor = new Mock<IHttpContextAccessor>();
         this.contextAccessor.Setup(c => c.HttpContext).Returns(this.contextMock.Object);
      }

      public static IEnumerable<object[]> GoodData =>
         new List<object[]>
         {
            new object[] { new TSMTSettings() { VPNDBConnectionString = "bleh" }, string.Empty, "bleh" },
            new object[] { new TSMTSettings() { BUPDConnectionString = "bleh" }, "bupd", "bleh" },
            new object[] { new TSMTSettings() { ESTRND9ConnectionString = "bleh" }, "d9", "bleh" },
            new object[] { new TSMTSettings() { ESTRNT3ConnectionString = "bleh" }, "t3", "bleh" },
            new object[] { new TSMTSettings() { ESTRNT7ConnectionString = "bleh" }, "t7", "bleh" },
            new object[] { new TSMTSettings() { ESTRNSConnectionString = "bleh" }, "s", "bleh" },
            new object[] { new TSMTSettings() { ESTRNDConnectionString = "bleh" }, "d", "bleh" },
            new object[] { new TSMTSettings() { ESTRND8ConnectionString = "bleh" }, "d8", "bleh" },
            new object[] { new TSMTSettings() { ESTRNTConnectionString = "bleh" }, "t", "bleh" },
         };

      [MemberData(nameof(GoodData))]
      [Theory]
      public void GetConnectionString_ReturnsExpectedSetting(TSMTSettings settings, string contextHeader, string expectedValue)
      {
         // Arrange
         this.headerDictionaryMock.Setup(h => h[ContextConnectionStringProvider.HeaderName]).Returns(contextHeader);
         this.optionsMock.Setup(o => o.Value).Returns(settings);
         var provider = new ContextConnectionStringProvider(this.optionsMock.Object, this.contextAccessor.Object, this.loggerMock.Object);

         // Act
         var connectionString = provider.ConnectionString;

         // Assert
         Assert.Equal(expectedValue, connectionString);
      }

      [Fact]
      public void GetConnectionString_GivenBadHeader_UsesDefault()
      {
         // Arrange
         TSMTSettings settings = new TSMTSettings()
         {
            VPNDBConnectionString = "booties"
         };
         this.optionsMock.Setup(o => o.Value).Returns(settings);
         this.headerDictionaryMock.Setup(h => h[ContextConnectionStringProvider.HeaderName]).Returns("smoosh");
         var provider = new ContextConnectionStringProvider(this.optionsMock.Object, this.contextAccessor.Object, this.loggerMock.Object);

         // Act
         var connectionString = provider.ConnectionString;

         // Assert
         Assert.Equal(settings.VPNDBConnectionString, connectionString);
      }

      [Fact]
      public void GetConnectionString_ChecksContextEachTime()
      {
         // Arrange
         TSMTSettings settings = new TSMTSettings()
         {
            BUPDConnectionString = "bupd",
            VPNDBConnectionString = "booties"
         };

         this.optionsMock.Setup(o => o.Value).Returns(settings);
         this.headerDictionaryMock.SetupSequence(h => h[ContextConnectionStringProvider.HeaderName])
            .Returns("smoosh")
            .Returns("bupd");
         var provider = new ContextConnectionStringProvider(this.optionsMock.Object, this.contextAccessor.Object, this.loggerMock.Object);

         // Act
         var defaultConnectionString = provider.ConnectionString;
         var bupdConnectionString = provider.ConnectionString;

         // Assert
         Assert.Equal(settings.VPNDBConnectionString, defaultConnectionString);
         Assert.Equal(settings.BUPDConnectionString, bupdConnectionString);
      }
   }
}
