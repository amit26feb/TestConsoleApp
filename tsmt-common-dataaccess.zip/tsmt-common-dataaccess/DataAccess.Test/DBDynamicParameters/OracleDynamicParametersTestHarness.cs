﻿// <copyright file="OracleDynamicParametersTestHarness.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Test.DBDynamicParameters
{
   using System.Collections.Generic;
   using DataAccess.DBDynamicParameters;

   public class OracleDynamicParametersTestHarness : OracleDynamicParameters
   {
      public Dictionary<string, ParamInfo> HiddenParameters
      {
         get
         {
            return this.Parameters;
         }
      }
   }
}
