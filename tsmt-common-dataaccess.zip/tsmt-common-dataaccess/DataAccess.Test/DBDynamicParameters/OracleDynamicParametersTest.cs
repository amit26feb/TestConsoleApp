﻿// <copyright file="OracleDynamicParametersTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess.Test.DBDynamicParameters
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Linq;
   using System.Text;
   using Dapper;
   using DataAccess.DBDynamicParameters;
   using Moq;
   using Oracle.ManagedDataAccess.Client;
   using Xunit;
   using static Dapper.SqlMapper;

   public class OracleDynamicParametersTest
   {
      [Fact]
      public void Add_NewParameter_AddsIt()
      {
         OracleDynamicParametersTestHarness paramsUnderTest = new OracleDynamicParametersTestHarness();

         paramsUnderTest.Add("myparmname", "myparmvalue");

         Assert.Single(paramsUnderTest.HiddenParameters);
      }

      [Fact]
      public void AddParameters_NewParameter_AddsIt()
      {
         OracleDynamicParametersTestHarness paramsUnderTest = new OracleDynamicParametersTestHarness();
         IDynamicParameters typedParamsUnderTest = (IDynamicParameters)paramsUnderTest;
         paramsUnderTest.Add("myparmname", "myparmvalue");
         OracleCommand command = new OracleCommand();

         typedParamsUnderTest.AddParameters(command, null);

         Assert.Single(command.Parameters);
      }

      [Fact]
      public void GetParameter_HasValidData_ReturnsParameter()
      {
         OracleDynamicParametersTestHarness paramsUnderTest = new OracleDynamicParametersTestHarness();

         paramsUnderTest.Add(name: "myinputparam", value: "myinputvalue", direction: ParameterDirection.Input);
         paramsUnderTest.Add(name: "myoutputparam", direction: ParameterDirection.Output);

         var test = paramsUnderTest.GetParameter("myoutputparam");

         Assert.NotNull(test);
         Assert.Null(test.Value);
      }
   }
}
