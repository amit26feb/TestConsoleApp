// <copyright file="GetListTestAsync.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System;
   using System.Collections.Generic;
   using global::DataAccess.Paging;
   using Xunit;

   [Trait("Category", "TSMT Data Access")]
   public sealed class GetListTestAsync : DataAccessTestBase
   {
      public GetListTestAsync(DataAccessFixture fixture)
          : base(fixture)
      {
      }

      [Fact]
      public async void Test_GetAllListTestAsync_InvalidConnectionConfig()
      {
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.GetListAsync<ProductFamily>());
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }

      [Fact]
      public async void Test_GetAllListTestAsync_NotExpectingDrAddressId()
      {
         // Tell the repository to honor a DrAddressId, when we know the ConnectionFactory will not be expecting it.
         this.ExceptionRepository.HonorDrAddressId(1);

         var ex = await Assert.ThrowsAsync<InvalidOperationException>(()
             => this.ExceptionRepository.GetListAsync<ProductFamily>());
         Assert.Equal("The ConnectionFactory is not expecting a DrAddressId to honor when generating a new connection.", ex.Message);
      }

      [Fact]
      public async void Test_GetAllListTestAsync_RequiringDrAddressId()
      {
         // With the repository that works against the ConnectionFactory that honors a DrAddressId, clear out the DrAddressId to honor.
         // This should result in an exception when the repository tries to retrieve a connection to use.
         this.ExceptionRepositoryExpectingDrAddressId.HonorDrAddressId(null);

         var ex = await Assert.ThrowsAsync<InvalidOperationException>(()
             => this.ExceptionRepositoryExpectingDrAddressId.GetListAsync<ProductFamily>());
         Assert.Equal("The ConnectionFactory is configured to require a DrAddressId to honor when generating a new connection.", ex.Message);
      }

      [Fact]
      public async void Test_GetListSatisfiesWhereCondition_TestAsync_InvalidConnectionConfig()
      {
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.GetListAsync<ProductFamily>("Test condition"));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }

      [Fact]
      public async void Test_GetListTestAsync_InvalidConnectionConfig()
      {
         object condition = "Test condition";
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.GetListAsync<ProductFamily>(condition));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }

      [Fact]
      public async void Test_GetListTestAsync_WithPagingOptions_InvalidConnectionConfig()
      {
         PagingOptions pagingOptions = new TSMT.DataAccess.PagingOptions
         {
            Skip = 0,
            Take = 100,
            Sort = new List<Sort> { new Sort { SortBy = "PROD_FAMILY_ID", SortDirection = SortDirection.Ascending } },
            Filters = new List<FilterCollection> { new FilterCollection { Filters = new List<Filter> { new Filter { Field = "PROD_FAMILY", Operator = "contains", Value = "CON" } }, Logic = "and" } }
         };
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.GetListAsync<ProductFamily>(pagingOptions));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }
   }
}
