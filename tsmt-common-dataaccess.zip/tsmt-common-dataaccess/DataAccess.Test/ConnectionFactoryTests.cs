// <copyright file="ConnectionFactoryTests.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace DataAccess
{
   using System;
   using System.Data;
   using DataAccess.Core.Abstractions;
   using DataAccess.Core.Infrastructure;
   using Moq;
   using Xunit;

   public class ConnectionFactoryTests
   {
      private readonly Mock<IDatabaseInfoProvider> dbInfo;

      public ConnectionFactoryTests()
      {
         this.dbInfo = new Mock<IDatabaseInfoProvider>();
      }

      [Fact]
      public void GetConnection_GivenVPDUnaware_ReturnsConnection()
      {
         // Arrange
         string expectedConnectionString = "Data Source=localhost;User Id=admin;Password=password";
         this.dbInfo.Setup(db => db.ConnectionString).Returns(expectedConnectionString);
         ConnectionFactory c = new ConnectionFactory(this.dbInfo.Object, false);

         // Act
         IDbConnection connection = c.GetConnection();

         // Assert
         Assert.Equal(expectedConnectionString, connection.ConnectionString);
      }

      [Fact]
      public void GetConnection_GivenVPDAware_ThrowsInvalidOperationException()
      {
         // Arrange
         ConnectionFactory c = new ConnectionFactory(this.dbInfo.Object, true);

         // Act + Assert
         Assert.Throws<InvalidOperationException>(() => c.GetConnection());
      }

      [Fact]
      public void GetOpenConnectionForDrAddressId_GivenVPDUnaware_ThrowsInvalidOperationException()
      {
         // Arrange
         int drAddressId = 42;
         ConnectionFactory c = new ConnectionFactory(this.dbInfo.Object, false);

         // Act + Assert
         Assert.Throws<InvalidOperationException>(() => c.GetOpenConnectionForDrAddressId(drAddressId));
      }

      [Fact]
      public void GetConnection_GetsConnectionStringFromIDatabaseInfoProvider()
      {
         // Arrange
         ConnectionFactory c = new ConnectionFactory(this.dbInfo.Object, false);

         // Act
         c.GetConnection();
         c.GetConnection();

         // Assert
         this.dbInfo.Verify(i => i.ConnectionString, Times.Exactly(2));
      }

      [Fact]
      public void IsHonoringDrAddressId_ContructedToHonor_ReturnsTrue()
      {
         // Arrange
         ConnectionFactory c = new ConnectionFactory(this.dbInfo.Object, true);

         // Act + Assert
         Assert.True(c.IsHonoringDrAddressId());
      }

      [Fact]
      public void IsHonoringDrAddressId_ContructedToNotHonor_ReturnsFalse()
      {
         // Arrange
         ConnectionFactory c = new ConnectionFactory(this.dbInfo.Object, false);

         // Act + Assert
         Assert.False(c.IsHonoringDrAddressId());
      }
   }
}
