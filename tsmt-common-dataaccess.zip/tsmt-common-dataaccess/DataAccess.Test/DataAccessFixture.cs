﻿// <copyright file="DataAccessFixture.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System;

   public class DataAccessFixture : IDisposable
   {
      public DataAccessFixture()
      {
      }

      public void Dispose()
      {
      }
   }
}
