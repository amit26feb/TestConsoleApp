﻿// <copyright file="UpdateTestAsync.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System;
   using System.Collections.Generic;
   using System.Data;
   using System.Net;
   using Xunit;

   [Trait("Category", "TSMT Data Access")]
   public sealed class UpdateTestAsync : DataAccessTestBase
   {
      public UpdateTestAsync(DataAccessFixture fixture)
          : base(fixture)
      {
      }

      [Fact]
      public async void Test_UpdateTestAsync_InvalidConnectionConfig()
      {
         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.UpdateAsync(entity));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }

      [Fact]
      public async void Test_UpdateTestAsync_NotExpectingDrAddressId()
      {
         // Tell the repository to honor a DrAddressId, when we know the ConnectionFactory will not be expecting it.
         this.ExceptionRepository.HonorDrAddressId(1);

         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<InvalidOperationException>(()
             => this.ExceptionRepository.UpdateAsync(entity));
         Assert.Equal("The ConnectionFactory is not expecting a DrAddressId to honor when generating a new connection.", ex.Message);
      }

      [Fact]
      public async void Test_UpdateTestAsync_RequiringDrAddressId()
      {
         // With the repository that works against the ConnectionFactory that honors a DrAddressId, clear out the DrAddressId to honor.
         // This should result in an exception when the repository tries to retrieve a connection to use.
         this.ExceptionRepositoryExpectingDrAddressId.HonorDrAddressId(null);

         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<InvalidOperationException>(()
             => this.ExceptionRepositoryExpectingDrAddressId.UpdateAsync(entity));
         Assert.Equal("The ConnectionFactory is configured to require a DrAddressId to honor when generating a new connection.", ex.Message);
      }

      [Fact]
      public async void Test_UpdateEntitiesTestAsync_InvalidConnectionConfig()
      {
         List<ProductFamily> list = new List<ProductFamily>();
         list.Add(new ProductFamily { DR_STATUS = "Open" });

         var entity = new ProductFamily { DR_STATUS = "Open" };
         var ex = await Assert.ThrowsAsync<ArgumentException>(()
             => this.ExceptionRepository.UpdateAsync(list));
         Assert.Equal("Connection string is not well-formed", ex.Message);
      }
   }
}
