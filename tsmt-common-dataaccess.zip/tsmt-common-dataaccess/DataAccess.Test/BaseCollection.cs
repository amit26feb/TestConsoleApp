﻿// <copyright file="BaseCollection.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using Xunit;

   [CollectionDefinition("DataAccessTestBase")]
   public class BaseCollection : ICollectionFixture<DataAccessFixture>
   {
   }
}
