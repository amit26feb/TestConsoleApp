﻿// <copyright file="ProductFamily.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace TSMT.DataAccess.Test
{
   using System.ComponentModel.DataAnnotations;
   using System.ComponentModel.DataAnnotations.Schema;

   /// <summary>
   /// A class which represents the Prod_Family table.
   /// </summary>
   [Table("Prod_Family")]
   public class ProductFamily : IDataEntity
   {
      [Key]
      public int PROD_FAMILY_ID { get; set; }

      public string PROD_FAMILY { get; set; }

      public string PROD { get; set; }

      public string DESCRIPTION { get; set; }

      public string OPTION_SELECTED_YES_NO_FLAG { get; set; }

      public string BU_MFG_LOC_ID { get; set; }

      public string PROD_PRICING_GRP_ID { get; set; }

      public string MODULE_USAGE { get; set; }

      public string IN_CHG_CONTROL_ID { get; set; }

      public string OUT_CHG_CONTROL_ID { get; set; }

      public string DR_STATUS { get; set; }

      public string OP_RULE_ID { get; set; }

      public string ORD_GRP_ID { get; set; }

      public string EPS_MODL_TYPE { get; set; }

      public string PROD_SEL_PGM_PATHNAME { get; set; }

      public string PROD_SEL_PGM_FILENAME { get; set; }

      public string PROD_SEL_PGM_PARAMETERS { get; set; }

      public string REFERRAL { get; set; }

      public string DR_UPDATED { get; set; }

      public string STATUS1 { get; set; }

      public string PROD_SEL_UNIT_SIZE_ID { get; set; }

      public string PROMPT_SEQ_NBR { get; set; }

      public string PROD_FAMILY_ALIAS { get; set; }

      public string MFG_PROD_GRP_EQUIV { get; set; }

      public string INTERNATIONAL_IND { get; set; }

      public string OE_TAGS_REQUIRED_IND { get; set; }

      public string DOE_ENABLED { get; set; }

      public string AUTO_GATE_CHECK_TYPE { get; set; }

      public string PRODUCT_FAMILY_USE_CLASS { get; set; }

      public string LAST_UPDATE_USER_ID { get; set; }

      public string LAST_UPDATE_DATE { get; set; }

      public string SEPARATE_BILLING_IND { get; set; }

      public string PERF_CHGS_REQ_TOPSS { get; set; }
   }
}
