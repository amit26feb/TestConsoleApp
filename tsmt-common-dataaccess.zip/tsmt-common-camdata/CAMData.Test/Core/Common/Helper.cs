namespace CAMData.Test.Core.Common
{
    using System.Collections.Generic;
    using TSMT.CAM.Data.Constants;
    using TSMT.CAM.Data.Core.Models;

    public static class Helper
    {
        public static IEnumerable<ActiveDirectoryModel> GetActiveDirectoryModels()
        {
            return new List<ActiveDirectoryModel>
            {
               new ActiveDirectoryModel(){
                   BusinessPhones= new string[]{"442/852-3362"},
                   DisplayName="Test, Shivam",
                   GivenName="Test",
                   JobTitle=null,
                   Mail="Shivam.Test@contractor.tranetechnologies.com",
                   MobilePhone=null,
                   OfficeLocation="New York",
                   Surname="Shivam",
                   UserPrincipalName="Shivam.test@contractor.tranetechnologies.com",
                   OnPremisesSamAccountName="tstuid",
                   PreferredLanguage=null,
                   AccountEnabled="true"
               }
            };
        }

        public static IEnumerable<FilterModel> GetFilterModels()
        {
            return new List<FilterModel>() {
                new FilterModel {
                Field = Constants.MailNickNameProperty, Value = "tstuid"
                }
            };
        }
    }
}
