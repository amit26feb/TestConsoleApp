// <copyright file="JobClientAPITest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Formatting;
    using System.Threading.Tasks;
    using AutoFixture;
    using Moq;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using Xunit;

    public class JobApiClientTest
    {
        private readonly Mock<IApiHttpClient> mockHttp;
        private readonly Mock<IUserApiClient> userApiClient;
        private readonly JobApiClient jobApiClient;
        private readonly string jobServiceUrl = "http://dont.com";
        private readonly CamData camData;
        private readonly CamInput camInput;
        private readonly LockInput jobLockInput;
        private readonly LockInfo jobLockInfo;

        public JobApiClientTest()
        {
            this.mockHttp = new Mock<IApiHttpClient>();
            this.userApiClient = new Mock<IUserApiClient>();
            this.jobApiClient = new JobApiClient(this.jobServiceUrl, this.mockHttp.Object, this.userApiClient.Object);
            Fixture fixture = new Fixture();
            this.camData = fixture.Create<CamData>();
            this.camInput = fixture.Create<CamInput>();
            this.jobLockInput = fixture.Create<LockInput>();
            this.jobLockInfo = fixture.Create<LockInfo>();

        }

        [Fact]
        public async Task GetCamLockInfo_HasData_ReturnsCamData()
        {
            // Arrange
            this.mockHttp.Setup(m => m.PostAsync<CamData>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(this.camData));
            this.userApiClient.Setup(m => m.Search(It.IsAny<CamData>()))
                .Returns(Task.FromResult(this.camData));

            // Act
            var result = await this.jobApiClient.GetCamLockInfo(this.camInput);

            // Assert
            Assert.Equal(result, this.camData);
            this.mockHttp.Verify(m => m.PostAsync<CamData>($"{camInput.DrAddressId}/Jobs/CamLockInfo", It.IsAny<StringContent>()), Times.Once);
            this.userApiClient.Verify(m => m.Search(this.camData), Times.Once);
        }

        [Fact]
        public async Task LockOrUnlockJob_SendDataToJobService_ReturnsJobLockOrUnlockinformation()
        {
            // Arrange
            bool isLockJob = true;
            var fixture = new Fixture();
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<LockInfo>(this.jobLockInfo, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.jobApiClient.LockOrUnlockJob(isLockJob, jobLockInput);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"{jobLockInput.DrAddressId}/Jobs/{jobLockInput.JobId}?lockJob={isLockJob}", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task LockOrUnlockJob_SendDataToJobService_ReturnsConflictStatus()
        {
            // Arrange
            bool isLockJob = true;
            var fixture = new Fixture();
            var response = new HttpResponseMessage(HttpStatusCode.Conflict)
            {
                Content = new ObjectContent<LockInfo>(this.jobLockInfo, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.jobApiClient.LockOrUnlockJob(isLockJob, jobLockInput);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"{jobLockInput.DrAddressId}/Jobs/{jobLockInput.JobId}?lockJob={isLockJob}", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task GetLocalJobId_DeosNotHaveData_ReturnsJobIdAsNull()
        {
            // Arrange
            camInput.HostData.JobId = 13958;
            IEnumerable<JobResponse> jobResponses = null;

            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<JobResponse>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(jobResponses));

            // Act
            var result = await this.jobApiClient.GetLocalJobId(camInput);

            // Assert
            Assert.Null(result);
            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<JobResponse>>($"{camInput.DrAddressId}/Jobs/Search", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task GetLocalJobId_HasData_ReturnsJobId()
        {
            // Arrange
            camInput.HostData.JobId = 13958;
            IEnumerable<JobResponse> jobResponses = new List<JobResponse>
            {
                new JobResponse{ JobId = 15833, HqtrJobId = 13958 }
            };

            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<JobResponse>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(jobResponses));

            // Act
            var result = await this.jobApiClient.GetLocalJobId(camInput);

            // Assert
            Assert.Equal(jobResponses.First().JobId, result);
            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<JobResponse>>($"{camInput.DrAddressId}/Jobs/Search", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task GetHostJobId_DeosNotHaveData_ReturnsJobIdAsNull()
        {
            // Arrange
            camInput.LocalData.JobId = 12784;
            JobResponse jobResponse = null;

            this.mockHttp.Setup(m => m.GetAsync<JobResponse>(It.IsAny<string>()))
                .Returns(Task.FromResult(jobResponse));

            // Act
            var result = await this.jobApiClient.GetHostJobId(camInput);

            // Assert
            Assert.Null(result);
            this.mockHttp.Verify(m => m.GetAsync<JobResponse>($"{camInput.DrAddressId}/Jobs/{camInput.LocalData.JobId}/BasicInfo"), Times.Once);
        }

        [Fact]
        public async Task GetHostJobId_HasData_ReturnsJobId()
        {
            // Arrange
            camInput.LocalData.JobId = 16785;
            JobResponse jobResponse = new JobResponse
            {
                JobId = 16785,
                HqtrJobId = 14874
            };

            this.mockHttp.Setup(m => m.GetAsync<JobResponse>(It.IsAny<string>()))
                .Returns(Task.FromResult(jobResponse));

            // Act
            var result = await this.jobApiClient.GetHostJobId(camInput);

            // Assert
            Assert.Equal(jobResponse.HqtrJobId, result);
            this.mockHttp.Verify(m => m.GetAsync<JobResponse>($"{camInput.DrAddressId}/Jobs/{camInput.LocalData.JobId}/BasicInfo"), Times.Once);
        }
    }
}
