// <copyright file="OrderingApiClientTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Formatting;
    using System.Threading.Tasks;
    using AutoFixture;
    using Moq;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using Xunit;

    /// <summary>
    /// Ordering api client test
    /// </summary>
    public class OrderingApiClientTest
    {
        private readonly Mock<IApiHttpClient> mockHttp;
        private readonly Mock<IUserApiClient> userApiClient;
        private readonly OrderingApiClient orderingApiClient;
        private readonly string orderingServiceUrl = "http://dont.com";
        private readonly CamData camData;
        private readonly CamInput camInput;
        private readonly CreditJobLockInput creditJobLockInput;
        private readonly LockInfo creditJobLockInfo;

        public OrderingApiClientTest()
        {
            this.mockHttp = new Mock<IApiHttpClient>();
            this.userApiClient = new Mock<IUserApiClient>();
            this.orderingApiClient = new OrderingApiClient(this.orderingServiceUrl, this.mockHttp.Object, this.userApiClient.Object);
            Fixture fixture = new Fixture();
            this.camData = fixture.Create<CamData>();
            this.camInput = fixture.Create<CamInput>();
            this.creditJobLockInput = fixture.Create<CreditJobLockInput>();
            this.creditJobLockInfo = fixture.Create<LockInfo>();
        }

        [Fact]
        public async Task GetCamLockInfo_HasData_ReturnsCamData()
        {
            // Arrange            
            this.mockHttp.Setup(m => m.PostAsync<CamData>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(this.camData));
            this.userApiClient.Setup(m => m.Search(It.IsAny<CamData>()))
                .Returns(Task.FromResult(this.camData));

            // Act
            var result = await this.orderingApiClient.GetCamLockInfo(this.camInput);

            // Assert            
            Assert.Equal(result, this.camData);
            this.mockHttp.Verify(m => m.PostAsync<CamData>($"{camInput.DrAddressId}/CreditJobs/CamLockInfo", It.IsAny<StringContent>()), Times.Once);
            this.userApiClient.Verify(m => m.Search(this.camData), Times.Once);
        }

        [Fact]
        public async Task GetLocalCreditJobId_DeosNotHaveData_ReturnsCreditJobIdAsNull()
        {
            // Arrange
            camInput.HostData.CreditJobId = 13958;
            IEnumerable<CreditJobResponse> creditJobResponses = null;

            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<CreditJobResponse>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(creditJobResponses));

            // Act
            var result = await this.orderingApiClient.GetLocalCreditJobId(camInput);

            // Assert
            Assert.Null(result);
            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<CreditJobResponse>>(
                $"{camInput.DrAddressId}/CreditJobs/PendingCreditJobs",
                It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task GetLocalCreditJobId_HasData_ReturnsCreditJobId()
        {
            // Arrange
            camInput.HostData.CreditJobId = 13958;
            IEnumerable<CreditJobResponse> creditJobResponses = new List<CreditJobResponse>
            {
                new CreditJobResponse{ CreditJobId = 15833, HqtrCreditJobId = 13958 }
            };

            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<CreditJobResponse>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(creditJobResponses));

            // Act
            var result = await this.orderingApiClient.GetLocalCreditJobId(camInput);

            // Assert
            Assert.Equal(creditJobResponses.First().CreditJobId, result);
            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<CreditJobResponse>>(
                $"{camInput.DrAddressId}/CreditJobs/PendingCreditJobs",
                It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task GetHostCreditJobId_StatusCodeNotFound_ReturnsNull()
        {
            // Arrange
            camInput.LocalData.CreditJobId = 12784;
            var response = new HttpResponseMessage(HttpStatusCode.NotFound);
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.orderingApiClient.GetHostCreditJobId(camInput);

            // Assert
            Assert.Null(result);
            this.mockHttp.Verify(m => m.GetAsync($"{camInput.DrAddressId}/CreditJobs/{camInput.LocalData.CreditJobId}/BasicInfo"), Times.Once);
        }

        [Fact]
        public async Task GetHostCreditJobId_DeosNotHaveData_ReturnsCreditJobIdAsNull()
        {
            // Arrange
            camInput.LocalData.CreditJobId = 12784;
            CreditJobResponse creditJobResponse = new CreditJobResponse { CreditJobId = 0 };

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<CreditJobResponse>(creditJobResponse, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.orderingApiClient.GetHostCreditJobId(camInput);

            // Assert
            Assert.Null(result);
            this.mockHttp.Verify(m => m.GetAsync($"{camInput.DrAddressId}/CreditJobs/{camInput.LocalData.CreditJobId}/BasicInfo"), Times.Once);
        }

        [Fact]
        public async Task GetHostCreditJobId_HasData_ReturnsCreditJobId()
        {
            // Arrange
            camInput.LocalData.CreditJobId = 12784;
            CreditJobResponse creditJobResponse = new CreditJobResponse { HqtrCreditJobId = 15936 };

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<CreditJobResponse>(creditJobResponse, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.orderingApiClient.GetHostCreditJobId(camInput);

            // Assert
            Assert.Equal(15936, result);
            this.mockHttp.Verify(m => m.GetAsync($"{camInput.DrAddressId}/CreditJobs/{camInput.LocalData.CreditJobId}/BasicInfo"), Times.Once);
        }

        [Fact]
        public async Task LockOrUnlockCreditJob_SendDataToOrderingService_ReturnsCreditJobLockOrUnlockInformation()
        {
            // Arrange
            bool isLockCreditJob = true;
            var fixture = new Fixture();
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<LockInfo>(creditJobLockInfo, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.orderingApiClient.LockOrUnlockCreditJob(isLockCreditJob, creditJobLockInput);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"{creditJobLockInput.DrAddressId}/CreditJobs/{creditJobLockInput.CreditJobId}/Lock?isCreditJobLock={isLockCreditJob}", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task LockOrUnlockCreditJob_SendDataToOrderingService_ReturnsConflictStatus()
        {
            // Arrange
            bool isLockCreditJob = true;
            var fixture = new Fixture();
            var response = new HttpResponseMessage(HttpStatusCode.Conflict)
            {
                Content = new ObjectContent<LockInfo>(creditJobLockInfo, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.orderingApiClient.LockOrUnlockCreditJob(isLockCreditJob, creditJobLockInput);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"{creditJobLockInput.DrAddressId}/CreditJobs/{creditJobLockInput.CreditJobId}/Lock?isCreditJobLock={isLockCreditJob}", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task SalesOrderLock_SalesOrderLockedSucessfully_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 76350;
            int drAddressId = 122;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.NoContent);
            this.mockHttp.Setup(m => m.PutAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
               .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderingApiClient.SalesOrderLock(drAddressId, creditJobId);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PutAsync($"{drAddressId}/CreditJobs/{creditJobId}/SalesOrders/Lock", null), Times.Once);
        }

        [Fact]
        public async Task SalesOrderLock_SalesOrderNotFound_ReturnsLockSuccessStatus()
        {
            // Arrange
            int creditJobId = 76350;
            int drAddressId = 122;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.NotFound);
            this.mockHttp.Setup(m => m.PutAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
               .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderingApiClient.SalesOrderLock(drAddressId, creditJobId);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PutAsync($"{drAddressId}/CreditJobs/{creditJobId}/SalesOrders/Lock", null), Times.Once);
        }

        [Fact]
        public async Task SalesOrderLock_SalesOrderLockFailed_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 76350;
            int drAddressId = 122;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.BadRequest);
            this.mockHttp.Setup(m => m.PutAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderingApiClient.SalesOrderLock(drAddressId, creditJobId);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PutAsync($"{drAddressId}/CreditJobs/{creditJobId}/SalesOrders/Lock", null), Times.Once);
        }
    }
}
