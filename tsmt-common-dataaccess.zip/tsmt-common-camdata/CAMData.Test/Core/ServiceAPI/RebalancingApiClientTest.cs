// <copyright file="RebalancingApiClientTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.ServiceAPI
{
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Formatting;
    using System.Threading.Tasks;
    using Moq;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using Xunit;

    /// <summary>
    /// Rebalancing api client test
    /// </summary>
    public class RebalancingApiClientTest
    {
        private readonly Mock<IApiHttpClient> mockHttp;
        private readonly RebalancingApiClient rebalancingApiClient;
        private readonly string rebalancingServiceUrl = "http://dont.com";

        public RebalancingApiClientTest()
        {
            this.mockHttp = new Mock<IApiHttpClient>();
            this.rebalancingApiClient = new RebalancingApiClient(this.rebalancingServiceUrl, this.mockHttp.Object);
        }

        [Fact]
        public async Task CheckAllowTransmit_DeosNotHaveData_ReturnsFalse()
        {
            // Arrange
            int drAddressId = 30;
            int jobId = 15885;
            int bidId = 13584;

            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.NotFound);
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.rebalancingApiClient.CheckAllowTransmit(drAddressId, jobId, bidId);

            // Assert
            Assert.False(result);
            this.mockHttp.Verify(m => m.GetAsync($"{drAddressId}/Jobs/{jobId}/Bids/{bidId}/Snapshot/AllowTransmit"), Times.Once);
        }

        [Fact]
        public async Task CheckAllowTransmit_TransmitNotAllowed_ReturnsFalse()
        {
            // Arrange
            int drAddressId = 30;
            int jobId = 68854;
            int bidId = 15775;

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<bool>(false, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.rebalancingApiClient.CheckAllowTransmit(drAddressId, jobId, bidId);

            // Assert
            Assert.False(result);
            this.mockHttp.Verify(m => m.GetAsync($"{drAddressId}/Jobs/{jobId}/Bids/{bidId}/Snapshot/AllowTransmit"), Times.Once);
        }

        [Fact]
        public async Task CheckAllowTransmit_TransmitAllowed_ReturnsTrue()
        {
            // Arrange
            int drAddressId = 30;
            int jobId = 48966;
            int bidId = 16897;

            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<bool>(true, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.rebalancingApiClient.CheckAllowTransmit(drAddressId, jobId, bidId);

            // Assert
            Assert.True(result);
            this.mockHttp.Verify(m => m.GetAsync($"{drAddressId}/Jobs/{jobId}/Bids/{bidId}/Snapshot/AllowTransmit"), Times.Once);
        }
    }
}
