// <copyright file="OrderApiClientTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.ServiceAPI
{
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Formatting;
    using System.Threading.Tasks;
    using AutoFixture;
    using Moq;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Data.Constants;
    using Xunit;
    using System.Linq;
    using System.Collections.Generic;
    using Newtonsoft.Json;
    using System.Text;

    /// <summary>
    /// Order api client test
    /// </summary>
    public class OrderApiClientTest
    {
        private readonly Mock<IApiHttpClient> mockHttp;
        private readonly Mock<IUserApiClient> userApiClient;
        private readonly OrderApiClient orderApiClient;
        private readonly string orderServiceUrl = "http://dont.com";
        private readonly CamData camData;
        private readonly CamInput camInput;
        private readonly LockInput orderLockInput;
        private readonly LockInfo orderLockInfo;

        public OrderApiClientTest()
        {
            this.mockHttp = new Mock<IApiHttpClient>();
            this.userApiClient = new Mock<IUserApiClient>();
            this.orderApiClient = new OrderApiClient(this.orderServiceUrl, this.mockHttp.Object, this.userApiClient.Object);
            Fixture fixture = new Fixture();
            this.camData = fixture.Create<CamData>();
            this.camInput = fixture.Create<CamInput>();
            this.orderLockInput = fixture.Create<LockInput>();
            this.orderLockInfo = fixture.Create<LockInfo>();
        }

        [Fact]
        public async Task GetCamLockInfo_HasData_ReturnsCamData()
        {
            // Arrange            
            this.mockHttp.Setup(m => m.PostAsync<CamData>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(this.camData));
            this.userApiClient.Setup(m => m.Search(It.IsAny<CamData>()))
                .Returns(Task.FromResult(this.camData));

            // Act
            var result = await this.orderApiClient.GetCamLockInfo(this.camInput);

            // Assert            
            Assert.Equal(result, this.camData);
            this.mockHttp.Verify(m => m.PostAsync<CamData>("Jobs/CamLockInfo", It.IsAny<StringContent>()), Times.Once);
            this.userApiClient.Verify(m => m.Search(this.camData), Times.Once);
        }

        [Fact]
        public async Task LockOrUnlockJob_SendDataToOrderService_ReturnsJobLockOrUnlockinformation()
        {
            // Arrange
            bool isLockJob = true;
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<LockInfo>(this.orderLockInfo, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.orderApiClient.LockOrUnlockJob(isLockJob, orderLockInput);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"Jobs/{orderLockInput.JobId}/Lock?lockJob={isLockJob}", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task LockOrUnlockJob_SendDataToOrderService_ReturnsConflictStatus()
        {
            // Arrange
            bool isLockJob = true;
            var fixture = new Fixture();
            var response = new HttpResponseMessage(HttpStatusCode.Conflict)
            {
                Content = new ObjectContent<LockInfo>(this.orderLockInfo, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.orderApiClient.LockOrUnlockJob(isLockJob, orderLockInput);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"Jobs/{orderLockInput.JobId}/Lock?lockJob={isLockJob}", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task AllHostLock_LockFalied_ReturnsLockStatusWithFailed()
        {
            // Arrange
            var fixture = new Fixture();
            HostLockInput hostLockInput = fixture.Create<HostLockInput>();
            HostLockResponse hostLockResponse = fixture.Create<HostLockResponse>();
            hostLockResponse.IsLockSuccess = false;

            this.mockHttp.Setup(m => m.PostAsync<HostLockResponse>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(hostLockResponse));

            // Act
            var result = await this.orderApiClient.AllHostLock(hostLockInput);

            // Assert
            Assert.False(result.IsSuccessful);
            Assert.Equal(result.Messages.First(), Constants.HostLockFailed);
            this.mockHttp.Verify(m => m.PostAsync<HostLockResponse>("CreditJobs/AllHostLock", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task AllHostLock_LockSuccess_ReturnsLockStatusWithSuccess()
        {
            // Arrange
            var fixture = new Fixture();
            HostLockInput hostLockInput = fixture.Create<HostLockInput>();
            HostLockResponse hostLockResponse = fixture.Create<HostLockResponse>();
            hostLockResponse.IsLockSuccess = true;

            this.mockHttp.Setup(m => m.PostAsync<HostLockResponse>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(hostLockResponse));

            // Act
            var result = await this.orderApiClient.AllHostLock(hostLockInput);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync<HostLockResponse>("CreditJobs/AllHostLock", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task ResetHostLock_LockFalied_ReturnsLockStatusWithFailed()
        {
            // Arrange
            var fixture = new Fixture();
            HostLockInput hostLockInput = fixture.Create<HostLockInput>();
            HostLockResponse hostLockResponse = fixture.Create<HostLockResponse>();
            hostLockResponse.IsLockSuccess = false;

            this.mockHttp.Setup(m => m.PostAsync<HostLockResponse>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(hostLockResponse));

            // Act
            var result = await this.orderApiClient.ResetHostLock(hostLockInput);

            // Assert
            Assert.False(result.IsSuccessful);
            Assert.Equal(result.Messages.First(), Constants.HostResetLockFailed);
            this.mockHttp.Verify(m => m.PostAsync<HostLockResponse>("CreditJobs/ResetLock", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task ResetHostLock_LockSuccess_ReturnsLockStatusWithSuccess()
        {
            // Arrange
            var fixture = new Fixture();
            HostLockInput hostLockInput = fixture.Create<HostLockInput>();
            HostLockResponse hostLockResponse = fixture.Create<HostLockResponse>();
            hostLockResponse.IsLockSuccess = true;

            this.mockHttp.Setup(m => m.PostAsync<HostLockResponse>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(hostLockResponse));

            // Act
            var result = await this.orderApiClient.ResetHostLock(hostLockInput);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync<HostLockResponse>("CreditJobs/ResetLock", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task TransmitReleaseSalesOrderLock_ReleasedLockSucessfully_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 254565;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.NoContent);
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.TransmitReleaseSalesOrderLock(creditJobId);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"CreditJobs/{creditJobId}/SalesOrders/TransmitReleaseLock", null), Times.Once);
        }

        [Fact]
        public async Task TransmitReleaseSalesOrderLock_ReleaseLockFailed_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 13084;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.BadRequest);
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.TransmitReleaseSalesOrderLock(creditJobId);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"CreditJobs/{creditJobId}/SalesOrders/TransmitReleaseLock", null), Times.Once);
        }

        [Fact]
        public async Task ReleaseSalesOrderLock_ReleasedSalesOrderLockSucessfully_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 14829;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.NoContent);
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.ReleaseSalesOrderLock(creditJobId);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"CreditJobs/{creditJobId}/SalesOrders/ReleaseLock", null), Times.Once);
        }

        [Fact]
        public async Task ReleaseSalesOrderLock_ReleaseLockFailed_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 13084;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.BadRequest);
            this.mockHttp.Setup(m => m.PostAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.ReleaseSalesOrderLock(creditJobId);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PostAsync($"CreditJobs/{creditJobId}/SalesOrders/ReleaseLock", null), Times.Once);
        }

        [Fact]
        public async Task ReleaseCreditJobLock_ReleasedCreditJobLockSucessfully_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 5436;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.NoContent);
            this.mockHttp.Setup(m => m.PutAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.ReleaseCreditJobLock(creditJobId);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PutAsync($"CreditJobs/{creditJobId}/ReleaseLock", null), Times.Once);
        }

        [Fact]
        public async Task ReleaseCreditJobLock_ReleaseLockFailed_ReturnsLockStatus()
        {
            // Arrange
            int creditJobId = 5436;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.BadRequest);
            this.mockHttp.Setup(m => m.PutAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.ReleaseCreditJobLock(creditJobId);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PutAsync($"CreditJobs/{creditJobId}/ReleaseLock", null), Times.Once);
        }

        [Fact]
        public async Task ApplyHostSalesOrderLock_ApplyLockSucessfully_ReturnsLockStatus()
        {
            // Arrange
            IEnumerable<int> salesOrderIds = new List<int>
            {
                16733, 15832
            };
            ApplyLockOrUnlock applyLockOrUnlock = new ApplyLockOrUnlock() { SalesOrderIds = salesOrderIds, LockApplication = "BuomTemp", ApplyLock = true };
            StringContent content = new StringContent(JsonConvert.SerializeObject(applyLockOrUnlock), Encoding.UTF8, "application/json");
            string lockApplication = "BuomTemp";
            bool applyLock = true;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.NoContent);
            this.mockHttp.Setup(m => m.PutAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.ApplyHostSalesOrderLockOrUnlock(salesOrderIds, lockApplication, applyLock);

            // Assert
            Assert.True(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PutAsync($"SalesOrders/Lock/{lockApplication}?applyLock={applyLock}", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task ApplyHostSalesOrderLock_ApplyLockFailed_ReturnsLockStatus()
        {
            // Arrange
            IEnumerable<int> salesOrderIds = new List<int>
            {
                0, 0
            };
            string lockApplication = "FOE";
            bool applyLock = true;
            HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.BadRequest);
            this.mockHttp.Setup(m => m.PutAsync(It.IsAny<string>(), It.IsAny<StringContent>()))
                .Returns(Task.FromResult(response));

            // Act
            LockStatus result = await this.orderApiClient.ApplyHostSalesOrderLockOrUnlock(salesOrderIds, lockApplication, applyLock);

            // Assert
            Assert.False(result.IsSuccessful);
            this.mockHttp.Verify(m => m.PutAsync($"SalesOrders/Lock/{lockApplication}?applyLock={applyLock}", It.IsAny<StringContent>()), Times.Once);
        }
    }
}
