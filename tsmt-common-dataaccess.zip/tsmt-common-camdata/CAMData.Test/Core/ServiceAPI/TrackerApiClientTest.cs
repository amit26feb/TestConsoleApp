// <copyright file="TrackerApiClientTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Formatting;
    using System.Threading.Tasks;
    using AutoFixture;
    using Moq;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using Xunit;

    /// <summary>
    /// Tracker api client test
    /// </summary>
    public class TrackerApiClientTest
    {
        private readonly Mock<IApiHttpClient> mockHttp;
        private readonly TrackerApiClient trackerApiClient;
        private readonly string trackerServiceUrl = "http://dont.com";
        private readonly string entityName = "CreditJob";
        private string entityId = "19934";

        public TrackerApiClientTest()
        {
            this.mockHttp = new Mock<IApiHttpClient>();
            this.trackerApiClient = new TrackerApiClient(this.trackerServiceUrl, this.mockHttp.Object);
        }

        [Fact]
        public async Task GetOpenTrackerTags_HasNoData_ReturnsNull()
        {
            // Arrange
            this.entityId = "18545";
            var response = new HttpResponseMessage(HttpStatusCode.NoContent);
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.trackerApiClient.GetOpenTrackerTags(this.entityId, this.entityName);

            // Assert
            Assert.Null(result);
            this.mockHttp.Verify(m => m.GetAsync($"Tracker/OpenTrackerTags?entityName={this.entityName}&entityId={this.entityId}"), Times.Once);
        }

        [Fact]
        public async Task GetOpenTrackerTags_HasData_ReturnsEntityTrackers()
        {
            // Arrange
            this.entityId = "158992";
            Fixture fixture = new Fixture();
            IEnumerable<TagEntityTracker> tagEntityTrackers = fixture.CreateMany<TagEntityTracker>(5);
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ObjectContent<IEnumerable<TagEntityTracker>>(tagEntityTrackers, new JsonMediaTypeFormatter())
            };
            this.mockHttp.Setup(m => m.GetAsync(It.IsAny<string>()))
                .Returns(Task.FromResult(response));

            // Act
            var result = await this.trackerApiClient.GetOpenTrackerTags(this.entityId, this.entityName);

            // Assert            
            Assert.Equal(result, tagEntityTrackers);
            this.mockHttp.Verify(m => m.GetAsync($"Tracker/OpenTrackerTags?entityName={this.entityName}&entityId={this.entityId}"), Times.Once);
        }
    }
}
