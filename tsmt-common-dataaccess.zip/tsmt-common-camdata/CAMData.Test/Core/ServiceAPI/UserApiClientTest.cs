// <copyright file="UserClientAPITest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Threading.Tasks;
    using AutoFixture;
    using CAMData.Test.Core.Common;
    using Moq;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Constants;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using Xunit;

    public class UserApiClientTest
    {
        private readonly Mock<IApiHttpClient> mockHttp;
        private readonly UserApiClient userApiClient;
        private readonly string userServiceUrl = "http://dont.com";
        private readonly CamData camData;
        private readonly string testUserId;

        public UserApiClientTest()
        {
            this.mockHttp = new Mock<IApiHttpClient>();
            this.userApiClient = new UserApiClient(this.userServiceUrl, this.mockHttp.Object);
            Fixture fixture = new Fixture();
            this.camData = fixture.Create<CamData>();
            testUserId = "tstuid";
        }

        [Fact]
        public async Task ActiveDirectorySearch_HasData_ReturnsActiveSearchData()
        {
            // Arrange
            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .ReturnsAsync(Helper.GetActiveDirectoryModels);

            // Act
            var result = await this.userApiClient.ActiveDirectorySearch(Helper.GetFilterModels());

            // Assert
            Assert.NotNull(result);
            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>("Users/ActiveDirectory/Search", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task ActiveDirectorySearch_EmptyData_ReturnsEmptySearchData()
        {
            // Arrange
            IEnumerable<ActiveDirectoryModel> expectedModel = new List<ActiveDirectoryModel>();
            IEnumerable<FilterModel> filterModel = new List<FilterModel>();
            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .ReturnsAsync(expectedModel);

            // Act
            var result = await this.userApiClient.ActiveDirectorySearch(filterModel);

            // Assert
            Assert.Equal(result, expectedModel);
            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>()), Times.Never);
        }

        [Fact]
        public async Task ActiveDirectorySearch_NullInput_ReturnsEmptySearchData()
        {
            // Arrange
            IEnumerable<ActiveDirectoryModel> expectedModel = new List<ActiveDirectoryModel>();
            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .ReturnsAsync(expectedModel);

            // Act
            var result = await this.userApiClient.ActiveDirectorySearch(null);

            // Assert
            Assert.Equal(result, expectedModel);
            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>()), Times.Never);
        }

        [Fact]
        public async Task Search_HasValidUserId_ReturnsCamData()
        {
            // Arrange
            this.camData.HostLock.LockUserId = testUserId;
            this.camData.LocalLock.LockUserId = testUserId;
            this.camData.HostLock.CreditProjectLocks.ToList().ForEach(x => { x.LockUserId = testUserId; x.SalesOrderLocks.ToList().ForEach(y => y.LockUserId = testUserId); });
            this.camData.LocalLock.CreditProjectLocks.ToList().ForEach(x => { x.LockUserId = testUserId; x.SalesOrderLocks.ToList().ForEach(y => y.LockUserId = testUserId); });

            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .ReturnsAsync(Helper.GetActiveDirectoryModels);

            // Act
            var result = await this.userApiClient.Search(this.camData);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result, this.camData);

            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>("Users/ActiveDirectory/Search", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task Search_HasInvalidUserId_ReturnsCamData()
        {
            // Arrange
            this.camData.HostLock.LockUserId = "server";
            this.camData.LocalLock.LockUserId = "server";

            this.camData.LocalLock.LockUserName = null;
            this.camData.HostLock.LockUserName = null;

            this.camData.HostLock.CreditProjectLocks.ToList().ForEach(x => { x.LockUserId = "server"; x.SalesOrderLocks.ToList().ForEach(y => y.LockUserId = "server"); });
            this.camData.LocalLock.CreditProjectLocks.ToList().ForEach(x => { x.LockUserId = "server"; x.SalesOrderLocks.ToList().ForEach(y => y.LockUserId = "server"); });

            IEnumerable<ActiveDirectoryModel> activeDirectoryModels = null;

            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>())).ReturnsAsync(activeDirectoryModels);

            // Act
            var result = await this.userApiClient.Search(this.camData);

            // Assert
            Assert.NotNull(result);
            Assert.Null(result.LocalLock.LockUserName);
            Assert.Equal(result, this.camData);

            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>("Users/ActiveDirectory/Search", It.IsAny<StringContent>()), Times.Once);
        }

        [Fact]
        public async Task Search_HasNullUserId_ReturnsCamData()
        {
            // Arrange
            this.camData.HostLock.LockUserId = null;
            this.camData.HostLock.LockUserName = null;
            this.camData.LocalLock.LockUserId = null;
            this.camData.LocalLock.LockUserName = null;
            this.camData.HostLock.CreditProjectLocks.ToList().ForEach(x => { x.LockUserId = null; x.LockUserName = null; x.SalesOrderLocks.ToList().ForEach(y => { y.LockUserId = null; y.LockUserName = null; }); });
            this.camData.LocalLock.CreditProjectLocks.ToList().ForEach(x => { x.LockUserId = null; x.LockUserName = null; x.SalesOrderLocks.ToList().ForEach(y => { y.LockUserId = null; y.LockUserName = null; }); });

            this.mockHttp.Setup(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>(It.IsAny<string>(), It.IsAny<StringContent>()))
                .ReturnsAsync(Helper.GetActiveDirectoryModels());

            // Act
            var result = await this.userApiClient.Search(this.camData);

            // Assert
            Assert.NotNull(result);
            Assert.Null(result.HostLock.GetType().GetProperty(Constants.LockUserNameProperty).GetValue(result.HostLock));
            Assert.Null(result.LocalLock.GetType().GetProperty(Constants.LockUserNameProperty).GetValue(result.LocalLock));

            this.mockHttp.Verify(m => m.PostAsync<IEnumerable<ActiveDirectoryModel>>("Users/ActiveDirectory/Search", It.IsAny<StringContent>()), Times.Never);
        }
    }
}
