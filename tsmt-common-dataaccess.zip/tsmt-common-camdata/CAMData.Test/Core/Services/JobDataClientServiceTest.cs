// <copyright file="JobDataClientServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.Services
{
    using System.Threading.Tasks;
    using AutoFixture;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Data.Core.Services;
    using Xunit;

    public class JobDataClientServiceTest
    {
        private readonly JobDataClientService jobDataClientService;
        private readonly Mock<IJobApiClient> jobApiClientServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobDataClientServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public JobDataClientServiceTest()
        {
            this.jobApiClientServiceMock = new Mock<IJobApiClient>();
            this.jobDataClientService = new JobDataClientService(this.jobApiClientServiceMock.Object);
        }

        [Fact]
        public async Task GetCamInfo_LocalDataJobIdInvalid_ReturnsNull()
        {
            // Arrange
            var fixture = new Fixture();
            CamInput camInput = fixture.Create<CamInput>();
            camInput.LocalData.JobId = 0;

            // Act
            var actualResult = await this.jobDataClientService.GetCamInfo(camInput);

            // Assert
            Assert.Null(actualResult);
            this.jobApiClientServiceMock.Verify(m => m.GetCamLockInfo(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetCamInfo_LoadDataFromJobService_ReturnsCamData()
        {
            // Arrange
            var fixture = new Fixture();
            CamInput camInput = fixture.Create<CamInput>();
            CamData camData = fixture.Create<CamData>();
            this.jobApiClientServiceMock.Setup(x => x.GetCamLockInfo(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(camData));

            // Act
            var actualResult = await this.jobDataClientService.GetCamInfo(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.Equal(camData, actualResult);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasBothHostAndLocalData_ReturnsCamInput()
        {
            // Arrange
            CamInput camInput = new CamInput
            {
                HostData = new CamInputMetaData { CreditJobId = 13584, JobId = 3685 },
                LocalData = new CamInputMetaData { CreditJobId = 14635, JobId = 2697 }
            };

            // Act
            var actualResult = await this.jobDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.Equal(camInput, actualResult);
            this.jobApiClientServiceMock.Verify(m => m.GetHostJobId(It.IsAny<CamInput>()), Times.Never);
            this.jobApiClientServiceMock.Verify(m => m.GetLocalJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasHostDataGetsLocalDataAsNull_ReturnsCamInput()
        {
            // Arrange
            int? localJobId = null;
            CamInput camInput = new CamInput
            {
                HostData = new CamInputMetaData { CreditJobId = 15735, JobId = 44772 }
            };
            this.jobApiClientServiceMock.Setup(x => x.GetLocalJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(localJobId));

            // Act
            var actualResult = await this.jobDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.LocalData.JobId == 0);
            this.jobApiClientServiceMock.Verify(m => m.GetLocalJobId(It.IsAny<CamInput>()), Times.Once);
            this.jobApiClientServiceMock.Verify(m => m.GetHostJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasHostDataGetsLocalData_ReturnsCamInput()
        {
            // Arrange
            int? localJobId = 16543;
            CamInput camInput = new CamInput
            {
                HostData = new CamInputMetaData { CreditJobId = 14685, JobId = 37854 }
            };
            this.jobApiClientServiceMock.Setup(x => x.GetLocalJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(localJobId));

            // Act
            var actualResult = await this.jobDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.LocalData.JobId == localJobId);
            this.jobApiClientServiceMock.Verify(m => m.GetLocalJobId(It.IsAny<CamInput>()), Times.Once);
            this.jobApiClientServiceMock.Verify(m => m.GetHostJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasLocalDataGetsHostDataAsNull_ReturnsCamInput()
        {
            // Arrange
            int? hostJobId = null;
            CamInput camInput = new CamInput
            {
                LocalData = new CamInputMetaData { CreditJobId = 16383, JobId = 37543 }
            };
            this.jobApiClientServiceMock.Setup(x => x.GetHostJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(hostJobId));

            // Act
            var actualResult = await this.jobDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.HostData.JobId == 0);
            this.jobApiClientServiceMock.Verify(m => m.GetHostJobId(It.IsAny<CamInput>()), Times.Once);
            this.jobApiClientServiceMock.Verify(m => m.GetLocalJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasLocalDataGetsHostData_ReturnsCamInput()
        {
            // Arrange
            int? hostJobId = 14764;
            CamInput camInput = new CamInput
            {
                LocalData = new CamInputMetaData { CreditJobId = 13243, JobId = 37954 }
            };
            this.jobApiClientServiceMock.Setup(x => x.GetHostJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(hostJobId));

            // Act
            var actualResult = await this.jobDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.HostData.JobId == hostJobId);
            this.jobApiClientServiceMock.Verify(m => m.GetHostJobId(It.IsAny<CamInput>()), Times.Once);
            this.jobApiClientServiceMock.Verify(m => m.GetLocalJobId(It.IsAny<CamInput>()), Times.Never);
        }
    }
}
