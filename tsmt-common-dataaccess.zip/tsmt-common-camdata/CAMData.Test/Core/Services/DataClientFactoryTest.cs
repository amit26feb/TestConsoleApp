// <copyright file="DataClientFactoryTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.Services
{
    using System.Collections.Generic;
    using Moq;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Data.Core.Services;
    using Xunit;

    public class DataClientFactoryTest
    {
        private readonly Mock<IOrderApiClient> orderApiClientMock;
        private readonly Mock<IOrderingApiClient> orderingApiClientMock;
        private readonly Mock<IJobApiClient> jobApiClientMock;
        private readonly DataClientFactory dataClientFactory;
        private readonly IEnumerable<IDataClientService> serviceClients;        
        private readonly IDataClientService jobDataClientService;
        private readonly IDataClientService orderDataClientService;
        private readonly IDataClientService orderingDataClientService;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataClientFactoryTest"/> class.
        /// Constructor.
        /// </summary>
        public DataClientFactoryTest()
        {
            this.orderApiClientMock = new Mock<IOrderApiClient>();
            this.orderingApiClientMock = new Mock<IOrderingApiClient>();
            this.jobApiClientMock = new Mock<IJobApiClient>();
            this.jobDataClientService = new JobDataClientService(this.jobApiClientMock.Object);
            this.orderDataClientService = new OrderDataClientService(this.orderApiClientMock.Object);
            this.orderingDataClientService = new OrderingDataClientService(this.orderingApiClientMock.Object);
            this.serviceClients = new List<IDataClientService>()
            {
                this.jobDataClientService,
                this.orderDataClientService,
                this.orderingDataClientService
            };            

            this.dataClientFactory = new DataClientFactory(this.serviceClients);
        }

        [Fact]
        public void GetServiceClient_JobServiceIsImplemented_ReturnsJobService()
        {
            // Act
            var actualResult = this.dataClientFactory.GetServiceClientInstance(ServiceClient.Job);

            // Assert
            Assert.Equal(ServiceClient.Job, actualResult.ServiceContext);
        }

        [Fact]
        public void GetServiceClient_OrderServiceIsImplemented_ReturnsOrderService()
        {
            // Act
            var actualResult = this.dataClientFactory.GetServiceClientInstance(ServiceClient.Order);

            // Assert
            Assert.Equal(ServiceClient.Order, actualResult.ServiceContext);
        }

        [Fact]
        public void GetServiceClient_OrderingServiceIsImplemented_ReturnsOrderingService()
        {
            // Act
            var actualResult = this.dataClientFactory.GetServiceClientInstance(ServiceClient.Ordering);

            // Assert
            Assert.Equal(ServiceClient.Ordering, actualResult.ServiceContext);
        }
    }
}
