// <copyright file="OrderingDataClientServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.Services
{
    using System.Threading.Tasks;
    using AutoFixture;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.Services;
    using Xunit;
    using Moq;
    using TSMT.CAM.Data.Core.ServiceAPI;

    public class OrderingDataClientServiceTest
    {
        private readonly OrderingDataClientService orderingDataClientService;
        private readonly Mock<IOrderingApiClient> orderingApiClientServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderingDataClientServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public OrderingDataClientServiceTest()
        {
            this.orderingApiClientServiceMock = new Mock<IOrderingApiClient>();
            this.orderingDataClientService = new OrderingDataClientService(this.orderingApiClientServiceMock.Object);
        }

        [Fact]
        public async Task GetCamInfo_LocalDataCreditJobIdInvalid_ReturnsNull()
        {
            // Arrange
            var fixture = new Fixture();
            CamInput camInput = fixture.Create<CamInput>();
            camInput.LocalData.CreditJobId = 0;

            // Act
            var actualResult = await this.orderingDataClientService.GetCamInfo(camInput);

            // Assert
            Assert.Null(actualResult);
            this.orderingApiClientServiceMock.Verify(m => m.GetCamLockInfo(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetCamInfo_LoadDataFromOrderingService_ReturnsCamData()
        {
            // Arrange
            var fixture = new Fixture();
            CamInput camInput = fixture.Create<CamInput>();
            CamData camData = fixture.Create<CamData>();
            this.orderingApiClientServiceMock.Setup(x => x.GetCamLockInfo(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(camData));

            // Act
            var actualResult = await this.orderingDataClientService.GetCamInfo(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.Equal(camData, actualResult);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasBothHostAndLocalData_ReturnsCamInput()
        {
            // Arrange
            CamInput camInput = new CamInput
            {
                HostData = new CamInputMetaData { CreditJobId = 13584, JobId = 3685 },
                LocalData = new CamInputMetaData { CreditJobId = 14635, JobId = 2697 }
            };

            // Act
            var actualResult = await this.orderingDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.Equal(camInput, actualResult);
            this.orderingApiClientServiceMock.Verify(m => m.GetHostCreditJobId(It.IsAny<CamInput>()), Times.Never);
            this.orderingApiClientServiceMock.Verify(m => m.GetLocalCreditJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasHostDataGetsLocalDataAsNull_ReturnsCamInput()
        {
            // Arrange
            int? localCreditJobId = null;
            CamInput camInput = new CamInput
            {
                HostData = new CamInputMetaData { CreditJobId = 15735, JobId = 44772 }
            };
            this.orderingApiClientServiceMock.Setup(x => x.GetLocalCreditJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(localCreditJobId));

            // Act
            var actualResult = await this.orderingDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.LocalData.CreditJobId == 0);
            this.orderingApiClientServiceMock.Verify(m => m.GetLocalCreditJobId(It.IsAny<CamInput>()), Times.Once);
            this.orderingApiClientServiceMock.Verify(m => m.GetHostCreditJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasHostDataGetsLocalData_ReturnsCamInput()
        {
            // Arrange
            int? localCreditJobId = 16543;
            CamInput camInput = new CamInput
            {
                HostData = new CamInputMetaData { CreditJobId = 14685, JobId = 37854 }
            };
            this.orderingApiClientServiceMock.Setup(x => x.GetLocalCreditJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(localCreditJobId));

            // Act
            var actualResult = await this.orderingDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.LocalData.CreditJobId == localCreditJobId);
            this.orderingApiClientServiceMock.Verify(m => m.GetLocalCreditJobId(It.IsAny<CamInput>()), Times.Once);
            this.orderingApiClientServiceMock.Verify(m => m.GetHostCreditJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasLocalDataGetsHostDataAsNull_ReturnsCamInput()
        {
            // Arrange
            int? hostCreditJobId = null;
            CamInput camInput = new CamInput
            {
                LocalData = new CamInputMetaData { CreditJobId = 16383, JobId = 37543 }
            };
            this.orderingApiClientServiceMock.Setup(x => x.GetHostCreditJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(hostCreditJobId));

            // Act
            var actualResult = await this.orderingDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.HostData.CreditJobId == 0);
            this.orderingApiClientServiceMock.Verify(m => m.GetHostCreditJobId(It.IsAny<CamInput>()), Times.Once);
            this.orderingApiClientServiceMock.Verify(m => m.GetLocalCreditJobId(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetEnrichedCamInput_HasLocalDataGetsHostData_ReturnsCamInput()
        {
            // Arrange
            int? hostCreditJobId = 14764;
            CamInput camInput = new CamInput
            {
                LocalData = new CamInputMetaData { CreditJobId = 13243, JobId = 37954 }
            };
            this.orderingApiClientServiceMock.Setup(x => x.GetHostCreditJobId(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(hostCreditJobId));

            // Act
            var actualResult = await this.orderingDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.NotNull(actualResult);
            Assert.True(actualResult.HostData.CreditJobId == hostCreditJobId);
            this.orderingApiClientServiceMock.Verify(m => m.GetHostCreditJobId(It.IsAny<CamInput>()), Times.Once);
            this.orderingApiClientServiceMock.Verify(m => m.GetLocalCreditJobId(It.IsAny<CamInput>()), Times.Never);
        }
    }
}
