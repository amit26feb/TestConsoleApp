// <copyright file="OrderDataClientServiceTest.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace CAMData.Test.Core.Services
{
    using System.Threading.Tasks;
    using AutoFixture;
    using Moq;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;
    using TSMT.CAM.Data.Core.Services;
    using Xunit;

    public class OrderDataClientServiceTest
    {
        private readonly OrderDataClientService orderDataClientService;
        private readonly Mock<IOrderApiClient> orderApiClientServiceMock;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderDataClientServiceTest"/> class.
        /// Constructor.
        /// </summary>
        public OrderDataClientServiceTest()
        {
            this.orderApiClientServiceMock = new Mock<IOrderApiClient>();
            this.orderDataClientService = new OrderDataClientService(this.orderApiClientServiceMock.Object);
        }

        [Fact]
        public async Task GetCamInfo_HostDataJobIdInvalid_ReturnsNull()
        {
            // Arrange
            var fixture = new Fixture();
            CamInput camInput = fixture.Create<CamInput>();
            camInput.HostData.JobId = 0;

            // Act
            var actualResult = await this.orderDataClientService.GetCamInfo(camInput);

            // Assert
            Assert.Null(actualResult);
            this.orderApiClientServiceMock.Verify(m => m.GetCamLockInfo(It.IsAny<CamInput>()), Times.Never);
        }

        [Fact]
        public async Task GetCamInfo_LoadDataFromOrderService_ReturnsCamData()
        {
            // Arrange
            var fixture = new Fixture();
            CamInput camInput = fixture.Create<CamInput>();
            CamData camData = fixture.Create<CamData>();
            this.orderApiClientServiceMock.Setup(x => x.GetCamLockInfo(It.IsAny<CamInput>()))
                .Returns(Task.FromResult(camData));
                
            // Act
            var actualResult = await this.orderDataClientService.GetCamInfo(camInput);

            // Assert
            Assert.Equal(camData, actualResult);
        }

        [Fact]
        public async Task GetEnrichedCamInput_DoesNotEnrichData_ReturnsCamInput()
        {
            // Arrange
            var fixture = new Fixture();
            CamInput camInput = fixture.Create<CamInput>();

            // Act
            var actualResult = await this.orderDataClientService.GetEnrichedCamInput(camInput);

            // Assert
            Assert.Equal(camInput, actualResult);
        }
    }
}
