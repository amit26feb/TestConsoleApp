// <copyright file="RebalancingApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Net.Http;
    using System.Threading.Tasks;
    using TSMT.ApiClient;

    /// <summary>
    /// Rebalancing api client
    /// </summary>
    public class RebalancingApiClient : IRebalancingApiClient
    {
        private readonly IApiHttpClient httpClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="RebalancingApiClient"/> class
        /// </summary>
        /// <param name="rebalancingServiceUrl">Rebalancing service url</param>
        /// <param name="httpClient">Http client</param>
        public RebalancingApiClient(
            string rebalancingServiceUrl,
            IApiHttpClient httpClient)
        {
            httpClient.SetBaseAddress(rebalancingServiceUrl);
            this.httpClient = httpClient;
        }

        /// <summary>
        /// Check allow transmit for the job id and bid id
        /// </summary>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="jobId">Job id</param>
        /// <param name="bidId">Bid id</param>
        /// <returns>Boolean</returns>
        public async Task<bool> CheckAllowTransmit(int drAddressId, int jobId, int bidId)
        {
            HttpResponseMessage response = await this.httpClient.GetAsync($"{drAddressId}/Jobs/{jobId}/Bids/{bidId}/Snapshot/AllowTransmit");
            if (response.StatusCode == System.Net.HttpStatusCode.OK && response.IsSuccessStatusCode)
            {
                bool canTransmit = await response.Content.ReadAsAsync<bool>();
                return canTransmit;
            }

            return false;
        }
    }
}
