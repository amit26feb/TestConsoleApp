// <copyright file="IOrderingApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Ordering api client interface
    /// </summary>
    public interface IOrderingApiClient
    {
        /// <summary>
        /// Get cam lock info by job/credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Cam lock data for the credit job and sales orders</returns>
        Task<CamData> GetCamLockInfo(CamInput camInput);

        /// <summary>
        /// Get local credit job id(TS data base) based on the hqtr credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Local credit job id</returns>
        Task<int?> GetLocalCreditJobId(CamInput camInput);

        /// <summary>
        /// Get host credit job id(ES data base) based on the credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Hoast credit job id</returns>
        Task<int?> GetHostCreditJobId(CamInput camInput);

        /// <summary>
        /// Lock or unlock credit job based on isLockCreditJob value(true / false)
        /// </summary>
        /// <param name="isLockCreditJob">Lock or unlock credit job</param>
        /// <param name="creditJobLockInput">Credit job lock input</param>
        /// <returns>Credit job lock status information</returns>
        Task<LockStatus> LockOrUnlockCreditJob(bool isLockCreditJob, CreditJobLockInput creditJobLockInput);

        /// <summary>
        /// Locks sales order by credit job id
        /// </summary>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        Task<LockStatus> SalesOrderLock(int drAddressId, int creditJobId);
    }
}
