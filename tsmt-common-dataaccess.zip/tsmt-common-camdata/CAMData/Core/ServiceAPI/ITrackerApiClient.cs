// <copyright file="ITrackerApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Tracker api client interface
    /// </summary>
    public interface ITrackerApiClient
    {
        /// <summary>
        /// Get open tracker tags
        /// </summary>
        /// <param name="entityId">Entity id</param>
        /// <param name="entityName">Entity name</param>
        /// <returns>Tag entity tracker</returns>
        Task<IEnumerable<TagEntityTracker>> GetOpenTrackerTags(string entityId, string entityName);
    }
}
