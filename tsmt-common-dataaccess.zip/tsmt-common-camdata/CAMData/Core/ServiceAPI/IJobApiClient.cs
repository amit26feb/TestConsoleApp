// <copyright file="IJobApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Job api client interface
    /// </summary>
    public interface IJobApiClient
    {
        /// <summary>
        /// Get cam lock info by job id
        /// Job id in cam input holds hqtr job id value.
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Cam Lock data for job</returns>
        Task<CamData> GetCamLockInfo(CamInput camInput);

        /// <summary>
        /// Lock or unlock job based on islockjob value(true / false)
        /// </summary>
        /// <param name="isLockJob">Lock or unlock job</param>
        /// <param name="jobLockInput">Job lock input</param>
        /// <returns>Job lock status information</returns>
        Task<LockStatus> LockOrUnlockJob(bool isLockJob, LockInput jobLockInput);

        /// <summary>
        /// Get local job id(TS data base) based on the hqtr job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Local job id</returns>
        Task<int?> GetLocalJobId(CamInput camInput);

        /// <summary>
        /// Get host job id(ES data base) based on the job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Host job id</returns>
        Task<int?> GetHostJobId(CamInput camInput);
    }
}
