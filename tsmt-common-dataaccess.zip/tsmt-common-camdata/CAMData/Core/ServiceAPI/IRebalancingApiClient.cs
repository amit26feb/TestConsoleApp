// <copyright file="IRebalancingApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Threading.Tasks;

    /// <summary>
    /// Interface for rebalancing api client
    /// </summary>
    public interface IRebalancingApiClient
    {
        /// <summary>
        /// Check allow transmit for the job id and bid id
        /// </summary>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="jobId">Job id</param>
        /// <param name="bidId">Bid id</param>
        /// <returns>Boolean</returns>
        Task<bool> CheckAllowTransmit(int drAddressId, int jobId, int bidId);
    }
}
