// <copyright file="JobApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Constants;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Job api client
    /// </summary>
    public class JobApiClient : IJobApiClient
    {
        private readonly IApiHttpClient httpClient;
        private readonly IUserApiClient userApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobApiClient"/> class
        /// </summary>
        /// <param name="jobServiceUrl">Job service url</param>
        /// <param name="httpClient">Http client</param>
        /// <param name="userApiClient">User api client</param>
        public JobApiClient(
            string jobServiceUrl,
            IApiHttpClient httpClient,
            IUserApiClient userApiClient)
        {
            httpClient.SetBaseAddress(jobServiceUrl);
            this.httpClient = httpClient;
            this.userApiClient = userApiClient;
        }

        /// <summary>
        /// Get cam lock info by job/credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Cam Lock data for job</returns>
        public async Task<CamData> GetCamLockInfo(CamInput camInput)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(camInput), Encoding.UTF8, "application/json");
            CamData camInputData = this.httpClient.PostAsync<CamData>($"{camInput.DrAddressId}/Jobs/CamLockInfo", content).Result;

            return await this.userApiClient.Search(camInputData);
        }

        /// <summary>
        /// Lock or unlock job based on islockjob value(true / false)
        /// </summary>
        /// <param name="isLockJob">Lock or unlock job</param>
        /// <param name="jobLockInput">Job lock input</param>
        /// <returns>Job lock status information</returns>
        public async Task<LockStatus> LockOrUnlockJob(bool isLockJob, LockInput jobLockInput)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(jobLockInput), Encoding.UTF8, "application/json");
            HttpResponseMessage localJobLockStatus = await this.httpClient.PostAsync(
                $"{jobLockInput.DrAddressId}/Jobs/{jobLockInput.JobId}?lockJob={isLockJob}",
                content);
            if (localJobLockStatus.StatusCode == System.Net.HttpStatusCode.OK && localJobLockStatus.IsSuccessStatusCode)
            {
                return new LockStatus { IsSuccessful = true };
            }
            else if (localJobLockStatus.StatusCode == System.Net.HttpStatusCode.Conflict)
            {
                LockInfo lockInfo = await localJobLockStatus.Content.ReadAsAsync<LockInfo>();
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.JobLocked, lockInfo.UserId } };
            }
            else
            {
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.BadRequest } };
            }
        }

        /// <summary>
        /// Get local job id(TS data base) based on the hqtr job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Local job id</returns>
        public async Task<int?> GetLocalJobId(CamInput camInput)
        {
            JobSearch jobSearch = new JobSearch { HqtrJobId = camInput.HostData.JobId };
            StringContent content = new StringContent(JsonConvert.SerializeObject(jobSearch), Encoding.UTF8, "application/json");
            IEnumerable<JobResponse> jobResponses = await this.httpClient.PostAsync<IEnumerable<JobResponse>>($"{camInput.DrAddressId}/Jobs/Search", content);
            if (jobResponses?.Any() == true)
            {
                return jobResponses.First().JobId;
            }

            return null;
        }

        /// <summary>
        /// Get host job id(ES data base) based on the job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Host job id</returns>
        public async Task<int?> GetHostJobId(CamInput camInput)
        {
            JobResponse jobResponse = await this.httpClient.GetAsync<JobResponse>($"{camInput.DrAddressId}/Jobs/{camInput.LocalData.JobId}/BasicInfo");
            if (jobResponse != null)
            {
                return jobResponse.HqtrJobId;
            }

            return null;
        }
    }
}
