// <copyright file="OrderApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Constants;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Order api client
    /// </summary>
    public class OrderApiClient : IOrderApiClient
    {
        private readonly IApiHttpClient httpClient;

        private readonly IUserApiClient userApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderApiClient"/> class
        /// </summary>
        /// <param name="orderServiceUrl">Order service url</param>
        /// <param name="httpClient">Http client</param>
        /// <param name="userApiClient">User api client</param>
        public OrderApiClient(
            string orderServiceUrl,
            IApiHttpClient httpClient,
            IUserApiClient userApiClient)
        {
            httpClient.SetBaseAddress(orderServiceUrl);
            this.httpClient = httpClient;
            this.userApiClient = userApiClient;
        }

        /// <summary>
        /// Get cam lock info by job/credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Cam lock data for the credit job and sales orders</returns>
        public async Task<CamData> GetCamLockInfo(CamInput camInput)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(camInput), Encoding.UTF8, "application/json");
            CamData camInputData = await this.httpClient.PostAsync<CamData>("Jobs/CamLockInfo", content);
            return await this.userApiClient.Search(camInputData);
        }

        /// <summary>
        /// Lock or unlock job based on islockjob value(true / false)
        /// </summary>
        /// <param name="isLockJob">Lock or unlock job</param>
        /// <param name="orderLockInput">Order lock input</param>
        /// <returns>Job lock status information</returns>
        public async Task<LockStatus> LockOrUnlockJob(bool isLockJob, LockInput orderLockInput)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(orderLockInput), Encoding.UTF8, "application/json");
            HttpResponseMessage hostJobLockStatus = await this.httpClient.PostAsync($"Jobs/{orderLockInput.JobId}/Lock?lockJob={isLockJob}", content);
            if (hostJobLockStatus.StatusCode == HttpStatusCode.OK && hostJobLockStatus.IsSuccessStatusCode)
            {
                return new LockStatus { IsSuccessful = true };
            }
            else if (hostJobLockStatus.StatusCode == HttpStatusCode.Conflict)
            {
                LockInfo lockInfo = await hostJobLockStatus.Content.ReadAsAsync<LockInfo>();
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.JobLocked, lockInfo.UserId } };
            }
            else
            {
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.BadRequest } };
            }
        }

        /// <summary>
        /// Lock host(ES data base) based on the lock input
        /// </summary>
        /// <param name="hostLockInput">Host lock input</param>
        /// <returns>Host lock status response</returns>
        public async Task<LockStatus> AllHostLock(HostLockInput hostLockInput)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(hostLockInput), Encoding.UTF8, "application/json");
            HostLockResponse hostLockResponse = await this.httpClient.PostAsync<HostLockResponse>("CreditJobs/AllHostLock", content);

            if (hostLockResponse.IsLockSuccess)
            {
                return new LockStatus { IsSuccessful = true };
            }
            else
            {
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.HostLockFailed } };
            }
        }

        /// <summary>
        /// Reset lock host(ES data base) based on the lock input
        /// </summary>
        /// <param name="resetHostLockInput">Reset host lock input</param>
        /// <returns>Reset host lock status response</returns>
        public async Task<LockStatus> ResetHostLock(HostLockInput resetHostLockInput)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(resetHostLockInput), Encoding.UTF8, "application/json");
            HostLockResponse hostRestLockResponse = await this.httpClient.PostAsync<HostLockResponse>("CreditJobs/ResetLock", content);

            if (hostRestLockResponse.IsLockSuccess)
            {
                return new LockStatus { IsSuccessful = true };
            }
            else
            {
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.HostResetLockFailed } };
            }
        }

        /// <summary>
        /// Transmit release sales order lock based on credit job id
        /// </summary>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        public async Task<LockStatus> TransmitReleaseSalesOrderLock(int creditJobId)
        {
            HttpResponseMessage response = await this.httpClient.PostAsync($"CreditJobs/{creditJobId}/SalesOrders/TransmitReleaseLock", null);
            return this.FormLockStatusResponse(response, HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Release sales order lock based on credit job id
        /// </summary>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        public async Task<LockStatus> ReleaseSalesOrderLock(int creditJobId)
        {
            HttpResponseMessage response = await this.httpClient.PostAsync($"CreditJobs/{creditJobId}/SalesOrders/ReleaseLock", null);
            return this.FormLockStatusResponse(response, HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Release credit job lock based on credit job id
        /// </summary>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        public async Task<LockStatus> ReleaseCreditJobLock(int creditJobId)
        {
            HttpResponseMessage response = await this.httpClient.PutAsync($"CreditJobs/{creditJobId}/ReleaseLock", null);
            return this.FormLockStatusResponse(response, HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Lock or unlock host(ES database) based on the applyLock value
        /// </summary>
        /// <param name="salesOrderIds">Sales order ids</param>
        /// <param name="lockApplication">Lock application</param>
        /// <param name="applyLock">Apply lock indicates whether the sales order id is to be locked/unlocked
        ///  with true value indicating lock and false indicating unlock</param>
        /// <returns>Lock status</returns>
        public async Task<LockStatus> ApplyHostSalesOrderLockOrUnlock(IEnumerable<int> salesOrderIds, string lockApplication, bool applyLock)
        {
            ApplyLockOrUnlock applyLockUnlock = new ApplyLockOrUnlock() { SalesOrderIds = salesOrderIds, LockApplication = lockApplication, ApplyLock = applyLock };
            StringContent content = new StringContent(JsonConvert.SerializeObject(applyLockUnlock), Encoding.UTF8, "application/json");
            HttpResponseMessage response = await this.httpClient.PutAsync($"SalesOrders/Lock/{lockApplication}?applyLock={applyLock}", content);
            return this.FormLockStatusResponse(response, HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Form lock status response
        /// </summary>
        /// <param name="httpResponseMessage">Http response message</param>
        /// <param name="successStatusCode">Success status code to be checked</param>
        /// <returns>Lock status</returns>
        private LockStatus FormLockStatusResponse(HttpResponseMessage httpResponseMessage, HttpStatusCode successStatusCode)
        {
            if (httpResponseMessage.StatusCode == successStatusCode && httpResponseMessage.IsSuccessStatusCode)
            {
                return new LockStatus { IsSuccessful = true };
            }
            else
            {
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.BadRequest } };
            }
        }
    }
}
