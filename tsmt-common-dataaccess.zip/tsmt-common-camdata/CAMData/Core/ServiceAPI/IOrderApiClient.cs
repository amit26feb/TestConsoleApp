// <copyright file="IOrderApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Order api client interface
    /// </summary>
    public interface IOrderApiClient
    {
        /// <summary>
        /// Get cam lock info by job/credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Cam lock data for the credit job and sales orders</returns>
        Task<CamData> GetCamLockInfo(CamInput camInput);

        /// <summary>
        /// Lock or unlock job based on islockjob value(true / false)
        /// </summary>
        /// <param name="isLockJob">Lock or unlock job</param>
        /// <param name="orderLockInput">Order lock input</param>
        /// <returns>Job lock status information</returns>
        Task<LockStatus> LockOrUnlockJob(bool isLockJob, LockInput orderLockInput);

        /// <summary>
        /// Lock host(ES data base) based on the lock input
        /// </summary>
        /// <param name="hostLockInput">Host lock input</param>
        /// <returns>Host lock status response</returns>
        Task<LockStatus> AllHostLock(HostLockInput hostLockInput);

        /// <summary>
        /// Reset lock host(ES data base) based on the lock input
        /// </summary>
        /// <param name="resetHostLockInput">Reset host lock input</param>
        /// <returns>Reset host lock status response</returns>
        Task<LockStatus> ResetHostLock(HostLockInput resetHostLockInput);

        /// <summary>
        /// Transmit release sales order lock based on credit job id
        /// </summary>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        Task<LockStatus> TransmitReleaseSalesOrderLock(int creditJobId);

        /// <summary>
        /// Release sales order lock based on credit job id
        /// </summary>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        Task<LockStatus> ReleaseSalesOrderLock(int creditJobId);

        /// <summary>
        /// Release credit job lock based on credit job id
        /// </summary>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        Task<LockStatus> ReleaseCreditJobLock(int creditJobId);

        /// <summary>
        /// Lock or unlock host(ES database) based on the applyLock value
        /// </summary>
        /// <param name="salesOrderIds">Sales order ids</param>
        /// <param name="lockApplication">Lock application</param>
        /// <param name="applyLock">Apply lock indicates whether the sales order id is to be locked/unlocked
        ///  with true value indicating lock and false indicating unlock</param>
        /// <returns>Lock status</returns>
        Task<LockStatus> ApplyHostSalesOrderLockOrUnlock(IEnumerable<int> salesOrderIds, string lockApplication, bool applyLock);
    }
}
