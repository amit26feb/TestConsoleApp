// <copyright file="OrderingApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Constants;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Ordering api client
    /// </summary>
    public class OrderingApiClient : IOrderingApiClient
    {
        private readonly IApiHttpClient httpClient;

        private readonly IUserApiClient userApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderingApiClient"/> class
        /// </summary>
        /// <param name="orderingServiceUrl">Ordering service url</param>
        /// <param name="httpClient">Http client</param>
        /// <param name="userApiClient">User api client</param>
        public OrderingApiClient(
            string orderingServiceUrl,
            IApiHttpClient httpClient,
            IUserApiClient userApiClient)
        {
            httpClient.SetBaseAddress(orderingServiceUrl);
            this.httpClient = httpClient;
            this.userApiClient = userApiClient;
        }

        /// <summary>
        /// Get cam lock info by job/credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Cam lock data for the credit job and sales orders</returns>
        public async Task<CamData> GetCamLockInfo(CamInput camInput)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(camInput), Encoding.UTF8, "application/json");
            CamData camInputData = await this.httpClient.PostAsync<CamData>($"{camInput.DrAddressId}/CreditJobs/CamLockInfo", content);
            return await this.userApiClient.Search(camInputData);
        }

        /// <summary>
        /// Get local credit job id(TS data base) based on the hqtr credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Local credit job id</returns>
        public async Task<int?> GetLocalCreditJobId(CamInput camInput)
        {
            IEnumerable<int> hqtrCreditJobIds = new List<int> { camInput.HostData.CreditJobId };
            StringContent content = new StringContent(JsonConvert.SerializeObject(hqtrCreditJobIds), Encoding.UTF8, "application/json");
            IEnumerable<CreditJobResponse> creditJobResponses =
                await this.httpClient.PostAsync<IEnumerable<CreditJobResponse>>($"{camInput.DrAddressId}/CreditJobs/PendingCreditJobs", content);
            if (creditJobResponses?.Any() == true)
            {
                return creditJobResponses.First().CreditJobId;
            }

            return null;
        }

        /// <summary>
        /// Get host credit job id(ES data base) based on the credit job id
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Host credit job id</returns>
        public async Task<int?> GetHostCreditJobId(CamInput camInput)
        {
            HttpResponseMessage response = await this.httpClient.GetAsync($"{camInput.DrAddressId}/CreditJobs/{camInput.LocalData.CreditJobId}/BasicInfo");
            if (response.StatusCode == System.Net.HttpStatusCode.OK && response.IsSuccessStatusCode)
            {
                CreditJobResponse creditJobResponse = await response.Content.ReadAsAsync<CreditJobResponse>();
                return creditJobResponse.HqtrCreditJobId;
            }

            return null;
        }

        /// <summary>
        /// Lock or unlock credit job based on isLockCreditJob value(true / false)
        /// </summary>
        /// <param name="isLockCreditJob">Lock or unlock credit job</param>
        /// <param name="creditJobLockInput">Credit job lock input</param>
        /// <returns>Credit job lock status information</returns>
        public async Task<LockStatus> LockOrUnlockCreditJob(bool isLockCreditJob, CreditJobLockInput creditJobLockInput)
        {
            StringContent stringContent = new StringContent(JsonConvert.SerializeObject(creditJobLockInput), Encoding.UTF8, "application/json");
            HttpResponseMessage localProjectLockStatus = await this.httpClient.PostAsync(
                $"{creditJobLockInput.DrAddressId}/CreditJobs/{creditJobLockInput.CreditJobId}/Lock?isCreditJobLock={isLockCreditJob}",
                stringContent);
            if (localProjectLockStatus.StatusCode == System.Net.HttpStatusCode.OK && localProjectLockStatus.IsSuccessStatusCode)
            {
                return new LockStatus { IsSuccessful = true };
            }
            else if (localProjectLockStatus.StatusCode == System.Net.HttpStatusCode.Conflict)
            {
                LockInfo lockInfo = await localProjectLockStatus.Content.ReadAsAsync<LockInfo>();
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.CreditJobLocked, lockInfo.UserId } };
            }
            else
            {
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.BadRequest } };
            }
        }

        /// <summary>
        /// Locks sales order by credit job id
        /// </summary>
        /// <param name="drAddressId">Dr address id</param>
        /// <param name="creditJobId">Credit job id</param>
        /// <returns>Lock status</returns>
        public async Task<LockStatus> SalesOrderLock(int drAddressId, int creditJobId)
        {
            HttpResponseMessage response = await this.httpClient.PutAsync($"{drAddressId}/CreditJobs/{creditJobId}/SalesOrders/Lock", null);

            // Lock endpoint from order service return BadRequest/NotFound/NoContent status codes
            // For the credit job it is not mandatory to have sales orders mapped
            // So getting an not found should not be considered as lock failure
            if (response.StatusCode == System.Net.HttpStatusCode.NoContent || response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return new LockStatus { IsSuccessful = true };
            }
            else
            {
                return new LockStatus { IsSuccessful = false, Messages = new List<string>() { Constants.BadRequest } };
            }
        }
    }
}
