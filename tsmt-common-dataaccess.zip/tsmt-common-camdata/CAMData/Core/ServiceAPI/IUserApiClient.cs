// <copyright file="IUserApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Job api client interface
    /// </summary>
    public interface IUserApiClient
    {
        /// <summary>
        /// Gets users based on filter criteria
        /// </summary>
        /// <param name="filterData">Input Filter Data</param>
        /// <returns>Returns user details</returns>
        Task<IEnumerable<ActiveDirectoryModel>> ActiveDirectorySearch(IEnumerable<FilterModel> filterData);

        /// <summary>
        /// Looks for user in AD and returns the details
        /// </summary>
        /// <param name="camData">Cam Input data</param>
        /// <returns>Cam data with user details</returns>
        Task<CamData> Search(CamData camData);
    }
}
