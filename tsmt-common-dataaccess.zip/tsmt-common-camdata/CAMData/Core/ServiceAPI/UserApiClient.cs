// <copyright file="UserApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Reflection;
    using System.Text;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Job api client
    /// </summary>
    public class UserApiClient : IUserApiClient
    {
        private readonly IApiHttpClient httpClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserApiClient"/> class
        /// </summary>
        /// <param name="userServiceUrl">User service url</param>
        /// <param name="httpClient">Http client</param>
        public UserApiClient(string userServiceUrl, IApiHttpClient httpClient)
        {
            httpClient.SetBaseAddress(userServiceUrl);
            this.httpClient = httpClient;
        }

        /// <summary>
        /// Gets users based on filter criteria
        /// </summary>
        /// <param name="filterData">Input Filter Data</param>
        /// <returns>Returns user details</returns>
        public async Task<IEnumerable<ActiveDirectoryModel>> ActiveDirectorySearch(IEnumerable<FilterModel> filterData)
        {
            if (filterData != null && filterData.Any() && filterData.All(x => !string.IsNullOrWhiteSpace(x.Field)) && filterData.All(x => !string.IsNullOrWhiteSpace(x.Value)))
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(filterData), Encoding.UTF8, "application/json");
                return await this.httpClient.PostAsync<IEnumerable<ActiveDirectoryModel>>("Users/ActiveDirectory/Search", content);
            }

            return new List<ActiveDirectoryModel>();
        }

        /// <summary>
        /// Looks for user in AD and returns the details
        /// </summary>
        /// <param name="camData">Cam Input data</param>
        /// <returns>Cam data with user details</returns>
        public async Task<CamData> Search(CamData camData)
        {
            if (camData == null)
            {
                return null;
            }

            List<string> lockUserIds = new List<string>();

            // gets all data from current object which are of LockData class type
            IEnumerable<PropertyInfo> lockDataProperties = camData.GetType().GetProperties().Where(x => x.PropertyType.Name.Equals(Constants.Constants.LockDataProperty));

            // gets list of user ids in object
            this.ReadProperties(camData, lockDataProperties, ref lockUserIds);

            // searches active directory for list of active directory users
            IEnumerable<FilterModel> activeDirectorySearchInput = lockUserIds.Select(id => new FilterModel() { Field = Constants.Constants.MailNickNameProperty, Value = id });
            IEnumerable<ActiveDirectoryModel> activeDirectoryData = await this.ActiveDirectorySearch(activeDirectorySearchInput);

            // writes display name property of active directory to LockUserName property
            if (activeDirectoryData != null && activeDirectoryData.Any())
            {
                this.WriteProperties(camData, lockDataProperties, activeDirectoryData);
            }

            return camData;
        }

        /// <summary>
        /// Writes Active directory data to object
        /// </summary>
        /// <param name="camData">input object</param>
        /// <param name="props">Property of LockData object</param>
        /// <param name="activeDirectoryData">User's Active Directory data</param>
        private void WriteProperties(CamData camData, IEnumerable<PropertyInfo> props, IEnumerable<ActiveDirectoryModel> activeDirectoryData)
        {
            foreach (PropertyInfo prop in props)
            {
                LockData lockDataValue = (LockData)prop.GetValue(camData, null);

                if (lockDataValue != null)
                {
                    this.WritePropertiesRecursive(lockDataValue, activeDirectoryData);
                }
            }
        }

        /// <summary>
        /// Reads object recursively and writes display name
        /// </summary>
        /// <param name="dynamicObject">current object in interation</param>
        /// <param name="activeDirectoryData">User's Active Directory data</param>
        private void WritePropertiesRecursive(dynamic dynamicObject, IEnumerable<ActiveDirectoryModel> activeDirectoryData)
        {
            foreach (PropertyInfo property in dynamicObject.GetType().GetProperties())
            {
                if (property.Name == Constants.Constants.LockUserIdProperty)
                {
                    this.WriteLockUserName(dynamicObject, activeDirectoryData, property);
                }

                if (property.PropertyType.GetInterfaces().Contains(typeof(IEnumerable)) && property.PropertyType != typeof(string))
                {
                    object enumerableData = property.GetValue(dynamicObject);
                    if (enumerableData != null)
                    {
                        foreach (object data in (IEnumerable)enumerableData)
                        {
                            // recursively calls this method for each element in the list
                            this.WritePropertiesRecursive(data, activeDirectoryData);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Reads display name of user and assigns to LockUserName
        /// </summary>
        /// <param name="dynamicObject">Current object in interation</param>
        /// <param name="activeDirectoryData">User's AD data</param>
        /// <param name="property">Property Info of current object</param>
        private void WriteLockUserName(dynamic dynamicObject, IEnumerable<ActiveDirectoryModel> activeDirectoryData, PropertyInfo property)
        {
            object lockUserIdObj = property.GetValue(dynamicObject);

            if (lockUserIdObj != null)
            {
                string fullDisplayName = activeDirectoryData.FirstOrDefault(x => x.OnPremisesSamAccountName.Equals(lockUserIdObj.ToString(), StringComparison.CurrentCultureIgnoreCase))?.DisplayName;

                if (!string.IsNullOrEmpty(fullDisplayName))
                {
                    dynamicObject.GetType().GetProperty(Constants.Constants.LockUserNameProperty).SetValue(dynamicObject, fullDisplayName);
                }
            }
        }

        /// <summary>
        /// Reads all properties of Lockdata class object
        /// </summary>
        /// <param name="camData">input object</param>
        /// <param name="lockDataProperties">Property of LockData Object</param>
        /// <param name="lockUserIds">List of userIds in input object</param>
        private void ReadProperties(CamData camData, IEnumerable<PropertyInfo> lockDataProperties, ref List<string> lockUserIds)
        {
            foreach (PropertyInfo propertiesInfo in lockDataProperties)
            {
                LockData lockDataValue = (LockData)propertiesInfo.GetValue(camData, null);

                if (lockDataValue != null)
                {
                    this.ReadPropertiesRecursive(lockDataValue, ref lockUserIds);
                }
            }
        }

        /// <summary>
        /// Recursively iterates thru all properties of object
        /// </summary>
        /// <param name="dynamicObject">current object in interation</param>
        /// <param name="lockUserIds">List of userIds in input object</param>
        private void ReadPropertiesRecursive(dynamic dynamicObject, ref List<string> lockUserIds)
        {
            foreach (PropertyInfo propertyInfo in dynamicObject.GetType().GetProperties())
            {
                this.ReadLockUserId(dynamicObject, lockUserIds, propertyInfo);

                if (propertyInfo.PropertyType.GetInterfaces().Contains(typeof(IEnumerable)) && propertyInfo.PropertyType != typeof(string))
                {
                    object enumerableData = propertyInfo.GetValue(dynamicObject);
                    if (enumerableData != null)
                    {
                        foreach (var data in (IEnumerable)enumerableData)
                        {
                            this.ReadPropertiesRecursive(data, ref lockUserIds);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Checks for lockUserId property value and returns the same
        /// </summary>
        /// <param name="dynamicObject">current object in interation</param>
        /// <param name="lockUserIds">List of userIds in input object</param>
        /// <param name="propertyInfo">Property Info of current object</param>
        private void ReadLockUserId(dynamic dynamicObject, List<string> lockUserIds, PropertyInfo propertyInfo)
        {
            if (propertyInfo.Name == Constants.Constants.LockUserIdProperty && propertyInfo.GetValue(dynamicObject) != null)
            {
                lockUserIds.Add(propertyInfo.GetValue(dynamicObject).ToString());
            }
        }
    }
}
