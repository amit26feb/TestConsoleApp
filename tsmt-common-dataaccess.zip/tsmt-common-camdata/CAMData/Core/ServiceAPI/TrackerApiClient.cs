// <copyright file="TrackerApiClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.ServiceAPI
{
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Threading.Tasks;
    using TSMT.ApiClient;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Tracker api client
    /// </summary>
    public class TrackerApiClient : ITrackerApiClient
    {
        private readonly IApiHttpClient httpClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="TrackerApiClient"/> class
        /// </summary>
        /// <param name="trackerServiceUrl">Tracker service url</param>
        /// <param name="httpClient">Http client</param>
        public TrackerApiClient(
            string trackerServiceUrl,
            IApiHttpClient httpClient)
        {
            httpClient.SetBaseAddress(trackerServiceUrl);
            this.httpClient = httpClient;
        }

        /// <summary>
        /// Get open tracker tags
        /// </summary>
        /// <param name="entityId">Entity id</param>
        /// <param name="entityName">Entity name</param>
        /// <returns>Tag entity tracker</returns>
        public async Task<IEnumerable<TagEntityTracker>> GetOpenTrackerTags(string entityId, string entityName)
        {
            HttpResponseMessage response = await this.httpClient.GetAsync($"Tracker/OpenTrackerTags?entityName={entityName}&entityId={entityId}");
            if (response.StatusCode == System.Net.HttpStatusCode.OK && response.IsSuccessStatusCode)
            {
                IEnumerable<TagEntityTracker> tagEntityTrackers = await response.Content.ReadAsAsync<IEnumerable<TagEntityTracker>>();
                return tagEntityTrackers;
            }

            return null;
        }
    }
}
