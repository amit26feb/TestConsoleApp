// <copyright file="CamInput.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Model for contextual access manager input
    /// </summary>
    public class CamInput
    {
        /// <summary>
        /// Gets or sets context
        /// </summary>
        public string Context { get; set; }

        /// <summary>
        /// Gets or sets dr address id
        /// </summary>
        public int DrAddressId { get; set; }

        /// <summary>
        /// Gets or sets user id
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets host data
        /// </summary>
        public CamInputMetaData HostData { get; set; }

        /// <summary>
        /// Gets or sets local data
        /// </summary>
        public CamInputMetaData LocalData { get; set; }
    }
}
