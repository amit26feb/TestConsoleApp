// <copyright file="FilterModel.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Filter view model
    /// </summary>
    public class FilterModel
    {
        /// <summary>
        /// Gets or sets field
        /// </summary>
        public string Field { get; set; }

        /// <summary>
        /// Gets or sets operator to apply
        /// </summary>
        public string Operator { get; set; }

        /// <summary>
        /// Gets or sets value for filter
        /// </summary>
        public string Value { get; set; }
    }
}
