// <copyright file="AccessContext.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using MongoDB.Bson;
    using MongoDB.Bson.Serialization.Attributes;

    /// <summary>
    /// Model to load access contexts
    /// </summary>
    public class AccessContext
    {
        /// <summary>
        /// Gets or sets id.
        /// </summary>
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets context
        /// </summary>
        public string Context { get; set; }

        /// <summary>
        /// Gets or sets access feasibility checker component
        /// </summary>
        public string AccessFeasibilityCheckerComponent { get; set; }

        /// <summary>
        /// Gets or sets action component
        /// </summary>
        public string ActionComponent { get; set; }

        /// <summary>
        /// Gets or sets toaster message
        /// </summary>
        public string ToasterMessage { get; set; }

        /// <summary>
        /// Gets or sets notification header message
        /// </summary>
        public string NotificationHeaderMessage { get; set; }
    }
}
