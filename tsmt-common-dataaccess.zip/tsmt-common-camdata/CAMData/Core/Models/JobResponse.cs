// <copyright file="JobResponse.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Job response
    /// </summary>
    public class JobResponse
    {
        /// <summary>
        /// Gets or sets job id
        /// </summary>
        public int JobId { get; set; }

        /// <summary>
        /// Gets or sets hqtr job id
        /// </summary>
        public int? HqtrJobId { get; set; }
    }
}
