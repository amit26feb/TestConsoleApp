// <copyright file="LockStatus.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Status of the lock
    /// </summary>
    public class LockStatus
    {
        /// <summary>
        /// Gets or sets a value indicating whether the lock is successful
        /// </summary>
        public bool IsSuccessful { get; set; }

        /// <summary>
        /// Gets or sets messages related to the lock process check
        /// </summary>
        public IEnumerable<string> Messages { get; set; }
    }
}
