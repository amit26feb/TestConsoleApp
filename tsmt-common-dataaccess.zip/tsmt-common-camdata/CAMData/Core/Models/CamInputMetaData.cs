// <copyright file="CamInputMetaData.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Cam input meta data
    /// </summary>
    public class CamInputMetaData
    {
        /// <summary>
        /// Gets or sets job id
        /// </summary>
        public int JobId { get; set; }

        /// <summary>
        /// Gets or sets credit job id
        /// </summary>
        public int CreditJobId { get; set; }

        /// <summary>
        /// Gets or sets BidAlternate Id
        /// </summary>
        public int? BidAlternateId { get; set; }

        /// <summary>
        /// Gets or sets sales order ids
        /// </summary>
        public IEnumerable<int> SalesOrderIds { get; set; }
    }
}
