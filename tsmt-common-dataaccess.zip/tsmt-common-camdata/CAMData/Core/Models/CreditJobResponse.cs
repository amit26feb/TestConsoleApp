// <copyright file="CreditJobResponse.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Credit job response
    /// </summary>
    public class CreditJobResponse
    {
        /// <summary>
        /// Gets or sets job id
        /// </summary>
        public int CreditJobId { get; set; }

        /// <summary>
        /// Gets or sets hqtr credit job id
        /// </summary>
        public int? HqtrCreditJobId { get; set; }
    }
}
