// <copyright file="CreditProjectLock.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Model for credit project lock information
    /// </summary>
    public class CreditProjectLock
    {
        /// <summary>
        /// Gets or sets credit job id
        /// </summary>
        public int CreditJobId { get; set; }

        /// <summary>
        /// Gets or sets hqtr credit job id
        /// </summary>
        public int? HqtrCreditJobId { get; set; }

        /// <summary>
        /// Gets or sets lock user id
        /// </summary>
        public string LockUserId { get; set; }

        /// <summary>
        /// Gets or sets lock user name
        /// </summary>
        public string LockUserName { get; set; }

        /// <summary>
        /// Gets or sets legacy credit job number
        /// </summary>
        public string LegacyCreditJobNumber { get; set; }

        /// <summary>
        /// Gets or sets change allowed indicator (Possible change allowed indicator values are 'Y', 'R', 'N')
        /// </summary>
        public char ChangeAllowedIndicator { get; set; }

        /// <summary>
        /// Gets or sets change order status
        /// </summary>
        public string ChangeOrderStatus { get; set; }

        /// <summary>
        /// Gets or sets change order decision status
        /// </summary>
        public int ChangeOrderDecisionStatus { get; set; }

        /// <summary>
        /// Gets or sets locked application
        /// </summary>
        public string LockedApplication { get; set; }

        /// <summary>
        /// Gets or sets credit project name
        /// </summary>
        public string CreditProjectName { get; set; }

        /// <summary>
        /// Gets or sets bid id
        /// </summary>
        public int BidId { get; set; }

        /// <summary>
        /// Gets or sets sales order locks
        /// </summary>
        public IEnumerable<SalesOrderLock> SalesOrderLocks { get; set; }
    }
}
