// <copyright file="ContextCondition.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using MongoDB.Bson;
    using MongoDB.Bson.Serialization.Attributes;

    /// <summary>
    /// Model to load conditions
    /// </summary>
    public class ContextCondition
    {
        /// <summary>
        /// Gets or sets id.
        /// </summary>
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets context
        /// </summary>
        public string Context { get; set; }

        /// <summary>
        /// Gets or sets condition checker component
        /// </summary>
        public string ConditionCheckerComponent { get; set; }

        /// <summary>
        /// Gets or sets priority of the condition
        /// </summary>
        public int Priority { get; set; }

        /// <summary>
        /// Gets or sets source for checking the condition
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets notification message
        /// </summary>
        public string NotificationMessage { get; set; }
    }
}
