// <copyright file="LockData.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Model for lock data
    /// </summary>
    public class LockData
    {
        /// <summary>
        /// Gets or sets job id
        /// </summary>
        public int JobId { get; set; }

        /// <summary>
        /// Gets or sets job name
        /// </summary>
        public string JobName { get; set; }

        /// <summary>
        /// Gets or sets hqtr job id
        /// </summary>
        public int? HqtrJobId { get; set; }

        /// <summary>
        /// Gets or sets lock user id
        /// </summary>
        public string LockUserId { get; set; }

        /// <summary>
        /// Gets or sets lock user name
        /// </summary>
        public string LockUserName { get; set; }

        /// <summary>
        /// Gets or sets credit project locks
        /// </summary>
        public IEnumerable<CreditProjectLock> CreditProjectLocks { get; set; }
    }
}
