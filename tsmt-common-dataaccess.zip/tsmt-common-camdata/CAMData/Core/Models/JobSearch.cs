// <copyright file="JobSearch.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Job serach model
    /// </summary>
    public class JobSearch
    {
        /// <summary>
        /// Gets or sets hqtr job id
        /// </summary>
        public int HqtrJobId { get; set; }
    }
}
