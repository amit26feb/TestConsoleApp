// <copyright file="CamData.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Model for contextual access manager data
    /// </summary>
    public class CamData
    {
        /// <summary>
        /// Gets or sets dr address id
        /// </summary>
        public int DrAddressId { get; set; }

        /// <summary>
        /// Gets or sets user id
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets local job lock
        /// </summary>
        public LockData LocalLock { get; set; }

        /// <summary>
        /// Gets or sets host job lock
        /// </summary>
        public LockData HostLock { get; set; }
    }
}
