// <copyright file="TagEntityTracker.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using System;

    /// <summary>
    /// Tag entity tracker class
    /// </summary>
    public class TagEntityTracker
    {
        /// <summary>
        /// Gets or sets entity id
        /// </summary>
        public string EntityId { get; set; }

        /// <summary>
        /// Gets or sets entity name
        /// </summary>
        public string EntityName { get; set; }

        /// <summary>
        /// Gets or sets tag
        /// </summary>
        public string Tag { get; set; }

        /// <summary>
        /// Gets or sets status
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets correlation id
        /// </summary>
        public string CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets parent id
        /// </summary>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets step id
        /// </summary>
        public string StepId { get; set; }

        /// <summary>
        /// Gets or sets created on
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets closed on
        /// </summary>
        public DateTime? ClosedOn { get; set; }

        /// <summary>
        /// Gets or sets additional info
        /// </summary>
        public string AdditionalInfo { get; set; }
    }
}
