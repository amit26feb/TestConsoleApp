// <copyright file="HostLockInput.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Host lock input(ES data base)
    /// </summary>
    public class HostLockInput
    {
        /// <summary>
        /// Gets or sets credit job id
        /// </summary>
        public int CreditJobId { get; set; }

        /// <summary>
        /// Gets or sets user id
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets application
        /// </summary>
        public string Application { get; set; }

        /// <summary>
        /// Gets or sets sales order
        /// </summary>
        public string SalesOrder { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether process change order
        /// </summary>
        public bool CanProcessChangeOrder { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether process sales order
        /// </summary>
        public bool CanProcessSalesOrder { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether process db commit
        /// </summary>
        public bool CanProcessDbCommit { get; set; }
    }
}
