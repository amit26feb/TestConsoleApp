// <copyright file="SalesOrderLock.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Model for sales order lock information
    /// </summary>
    public class SalesOrderLock
    {
        /// <summary>
        /// Gets or sets sales order id
        /// </summary>
        public int SalesOrderId { get; set; }

        /// <summary>
        /// Gets or sets hqtr sales order id
        /// </summary>
        public int? HqtrSalesOrderId { get; set; }

        /// <summary>
        /// Gets or sets lock user id
        /// </summary>
        public string LockUserId { get; set; }

        /// <summary>
        /// Gets or sets lock user name
        /// </summary>
        public string LockUserName { get; set; }

        /// <summary>
        /// Gets or sets change order status
        /// </summary>
        public string ChangeOrderStatus { get; set; }

        /// <summary>
        /// Gets or sets legacy order number
        /// </summary>
        public string LegacyOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets locked application
        /// </summary>
        public string LockedApplication { get; set; }

        /// <summary>
        /// Gets or sets ECS transaction type
        /// </summary>
        public string EcsTransactionType { get; set; }

        /// <summary>
        /// Gets or sets sales order description
        /// </summary>
        public string SalesOrderDescription { get; set; }
    }
}
