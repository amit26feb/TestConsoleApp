// <copyright file="ApplyLockOrUnlock.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Apply lock or unlock
    /// </summary>
    public class ApplyLockOrUnlock
    {
        /// <summary>
        /// Gets or sets sales order ids
        /// </summary>
        public IEnumerable<int> SalesOrderIds { get; set; }

        /// <summary>
        /// Gets or sets lock application
        /// </summary>
        public string LockApplication { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether sales order ids are locked or unlocked
        /// </summary>
        public bool ApplyLock { get; set; }
    }
}
