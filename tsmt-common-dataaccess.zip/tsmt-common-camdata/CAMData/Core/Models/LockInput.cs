// <copyright file="LockInput.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Model for job lock
    /// </summary>
    public class LockInput
    {
        /// <summary>
        /// Gets or sets job id
        /// </summary>
        public int JobId { get; set; }

        /// <summary>
        /// Gets or sets dr address id
        /// </summary>
        public int DrAddressId { get; set; }

        /// <summary>
        /// Gets or sets user identifier
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the lock state can be forced outside of normal rules
        /// </summary>
        public bool AllowLockOverride { get; set; }
    }
}
