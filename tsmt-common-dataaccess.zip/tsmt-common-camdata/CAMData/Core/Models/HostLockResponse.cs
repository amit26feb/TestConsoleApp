// <copyright file="HostLockResponse.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    using System;

    /// <summary>
    /// Host lock response(ES data base)
    /// </summary>
    public class HostLockResponse
    {
        /// <summary>
        /// Gets or sets user id
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets application
        /// </summary>
        public string Application { get; set; }

        /// <summary>
        /// Gets or sets lock time
        /// </summary>
        public DateTime? LockTime { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether locking is success or not
        /// </summary>
        public bool IsLockSuccess { get; set; }
    }
}
