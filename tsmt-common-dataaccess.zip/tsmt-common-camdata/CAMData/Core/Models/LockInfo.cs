// <copyright file="LockInfo.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// Model for job lock info.
    /// </summary>
   public class LockInfo
    {
        /// <summary>
        /// Gets or sets user id
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets first name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets last name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether ok / conflict response
        /// </summary>
        public bool IsOkStatusCode { get; set; }
    }
}
