// <copyright file="ActiveDirectoryModel.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Models
{
    /// <summary>
    /// User model
    /// </summary>
    public class ActiveDirectoryModel
    {
        /// <summary>
        /// Gets or sets business phone numbers
        /// </summary>
        public string[] BusinessPhones { get; set; }

        /// <summary>
        /// Gets or sets display name
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets given name or first name
        /// </summary>
        public string GivenName { get; set; }

        /// <summary>
        /// Gets or sets job title
        /// </summary>
        public string JobTitle { get; set; }

        /// <summary>
        /// Gets or sets mail
        /// </summary>
        public string Mail { get; set; }

        /// <summary>
        /// Gets or sets mobile phone number
        /// </summary>
        public string MobilePhone { get; set; }

        /// <summary>
        /// Gets or sets office location
        /// </summary>
        public string OfficeLocation { get; set; }

        /// <summary>
        /// Gets or sets surname
        /// </summary>
        public string Surname { get; set; }

        /// <summary>
        /// Gets or sets user principal name -- which is the user's unique identifer in Active Directory.
        /// By convention, our organization typically uses the user's email address, for this attribute.
        /// </summary>
        public string UserPrincipalName { get; set; }

        /// <summary>
        /// Gets or sets the on premises SAM account name -- which is the user identifier that we often refer to as a domain login (like "IRABC").
        /// </summary>
        public string OnPremisesSamAccountName { get; set; }

        /// <summary>
        /// Gets or sets preferred language
        /// </summary>
        public string PreferredLanguage { get; set; }

        /// <summary>
        /// Gets or sets account enabled
        /// </summary>
        public string AccountEnabled { get; set; }
    }
}
