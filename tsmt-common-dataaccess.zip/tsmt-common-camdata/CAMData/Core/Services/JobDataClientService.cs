// <copyright file="JobDataClientService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;

    /// <summary>
    /// Class to define the implementation of api methods of job service
    /// </summary>
    public class JobDataClientService : IDataClientService
    {
        private readonly IJobApiClient jobApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobDataClientService"/> class.
        /// </summary>
        /// <param name="jobApiClient">Job api</param>
        public JobDataClientService(IJobApiClient jobApiClient)
        {
            this.jobApiClient = jobApiClient;
            this.ServiceContext = ServiceClient.Job;
        }

        /// <summary>
        /// Gets service context
        /// </summary>
        public ServiceClient ServiceContext { get; }

        /// <summary>
        /// Get the lock info from the api clients
        /// </summary>
        /// <param name="camInput">Contextual access manager input</param>
        /// <returns>Contextual access manager data</returns>
        public async Task<CamData> GetCamInfo(CamInput camInput)
        {
            if (camInput.LocalData.JobId > 0)
            {
                return await this.jobApiClient.GetCamLockInfo(camInput);
            }

            return null;
        }

        /// <summary>
        /// Get enriched cam input
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Enriched cam input</returns>
        public async Task<CamInput> GetEnrichedCamInput(CamInput camInput)
        {
            // Make sure before enrich cam input
            // We dont have null object for host data and local data
            camInput.LocalData = camInput.LocalData == null ? new CamInputMetaData() : camInput.LocalData;
            camInput.HostData = camInput.HostData == null ? new CamInputMetaData() : camInput.HostData;

            // Checks only host job id available and local job id is 0
            if (camInput.HostData.JobId > 0 && camInput.LocalData.JobId == 0)
            {
                camInput.LocalData.JobId = await this.jobApiClient.GetLocalJobId(camInput) ?? 0;
            }

            // Checks only local job id available and host job id is 0
            if (camInput.LocalData.JobId > 0 && camInput.HostData.JobId == 0)
            {
                camInput.HostData.JobId = await this.jobApiClient.GetHostJobId(camInput) ?? 0;
            }

            return camInput;
        }
    }
}
