// <copyright file="IDataClientFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Services
{
    using TSMT.CAM.Data.Constants.Enumerators;

    /// <summary>
    /// Defines the methods that are used in DataClientFactory
    /// </summary>
    public interface IDataClientFactory
    {
        /// <summary>
        /// Creates the instance of the data client service based on the context
        /// </summary>
        /// <param name="serviceContext">Specifies the service client</param>
        /// <returns>Service client instance based on the context</returns>
        IDataClientService GetServiceClientInstance(ServiceClient serviceContext);
    }
}
