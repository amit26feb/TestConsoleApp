// <copyright file="OrderDataClientService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;

    /// <summary>
    /// Class to define the implementation of api methods of order service
    /// </summary>
    public class OrderDataClientService : IDataClientService
    {
        private readonly IOrderApiClient orderApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderDataClientService"/> class.
        /// </summary>
        /// <param name="orderApiClient">Order api</param>
        public OrderDataClientService(IOrderApiClient orderApiClient)
        {
            this.orderApiClient = orderApiClient;
            this.ServiceContext = ServiceClient.Order;
        }

        /// <summary>
        /// Gets service context
        /// </summary>
        public ServiceClient ServiceContext { get; }

        /// <summary>
        /// Get the lock info from the api clients
        /// </summary>
        /// <param name="camInput">Contextual access manager input</param>
        /// <returns>Contextual access manager data</returns>
        public async Task<CamData> GetCamInfo(CamInput camInput)
        {
            if (camInput.HostData.JobId > 0)
            {
                return await this.orderApiClient.GetCamLockInfo(camInput);
            }

            return null;
        }

        /// <summary>
        /// Get enriched cam input
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Enriched cam input</returns>
        public async Task<CamInput> GetEnrichedCamInput(CamInput camInput)
        {
            // Current scenarion we dont need to enrich any data based on the OrderDataClient
            // We will extend this method once requried
            return await Task.FromResult(camInput);
        }
    }
}
