// <copyright file="DataClientFactory.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using TSMT.CAM.Data.Constants.Enumerators;

    /// <summary>
    /// Class to implement service calls
    /// </summary>
    public class DataClientFactory : IDataClientFactory
    {
        private readonly IEnumerable<IDataClientService> dataClientServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataClientFactory"/> class.
        /// </summary>
        /// <param name="dataClientServices">List of data client services</param>
        public DataClientFactory(IEnumerable<IDataClientService> dataClientServices)
        {
            this.dataClientServices = dataClientServices;
        }

        /// <summary>
        /// Creates the instance of the data client service based on the context
        /// </summary>
        /// <param name="serviceContext">Specifies the service client</param>
        /// <returns>Service client instance based on the context</returns>
        public IDataClientService GetServiceClientInstance(ServiceClient serviceContext)
        {
            return this.dataClientServices.FirstOrDefault(x => x.ServiceContext == serviceContext);
        }
    }
}
