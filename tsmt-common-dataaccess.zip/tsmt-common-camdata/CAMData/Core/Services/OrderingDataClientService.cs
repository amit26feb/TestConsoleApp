// <copyright file="OrderingDataClientService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>
namespace TSMT.CAM.Data.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;
    using TSMT.CAM.Data.Core.ServiceAPI;

    /// <summary>
    /// Class to define the implementation of api methods of ordering service
    /// </summary>
    public class OrderingDataClientService : IDataClientService
    {
        private readonly IOrderingApiClient orderingApiClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderingDataClientService"/> class.
        /// </summary>
        /// <param name="orderingApiClient">Ordering api</param>
        public OrderingDataClientService(IOrderingApiClient orderingApiClient)
        {
            this.orderingApiClient = orderingApiClient;
            this.ServiceContext = ServiceClient.Ordering;
        }

        /// <summary>
        /// Gets service context
        /// </summary>
        public ServiceClient ServiceContext { get; }

        /// <summary>
        /// Get the lock info from the api clients
        /// </summary>
        /// <param name="camInput">Contextual access manager input</param>
        /// <returns>Contextual access manager data</returns>
        public async Task<CamData> GetCamInfo(CamInput camInput)
        {
            if (camInput.LocalData.CreditJobId > 0)
            {
                return await this.orderingApiClient.GetCamLockInfo(camInput);
            }

            return null;
        }

        /// <summary>
        /// Get enriched cam input
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Enriched cam input</returns>
        public async Task<CamInput> GetEnrichedCamInput(CamInput camInput)
        {
            // Make sure before enrich cam input
            // We dont have null object for host data and local data
            camInput.LocalData = camInput.LocalData == null ? new CamInputMetaData() : camInput.LocalData;
            camInput.HostData = camInput.HostData == null ? new CamInputMetaData() : camInput.HostData;

            // Checks only host credit job id available and local credit job id is 0
            if (camInput.HostData.CreditJobId > 0 && camInput.LocalData.CreditJobId == 0)
            {
                camInput.LocalData.CreditJobId = await this.orderingApiClient.GetLocalCreditJobId(camInput) ?? 0;
            }

            // Checks only local credit job id available and host credit job id is 0
            if (camInput.LocalData.CreditJobId > 0 && camInput.HostData.CreditJobId == 0)
            {
                camInput.HostData.CreditJobId = await this.orderingApiClient.GetHostCreditJobId(camInput) ?? 0;
            }

            return camInput;
        }
    }
}
