// <copyright file="IDataClientService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Constants.Enumerators;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Interface for contextual access manager data service for api clients
    /// </summary>
    public interface IDataClientService
    {
        /// <summary>
        /// Gets service context
        /// </summary>
        ServiceClient ServiceContext { get; }

        /// <summary>
        /// Get the lock info from the api clients
        /// </summary>
        /// <param name="camInput">Contextual access manager input</param>
        /// <returns>Contextual access manager data</returns>
        Task<CamData> GetCamInfo(CamInput camInput);

        /// <summary>
        /// Get enriched cam input
        /// </summary>
        /// <param name="camInput">Cam input</param>
        /// <returns>Enriched cam input</returns>
        Task<CamInput> GetEnrichedCamInput(CamInput camInput);
    }
}
