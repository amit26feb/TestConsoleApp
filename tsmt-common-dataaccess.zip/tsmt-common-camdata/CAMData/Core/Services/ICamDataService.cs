// <copyright file="ICamDataService.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Core.Services
{
    using System.Threading.Tasks;
    using TSMT.CAM.Data.Core.Models;

    /// <summary>
    /// Interface for contextual access manager data service
    /// </summary>
    public interface ICamDataService
    {
        /// <summary>
        /// Get the lock info from the ts and es sources
        /// </summary>
        /// <param name="camInput">Contextual access manager input</param>
        /// <returns>Contextual access manager data</returns>
        Task<CamData> GetCamInfo(CamInput camInput);
    }
}
