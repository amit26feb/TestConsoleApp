// <copyright file="ServiceClient.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Constants.Enumerators
{
    /// <summary>
    /// Service clients
    /// </summary>
    public enum ServiceClient
    {
        /// <summary>
        /// Job service
        /// </summary>
        Job,

        /// <summary>
        /// Ordering service
        /// </summary>
        Ordering,

        /// <summary>
        /// Order service
        /// </summary>
        Order
    }
}
