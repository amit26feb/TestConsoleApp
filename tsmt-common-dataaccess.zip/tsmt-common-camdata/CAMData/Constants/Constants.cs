// <copyright file="Constants.cs" company="Trane Technologies">
// Copyright (c) Trane Technologies. All rights reserved.
// </copyright>

namespace TSMT.CAM.Data.Constants
{
    /// <summary>
    /// Constants
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Lock not implemented message
        /// </summary>
        public const string LockNotImplemented = "Lock is not implemented";

        /// <summary>
        /// Service client not implemented message
        /// </summary>
        public const string ServiceClientNotImplemented = "Service client is not implemented";

        /// <summary>
        /// Job is locked message
        /// </summary>
        public const string JobLocked = "Job is locked by other user";

        /// <summary>
        /// Credit job is locked message
        /// </summary>
        public const string CreditJobLocked = "Job is locked by other user";

        /// <summary>
        /// Host reset lock failed
        /// </summary>
        public const string HostResetLockFailed = "Host reset lock failed for the credit job";

        /// <summary>
        /// Host lock failed
        /// </summary>
        public const string HostLockFailed = "Host lock failed for the credit job";

        /// <summary>
        /// Bad request
        /// </summary>
        public const string BadRequest = "Bad Request";

        /// <summary>
        /// LockData property name
        /// </summary>
        public const string LockDataProperty = "LockData";

        /// <summary>
        /// ActiveDirectory property MailNickName
        /// </summary>
        public const string MailNickNameProperty = "mailNickname";

        /// <summary>
        /// LockUserId property name
        /// </summary>
        public const string LockUserIdProperty = "LockUserId";

        /// <summary>
        /// LockUserName property name
        /// </summary>
        public const string LockUserNameProperty = "LockUserName";
    }
}
