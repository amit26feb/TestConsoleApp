﻿// <copyright file="SalesRollupServiceDomainException.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Common.Exceptions
{
   using System;
   using System.Runtime.Serialization;

   /// <summary>
   /// Exception type for app exceptions
   /// </summary>
   [Serializable]
   public class SalesRollupServiceDomainException : Exception
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="SalesRollupServiceDomainException"/> class.
      /// </summary>
      public SalesRollupServiceDomainException()
      {
      }

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesRollupServiceDomainException"/> class.
      /// </summary>
      /// <param name="message">message</param>
      public SalesRollupServiceDomainException(string message)
          : base(message)
      {
      }

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesRollupServiceDomainException"/> class.
      /// </summary>
      /// <param name="message">Message detatails</param>
      /// <param name="innerException">inner exception</param>
      public SalesRollupServiceDomainException(string message, Exception innerException)
          : base(message, innerException)
      {
      }

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesRollupServiceDomainException"/> class.
      /// </summary>
      /// <param name="info">The serialization info</param>
      /// <param name="context">The streaming context</param>
      protected SalesRollupServiceDomainException(SerializationInfo info, StreamingContext context)
          : base(info, context)
      {
      }
   }
}