﻿// <copyright file="Constants.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Common
{
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// Constants used within this microservice
   /// </summary>
   public static class Constants
   {
      /// <summary>
      /// An enum to help some code determine if were operating in the context of
      /// Sales, Pricing (COJO), etc...
      /// </summary>
      public const RollupConsumer PrimaryRollupConsumer = RollupConsumer.SalesOffice;
   }
}
