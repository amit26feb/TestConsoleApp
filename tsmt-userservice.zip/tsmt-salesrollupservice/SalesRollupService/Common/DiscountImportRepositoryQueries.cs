﻿// <copyright file="DiscountImportRepositoryQueries.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Common
{
   /// <summary>
   /// Queries used by Discount Import repository
   /// </summary>
   public static class DiscountImportRepositoryQueries
   {
      /// <summary>
      /// Get list of Bid Alternate records using Job Id
      /// </summary>
      public const string BidAlternatesByJobId =
         @"SELECT
               ba.bid_alternate_id,
               ba.current_bid_ind,
               ba.base_bid_yes_no
            FROM
               bid_alternate ba
            WHERE
               ba.job_id = :JOB_ID
         ";

      /// <summary>
      /// Update statement to apply discounts to a selected pricing parm
      /// </summary>
      public const string ApplySelectedPricingParmDiscount =
         @"UPDATE
               selected_pricing_parm
            SET
               auth_mult = :AUTH_MULT,
               auth_cost_point_lpaf = :AUTH_COST_POINT_LPAF
            WHERE
               selected_pricing_parm_id = :SELECTED_PRICING_PARM_ID
         ";

      /// <summary>
      /// Get list of Selected Pricing Parameters using Bid Alt Id
      /// </summary>
      public const string SelectedPriceParamsUsingBidId =
         @"SELECT DISTINCT
               spp.selected_pricing_parm_id,
               spp.selection_id,
               spp.prod_pricing_grp_id,
               spp.auth_mult,
               spp.auth_cost_point_lpaf,
               s.sales_ord_id
         FROM 
               bid_alternate_xref bax
               JOIN selection s
                  ON bax.selection_id = s.selection_id
               JOIN selected_pricing_parm spp
                  ON s.selection_id = spp.selection_id
         WHERE 
               bax.bid_alternate_id = :bid_alternate_id
         ";
   }
}
