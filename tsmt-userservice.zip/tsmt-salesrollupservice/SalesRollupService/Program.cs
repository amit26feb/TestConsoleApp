﻿// <copyright file="Program.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService
{
   using System.IO;
   using Microsoft.AspNetCore;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.Logging;
   using NLog.Web;
   using SalesRollupService.Configurations;

   /// <summary>
   /// Program
   /// </summary>
   public static class Program
   {
      /// <summary>
      /// Main
      /// </summary>
      /// <param name="args">args</param>
      public static void Main(string[] args)
      {
         BuildWebHost(args).Build().Run();
      }

      /// <summary>
      /// BuildWebHost
      /// </summary>
      /// <param name="args">args</param>
      /// <returns>WebHost</returns>
      public static IWebHostBuilder BuildWebHost(string[] args) =>
          WebHost.CreateDefaultBuilder(args)
              .UseStartup<Startup>()
              .UseContentRoot(Directory.GetCurrentDirectory())
              .ConfigureAppConfiguration((builderContext, config) =>
              {
                 IWebHostEnvironment env = builderContext.HostingEnvironment;
                 config.AddJsonFile("appsettings.json", optional: false)
                   .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);
                 IConfigurationRoot configBuilder = config.Build();
                 config.Add(new TSMT.Settings.TsmtConfigurationSource<ConfigParameterConstants>(env.EnvironmentName, configBuilder["AWSRegion"].ToString()));
                 config.AddEnvironmentVariables();
              })
              .ConfigureLogging((hostingContext, builder) =>
              {
                 builder.AddConfiguration(hostingContext.Configuration.GetSection("Logging"));
                 builder.AddDebug();
              })
          .UseNLog();
   }
}
