﻿// <copyright file="HostingEnvironmentExtensions.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Configurations
{
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.Extensions.Hosting;

   /// <summary>
   /// Hosting environment extensions
   /// </summary>
   public static class HostingEnvironmentExtensions
   {
      /// <summary>
      /// DEV Environment
      /// </summary>
      public const string DEVEnvironment = "Development";

      /// <summary>
      /// UAT Environment
      /// </summary>
      public const string UATEnvironment = "UAT";

      /// <summary>
      /// STAGE Environment
      /// </summary>
      public const string STAGEEnvironment = "Staging";

      /// <summary>
      /// PROD Environment
      /// </summary>
      public const string PRODEnvironment = "Production";

      /// <summary>
      /// Check Is DEV
      /// </summary>
      /// <param name="hostingEnvironment">Hosting environment</param>
      /// <returns>Hosting environment details</returns>
      public static bool IsDevelopment(this IWebHostEnvironment hostingEnvironment)
      {
         return hostingEnvironment.IsEnvironment(DEVEnvironment);
      }

      /// <summary>
      /// Check Is UAT
      /// </summary>
      /// <param name="hostingEnvironment">Hosting environment</param>
      /// <returns>Hosting environment details</returns>
      public static bool IsUAT(this IWebHostEnvironment hostingEnvironment)
      {
         return hostingEnvironment.IsEnvironment(UATEnvironment);
      }

      /// <summary>
      /// Check Is STAGE
      /// </summary>
      /// <param name="hostingEnvironment">Hosting environment</param>
      /// <returns>Hosting environment details</returns>
      public static bool IsStaging(this IWebHostEnvironment hostingEnvironment)
      {
         return hostingEnvironment.IsEnvironment(STAGEEnvironment);
      }

      /// <summary>
      /// Check Is PROD
      /// </summary>
      /// <param name="hostingEnvironment">Hosting environment</param>
      /// <returns>Hosting environment details</returns>
      public static bool IsProduction(this IWebHostEnvironment hostingEnvironment)
      {
         return hostingEnvironment.IsEnvironment(PRODEnvironment);
      }
   }
}
