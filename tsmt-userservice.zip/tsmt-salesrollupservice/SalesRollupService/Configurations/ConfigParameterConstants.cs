﻿// <copyright file="ConfigParameterConstants.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Configurations
{
   /// <summary>
   /// ConfigParameterConstants. The Property names on this constant file need to be same as the TSMTSetttings file property names.
   /// </summary>
   public class ConfigParameterConstants
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="ConfigParameterConstants"/> class.
      /// </summary>
      protected ConfigParameterConstants()
      {
      }

      /// <summary>
      /// Gets TSMT Connection String Parameter name
      /// </summary>
      public static string VPNDBConnectionString => "tsmt-tstrn-SalesRollupService-v2";

      /// <summary>
      /// Gets RedisEndpoint Parameter name
      /// </summary>
      public static string RedisEndpoint => "tsmt-redisendpoint-SalesRollupService-v2";

      /// <summary>
      /// Gets DocumentDB connection string parameter name
      /// </summary>
      public static string DocumentDBConnectionString => "tsmt-docdb-SalesRollup";

      /// <summary>
      /// Gets InfluxDb Parameter name
      /// </summary>
      public static string InfluxDb => "tsmt-influxdb-db";

      /// <summary>
      /// Gets InfluxDb Url Parameter name
      /// </summary>
      public static string InfluxDbUrl => "tsmt-influxdb-url";

      /// <summary>
      /// Gets InfluxDb UserName Parameter name
      /// </summary>
      public static string InfluxDbUserName => "tsmt-influxdb-user";

      /// <summary>
      /// Gets InfluxDb Password Parameter name
      /// </summary>
      public static string InfluxDbPassword => "tsmt-influxdb-password";
   }
}