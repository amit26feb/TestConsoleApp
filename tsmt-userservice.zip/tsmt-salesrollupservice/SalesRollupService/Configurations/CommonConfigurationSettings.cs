﻿// <copyright file="CommonConfigurationSettings.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Configurations
{
   /// <summary>
   /// Common Configuration Settings
   /// </summary>
   public class CommonConfigurationSettings
   {
      /// <summary>
      /// Gets or sets sqs service url
      /// </summary>
      public string SqsServiceURLForRollupHistoryService { get; set; }

      /// <summary>
      /// Gets or sets queue wait time for rollup history
      /// </summary>
      public int QueueWaitTimeForRollupHistory { get; set; }

      /// <summary>
      /// Gets or sets message hiding time for rollup history
      /// </summary>
      public int MessageHidingTimeInMinutesForRollupHistory { get; set; }

      /// <summary>
      /// Gets or sets maximum number of messages for rollup history
      /// </summary>
      public int MaxNoOfMessagesForRollupHistory { get; set; }

      /// <summary>
      /// Gets or sets SQS Queue URL for SPP discount updates
      /// </summary>
      public string SqsServiceUrlForDiscountTransfer { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether it is stage or production environment
      /// </summary>
      public bool IsStageOrProdEnvironment { get; set; }
   }
}
