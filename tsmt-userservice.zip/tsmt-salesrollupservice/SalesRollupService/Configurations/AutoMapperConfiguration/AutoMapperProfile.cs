﻿// <copyright file="AutoMapperProfile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Configurations.AutoMapperConfiguration
{
   using AutoMapper;
   using DataAccesWriteModels = TSMT.RollupDataAccess.Models.WriteRollupDataModels;
   using EngineWriteModels = PriceRollupCalculationEngine.Models.WriteRollupDataModels;

   /// <summary>
   /// class for autoMapper profile
   /// </summary>
   public class AutoMapperProfile : Profile
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="AutoMapperProfile"/> class.
      /// </summary>
      public AutoMapperProfile()
      {
         this.MapForViewing();
      }

      /// <summary>
      /// Maps the domain models to the view models that are used for viewing in UI
      /// </summary>
      private void MapForViewing()
      {
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.PriceRollupBaseDataViewModel, PriceRollupCalculationEngine.ViewModels.PriceRollupBaseDataViewModel>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.CalculatedPriceViewModel, PriceRollupCalculationEngine.ViewModels.CalculatedPriceViewModel>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.ProductFamilyViewModel, PriceRollupCalculationEngine.Models.ProductFamily>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.PricedSelectedItemViewModel, PriceRollupCalculationEngine.ViewModels.PricedSelectedItemViewModel>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.ProductCodeSummaryViewModel, PriceRollupCalculationEngine.ViewModels.ProductCodeSummaryViewModel>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.SelectionIdentifierViewModel, PriceRollupCalculationEngine.ViewModels.SelectionIdentifierViewModel>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.VariationIdentifierViewModel, PriceRollupCalculationEngine.Models.VariationIdentifier>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.ProdPricingGroupViewModel, PriceRollupCalculationEngine.Models.ProductPricingGroup>();
         this.CreateMap<TSMT.RollupDataAccess.ViewModels.JobViewModel, PriceRollupCalculationEngine.ViewModels.JobViewModel>();

         this.CreateMap<TSMT.RollupDataAccess.Models.RollupView, Core.ViewModels.RollupViewViewModel>().ReverseMap();
         this.CreateMap<TSMT.RollupDataAccess.Models.RollupColumn, Core.ViewModels.RollupColumnViewModel>().ReverseMap();

         this.CreateMap<PriceRollupCalculationEngine.Models.WriteRollupDataStatement, TSMT.RollupDataAccess.Models.WriteRollupDataStatement>();
         this.CreateMap<PriceRollupCalculationEngine.Models.WriteRollupDataStatementType, TSMT.RollupDataAccess.Models.WriteRollupDataStatementType>();

         this.CreateMap<Core.Models.JobScoring.SalesOfficeScoringData, PriceRollupCalculationEngine.ViewModels.JobScoring.SalesOfficeScoringDataViewModel>();
         this.CreateMap<Core.Models.JobScoring.ProductCodeQuintile, PriceRollupCalculationEngine.ViewModels.JobScoring.ProductCodeQuintilesViewModel>();
         this.CreateMap<Core.Models.JobScoring.Quintile, PriceRollupCalculationEngine.ViewModels.JobScoring.QuintileViewModel>();

         // Map all types of IWriteRollupDataModel, at least those that are appropiate from a SalesRollup perspective
         this.CreateMap<PriceRollupCalculationEngine.Models.IWriteRollupDataModel, TSMT.RollupDataAccess.Models.IWriteRollupDataModel>()
            .IncludeAllDerived();
         this.CreateMap<EngineWriteModels.BidProdAmountDelete, DataAccesWriteModels.BidProdAmountDelete>();
         this.CreateMap<EngineWriteModels.BidProdAmountInsert, DataAccesWriteModels.BidProdAmountInsert>();
         this.CreateMap<EngineWriteModels.BidSellingPriceUpdate, DataAccesWriteModels.BidSellingPriceUpdate>();
         this.CreateMap<EngineWriteModels.JobEstimatedRevenueProcedure, DataAccesWriteModels.JobEstimatedRevenueProcedure>();
         this.CreateMap<EngineWriteModels.JobRefreshOrdersRequiredDateIfUnsetUpdate, DataAccesWriteModels.JobRefreshOrdersRequiredDateIfUnsetUpdate>();
         this.CreateMap<EngineWriteModels.SelectionBomReviseDateRefreshUpdate, DataAccesWriteModels.SelectionBomReviseDateRefreshUpdate>();
         this.CreateMap<EngineWriteModels.SppEnteredCostPointLpafUpdate, DataAccesWriteModels.SppEnteredCostPointLpafUpdate>();
         this.CreateMap<EngineWriteModels.SppEnteredMultiplierUpdate, DataAccesWriteModels.SppEnteredMultiplierUpdate>();
         this.CreateMap<EngineWriteModels.VariationMarkupUpdate, DataAccesWriteModels.VariationMarkupUpdate>();
      }
   }
}