﻿// <copyright file="ProductCodeQuintile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Models.JobScoring
{
   using System.Collections.Generic;

   /// <summary>
   /// Class for product code quintile properties
   /// </summary>
   public class ProductCodeQuintile
   {
      /// <summary>
      /// Gets or sets product code that these quintiles apply to
      /// </summary>
      public string ProductCode { get; set; }

      /// <summary>
      /// Gets or sets quintiles or buckets for price grading
      /// </summary>
      public IEnumerable<Quintile> Quintiles { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether this product code is exempt from certain scoring caclulations
      /// </summary>
      public bool IsExempt { get; set; }
   }
}
