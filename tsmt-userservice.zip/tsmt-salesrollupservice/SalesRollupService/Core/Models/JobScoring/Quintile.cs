﻿// <copyright file="Quintile.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Models.JobScoring
{
   /// <summary>
   /// Class for quintile properties.  A quintile is any of five equal groups into which data can be divided
   /// according to the distribution of values of a particular variable - ie - a price bucket.
   /// </summary>
   public class Quintile
   {
      /// <summary>
      /// Gets or sets job size min inclusive endpoint in USD
      /// </summary>
      public decimal JobSizeMin { get; set; }

      /// <summary>
      /// Gets or sets job size max exclusive endpoint in USD
      /// </summary>
      public decimal JobSizeMax { get; set; }

      /// <summary>
      /// Gets or sets start b
      /// </summary>
      public decimal StartB { get; set; }

      /// <summary>
      /// Gets or sets start c
      /// </summary>
      public decimal StartC { get; set; }

      /// <summary>
      /// Gets or sets start d
      /// </summary>
      public decimal StartD { get; set; }

      /// <summary>
      /// Gets or sets start e
      /// </summary>
      public decimal StartE { get; set; }
   }
}
