﻿// <copyright file="SalesOfficeScoringData.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Models.JobScoring
{
   using System.Collections.Generic;

   /// <summary>
   /// Class for sales office scoring data properties
   /// </summary>
   public class SalesOfficeScoringData
   {
      /// <summary>
      /// Gets or sets an enumeration of product code quintiles
      /// </summary>
      public IEnumerable<ProductCodeQuintile> ProductCodeQuintiles { get; set; }

      /// <summary>
      /// Gets or sets the job size factor
      /// </summary>
      public decimal JobSizeFactor { get; set; }

      /// <summary>
      /// Gets or sets the currency exchange rate
      /// </summary>
      public decimal CurrencyExchangeRate { get; set; }
   }
}
