﻿// <copyright file="SelectedPricingParm.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Models
{
   /// <summary>
   /// selected pricing parm model
   /// </summary>
   public class SelectedPricingParm
   {
      /// <summary>
      /// Gets or sets selected pricing parm id
      /// </summary>
      public int SELECTED_PRICING_PARM_ID { get; set; }

      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SELECTION_ID { get; set; }

      /// <summary>
      /// Gets or sets prod pricing group id
      /// </summary>
      public int PROD_PRICING_GRP_ID { get; set; }

      /// <summary>
      /// Gets or sets authorized multiplier
      /// </summary>
      public decimal? AUTH_MULT { get; set; }

      /// <summary>
      /// Gets or sets authorized cost point list price adjustment factor
      /// </summary>
      public decimal? AUTH_COST_POINT_LPAF { get; set; }

      /// <summary>
      /// Gets or sets sales order id
      /// </summary>
      public int? SALES_ORD_ID { get; set; }

      /// <summary>
      /// Gets a value indicating whether the selection has bene ordered
      /// </summary>
      public bool IsOrdered
      {
         get
         {
            return this.SALES_ORD_ID.HasValue;
         }
      }
   }
}
