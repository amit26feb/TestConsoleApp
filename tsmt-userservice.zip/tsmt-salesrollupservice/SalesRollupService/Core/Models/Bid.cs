﻿// <copyright file="Bid.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Models
{
   /// <summary>
   /// bid alternate model
   /// </summary>
   public class Bid
   {
      /// <summary>
      /// Gets or sets bid alternate id
      /// </summary>
      public int BidAlternateId { get; set; }

      /// <summary>
      /// Gets or sets current bid identifier
      /// </summary>
      public string CurrentBidInd { get; set; }

      /// <summary>
      /// Gets or sets base bid yes no flag
      /// </summary>
      public int BaseBidYesNo { get; set; }

      /// <summary>
      /// Gets a value indicating whether this object is the current bid
      /// </summary>
      public bool IsCurrentBid
      {
         get
         {
            return this.CurrentBidInd == "Y";
         }
      }

      /// <summary>
      /// Gets a value indicating whether this object is the base bid
      /// </summary>
      public bool IsBaseBid
      {
         get
         {
            return this.BaseBidYesNo == 1;
         }
      }
   }
}
