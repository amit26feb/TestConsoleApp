﻿// <copyright file="DiscountSelectionViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ViewModels
{
   /// <summary>
   /// Contains the discount information for a selection-pricing group
   /// </summary>
   public class DiscountSelectionViewModel
   {
      /// <summary>
      /// Gets or sets selection id
      /// </summary>
      public int SelectionId { get; set; }

      /// <summary>
      /// Gets or sets product pricing group id
      /// </summary>
      public int ProdPricingGroupId { get; set; }

      /// <summary>
      /// Gets or sets authorized multiplier
      /// </summary>
      public decimal? AuthMult { get; set; }

      /// <summary>
      /// Gets or sets authorized cost point lpaf
      /// </summary>
      public decimal? AuthCplpaf { get; set; }

      /// <summary>
      /// Gets or sets a value indicating whether discount has been checked/applied</summary>
      public bool IsApplied { get; set; }
   }
}
