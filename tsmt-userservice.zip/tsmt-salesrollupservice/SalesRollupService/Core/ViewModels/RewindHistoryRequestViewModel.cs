﻿// <copyright file="RewindHistoryRequestViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ViewModels
{
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// A model of a request to rewind a rollup's history
   /// </summary>
   public class RewindHistoryRequestViewModel
   {
      /// <summary>
      /// Gets or sets the job for the rollup
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets the bid for the rollup
      /// </summary>
      public int BidId { get; set; }

      /// <summary>
      /// Gets or sets the edit to rewind to
      /// </summary>
      public PriceRollupEdit Edit { get; set; }

      /// <summary>
      /// Gets or sets the rollup type to build in response.
      /// If omitted, the type of rollup is pulled from the edit.
      /// </summary>
      public RollupType? RollupType { get; set; }

      /// <summary>
      /// Determines if the model is valid
      /// </summary>
      /// <param name="reason">The reason for false</param>
      /// <returns>The validity</returns>
      public bool Validate(out string reason)
      {
         reason = null;

         if (this.JobId <= 0)
         {
            reason = "The job ID is invalid";
            return false;
         }

         if (this.BidId <= 0)
         {
            reason = "The bid ID is invalid";
            return false;
         }

         if (this.Edit == null)
         {
            reason = "The edit is missing";
            return false;
         }

         return true;
      }
   }
}
