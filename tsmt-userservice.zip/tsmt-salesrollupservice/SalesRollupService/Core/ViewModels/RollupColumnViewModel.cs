﻿// <copyright file="RollupColumnViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ViewModels
{
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// A view model for a rollup column
   /// </summary>
   public class RollupColumnViewModel
   {
      /// <summary>
      /// Gets or sets the Id
      /// </summary>
      public RollupColumnType Id { get; set; }

      /// <summary>
      /// Gets or sets the name
      /// </summary>
      public string Name { get; set; }

      /// <summary>
      /// Gets or sets the index
      /// </summary>
      public int Index { get; set; }
   }
}
