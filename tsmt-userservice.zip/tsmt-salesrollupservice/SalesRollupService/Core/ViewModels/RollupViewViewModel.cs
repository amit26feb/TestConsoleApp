﻿// <copyright file="RollupViewViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// A view model for a rollup view
   /// </summary>
   public class RollupViewViewModel
   {
      /// <summary>
      /// Gets or sets the owner
      /// </summary>
      public string Owner { get; set; }

      /// <summary>
      /// Gets or sets the name
      /// </summary>
      public string Name { get; set; }

      /// <summary>
      /// Gets or sets the owner
      /// </summary>
      public IEnumerable<RollupColumnViewModel> Columns { get; set; }
   }
}
