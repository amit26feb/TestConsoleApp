﻿// <copyright file="RewindHistoryResultViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ViewModels
{
   using System.Collections.Generic;
   using System.Linq;
   using PriceRollupCalculationEngine.ViewModels;

   /// <summary>
   /// The result of using the history service to rewind history
   /// </summary>
   public class RewindHistoryResultViewModel
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="RewindHistoryResultViewModel"/> class.
      /// </summary>
      /// <param name="rollup">The rewound rollup</param>
      public RewindHistoryResultViewModel(RollupViewModel rollup)
      {
         this.Rollup = rollup;
      }

      /// <summary>
      /// Initializes a new instance of the <see cref="RewindHistoryResultViewModel"/> class.
      /// </summary>
      /// <param name="errors">Errors that occurred</param>
      public RewindHistoryResultViewModel(params string[] errors)
      {
         this.Errors = errors;
      }

      /// <summary>
      /// Gets or sets the rewound rollup
      /// </summary>
      public RollupViewModel Rollup { get; set; }

      /// <summary>
      /// Gets or sets the errors that occurred during rewinding
      /// </summary>
      public IEnumerable<string> Errors { get; set; }

      /// <summary>
      /// Gets a value indicating whether rewinding was successful
      /// </summary>
      public bool IsSuccessful => this.Errors?.Any() != true;
   }
}
