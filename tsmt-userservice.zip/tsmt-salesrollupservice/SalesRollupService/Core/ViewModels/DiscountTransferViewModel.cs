﻿// <copyright file="DiscountTransferViewModel.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ViewModels
{
   using System.Collections.Generic;

   /// <summary>
   /// Contains the discount information for a job
   /// </summary>
   public class DiscountTransferViewModel
   {
      /// <summary>
      /// Gets or sets dr address id
      /// </summary>
      public int DrAddressId { get; set; }

      /// <summary>
      /// Gets or sets job id
      /// </summary>
      public int JobId { get; set; }

      /// <summary>
      /// Gets or sets user id
      /// </summary>
      public string UserId { get; set; }

      /// <summary>
      /// Gets or sets selections
      /// </summary>
      public IEnumerable<DiscountSelectionViewModel> Selections { get; set; }
   }
}
