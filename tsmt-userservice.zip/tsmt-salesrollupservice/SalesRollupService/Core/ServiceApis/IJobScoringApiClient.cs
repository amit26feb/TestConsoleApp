﻿// <copyright file="IJobScoringApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ServiceApis
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using SalesRollupService.Core.Models.JobScoring;

   /// <summary>
   /// API Client for job scoring service
   /// </summary>
   public interface IJobScoringApiClient
   {
      /// <summary>
      /// Gets sales office scoring data
      /// </summary>
      /// <param name="salesOfficeId">sales office id</param>
      /// <param name="prodCodes">prod codes</param>
      /// <param name="custChannelId">cust channel id</param>
      /// <returns>Sales office scoring data object</returns>
      Task<SalesOfficeScoringData> GetSalesOfficeScoringData(int salesOfficeId, IEnumerable<string> prodCodes, string custChannelId);
   }
}