﻿// <copyright file="JobScoringApiClient.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.ServiceApis
{
   using System.Collections.Generic;
   using System.Net.Http;
   using System.Text;
   using System.Threading.Tasks;
   using Newtonsoft.Json;
   using SalesRollupService.Core.Models.JobScoring;
   using TSMT.ApiClient;

   /// <inheritdoc/>
   public class JobScoringApiClient : IJobScoringApiClient
   {
      private readonly IApiHttpClient apiHttpClient;

      /// <summary>
      /// Initializes a new instance of the <see cref="JobScoringApiClient"/> class.
      /// </summary>
      /// <param name="baseUrl">The base url for the api client</param>
      /// <param name="apiHttpClient">Api client for making http calls</param>
      public JobScoringApiClient(string baseUrl, IApiHttpClient apiHttpClient)
      {
         this.apiHttpClient = apiHttpClient;
         this.apiHttpClient.SetBaseAddress(baseUrl);
      }

      /// <inheritdoc/>
      public async Task<SalesOfficeScoringData> GetSalesOfficeScoringData(int salesOfficeId, IEnumerable<string> prodCodes, string custChannelId)
      {
         return await this.apiHttpClient.PostAsync<SalesOfficeScoringData>($"SalesOfficeScoringData/{salesOfficeId}", new StringContent(JsonConvert.SerializeObject(new { prodCodes, custChannelId }), Encoding.UTF8, "application/json"));
      }
   }
}
