﻿// <copyright file="RollupGridService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using Microsoft.AspNetCore.Http;
   using PriceRollupCalculationEngine.CalculationEngine;
   using PriceRollupCalculationEngine.Models;
   using PriceRollupCalculationEngine.ViewModels;
   using PriceRollupCalculationEngine.ViewModels.JobScoring;
   using SalesRollupService.Core.Models.JobScoring;
   using SalesRollupService.Core.ServiceApis;
   using TSMT.RollupDataAccess.Services;
   using TSMT.RollupDomain.Models;
   using api = Models.JobScoring;

   /// <summary>
   /// Exposes routines to build rollup grids and respond to grid edits.
   /// </summary>
   public class RollupGridService : IRollupGridService
   {
      private readonly IMapper mapper;
      private readonly IRollupBuilder rollupBuilder;
      private readonly IReadRollupDataService readRollupDataService;
      private readonly IWriteRollupDataService writeRollupDataService;
      private readonly IRollupCriticalWriteProducer rollupCriticalWriteProducer;
      private readonly IRollupAncillaryWriteProducer rollupAncillaryWriteProducer;
      private readonly IJobScoringApiClient jobScoringApiClient;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupGridService"/> class.
      /// </summary>
      /// <param name="mapper">The object mapper</param>
      /// <param name="rollupBuilder">The rollup builder engine</param>
      /// <param name="readRollupDataService">The rollup read-only data access</param>
      /// <param name="writeRollupDataService">The rollup writeable data access</param>
      /// <param name="rollupCriticalWriteProducer">The rollup critical write producer</param>
      /// <param name="rollupAncillaryWriteProducer">The rollup ancillary write producer</param>
      /// <param name="httpContextAccessor">The HTTP context accessor</param>
      /// <param name="jobScoringApiClient">Job scoring api client</param>
      public RollupGridService(
         IMapper mapper,
         IRollupBuilder rollupBuilder,
         IReadRollupDataService readRollupDataService,
         IWriteRollupDataService writeRollupDataService,
         IRollupCriticalWriteProducer rollupCriticalWriteProducer,
         IRollupAncillaryWriteProducer rollupAncillaryWriteProducer,
         IHttpContextAccessor httpContextAccessor,
         IJobScoringApiClient jobScoringApiClient)
      {
         this.mapper = mapper;
         this.rollupBuilder = rollupBuilder;
         this.readRollupDataService = readRollupDataService;
         this.writeRollupDataService = writeRollupDataService;
         this.rollupCriticalWriteProducer = rollupCriticalWriteProducer;
         this.rollupAncillaryWriteProducer = rollupAncillaryWriteProducer;
         this.jobScoringApiClient = jobScoringApiClient;

         // Pull the DrAddressId out of the HTTP context
         // The data services/repositories need to be told to honor it
         if (httpContextAccessor.HttpContext != null
            && httpContextAccessor.HttpContext.Items != null
            && httpContextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID")
            && int.TryParse(httpContextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.readRollupDataService.HonorDrAddressId(drAddressIdToHonor);
            this.writeRollupDataService.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.readRollupDataService.HonorDrAddressId(null);
            this.writeRollupDataService.HonorDrAddressId(null);
         }
      }

      /// <inheritdoc/>
      public async Task<PriceRollupBaseDataViewModel> GetRollupBaseData(int jobId, int bidId)
      {
         TSMT.RollupDataAccess.ViewModels.PriceRollupBaseDataViewModel baseData = await this.readRollupDataService.GetPriceRollupData(jobId, bidId, RollupConsumer.SalesOffice);
         PriceRollupBaseDataViewModel mappedBaseData = this.mapper.Map<PriceRollupBaseDataViewModel>(baseData);

         return mappedBaseData;
      }

      /// <inheritdoc/>
      public async Task<RollupViewModel> GetRollupGrid(int jobId, int bidId, RollupType rollupType, bool calculatePricingPolicy)
      {
         PriceRollupBaseDataViewModel baseData = await this.GetRollupBaseData(jobId, bidId);
         return await this.GetRollupGrid(baseData, rollupType, calculatePricingPolicy);
      }

      /// <inheritdoc/>
      public async Task<RollupViewModel> GetRollupGrid(PriceRollupBaseDataViewModel baseData, RollupType rollupType, bool calculatePricingPolicy)
      {
         if (calculatePricingPolicy)
         {
            // The rollup base data fetched earlier via RollupDataAccess will not contain populated PricingPolicy attributes, so we attempt to gather these attributes here
            // in the last mile, before rolling up into grid data.
            SalesOfficeScoringDataViewModel scoringData = await this.GetScoringData(baseData);
            PricingPolicyCalculator pricingPolicyCalculator = new PricingPolicyCalculator(baseData, scoringData, this.rollupBuilder);
            pricingPolicyCalculator.Calculate();
         }

         return this.rollupBuilder.GetProductRollup(rollupType, baseData);
      }

      /// <inheritdoc/>
      public async Task<bool> ApplyRollupGridEdit(int jobId, int bidId, PriceRollupBaseDataViewModel baseData, PriceRollupEdit priceRollupEdit, List<string> responseErrors)
      {
         List<WriteRollupDataStatement> writeStatements = new List<WriteRollupDataStatement>();

         // Determine the "critical" statements that need to be executed to carry out the edit.
         WriteProducerResponse criticalResponse = this.rollupCriticalWriteProducer.ProduceStatements(jobId, bidId, baseData, priceRollupEdit);
         if (criticalResponse.IsSuccessful)
         {
            if (criticalResponse.Statements != null)
            {
               writeStatements.AddRange(criticalResponse.Statements);
            }
         }
         else
         {
            // We are unable to apply the edit.
            if (criticalResponse.Errors != null)
            {
               responseErrors.AddRange(criticalResponse.Errors);
            }

            return false;
         }

         return await this.FinishDatabaseEdits(jobId, bidId, baseData, writeStatements, responseErrors);
      }

      /// <inheritdoc/>
      public async Task<bool> CopyMultipliers(int jobId, int bidId, PriceRollupBaseDataViewModel baseData, CopyMultiplierSource copyMultiplierSource, List<CopiedMultiplier> copiedMultipliers, List<string> responseErrors)
      {
         List<WriteRollupDataStatement> writeStatements = new List<WriteRollupDataStatement>();

         // The rollup base data fetched earlier via RollupDataAccess will not contain populated PricingPolicy attributes, so we need to gather these attributes
         // before we try to copy from them.
         if (copyMultiplierSource == CopyMultiplierSource.PricingPolicy)
         {
            SalesOfficeScoringDataViewModel scoringData = await this.GetScoringData(baseData);
            PricingPolicyCalculator pricingPolicyCalculator = new PricingPolicyCalculator(baseData, scoringData, this.rollupBuilder);
            pricingPolicyCalculator.Calculate();
         }

         // Determine the "critical" statements that need to be executed to carry out the copies.
         // At the same time, gather the list of copied multipliers.
         CopyMultipliersResponse response = this.rollupCriticalWriteProducer.ProduceStatementsForCopyMultipliers(jobId, bidId, RollupConsumer.SalesOffice, baseData, copyMultiplierSource, CopyMultiplierDestination.Entered); // Destination is always Entered, for this audience.
         if (response.IsSuccessful)
         {
            if (response.Statements != null)
            {
               writeStatements.AddRange(response.Statements);
            }

            // Caller wants to know about the list of copied multipliers.
            if (response.CopiedMultipliers != null)
            {
               copiedMultipliers.AddRange(response.CopiedMultipliers);
            }
         }
         else
         {
            // We are unable to copy multipliers.
            if (response.Errors != null)
            {
               responseErrors.AddRange(response.Errors);
            }

            return false;
         }

         return await this.FinishDatabaseEdits(jobId, bidId, baseData, writeStatements, responseErrors);
      }

      /// <summary>
      /// Carries the desired database writes across the finish line, actually writing to the database.
      /// </summary>
      /// <param name="jobId">Job ID</param>
      /// <param name="bidId">Bid ID</param>
      /// <param name="baseData">Existing rollup base data (including SPP-level data)</param>
      /// <param name="writeStatements">List of database write statements, to be applied to the database</param>
      /// <param name="responseErrors">List of errors, which explain why the edits could not be applied</param>
      /// <returns>true when successful, false when the database edits could not be applied</returns>
      public async Task<bool> FinishDatabaseEdits(int jobId, int bidId, PriceRollupBaseDataViewModel baseData, List<WriteRollupDataStatement> writeStatements, List<string> responseErrors)
      {
         // Determine the additional "ancillary" statements that are not of utmost importance, but should get executed at some point.
         // In the future, we may actually queue these up as job/bid requests, and let a background worker plow through them, rather than do it here.
         WriteProducerResponse ancillaryResponse = this.rollupAncillaryWriteProducer.ProduceStatements(jobId, bidId, baseData, Common.Constants.PrimaryRollupConsumer);
         if (ancillaryResponse.IsSuccessful)
         {
            if (ancillaryResponse.Statements != null)
            {
               // We have additional statements to execute.
               writeStatements.AddRange(ancillaryResponse.Statements);
            }
         }
         else
         {
            // We are unable to move forward, as there are likely some ancillary statements that we failed to gather.
            if (ancillaryResponse.Errors != null)
            {
               responseErrors.AddRange(ancillaryResponse.Errors);
            }

            return false;
         }

         // Need to translate the database write statements, from the calculation engine models to the data access models.
         List<TSMT.RollupDataAccess.Models.WriteRollupDataStatement> rdaWriteStatements = new List<TSMT.RollupDataAccess.Models.WriteRollupDataStatement>();
         foreach (WriteRollupDataStatement writeStatement in writeStatements)
         {
            rdaWriteStatements.Add(this.mapper.Map<TSMT.RollupDataAccess.Models.WriteRollupDataStatement>(writeStatement));
         }

         // Finally, execute the statements.
         bool writesSucceeded = await this.writeRollupDataService.TransactStatements(rdaWriteStatements);
         if (!writesSucceeded)
         {
            responseErrors.Add("Failure executing database statements.");
            return false;
         }

         return true;
      }

      private async Task<SalesOfficeScoringDataViewModel> GetScoringData(PriceRollupBaseDataViewModel baseData)
      {
         IEnumerable<string> prodCodes = baseData.ProductCodeSummary.Select(pcs => pcs.ProductCode).Where(pc => pc != null).Distinct();
         SalesOfficeScoringData scoringData = await this.jobScoringApiClient.GetSalesOfficeScoringData(baseData.Job.SalesOfficeId, prodCodes, baseData.Job.CustChannelId);
         return this.mapper.Map<SalesOfficeScoringDataViewModel>(scoringData);
      }
   }
}
