﻿// <copyright file="RollupEnumService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System;
   using System.Linq;

   /// <inheritdoc/>
   public class RollupEnumService : IRollupEnumService
   {
      /// <inheritdoc/>
      public Tuple<int, string>[] CreateEnumTuples(Type enumType)
      {
         return Enum.GetValues(enumType)
            .Cast<int>()
            .OrderBy(e => e)
            .Select(e => Tuple.Create(e, Enum.GetName(enumType, e)))
            .ToArray();
      }
   }
}
