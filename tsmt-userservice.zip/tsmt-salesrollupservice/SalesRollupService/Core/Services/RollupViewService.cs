﻿// <copyright file="RollupViewService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDataAccess.Models;
   using TSMT.RollupDataAccess.Repositories;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// A service for handling rollup views
   /// </summary>
   public class RollupViewService : IRollupViewService
   {
      private readonly IMapper mapper;
      private readonly IRollupViewRepository viewRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupViewService"/> class.
      /// </summary>
      /// <param name="mapper">The object mapper</param>
      /// <param name="viewRepository">The view repository</param>
      public RollupViewService(IMapper mapper, IRollupViewRepository viewRepository)
      {
         this.mapper = mapper;
         this.viewRepository = viewRepository;
      }

      /// <inheritdoc/>
      public async Task PutView(RollupViewViewModel view)
      {
         RollupView dataModel = this.mapper.Map<RollupView>(view);
         await this.viewRepository.PutView(dataModel);
      }

      /// <inheritdoc/>
      public async Task PutViews(IEnumerable<RollupViewViewModel> views)
      {
         IEnumerable<RollupView> dataModels = this.mapper.Map<IEnumerable<RollupView>>(views);
         await this.viewRepository.PutViews(dataModels);
      }

      /// <inheritdoc/>
      public async Task DeleteView(string viewName)
      {
         await this.viewRepository.DeleteView(viewName);
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<RollupViewViewModel>> GetViews()
      {
         IEnumerable<RollupView> dataModels = await this.viewRepository.GetViews();
         return this.mapper.Map<IEnumerable<RollupViewViewModel>>(dataModels);
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<RollupViewViewModel>> GetUserViews(string userName)
      {
         IEnumerable<RollupView> dataModels = await this.viewRepository.GetUserViews(userName);
         return this.mapper.Map<IEnumerable<RollupViewViewModel>>(dataModels);
      }

      /// <inheritdoc/>
      public async Task PutColumn(string viewName, RollupColumnViewModel column)
      {
         RollupView dataView = await this.viewRepository.GetView(viewName);
         RollupColumn dataColumn = this.mapper.Map<RollupColumn>(column);

         // we may need to shift other columns over to accomadate.
         if (dataView.Columns.Any(c => c.Index == column.Index))
         {
            var columnsAfterIndex = dataView.Columns.Where(c => c.Index >= dataColumn.Index);
            foreach (var afterColumn in columnsAfterIndex)
            {
               afterColumn.Index++;
            }
         }

         dataView.Columns.Add(dataColumn);

         await this.viewRepository.PutView(dataView);
      }

      /// <inheritdoc/>
      public async Task DeleteColumn(string viewName, RollupColumnType columnType)
      {
         RollupView dataView = await this.viewRepository.GetView(viewName);
         RollupColumn dataColumn = dataView.Columns.Single(c => c.Id == (int)columnType);

         // we may need to shift other columns over to accomadate.
         var columnsAfterIndex = dataView.Columns.Where(c => c.Index > dataColumn.Index);
         foreach (var afterColumn in columnsAfterIndex)
         {
            afterColumn.Index--;
         }

         dataView.Columns.Remove(dataColumn);

         await this.viewRepository.PutView(dataView);
      }
   }
}