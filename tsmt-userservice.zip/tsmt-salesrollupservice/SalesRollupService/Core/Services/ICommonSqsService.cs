﻿// <copyright file="ICommonSqsService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;

   /// <summary>
   /// Interface for Common SQS Service
   /// </summary>
   public interface ICommonSqsService
   {
      /// <summary>
      /// Receive the message from sqs queue
      /// </summary>
      /// <param name="sqsUrl"> Sqs queue url</param>
      /// <param name="maximumNumberOfMessages">Number to get the maximum count of messages from sqs</param>
      /// <param name="queueWaitTime">Sqs queue wait time</param>
      /// <param name="messageHidingTime">Message visibility time</param>
      /// <returns>A <see cref="Task"/>Representing the asynchronous operation.</returns>
      Task<IEnumerable<Message>> GetSQSMessagesAsync(string sqsUrl, int maximumNumberOfMessages, int queueWaitTime, int messageHidingTime);

      /// <summary>
      /// Delete the sqs message
      /// </summary>
      /// <param name="message">Message to delete</param>
      /// <param name="sqsUrl"> Sqs queue url</param>
      /// <returns>Request id of deleted message</returns>
      Task<string> DeleteMessageAsync(Message message, string sqsUrl);
   }
}
