﻿// <copyright file="DiscountImportService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using AWS.MessagingWrapper.Contracts;
   using Microsoft.Extensions.Hosting;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Newtonsoft.Json;
   using Newtonsoft.Json.Linq;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.Models;
   using SalesRollupService.Core.Repository;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// Hosted service to monitor TSMT-DiscountTransfer queue for CoJo approvals
   /// </summary>
   public class DiscountImportService : BackgroundService
   {
      private readonly ILogger logger;
      private readonly IMessageReceiver messageReceiver;
      private readonly IOptions<CommonConfigurationSettings> appSettings;
      private readonly IDiscountImportRepository repository;
      private readonly IRollupHistoryService historyService;

      /// <summary>
      /// Initializes a new instance of the <see cref="DiscountImportService"/> class.
      /// </summary>
      /// <param name="logger">logger for trace/error messages</param>
      /// <param name="messageReceiver">queue for reading requests</param>
      /// <param name="appSettings">application settings</param>
      /// <param name="historyService">rollup history service</param>
      /// <param name="repository">discount import repository</param>
      public DiscountImportService(
         ILogger<DiscountImportService> logger,
         IMessageReceiver messageReceiver,
         IOptions<CommonConfigurationSettings> appSettings,
         IRollupHistoryService historyService,
         IDiscountImportRepository repository)
      {
         this.logger = logger;
         this.messageReceiver = messageReceiver;
         this.appSettings = appSettings;
         this.historyService = historyService;
         this.repository = repository;
      }

      /// <summary>
      /// Create rollup history entry
      /// </summary>
      /// <param name="jobId">job id</param>
      /// <param name="bidId">bid alternate id</param>
      /// <param name="userId">user responsible for the data update</param>
      /// <param name="editDate">datetime of edit activity</param>
      /// <param name="sppId">selected pricing parameter id</param>
      /// <param name="columnType">edited column</param>
      /// <param name="oldValue">prior value</param>
      /// <param name="newValue">new value</param>
      /// <returns>task</returns>
      public async Task AddHistory(int jobId, int bidId, string userId, DateTime editDate, int sppId, EditableColumnType columnType, decimal oldValue, decimal newValue)
      {
         // Conjure up the editing circumstances, for discounted item (as if it happened in isolation).
         PriceRollupEdit priceRollupEdit = new PriceRollupEdit()
         {
            Guid = Guid.NewGuid(),
            User = userId,
            Date = editDate,
            RollupType = RollupType.Code, // providing a value, there is no active rollup
            RollupRowType = RollupRowType.SelectedPricingParm,
            RollupRowIdentifier = sppId.ToString(),
            EditableColumnType = columnType,
            OldValue = oldValue,
            NewValue = newValue,
            RollupConsumer = RollupConsumer.SalesOffice
         };

         // Add this edit to the history of edits to this rollup
         if (!await this.historyService.AppendEdit(jobId, bidId, priceRollupEdit))
         {
            this.logger.LogWarning("Failure to append rollup edit to history, after applying discounts");
         }
      }

      /// <summary>
      /// Update selected pricing paramters on a job with authorized discount
      /// </summary>
      /// <param name="transferJob">instance of a job, received from Cojo</param>
      /// <returns>task</returns>
      public async Task UpdateSalesOfficeJob(DiscountTransferViewModel transferJob)
      {
         this.logger.LogInformation("Starting Import of Discounts - Dr Address Id: {DrAddressId}, Job Id: {JobId}", transferJob.DrAddressId, transferJob.JobId);

         // set current VPD instance
         this.repository.HonorDrAddressId(transferJob.DrAddressId);

         // get current bid
         Bid bid = await this.repository.GetCurrentBid(transferJob.JobId);

         // load spps on current rollup (bid)
         IEnumerable<SelectedPricingParm> soSpps = await this.repository.GetSelectedPricingParms(bid.BidAlternateId);

         DateTime editDate = DateTime.UtcNow;
         foreach (SelectedPricingParm spp in soSpps)
         {
            // do not update ordered selections
            if (!spp.IsOrdered)
            {
               // locate discount spp
               DiscountSelectionViewModel discountSpp = transferJob.Selections.SingleOrDefault(x => x.SelectionId == spp.SELECTION_ID && x.ProdPricingGroupId == spp.PROD_PRICING_GRP_ID);

               if (discountSpp == null)
               {
                  // SPP in Sales Office job which isn't in Cojo data.
                  // This indicates the selection has been added after the job was submitted for coordination
                  // Legacy:  "It appears that the job has changed since submitting it to the COJO team. Multipliers and CPLPAFs have been imported for those items that match the information in COJO. Make sure you closely examine the results in Price Rollup for accuracy."
                  this.logger.LogInformation("Import of Discounts ({DrAddressId}/{JobId}) : SPP in Sales Office job which isn't in COJO data", transferJob.DrAddressId, transferJob.JobId);
               }
               else
               {
                  // identify this SPP as having been touched
                  discountSpp.IsApplied = true;

                  // identify new values, using provided values - or reset to default, if not provided by Cojo
                  decimal authMult = discountSpp.AuthMult ?? 1.0M;
                  decimal authCplpaf = discountSpp.AuthCplpaf ?? 1.0M;

                  bool isCplpafModified = spp.AUTH_COST_POINT_LPAF != authCplpaf;
                  bool isMultModified = spp.AUTH_MULT != authMult;

                  if (isCplpafModified || isMultModified)
                  {
                     if (isCplpafModified)
                     {
                        await this.AddHistory(
                              transferJob.JobId,
                              bid.BidAlternateId,
                              transferJob.UserId,
                              editDate,
                              spp.SELECTED_PRICING_PARM_ID,
                              EditableColumnType.AuthorizedCPLPAF,
                              spp.AUTH_COST_POINT_LPAF ?? 0,
                              authCplpaf);
                     }

                     if (isMultModified)
                     {
                        await this.AddHistory(
                              transferJob.JobId,
                              bid.BidAlternateId,
                              transferJob.UserId,
                              editDate,
                              spp.SELECTED_PRICING_PARM_ID,
                              EditableColumnType.AuthorizedMultiplier,
                              spp.AUTH_MULT ?? 0,
                              authMult);
                     }

                     spp.AUTH_COST_POINT_LPAF = authCplpaf;
                     spp.AUTH_MULT = authMult;
                     await this.repository.UpdateSelectedPricingParm(spp);
                  }
               }
            }
         }

         // determine if any Discount SPPs were not touched
         if (transferJob?.Selections?.Any(x => !x.IsApplied) == true)
         {
            /*
             * Job has changed since submission to cojo
             *   one or more seperately biddables or a selection has been removed since submission
             * Legacy:  "It appears that the job has changed since submitting it to the COJO team. Multipliers and CPLPAFs have been imported for those items that match the information in COJO. Make sure you closely examine the results in Price Rollup for accuracy."
            */
            this.logger.LogInformation("Import of Discounts ({DrAddressId}/{JobId}) : Job changed since submission to COJO", transferJob.DrAddressId, transferJob.JobId);
         }

         this.logger.LogInformation("Complete: Import of Discounts - Dr Address Id: {DrAddressId}, Job Id: {JobId}", transferJob.DrAddressId, transferJob.JobId);
      }

      /// <summary>
      /// Executes the background service
      /// </summary>
      /// <param name="stoppingToken">token for canceling execution</param>
      /// <returns>Task representing completion</returns>
      protected async override Task ExecuteAsync(CancellationToken stoppingToken)
      {
         this.logger.LogTrace("Discount Import background service is starting.");
         while (!stoppingToken.IsCancellationRequested)
         {
            try
            {
               /*
                * look to enhance this processing loop to tread multiple imports concurrently
                * see RollupHistoryBackgroundService
                */

               IEnumerable<Message> workItems = await this.messageReceiver.ReceiveMessageAsync(
                  this.appSettings.Value.SqsServiceUrlForDiscountTransfer,
                  stoppingToken);

               foreach (Message message in workItems)
               {
                  await this.messageReceiver.DeleteMessageAsync(this.appSettings.Value.SqsServiceUrlForDiscountTransfer, message.ReceiptHandle);

                  // Deserialize the message to the response.
                  JObject responseData = JsonConvert.DeserializeObject<JObject>(message.Body);

                  // Deserialize the response to the model.
                  DiscountTransferViewModel transferJob = JsonConvert.DeserializeObject<DiscountTransferViewModel>(responseData["Message"].ToString());

                  await this.UpdateSalesOfficeJob(transferJob);
               }
            }
            catch (Exception ex)
            {
               this.logger.LogError(ex, "Error occurred executing Discount Import background service.");
            }
         }

         this.logger.LogTrace("Discount Import background service is stopping.");
      }
   }
}
