﻿// <copyright file="IRollupGridService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using PriceRollupCalculationEngine.Models;
   using PriceRollupCalculationEngine.ViewModels;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// Exposes routines to build rollup grids and respond to grid edits.
   /// </summary>
   public interface IRollupGridService
   {
      /// <summary>
      /// Gathers rollup base data (including SPP-level data) for a job/bid.
      /// </summary>
      /// <param name="jobId">Job ID</param>
      /// <param name="bidId">Bid ID</param>
      /// <returns>rollup base data</returns>
      Task<PriceRollupBaseDataViewModel> GetRollupBaseData(int jobId, int bidId);

      /// <summary>
      /// Builds a rollup grid for a job/bid.
      /// </summary>
      /// <param name="jobId">The job ID</param>
      /// <param name="bidId">The bid ID</param>
      /// <param name="rollupType">Type of rollup to return (code, family, model)</param>
      /// <param name="calculatePricingPolicy">Should we calculate pricing policy?</param>
      /// <returns>A grid model</returns>
      Task<RollupViewModel> GetRollupGrid(int jobId, int bidId, RollupType rollupType, bool calculatePricingPolicy);

      /// <summary>
      /// Shapes rollup base data into a rollup grid.
      /// </summary>
      /// <param name="baseData">Rollup base data (including SPP-level data)</param>
      /// <param name="rollupType">Type of rollup to return (code, family, model)</param>
      /// <param name="calculatePricingPolicy">Should we calculate pricing policy?</param>
      /// <returns>A grid model</returns>
      Task<RollupViewModel> GetRollupGrid(PriceRollupBaseDataViewModel baseData, RollupType rollupType, bool calculatePricingPolicy);

      /// <summary>
      /// Applies a grid edit to the underlying database.
      /// </summary>
      /// <param name="jobId">Job ID</param>
      /// <param name="bidId">Bid ID</param>
      /// <param name="baseData">Existing rollup base data (including SPP-level data)</param>
      /// <param name="priceRollupEdit">Circumstances of the edit attempt (which cell is being edited, and the desired change)</param>
      /// <param name="responseErrors">List of errors, populated during the edit attempt, which explain why the edit could not be applied</param>
      /// <returns>true when successful, false when the edit could not be applied</returns>
      Task<bool> ApplyRollupGridEdit(int jobId, int bidId, PriceRollupBaseDataViewModel baseData, PriceRollupEdit priceRollupEdit, List<string> responseErrors);

      /// <summary>
      /// Copies multipliers, applying changes to the underlying database.
      /// </summary>
      /// <param name="jobId">Job ID</param>
      /// <param name="bidId">Bid ID</param>
      /// <param name="baseData">Existing rollup base data (including SPP-level data)</param>
      /// <param name="copyMultiplierSource">Identifies the source of copied data</param>
      /// <param name="copiedMultipliers">When successful, this list is populated with the multiplier values that were changed</param>
      /// <param name="responseErrors">List of errors, populated during the copy attempt, which explain why the copy could not be applied</param>
      /// <returns>true when successful, false when the copy could not be applied</returns>
      Task<bool> CopyMultipliers(int jobId, int bidId, PriceRollupBaseDataViewModel baseData, CopyMultiplierSource copyMultiplierSource, List<CopiedMultiplier> copiedMultipliers, List<string> responseErrors);
   }
}
