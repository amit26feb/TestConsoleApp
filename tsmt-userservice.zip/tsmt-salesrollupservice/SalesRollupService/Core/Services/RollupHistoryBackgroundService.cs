﻿// <copyright file="RollupHistoryBackgroundService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using Microsoft.Extensions.Hosting;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Newtonsoft.Json;
   using Newtonsoft.Json.Linq;
   using SalesRollupService.Configurations;
   using TSMT.RebalancingDomain.Models;
   using TSMT.RollupDataAccess.Repositories;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// Rollup History Background Service
   /// </summary>
   public class RollupHistoryBackgroundService : BackgroundService
   {
      private readonly ILogger<RollupHistoryBackgroundService> logger;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettings;
      private readonly ICommonSqsService commonSqsService;
      private readonly IRollupHistoryRepository rollupHistoryRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupHistoryBackgroundService"/> class.
      /// </summary>
      /// <param name="logger">Logging the information</param>
      /// <param name="commonConfigurationSettings">Set configurable values</param>
      /// <param name="commonSqsService">Message receiver</param>
      /// <param name="rollupHistoryRepository">Rollup history repository</param>
      public RollupHistoryBackgroundService(IOptions<CommonConfigurationSettings> commonConfigurationSettings, ICommonSqsService commonSqsService, IRollupHistoryRepository rollupHistoryRepository, ILogger<RollupHistoryBackgroundService> logger)
      {
         this.commonConfigurationSettings = commonConfigurationSettings;
         this.commonSqsService = commonSqsService;
         this.rollupHistoryRepository = rollupHistoryRepository;
         this.logger = logger;
      }

      /// <summary>
      /// Process the message
      /// </summary>
      /// <param name="message">Message to process</param>
      /// <returns>A <see cref="Task"/>Representing the asynchronous operation.</returns>
      public async Task ProcessRollupHistoryExecution(Message message)
      {
         this.logger.LogInformation($"Started processing the below message. {Environment.NewLine} {message}");

         if (message?.Body != null)
         {
            // Read message body and deserialize it.
            JObject jsonObject = (JObject)JsonConvert.DeserializeObject(message.Body);

            // [1..^1] represent the removal of char from starting and end
            string rollupHistoryMessage = jsonObject["Message"].Value<string>().Replace("\\\"", "\"")[1..^1];

            // deserialize the message after removing of char
            JobEdit jobEdit = JsonConvert.DeserializeObject<JobEdit>(rollupHistoryMessage);

            // SelectionEdits is having data
            if (jobEdit?.SelectionEdits?.Any() == true)
            {
               // selections are grouped by BidAlternateId
               List<IGrouping<int?, Edit>> groupByBidAlternateId = jobEdit.SelectionEdits.GroupBy(x => x.BidAlternateId).ToList();

               // Each grouped selection iteration
               foreach (IGrouping<int?, Edit> group in groupByBidAlternateId)
               {
                  // Each selection item in group form the PriceRollupEdit model and update DocDb
                  foreach (Edit selectionEdit in group)
                  {
                     // forming the PriceRollupEdit model with message of the body
                     PriceRollupEdit priceRollupEdit = new PriceRollupEdit()
                     {
                        Guid = Guid.NewGuid(),
                        User = jobEdit.UserId,
                        Date = DateTime.UtcNow,
                        RollupType = RollupType.Family,
                        RollupRowType = RollupRowType.Selection,
                        RollupRowIdentifier = selectionEdit.Id.ToString(),
                        EditableColumnType = (selectionEdit.ColumnType == ColumnType.NetDollars) ? EditableColumnType.NetDollars : EditableColumnType.UnadjustedListPrice,
                        OldValue = selectionEdit.OldValue ?? 0,
                        NewValue = selectionEdit.NewValue ?? 0,
                        RollupConsumer = RollupConsumer.SalesOffice,
                        RollupHistoryType = RollupHistoryTypes.UnTransmitted,
                     };

                     // update the DocDb
                     await this.rollupHistoryRepository.AppendEdit(jobEdit.JobId, (int)selectionEdit.BidAlternateId, priceRollupEdit);
                  }
               }
            }

            // VariationEdits is having data
            if (jobEdit?.VariationEdits?.Any() == true)
            {
               // Variations are grouped by BidAlternateId
               List<IGrouping<int?, Edit>> groupByBidAlternateId = jobEdit.VariationEdits.GroupBy(x => x.BidAlternateId).ToList();

               // Each grouped variation iteration
               foreach (IGrouping<int?, Edit> group in groupByBidAlternateId)
               {
                  // Each variation item in group form the PriceRollupEdit model and update DocDb
                  foreach (Edit variationEdit in group)
                  {
                     // forming the PriceRollupEdit model with message of the body
                     PriceRollupEdit priceRollupEdit = new PriceRollupEdit()
                     {
                        Guid = Guid.NewGuid(),
                        User = jobEdit.UserId,
                        Date = DateTime.UtcNow,
                        RollupType = RollupType.Family,
                        RollupRowType = RollupRowType.JobVariationProdCode,
                        RollupRowIdentifier = variationEdit.Id.ToString(),
                        EditableColumnType = EditableColumnType.CostForecast,
                        OldValue = variationEdit.OldValue ?? 0,
                        NewValue = variationEdit.NewValue ?? 0,
                        RollupConsumer = RollupConsumer.SalesOffice,
                        RollupHistoryType = RollupHistoryTypes.UnTransmitted,
                     };

                     // update the DocDb
                     await this.rollupHistoryRepository.AppendEdit(jobEdit.JobId, (int)variationEdit.BidAlternateId, priceRollupEdit);
                  }
               }
            }
            else
            {
               this.logger.LogInformation($"JobEdit or selections or variations does not contain data. JobId: {jobEdit?.JobId}, Selections: {jobEdit?.SelectionEdits}, Variations: {jobEdit?.VariationEdits}");
            }

            // Deletes the message from sqs queue
            await this.commonSqsService.DeleteMessageAsync(message, this.commonConfigurationSettings.Value.SqsServiceURLForRollupHistoryService);

            this.logger.LogInformation($"Deleted the below message from rollup history sqs queue. {Environment.NewLine} {message}");
         }
         else
         {
            this.logger.LogInformation("SQS queue message is invalid");
         }
      }

      /// <summary>
      /// Start execution of rollup history background service
      /// </summary>
      /// <param name="stoppingToken">Canellation token</param>
      /// <returns>A <see cref="Task"/>Representing the asynchronous operation</returns>
      protected async override Task ExecuteAsync(CancellationToken stoppingToken)
      {
         this.logger.LogTrace("Rollup history background service started");

         // The code inside IF will not run in stage and production environment until Equipment Single Site Pilot release
         if (!this.commonConfigurationSettings.Value.IsStageOrProdEnvironment)
         {
            // Initialize the available tasks count to max number of messages that can be received at an instance
            int availableTasksCount = this.commonConfigurationSettings.Value.MaxNoOfMessagesForRollupHistory;
            var tasks = new List<Task>();
            while (!stoppingToken.IsCancellationRequested)
            {
               try
               {
                  // read message from sqs
                  this.logger.LogTrace($"Started getting SQS messages through Rollup history service. SQS Url - {this.commonConfigurationSettings.Value.SqsServiceURLForRollupHistoryService}");
                  var rollupHistoryList = await this.commonSqsService.GetSQSMessagesAsync(this.commonConfigurationSettings.Value.SqsServiceURLForRollupHistoryService, availableTasksCount, this.commonConfigurationSettings.Value.QueueWaitTimeForRollupHistory, this.commonConfigurationSettings.Value.MessageHidingTimeInMinutesForRollupHistory);

                  if (rollupHistoryList?.Any() == true)
                  {
                     foreach (Message message in rollupHistoryList)
                     {
                        tasks.Add(Task.Run(async () => { await this.ProcessRollupHistoryExecution(message); }));
                     }

                     await Task.WhenAny(tasks);

                     // Gets the count of running tasks to adjust the availableTasksCount
                     int runningTasksCount = tasks.Count(x => (x.Status == TaskStatus.Running || x.Status == TaskStatus.WaitingForActivation || x.Status == TaskStatus.WaitingToRun));
                     availableTasksCount = this.commonConfigurationSettings.Value.MaxNoOfMessagesForRollupHistory - runningTasksCount;

                     // Removing completed, faulted or canceled tasks from parallel execution to make room for new tasks
                     tasks.RemoveAll(x => (x.Status == TaskStatus.RanToCompletion || x.Status == TaskStatus.Faulted || x.Status == TaskStatus.Canceled));
                  }
               }
               catch (Exception ex)
               {
                  this.logger.LogError($"Error in Rollup history execution background service. Error details - {ex.Message}");
               }
            }
         }
      }
   }
}
