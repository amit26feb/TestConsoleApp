﻿// <copyright file="IRollupEnumService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System;

   /// <summary>
   /// Exposes routines for getting information about rollup enumerations.
   /// </summary>
   public interface IRollupEnumService
   {
      /// <summary>
      /// Create an ordered collection of enum tuples
      /// where each tuple is the pair of an enum's index and name.
      /// </summary>
      /// <param name="enumType">The enum to use</param>
      /// <returns>A collection of tuples</returns>
      Tuple<int, string>[] CreateEnumTuples(Type enumType);
   }
}
