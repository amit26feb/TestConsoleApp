﻿// <copyright file="CommonSqsService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using AWS.MessagingWrapper.Contracts;
   using Microsoft.Extensions.Logging;

   /// <summary>
   /// Common sqs service
   /// </summary>
   public class CommonSqsService : ICommonSqsService
   {
      private readonly ILogger<CommonSqsService> logger;
      private readonly IMessageReceiver messageReceiver;

      /// <summary>
      /// Initializes a new instance of the <see cref="CommonSqsService"/> class.
      /// </summary>
      /// <param name="logger">Logger</param>
      /// <param name="messageReceiver">Message receiver </param>
      public CommonSqsService(ILogger<CommonSqsService> logger, IMessageReceiver messageReceiver)
      {
         this.logger = logger;
         this.messageReceiver = messageReceiver;
      }

      /// <summary>
      /// Receive the message from sqs queue
      /// </summary>
      /// <param name="sqsUrl"> Sqs queue url</param>
      /// <param name="maximumNumberOfMessages">Number to get the maximum count of messages from sqs</param>
      /// <param name="queueWaitTime">Sqs queue wait time</param>
      /// <param name="messageHidingTime">Message visibility time</param>
      /// <returns>A <see cref="Task"/>Representing the asynchronous operation.</returns>
      public async Task<IEnumerable<Message>> GetSQSMessagesAsync(string sqsUrl, int maximumNumberOfMessages, int queueWaitTime, int messageHidingTime)
      {
         IEnumerable<Message> messages = null;
         try
         {
            // Gets the message from SQS only when the maximum number of message is greater than 0
            if (maximumNumberOfMessages > 0)
            {
               this.logger.LogInformation($"Started to connecting SQS to get messages for rule execution. SQS Url - {sqsUrl}");
               messages = await this.messageReceiver.ReceiveMessageAsync(sqsUrl, CancellationToken.None, maximumNumberOfMessages, queueWaitTime, messageHidingTime);
               this.logger.LogInformation(messages != null ? $"Received {messages.Count()} message(s) from SQS rule execution. SQS Url - {sqsUrl}" : $"Message not received from SQS for rule execution. SQS Url - {sqsUrl}");
            }
         }
         catch (Exception ex)
         {
            this.logger.LogError("Error while receiving SQS message: ", ex.ToString());
         }

         return messages;
      }

      /// <summary>
      /// Delete the sqs message
      /// </summary>
      /// <param name="message">Message to delete</param>
      /// <param name="sqsUrl"> Sqs queue url</param>
      /// <returns>Request id of deleted message</returns>
      public async Task<string> DeleteMessageAsync(Message message, string sqsUrl)
      {
         return await this.messageReceiver.DeleteMessageAsync(sqsUrl, message.ReceiptHandle);
      }
   }
}
