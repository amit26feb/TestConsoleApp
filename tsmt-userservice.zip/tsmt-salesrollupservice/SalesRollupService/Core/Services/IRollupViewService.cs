﻿// <copyright file="IRollupViewService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// A service for handling rollup views
   /// </summary>
   public interface IRollupViewService
   {
      /// <summary>
      /// Adds a view.
      /// The view is replaced if it already exists.
      /// </summary>
      /// <param name="view">The view model</param>
      /// <returns>A task</returns>
      Task PutView(RollupViewViewModel view);

      /// <summary>
      /// Adds a batch of views.
      /// A view is replaced if it already exists.
      /// </summary>
      /// <param name="views">The view batch</param>
      /// <returns>A task</returns>
      Task PutViews(IEnumerable<RollupViewViewModel> views);

      /// <summary>
      /// Deletes a view (a 'standard' view).
      /// </summary>
      /// <param name="viewName">The name of the view to delete</param>
      /// <returns>A task</returns>
      Task DeleteView(string viewName);

      /// <summary>
      /// Gets all views.
      /// </summary>
      /// <returns>The views</returns>
      Task<IEnumerable<RollupViewViewModel>> GetViews();

      /// <summary>
      /// Gets all views available for a specific user (AKA owner).
      /// This includes both standard and custom views.
      /// </summary>
      /// <param name="userName">The user name used to filter views</param>
      /// <returns>The views for the user</returns>
      Task<IEnumerable<RollupViewViewModel>> GetUserViews(string userName);

      /// <summary>
      /// Adds a column to a view (a 'standard' view).
      /// The column is replaced if it already exists.
      /// Indices of other columns are adjusted to accommodate.
      /// </summary>
      /// <param name="viewName">The name of the view to add the column to</param>
      /// <param name="column">The model of the column to add</param>
      /// <returns>A task</returns>
      Task PutColumn(string viewName, RollupColumnViewModel column);

      /// <summary>
      /// Deletes a column from a view (a 'standard' view).
      /// Indices of other columns are adjusted to accommodate.
      /// </summary>
      /// <param name="viewName">The ID of the view to delete the column from</param>
      /// <param name="columnType">The type (AKA ID) of the the column to delete</param>
      /// <returns>A task</returns>
      Task DeleteColumn(string viewName, RollupColumnType columnType);
   }
}
