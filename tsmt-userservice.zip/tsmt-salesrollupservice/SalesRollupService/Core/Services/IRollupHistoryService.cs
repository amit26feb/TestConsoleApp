﻿// <copyright file="IRollupHistoryService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// A service for handling rollup histories
   /// </summary>
   public interface IRollupHistoryService
   {
      /// <summary>
      /// Gets the entire history of edits for a rollup
      /// </summary>
      /// <param name="jobId">The job for the rollup</param>
      /// <param name="bidId">The bid for the rollup</param>
      /// <returns>The history</returns>
      Task<PriceRollupHistory> GetHistory(int jobId, int bidId);

      /// <summary>
      /// Appends (or creates) a history with an edit
      /// </summary>
      /// <param name="jobId">The job for the rollup</param>
      /// <param name="bidId">The bid for the rollup</param>
      /// <param name="edit">The edit to append</param>
      /// <returns>The state of success</returns>
      Task<bool> AppendEdit(int jobId, int bidId, PriceRollupEdit edit);

      /// <summary>
      /// Removes edits for provided IDs
      /// </summary>
      /// <param name="jobId">The job for the rollup</param>
      /// <param name="bidId">The bid for the rollup</param>
      /// <param name="editIds">The edit IDs to remove</param>
      /// <returns>The state of success</returns>
      Task<bool> RemoveEdits(int jobId, int bidId, IList<Guid> editIds);

      /// <summary>
      /// Rewinds a rollup history to a certain edit
      /// </summary>
      /// <param name="request">The request model</param>
      /// <returns>A rewound rollup</returns>
      Task<RewindHistoryResultViewModel> RewindHistory(RewindHistoryRequestViewModel request);
   }
}
