﻿// <copyright file="RollupHistoryService.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using PriceRollupCalculationEngine.CalculationEngine;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDataAccess.Models;
   using TSMT.RollupDataAccess.Repositories;
   using TSMT.RollupDataAccess.Services;
   using TSMT.RollupDomain.Models;

   using DAModels = TSMT.RollupDataAccess.Models;
   using ENGViewModels = PriceRollupCalculationEngine.ViewModels;

   /// <summary>
   /// A service for handling rollup histories
   /// </summary>
   public class RollupHistoryService : IRollupHistoryService
   {
      private readonly ILogger logger;
      private readonly IMapper mapper;
      private readonly IReadRollupDataService rollupReadDataService;
      private readonly IWriteRollupDataService rollupWriteDataService;
      private readonly IRollupHistoryRepository rollupHistoryRepository;
      private readonly IRollupHistoryRewinder rollupHistoryRewinder;
      private readonly IRollupGridService rollupGridService;
      private readonly IRollupRepository rollupRepository;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettings;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupHistoryService"/> class.
      /// </summary>
      /// <param name="logger">The class logger</param>
      /// <param name="mapper">The object mapper</param>
      /// <param name="httpContextAccessor">The HTTP context accessor</param>
      /// <param name="rollupReadDataService">The read data service</param>
      /// <param name="rollupWriteDataService">The write data service</param>
      /// <param name="rollupGridService">The rollup grid service</param>
      /// <param name="rollupHistoryRepository">The history repository</param>
      /// <param name="rollupHistoryRewinder">The history rewinder</param>
      /// <param name="rollupRepository">The rollup repository</param>
      /// <param name="commonConfigurationSettings">The common configuration settings</param>
      public RollupHistoryService(
         ILogger<RollupHistoryService> logger,
         IMapper mapper,
         IHttpContextAccessor httpContextAccessor,
         IReadRollupDataService rollupReadDataService,
         IWriteRollupDataService rollupWriteDataService,
         IRollupGridService rollupGridService,
         IRollupHistoryRepository rollupHistoryRepository,
         IRollupHistoryRewinder rollupHistoryRewinder,
         IRollupRepository rollupRepository,
         IOptions<CommonConfigurationSettings> commonConfigurationSettings)
      {
         this.logger = logger;
         this.mapper = mapper;
         this.rollupReadDataService = rollupReadDataService;
         this.rollupWriteDataService = rollupWriteDataService;
         this.rollupGridService = rollupGridService;
         this.rollupHistoryRepository = rollupHistoryRepository;
         this.rollupHistoryRewinder = rollupHistoryRewinder;
         this.rollupRepository = rollupRepository;
         this.commonConfigurationSettings = commonConfigurationSettings;

         // Pull the DrAddressId out of the HTTP context
         // The data services/repositories need to be told to honor it
         if (httpContextAccessor.HttpContext != null
            && httpContextAccessor.HttpContext.Items != null
            && httpContextAccessor.HttpContext.Items.ContainsKey("DR_ADDRESS_ID")
            && int.TryParse(httpContextAccessor.HttpContext.Items["DR_ADDRESS_ID"].ToString(), out int drAddressIdToHonor))
         {
            this.rollupReadDataService.HonorDrAddressId(drAddressIdToHonor);
            this.rollupWriteDataService.HonorDrAddressId(drAddressIdToHonor);
            this.rollupRepository.HonorDrAddressId(drAddressIdToHonor);
         }
         else
         {
            this.rollupReadDataService.HonorDrAddressId(null);
            this.rollupWriteDataService.HonorDrAddressId(null);
            this.rollupRepository.HonorDrAddressId(null);
         }
      }

      /// <inheritdoc/>
      public async Task<PriceRollupHistory> GetHistory(int jobId, int bidId)
      {
         try
         {
            PriceRollupHistory result = await this.rollupHistoryRepository.GetHistory(jobId, bidId);

            // The code inside IF will not run in stage and production environment until Equipment Single Site Pilot release
            if (!this.commonConfigurationSettings.Value.IsStageOrProdEnvironment)
            {
               IEnumerable<PriceRollupEdit> priceRollupEdits = result?.Edits;

               // Adding Description for  PreAward, Transmitted and UnTransmitted data
               if (priceRollupEdits?.Any() == true)
               {
                  await this.LoadDescriptionForSelections(priceRollupEdits);

                  await this.LoadDescriptionForProductFamilies(priceRollupEdits);

                  await this.LoadDescriptionForProductCodes(priceRollupEdits);

                  await this.LoadDescriptionForVariations(priceRollupEdits);

                  // Load total description
                  priceRollupEdits.Where(priceRollupEdit => (priceRollupEdit.RollupRowType == RollupRowType.Total))?.ToList().ForEach(priceRollupEdit => priceRollupEdit.Description = "Total");

                  // Load grand total description
                  priceRollupEdits.Where(priceRollupEdit => (priceRollupEdit.RollupRowType == RollupRowType.GrandTotal))?.ToList().ForEach(priceRollupEdit => priceRollupEdit.Description = "GrandTotal");
               }
            }

            return result;
         }
         catch (Exception ex)
         {
            this.logger.LogError(ex, $"Error in RollupHistoryService.GetHistory");
            return null;
         }
      }

      /// <inheritdoc/>
      public async Task<bool> AppendEdit(int jobId, int bidId, PriceRollupEdit edit)
      {
         try
         {
            bool result = await this.rollupHistoryRepository.AppendEdit(jobId, bidId, edit);
            return result;
         }
         catch (Exception ex)
         {
            this.logger.LogError(ex, $"Error in RollupHistoryService.AppendEdit");
            return false;
         }
      }

      /// <inheritdoc/>
      public async Task<bool> RemoveEdits(int jobId, int bidId, IList<Guid> editIds)
      {
         try
         {
            bool result = await this.rollupHistoryRepository.RemoveEdits(jobId, bidId, editIds);
            return result;
         }
         catch (Exception ex)
         {
            this.logger.LogError(ex, $"Error in RollupHistoryService.RemoveEdits");
            return false;
         }
      }

      /// <inheritdoc/>
      public async Task<RewindHistoryResultViewModel> RewindHistory(RewindHistoryRequestViewModel request)
      {
         try
         {
            // Validate the request
            if (!request.Validate(out string error))
            {
               string errorMessage = $"Invalid request. {error}";
               this.logger.LogError(errorMessage);
               return new RewindHistoryResultViewModel(errorMessage);
            }

            int jobId = request.JobId;
            int bidId = request.BidId;

            // Get base data
            var daBaseData = await this.rollupReadDataService.GetPriceRollupData(jobId, bidId);
            if (daBaseData == null)
            {
               string errorMessage = $"Failure to get base data";
               this.logger.LogError(errorMessage);
               return new RewindHistoryResultViewModel(errorMessage);
            }

            var engBaseData = this.mapper.Map<ENGViewModels.PriceRollupBaseDataViewModel>(daBaseData);

            // Get history
            var history = await this.GetHistory(jobId, bidId);
            if (history == null)
            {
               string errorMessage = $"Failure to get history";
               this.logger.LogError(errorMessage);
               return new RewindHistoryResultViewModel(errorMessage);
            }

            // Rewind to edit
            var rewindToEdit = this.rollupHistoryRewinder.RewindToEdit(engBaseData, history, request.Edit);
            if (rewindToEdit.Errors?.Any() == true)
            {
               string errorMessage = $"Failure rewind to edit";
               this.logger.LogError(errorMessage);
               return new RewindHistoryResultViewModel(errorMessage);
            }

            // Sync SPPs and VARIATIONs (these are the two tables to potentially update)
            var dbWrites = rewindToEdit.Statements.Select(this.mapper.Map<DAModels.WriteRollupDataStatement>);
            bool syncDbSuccess = await this.rollupWriteDataService.TransactStatements(dbWrites);
            if (!syncDbSuccess)
            {
               string errorMessage = $"Failure sync database (SPPs and VARIATIONs)";
               this.logger.LogError(errorMessage);
               return new RewindHistoryResultViewModel(errorMessage);
            }

            // Sync History
            bool syncEditSuccess = await this.rollupHistoryRepository.RemoveEdits(jobId, bidId, rewindToEdit.RewoundEdits.ToList());
            if (!syncEditSuccess)
            {
               string errorMessage = $"Failure sync history";
               this.logger.LogError(errorMessage);
               return new RewindHistoryResultViewModel(errorMessage);
            }

            // Get rollup grid data (build rollup)
            var rollupType = request.RollupType ?? request.Edit.RollupType;
            var rollup = await this.rollupGridService.GetRollupGrid(engBaseData, rollupType, true);
            if (rollup == null)
            {
               string errorMessage = $"Failure to get rollup grid";
               this.logger.LogError(errorMessage);
               return new RewindHistoryResultViewModel(errorMessage);
            }

            // Return with the rollup
            return new RewindHistoryResultViewModel(rollup);
         }
         catch (Exception ex)
         {
            string errorMessage = $"Unhandled exception";
            this.logger.LogError(errorMessage, ex);
            return new RewindHistoryResultViewModel(errorMessage);
         }
      }

      /// <summary>
      /// Load the description for selection records by selection Ids
      /// </summary>
      /// <param name="priceRollupEdits">History record from document DB</param>
      /// <returns>representing the asynchronous operation.</returns>
      private async Task LoadDescriptionForSelections(IEnumerable<PriceRollupEdit> priceRollupEdits)
      {
         List<RollupRowType> rollupTypes = new List<RollupRowType>()
        {
            RollupRowType.Selection,
            RollupRowType.SelectionMainUnitProdCode
         };

         // Load Selection Records
         IEnumerable<PriceRollupEdit> rollupEdits = priceRollupEdits.Where(priceRollupEdit => rollupTypes.Contains(priceRollupEdit.RollupRowType));

         IEnumerable<int> selectionIds = rollupEdits?.Select(rollupEdit =>
         {
            return int.TryParse(rollupEdit.RollupRowIdentifier, out int rollupRowIdentifier) ? rollupRowIdentifier : 0;
         });

         if (selectionIds?.Any() == true)
         {
            IEnumerable<SelectionIdentifier> selections = await this.rollupRepository.GetSelectionIdentifiers(selectionIds);

            rollupEdits?.ToList().ForEach(rollupEdit =>
            {
               rollupEdit.Description = selections?.Where(selectionIdentifier => selectionIdentifier.SELECTION_ID.ToString() == rollupEdit.RollupRowIdentifier)?.Select(selection => $"<{selection.TAG}>{selection.SALESMAN_DESCR}").FirstOrDefault();
            });
         }
      }

      /// <summary>
      /// Load the description for family by family Ids
      /// </summary>
      /// <param name="priceRollupEdits">History record from document DB</param>
      /// <returns>representing the asynchronous operation.</returns>
      private async Task LoadDescriptionForProductFamilies(IEnumerable<PriceRollupEdit> priceRollupEdits)
      {
         // Load Selection Records
         IEnumerable<PriceRollupEdit> rollupEdits = priceRollupEdits.Where(priceRollupEdit => (priceRollupEdit.RollupRowType == RollupRowType.ProductFamily));

         IEnumerable<int> familyIds = rollupEdits?.Select(priceRollupEdit =>
         {
            return int.TryParse(priceRollupEdit.RollupRowIdentifier, out int rollupRowIdentifier) ? rollupRowIdentifier : 0;
         });

         if (familyIds?.Any() == true)
         {
            IEnumerable<ProductFamily> productFamilies = await this.rollupRepository.GetProductFamilies(familyIds);

            rollupEdits?.ToList().ForEach(priceRollupEdit =>
            {
               priceRollupEdit.Description = productFamilies?.Where(productFamily => productFamily.PROD_FAMILY_ID.ToString() == priceRollupEdit.RollupRowIdentifier)?.Select(prodFamily => prodFamily.DESCRIPTION).FirstOrDefault();
            });
         }
      }

      /// <summary>
      /// Load the description for main unit product code, separately biddable product code, variation product code, selection separately biddable product code, selection variation prodcut code by product codes
      /// </summary>
      /// <param name="priceRollupEdits">History record from document DB</param>
      /// <returns>representing the asynchronous operation.</returns>
      private async Task LoadDescriptionForProductCodes(IEnumerable<PriceRollupEdit> priceRollupEdits)
      {
         List<RollupRowType> rollupTypes = new List<RollupRowType>()
        {
            RollupRowType.MainUnitProdCode,
            RollupRowType.SeparatelyBiddableProdCode,
            RollupRowType.VariationProdCode,
            RollupRowType.SelectionSeparatelyBiddableProdCode,
            RollupRowType.SelectionVariationProdCode
         };

         // Load Selection Records
         IEnumerable<PriceRollupEdit> rollupEdits = priceRollupEdits.
             Where(priceRollupEdit => rollupTypes.Contains(priceRollupEdit.RollupRowType));

         IEnumerable<string> productCodes = rollupEdits?.Select(priceRollupEdit =>
         {
            string[] productCode = priceRollupEdit.RollupRowIdentifier?.Split('|');
            if (productCode != null)
            {
               return (productCode?.Count() > 1) ? productCode[1] : priceRollupEdit.RollupRowIdentifier;
            }
            return string.Empty;
         });

         if (productCodes?.Any() == true)
         {
            IEnumerable<ProductCode> productCodesWithDescriptions = await this.rollupRepository.GetProductCodesAndDescriptions(productCodes);

            rollupEdits?.ToList().ForEach(priceRollupEdit =>
            {
               priceRollupEdit.Description = productCodesWithDescriptions?.Where(productCode => productCode.PROD_CODE?.ToString() == priceRollupEdit.RollupRowIdentifier)?.Select(description => description.DESCRIPTION).FirstOrDefault();
            });
         }
      }

      /// <summary>
      /// Load the description for job variation product code by variation Ids
      /// </summary>
      /// <param name="priceRollupEdits">History record from document DB</param>
      /// <returns>representing the asynchronous operation.</returns>
      private async Task LoadDescriptionForVariations(IEnumerable<PriceRollupEdit> priceRollupEdits)
      {
         // Load Selection Records
         IEnumerable<PriceRollupEdit> rollupEdits = priceRollupEdits.
             Where(priceRollupEdit => (priceRollupEdit.RollupRowType == RollupRowType.JobVariationProdCode));

         IEnumerable<int> jobVariationIds = rollupEdits?.Select(priceRollupEdit =>
         {
            return int.TryParse(priceRollupEdit.RollupRowIdentifier, out int rollupRowIdentifier) ? rollupRowIdentifier : 0;
         });

         if (jobVariationIds?.Any() == true)
         {
            IEnumerable<VariationIdentifier> jobVariationProductCodesWithDescriptions = await this.rollupRepository.GetVariationIdentifiers(jobVariationIds);

            rollupEdits?.ToList().ForEach(priceRollupEdit =>
            {
               priceRollupEdit.Description = jobVariationProductCodesWithDescriptions?.Where(variationIdentifier => variationIdentifier.VARIATION_ID.ToString() == priceRollupEdit.RollupRowIdentifier).Select(description => description.SHORT_DESC).FirstOrDefault();
            });
         }
      }
   }
}
