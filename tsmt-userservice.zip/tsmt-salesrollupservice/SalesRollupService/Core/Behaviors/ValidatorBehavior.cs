﻿// <copyright file="ValidatorBehavior.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Behaviors
{
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using FluentValidation;
   using MediatR;
   using SalesRollupService.Common.Exceptions;

   /// <summary>
   /// Validator behavior
   /// </summary>
   /// <typeparam name="TRequest">TRequest details</typeparam>
   /// <typeparam name="TResponse">TResponse details</typeparam>
   public class ValidatorBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
   {
      private readonly IValidator<TRequest>[] validators;

      /// <summary>
      /// Initializes a new instance of the <see cref="ValidatorBehavior{TRequest, TResponse}"/> class.
      /// </summary>
      /// <param name="validators">Validators details</param>
      public ValidatorBehavior(IValidator<TRequest>[] validators) => this.validators = validators;

      /// <summary>
      /// Handle request
      /// </summary>
      /// <param name="request">Request details</param>
      /// <param name="cancellationToken">Cancellation Token</param>
      /// <param name="next">Next request handler delegate</param>
      /// <returns>Representing the asynchronous operation.</returns>
      public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
      {
         var failures = this.validators
             .Select(v => v.Validate(request))
             .SelectMany(result => result.Errors)
             .Where(error => error != null)
             .ToList();

         if (failures.Any())
         {
            throw new SalesRollupServiceDomainException(
                $"Command Validation Errors for type {typeof(TRequest).Name}", new ValidationException("Validation exception", failures));
         }

         var response = await next();
         return response;
      }
   }
}
