﻿// <copyright file="IDiscountImportRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Repository
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using SalesRollupService.Core.Models;

   /// <summary>
   /// Interface for the Discount Import repository
   /// </summary>
   public interface IDiscountImportRepository
   {
      /// <summary>
      /// Identify the dr_address_id (vpd) which should be honored when interacting with the database
      /// </summary>
      /// <param name="drAddressId">dr address id</param>
      void HonorDrAddressId(int? drAddressId);

      /// <summary>
      /// Get bids on a job
      /// </summary>
      /// <param name="jobId">job id</param>
      /// <returns>bid collection</returns>
      Task<IEnumerable<Bid>> GetBids(int jobId);

      /// <summary>
      /// Get bid identified as current on a job
      /// </summary>
      /// <param name="jobId">job id</param>
      /// <returns>current bid, or null if none exist or not identified</returns>
      Task<Bid> GetCurrentBid(int jobId);

      /// <summary>
      /// Get selected pricing parms for selection discounts
      /// </summary>
      /// <param name="bidId">bid alternate id</param>
      /// <returns>selected pricing parm collection</returns>
      Task<IEnumerable<SelectedPricingParm>> GetSelectedPricingParms(int bidId);

      /// <summary>
      /// Update selected pricing parameter discount information
      /// </summary>
      /// <param name="spp">selected pricing parameter</param>
      /// <returns>task</returns>
      Task UpdateSelectedPricingParm(SelectedPricingParm spp);
   }
}
