﻿// <copyright file="DiscountImportRepository.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Core.Repository
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using Dapper;
   using SalesRollupService.Common;
   using SalesRollupService.Core.Models;
   using TSMT.DataAccess;

   /// <summary>
   /// Implementation of the Discount Import repository
   /// </summary>
   public class DiscountImportRepository : IDiscountImportRepository
   {
      private readonly IRepository<IDataEntity> repository;

      /// <summary>
      /// Initializes a new instance of the <see cref="DiscountImportRepository"/> class.
      /// </summary>
      /// <param name="repository">repository instance</param>
      public DiscountImportRepository(IRepository<IDataEntity> repository)
      {
         DefaultTypeMap.MatchNamesWithUnderscores = true;
         this.repository = repository;
         this.repository.HonorDrAddressId(-1);
      }

      /// <inheritdoc/>
      public void HonorDrAddressId(int? drAddressId)
      {
         this.repository.HonorDrAddressId(drAddressId);
      }

      /// <inheritdoc/>
      public virtual async Task<IEnumerable<Bid>> GetBids(int jobId)
      {
         var param = new
         {
            JOB_ID = jobId
         };

         return await this.repository.ExecuteListQuery<Bid>(DiscountImportRepositoryQueries.BidAlternatesByJobId, param);
      }

      /// <inheritdoc/>
      public async Task<Bid> GetCurrentBid(int jobId)
      {
         IEnumerable<Bid> bids = await this.GetBids(jobId);

         if (bids == null || !bids.Any())
         {
            return null;
         }

         Bid currentBid = bids.SingleOrDefault(x => x.IsCurrentBid);

         if (currentBid == null)
         {
            currentBid = bids.SingleOrDefault(x => x.IsBaseBid);
         }

         return currentBid;
      }

      /// <inheritdoc/>
      public async Task<IEnumerable<SelectedPricingParm>> GetSelectedPricingParms(int bidId)
      {
         var param = new
         {
            BID_ALTERNATE_ID = bidId
         };

         return await this.repository.ExecuteListQuery<SelectedPricingParm>(DiscountImportRepositoryQueries.SelectedPriceParamsUsingBidId, param);
      }

      /// <inheritdoc/>
      public async Task UpdateSelectedPricingParm(SelectedPricingParm spp)
      {
         var param = new
         {
            spp.SELECTED_PRICING_PARM_ID,
            spp.AUTH_COST_POINT_LPAF,
            spp.AUTH_MULT
         };

         await this.repository.ExecuteAsync<int>(DiscountImportRepositoryQueries.ApplySelectedPricingParmDiscount, param);
      }
   }
}
