// <copyright file="Startup.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService
{
   using System;
   using System.Collections.Generic;
   using System.IO;
   using System.Reflection;
   using App.Metrics;
   using Autofac;
   using Autofac.Extensions.DependencyInjection;
   using AutoMapper;
   using CrossCuttingServices.Common.Filters;
   using CrossCuttingServices.Common.Middlewares;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Builder;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.AspNetCore.Mvc.Authorization;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.OpenApi.Models;
   using NLog.Web;
   using Okta.AspNetCore;
   using SalesRollupService.Common.Configurations.AutofacModules;
   using SalesRollupService.Common.Exceptions;
   using SalesRollupService.Configurations;
   using TraneSalesTools.Middlewares;
   using TSMT.Settings;

   /// <summary>
   /// Startup
   /// </summary>
   public class Startup
   {
      private readonly string liveness;

      /// <summary>
      /// Initializes a new instance of the <see cref="Startup"/> class.
      /// </summary>
      /// <param name="configuration">configuration</param>
      /// <param name="env">hosting environment</param>
      public Startup(IConfiguration configuration, IWebHostEnvironment env)
      {
         this.Configuration = configuration;
         this.HostingEnvironment = env;
         NLogBuilder.ConfigureNLog($"nlog.{env.EnvironmentName}.config");
         this.liveness = "/liveness";
      }

      /// <summary>
      /// Gets Configuration
      /// </summary>
      public IConfiguration Configuration { get; }

      /// <summary>
      /// Gets the Hosting Environment.
      /// </summary>
      public IWebHostEnvironment HostingEnvironment { get; }

      // This method gets called by the runtime. Use this method to add services to the container.

      /// <summary>
      /// Initializes a new instance of the <see cref="IServiceProvider"/> class.
      /// </summary>
      /// <param name="services">configuration</param>
      /// <returns>Config</returns>
      public IServiceProvider ConfigureServices(IServiceCollection services)
      {
         var metrics = AppMetrics.CreateDefaultBuilder()

                     .Configuration.Configure(
                         options =>
                         {
                            options.AddEnvTag(this.HostingEnvironment.EnvironmentName);
                         })
                       .Report.ToInfluxDb(options =>
                       {
                          options.InfluxDb.BaseUri = new Uri(this.Configuration["InfluxDbUrl"]);
                          options.InfluxDb.Database = this.Configuration["InfluxDb"];
                          options.InfluxDb.UserName = this.Configuration["InfluxDbUserName"];
                          options.InfluxDb.Password = this.Configuration["InfluxDbPassword"];
                          options.InfluxDb.CreateDataBaseIfNotExists = true;
                       }).Build();

         services.AddMetrics(metrics);
         services.AddMetricsReportingHostedService();
         services.AddMetricsEndpoints();
         services.AddMetricsTrackingMiddleware();
         services.AddHttpContextAccessor();

         // Add framework services.
         services.AddMvc(options =>
         {
            AuthorizationPolicy policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
            options.Filters.Add(new AuthorizeFilter(policy));
         }).AddControllersAsServices().AddMetrics().AddNewtonsoftJson();

         services.AddMvcCore(options =>
         {
            options.Filters.Add(typeof(HttpGlobalExceptionFilter<SalesRollupServiceDomainException>));
         }).AddControllersAsServices();

         services.Configure<TSMTSettings>(this.Configuration);

         services.AddSwaggerGen(options =>
         {
#pragma warning disable SA1118 // Parameter must not span multiple lines
            options.SwaggerDoc("v1", new OpenApiInfo
            {
               Title = "SalesRollup Service HTTP API",
               Version = "v1",
               Description = "The SalesRollup Service HTTP API"
            });
            OpenApiSecurityScheme apiKeyScheme = new OpenApiSecurityScheme()
            {
               Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
               Name = "Authorization",
               In = ParameterLocation.Header,
               Type = SecuritySchemeType.ApiKey,
               Scheme = "Bearer",
               BearerFormat = "JWT"
            };
            options.AddSecurityDefinition("Bearer", apiKeyScheme);
            options.AddSecurityRequirement(new OpenApiSecurityRequirement()
            {
               {
                  new OpenApiSecurityScheme
                  {
                     Reference = new OpenApiReference
                     {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer",
                     },
                     Scheme = "OAuth2",
                     Name = "Bearer",
                     In = ParameterLocation.Header
                  }, new List<string>()
               }
            });
            //// Set the comments path for the Swagger JSON and UI.
            var xmlFile = $"{Assembly.GetEntryAssembly().GetName().Name}.xml";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            if (File.Exists(xmlPath))
            {
               options.IncludeXmlComments(xmlPath);
            }
         });

         services.AddAuthentication(options =>
         {
            options.DefaultAuthenticateScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultChallengeScheme = OktaDefaults.ApiAuthenticationScheme;
            options.DefaultSignInScheme = OktaDefaults.ApiAuthenticationScheme;
         })
         .AddOktaWebApi(new OktaWebApiOptions()
         {
            OktaDomain = this.Configuration["OktaDomain"],
            AuthorizationServerId = this.Configuration["OktaAuthorizationServerID"]
         });

         services.AddCors(options =>
         {
            options.AddPolicy(
                   "CorsPolicy",
                   builder => builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader());
         });

         services.AddApiVersioning();

         services.AddOptions();

         services.AddAutoMapper(
            typeof(TSMT.RollupDataAccess.Common.AutoMapperProfile),
            typeof(Configurations.AutoMapperConfiguration.AutoMapperProfile));
         services.Configure<CommonConfigurationSettings>(this.Configuration);

         services.AddHttpClient();

         // configure autofac
         var container = new ContainerBuilder();
         container.Populate(services);

         // The mediator module uses the pipeline, notification and Request/Response Command handler
         // This is stored as a separate Module
         container.RegisterModule(new MediatorModule(this.Configuration));

         return new AutofacServiceProvider(container.Build());
      }

      /// <summary>
      /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
      /// </summary>
      /// <param name="app">application builder</param>
      /// <param name="env">hosting environment</param>
      public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
      {
         var pathBase = this.Configuration["PATH_BASE"];

         if (!string.IsNullOrEmpty(pathBase))
         {
            app.UsePathBase(pathBase);
         }

         app.UseMiddleware<LoggerMiddleware>();
         app.UseMetricsAllMiddleware();
         app.UseMetricsAllEndpoints();
         app.UseRouting();
         app.UseCors("CorsPolicy");
         app.UseAuthentication();
         app.UseAuthorization();
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseDrAddressIdResolver();
         });
         app.UseWhen(context => context.Request.Method != "OPTIONS", appBuilder =>
         {
            appBuilder.UseVPDAuthenticator();
         });

#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
         app.Map(this.liveness, lapp => lapp.Run(async ctx => ctx.Response.StatusCode = 200));
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously

         app.UseEndpoints(endpoints =>
         {
            endpoints.MapControllers();
         });

         app.UseSwagger()
            .UseSwaggerUI(c =>
            {
               c.SwaggerEndpoint($"{(!string.IsNullOrEmpty(pathBase) ? pathBase : string.Empty)}/swagger/v1/swagger.json", "SalesRollupService.API V1");
            });
      }
   }
}
