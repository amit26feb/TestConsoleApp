﻿// <copyright file="RollupEnumsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Controllers
{
   using System;
   using System.Net;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using SalesRollupService.Core.Services;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// A controller for providing information about rollup enumerations
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/[controller]")]
   [Authorize]
   public class RollupEnumsController : Controller
   {
      private readonly IRollupEnumService rollupEnumService;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupEnumsController"/> class.
      /// </summary>
      /// <param name="rollupEnumService">The rollup enum service</param>
      public RollupEnumsController(IRollupEnumService rollupEnumService)
      {
         this.rollupEnumService = rollupEnumService;
      }

      /// <summary>
      /// Gets the rollup column type enumeration.
      /// </summary>
      /// <returns>The enumeration</returns>
      [Route("ColumnType")]
      [HttpGet]
      [ProducesResponseType(typeof(Tuple<int, string>[]), (int)HttpStatusCode.OK)]
      public IActionResult GetRollupColumnTypes()
      {
         return this.Ok(this.rollupEnumService.CreateEnumTuples(typeof(RollupColumnType)));
      }
   }
}