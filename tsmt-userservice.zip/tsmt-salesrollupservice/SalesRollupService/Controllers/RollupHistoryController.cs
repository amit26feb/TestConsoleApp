﻿// <copyright file="RollupHistoryController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Controllers
{
   using System.Collections.Generic;
   using System.Net;
   using System.Threading.Tasks;
   using CrossCuttingServices.Common.Exceptions;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using PriceRollupCalculationEngine.ViewModels;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// Rollup history controller
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/[controller]")]
   [Authorize]
   public class RollupHistoryController : Controller
   {
      private readonly ILogger<RollupHistoryController> logger;
      private readonly IRollupHistoryService rollupHistoryService;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupHistoryController"/> class.
      /// </summary>
      /// <param name="logger">Selections logger</param>
      /// <param name="rollupHistoryService">A service to handle rollup views</param>
      public RollupHistoryController(ILogger<RollupHistoryController> logger, IRollupHistoryService rollupHistoryService)
      {
         this.logger = logger;
         this.rollupHistoryService = rollupHistoryService;
      }

      /// <summary>
      /// Gets the entire history of edits for a rollup
      /// </summary>
      /// <param name="jobId">The job for the rollup</param>
      /// <param name="bidId">The bid for the rollup</param>
      /// <returns>The history</returns>
      [Route("Job/{jobId}/Bid/{bidId}")]
      [HttpGet]
      [ProducesResponseType(typeof(PriceRollupHistory), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetHistory(int jobId, int bidId)
      {
         if (jobId <= 0)
         {
            string errorMessage = $"Invalid Request. Job ID '{jobId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (bidId <= 0)
         {
            string errorMessage = $"Invalid Request. Bid ID '{bidId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         PriceRollupHistory history = await this.rollupHistoryService.GetHistory(jobId, bidId);
         return this.Ok(history);
      }

      /// <summary>
      /// Rewinds a rollup history to a certain edit
      /// </summary>
      /// <param name="request">The request model</param>
      /// <returns>A rewound rollup</returns>
      [Route("Job/{jobId}/Bid/{bidId}/RewoundRollup")]
      [HttpPost]
      [ProducesResponseType(typeof(RollupViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.Conflict)]
      public async Task<IActionResult> RewindHistory([FromBody]RewindHistoryRequestViewModel request)
      {
         if (request == null)
         {
            string errorMessage = $"The request is null";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (!request.Validate(out string reason))
         {
            string errorMessage = $"The request is invalid. {reason}";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         var result = await this.rollupHistoryService.RewindHistory(request);

         if (!result.IsSuccessful)
         {
            this.logger.LogInformation($"Failure to rewind history. Reason(s): {string.Join(". ", result.Errors)}");
            return this.Conflict(ValidationResult.ValidationMessage(result.Errors));
         }

         return this.Ok(result.Rollup);
      }
   }
}