﻿// <copyright file="RollupViewController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Controllers
{
   using System.Net;
   using System.Threading.Tasks;
   using CrossCuttingServices.Common.Exceptions;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// A controller for dealing with a specific rollup view.
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/[controller]")]
   [Authorize]
   public class RollupViewController : Controller
   {
      private readonly ILogger<RollupViewController> logger;
      private readonly IRollupViewService rollupViewService;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupViewController"/> class.
      /// </summary>
      /// <param name="logger">Selections logger</param>
      /// <param name="rollupViewService">A service to handle rollup views</param>
      public RollupViewController(ILogger<RollupViewController> logger, IRollupViewService rollupViewService)
      {
         this.logger = logger;
         this.rollupViewService = rollupViewService;
      }

      /// <summary>
      /// Adds a view.
      /// The view is replaced if it already exists.
      /// </summary>
      /// <param name="view">The view model</param>
      /// <returns>The success or failure code</returns>
      [HttpPut]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> PutView([FromBody] RollupViewViewModel view)
      {
         if (view == null)
         {
            string errorMessage = $"Invalid Request. The view argument is null.";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new[] { errorMessage }));
         }

         await this.rollupViewService.PutView(view);
         return this.Ok();
      }

      /// <summary>
      /// Deletes a view (a 'standard' view).
      /// </summary>
      /// <param name="viewName">The name of the view to delete</param>
      /// <returns>The success or failure code</returns>
      [Route("{viewName}")]
      [HttpDelete]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> DeleteView(string viewName)
      {
         if (string.IsNullOrEmpty(viewName))
         {
            string errorMessage = $"Invalid Request. The view name is falsy.";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new[] { errorMessage }));
         }

         await this.rollupViewService.DeleteView(viewName);
         return this.Ok();
      }

      /// <summary>
      /// Adds a column to a view (a 'standard' view).
      /// The column is replaced if it already exists.
      /// Indices of other columns are adjusted to accommodate.
      /// </summary>
      /// <param name="viewName">The name of the view to add the column to</param>
      /// <param name="column">The model of the column to add</param>
      /// <returns>The success or failure code</returns>
      [Route("{viewName}/Column")]
      [HttpPut]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> PutColumn(string viewName, [FromBody] RollupColumnViewModel column)
      {
         if (string.IsNullOrEmpty(viewName))
         {
            string errorMessage = $"Invalid Request. The view name is falsy.";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new[] { errorMessage }));
         }

         if (column == null)
         {
            string errorMessage = $"Invalid Request. The column model is null.";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new[] { errorMessage }));
         }

         await this.rollupViewService.PutColumn(viewName, column);
         return this.Ok();
      }

      /// <summary>
      /// Deletes a column from a view (a 'standard' view).
      /// Indices of other columns are adjusted to accommodate.
      /// </summary>
      /// <param name="viewName">The name of the view to delete the column from</param>
      /// <param name="columnType">The type (AKA ID) of the the column to delete</param>
      /// <returns>The success or failure code</returns>
      [Route("{viewName}/Column/{columnType}")]
      [HttpDelete]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> DeleteColumn(string viewName, RollupColumnType columnType)
      {
         if (string.IsNullOrEmpty(viewName))
         {
            string errorMessage = $"Invalid Request. The view name is falsy.";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new[] { errorMessage }));
         }

         await this.rollupViewService.DeleteColumn(viewName, columnType);
         return this.Ok();
      }
   }
}