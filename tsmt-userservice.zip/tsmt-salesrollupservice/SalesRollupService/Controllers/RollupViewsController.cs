﻿// <copyright file="RollupViewsController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Controllers
{
   using System.Collections.Generic;
   using System.Net;
   using System.Threading.Tasks;
   using CrossCuttingServices.Common.Exceptions;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;

   /// <summary>
   /// A controller for dealing with a collections of rollup view.
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/[controller]")]
   [Authorize]
   public class RollupViewsController : Controller
   {
      private readonly ILogger<RollupViewsController> logger;
      private readonly IRollupViewService rollupViewService;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupViewsController"/> class.
      /// </summary>
      /// <param name="logger">Selections logger</param>
      /// <param name="rollupViewService">A service to handle rollup views</param>
      public RollupViewsController(ILogger<RollupViewsController> logger, IRollupViewService rollupViewService)
      {
         this.logger = logger;
         this.rollupViewService = rollupViewService;
      }

      /// <summary>
      /// Adds a batch of views.
      /// A view is replaced if it already exists.
      /// </summary>
      /// <param name="views">The view batch</param>
      /// <returns>The success or failure code</returns>
      [HttpPut]
      [ProducesResponseType((int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> PutViews([FromBody] IEnumerable<RollupViewViewModel> views)
      {
         if (views == null)
         {
            string errorMessage = $"Invalid Request. The views argument is null.";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new[] { errorMessage }));
         }

         await this.rollupViewService.PutViews(views);
         return this.Ok();
      }

      /// <summary>
      /// Gets all views.
      /// </summary>
      /// <returns>The views</returns>
      [HttpGet]
      [ProducesResponseType(typeof(RollupViewViewModel), (int)HttpStatusCode.OK)]
      public async Task<IActionResult> GetViews()
      {
         IEnumerable<RollupViewViewModel> views = await this.rollupViewService.GetViews();
         return this.Ok(views);
      }

      /// <summary>
      /// Gets all views available for a specific user.
      /// This includes both standard and custom views.
      /// </summary>
      /// <param name="userName">The username to find views for</param>
      /// <returns>The views for the user</returns>
      [Route("{userName}")]
      [HttpGet]
      [ProducesResponseType(typeof(IEnumerable<RollupViewViewModel>), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetUserViews(string userName)
      {
         if (string.IsNullOrEmpty(userName))
         {
            string errorMessage = $"Invalid Request. UserName '{userName}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         IEnumerable<RollupViewViewModel> views = await this.rollupViewService.GetUserViews(userName);
         return this.Ok(views);
      }
   }
}