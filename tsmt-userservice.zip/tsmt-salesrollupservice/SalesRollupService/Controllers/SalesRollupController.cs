﻿// <copyright file="SalesRollupController.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Controllers
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using System.Web;
   using CrossCuttingServices.Common.Exceptions;
   using Microsoft.AspNetCore.Authorization;
   using Microsoft.AspNetCore.Http;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using PriceRollupCalculationEngine.Models;
   using PriceRollupCalculationEngine.ViewModels;
   using SalesRollupService.Core.Services;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// SalesRollup Controller
   /// </summary>
   [ApiVersion("1.0")]
   [Route("api/v{version:apiVersion}/{drAddressId}/Jobs/{jobId}/[controller]")]
   [Authorize]
   public class SalesRollupController : Controller
   {
      private readonly ILogger<SalesRollupController> logger;
      private readonly IRollupGridService rollupGridService;
      private readonly IRollupHistoryService rollupHistoryService;
      private readonly IHttpContextAccessor httpContextAccessor;

      /// <summary>
      /// Initializes a new instance of the <see cref="SalesRollupController"/> class.
      /// </summary>
      /// <param name="logger">Selections logger</param>
      /// <param name="rollupGridService">A service to build rollup grids</param>
      /// <param name="rollupHistoryService">A service to track edits to a rollup</param>
      /// <param name="httpContextAccessor">A service to scrape info from the http request</param>
      public SalesRollupController(
         ILogger<SalesRollupController> logger,
         IRollupGridService rollupGridService,
         IRollupHistoryService rollupHistoryService,
         IHttpContextAccessor httpContextAccessor)
      {
         this.logger = logger;
         this.rollupGridService = rollupGridService;
         this.rollupHistoryService = rollupHistoryService;
         this.httpContextAccessor = httpContextAccessor;
      }

      /// <summary>
      /// GetPriceRollup
      /// </summary>
      /// <returns>Return PriceRollup based on JobId/BidId</returns>
      /// <param name="jobId">The job ID</param>
      /// <param name="bidId">The bid ID</param>
      /// <param name="rollupType">Rollup shape (code, family, model)</param>
      /// <param name="calculatePricingPolicy">Should we calculate pricing policy?</param>
      [Route("{rollupType}")]
      [HttpGet]
      [ProducesResponseType(typeof(RollupViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      public async Task<IActionResult> GetRollupGrid(int jobId, int bidId, string rollupType = "code", bool calculatePricingPolicy = true)
      {
         if (jobId <= 0)
         {
            string errorMessage = $"Invalid Request. Job Id '{jobId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (bidId <= 0)
         {
            string errorMessage = $"Invalid Request. Bid Id '{bidId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (!Enum.TryParse<RollupType>(rollupType, ignoreCase: true, result: out RollupType rollupTypeEnum))
         {
            string errorMessage = $"Invalid Request. Rollup type '{rollupType}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         RollupViewModel gridData = await this.rollupGridService.GetRollupGrid(jobId, bidId, rollupTypeEnum, calculatePricingPolicy);
         return this.Ok(gridData);
      }

      /// <summary>
      /// Applies an edit, and returns refreshed PriceRollup grid data upon success.
      /// </summary>
      /// <param name="jobId">The job ID</param>
      /// <param name="bidId">The bid ID</param>
      /// <param name="rollupType">Rollup shape (code, family, model)</param>
      /// <param name="rowType">Type of rollup row being edited, such as Total, GrandTotal, or a row type that is applicable to the specific rollup grid.  For the Product Code grid, we expect things like MainUnitProdCode, SeparatelyBiddableProdCode, etc.  For the Product Family grid, we expect things like ProductFamily, Selection, SelectionMainUnitProdCode, etc.  For the Product Model grid, we expect things like SelectionMainUnitProdCode, SelectionMainUnitProdCodeWithModelNumber, etc.</param>
      /// <param name="rowIdentifier">Identifies which row in the grid is being edited (not applicable for some row types, like Totals, GrandTotals or AllJobVariations)</param>
      /// <param name="columnIdentifier">Identifies which column is being edited (such as EnteredDollars, EnteredMultiplier, etc.)</param>
      /// <param name="oldValue">Old (previous) value</param>
      /// <param name="newValue">New value</param>
      /// <returns>Upon success, returns post-edited PriceRollup grid data, otherwise returns reasons for failure</returns>
      [Route("{rollupType}/RowType/{rowType}/Row/{rowIdentifier}/Column/{columnIdentifier}")]
      [HttpPut]
      [ProducesResponseType(typeof(RollupViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.Conflict)]
      public async Task<IActionResult> ApplyEdit(int jobId, int bidId, string rollupType, string rowType, string rowIdentifier, string columnIdentifier, decimal oldValue, decimal newValue)
      {
         if (jobId <= 0)
         {
            string errorMessage = $"Invalid Request. Job Id '{jobId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (bidId <= 0)
         {
            string errorMessage = $"Invalid Request. Bid Id '{bidId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (!Enum.TryParse<RollupType>(rollupType, ignoreCase: true, result: out RollupType rollupTypeEnum))
         {
            string errorMessage = $"Invalid Request. Rollup type '{rollupType}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (!Enum.TryParse<RollupRowType>(rowType, ignoreCase: true, result: out RollupRowType rollupRowTypeEnum))
         {
            string errorMessage = $"Invalid Request. Row type '{rowType}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (!Enum.TryParse<EditableColumnType>(columnIdentifier, ignoreCase: true, result: out EditableColumnType editableColumnTypeEnum))
         {
            string errorMessage = $"Invalid Request. Column identifier '{columnIdentifier}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         // Only the dollars are editable in the Grand Total row.
         if (rollupRowTypeEnum == RollupRowType.GrandTotal && editableColumnTypeEnum != EditableColumnType.EnteredDollars)
         {
            string errorMessage = $"Invalid Request. Column identifier '{columnIdentifier}' is not valid for row type '{rowType}', this value is not editable";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         // Fetch latest rollup base data (including SPP-level data), for the job/bid.
         PriceRollupBaseDataViewModel rollupBaseData = await this.rollupGridService.GetRollupBaseData(jobId, bidId);

         // Need to decode, since the row identifier was encoded to handle characters such as the forward slash (in  identifiers like "N/A").
         string decodedRowIdentifier = (rowIdentifier != null && rowIdentifier != "null")
            ? HttpUtility.UrlDecode(rowIdentifier)
            : null;

         // Figure out who the user is making the edit
         string userId = string.Empty;
         if (this.httpContextAccessor.HttpContext?.User?.Claims != null)
         {
            userId = this.httpContextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
         }

         // Package up the editing circumstances.
         PriceRollupEdit priceRollupEdit = new PriceRollupEdit()
         {
            Guid = Guid.NewGuid(),
            User = userId,
            Date = DateTime.UtcNow,
            RollupType = rollupTypeEnum,
            RollupRowType = rollupRowTypeEnum,
            RollupRowIdentifier = decodedRowIdentifier,
            EditableColumnType = editableColumnTypeEnum,
            OldValue = oldValue,
            NewValue = newValue,
            RollupConsumer = RollupConsumer.SalesOffice,
            RollupHistoryType = RollupHistoryTypes.PreAward,
      };

         // Attempt to apply the rollup grid edit.
         List<string> editResponseErrors = new List<string>();
         bool successApplyingEdit = await this.rollupGridService.ApplyRollupGridEdit(jobId, bidId, rollupBaseData, priceRollupEdit, editResponseErrors);
         if (!successApplyingEdit)
         {
            this.logger.LogInformation(string.Format("Rollup Edit could not be applied.  Reason(s): " + string.Join("; ", editResponseErrors)));

            // Let the caller know the reason(s) why the edit could not be carried out.
            return this.Conflict(ValidationResult.ValidationMessage(editResponseErrors));
         }

         // Add this edit to the history of edits to this rollup
         if (!await this.rollupHistoryService.AppendEdit(jobId, bidId, priceRollupEdit))
         {
            this.logger.LogWarning("Failure to append rollup edit to history");
         }

         // Shape the post-edited rollup base data into rollup grid data.
         RollupViewModel gridData = await this.rollupGridService.GetRollupGrid(rollupBaseData, rollupTypeEnum, true);

         // Return rollup grid data, which portrays all the effects of the applied edit.
         return this.Ok(gridData);
      }

      /// <summary>
      /// Copies multipliers, and returns refreshed PriceRollup grid data upon success.
      /// </summary>
      /// <param name="jobId">The job ID</param>
      /// <param name="bidId">The bid ID</param>
      /// <param name="rollupType">Rollup shape (code, family, model)</param>
      /// <param name="source">Identifies the source of copied data (FAP, Authorized or PricingPolicy)</param>
      /// <returns>Upon success, returns post-edited PriceRollup grid data, otherwise returns reasons for failure</returns>
      [Route("{rollupType}/Multipliers/Source/{source}")]
      [HttpPut]
      [ProducesResponseType(typeof(RollupViewModel), (int)HttpStatusCode.OK)]
      [ProducesResponseType((int)HttpStatusCode.BadRequest)]
      [ProducesResponseType((int)HttpStatusCode.Conflict)]
      public async Task<IActionResult> CopyMultipliers(int jobId, int bidId, string rollupType, string source)
      {
         if (jobId <= 0)
         {
            string errorMessage = $"Invalid Request. Job Id '{jobId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (bidId <= 0)
         {
            string errorMessage = $"Invalid Request. Bid Id '{bidId}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (!Enum.TryParse<RollupType>(rollupType, ignoreCase: true, result: out RollupType rollupTypeEnum))
         {
            string errorMessage = $"Invalid Request. Rollup type '{rollupType}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         if (!Enum.TryParse<CopyMultiplierSource>(source, ignoreCase: true, result: out CopyMultiplierSource copyMultiplierSourceEnum))
         {
            string errorMessage = $"Invalid Request. Multiplier source type '{source}' is not valid";
            this.logger.LogError(errorMessage);
            return this.BadRequest(ValidationResult.ValidationMessage(new List<string>() { errorMessage }));
         }

         // Fetch latest rollup base data (including SPP-level data), for the job/bid.
         PriceRollupBaseDataViewModel rollupBaseData = await this.rollupGridService.GetRollupBaseData(jobId, bidId);

         // Attempt to apply the desired copy.
         List<CopiedMultiplier> copiedMultipliers = new List<CopiedMultiplier>();
         List<string> copyResponseErrors = new List<string>();
         bool successCopying = await this.rollupGridService.CopyMultipliers(jobId, bidId, rollupBaseData, copyMultiplierSourceEnum, copiedMultipliers, copyResponseErrors);
         if (!successCopying)
         {
            this.logger.LogInformation(string.Format("Multipliers could not be copied.  Reason(s): " + string.Join("; ", copyResponseErrors)));

            // Let the caller know the reason(s) why the copy could not be carried out.
            return this.Conflict(ValidationResult.ValidationMessage(copyResponseErrors));
         }

         // Figure out who the user is copying multipliers -- we'll need this for the history entries that we will conjure up.
         string userId = string.Empty;
         if (this.httpContextAccessor.HttpContext?.User?.Claims != null)
         {
            userId = this.httpContextAccessor.HttpContext.User.Claims.SingleOrDefault(x => x.Type == "samAccountName")?.Value.ToLower();
         }

         // Treat each copied multiplier as an individual edit, adding to the edit history.
         DateTime editDate = DateTime.UtcNow;
         foreach (CopiedMultiplier copiedMultiplier in copiedMultipliers)
         {
            // Multipliers are always copied at the most granular level -- either the SelectedPricingParm level or Variation level.
            RollupRowType editedRollupRowType;
            string editedRollupRowIdentifier;
            if (copiedMultiplier.DestinationEditableColumnType == EditableColumnType.VariationMarkup)
            {
               // Copying a Variation attribute (markup).
               editedRollupRowType = RollupRowType.Variation;
               editedRollupRowIdentifier = copiedMultiplier.VariationId.ToString();
            }
            else
            {
               // All other scenarios involve the copy of SelectedPricingParm attributes.
               editedRollupRowType = RollupRowType.SelectedPricingParm;
               editedRollupRowIdentifier = copiedMultiplier.SelectedPricingParmId.ToString();
            }

            // Conjure up the editing circumstances, for the copied multiplier (as if it happened in isolation).
            PriceRollupEdit priceRollupEdit = new PriceRollupEdit()
            {
               Guid = Guid.NewGuid(),
               User = userId,
               Date = editDate,
               RollupType = rollupTypeEnum,
               RollupRowType = editedRollupRowType,
               RollupRowIdentifier = editedRollupRowIdentifier,
               EditableColumnType = copiedMultiplier.DestinationEditableColumnType,
               OldValue = copiedMultiplier.OldValue,
               NewValue = copiedMultiplier.NewValue,
               RollupConsumer = RollupConsumer.SalesOffice
            };

            // Add this edit to the history of edits to this rollup
            if (!await this.rollupHistoryService.AppendEdit(jobId, bidId, priceRollupEdit))
            {
               this.logger.LogWarning("Failure to append rollup edit to history, after copying multipliers");
            }
         }

         // Shape the post-edited rollup base data into rollup grid data.
         RollupViewModel gridData = await this.rollupGridService.GetRollupGrid(rollupBaseData, rollupTypeEnum, true);

         // Return rollup grid data, which portrays all the effects of the copied multipliers.
         return this.Ok(gridData);
      }
   }
}