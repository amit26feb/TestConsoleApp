﻿// <copyright file="RollupViewControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Controller
{
   using System.Threading.Tasks;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using SalesRollupService.Controllers;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public class RollupViewControllerTest
   {
      private readonly RollupViewController controller;
      private readonly Mock<IRollupViewService> viewService;

      /// <summary>
      ///  Initializes a new instance of the <see cref="RollupViewControllerTest"/> class.
      /// </summary>
      public RollupViewControllerTest()
      {
         this.viewService = new Mock<IRollupViewService>();

         Mock<ILogger<RollupViewController>> logger = new Mock<ILogger<RollupViewController>>();
         this.controller = new RollupViewController(logger.Object, this.viewService.Object);
      }

      [Fact]
      public async Task PutView_GivenValidView_ReturnGoodResponse()
      {
         // Arrange
         var view = new RollupViewViewModel();

         // Act
         IActionResult result = await this.controller.PutView(view);

         // Assert
         Assert.IsType<OkResult>(result);
      }

      [Fact]
      public async Task PutView_GivenNullView_ReturnsBadResponse()
      {
         // Arrange
         RollupViewViewModel view = null;

         // Act
         IActionResult result = await this.controller.PutView(view);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task PutView_GivenValidView_CallsServiceOnce()
      {
         // Arrange
         var view = new RollupViewViewModel();

         // Act
         IActionResult result = await this.controller.PutView(view);

         // Assert
         this.viewService.Verify(x => x.PutView(view), Times.Once);
      }

      [Fact]
      public async Task DeleteView_GivenValidName_ReturnGoodResponse()
      {
         // Arrange
         string viewName = "bob's view";

         // Act
         IActionResult result = await this.controller.DeleteView(viewName);

         // Assert
         Assert.IsType<OkResult>(result);
      }

      [Fact]
      public async Task DeleteView_GivenFalsyName_ReturnsBadResponse()
      {
         // Arrange
         string viewName = string.Empty;

         // Act
         IActionResult result = await this.controller.DeleteView(viewName);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task DeleteView_GivenValidName_CallsServiceOnce()
      {
         // Arrange
         string viewName = "bob's view";

         // Act
         IActionResult result = await this.controller.DeleteView(viewName);

         // Assert
         this.viewService.Verify(x => x.DeleteView(viewName), Times.Once);
      }

      [Fact]
      public async Task PutColumn_GivenValidArguments_ReturnsGoodResponse()
      {
         // Arrange
         string viewName = "bob's view";
         var column = new RollupColumnViewModel();

         // Act
         IActionResult result = await this.controller.PutColumn(viewName, column);

         // Assert
         Assert.IsType<OkResult>(result);
      }

      [Fact]
      public async Task PutColumn_GivenFalsyViewName_ReturnsBadResponse()
      {
         // Arrange
         string viewName = string.Empty;
         var column = new RollupColumnViewModel();

         // Act
         IActionResult result = await this.controller.PutColumn(viewName, column);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task PutColumn_GivenNullColumn_ReturnsBadResponse()
      {
         // Arrange
         string viewName = "bob's view";
         RollupColumnViewModel column = null;

         // Act
         IActionResult result = await this.controller.PutColumn(viewName, column);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task PutColumn_GivenValidArguments_CallsServiceOnce()
      {
         // Arrange
         string viewName = "bob's view";
         var column = new RollupColumnViewModel();

         // Act
         IActionResult result = await this.controller.PutColumn(viewName, column);

         // Assert
         this.viewService.Verify(x => x.PutColumn(viewName, column), Times.Once);
      }

      [Fact]
      public async Task DeleteColumn_GivenValidArguments_ReturnsGoodResponse()
      {
         // Arrange
         string viewName = "bob's view";
         var columnType = RollupColumnType.AdjustedList;

         // Act
         IActionResult result = await this.controller.DeleteColumn(viewName, columnType);

         // Assert
         Assert.IsType<OkResult>(result);
      }

      [Fact]
      public async Task DeleteColumn_GivenFalsyViewName_ReturnsBadResponse()
      {
         // Arrange
         string viewName = string.Empty;
         var columnType = RollupColumnType.AdjustedList;

         // Act
         IActionResult result = await this.controller.DeleteColumn(viewName, columnType);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task DeleteColumn_GivenValidArguments_CallsServiceOnce()
      {
         // Arrange
         string viewName = "bob's view";
         var columnType = RollupColumnType.AdjustedList;

         // Act
         IActionResult result = await this.controller.DeleteColumn(viewName, columnType);

         // Assert
         this.viewService.Verify(x => x.DeleteColumn(viewName, columnType), Times.Once);
      }
   }
}