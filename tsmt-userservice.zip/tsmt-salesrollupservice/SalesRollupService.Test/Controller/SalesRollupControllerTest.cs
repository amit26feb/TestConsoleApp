﻿// <copyright file="SalesRollupControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Controller
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Net;
   using System.Threading.Tasks;
   using CrossCuttingServices.Common.Exceptions;
   using Microsoft.AspNetCore.Http;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using PriceRollupCalculationEngine.Models;
   using PriceRollupCalculationEngine.ViewModels;
   using SalesRollupService.Controllers;
   using SalesRollupService.Core.Services;
   using TSMT.RollupDomain.Models;
   using Xunit;

   /// <summary>
   /// SalesRollup Controller Test
   /// </summary>
   public class SalesRollupControllerTest
   {
      private readonly int jobId = 11466;
      private readonly int bidId = 629436;

      private readonly SalesRollupController controller;
      private readonly Mock<IRollupGridService> rollupGridService;
      private readonly Mock<IRollupHistoryService> rollupHistoryService;
      private readonly Mock<IHttpContextAccessor> mockHttpContextAccessor;

      /// <summary>
      ///  Initializes a new instance of the <see cref="SalesRollupControllerTest"/> class.
      /// </summary>
      public SalesRollupControllerTest()
      {
         Mock<ILogger<SalesRollupController>> logger = new Mock<ILogger<SalesRollupController>>();
         this.rollupGridService = new Mock<IRollupGridService>();
         this.rollupHistoryService = new Mock<IRollupHistoryService>();
         this.mockHttpContextAccessor = new Mock<IHttpContextAccessor>();

         this.controller = new SalesRollupController(
            logger.Object,
            this.rollupGridService.Object,
            this.rollupHistoryService.Object,
            this.mockHttpContextAccessor.Object);
      }

      /// <summary>
      /// Verify OK response from when JobId is valid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_ValidRequest_ReturnsValidData()
      {
         // Act
         IActionResult result = await this.controller.GetRollupGrid(this.jobId, this.bidId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(this.jobId, this.bidId, RollupType.Code, true), Times.Once);
      }

      /// <summary>
      /// Verify OK response from when JobId is valid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_CalcPricingPolicyFalse_DoesntCalcPricingPolicy()
      {
         // Act
         IActionResult result = await this.controller.GetRollupGrid(this.jobId, this.bidId, calculatePricingPolicy: false);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(this.jobId, this.bidId, RollupType.Code, false), Times.Once);
      }

      /// <summary>
      /// Verify BadRequest response from when JobId is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;

         // Act
         IActionResult result = await this.controller.GetRollupGrid(invalidJobId, this.bidId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response from  when BidId is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_InvalidBidId_ReturnsBadRequest()
      {
         // Arrange
         int invalidBidId = 0;

         // Act
         IActionResult result = await this.controller.GetRollupGrid(this.jobId, invalidBidId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response when requested rollup type is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_ReturnsBadRequest_GivenInvalidRequestedType()
      {
         // Act
         IActionResult result = await this.controller.GetRollupGrid(this.jobId, this.bidId, "brett");

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(this.jobId, this.bidId, It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verifies product code grid data is called for when requested
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_ReturnsProductCodeGrid_GivenValidRequestedType()
      {
         // Act
         IActionResult result = await this.controller.GetRollupGrid(this.jobId, this.bidId, "code");

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(this.jobId, this.bidId, RollupType.Code, It.IsAny<bool>()), Times.Once);
      }

      /// <summary>
      /// Verifies product family grid data is called for when requested
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_ReturnsProductFamilyGrid_GivenValidRequestedType()
      {
         // Act
         IActionResult result = await this.controller.GetRollupGrid(this.jobId, this.bidId, "family");

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(this.jobId, this.bidId, RollupType.Family, It.IsAny<bool>()), Times.Once);
      }

      /// <summary>
      /// Verifies product model grid data is called for when requested
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetRollupGrid_ReturnsProductModelGrid_GivenValidRequestedType()
      {
         // Act
         IActionResult result = await this.controller.GetRollupGrid(this.jobId, this.bidId, "model");

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupGrid(this.jobId, this.bidId, RollupType.Model, true), Times.Once);
      }

      /// <summary>
      /// Verify OK response from when inputs are valid, and the edit is successfully applied.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_ValidRequestAndSuccessfulEditApplied_ReturnsOk()
      {
         // Arrange
         string rollupType = "code";
         string rowType = "MainUnitProdCode";
         string rowIdentifier = "something";
         string columnIdentifier = "EnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         this.rollupGridService
            .Setup(x => x.ApplyRollupGridEdit(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<PriceRollupEdit>(), It.IsAny<List<string>>()))
            .Returns(Task.FromResult(true));

         this.rollupHistoryService
            .Setup(x => x.AppendEdit(this.jobId, this.bidId, It.IsAny<PriceRollupEdit>()))
            .Returns(Task.FromResult(true));

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, this.bidId, rollupType, rowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(this.jobId, this.bidId), Times.Once);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), RollupType.Code, true), Times.Once);
         this.rollupGridService.Verify(x => x.ApplyRollupGridEdit(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<PriceRollupEdit>(), It.IsAny<List<string>>()), Times.Once);
         this.rollupHistoryService.Verify(x => x.AppendEdit(this.jobId, this.bidId, It.IsAny<PriceRollupEdit>()), Times.Once);
      }

      /// <summary>
      /// Verify the row ID handle the null case when being decoded during an edit
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_GivenNullRowIdentifier_UsesNullInsteadOfString()
      {
         // Arrange
         string rollupType = "code";
         string rowType = "MainUnitProdCode";
         string rowIdentifier = "null"; // this seems to be what happens when null is pulled out of a url
         string columnIdentifier = "EnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         PriceRollupEdit theEditCreated = null;

         this.rollupGridService
            .Setup(x => x.ApplyRollupGridEdit(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<PriceRollupEdit>(), It.IsAny<List<string>>()))
            .Callback<int, int, PriceRollupBaseDataViewModel, PriceRollupEdit, List<string>>((job, bid, data, edit, errors) =>
            {
               theEditCreated = edit;
            })
            .Returns(Task.FromResult(true));

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, this.bidId, rollupType, rowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.Null(theEditCreated.RollupRowIdentifier);
      }

      /// <summary>
      /// Verify Conflict response from when inputs are valid, but the edit could not be applied.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_ValidRequestButFailedEdit_ReturnsConflictWithErrorMessages()
      {
         // Arrange
         string rollupType = "code";
         string rowType = "MainUnitProdCode";
         string rowIdentifier = "something";
         string columnIdentifier = "EnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         string errorFromApliedEdit = "sorry, folks the park is closed";
         this.rollupGridService
            .Setup(x => x.ApplyRollupGridEdit(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<PriceRollupEdit>(), It.IsAny<List<string>>()))
            .Returns(Task.FromResult(false))
            .Callback<int, int, PriceRollupBaseDataViewModel, PriceRollupEdit, List<string>>((jobIdParam, bidIdParam, baseDataParam, priceRollupEditParam, responseErrors) => responseErrors.Add(errorFromApliedEdit));

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, this.bidId, rollupType, rowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.NotNull(result);
         Assert.Equal((int)HttpStatusCode.Conflict, ((ConflictObjectResult)result).StatusCode);
         JsonErrorResponse jsonErrorResponse = ((ConflictObjectResult)result).Value as JsonErrorResponse;
         Assert.NotNull(jsonErrorResponse);
         Assert.Single(jsonErrorResponse.Messages);
         Assert.Equal(errorFromApliedEdit, jsonErrorResponse.Messages.First());
         this.rollupGridService.Verify(x => x.GetRollupBaseData(this.jobId, this.bidId), Times.Once);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), RollupType.Code, It.IsAny<bool>()), Times.Never);
         this.rollupGridService.Verify(x => x.ApplyRollupGridEdit(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<PriceRollupEdit>(), It.IsAny<List<string>>()), Times.Once);
      }

      /// <summary>
      /// Verify BadRequest response from when JobId is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         string rollupType = "code";
         string rowType = "MainUnitProdCode";
         string rowIdentifier = "something";
         string columnIdentifier = "EnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         // Act
         IActionResult result = await this.controller.ApplyEdit(invalidJobId, this.bidId, rollupType, rowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response from  when BidId is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_InvalidBidId_ReturnsBadRequest()
      {
         // Arrange
         int invalidBidId = 0;
         string rollupType = "code";
         string rowType = "MainUnitProdCode";
         string rowIdentifier = "something";
         string columnIdentifier = "EnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, invalidBidId, rollupType, rowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response when requested rollup type is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_ReturnsBadRequest_GivenInvalidRollupType()
      {
         // Arrange
         string invalidRollupType = "brett";
         string rowType = "MainUnitProdCode";
         string rowIdentifier = "something";
         string columnIdentifier = "EnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, this.bidId, invalidRollupType, rowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response when requested row type is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_ReturnsBadRequest_GivenInvalidRowType()
      {
         // Arrange
         string rollupType = "code";
         string invalidRowType = "zzz";
         string rowIdentifier = "something";
         string columnIdentifier = "EnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, this.bidId, rollupType, invalidRowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response when requested column identifier is invalid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_ReturnsBadRequest_GivenInvalidColumnIdentifier()
      {
         // Arrange
         string rollupType = "code";
         string rowType = "MainUnitProdCode";
         string rowIdentifier = "something";
         string invalidColumnIdentifier = "DookyEnteredDollars";
         decimal oldValue = 100m;
         decimal newValue = 200m;

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, this.bidId, rollupType, rowType, rowIdentifier, invalidColumnIdentifier, oldValue, newValue);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response when requested row type and column identifier combination is not valid.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task ApplyEdit_ReturnsBadRequest_GivenInvalidRowAndColumnCombination()
      {
         // Arrange
         string rollupType = "code";
         string rowType = "GrandTotal";
         string rowIdentifier = "something";
         string columnIdentifier = "EnteredMultiplier";  // only dollars can be edited on GrandTotal row
         decimal oldValue = 100m;
         decimal newValue = 200m;

         // Act
         IActionResult result = await this.controller.ApplyEdit(this.jobId, this.bidId, rollupType, rowType, rowIdentifier, columnIdentifier, oldValue, newValue);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify OK response from when inputs are valid, and the multipliers are successfully copied.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task CopyMultipliers_ValidRequestAndSuccessfulCopy_ReturnsOk()
      {
         // Arrange
         string rollupType = "code";
         string multiplierSource = "PricingPolicy";
         List<CopiedMultiplier> copiedMultipliers = new List<CopiedMultiplier>()
         {
            new CopiedMultiplier() { DestinationEditableColumnType = EditableColumnType.EnteredMultiplier, SelectedPricingParmId = 100 },
            new CopiedMultiplier() { DestinationEditableColumnType = EditableColumnType.EnteredCPLPAF, SelectedPricingParmId = 101 },
            new CopiedMultiplier() { DestinationEditableColumnType = EditableColumnType.VariationMarkup, VariationId = 200 },
         };

         this.rollupGridService
            .Setup(x => x.CopyMultipliers(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<CopyMultiplierSource>(), It.IsAny<List<CopiedMultiplier>>(), It.IsAny<List<string>>()))
            .Returns(Task.FromResult(true))
            .Callback<int, int, PriceRollupBaseDataViewModel, CopyMultiplierSource, List<CopiedMultiplier>, List<string>>((jobIdParam, bidIdParam, baseDataParam, copyMultiplierSourceParam, copiedMultipliersParam, responseErrorsParam) => copiedMultipliersParam.AddRange(copiedMultipliers));

         this.rollupHistoryService
            .Setup(x => x.AppendEdit(this.jobId, this.bidId, It.IsAny<PriceRollupEdit>()))
            .Returns(Task.FromResult(true));

         // Act
         IActionResult result = await this.controller.CopyMultipliers(this.jobId, this.bidId, rollupType, multiplierSource);

         // Assert
         Assert.IsType<OkObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(this.jobId, this.bidId), Times.Once);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), RollupType.Code, true), Times.Once);
         this.rollupGridService.Verify(x => x.CopyMultipliers(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<CopyMultiplierSource>(), It.IsAny<List<CopiedMultiplier>>(), It.IsAny<List<string>>()), Times.Once);
         this.rollupHistoryService.Verify(x => x.AppendEdit(this.jobId, this.bidId, It.Is<PriceRollupEdit>(pre => pre.RollupRowType == RollupRowType.SelectedPricingParm)), Times.Exactly(2));
         this.rollupHistoryService.Verify(x => x.AppendEdit(this.jobId, this.bidId, It.Is<PriceRollupEdit>(pre => pre.RollupRowType == RollupRowType.Variation)), Times.Once());
      }

      /// <summary>
      /// Verify Conflict response from when inputs are valid, but the multipliers could not be copied.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task CopyMultipliers_ValidRequestButFailedCopy_ReturnsConflictWithErrorMessages()
      {
         // Arrange
         string rollupType = "code";
         string multiplierSource = "Authorized";

         string errorFromCopyAttempt = "sorry, folks the park is closed";
         this.rollupGridService
            .Setup(x => x.CopyMultipliers(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<CopyMultiplierSource>(), It.IsAny<List<CopiedMultiplier>>(), It.IsAny<List<string>>()))
            .Returns(Task.FromResult(false))
            .Callback<int, int, PriceRollupBaseDataViewModel, CopyMultiplierSource, List<CopiedMultiplier>, List<string>>((jobIdParam, bidIdParam, baseDataParam, copyMultiplierSourceParam, copiedMultipliersParam, responseErrorsParam) => responseErrorsParam.Add(errorFromCopyAttempt));

         // Act
         IActionResult result = await this.controller.CopyMultipliers(this.jobId, this.bidId, rollupType, multiplierSource);

         // Assert
         Assert.NotNull(result);
         Assert.Equal((int)HttpStatusCode.Conflict, ((ConflictObjectResult)result).StatusCode);
         JsonErrorResponse jsonErrorResponse = ((ConflictObjectResult)result).Value as JsonErrorResponse;
         Assert.NotNull(jsonErrorResponse);
         Assert.Single(jsonErrorResponse.Messages);
         Assert.Equal(errorFromCopyAttempt, jsonErrorResponse.Messages.First());
         this.rollupGridService.Verify(x => x.GetRollupBaseData(this.jobId, this.bidId), Times.Once);
         this.rollupGridService.Verify(x => x.CopyMultipliers(this.jobId, this.bidId, It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<CopyMultiplierSource>(), It.IsAny<List<CopiedMultiplier>>(), It.IsAny<List<string>>()), Times.Once);
         this.rollupHistoryService.Verify(x => x.AppendEdit(this.jobId, this.bidId, It.IsAny<PriceRollupEdit>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), RollupType.Code, It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response from when JobId is invalid, when copying multipliers.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task CopyMultipliers_InvalidJobId_ReturnsBadRequest()
      {
         // Arrange
         int invalidJobId = 0;
         string rollupType = "code";
         string multiplierSource = "Authorized";

         // Act
         IActionResult result = await this.controller.CopyMultipliers(invalidJobId, this.bidId, rollupType, multiplierSource);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response from  when BidId is invalid, when copying multipliers.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task CopyMultipliers_InvalidBidId_ReturnsBadRequest()
      {
         // Arrange
         int invalidBidId = 0;
         string rollupType = "code";
         string multiplierSource = "Authorized";

         // Act
         IActionResult result = await this.controller.CopyMultipliers(this.jobId, invalidBidId, rollupType, multiplierSource);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response when requested rollup type is invalid, when copying multipliers.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task CopyMultipliers_ReturnsBadRequest_GivenInvalidRollupType()
      {
         // Arrange
         string invalidRollupType = "brett";
         string multiplierSource = "Authorized";

         // Act
         IActionResult result = await this.controller.CopyMultipliers(this.jobId, this.bidId, invalidRollupType, multiplierSource);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }

      /// <summary>
      /// Verify BadRequest response when requested multiplier source is invalid when copying multipliers.
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task CopyMultipliers_ReturnsBadRequest_GivenInvalidMultiplierSource()
      {
         // Arrange
         string rollupType = "code";
         string invalidMultiplierSource = "binky";

         // Act
         IActionResult result = await this.controller.CopyMultipliers(this.jobId, this.bidId, rollupType, invalidMultiplierSource);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
         this.rollupGridService.Verify(x => x.GetRollupBaseData(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
         this.rollupGridService.Verify(x => x.GetRollupGrid(It.IsAny<PriceRollupBaseDataViewModel>(), It.IsAny<RollupType>(), It.IsAny<bool>()), Times.Never);
      }
   }
}
