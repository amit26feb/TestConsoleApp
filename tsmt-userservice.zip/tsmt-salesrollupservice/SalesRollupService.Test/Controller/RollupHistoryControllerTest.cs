﻿namespace SalesRollupService.Test.Controller
{
   using System.Threading.Tasks;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using SalesRollupService.Controllers;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public class RollupHistoryControllerTest
   {
      private readonly RollupHistoryController controller;
      private readonly Mock<IRollupHistoryService> mockHistoryService;

      public RollupHistoryControllerTest()
      {
         this.mockHistoryService = new Mock<IRollupHistoryService>();

         Mock<ILogger<RollupHistoryController>> logger = new Mock<ILogger<RollupHistoryController>>();
         this.controller = new RollupHistoryController(logger.Object, this.mockHistoryService.Object);
      }

      [Fact]
      public async Task GetHistory_GivenValidRequest_ReturnsOKResponse()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;

         // Act
         IActionResult result = await this.controller.GetHistory(jobId, bidId);

         // Assert
         Assert.IsType<OkObjectResult>(result);
      }

      [Fact]
      public async Task GetHistory_GivenValidRequest_CallsServiceOnce()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;

         // Act
         IActionResult result = await this.controller.GetHistory(jobId, bidId);

         // Assert
         this.mockHistoryService.Verify(x => x.GetHistory(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
      }

      [Fact]
      public async Task GetHistory_GivenInvalidJobId_ReturnsBadResponse()
      {
         // Arrange
         int jobId = -1;
         int bidId = 456;

         // Act
         IActionResult result = await this.controller.GetHistory(jobId, bidId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task GetHistory_GivenInvalidBidId_ReturnsBadResponse()
      {
         // Arrange
         int jobId = 123;
         int bidId = -1;

         // Act
         IActionResult result = await this.controller.GetHistory(jobId, bidId);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task RewindHistory_GivenValidRequest_ReturnsOKResponse()
      {
         // Arrange
         var request = new RewindHistoryRequestViewModel
         {
            JobId = 123,
            BidId = 234,
            Edit = new PriceRollupEdit(),
         };

         var serviceResult = new RewindHistoryResultViewModel
         {
            Rollup = new PriceRollupCalculationEngine.ViewModels.RollupViewModel()
         };
         this.mockHistoryService.Setup(x => x.RewindHistory(request))
            .Returns(Task.FromResult(serviceResult));

         // Act
         IActionResult result = await this.controller.RewindHistory(request);

         // Assert
         Assert.IsType<OkObjectResult>(result);
      }

      [Fact]
      public async Task RewindHistory_GivenValidRequest_CallsServiceOnce()
      {
         // Arrange
         var request = new RewindHistoryRequestViewModel
         {
            JobId = 123,
            BidId = 234,
            Edit = new PriceRollupEdit(),
         };

         var serviceResult = new RewindHistoryResultViewModel
         {
            Rollup = new PriceRollupCalculationEngine.ViewModels.RollupViewModel()
         };
         this.mockHistoryService.Setup(x => x.RewindHistory(request))
            .Returns(Task.FromResult(serviceResult));

         // Act
         IActionResult result = await this.controller.RewindHistory(request);

         // Assert
         this.mockHistoryService.Verify(x => x.RewindHistory(request), Times.Once);
      }

      [Fact]
      public async Task RewindHistory_GivenNullRequest_ReturnsBadRequestResponse()
      {
         // Arrange
         var request = default(RewindHistoryRequestViewModel);

         // Act
         IActionResult result = await this.controller.RewindHistory(request);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task RewindHistory_GivenInvalidRequest_ReturnsBadRequestResponse()
      {
         // Arrange
         var request = new RewindHistoryRequestViewModel
         {
            JobId = 0,
         };

         // Act
         IActionResult result = await this.controller.RewindHistory(request);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      [Fact]
      public async Task RewindHistory_GivenInvalidRequest_CallsServiceNever()
      {
         // Arrange
         var request = new RewindHistoryRequestViewModel
         {
            JobId = 0,
         };

         // Act
         IActionResult result = await this.controller.RewindHistory(request);

         // Assert
         this.mockHistoryService.Verify(x => x.RewindHistory(request), Times.Never);
      }

      [Fact]
      public async Task RewindHistory_GivenUnsuccessfulResult_ReturnsConflictResponse()
      {
         // Arrange
         var rewindRequest = new RewindHistoryRequestViewModel
         {
            JobId = 123,
            BidId = 234,
            Edit = new PriceRollupEdit(),
            RollupType = RollupType.Code
         };

         var rewindResult = new RewindHistoryResultViewModel
         {
            Errors = new[] { "Error..." }
         };

         this.mockHistoryService.Setup(x => x.RewindHistory(rewindRequest))
            .Returns(Task.FromResult(rewindResult));

         // Act
         IActionResult result = await this.controller.RewindHistory(rewindRequest);

         // Assert
         Assert.IsType<ConflictObjectResult>(result);
      }
   }
}