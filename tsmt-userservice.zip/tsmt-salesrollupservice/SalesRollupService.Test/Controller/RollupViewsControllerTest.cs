﻿// <copyright file="RollupViewsControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Controller
{
   using System.Threading.Tasks;
   using Microsoft.AspNetCore.Mvc;
   using Microsoft.Extensions.Logging;
   using Moq;
   using SalesRollupService.Controllers;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using Xunit;

   public class RollupViewsControllerTest
   {
      private readonly RollupViewsController controller;
      private readonly Mock<IRollupViewService> viewService;

      /// <summary>
      ///  Initializes a new instance of the <see cref="RollupViewsControllerTest"/> class.
      /// </summary>
      public RollupViewsControllerTest()
      {
         this.viewService = new Mock<IRollupViewService>();

         Mock<ILogger<RollupViewsController>> logger = new Mock<ILogger<RollupViewsController>>();
         this.controller = new RollupViewsController(logger.Object, this.viewService.Object);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task PutViews_GivenValidViews_ReturnGoodResponse()
      {
         // Arrange
         var views = new[] { new RollupViewViewModel() };

         // Act
         IActionResult result = await this.controller.PutViews(views);

         // Assert
         Assert.IsType<OkResult>(result);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task PutViews_GivenNullViews_ReturnsBadResponse()
      {
         // Arrange
         RollupViewViewModel[] views = null;

         // Act
         IActionResult result = await this.controller.PutViews(views);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task PutViews_GivenValidViews_CallsServiceOnce()
      {
         // Arrange
         var views = new[] { new RollupViewViewModel() };

         // Act
         IActionResult result = await this.controller.PutViews(views);

         // Assert
         this.viewService.Verify(x => x.PutViews(views), Times.Once);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetViews_ReturnGoodResponse()
      {
         // Act
         IActionResult result = await this.controller.GetViews();

         // Assert
         Assert.IsType<OkObjectResult>(result);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetViews_CallsServiceOnce()
      {
         // Act
         IActionResult result = await this.controller.GetViews();

         // Assert
         this.viewService.Verify(x => x.GetViews(), Times.Once);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetUserViews_GivenValidUsername_ReturnGoodResponse()
      {
         // Arrange
         string userName = "irbrfr";

         // Act
         IActionResult result = await this.controller.GetUserViews(userName);

         // Assert
         Assert.IsType<OkObjectResult>(result);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetUserViews_GivenInvalidUsername_ReturnsBadResponse()
      {
         // Arrange
         string userName = null;

         // Act
         IActionResult result = await this.controller.GetUserViews(userName);

         // Assert
         Assert.IsType<BadRequestObjectResult>(result);
      }

      /// <summary>
      /// Tests the response for a request
      /// </summary>
      /// <returns>A task</returns>
      [Fact]
      public async Task GetUserViews_GivenValidUsername_CallsServiceOnce()
      {
         // Arrange
         string userName = "irbrfr";

         // Act
         IActionResult result = await this.controller.GetUserViews(userName);

         // Assert
         this.viewService.Verify(x => x.GetUserViews(It.IsAny<string>()), Times.Once);
      }
   }
}