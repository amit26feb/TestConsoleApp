﻿// <copyright file="RollupEnumsControllerTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Controller
{
   using Microsoft.AspNetCore.Mvc;
   using Moq;
   using SalesRollupService.Controllers;
   using SalesRollupService.Core.Services;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public class RollupEnumsControllerTest
   {
      private readonly RollupEnumsController controller;
      private readonly Mock<IRollupEnumService> mockRollupEnumService;

      public RollupEnumsControllerTest()
      {
         this.mockRollupEnumService = new Mock<IRollupEnumService>();

         this.controller = new RollupEnumsController(this.mockRollupEnumService.Object);
      }

      [Fact]
      public void GetRollupColumnTypes_ReturnsEnumTuples()
      {
         // Act
         IActionResult result = this.controller.GetRollupColumnTypes();

         // Assert
         this.mockRollupEnumService.Verify(x => x.CreateEnumTuples(typeof(RollupColumnType)), Times.Once);
         Assert.IsType<OkObjectResult>(result);
      }
   }
}