﻿// <copyright file="DiscountImportRepositoryTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Repository
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using Moq;
   using SalesRollupService.Common;
   using SalesRollupService.Core.Models;
   using SalesRollupService.Core.Repository;
   using TSMT.DataAccess;
   using Xunit;

   public class DiscountImportRepositoryTest
   {
      private readonly Mock<IRepository<IDataEntity>> mockInteralRepo;
      private readonly DiscountImportRepository respositoryUnderTest;

      private readonly int jobId = 100;
      private readonly int bidId = 12345;

      public DiscountImportRepositoryTest()
      {
         this.mockInteralRepo = new Mock<IRepository<IDataEntity>>();
         this.respositoryUnderTest = new DiscountImportRepository(this.mockInteralRepo.Object);
      }

      [Fact]
      public void HonorDrAddress_OnCall_SetsDrAddress()
      {
         // Arrange
         int drAddressId = 78;
         this.mockInteralRepo.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));

         // Act
         this.respositoryUnderTest.HonorDrAddressId(drAddressId);

         // Assert
         this.mockInteralRepo.Verify(x => x.HonorDrAddressId(drAddressId), Times.Once);
      }

      [Fact]
      public async Task GetBids_HasData_ReturnsIt()
      {
         // Arrange
         IEnumerable<Bid> bids = new List<Bid>() { new Bid() };
         this.mockInteralRepo.Setup(x => x.ExecuteListQuery<Bid>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(bids));

         // Act
         IEnumerable<Bid> results = await this.respositoryUnderTest.GetBids(this.jobId);

         // Assert
         Assert.Equal(results, bids);
         this.mockInteralRepo.Verify(x => x.ExecuteListQuery<Bid>(DiscountImportRepositoryQueries.BidAlternatesByJobId, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task GetCurrentBid_NoData_ReturnsNull()
      {
         // Arrange
         Mock<DiscountImportRepository> mockRepo = new Mock<DiscountImportRepository>(this.mockInteralRepo.Object) { CallBase = true };
         mockRepo.Setup(x => x.GetBids(It.IsAny<int>()))
            .Returns(Task.FromResult<IEnumerable<Bid>>(null));

         // Act
         Bid result = await mockRepo.Object.GetCurrentBid(this.jobId);

         // Assert
         Assert.Null(result);

         mockRepo.Verify(m => m.GetBids(this.jobId), Times.Once);
      }

      [Fact]
      public async Task GetCurrentBid_HasCurrentBid_ReturnsIt()
      {
         // Arrange
         IEnumerable<Bid> bids = new List<Bid>()
         {
            new Bid() { BidAlternateId = 1, CurrentBidInd = "N" },
            new Bid() { BidAlternateId = 2, CurrentBidInd = "Y" },
         };
         Mock<DiscountImportRepository> mockRepo = new Mock<DiscountImportRepository>(this.mockInteralRepo.Object) { CallBase = true };
         mockRepo.Setup(x => x.GetBids(It.IsAny<int>()))
            .Returns(Task.FromResult<IEnumerable<Bid>>(bids));

         // Act
         Bid result = await mockRepo.Object.GetCurrentBid(this.jobId);

         // Assert
         Assert.Equal(result, bids.Single(x => x.BidAlternateId == 2));
         mockRepo.Verify(m => m.GetBids(this.jobId), Times.Once);
      }

      [Fact]
      public async Task GetCurrentBid_HasBaseBid_ReturnsIt()
      {
         // Arrange
         IEnumerable<Bid> bids = new List<Bid>()
         {
            new Bid() { BidAlternateId = 1, CurrentBidInd = "N" },
            new Bid() { BidAlternateId = 2 },
            new Bid() { BidAlternateId = 3, BaseBidYesNo = 1 },
         };
         Mock<DiscountImportRepository> mockRepo = new Mock<DiscountImportRepository>(this.mockInteralRepo.Object) { CallBase = true };
         mockRepo.Setup(x => x.GetBids(It.IsAny<int>()))
            .Returns(Task.FromResult<IEnumerable<Bid>>(bids));

         // Act
         Bid result = await mockRepo.Object.GetCurrentBid(this.jobId);

         // Assert
         Assert.Equal(result, bids.Single(x => x.BidAlternateId == 3));
         mockRepo.Verify(m => m.GetBids(this.jobId), Times.Once);
      }

      [Fact]
      public async Task GetCurrentBid_NoMarkedBids_ReturnsNull()
      {
         // Arrange
         IEnumerable<Bid> bids = new List<Bid>()
         {
            new Bid() { BidAlternateId = 1, CurrentBidInd = "N" },
            new Bid() { BidAlternateId = 2 },
            new Bid() { BidAlternateId = 3, BaseBidYesNo = 0 },
         };
         Mock<DiscountImportRepository> mockRepo = new Mock<DiscountImportRepository>(this.mockInteralRepo.Object) { CallBase = true };
         mockRepo.CallBase = true;
         mockRepo.Setup(x => x.GetBids(It.IsAny<int>()))
            .Returns(Task.FromResult<IEnumerable<Bid>>(bids));

         // Act
         Bid result = await mockRepo.Object.GetCurrentBid(this.jobId);

         // Assert
         Assert.Null(result);
         mockRepo.Verify(m => m.GetBids(this.jobId), Times.Once);
      }

      [Fact]
      public async Task GetSelectedPricingParm_HasData_ReturnsIt()
      {
         // Arrange
         IEnumerable<SelectedPricingParm> spps = new List<SelectedPricingParm>() { new SelectedPricingParm() };
         this.mockInteralRepo.Setup(x => x.ExecuteListQuery<SelectedPricingParm>(It.IsAny<string>(), It.IsAny<object>()))
            .Returns(Task.FromResult(spps));

         // Act
         IEnumerable<SelectedPricingParm> results = await this.respositoryUnderTest.GetSelectedPricingParms(this.bidId);

         // Assert
         Assert.Equal(results, spps);
         this.mockInteralRepo.Verify(x => x.ExecuteListQuery<SelectedPricingParm>(DiscountImportRepositoryQueries.SelectedPriceParamsUsingBidId, It.IsAny<object>()), Times.Once);
      }

      [Fact]
      public async Task UpdateSelectedPricingParm_GivenData_Executes()
      {
         // Arrange
         SelectedPricingParm spp = new SelectedPricingParm();
         this.mockInteralRepo.Setup(x => x.ExecuteAsync<SelectedPricingParm>(It.IsAny<string>(), It.IsAny<object>()));

         // Act
         await this.respositoryUnderTest.UpdateSelectedPricingParm(spp);

         // Assert
         this.mockInteralRepo.Verify(x => x.ExecuteAsync<int>(DiscountImportRepositoryQueries.ApplySelectedPricingParmDiscount, It.IsAny<object>()), Times.Once);
      }
   }
}
