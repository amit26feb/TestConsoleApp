﻿// <copyright file="RollupViewServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using Moq;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDataAccess.Models;
   using TSMT.RollupDataAccess.Repositories;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public enum RollupEnumServiceTestEnum
   {
      A, B
   }

   public class RollupEnumServiceTest
   {
      private readonly RollupEnumService serviceUnderTest;

      public RollupEnumServiceTest()
      {
         this.serviceUnderTest = new RollupEnumService();
      }

      [Fact]
      public void CreateEnumTuples_ReturnsTupleCollection()
      {
         Tuple<int, string>[] result = this.serviceUnderTest.CreateEnumTuples(typeof(RollupEnumServiceTestEnum));

         Assert.Equal(Tuple.Create(0, "A"), result.First());
         Assert.Equal(Tuple.Create(1, "B"), result.Last());
      }
   }
}