﻿namespace SalesRollupService.Test.Core.Services
{
   using System;
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using Microsoft.AspNetCore.Http;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using PriceRollupCalculationEngine.CalculationEngine;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.ServiceApis;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using SalesRollupService.Test.Common;
   using TSMT.RollupDataAccess.Repositories;
   using TSMT.RollupDataAccess.Services;
   using TSMT.RollupDomain.Models;
   using Xunit;
   using DAModels = TSMT.RollupDataAccess.Models;
   using DAViewModels = TSMT.RollupDataAccess.ViewModels;
   using ENGModels = PriceRollupCalculationEngine.Models;
   using ENGViewModels = PriceRollupCalculationEngine.ViewModels;

   public class RollupHistoryServiceTest
   {
      private readonly RollupHistoryService serviceUnderTest;

      private readonly Mock<ILogger<RollupHistoryService>> mockLogger;
      private readonly IMapper mapper;
      private readonly Mock<IHttpContextAccessor> mockHttpContextAccessor;
      private readonly Mock<IReadRollupDataService> mockReadRollupDataService;
      private readonly Mock<IWriteRollupDataService> mockWriteRollupDataService;
      private readonly Mock<IRollupGridService> mockRollupGridService;
      private readonly Mock<IRollupHistoryRepository> mockHistoryRepository;
      private readonly Mock<IRollupHistoryRewinder> mockHistoryRewinder;
      private readonly Mock<IRollupRepository> mockRollupRepository;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettingsMock;

      private readonly int arrangedJobId;
      private readonly int arrangedBidId;
      private readonly RollupConsumer arrangedConsumer;
      private readonly RewindHistoryRequestViewModel arrangedRewindHistoryRequest;
      private readonly RollupType arrangedRollupType;
      private readonly PriceRollupHistory arrangedHistory;
      private readonly PriceRollupEdit arrangedEdit;
      private readonly IList<Guid> arrangedEditIds;
      private readonly ENGModels.HistoryRewinderResponse arrangedRewinderResponse;

      public RollupHistoryServiceTest()
      {
         // Create object to test
         this.mockLogger = new Mock<ILogger<RollupHistoryService>>();

         this.mapper = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<SalesRollupService.Configurations.AutoMapperConfiguration.AutoMapperProfile>();
         }).CreateMapper();

         var configuration = new CommonConfigurationSettings()
         {
            IsStageOrProdEnvironment = false,
         };
         this.commonConfigurationSettingsMock = Options.Create<CommonConfigurationSettings>(configuration);

         this.mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
         this.mockHistoryRepository = new Mock<IRollupHistoryRepository>();
         this.mockReadRollupDataService = new Mock<IReadRollupDataService>();
         this.mockWriteRollupDataService = new Mock<IWriteRollupDataService>();
         this.mockRollupGridService = new Mock<IRollupGridService>();
         this.mockHistoryRewinder = new Mock<IRollupHistoryRewinder>();
         this.mockRollupRepository = new Mock<IRollupRepository>();

         this.serviceUnderTest = new RollupHistoryService(
            this.mockLogger.Object,
            this.mapper,
            this.mockHttpContextAccessor.Object,
            this.mockReadRollupDataService.Object,
            this.mockWriteRollupDataService.Object,
            this.mockRollupGridService.Object,
            this.mockHistoryRepository.Object,
            this.mockHistoryRewinder.Object,
            this.mockRollupRepository.Object,
            this.commonConfigurationSettingsMock);

         // Arrange base testing context
         this.arrangedJobId = 123;
         this.arrangedBidId = 234;
         this.arrangedConsumer = RollupConsumer.SalesOffice;
         var arrangedBaseData = new DAViewModels.PriceRollupBaseDataViewModel();
         this.arrangedEdit = new PriceRollupEdit { Guid = Guid.NewGuid() };
         this.arrangedHistory = new PriceRollupHistory { JobId = this.arrangedJobId, BidId = this.arrangedBidId, Edits = new[] { this.arrangedEdit } };
         var arrangedRewinderWrites = new List<ENGModels.WriteRollupDataStatement>();
         this.arrangedEditIds = new List<Guid>();
         this.arrangedRewinderResponse = new ENGModels.HistoryRewinderResponse(arrangedRewinderWrites, this.arrangedEditIds);
         this.arrangedRollupType = RollupType.Code;
         var arrangedRollup = new ENGViewModels.RollupViewModel();
         this.arrangedRewindHistoryRequest = new RewindHistoryRequestViewModel { JobId = this.arrangedJobId, BidId = this.arrangedBidId, Edit = this.arrangedEdit, RollupType = this.arrangedRollupType };

         this.mockReadRollupDataService
            .Setup(x => x.GetPriceRollupData(this.arrangedJobId, this.arrangedBidId, this.arrangedConsumer))
            .Returns(Task.FromResult(arrangedBaseData));

         this.mockHistoryRepository
            .Setup(x => x.GetHistory(this.arrangedJobId, this.arrangedBidId))
            .Returns(Task.FromResult(this.arrangedHistory));

         this.mockHistoryRewinder
            .Setup(x => x.RewindToEdit(It.IsAny<ENGViewModels.PriceRollupBaseDataViewModel>(), this.arrangedHistory, this.arrangedEdit))
            .Returns(this.arrangedRewinderResponse);

         this.mockWriteRollupDataService
            .Setup(x => x.TransactStatements(It.IsAny<IEnumerable<DAModels.WriteRollupDataStatement>>()))
            .Returns(Task.FromResult(true));

         this.mockHistoryRepository
            .Setup(x => x.RemoveEdits(this.arrangedJobId, this.arrangedBidId, this.arrangedEditIds))
            .Returns(Task.FromResult(true));

         this.mockRollupGridService
            .Setup(x => x.GetRollupGrid(It.IsAny<ENGViewModels.PriceRollupBaseDataViewModel>(), this.arrangedRollupType, It.IsAny<bool>()))
            .Returns(Task.FromResult(arrangedRollup));

         this.mockRollupRepository
            .Setup(x => x.GetSelectionIdentifiers(It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(Helper.GetSelectionIdentifiers()));

         this.mockRollupRepository
            .Setup(x => x.GetProductFamilies(It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(Helper.GetProductFamilies()));

         this.mockRollupRepository
            .Setup(x => x.GetVariationIdentifiers(It.IsAny<IEnumerable<int>>()))
            .Returns(Task.FromResult(Helper.GetVariationIdentifiers()));

         this.mockRollupRepository
            .Setup(x => x.GetProductCodesAndDescriptions(It.IsAny<IEnumerable<string>>()))
            .Returns(Task.FromResult(Helper.GetProductCodes()));
      }

      [Fact]
      public async Task GetHistory_GivenValidArguments_CorrectlyCallsRepository()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;

         this.mockHistoryRepository.Setup(x => x.GetHistory(jobId, bidId))
            .Returns(Task.FromResult(default(PriceRollupHistory)));

         // Act
         var result = await this.serviceUnderTest.GetHistory(jobId, bidId);

         // Assert
         this.mockHistoryRepository.Verify(x => x.GetHistory(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
      }

      [Fact]
      public async Task GetHistory_RepoException_ReturnsNull()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;

         this.mockHistoryRepository.Setup(x => x.GetHistory(jobId, bidId))
            .Throws(new Exception());

         // Act
         PriceRollupHistory result = await this.serviceUnderTest.GetHistory(jobId, bidId);

         // Assert
         Assert.Null(result);
      }

      [Fact]
      public async Task GetHistory_GivenValidArguments_ReturnsHistoryWithDescription()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;

         PriceRollupHistory priceRollupHistorymock = Helper.GetPriceRollupHistory();

         this.mockHistoryRepository.Setup(x => x.GetHistory(jobId, bidId))
            .Returns(Task.FromResult(priceRollupHistorymock));

         // Act
         PriceRollupHistory priceRollupHistory = await this.serviceUnderTest.GetHistory(jobId, bidId);

         // Assert
         Assert.NotNull(priceRollupHistory);
         this.mockHistoryRepository.Verify(x => x.GetHistory(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
         this.mockRollupRepository.Verify(x => x.GetSelectionIdentifiers(It.IsAny<IEnumerable<int>>()), Times.Once);
         this.mockRollupRepository.Verify(x => x.GetProductFamilies(It.IsAny<IEnumerable<int>>()), Times.Once);
         this.mockRollupRepository.Verify(x => x.GetVariationIdentifiers(It.IsAny<IEnumerable<int>>()), Times.Once);
         this.mockRollupRepository.Verify(x => x.GetProductCodesAndDescriptions(It.IsAny<IEnumerable<string>>()), Times.Once);
         Assert.Equal("<120 test>Selection", priceRollupHistory.Edits.Where(x => x.RollupRowType == RollupRowType.Selection).Select(x => x.Description).FirstOrDefault());
         Assert.Equal("ProdFamily", priceRollupHistory.Edits.Where(x => x.RollupRowType == RollupRowType.ProductFamily).Select(x => x.Description).FirstOrDefault());
         Assert.Equal("Variation", priceRollupHistory.Edits.Where(x => x.RollupRowType == RollupRowType.JobVariationProdCode).Select(x => x.Description).FirstOrDefault());
         Assert.Equal("ProdCodes", priceRollupHistory.Edits.Where(x => x.RollupRowType == RollupRowType.MainUnitProdCode).Select(x => x.Description).FirstOrDefault());
         Assert.Equal("Total", priceRollupHistory.Edits.Where(x => x.RollupRowType == RollupRowType.Total).Select(x => x.Description).FirstOrDefault());
         Assert.Equal("GrandTotal", priceRollupHistory.Edits.Where(x => x.RollupRowType == RollupRowType.GrandTotal).Select(x => x.Description).FirstOrDefault());
      }

      [Fact]
      public async Task AppendEdit_GivenValidArguments_CorrectlyCallsRepository()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;
         PriceRollupEdit edit = new PriceRollupEdit { User = "Brett" };

         this.mockHistoryRepository.Setup(x => x.AppendEdit(jobId, bidId, edit))
            .Returns(Task.FromResult(true));

         // Act
         var result = await this.serviceUnderTest.AppendEdit(jobId, bidId, edit);

         // Assert
         this.mockHistoryRepository.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Once);
      }

      [Fact]
      public async Task AppendEdit_RepoException_ReturnsFalse()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;
         PriceRollupEdit edit = new PriceRollupEdit { User = "Brett" };

         this.mockHistoryRepository.Setup(x => x.AppendEdit(jobId, bidId, edit))
            .Throws(new Exception());

         // Act
         bool result = await this.serviceUnderTest.AppendEdit(jobId, bidId, edit);

         // Assert
         Assert.False(result);
      }

      [Fact]
      public async Task RemoveEdits_GivenValidArguments_CorrectlyCallsRepository()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;
         var editIds = new List<Guid> { };

         this.mockHistoryRepository.Setup(x => x.RemoveEdits(jobId, bidId, editIds))
            .Returns(Task.FromResult(true));

         // Act
         var result = await this.serviceUnderTest.RemoveEdits(jobId, bidId, editIds);

         // Assert
         this.mockHistoryRepository.Verify(x => x.RemoveEdits(jobId, bidId, editIds), Times.Once);
      }

      [Fact]
      public async Task RemoveEdits_RepoException_ReturnsFalse()
      {
         // Arrange
         int jobId = 123;
         int bidId = 456;
         var editIds = new List<Guid> { };

         this.mockHistoryRepository.Setup(x => x.RemoveEdits(jobId, bidId, editIds))
            .Throws(new Exception());

         // Act
         bool result = await this.serviceUnderTest.RemoveEdits(jobId, bidId, editIds);

         // Assert
         Assert.False(result);
      }

      [Fact]
      public async Task RewindHistory_GivenValidRequest_CorrectlyCallsDependencies()
      {
         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.True(result.IsSuccessful);
         Assert.NotNull(result.Rollup);

         this.mockReadRollupDataService
            .Verify(x => x.GetPriceRollupData(this.arrangedJobId, this.arrangedBidId, this.arrangedConsumer), Times.Once);

         this.mockHistoryRepository
            .Verify(x => x.GetHistory(this.arrangedJobId, this.arrangedBidId), Times.Once);

         this.mockHistoryRewinder
            .Verify(x => x.RewindToEdit(It.IsAny<ENGViewModels.PriceRollupBaseDataViewModel>(), this.arrangedHistory, this.arrangedEdit), Times.Once);

         this.mockWriteRollupDataService
            .Verify(x => x.TransactStatements(It.IsAny<IEnumerable<DAModels.WriteRollupDataStatement>>()), Times.Once);

         this.mockHistoryRepository
            .Verify(x => x.RemoveEdits(this.arrangedJobId, this.arrangedBidId, this.arrangedEditIds), Times.Once);

         this.mockRollupGridService
            .Verify(x => x.GetRollupGrid(It.IsAny<ENGViewModels.PriceRollupBaseDataViewModel>(), this.arrangedRollupType, It.IsAny<bool>()), Times.Once);
      }

      [Fact]
      public async Task RewindHistory_GivenInvalidRequest_ReturnsError()
      {
         // Arrange
         this.arrangedRewindHistoryRequest.JobId = 0;

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Invalid request. The job ID is invalid", result.Errors.Single());
      }

      [Fact]
      public async Task RewindHistory_GivenNullBaseData_ReturnsError()
      {
         // Arrange
         this.mockReadRollupDataService
            .Setup(x => x.GetPriceRollupData(this.arrangedJobId, this.arrangedBidId, this.arrangedConsumer))
            .Returns(Task.FromResult(default(DAViewModels.PriceRollupBaseDataViewModel)));

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Failure to get base data", result.Errors.Single());
      }

      [Fact]
      public async Task RewindHistory_GivenNullHistory_ReturnsError()
      {
         // Arrange
         this.mockHistoryRepository
            .Setup(x => x.GetHistory(this.arrangedJobId, this.arrangedBidId))
            .Returns(Task.FromResult(default(PriceRollupHistory)));

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Failure to get history", result.Errors.Single());
      }

      [Fact]
      public async Task RewindHistory_GivenRewindFailure_ReturnsError()
      {
         // Arrange
         this.arrangedRewinderResponse.Errors = new[] { "Failure..." };

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Failure rewind to edit", result.Errors.Single());
      }

      [Fact]
      public async Task RewindHistory_GivenSyncDatabaseFailure_ReturnsError()
      {
         // Arrange
         this.mockWriteRollupDataService
            .Setup(x => x.TransactStatements(It.IsAny<IEnumerable<DAModels.WriteRollupDataStatement>>()))
            .Returns(Task.FromResult(false));

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Failure sync database (SPPs and VARIATIONs)", result.Errors.Single());
      }

      [Fact]
      public async Task RewindHistory_GivenSyncHistoryFailure_ReturnsError()
      {
         // Arrange
         this.mockHistoryRepository
            .Setup(x => x.RemoveEdits(this.arrangedJobId, this.arrangedBidId, this.arrangedEditIds))
            .Returns(Task.FromResult(false));

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Failure sync history", result.Errors.Single());
      }

      [Fact]
      public async Task RewindHistory_GivenGetRollupGridFailure_ReturnsError()
      {
         // Arrange
         this.mockRollupGridService
            .Setup(x => x.GetRollupGrid(It.IsAny<ENGViewModels.PriceRollupBaseDataViewModel>(), this.arrangedRollupType, It.IsAny<bool>()))
            .Returns(Task.FromResult(default(ENGViewModels.RollupViewModel)));

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Failure to get rollup grid", result.Errors.Single());
      }

      [Fact]
      public async Task RewindHistory_GivenExceptionForBaseData_ReturnsError()
      {
         // Arrange
         this.mockReadRollupDataService
            .Setup(x => x.GetPriceRollupData(this.arrangedJobId, this.arrangedBidId, this.arrangedConsumer))
            .Throws(new Exception());

         // Act
         var result = await this.serviceUnderTest.RewindHistory(this.arrangedRewindHistoryRequest);

         // Assert
         Assert.Equal("Unhandled exception", result.Errors.Single());
      }
   }
}