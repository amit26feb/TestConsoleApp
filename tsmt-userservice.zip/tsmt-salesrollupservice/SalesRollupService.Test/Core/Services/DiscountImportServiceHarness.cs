﻿// <copyright file="DiscountImportServiceHarness.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System.Threading;
   using System.Threading.Tasks;
   using AWS.MessagingWrapper.Contracts;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.Repository;
   using SalesRollupService.Core.Services;

   /// <summary>
   /// Harness for the Discount Import background service
   /// </summary>
   public class DiscountImportServiceHarness : DiscountImportService
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="DiscountImportServiceHarness"/> class.
      /// </summary>
      /// <param name="log">Logging the information</param>
      /// <param name="messageReceiver">Message receiver</param>
      /// <param name="commonConfigurationSettings">Set configurable values</param>
      /// <param name="repository">discount import repository</param>
      public DiscountImportServiceHarness(
         ILogger<DiscountImportService> log,
         IMessageReceiver messageReceiver,
         IOptions<CommonConfigurationSettings> commonConfigurationSettings,
         IRollupHistoryService historyService,
         IDiscountImportRepository repository)
        : base(log, messageReceiver, commonConfigurationSettings, historyService, repository)
      {
      }

      /// <summary>
      /// Execute async harness
      /// </summary>
      /// <param name="stoppingToken">Cancellation token</param>
      /// <returns>Task representing completion</returns>
      public Task ExecuteAsyncHarness(CancellationToken stoppingToken)
      {
         return this.ExecuteAsync(stoppingToken);
      }
   }
}
