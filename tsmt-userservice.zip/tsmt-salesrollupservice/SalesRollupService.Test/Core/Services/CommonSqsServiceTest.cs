﻿// <copyright file="CommonSqsServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using AWS.MessagingWrapper.Contracts;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.Services;
   using Xunit;

   public class CommonSqsServiceTest
   {
      private readonly CommonSqsService commonSqsService;
      private readonly Mock<ILogger<CommonSqsService>> loggerMock;
      private readonly Mock<IMessageReceiver> messageReceiverMock;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettingsMock;
      private readonly int maxProcessesAllowedCount = 1;

      /// <summary>
      /// Initializes a new instance of the <see cref="CommonSqsServiceTest"/> class.
      /// </summary>
      public CommonSqsServiceTest()
      {
         this.loggerMock = new Mock<ILogger<CommonSqsService>>();
         this.messageReceiverMock = new Mock<IMessageReceiver>();
         var configuration = new CommonConfigurationSettings()
         {
            SqsServiceURLForRollupHistoryService = "http://url1.com",
            QueueWaitTimeForRollupHistory = 5,
            MessageHidingTimeInMinutesForRollupHistory = 5,
         };
         this.commonConfigurationSettingsMock = Options.Create<CommonConfigurationSettings>(configuration);
         this.commonSqsService = new CommonSqsService(this.loggerMock.Object, this.messageReceiverMock.Object);
      }

      [Fact]
      public async Task DeleteMessageAsync_HasValidMessage_DeletesMessageSuccessfully()
      {
         // Arrange
         Message message = new Message
         {
            Body = "{jobId: '1234'}",
         };
         this.messageReceiverMock.Setup(x => x.DeleteMessageAsync(this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService, message.ReceiptHandle)).Returns(Task.FromResult(It.IsAny<string>()));

         // Act
         await this.commonSqsService.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService);

         // Assert
         this.messageReceiverMock.Verify(x => x.DeleteMessageAsync(this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService, message.ReceiptHandle), Times.Once);
      }

      [Fact]
      public void GetSQSMessagesAsync_NoMessagesInSqs_NoMessageRetrieved()
      {
         // Arrange
         IEnumerable<Message> messages = new List<Message>();

         this.messageReceiverMock.SetupSequence(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(messages));

         // Act
         var task = this.commonSqsService.GetSQSMessagesAsync(this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService, this.maxProcessesAllowedCount, this.commonConfigurationSettingsMock.Value.QueueWaitTimeForRollupHistory, this.commonConfigurationSettingsMock.Value.MessageHidingTimeInMinutesForRollupHistory);

         // Assert
         Assert.Empty(task.Result.ToList());
         this.messageReceiverMock.Verify(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.Once);
      }

      [Fact]
      public void GetSQSMessagesAsync_MessagesAvailableInSqs_MessagesRetrievedSuccesfully()
      {
         // Arrange
         IEnumerable<Message> messages = new List<Message>()
             {
                new Message
                {
                    Body = "{jobId: '1234'}"
                }
             };

         this.messageReceiverMock.SetupSequence(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(messages));

         // Act
         var task = this.commonSqsService.GetSQSMessagesAsync(this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService, this.maxProcessesAllowedCount, this.commonConfigurationSettingsMock.Value.QueueWaitTimeForRollupHistory, this.commonConfigurationSettingsMock.Value.MessageHidingTimeInMinutesForRollupHistory);

         // Assert
         Assert.NotEmpty(task.Result.ToList());
         this.messageReceiverMock.Verify(x => x.ReceiveMessageAsync(It.IsAny<string>(), CancellationToken.None, It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.AtLeastOnce);
      }
   }
}
