﻿// <copyright file="RollupGridServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Threading.Tasks;
   using AutoMapper;
   using Microsoft.AspNetCore.Http;
   using Moq;
   using PriceRollupCalculationEngine.CalculationEngine;
   using PriceRollupCalculationEngine.Models;
   using PriceRollupCalculationEngine.ViewModels;
   using SalesRollupService.Core.ServiceApis;
   using SalesRollupService.Core.Services;
   using TSMT.RollupDataAccess.Services;
   using TSMT.RollupDomain.Models;
   using Xunit;
   using RDA = TSMT.RollupDataAccess.ViewModels;

   /// <summary>
   /// RollupGridService Tests
   /// </summary>
   public class RollupGridServiceTest
   {
      private readonly Mock<IRollupBuilder> mockRollupBuilder;
      private readonly Mock<IReadRollupDataService> mockReadRollupDataService;
      private readonly Mock<IWriteRollupDataService> mockWriteRollupDataService;
      private readonly Mock<IRollupCriticalWriteProducer> mockRollupCriticalWriteProducer;
      private readonly Mock<IRollupAncillaryWriteProducer> mockRollupAncillaryWriteProducer;
      private readonly Mock<IHttpContextAccessor> mockHttpContextAccessor;
      private readonly IMapper mapper;
      private readonly Mock<IJobScoringApiClient> mockJobScoringApiClient;
      private readonly SalesRollupService.Core.Models.JobScoring.SalesOfficeScoringData jobScoringData;
      private readonly RollupGridService serviceUnderTest;

      /// <summary>
      ///  Initializes a new instance of the <see cref="RollupGridServiceTest"/> class.
      /// </summary>
      public RollupGridServiceTest()
      {
         this.mockRollupBuilder = new Mock<IRollupBuilder>();
         this.mockReadRollupDataService = new Mock<IReadRollupDataService>();
         this.mockWriteRollupDataService = new Mock<IWriteRollupDataService>();
         this.mockRollupCriticalWriteProducer = new Mock<IRollupCriticalWriteProducer>();
         this.mockRollupAncillaryWriteProducer = new Mock<IRollupAncillaryWriteProducer>();
         this.mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
         this.mockJobScoringApiClient = new Mock<IJobScoringApiClient>();
         this.jobScoringData = new SalesRollupService.Core.Models.JobScoring.SalesOfficeScoringData()
         {
            JobSizeFactor = 1,
            CurrencyExchangeRate = 1,
            ProductCodeQuintiles = new List<SalesRollupService.Core.Models.JobScoring.ProductCodeQuintile>()
            {
               new SalesRollupService.Core.Models.JobScoring.ProductCodeQuintile() {
                  ProductCode = "ABC",
                  IsExempt = false,
                  Quintiles = new List<SalesRollupService.Core.Models.JobScoring.Quintile> { new SalesRollupService.Core.Models.JobScoring.Quintile() }
               },
               new SalesRollupService.Core.Models.JobScoring.ProductCodeQuintile() {
                  ProductCode = "DEF",
                  IsExempt = false,
                  Quintiles = new List<SalesRollupService.Core.Models.JobScoring.Quintile> { new SalesRollupService.Core.Models.JobScoring.Quintile() }
               },
            }
         };
         this.mapper = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<SalesRollupService.Configurations.AutoMapperConfiguration.AutoMapperProfile>();
         }).CreateMapper();

         this.serviceUnderTest = new RollupGridService(
            this.mapper,
            this.mockRollupBuilder.Object,
            this.mockReadRollupDataService.Object,
            this.mockWriteRollupDataService.Object,
            this.mockRollupCriticalWriteProducer.Object,
            this.mockRollupAncillaryWriteProducer.Object,
            this.mockHttpContextAccessor.Object,
            this.mockJobScoringApiClient.Object);
      }

      /// <summary>
      /// Test to ensure data access models get mapped to calc engine models
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task GetRollupBaseData_MapsDataAccessOutput_ToCalcEngineInput()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;

         // Mock data access to return "good" data
         RDA.PriceRollupBaseDataViewModel dataFromDataAccess = new RDA.PriceRollupBaseDataViewModel
         {
            IsUnpricedSelection = true,
            CalculatedPrices = new List<RDA.CalculatedPriceViewModel>
            {
               new RDA.CalculatedPriceViewModel
               {
                  AdjustedList = 2000,
                  PricedSelectedItems = new List<RDA.PricedSelectedItemViewModel>(),
               }
            }
         };
         this.mockReadRollupDataService
            .Setup(x => x.GetPriceRollupData(jobId, bidId, RollupConsumer.SalesOffice))
            .Returns(Task.FromResult(dataFromDataAccess));

         // Act
         PriceRollupBaseDataViewModel mappedDataForCalcEngine = await this.serviceUnderTest.GetRollupBaseData(jobId, bidId);

         // Assert that some properties were mapped
         // (Not concerned will all properties, just that all nested levels get mapped)
         Assert.NotNull(mappedDataForCalcEngine);
         Assert.Equal(dataFromDataAccess.IsUnpricedSelection, mappedDataForCalcEngine.IsUnpricedSelection);
         Assert.Equal(dataFromDataAccess.CalculatedPrices.Count, mappedDataForCalcEngine.CalculatedPrices.Count);
         Assert.Equal(dataFromDataAccess.CalculatedPrices[0].AdjustedList, mappedDataForCalcEngine.CalculatedPrices[0].AdjustedList);
      }

      /// <summary>
      /// Test to ensure the product code route makes the expected calls
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task GetRollupGrid_WithBaseData_CallsForCodeGrid_GivenCodeType()
      {
         // Arrange
         RDA.PriceRollupBaseDataViewModel dataFromDataAccess = new RDA.PriceRollupBaseDataViewModel
         {
            CalculatedPrices = new List<RDA.CalculatedPriceViewModel>
            {
               new RDA.CalculatedPriceViewModel
               {
                  AdjustedList = 2000,
                  PricedSelectedItems = new List<RDA.PricedSelectedItemViewModel>(),
               }
            },
            Job = new RDA.JobViewModel(),
            SelectionIdentifiers = new List<RDA.SelectionIdentifierViewModel>(),
            VariationIdentifiers = new List<RDA.VariationIdentifierViewModel>(),
         };
         PriceRollupBaseDataViewModel mappedBaseData = this.mapper.Map<PriceRollupBaseDataViewModel>(dataFromDataAccess);

         RollupViewModel emptyRollupViewModel = new RollupViewModel()
         {
            Rows = new List<RollupRowViewModel>(),
            Total = new RollupRowViewModel(),
            GrandTotal = new RollupRowViewModel(),
         };
         this.mockRollupBuilder
            .Setup(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false))
            .Returns(emptyRollupViewModel); // Setup for product code rollup performed during pricing policy calculation

         this.mockJobScoringApiClient.Setup(a => a.GetSalesOfficeScoringData(It.IsAny<int>(), It.IsAny<IEnumerable<string>>(), It.IsAny<string>()))
            .Returns(Task.FromResult(this.jobScoringData));

         // Act
         RollupViewModel rollupView = await this.serviceUnderTest.GetRollupGrid(mappedBaseData, RollupType.Code, true);

         // Assert
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), true), Times.Once);
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false), Times.Exactly(1)); // During pricing policy calculation
      }

      /// <summary>
      /// Test to ensure the product code route makes the expected calls
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task GetRollupGrid_CalculatePricingPolicyIsFalse_DoesntCalcPricingPolicy()
      {
         // Arrange
         RDA.PriceRollupBaseDataViewModel dataFromDataAccess = new RDA.PriceRollupBaseDataViewModel
         {
            CalculatedPrices = new List<RDA.CalculatedPriceViewModel>
            {
               new RDA.CalculatedPriceViewModel
               {
                  AdjustedList = 2000,
                  PricedSelectedItems = new List<RDA.PricedSelectedItemViewModel>(),
               }
            },
            Job = new RDA.JobViewModel(),
            SelectionIdentifiers = new List<RDA.SelectionIdentifierViewModel>(),
            VariationIdentifiers = new List<RDA.VariationIdentifierViewModel>(),
         };
         PriceRollupBaseDataViewModel mappedBaseData = this.mapper.Map<PriceRollupBaseDataViewModel>(dataFromDataAccess);

         RollupViewModel emptyRollupViewModel = new RollupViewModel()
         {
            Rows = new List<RollupRowViewModel>(),
            Total = new RollupRowViewModel(),
            GrandTotal = new RollupRowViewModel(),
         };
         this.mockRollupBuilder
            .Setup(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false))
            .Returns(emptyRollupViewModel); // Setup for product code rollup performed during pricing policy calculation

         // Act
         RollupViewModel rollupView = await this.serviceUnderTest.GetRollupGrid(mappedBaseData, RollupType.Code, false);

         // Assert
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), true), Times.Once);
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false), Times.Never); // During pricing policy calculation
         this.mockJobScoringApiClient.Verify(a => a.GetSalesOfficeScoringData(It.IsAny<int>(), It.IsAny<IEnumerable<string>>(), It.IsAny<string>()), Times.Never);
      }

      /// <summary>
      /// Test to ensure the product family route
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task GetRollupGrid_CallsForFamilyGrid_GivenFamilyType()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;

         RDA.PriceRollupBaseDataViewModel dataFromDataAccess = new RDA.PriceRollupBaseDataViewModel
         {
            CalculatedPrices = new List<RDA.CalculatedPriceViewModel>
            {
               new RDA.CalculatedPriceViewModel
               {
                  AdjustedList = 2000,
                  PricedSelectedItems = new List<RDA.PricedSelectedItemViewModel>(),
               }
            },
            Job = new RDA.JobViewModel(),
            SelectionIdentifiers = new List<RDA.SelectionIdentifierViewModel>(),
            VariationIdentifiers = new List<RDA.VariationIdentifierViewModel>(),
         };
         this.mockReadRollupDataService
            .Setup(x => x.GetPriceRollupData(jobId, bidId, RollupConsumer.SalesOffice))
            .Returns(Task.FromResult(dataFromDataAccess));

         RollupViewModel emptyRollupViewModel = new RollupViewModel()
         {
            Rows = new List<RollupRowViewModel>(),
            Total = new RollupRowViewModel(),
            GrandTotal = new RollupRowViewModel(),
         };
         this.mockRollupBuilder
            .Setup(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false))
            .Returns(emptyRollupViewModel); // Setup for product code rollup performed during pricing policy calculation

         this.mockJobScoringApiClient.Setup(a => a.GetSalesOfficeScoringData(It.IsAny<int>(), It.IsAny<IEnumerable<string>>(), It.IsAny<string>()))
            .Returns(Task.FromResult(this.jobScoringData));

         // Act
         await this.serviceUnderTest.GetRollupGrid(jobId, bidId, RollupType.Family, true);

         // Assert
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Family, It.IsAny<PriceRollupBaseDataViewModel>(), true), Times.Once);
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false), Times.Exactly(1)); // During pricing policy calculation
      }

      /// <summary>
      /// Test to ensure the product model route
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task GetRollupGrid_CallsForModelGrid_GivenModelType()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;

         RDA.PriceRollupBaseDataViewModel dataFromDataAccess = new RDA.PriceRollupBaseDataViewModel
         {
            CalculatedPrices = new List<RDA.CalculatedPriceViewModel>
            {
               new RDA.CalculatedPriceViewModel
               {
                  AdjustedList = 2000,
                  PricedSelectedItems = new List<RDA.PricedSelectedItemViewModel>(),
               }
            },
            Job = new RDA.JobViewModel(),
            SelectionIdentifiers = new List<RDA.SelectionIdentifierViewModel>(),
            VariationIdentifiers = new List<RDA.VariationIdentifierViewModel>(),
         };
         this.mockReadRollupDataService
            .Setup(x => x.GetPriceRollupData(jobId, bidId, RollupConsumer.SalesOffice))
            .Returns(Task.FromResult(dataFromDataAccess));

         RollupViewModel emptyRollupViewModel = new RollupViewModel()
         {
            Rows = new List<RollupRowViewModel>(),
            Total = new RollupRowViewModel(),
            GrandTotal = new RollupRowViewModel(),
         };
         this.mockRollupBuilder
            .Setup(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false))
            .Returns(emptyRollupViewModel); // Setup for product code rollup performed during pricing policy calculation

         this.mockJobScoringApiClient.Setup(a => a.GetSalesOfficeScoringData(It.IsAny<int>(), It.IsAny<IEnumerable<string>>(), It.IsAny<string>()))
            .Returns(Task.FromResult(this.jobScoringData));

         // Act
         await this.serviceUnderTest.GetRollupGrid(jobId, bidId, RollupType.Model, true);

         // Assert
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Model, It.IsAny<PriceRollupBaseDataViewModel>(), true), Times.Once);
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false), Times.Exactly(1)); // During pricing policy calculation
      }

      /// <summary>
      /// Test to ensure the failure indicator and errors are returned when the critical write producer encounters validation errors, when applying a grid edit.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task ApplyRollupGridEdit_CriticalWriteProducerHasErrors_ReturnsFailureWithErrors()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel();
         PriceRollupEdit priceRollupEdit = new PriceRollupEdit();
         List<string> responseErrors = new List<string>();
         string errMessage = "holy errors batman!";

         WriteProducerResponse producerResponse = new WriteProducerResponse()
         {
            IsSuccessful = false,
            Errors = new List<string>() { errMessage },
         };
         this.mockRollupCriticalWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, priceRollupEdit))
            .Returns(producerResponse);

         // Act
         bool returnStatus = await this.serviceUnderTest.ApplyRollupGridEdit(jobId, bidId, baseData, priceRollupEdit, responseErrors);

         // Assert
         Assert.False(returnStatus);
         Assert.Single(responseErrors);
         Assert.Equal(errMessage, responseErrors[0]);
      }

      /// <summary>
      /// Test to ensure the success indicator is returned when no problems are encountered, when applying a grid edit.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task ApplyRollupGridEdit_EncountersNoProblems_ReturnsTrue()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel();
         PriceRollupEdit priceRollupEdit = new PriceRollupEdit();
         List<string> responseErrors = new List<string>();

         WriteProducerResponse criticalProducerResponse = new WriteProducerResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
         };
         this.mockRollupCriticalWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, priceRollupEdit))
            .Returns(criticalProducerResponse);

         WriteProducerResponse ancillaryProducerResponse = new WriteProducerResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
         };
         this.mockRollupAncillaryWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, SalesRollupService.Common.Constants.PrimaryRollupConsumer))
            .Returns(ancillaryProducerResponse);

         this.mockWriteRollupDataService
            .Setup(x => x.TransactStatements(It.IsAny<IEnumerable<TSMT.RollupDataAccess.Models.WriteRollupDataStatement>>()))
            .Returns(Task.FromResult(true));

         // Act
         bool returnStatus = await this.serviceUnderTest.ApplyRollupGridEdit(jobId, bidId, baseData, priceRollupEdit, responseErrors);

         // Assert
         Assert.True(returnStatus);
         Assert.Empty(responseErrors);
      }

      /// <summary>
      /// Test to ensure the failure indicator and errors are returned when the critical write producer encounters validation errors, when copying multipliers.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task CopyMultipliers_CriticalWriteProducerHasErrors_ReturnsFailureWithErrors()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel();
         List<CopiedMultiplier> copiedMultipliers = new List<CopiedMultiplier>();
         RollupConsumer rollupConsumer = RollupConsumer.SalesOffice;
         CopyMultiplierSource copyMultiplierSource = CopyMultiplierSource.Authorized;
         CopyMultiplierDestination copyMultiplierDestination = CopyMultiplierDestination.Entered;
         List<string> responseErrors = new List<string>();
         string errMessage = "holy errors batman!";

         CopyMultipliersResponse producerResponse = new CopyMultipliersResponse()
         {
            IsSuccessful = false,
            Errors = new List<string>() { errMessage },
         };
         this.mockRollupCriticalWriteProducer
            .Setup(x => x.ProduceStatementsForCopyMultipliers(jobId, bidId, rollupConsumer, baseData, copyMultiplierSource, copyMultiplierDestination))
            .Returns(producerResponse);

         // Act
         bool returnStatus = await this.serviceUnderTest.CopyMultipliers(jobId, bidId, baseData, copyMultiplierSource, copiedMultipliers, responseErrors);

         // Assert
         Assert.False(returnStatus);
         Assert.Single(responseErrors);
         Assert.Equal(errMessage, responseErrors[0]);
      }

      /// <summary>
      /// Test to ensure the success indicator is returned when no problems are encountered, when copying multipliers.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task CopyMultipliers_EncountersNoProblems_ReturnsTrue()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel();
         List<CopiedMultiplier> copiedMultipliers = new List<CopiedMultiplier>();
         RollupConsumer rollupConsumer = RollupConsumer.SalesOffice;
         CopyMultiplierSource copyMultiplierSource = CopyMultiplierSource.Authorized;
         CopyMultiplierDestination copyMultiplierDestination = CopyMultiplierDestination.Entered;
         List<string> responseErrors = new List<string>();

         CopyMultipliersResponse producerResponse = new CopyMultipliersResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
            CopiedMultipliers = new List<CopiedMultiplier>(),
         };
         this.mockRollupCriticalWriteProducer
            .Setup(x => x.ProduceStatementsForCopyMultipliers(jobId, bidId, rollupConsumer, baseData, copyMultiplierSource, copyMultiplierDestination))
            .Returns(producerResponse);

         WriteProducerResponse ancillaryProducerResponse = new WriteProducerResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
         };
         this.mockRollupAncillaryWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, SalesRollupService.Common.Constants.PrimaryRollupConsumer))
            .Returns(ancillaryProducerResponse);

         this.mockWriteRollupDataService
            .Setup(x => x.TransactStatements(It.IsAny<IEnumerable<TSMT.RollupDataAccess.Models.WriteRollupDataStatement>>()))
            .Returns(Task.FromResult(true));

         // Act
         bool returnStatus = await this.serviceUnderTest.CopyMultipliers(jobId, bidId, baseData, copyMultiplierSource, copiedMultipliers, responseErrors);

         // Assert
         Assert.True(returnStatus);
         Assert.Empty(responseErrors);
      }

      /// <summary>
      /// Test to ensure the success indicator is returned when no problems are encountered, when copying multipliers from the Pricing Policy source.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task CopyMultipliers_EncountersNoProblemsCopyingFromPricingPolicy_ReturnsTrue()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel()
         {
            CalculatedPrices = new List<CalculatedPriceViewModel>(),
            Job = new JobViewModel(),
            SelectionIdentifiers = new List<SelectionIdentifierViewModel>(),
            VariationIdentifiers = new List<VariationIdentifier>(),
            ProductCodeSummary = new List<ProductCodeSummaryViewModel>()
         };
         List<CopiedMultiplier> copiedMultipliers = new List<CopiedMultiplier>();
         RollupConsumer rollupConsumer = RollupConsumer.SalesOffice;
         CopyMultiplierSource copyMultiplierSource = CopyMultiplierSource.PricingPolicy;
         CopyMultiplierDestination copyMultiplierDestination = CopyMultiplierDestination.Entered;
         List<string> responseErrors = new List<string>();

         RollupViewModel emptyRollupViewModel = new RollupViewModel()
         {
            Rows = new List<RollupRowViewModel>(),
            Total = new RollupRowViewModel(),
            GrandTotal = new RollupRowViewModel(),
         };
         this.mockRollupBuilder
            .Setup(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false))
            .Returns(emptyRollupViewModel); // Setup for product code rollup performed during pricing policy calculation

         CopyMultipliersResponse producerResponse = new CopyMultipliersResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
            CopiedMultipliers = new List<CopiedMultiplier>(),
         };
         this.mockRollupCriticalWriteProducer
            .Setup(x => x.ProduceStatementsForCopyMultipliers(jobId, bidId, rollupConsumer, baseData, copyMultiplierSource, copyMultiplierDestination))
            .Returns(producerResponse);

         WriteProducerResponse ancillaryProducerResponse = new WriteProducerResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
         };
         this.mockRollupAncillaryWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, SalesRollupService.Common.Constants.PrimaryRollupConsumer))
            .Returns(ancillaryProducerResponse);

         this.mockWriteRollupDataService
            .Setup(x => x.TransactStatements(It.IsAny<IEnumerable<TSMT.RollupDataAccess.Models.WriteRollupDataStatement>>()))
            .Returns(Task.FromResult(true));

         this.mockJobScoringApiClient.Setup(a => a.GetSalesOfficeScoringData(It.IsAny<int>(), It.IsAny<IEnumerable<string>>(), It.IsAny<string>()))
            .Returns(Task.FromResult(this.jobScoringData));

         // Act
         bool returnStatus = await this.serviceUnderTest.CopyMultipliers(jobId, bidId, baseData, copyMultiplierSource, copiedMultipliers, responseErrors);

         // Assert
         Assert.True(returnStatus);
         Assert.Empty(responseErrors);
         this.mockRollupBuilder.Verify(x => x.GetProductRollup(RollupType.Code, It.IsAny<PriceRollupBaseDataViewModel>(), false), Times.Exactly(1)); // During pricing policy calculation
      }

      /// <summary>
      /// Test to ensure the failure indicator and errors are returned when the ancillary write producer encounters a problem.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task FinishDatabaseEdits_AncillaryWriteProducerHasErrors_ReturnsFailureWithErrors()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel();
         List<WriteRollupDataStatement> writeStatements = new List<WriteRollupDataStatement>();
         List<string> responseErrors = new List<string>();
         string errMessage = "holy errors batman!";

         WriteProducerResponse ancillaryProducerResponse = new WriteProducerResponse()
         {
            IsSuccessful = false,
            Errors = new List<string>() { errMessage },
         };
         this.mockRollupAncillaryWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, SalesRollupService.Common.Constants.PrimaryRollupConsumer))
            .Returns(ancillaryProducerResponse);

         // Act
         bool returnStatus = await this.serviceUnderTest.FinishDatabaseEdits(jobId, bidId, baseData, writeStatements, responseErrors);

         // Assert
         Assert.False(returnStatus);
         Assert.Single(responseErrors);
         Assert.Equal(errMessage, responseErrors[0]);
      }

      /// <summary>
      /// Test to ensure the failure indicator and an error is returned when the transaction for db writes fails.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task FinishDatabaseEdits_WriterTransactionFails_ReturnsFailureWithError()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel();
         List<WriteRollupDataStatement> writeStatements = new List<WriteRollupDataStatement>();
         List<string> responseErrors = new List<string>();

         WriteProducerResponse ancillaryProducerResponse = new WriteProducerResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
         };
         this.mockRollupAncillaryWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, SalesRollupService.Common.Constants.PrimaryRollupConsumer))
            .Returns(ancillaryProducerResponse);

         this.mockWriteRollupDataService
            .Setup(x => x.TransactStatements(It.IsAny<IEnumerable<TSMT.RollupDataAccess.Models.WriteRollupDataStatement>>()))
            .Returns(Task.FromResult(false));

         // Act
         bool returnStatus = await this.serviceUnderTest.FinishDatabaseEdits(jobId, bidId, baseData, writeStatements, responseErrors);

         // Assert
         Assert.False(returnStatus);
         Assert.Single(responseErrors);
         Assert.Equal("Failure executing database statements.", responseErrors[0]);
      }

      /// <summary>
      /// Test to ensure the success indicator is returned when no problems are encountered, during database edits.
      /// </summary>
      /// <returns>A Task</returns>
      [Fact]
      public async Task FinishDatabaseEdits_EncountersNoProblems_ReturnsTrue()
      {
         // Arrange
         int jobId = 11466;
         int bidId = 629436;
         PriceRollupBaseDataViewModel baseData = new PriceRollupBaseDataViewModel();
         List<WriteRollupDataStatement> writeStatements = new List<WriteRollupDataStatement>();
         List<string> responseErrors = new List<string>();

         WriteProducerResponse ancillaryProducerResponse = new WriteProducerResponse()
         {
            IsSuccessful = true,
            Statements = new List<WriteRollupDataStatement>(),
         };
         this.mockRollupAncillaryWriteProducer
            .Setup(x => x.ProduceStatements(jobId, bidId, baseData, SalesRollupService.Common.Constants.PrimaryRollupConsumer))
            .Returns(ancillaryProducerResponse);

         this.mockWriteRollupDataService
            .Setup(x => x.TransactStatements(It.IsAny<IEnumerable<TSMT.RollupDataAccess.Models.WriteRollupDataStatement>>()))
            .Returns(Task.FromResult(true));

         // Act
         bool returnStatus = await this.serviceUnderTest.FinishDatabaseEdits(jobId, bidId, baseData, writeStatements, responseErrors);

         // Assert
         Assert.True(returnStatus);
         Assert.Empty(responseErrors);
      }
   }
}
