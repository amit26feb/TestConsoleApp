﻿// <copyright file="DiscountImportServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using AWS.MessagingWrapper.Contracts;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.Models;
   using SalesRollupService.Core.Repository;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public class DiscountImportServiceTest
   {
      private readonly Mock<ILogger<DiscountImportService>> logger;
      private readonly CancellationTokenSource cancelSource;
      private readonly DiscountImportService service;
      private readonly DiscountImportServiceHarness serviceHarness;
      private readonly Mock<IMessageReceiver> messageReceiver;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettingsMock;
      private readonly CommonConfigurationSettings settings;
      private readonly Mock<IDiscountImportRepository> repository;
      private readonly Mock<IRollupHistoryService> historyService;

      private readonly int drAddressId = 73;
      private readonly int jobId = 123000;

      /// <summary>
      /// Initializes a new instance of the <see cref="DiscountImportServiceTest"/> class.
      /// </summary>
      public DiscountImportServiceTest()
      {
         this.settings = new CommonConfigurationSettings()
         {
            SqsServiceUrlForDiscountTransfer = "https://sqs.us-east-1.amazonaws.com/somequeue",
         };
         this.commonConfigurationSettingsMock = Options.Create<CommonConfigurationSettings>(this.settings);
         this.messageReceiver = new Mock<IMessageReceiver>();
         this.logger = new Mock<ILogger<DiscountImportService>>();
         this.historyService = new Mock<IRollupHistoryService>();
         this.repository = new Mock<IDiscountImportRepository>();

         this.cancelSource = new CancellationTokenSource();

         this.service = new DiscountImportService(
            this.logger.Object,
            this.messageReceiver.Object,
            this.commonConfigurationSettingsMock,
            this.historyService.Object,
            this.repository.Object);

         this.serviceHarness = new DiscountImportServiceHarness(
            this.logger.Object,
            this.messageReceiver.Object,
            this.commonConfigurationSettingsMock,
            this.historyService.Object,
            this.repository.Object);
      }

      [Fact]
      public void ExecuteAsyncHarness_ReceivesMessageAndStopsOnCancellationToken_Success()
      {
         // Act
         Task runningService = Task.Run(() => this.serviceHarness.ExecuteAsyncHarness(this.cancelSource.Token));

         // Assert
         Assert.Equal(TaskStatus.WaitingForActivation, runningService.Status);
         this.cancelSource.Cancel();
         Thread.Sleep(500);
         Assert.Equal(TaskStatus.RanToCompletion, runningService.Status);
      }

      [Fact]
      public void ExecuteAsyncHarness_ReceiveMessageFromSqs_Processed()
      {
         // Arrange
         string handle = "handle";
         IEnumerable<Message> messages = new List<Message>()
             {
                new Message
                {
                  ReceiptHandle = handle,
                  Body = "{jobId: '1234'}"
                }
             };
         IEnumerable<Message> emptyMessages = null;
         this.messageReceiver.Setup(x => x.DeleteMessageAsync(It.IsAny<string>(), It.IsAny<string>()));
         this.messageReceiver.SetupSequence(x => x.ReceiveMessageAsync(It.IsAny<string>(), It.IsAny<CancellationToken>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()))
            .Returns(Task.FromResult(messages))
            .Returns(Task.FromResult(emptyMessages));

         // Act
         Task.Run(() => this.serviceHarness.ExecuteAsyncHarness(this.cancelSource.Token));

         // Due to the Task.Run background execution we have to sleep a bit to allow that thread to start up and run our loop a few times.
         // We can't just await ExecuteAsyncHarness inline because we have to be able to cancel the token.  Basically the test as a whole
         // fires up the background process for a half second or so so it can do the work and then shuts it down so we can verify what happened...
         // DO NOT USE THIS IN ANY PRODUCTION CODE!!!!!!!!!!!!!!!
         Thread.Sleep(500);

         // Assert
         this.messageReceiver.Verify(x => x.ReceiveMessageAsync(this.settings.SqsServiceUrlForDiscountTransfer, It.IsAny<CancellationToken>(), 1, 10), Times.AtLeastOnce);
         this.cancelSource.Cancel();
      }

      [Fact]
      public async Task UpdateSalesOfficeJob_HasNoSalesOfficeSpps_NoUpdates()
      {
         // Arrange
         int bidId = 333444;
         Bid bid = new Bid() { BidAlternateId = bidId };
         IEnumerable<SelectedPricingParm> spps = Enumerable.Empty<SelectedPricingParm>();

         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.repository.Setup(x => x.GetCurrentBid(It.IsAny<int>()))
            .Returns(Task.FromResult(bid));
         this.repository.Setup(x => x.GetSelectedPricingParms(It.IsAny<int>()))
            .Returns(Task.FromResult(spps));

         DiscountTransferViewModel job = new DiscountTransferViewModel()
         {
            DrAddressId = this.drAddressId,
            JobId = this.jobId
         };

         // Act
         await this.service.UpdateSalesOfficeJob(job);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetCurrentBid(this.jobId), Times.Once);
         this.repository.Verify(x => x.GetSelectedPricingParms(bidId), Times.Once);
         this.repository.Verify(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()), Times.Never);
         this.historyService.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Never);
      }

      [Fact]
      public async Task UpdateSalesOfficeJob_HasOrderedSpp_IsNotUpdated()
      {
         // Arrange
         int bidId = 333444;
         Bid bid = new Bid() { BidAlternateId = bidId };
         IEnumerable<SelectedPricingParm> spps = new List<SelectedPricingParm>()
         {
            new SelectedPricingParm() { SELECTION_ID = 1, PROD_PRICING_GRP_ID = 20, SALES_ORD_ID = 300 } // if sales office id is set, selection is ordered
         };

         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.repository.Setup(x => x.GetCurrentBid(It.IsAny<int>()))
            .Returns(Task.FromResult(bid));
         this.repository.Setup(x => x.GetSelectedPricingParms(It.IsAny<int>()))
            .Returns(Task.FromResult(spps));

         DiscountTransferViewModel job = new DiscountTransferViewModel()
         {
            DrAddressId = this.drAddressId,
            JobId = this.jobId,
            Selections = new List<DiscountSelectionViewModel>()
            {
               new DiscountSelectionViewModel() { SelectionId = 1, ProdPricingGroupId = 20 }
            }
         };

         // Act
         await this.service.UpdateSalesOfficeJob(job);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetCurrentBid(this.jobId), Times.Once);
         this.repository.Verify(x => x.GetSelectedPricingParms(bidId), Times.Once);
         this.repository.Verify(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()), Times.Never);
         this.historyService.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Never);
      }

      [Fact]
      public async Task UpdateSalesOfficeJob_HasUnorderedSpp_IsUpdatedWithDefaults()
      {
         // Arrange
         int bidId = 333444;
         Bid bid = new Bid() { BidAlternateId = bidId };
         IEnumerable<SelectedPricingParm> spps = new List<SelectedPricingParm>()
         {
            new SelectedPricingParm() { SELECTION_ID = 1, PROD_PRICING_GRP_ID = 20, SALES_ORD_ID = 300 },   // if sales office id is set, selection is ordered
            new SelectedPricingParm() { SELECTION_ID = 2, PROD_PRICING_GRP_ID = 22 }
         };

         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.repository.Setup(x => x.GetCurrentBid(It.IsAny<int>()))
            .Returns(Task.FromResult(bid));
         this.repository.Setup(x => x.GetSelectedPricingParms(It.IsAny<int>()))
            .Returns(Task.FromResult(spps));
         this.historyService.Setup(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()))
            .Returns(Task.FromResult(true));
         this.repository.Setup(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()))
            .Returns(Task.CompletedTask);

         DiscountTransferViewModel job = new DiscountTransferViewModel()
         {
            DrAddressId = this.drAddressId,
            JobId = this.jobId,
            Selections = new List<DiscountSelectionViewModel>()
            {
               new DiscountSelectionViewModel() { SelectionId = 1, ProdPricingGroupId = 20 },
               new DiscountSelectionViewModel() { SelectionId = 2, ProdPricingGroupId = 22 }
            }
         };

         // Act
         await this.service.UpdateSalesOfficeJob(job);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetCurrentBid(this.jobId), Times.Once);
         this.repository.Verify(x => x.GetSelectedPricingParms(bidId), Times.Once);
         this.historyService.Verify(x => x.AppendEdit(this.jobId, bidId, It.IsAny<PriceRollupEdit>()), Times.Exactly(2));
         this.repository.Verify(
            x => x.UpdateSelectedPricingParm(
               It.Is<SelectedPricingParm>(y =>
                  (decimal)y.GetType().GetProperty("AUTH_MULT").GetValue(y) == 1.0M
                     && (decimal)y.GetType().GetProperty("AUTH_COST_POINT_LPAF").GetValue(y) == 1.0M)),
            Times.Once);
      }

      [Fact]
      public async Task UpdateSalesOfficeJob_HasUnorderedSppAuthMult_AuthMultUpdatedWithDefaultCplpaf()
      {
         // Arrange
         int bidId = 333444;
         Bid bid = new Bid() { BidAlternateId = bidId };
         IEnumerable<SelectedPricingParm> spps = new List<SelectedPricingParm>()
         {
            new SelectedPricingParm() { SELECTED_PRICING_PARM_ID = 1, SELECTION_ID = 1, PROD_PRICING_GRP_ID = 20, SALES_ORD_ID = 300 },   // if sales office id is set, selection is ordered
            new SelectedPricingParm() { SELECTED_PRICING_PARM_ID = 2, SELECTION_ID = 2, PROD_PRICING_GRP_ID = 22 }
         };

         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.repository.Setup(x => x.GetCurrentBid(It.IsAny<int>()))
            .Returns(Task.FromResult(bid));
         this.repository.Setup(x => x.GetSelectedPricingParms(It.IsAny<int>()))
            .Returns(Task.FromResult(spps));
         this.historyService.Setup(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()))
            .Returns(Task.FromResult(true));
         this.repository.Setup(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()))
            .Returns(Task.CompletedTask);

         DiscountTransferViewModel job = new DiscountTransferViewModel()
         {
            DrAddressId = this.drAddressId,
            JobId = this.jobId,
            Selections = new List<DiscountSelectionViewModel>()
            {
               new DiscountSelectionViewModel() { SelectionId = 1, ProdPricingGroupId = 20 },
               new DiscountSelectionViewModel() { SelectionId = 2, ProdPricingGroupId = 22, AuthMult = .93M }
            }
         };

         // Act
         await this.service.UpdateSalesOfficeJob(job);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetCurrentBid(this.jobId), Times.Once);
         this.repository.Verify(x => x.GetSelectedPricingParms(bidId), Times.Once);
         this.historyService.Verify(x => x.AppendEdit(this.jobId, bidId, It.IsAny<PriceRollupEdit>()), Times.Exactly(2));
         this.repository.Verify(
            x => x.UpdateSelectedPricingParm(
               It.Is<SelectedPricingParm>(y =>
                  (decimal)y.GetType().GetProperty("AUTH_MULT").GetValue(y) == 0.93M
                     && (decimal)y.GetType().GetProperty("AUTH_COST_POINT_LPAF").GetValue(y) == 1.0M)),
            Times.Once);
      }

      [Fact]
      public async Task UpdateSalesOfficeJob_HasUnorderedSppAuthCplpaf_AuthCplpafUpdatedWithDefaultMult()
      {
         // Arrange
         int bidId = 333444;
         Bid bid = new Bid() { BidAlternateId = bidId };
         IEnumerable<SelectedPricingParm> spps = new List<SelectedPricingParm>()
         {
            new SelectedPricingParm() { SELECTED_PRICING_PARM_ID = 1, SELECTION_ID = 1, PROD_PRICING_GRP_ID = 20, SALES_ORD_ID = 300 },   // if sales office id is set, selection is ordered
            new SelectedPricingParm() { SELECTED_PRICING_PARM_ID = 2, SELECTION_ID = 2, PROD_PRICING_GRP_ID = 22 }
         };

         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.repository.Setup(x => x.GetCurrentBid(It.IsAny<int>()))
            .Returns(Task.FromResult(bid));
         this.repository.Setup(x => x.GetSelectedPricingParms(It.IsAny<int>()))
            .Returns(Task.FromResult(spps));
         this.historyService.Setup(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()))
            .Returns(Task.FromResult(true));
         this.repository.Setup(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()))
            .Returns(Task.CompletedTask);

         DiscountTransferViewModel job = new DiscountTransferViewModel()
         {
            DrAddressId = this.drAddressId,
            JobId = this.jobId,
            Selections = new List<DiscountSelectionViewModel>()
            {
               new DiscountSelectionViewModel() { SelectionId = 1, ProdPricingGroupId = 20 },
               new DiscountSelectionViewModel() { SelectionId = 2, ProdPricingGroupId = 22, AuthCplpaf = .78M }
            }
         };

         // Act
         await this.service.UpdateSalesOfficeJob(job);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetCurrentBid(this.jobId), Times.Once);
         this.repository.Verify(x => x.GetSelectedPricingParms(bidId), Times.Once);
         this.historyService.Verify(x => x.AppendEdit(this.jobId, bidId, It.IsAny<PriceRollupEdit>()), Times.Exactly(2));
         this.repository.Verify(
            x => x.UpdateSelectedPricingParm(
               It.Is<SelectedPricingParm>(y =>
                  (decimal)y.GetType().GetProperty("AUTH_MULT").GetValue(y) == 1.0M
                     && (decimal)y.GetType().GetProperty("AUTH_COST_POINT_LPAF").GetValue(y) == 0.78M)),
            Times.Once);
      }

      [Fact]
      public async Task UpdateSalesOfficeJob_UnmodifiedAuthCplpaf_DoesNotUpdate()
      {
         // Arrange
         int bidId = 333444;
         Bid bid = new Bid() { BidAlternateId = bidId };
         IEnumerable<SelectedPricingParm> spps = new List<SelectedPricingParm>()
         {
            new SelectedPricingParm() { SELECTED_PRICING_PARM_ID = 1, SELECTION_ID = 22, PROD_PRICING_GRP_ID = 333, AUTH_COST_POINT_LPAF = 0.7M, AUTH_MULT = 1M }
         };

         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.repository.Setup(x => x.GetCurrentBid(It.IsAny<int>()))
            .Returns(Task.FromResult(bid));
         this.repository.Setup(x => x.GetSelectedPricingParms(It.IsAny<int>()))
            .Returns(Task.FromResult(spps));
         this.historyService.Setup(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()))
            .Returns(Task.FromResult(true));
         this.repository.Setup(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()))
            .Returns(Task.CompletedTask);

         DiscountTransferViewModel job = new DiscountTransferViewModel()
         {
            DrAddressId = this.drAddressId,
            JobId = this.jobId,
            Selections = new List<DiscountSelectionViewModel>()
            {
               new DiscountSelectionViewModel() { SelectionId = 22, ProdPricingGroupId = 333, AuthCplpaf = .7M }
            }
         };

         // Act
         await this.service.UpdateSalesOfficeJob(job);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetCurrentBid(this.jobId), Times.Once);
         this.repository.Verify(x => x.GetSelectedPricingParms(bidId), Times.Once);
         this.historyService.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Never);
         this.repository.Verify(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()), Times.Never);
      }

      [Fact]
      public async Task UpdateSalesOfficeJob_UnmodifiedAuthMult_DoesNotUpdate()
      {
         // Arrange
         int bidId = 333444;
         Bid bid = new Bid() { BidAlternateId = bidId };
         IEnumerable<SelectedPricingParm> spps = new List<SelectedPricingParm>()
         {
            new SelectedPricingParm() { SELECTED_PRICING_PARM_ID = 1, SELECTION_ID = 22, PROD_PRICING_GRP_ID = 333, AUTH_COST_POINT_LPAF = 1M, AUTH_MULT = 0.7M }
         };

         this.repository.Setup(x => x.HonorDrAddressId(It.IsAny<int>()));
         this.repository.Setup(x => x.GetCurrentBid(It.IsAny<int>()))
            .Returns(Task.FromResult(bid));
         this.repository.Setup(x => x.GetSelectedPricingParms(It.IsAny<int>()))
            .Returns(Task.FromResult(spps));
         this.historyService.Setup(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()))
            .Returns(Task.FromResult(true));
         this.repository.Setup(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()))
            .Returns(Task.CompletedTask);

         DiscountTransferViewModel job = new DiscountTransferViewModel()
         {
            DrAddressId = this.drAddressId,
            JobId = this.jobId,
            Selections = new List<DiscountSelectionViewModel>()
            {
               new DiscountSelectionViewModel() { SelectionId = 22, ProdPricingGroupId = 333, AuthMult = .7M }
            }
         };

         // Act
         await this.service.UpdateSalesOfficeJob(job);

         // Assert
         this.repository.Verify(x => x.HonorDrAddressId(this.drAddressId), Times.Once);
         this.repository.Verify(x => x.GetCurrentBid(this.jobId), Times.Once);
         this.repository.Verify(x => x.GetSelectedPricingParms(bidId), Times.Once);
         this.historyService.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Never);
         this.repository.Verify(x => x.UpdateSelectedPricingParm(It.IsAny<SelectedPricingParm>()), Times.Never);
      }
   }
}
