﻿// <copyright file="RollupHistoryBackgroundServiceHarness.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System.Threading;
   using System.Threading.Tasks;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.Services;
   using TSMT.RollupDataAccess.Repositories;

   /// <summary>
   /// Harness for the rollup history background service
   /// </summary>
   public class RollupHistoryBackgroundServiceHarness : RollupHistoryBackgroundService
   {
      /// <summary>
      /// Initializes a new instance of the <see cref="RollupHistoryBackgroundServiceHarness"/> class.
      /// </summary>
      /// <param name="log">Logging the information</param>
      /// <param name="commonConfigurationSettings">Set configurable values</param>
      /// <param name="commonSqsService">Message receiver</param>
      /// <param name="ruleFactoryService">Rule factory service</param>
      /// <param name="cacheProvider">Cache provider</param>
      /// <param name="ruleList">Rule list</param>
      /// <param name="rollupHistoryRepository">Rollup history repository</param>
      public RollupHistoryBackgroundServiceHarness(IOptions<CommonConfigurationSettings> commonConfigurationSettings, ICommonSqsService commonSqsService, IRollupHistoryRepository rollupHistoryRepository, ILogger<RollupHistoryBackgroundService> log)
        : base(commonConfigurationSettings, commonSqsService, rollupHistoryRepository, log)
      {
      }

      /// <summary>
      /// Execute async harness
      /// </summary>
      /// <param name="stoppingToken">Cancellation token</param>
      /// <returns>Task representing completion</returns>
      public Task ExecuteAsyncHarness(CancellationToken stoppingToken)
      {
         return this.ExecuteAsync(stoppingToken);
      }
   }
}
