﻿// <copyright file="RollupHistoryBackgroundServiceHarnessTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Threading;
   using System.Threading.Tasks;
   using Amazon.SQS.Model;
   using Microsoft.Extensions.Logging;
   using Microsoft.Extensions.Options;
   using Moq;
   using SalesRollupService.Configurations;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Test.Common;
   using TSMT.RebalancingDomain.Models;
   using TSMT.RollupDataAccess.Repositories;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public class RollupHistoryBackgroundServiceHarnessTest
   {
      private readonly Mock<ILogger<RollupHistoryBackgroundService>> logger;
      private readonly CancellationTokenSource cancelSource;
      private readonly RollupHistoryBackgroundServiceHarness serviceUnderTest;
      private readonly Mock<ICommonSqsService> commonSqsServiceMock;
      private readonly IOptions<CommonConfigurationSettings> commonConfigurationSettingsMock;
      private readonly Mock<IRollupHistoryRepository> rollupHistoryRepository;

      /// <summary>
      /// Initializes a new instance of the <see cref="RollupHistoryBackgroundServiceHarnessTest"/> class.
      /// </summary>
      public RollupHistoryBackgroundServiceHarnessTest()
      {
         var configuration = new CommonConfigurationSettings()
         {
            QueueWaitTimeForRollupHistory = 1,
            SqsServiceURLForRollupHistoryService = "https://sqs.us-east-1.amazonaws.com/somequeue",
            MessageHidingTimeInMinutesForRollupHistory = 1,
            IsStageOrProdEnvironment = false,
         };
         this.commonConfigurationSettingsMock = Options.Create<CommonConfigurationSettings>(configuration);
         this.logger = new Mock<ILogger<RollupHistoryBackgroundService>>();
         this.cancelSource = new CancellationTokenSource();
         this.commonSqsServiceMock = new Mock<ICommonSqsService>();
         this.rollupHistoryRepository = new Mock<IRollupHistoryRepository>();
         this.serviceUnderTest = new RollupHistoryBackgroundServiceHarness(this.commonConfigurationSettingsMock, this.commonSqsServiceMock.Object, this.rollupHistoryRepository.Object, this.logger.Object);
      }

      [Fact]
      public void ExecuteAsyncHarness_ReceivesMessageAndStopsOnCancellationToken_Success()
      {
         // Act
         Task runningService = Task.Run(() => this.serviceUnderTest.ExecuteAsyncHarness(this.cancelSource.Token));

         // Assert
         Assert.Equal(TaskStatus.WaitingForActivation, runningService.Status);
         this.cancelSource.Cancel();
         Thread.Sleep(500);
         Assert.Equal(TaskStatus.RanToCompletion, runningService.Status);
      }

      [Fact]
      public void ExecuteAsyncHarness_ReceiveMessageFromSqs_Processed()
      {
         // Arrange
         JobEdit jobEdit = Helper.GetJobEdit();
         IEnumerable<Message> messages = new List<Message>()
         {
            Helper.GetMessage(jobEdit)
         };
         IEnumerable<Message> emptyMessages = null;
         this.commonSqsServiceMock.SetupSequence(x => x.GetSQSMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(Task.FromResult(messages)).Returns(Task.FromResult(emptyMessages));

         // Act
         Task.Run(() => this.serviceUnderTest.ExecuteAsyncHarness(this.cancelSource.Token));
         Thread.Sleep(500);

         // Assert
         this.commonSqsServiceMock.Verify(x => x.GetSQSMessagesAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>()), Times.AtLeastOnce);
         this.cancelSource.Cancel();
      }

      [Fact]
      public async Task ProcessRuleExecution_HasEmptyMessageBody()
      {
         // Arrange
         var message = new Message() { };

         // Act
         await this.serviceUnderTest.ProcessRollupHistoryExecution(message);

         // Assert
         this.commonSqsServiceMock.Verify(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService), Times.Never);
      }

      [Fact]
      public async Task ProcessRuleExecution_HasJobWithEdits_Appended()
      {
         // Arrange
         JobEdit jobEdit = Helper.GetJobEdit();
         Message message = Helper.GetMessage(jobEdit);
         this.rollupHistoryRepository.Setup(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>())).Returns(Task.FromResult(true));
         this.commonSqsServiceMock.Setup(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService)).Returns(Task.FromResult(It.IsAny<string>()));

         // Act
         await this.serviceUnderTest.ProcessRollupHistoryExecution(message);

         // Assert
         this.rollupHistoryRepository.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.AtLeastOnce);
         this.commonSqsServiceMock.Verify(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService), Times.Once);
      }

      [Fact]
      public async Task ProcessRuleExecution_HasVariationsWithoutSelections_Append()
      {
         // Arrange
         JobEdit jobEdit = Helper.GetJobEdit();
         jobEdit.SelectionEdits = null;
         Message message = Helper.GetMessage(jobEdit);
         this.commonSqsServiceMock.Setup(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService)).Returns(Task.FromResult(It.IsAny<string>()));

         // Act
         await this.serviceUnderTest.ProcessRollupHistoryExecution(message);

         // Assert
         this.rollupHistoryRepository.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Once);
         this.commonSqsServiceMock.Verify(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService), Times.Once);
      }

      [Fact]
      public async Task ProcessRuleExecution_NoSelectionsAndVariations_NeverAppend()
      {
         // Arrange
         JobEdit jobEdit = Helper.GetJobEdit();
         jobEdit.SelectionEdits = jobEdit.VariationEdits = null;
         Message message = Helper.GetMessage(jobEdit);
         this.commonSqsServiceMock.Setup(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService)).Returns(Task.FromResult(It.IsAny<string>()));

         // Act
         await this.serviceUnderTest.ProcessRollupHistoryExecution(message);

         // Assert
         this.rollupHistoryRepository.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Never);
         this.commonSqsServiceMock.Verify(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService), Times.Once);
      }

      [Fact]
      public async Task ProcessRuleExecution_HasSelectionsWithoutVariations_Append()
      {
         // Arrange
         JobEdit jobEdit = Helper.GetJobEdit();
         jobEdit.VariationEdits = null;
         Message message = Helper.GetMessage(jobEdit);
         this.rollupHistoryRepository.Setup(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>())).Returns(Task.FromResult(true));
         this.commonSqsServiceMock.Setup(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService)).Returns(Task.FromResult(It.IsAny<string>()));

         // Act
         await this.serviceUnderTest.ProcessRollupHistoryExecution(message);

         // Assert
         this.rollupHistoryRepository.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.AtLeastOnce);
         this.commonSqsServiceMock.Verify(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService), Times.Once);
      }

      [Fact]
      public async Task ProcessRuleExecution_NoJobEdit_NeverAppend()
      {
         // Arrange
         JobEdit jobEdit = Helper.GetJobEdit();
         jobEdit = null;
         Message message = Helper.GetMessage(jobEdit);
         this.commonSqsServiceMock.Setup(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService)).Returns(Task.FromResult(It.IsAny<string>()));

         // Act
         await this.serviceUnderTest.ProcessRollupHistoryExecution(message);

         // Assert
         this.rollupHistoryRepository.Verify(x => x.AppendEdit(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<PriceRollupEdit>()), Times.Never);
         this.commonSqsServiceMock.Verify(x => x.DeleteMessageAsync(message, this.commonConfigurationSettingsMock.Value.SqsServiceURLForRollupHistoryService), Times.Once);
      }
   }
}
