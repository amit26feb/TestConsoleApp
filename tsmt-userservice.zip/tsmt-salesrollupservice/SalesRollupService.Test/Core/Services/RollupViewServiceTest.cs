﻿// <copyright file="RollupViewServiceTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Services
{
   using System.Collections.Generic;
   using System.Linq;
   using System.Threading.Tasks;
   using AutoMapper;
   using Moq;
   using SalesRollupService.Core.Services;
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDataAccess.Models;
   using TSMT.RollupDataAccess.Repositories;
   using TSMT.RollupDomain.Models;
   using Xunit;

   /// <summary>
   /// RollupViewServiceTest
   /// </summary>
   public class RollupViewServiceTest
   {
      private readonly RollupViewService serviceUnderTest;
      private readonly IMapper mapper;
      private readonly Mock<IRollupViewRepository> mockViewRepository;

      /// <summary>
      ///  Initializes a new instance of the <see cref="RollupViewServiceTest"/> class.
      /// </summary>
      public RollupViewServiceTest()
      {
         this.mapper = new MapperConfiguration(cfg =>
         {
            cfg.AddProfile<TSMT.RollupDataAccess.Common.AutoMapperProfile>();
            cfg.AddProfile<SalesRollupService.Configurations.AutoMapperConfiguration.AutoMapperProfile>();
         }).CreateMapper();

         this.mockViewRepository = new Mock<IRollupViewRepository>();

         this.serviceUnderTest = new RollupViewService(this.mapper, this.mockViewRepository.Object);
      }

      [Fact]
      public async Task PutView_GivenView_CallsRepositoryOnce()
      {
         // Arrange
         var view = new RollupViewViewModel();

         // Act
         await this.serviceUnderTest.PutView(view);

         // Assert
         this.mockViewRepository.Verify(x => x.PutView(It.IsAny<RollupView>()), Times.Once);
      }

      [Fact]
      public async Task PutViews_GivenViews_CallsRepositoryOnce()
      {
         // Arrange
         var views = new[] { new RollupViewViewModel() };

         // Act
         await this.serviceUnderTest.PutViews(views);

         // Assert
         this.mockViewRepository.Verify(x => x.PutViews(It.IsAny<IEnumerable<RollupView>>()), Times.Once);
      }

      [Fact]
      public async Task DeleteView_CallsRepositoryOnce()
      {
         // Arrange
         string viewName = "bob's view";

         // Act
         await this.serviceUnderTest.DeleteView(viewName);

         // Assert
         this.mockViewRepository.Verify(x => x.DeleteView(viewName, null), Times.Once);
      }

      [Fact]
      public async Task GetViews_CallsRepositoryOnce()
      {
         // Act
         await this.serviceUnderTest.GetViews();

         // Assert
         this.mockViewRepository.Verify(x => x.GetViews(), Times.Once);
      }

      [Fact]
      public async Task GetUserViews_GivenDataAccessViews_MapsToServiceViews()
      {
         // Arrange
         string userName = "irbrfr";

         var dataAccessViews = new[]
         {
            new RollupView { Owner = userName },
            new RollupView { Owner = userName }
         }.AsEnumerable();

         this.mockViewRepository
            .Setup(x => x.GetUserViews(userName))
            .Returns(Task.FromResult(dataAccessViews));

         // Act
         var serviceViews = await this.serviceUnderTest.GetUserViews(userName);

         // Assert that some properties were mapped
         Assert.NotNull(serviceViews);
         Assert.Equal(dataAccessViews.Count(), serviceViews.Count());
         Assert.Equal(dataAccessViews.First().Owner, serviceViews.First().Owner);
      }

      [Fact]
      public async Task PutColumn_GivenColumnToBeFirst_AddsColumnAsTheFirst()
      {
         // Arrange
         var dataView = new RollupView
         {
            Name = "bob's view",
            Columns = new List<RollupColumn>
            {
               new RollupColumn { Name = "cA", Index = 0 },
               new RollupColumn { Name = "cB", Index = 1 }
            }
         };

         var viewColumnToPut = new RollupColumnViewModel
         {
            Name = "cC",
            Index = 0
         };
         var dataColumnToPut = this.mapper.Map<RollupColumn>(viewColumnToPut);

         this.mockViewRepository
            .Setup(x => x.GetView(dataView.Name, null))
            .Returns(Task.FromResult(dataView))
            .Verifiable();

         this.mockViewRepository
            .Setup(x => x.PutView(dataView))
            .Returns(Task.CompletedTask)
            .Verifiable();

         // Act
         await this.serviceUnderTest.PutColumn(dataView.Name, viewColumnToPut);

         // Assert
         Assert.Equal("cA", dataView.Columns[0].Name);
         Assert.Equal(1, dataView.Columns[0].Index);
         Assert.Equal("cB", dataView.Columns[1].Name);
         Assert.Equal(2, dataView.Columns[1].Index);
         Assert.Equal("cC", dataView.Columns[2].Name);
         Assert.Equal(0, dataView.Columns[2].Index);
         Assert.True(dataView.Columns.Count == 3);
         this.mockViewRepository.Verify();
      }

      [Fact]
      public async Task PutColumn_GivenColumnToBeLast_AddsColumnAsTheLast()
      {
         // Arrange
         var dataView = new RollupView
         {
            Name = "bob's view",
            Columns = new List<RollupColumn>
            {
               new RollupColumn { Name = "cA", Index = 0 },
               new RollupColumn { Name = "cB", Index = 1 }
            }
         };

         var viewColumnToPut = new RollupColumnViewModel
         {
            Name = "cC",
            Index = 2
         };
         var dataColumnToPut = this.mapper.Map<RollupColumn>(viewColumnToPut);

         this.mockViewRepository
            .Setup(x => x.GetView(dataView.Name, null))
            .Returns(Task.FromResult(dataView))
            .Verifiable();

         this.mockViewRepository
            .Setup(x => x.PutView(dataView))
            .Returns(Task.CompletedTask)
            .Verifiable();

         // Act
         await this.serviceUnderTest.PutColumn(dataView.Name, viewColumnToPut);

         // Assert
         Assert.Equal("cA", dataView.Columns[0].Name);
         Assert.Equal(0, dataView.Columns[0].Index);
         Assert.Equal("cB", dataView.Columns[1].Name);
         Assert.Equal(1, dataView.Columns[1].Index);
         Assert.Equal("cC", dataView.Columns[2].Name);
         Assert.Equal(2, dataView.Columns[2].Index);
         Assert.True(dataView.Columns.Count == 3);
         this.mockViewRepository.Verify();
      }

      [Fact]
      public async Task DeleteColumn_GivenFirstColumnToDelete_DeletesTheFirstColumn()
      {
         // Arrange
         var dataView = new RollupView
         {
            Name = "bob's view",
            Columns = new List<RollupColumn>
            {
               new RollupColumn
               {
                  Name = "cA",
                  Id = (int)RollupColumnType.AdjustedList,
                  Index = 0
               },
               new RollupColumn
               {
                  Name = "cB",
                  Id = (int)RollupColumnType.EnteredMultiplier,
                  Index = 1
               },
               new RollupColumn
               {
                  Name = "cC",
                  Id = (int)RollupColumnType.FAPDollars,
                  Index = 2
               }
            }
         };

         var columnTypeToDelete = RollupColumnType.AdjustedList;

         this.mockViewRepository
            .Setup(x => x.GetView(dataView.Name, null))
            .Returns(Task.FromResult(dataView))
            .Verifiable();

         this.mockViewRepository
            .Setup(x => x.PutView(dataView))
            .Returns(Task.CompletedTask)
            .Verifiable();

         // Act
         await this.serviceUnderTest.DeleteColumn(dataView.Name, columnTypeToDelete);

         // Assert
         Assert.Equal("cB", dataView.Columns[0].Name);
         Assert.Equal(0, dataView.Columns[0].Index);
         Assert.Equal("cC", dataView.Columns[1].Name);
         Assert.Equal(1, dataView.Columns[1].Index);
         Assert.True(dataView.Columns.Count == 2);
         this.mockViewRepository.Verify();
      }

      [Fact]
      public async Task DeleteColumn_GivenLastColumnToDelete_DeletesTheLastColumn()
      {
         // Arrange
         var dataView = new RollupView
         {
            Name = "bob's view",
            Columns = new List<RollupColumn>
            {
               new RollupColumn
               {
                  Name = "cA",
                  Id = (int)RollupColumnType.AdjustedList,
                  Index = 0
               },
               new RollupColumn
               {
                  Name = "cB",
                  Id = (int)RollupColumnType.EnteredMultiplier,
                  Index = 1
               },
               new RollupColumn
               {
                  Name = "cC",
                  Id = (int)RollupColumnType.FAPDollars,
                  Index = 2
               }
            }
         };

         var columnTypeToDelete = RollupColumnType.FAPDollars;

         this.mockViewRepository
            .Setup(x => x.GetView(dataView.Name, null))
            .Returns(Task.FromResult(dataView))
            .Verifiable();

         this.mockViewRepository
            .Setup(x => x.PutView(dataView))
            .Returns(Task.CompletedTask)
            .Verifiable();

         // Act
         await this.serviceUnderTest.DeleteColumn(dataView.Name, columnTypeToDelete);

         // Assert
         Assert.Equal("cA", dataView.Columns[0].Name);
         Assert.Equal(0, dataView.Columns[0].Index);
         Assert.Equal("cB", dataView.Columns[1].Name);
         Assert.Equal(1, dataView.Columns[1].Index);
         Assert.True(dataView.Columns.Count == 2);
         this.mockViewRepository.Verify();
      }
   }
}