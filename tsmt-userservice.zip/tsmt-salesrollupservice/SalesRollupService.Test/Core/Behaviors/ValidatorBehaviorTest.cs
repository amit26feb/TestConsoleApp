﻿// <copyright file="ValidatorBehaviorTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Behaviors
{
   using System.Threading;
   using System.Threading.Tasks;
   using FluentValidation;
   using MediatR;
   using SalesRollupService.Core.Behaviors;
   using Xunit;

   /// <summary>
   /// Validator Behavior Test
   /// </summary>
   public class ValidatorBehaviorTest
   {
      /// <summary>
      /// Logging behavior request and response
      /// </summary>
      private readonly IValidator<Request>[] validators;

      /// <summary>
      /// Initializes a new instance of the <see cref="ValidatorBehaviorTest"/> class.
      /// </summary>
      public ValidatorBehaviorTest()
      {
         this.validators = new IValidator<Request>[0];
      }

      /// <summary>
      /// Success validator behavior
      /// </summary>
      /// <returns>Success</returns>
      [Fact]
      public async Task ValidatorBehavior_ValidInput_ReturnsMessage()
      {
         // Arrange
         ValidatorBehavior<Request, Response> validatorBehavior = new ValidatorBehavior<Request, Response>(this.validators);

         Request ping = new Request
         {
            Message = "test request"
         };
         Response pong = new Response
         {
            Message = "test response"
         };

         CancellationToken cancellationToken = default(CancellationToken);

         // Act
         var response = await validatorBehavior.Handle(ping, cancellationToken, next: () => Task.FromResult(pong));

         // Assert
         Assert.NotNull(response);
         Assert.Equal(response.Message, pong.Message);
      }

#pragma warning disable SA1402 // File may only contain a single class
      /// <summary>
      /// Request
      /// </summary>
      public class Request : IRequest<Response>
#pragma warning restore SA1402 // File may only contain a single class
      {
         /// <summary>
         /// Gets or sets message
         /// </summary>
         public string Message { get; set; }

         /// <summary>
         /// Gets or sets error
         /// </summary>
         public string Errors { get; set; }
      }

#pragma warning disable SA1402 // File may only contain a single class
      /// <summary>
      /// Response
      /// </summary>
      public class Response
#pragma warning restore SA1402 // File may only contain a single class
      {
         /// <summary>
         /// Gets or sets message
         /// </summary>
         public string Message { get; set; }

         /// <summary>
         /// Gets or sets error
         /// </summary>
         public string Errors { get; set; }
      }
   }
}
