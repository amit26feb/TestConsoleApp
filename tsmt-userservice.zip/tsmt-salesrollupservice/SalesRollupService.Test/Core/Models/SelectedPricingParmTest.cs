﻿// <copyright file="SelectedPricingParmTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Models
{
   using SalesRollupService.Core.Models;
   using Xunit;

   /// <summary>
   /// Selected Pricing Parm model test
   /// </summary>
   public class SelectedPricingParmTest
   {
      [Fact]
      public void IsOrdered_HasNullSalesOrderId_ReturnsFalse()
      {
         // Arrange
         SelectedPricingParm spp = new SelectedPricingParm();

         // Act + Assert
         Assert.False(spp.IsOrdered);
      }

      [Fact]
      public void IsOrdered_HasSalesOrderId_ReturnsTrue()
      {
         // Arrange
         SelectedPricingParm spp = new SelectedPricingParm() { SALES_ORD_ID = 100 };

         // Act + Assert
         Assert.True(spp.IsOrdered);
      }
   }
}
