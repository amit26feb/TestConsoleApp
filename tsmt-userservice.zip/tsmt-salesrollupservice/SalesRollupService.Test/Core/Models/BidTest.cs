﻿// <copyright file="BidTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Core.Models
{
   using SalesRollupService.Core.Models;
   using Xunit;

   /// <summary>
   /// Bids Model test
   /// </summary>
   public class BidTest
   {
      [Fact]
      public void IsBaseBid_BaseBidIsZero_ReturnsFalse()
      {
         // Arrange
         Bid bid = new Bid() { BaseBidYesNo = 0 };

         // Act + Assert
         Assert.False(bid.IsBaseBid);
      }

      [Fact]
      public void IsBaseBid_BaseBidIsOne_ReturnsTrue()
      {
         // Arrange
         Bid bid = new Bid() { BaseBidYesNo = 1 };

         // Act + Assert
         Assert.True(bid.IsBaseBid);
      }

      [Fact]
      public void IsCurrentBid_CurrentBidIndIsNull_ReturnsFalse()
      {
         // Arrange
         Bid bid = new Bid();

         // Act + Assert
         Assert.False(bid.IsCurrentBid);
      }

      [Fact]
      public void IsCurrentBid_CurrentBidIndIsN_ReturnsFalse()
      {
         // Arrange
         Bid bid = new Bid() { CurrentBidInd = "N" };

         // Act + Assert
         Assert.False(bid.IsCurrentBid);
      }

      [Fact]
      public void IsCurrentBid_CurrentBidIndIsY_ReturnsTrue()
      {
         // Arrange
         Bid bid = new Bid() { CurrentBidInd = "Y" };

         // Act + Assert
         Assert.True(bid.IsCurrentBid);
      }
   }
}
