﻿namespace SalesRollupService.Test.Core.ViewModels
{
   using SalesRollupService.Core.ViewModels;
   using TSMT.RollupDomain.Models;
   using Xunit;

   public class RewindHistoryRequestViewModelTest
   {
      private readonly RewindHistoryRequestViewModel modelUnderTest;

      public RewindHistoryRequestViewModelTest()
      {
         this.modelUnderTest = new RewindHistoryRequestViewModel
         {
            JobId = 123,
            BidId = 234,
            Edit = new PriceRollupEdit(),
            RollupType = RollupType.Code
         };
      }

      [Fact]
      public void Validate_GivenValidRequest_ReturnsTrue()
      {
         // Act
         var success = this.modelUnderTest.Validate(out string reason);

         // Assert
         Assert.True(success);
         Assert.Null(reason);
      }

      [Fact]
      public void Validate_GivenNonNullRollupType_ReturnsTrue()
      {
         // Arrange
         this.modelUnderTest.RollupType = RollupType.Code;

         // Act
         var success = this.modelUnderTest.Validate(out string reason);

         // Assert
         Assert.True(success);
      }

      [Fact]
      public void Validate_GivenNullRollupType_ReturnsTrue()
      {
         // Arrange
         this.modelUnderTest.RollupType = null;

         // Act
         var success = this.modelUnderTest.Validate(out string reason);

         // Assert
         Assert.True(success);
      }

      [Fact]
      public void Validate_GivenInvalidJobId_ReturnsFalseWithAReason()
      {
         // Arrange
         this.modelUnderTest.JobId = 0;

         // Act
         var success = this.modelUnderTest.Validate(out string reason);

         // Assert
         Assert.False(success);
         Assert.Equal("The job ID is invalid", reason);
      }

      [Fact]
      public void Validate_GivenInvalidBidId_ReturnsFalseWithAReason()
      {
         // Arrange
         this.modelUnderTest.BidId = 0;

         // Act
         var success = this.modelUnderTest.Validate(out string reason);

         // Assert
         Assert.False(success);
         Assert.Equal("The bid ID is invalid", reason);
      }

      [Fact]
      public void Validate_GivenNullEdit_ReturnsFalseWithAReason()
      {
         // Arrange
         this.modelUnderTest.Edit = null;

         // Act
         var success = this.modelUnderTest.Validate(out string reason);

         // Assert
         Assert.False(success);
         Assert.Equal("The edit is missing", reason);
      }
   }
}
