﻿// <copyright file="AutoMapperTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Configurations
{
   using System;
   using System.Linq;
   using AutoMapper;
   using PriceRollupCalculationEngine.ViewModels;
   using SalesRollupService.Configurations.AutoMapperConfiguration;
   using Xunit;
   using DataAccessModels = TSMT.RollupDataAccess.Models;
   using DataAccessViewModels = TSMT.RollupDataAccess.ViewModels;
   using DataAccessWriteModels = TSMT.RollupDataAccess.Models.WriteRollupDataModels;
   using EngineModels = PriceRollupCalculationEngine.Models;
   using EngineWriteModels = PriceRollupCalculationEngine.Models.WriteRollupDataModels;

   public class AutoMapperTest
   {
      private readonly IMapper mapperUnderTest;

      public AutoMapperTest()
      {
         this.mapperUnderTest = new MapperConfiguration(cfg => { cfg.AddProfile<AutoMapperProfile>(); })
            .CreateMapper();
      }

      [Fact]
      public void Mapper_GivenPriceRollupBaseDataViewModel_MapsDataAccessModelToEngineModel()
      {
         // Arrange
         var dataAccessModel = new DataAccessViewModels.PriceRollupBaseDataViewModel
         {
            CalculatedPrices = new[]
            {
               new DataAccessViewModels.CalculatedPriceViewModel
               {
                  ProductCode = "SomeProductCode",
                  PricedSelectedItems = new[] { new DataAccessViewModels.PricedSelectedItemViewModel { OrderingNbr = "SomeOrderingNbr" } }
               }
            },
            ProductCodeSummary = new[]
            {
               new DataAccessViewModels.ProductCodeSummaryViewModel { Description = "SomeDescription" }
            },
            ProductFamilies = new[]
            {
               new DataAccessViewModels.ProductFamilyViewModel { Description = "SomeDescription" }
            },
            SelectionIdentifiers = new[]
            {
               new DataAccessViewModels.SelectionIdentifierViewModel { Description = "SomeDescription" }
            },
            VariationIdentifiers = new[]
            {
               new DataAccessViewModels.VariationIdentifierViewModel { Description = "SomeDescription" }
            },
            ProdPricingGroups = new[]
            {
               new DataAccessViewModels.ProdPricingGroupViewModel { BidBreakoutName = "SomeBidBreakoutName" }
            },
            Job = new DataAccessViewModels.JobViewModel { SalesOfficeId = 123 }
         };

         // Act
         var engineModel = this.mapperUnderTest.Map<PriceRollupBaseDataViewModel>(dataAccessModel);

         // Assert
         Assert.Equal(dataAccessModel.CalculatedPrices.First().ProductCode, engineModel.CalculatedPrices.First().ProductCode);
         Assert.Equal(dataAccessModel.CalculatedPrices.First().PricedSelectedItems.First().OrderingNbr, engineModel.CalculatedPrices.First().PricedSelectedItems.First().OrderingNbr);
         Assert.Equal(dataAccessModel.ProductCodeSummary.First().Description, engineModel.ProductCodeSummary.First().Description);
         Assert.Equal(dataAccessModel.ProductFamilies.First().Description, engineModel.ProductFamilies.First().Description);
         Assert.Equal(dataAccessModel.SelectionIdentifiers.First().Description, engineModel.SelectionIdentifiers.First().Description);
         Assert.Equal(dataAccessModel.VariationIdentifiers.First().Description, engineModel.VariationIdentifiers.First().Description);
         Assert.Equal(dataAccessModel.ProdPricingGroups.First().BidBreakoutName, engineModel.ProdPricingGroups.First().BidBreakoutName);
         Assert.Equal(dataAccessModel.Job.SalesOfficeId, engineModel.Job.SalesOfficeId);
      }

      [Fact]
      public void Mapper_GivenBidProdAmountDeleteWriteStatement_MapsEngineModelToDataAccessModel()
      {
         // Arrange
         var engineModel = new EngineWriteModels.BidProdAmountDelete { BidAlternateId = 123 };
         var engineStatement = new EngineModels.WriteRollupDataStatement(EngineModels.WriteRollupDataStatementType.Delete, engineModel);

         // Act
         var dataAccessStatement = this.mapperUnderTest.Map<DataAccessModels.WriteRollupDataStatement>(engineStatement);

         // Assert
         Assert.Equal(DataAccessModels.WriteRollupDataStatementType.Delete, dataAccessStatement.Type);
         Assert.IsType<DataAccessWriteModels.BidProdAmountDelete>(dataAccessStatement.Model);

         var dataAccessModel = dataAccessStatement.Model as DataAccessWriteModels.BidProdAmountDelete;
         Assert.Equal(engineModel.BidAlternateId, dataAccessModel.BidAlternateId);
      }

      [Fact]
      public void Mapper_VariationMarkupUpdateModels_MapProperties()
      {
         // Arrange
         CalculatedPriceViewModel calculatedPrice = new CalculatedPriceViewModel() { VariationId = 1, VariationCost = 3, VariationPrice = 4 };
         EngineWriteModels.VariationMarkupUpdate engineModel = new EngineWriteModels.VariationMarkupUpdate(calculatedPrice, 1.4m, DateTime.Now);
         EngineModels.WriteRollupDataStatement engineStatement = new EngineModels.WriteRollupDataStatement(EngineModels.WriteRollupDataStatementType.Update, engineModel);

         // Act
         DataAccessModels.WriteRollupDataStatement dataAccessStatement = this.mapperUnderTest.Map<DataAccessModels.WriteRollupDataStatement>(engineStatement);

         // Assert
         Assert.Equal(DataAccessModels.WriteRollupDataStatementType.Update, dataAccessStatement.Type);
         Assert.IsType<DataAccessWriteModels.VariationMarkupUpdate>(dataAccessStatement.Model);

         DataAccessWriteModels.VariationMarkupUpdate dataAccessModel = dataAccessStatement.Model as DataAccessWriteModels.VariationMarkupUpdate;
         Assert.Equal(engineModel.Id, dataAccessModel.Id);
         Assert.Equal(engineModel.Multiplier, dataAccessModel.Multiplier);
         Assert.Equal(engineModel.Price, dataAccessModel.Price);
         Assert.Equal(engineModel.ReviseDate, dataAccessModel.ReviseDate);
      }
   }
}
