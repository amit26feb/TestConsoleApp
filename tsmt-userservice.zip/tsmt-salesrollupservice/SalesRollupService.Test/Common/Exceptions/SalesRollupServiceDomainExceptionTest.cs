﻿// <copyright file="SalesRollupServiceDomainExceptionTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Common.Exceptions
{
   using System;
   using SalesRollupService.Common.Exceptions;
   using Xunit;

   /// <summary>
   /// SalesRollupService Domain Exception Test
   /// </summary>
   public class SalesRollupServiceDomainExceptionTest
   {
      /// <summary>
      /// Ensures basic constructor leads to a canned error message in the domain exception message
      /// </summary>
      [Fact]
      public void DomainException_BasicConstructor_DoesNotAutomaticallyDefineMessage()
      {
         // Act
         SalesRollupServiceDomainException domainException = new SalesRollupServiceDomainException();

         // Assert
         Assert.NotNull(domainException.Message);
      }

      /// <summary>
      /// Ensures constructor override with message has the message retained as the domain exception message
      /// </summary>
      [Fact]
      public void DomainException_ConstructorWithMessage__PreservesErrorAttributes()
      {
         // Setup
         string errorMessage = "error text";

         // Act
         SalesRollupServiceDomainException domainException = new SalesRollupServiceDomainException(errorMessage);

         // Assert
         Assert.Equal(domainException.Message, errorMessage);
      }

      /// <summary>
      /// Ensures constructor override with message and inner exception has these retained as domain exception attributes
      /// </summary>
      [Fact]
      public void DomainException_ConstructorWithMessageAndException__PreservesErrorAttributes()
      {
         // Setup
         string errorMessage = "error text";
         Exception ex = new Exception();

         // Act
         SalesRollupServiceDomainException domainException = new SalesRollupServiceDomainException(errorMessage, ex);

         // Assert
         Assert.Equal(domainException.Message, errorMessage);
         Assert.Equal(domainException.InnerException, ex);
      }
   }
}
