﻿// <copyright file="Helper.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test.Common
{
   using System.Collections.Generic;
   using Amazon.SQS.Model;
   using Newtonsoft.Json;
   using TSMT.RebalancingDomain.Models;
   using TSMT.RollupDataAccess.Models;
   using TSMT.RollupDomain.Models;

   /// <summary>
   /// Helper class includes the methods that can be commonly used across the test project.
   /// </summary>
   public static class Helper
   {
      /// <summary>
      /// Method to get price rollup history
      /// </summary>
      /// <returns>Price rollup history</returns>
      public static PriceRollupHistory GetPriceRollupHistory()
      {
         return new PriceRollupHistory()
         {
            BidId = 456,
            JobId = 123,
            Edits = new List<PriceRollupEdit>()
            {
               new PriceRollupEdit()
               {
                  RollupHistoryType = RollupHistoryTypes.Transmitted,
                  RollupRowType = RollupRowType.Selection,
                  RollupRowIdentifier = "1000"
               },
               new PriceRollupEdit()
               {
                  RollupRowType = RollupRowType.ProductFamily,
                  RollupRowIdentifier = "1001"
               },
               new PriceRollupEdit()
               {
                  RollupRowType = RollupRowType.JobVariationProdCode,
                  RollupRowIdentifier = "1002"
               },
               new PriceRollupEdit()
               {
                  RollupRowType = RollupRowType.MainUnitProdCode,
                  RollupRowIdentifier = "1003c"
               },
               new PriceRollupEdit()
               {
                  RollupRowType = RollupRowType.Total,
               },
               new PriceRollupEdit()
               {
                  RollupRowType = RollupRowType.GrandTotal,
               }
            }
         };
      }

      /// <summary>
      /// Method to get selection identifiers
      /// </summary>
      /// <returns>Selections identifier</returns>
      public static IEnumerable<SelectionIdentifier> GetSelectionIdentifiers()
      {
         return new List<SelectionIdentifier>()
         {
            new SelectionIdentifier()
            {
               SALESMAN_DESCR = "Selection",
               TAG = "120 test",
               SELECTION_ID = 1000
            }
         };
      }

      /// <summary>
      /// Method to get product families
      /// </summary>
      /// <returns>Product family</returns>
      public static IEnumerable<ProductFamily> GetProductFamilies()
      {
         return new List<ProductFamily>()
         {
            new ProductFamily()
            {
               DESCRIPTION = "ProdFamily",
               PROD_FAMILY_ID = 1001
            }
         };
      }

      /// <summary>
      /// Method to get variation identifiers
      /// </summary>
      /// <returns>Variation identifier</returns>
      public static IEnumerable<VariationIdentifier> GetVariationIdentifiers()
      {
         return new List<VariationIdentifier>()
         {
            new VariationIdentifier()
            {
               SHORT_DESC = "Variation",
               VARIATION_ID = 1002
            }
         };
      }

      /// <summary>
      /// Method to get product code
      /// </summary>
      /// <returns>Product code</returns>
      public static IEnumerable<ProductCode> GetProductCodes()
      {
         return new List<ProductCode>()
         {
            new ProductCode()
            {
               DESCRIPTION = "ProdCodes",
               PROD_CODE = "1003c"
            }
         };
      }

      /// <summary>
      /// Method to get job edit
      /// </summary>
      /// <returns>Job edit</returns>
      public static JobEdit GetJobEdit()
      {
         return new JobEdit()
         {
            JobId = 12345,
            DrAddressId = 10,
            UserId = "ccdore",
            SelectionEdits = new List<Edit>()
            {
               new Edit()
               {
                  Id = 1,
                  BidAlternateId = 657058,
                  OldValue = 0,
                  NewValue = 120,
                  ColumnType = 0,
               },
               new Edit()
               {
                  Id = 1,
                  BidAlternateId = 657058,
                  OldValue = 1,
                  NewValue = 122,
                  ColumnType = (ColumnType)2,
               }
            },
            VariationEdits = new List<Edit>()
            {
               new Edit()
               {
                  Id = 1,
                  BidAlternateId = 657058,
                  OldValue = 0,
                  NewValue = 120,
                  ColumnType = 0,
               }
            }
         };
      }

      /// <summary>
      /// Method to get message.
      /// </summary>
      /// <param name="jobEdit">Job edit</param>
      /// <returns>Message.</returns>
      public static Message GetMessage(JobEdit jobEdit)
      {
         string data = JsonConvert.SerializeObject(jobEdit);

         object messageBody = new
         {
            Type = "Notification",
            MessageId = "2d6a0af8-1aca-5240-bae6-5daa2f02e45d",
            TopicArn = "arn:aws:sqs:us-east-1:611998158124:TSMT-SQS-RollupHistory",
            SnsMessage = "Subject",
            Message = JsonConvert.SerializeObject(data),
         };

         return new Message()
         {
            MessageId = "TestMessage",
            ReceiptHandle = "TetsHandle",
            Body = JsonConvert.SerializeObject(messageBody),
         };
      }
   }
}
