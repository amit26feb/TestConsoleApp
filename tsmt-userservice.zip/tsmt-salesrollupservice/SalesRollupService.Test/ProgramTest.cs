﻿// <copyright file="ProgramTest.cs" company="Trane Company">
// Copyright (c) Trane Company. All rights reserved.
// </copyright>

namespace SalesRollupService.Test
{
   using System;
   using System.IO;
   using System.Net;
   using System.Net.Http;
   using System.Threading.Tasks;
   using Microsoft.AspNetCore.Hosting;
   using Microsoft.AspNetCore.TestHost;
   using Microsoft.Extensions.Configuration;
   using Microsoft.Extensions.DependencyInjection;
   using Microsoft.Extensions.Options;
   using SalesRollupService;
   using SalesRollupService.Configurations;
   using TSMT.Settings;
   using Xunit;

   /// <summary>
   /// Program Test
   /// </summary>
   public class ProgramTest
   {
      /// <summary>
      /// Test ability to build web host
      /// </summary>
      /// <returns>Success</returns>
      [Fact]
      public async Task ShouldBuildWebHost()
      {
         // Arrange
         Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
         string appRootPath = Path.GetFullPath(Path.Combine(
             AppContext.BaseDirectory,
             "..",
             "..",
             "..",
             "..",
             "SalesRollupService"));
         var webHostBuilder = Program.BuildWebHost(Array.Empty<string>())
             .UseContentRoot(appRootPath);
         var server = new TestServer(webHostBuilder);
         var client = server.CreateClient();
         HttpResponseMessage response = new HttpResponseMessage();

         // Act
         response = await client.GetAsync(" ");

         Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
      }

      /// <summary>
      /// Should configure TSMTSettings
      /// </summary>
      [Fact]
      public void ConfigureWithoutBindMethod()
      {
         // Arrange
         var collection = new ServiceCollection();
         collection.AddOptions();

         var config = new ConfigurationBuilder()
             .Add(new TsmtConfigurationSource<ConfigParameterConstants>("Development", "us-east-1"))
             .Build();

         collection.Configure<TSMTSettings>(config);

         var services = collection.BuildServiceProvider();

         // Act
         var options = services.GetService<IOptions<TSMTSettings>>();

         // Assert
         Assert.NotNull(options);
         Assert.NotNull(options.Value.RedisEndpoint);
      }
   }
}