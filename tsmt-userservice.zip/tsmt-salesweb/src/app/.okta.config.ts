import { environment } from '../environments/environment';

export default {
  oidc: {
    clientId: environment.oktaClientId,
    issuer: environment.oktaIssuer,
    redirectUri: window.location.origin + '/implicit/callback',
    scope: 'openid profile email',
    pkce: true,
  },
};
