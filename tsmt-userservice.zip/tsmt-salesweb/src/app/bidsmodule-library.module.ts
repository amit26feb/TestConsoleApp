import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { Settings, SalesWebBidsModule } from '@tsmt/salesweb-bidsmodule';

@NgModule({})
export class BidsModuleLibraryModule {
  public static forRoot(environment: any): ModuleWithProviders<SalesWebBidsModule> {
    return {
      ngModule: SalesWebBidsModule,
      providers: [
        Settings,
        {
          provide: 'environment',
          useValue: environment,
        },
      ],
    };
  }
}
