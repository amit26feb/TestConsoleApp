import { ModuleWithProviders, NgModule } from '@angular/core';
import { ApiErrorService } from '@tsmt/shared-core-salesweb';
import {
    BidService, ErrorService, GatewayService, JobService, RollupService, SalesBidService,
    SalesJobService, SalesRollupService, SalesWebGatewayService, SharedPriceRollupModule
} from '@tsmt/shared-price-rollup';

import { UserService } from './modules/jobs-list-master/services/user.service';

@NgModule({})
export class SharedPriceRollUpLibraryModule {

  public static forRoot(environment: any): ModuleWithProviders<SharedPriceRollupModule> {

    return {
      ngModule: SharedPriceRollupModule,
      providers: [
        UserService,
        { provide: 'environment', useValue: environment },
        { provide: ErrorService, useClass: ApiErrorService },
        { provide: RollupService, useClass: SalesRollupService },
        { provide: GatewayService, useClass: SalesWebGatewayService },
        { provide: JobService, useClass: SalesJobService },
        { provide: BidService, useClass: SalesBidService },
      ],
    };
  }
}
