import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes, ExtraOptions } from '@angular/router';
import { OktaAuthGuard, OktaCallbackComponent } from '@okta/okta-angular';

import { TSMTMenuGuard } from './auth/menu-guard.service';
import { LoginComponent } from './login/login.component';
import { DevEnvGuard } from './shared/guards/dev-env.guard';
import { UserInfoResolver } from './user-info-resolver.service';
import { UserPreferencesComponent } from './shared/components/user-preferences/user-preferences.component';

const approutes: Routes = [
  {
    path: '',
    component: LoginComponent,
  },
  {
    path: 'implicit/callback',
    component: OktaCallbackComponent,
  },
  {
    path: 'home-page-list/:drAddressId',
    resolve: {
      userInfo: UserInfoResolver,
    },
    loadChildren: () => import('./modules/home-page/home-page.module')
      .then((m) => m.HomePageModule),
    canActivate: [OktaAuthGuard, TSMTMenuGuard],
    pathMatch: 'prefix',
    data: { Ctitle: 'Home Page List', headerData: '', routeName: 'home-page-list' },
  },
  {
    // For an existing PO Acknowledgement form - original implementation left in to
    // redirect email links users may still have to the new implementation in OrdersModule
    path: 'PurDocAck/:id',
    redirectTo: 'orders/po-acknowledgements/:id',
  },
  {
    path: 'support',
    resolve: {
      userInfo: UserInfoResolver,
    },
    loadChildren: () => import('@tsmt/salesweb-supportmodule')
      .then((m) => m.SaleswebSupportModule),
    canLoad: [DevEnvGuard],
    canActivate: [OktaAuthGuard, TSMTMenuGuard],
  },
  {
    path: 'orders',
    resolve: {
      userInfo: UserInfoResolver,
    },
    loadChildren: () => import('@tsmt/salesweb-ordersmodule')
      .then((m) => m.SalesWebOrdersModule),
    canActivate: [OktaAuthGuard, TSMTMenuGuard],
  },
  {
    path: 'manual-payment-request',
    resolve: {
      userInfo: UserInfoResolver,
    },
    loadChildren: () => import('@tsmt/salesweb-manualpaymentrequestmodule')
      .then((m) => m.SaleswebManualpaymentrequestmoduleModule),
    canLoad: [DevEnvGuard],
    canActivate: [TSMTMenuGuard],
  },
  {
    path: 'my-preferences',
    component: UserPreferencesComponent,
    canActivate: [OktaAuthGuard],
    resolve: {
      userInfo: UserInfoResolver,
    },
  },
];

export const routingConfiguration: ExtraOptions = {
  paramsInheritanceStrategy: 'always'
};


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(approutes, routingConfiguration),
  ],
  declarations: [],
  providers: [UserInfoResolver],
})
export class AppRoutingModule { }
