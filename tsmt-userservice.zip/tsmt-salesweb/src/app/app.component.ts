import { HttpErrorResponse } from '@angular/common/http';
import {
  AfterViewInit, Component, HostListener, NgZone, OnInit, TemplateRef,
  ViewChild, ViewContainerRef, ViewEncapsulation
} from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import { NotificationService } from '@progress/kendo-angular-notification';
import { JobsListComponent } from '@tsmt/salesweb-jobsmodule';
import { CreditProjectService, HistoryService } from '@tsmt/salesweb-ordersmodule';
import { MessageCountService } from '@tsmt/shared-core';
import {
  ApiErrorService, CommonService as CommonServiceService, ErrorsAndWarningsPanelService,
  JobHeaderService as SharedJobHeaderService, UserInfoService
} from '@tsmt/shared-core-salesweb';
import 'rxjs/add/operator/filter';
import { IMessageAppInfo, IMessageContainerConfig } from './../../node_modules/@tsmt/shared-core/lib/modules/message/message-model';
import { DocumentService } from './modules/jobs-list-master/services/document.service';
import { JobsServicesService } from './modules/jobs-list-master/services/jobs-services.service';
// components
import { HeaderComponent } from './shared/components/header/header.component';
// Constants
import { AppConstants } from './shared/constants/constants';
import { GlobalSearchService } from './shared/services/global-search.service';
// services
import { ToasterService } from '@tsmt/shared-core';
import { WorkflowPopupService } from './shared/services/workflow-popup.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [CommonServiceService, ToasterService]
})


export class AppComponent implements OnInit, AfterViewInit {
  public messageAppInfo: IMessageAppInfo;
  messageContainerConfig: IMessageContainerConfig = {
    showPopover: false,
    anchorAlign: { horizontal: 'right', vertical: 'bottom' },
    popupAlign: { horizontal: 'right', vertical: 'top' },
  };
  public showSidePanel = false;
  @ViewChild('myTemplateVar') routerOutlet: RouterOutlet;
  @ViewChild('header') headerComponent: HeaderComponent;
  public headerContent: string;
  @ViewChild(HeaderComponent) headerInstance;
  @ViewChild('template', { read: TemplateRef })
  public notificationTemplate: TemplateRef<any>;
  @ViewChild('appendTo', { read: ViewContainerRef })
  public appendTo: ViewContainerRef;
  isShowNotification = false;
  isSidenav: boolean;
  docWidth: number;
  public showToaster = false;
  public showSuccessMsg = false;
  public showErrorMsg = false;
  public showWarningMsg = false;
  public showInfoMsg = false;
  public showNoticeMsg = false;
  isAuthentication = false;
  userDenied = false;
  oktaAuthError: any = {};
  pageOverlay: HTMLElement;
  browserValidation: boolean;
  public showWorkflowPanel = false;
  public showNotification = false;
  public showErrorAndWarningsPanel = false;
  public pinPanel = false;
  public isRefresh = false;
  constructor(
    public toasterService: ToasterService,
    private zone: NgZone,
    public oktaAuth: OktaAuthService,
    private router: Router,
    private appConstants: AppConstants,
    private apiErrorService: ApiErrorService,
    private kendoNotification: NotificationService,
    private workflowPopupService: WorkflowPopupService,
    private userInfoService: UserInfoService,
    private jobService: JobsServicesService,
    private messageCountService: MessageCountService,
    private creditProjectService: CreditProjectService,
    private documentService: DocumentService,
    private errorsAndWarningsPanelService: ErrorsAndWarningsPanelService,
    private sharedJobHeaderService: SharedJobHeaderService,
    private commonService: CommonServiceService,
    private historyService: HistoryService,
    private globalSearchService: GlobalSearchService,

  ) {
  }

  async ngOnInit() {
    const userAgent = window.navigator.userAgent.toLowerCase();
    this.browserValidation = (
      userAgent.indexOf('msie 9') !== -1
      || userAgent.indexOf('msie 1') !== -1
      || userAgent.indexOf('trident/7.0') !== -1
      && userAgent.indexOf('verson/5') === -1
      && userAgent.indexOf('verson/6') === -1
      && userAgent.indexOf('firefox') === -1
    );
    this.isAuthentication = await this.oktaAuth.isAuthenticated();
    this.oktaAuth.$authenticationState.subscribe((isAuthenticated) => {
      this.isAuthentication = isAuthenticated;
    });
    this.enableWorkflowPanel();
    this.messageCountService.
      setToasterConfig({ content: this.notificationTemplate, appendTo: this.appendTo });
    this.enableNotification();
    this.enableErrorsAndWarningsPanel();
    const routepath = this.router.routerState.snapshot.url;
    if (routepath.match(/error=access_denied/g)) {
      this.router.navigate(['/']);
      this.userDenied = true;
    }
    if (!localStorage.getItem('currentMessageCount')) {
      // set the initial notification count to 0
      localStorage.setItem('currentMessageCount', '0');
    }
    this.router.events.filter((event) => event instanceof NavigationEnd)
      .subscribe((event) => {
        const oktaStorageItems = localStorage.getItem('okta-cache-storage') && localStorage.getItem('okta-token-storage');
        if ((oktaStorageItems === null || oktaStorageItems === '') && !this.userDenied) {
          localStorage.clear();
          localStorage.setItem('okta_error', 'timeout');
          location.reload();
        } else if (this.userDenied === true) {
          this.toasterService.setToaster('error', this.appConstants.OKTA_ACCESS_DENIED);
        }
      });
    this.sharedJobHeaderService.showErrorsAndWarningsPanel.subscribe((showError) => {
      this.showErrorAndWarningsPanel = showError;
    });
  }


  ngAfterViewInit() {
    this.setContentHeight();
  }

  // set minimun height to the content-container so that the footer appears at the bottom
  @HostListener('window:resize')
  @HostListener('window:orientationchange')
  setContentHeight() {
    const headerElement: HTMLElement = document.querySelector('header');
    const footerElement: HTMLElement = document.querySelector('footer');
    const containerElement: HTMLElement = document.querySelector('.content-container');
    const headerHeight = headerElement ? headerElement.offsetHeight : 60;
    const footerHeight = footerElement.offsetHeight;
    // min height for the container is the (document height -(footer height + header Height) -
    // (offset of the container at the top(spacing between container and header)) )
    const minHeight = (document.documentElement.clientHeight - (headerHeight + footerHeight) - 10) + 'px';
    containerElement.style.minHeight = minHeight;
  }

  // Subscribe to catch click event emitter from header component
  enableWorkflowPanel() {
    this.workflowPopupService.workflowPopup.subscribe((setFlag) => {
      if (setFlag) {
        this.showWorkflowPopup();
      }
    });
  }

  // Enable workflow popup panel
  showWorkflowPopup() {
    this.pageOverlay = document.querySelector('#page-mask');
    this.showWorkflowPanel = true;
    this.pageOverlay.style.width = '100%';
  }

  // Disable workflow popup panel
  hideWorkflowPopup() {
    this.pageOverlay = document.querySelector('#page-mask');
    this.showWorkflowPanel = false;
    this.pageOverlay.style.width = '0';
  }

  // hide notification panel
  hideNotification(): void {
    this.showNotification = false;
    this.messageCountService.isMessagePanelOpen$.next(false);
  }

  openNotificationPanel(event: Event): void {
    event.stopPropagation();
    this.messageCountService.isMessagePanelOpen$.next(true);
  }

  // show notification panel
  enableNotification(): void {
    this.docWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    this.messageCountService.isMessagePanelOpen$.subscribe((res) => {
      if (res && this.routerOutlet.isActivated) {
        this.showNotification = true;
        this.messageAppInfo = {
          userId: this.userInfoService.getUserId(),
          version: this.appConstants.applicationId,
          appId: 'SalesWeb',
        };
        if (!(this.routerOutlet.component['currentRouteCompRef'] instanceof JobsListComponent) || this.docWidth < 800) {
          this.messageContainerConfig.showPopover = true;
          if (this.headerComponent) {
            this.messageContainerConfig.notificationContainer = this.headerComponent.notificationContainer;
          }
        }
      } else {
        this.showNotification = false;
      }
    });
  }

  // method to redirect and download file
  clickAction(event: Event): void {
    if (event['urlType'] === 'Redirect') {
      if (event['urlPath'].includes('work-packages')) {
        this.redirectToScope(event);
      } else {
        const path = event['urlPath'].split('/');
        const jobId = path[2];
        const drAddressId = path[3];
        const payload = {
          jobId,
          drAddressId,
          userId: this.userInfoService.getUserId(),
          lockJob: true,
          allowLockOverride: true,
        };

        // attempt to lock job
        this.jobService.LockAndUnLockJob(payload).subscribe(() => {
          window.open(event['urlPath'], event['urlPath']);
        },
          (err: HttpErrorResponse) => {
            if (err.status === 409) {
              window.open(event['urlPath'], event['urlPath']);
            } else {
              this.apiErrorService.show(err.error.Message);
            }
          });
      }
    } else {
      if (event['urlPath'].indexOf('Jobs/CreditProjects/') !== -1) {
        this.downloadCreditProjectFile(event['urlPath']);
      } else if (event['urlPath'].indexOf('Jobs/CreditProjectHistory/') !== -1) {
        this.downloadCreditProjectHistoryFile(event['urlPath']);
      } else if (event['urlPath'].indexOf('documentgeneration/') !== -1) {
        this.downloadDocGenFile(event['urlPath']);
      } else if (event['urlPath'].indexOf('orderreport/') !== -1) {
        this.downloadShippingHistoryFile(event['urlPath']);
      } else {
        this.downloadJobsFile(event['urlPath']);
      }
    }
  }

  downloadShippingHistoryFile(key: string): void {
    const path = key.split('/');
    const fileName = path[2];
    this.globalSearchService.downloadPDF(key).subscribe((fileModel) => {
      this.downloadFile(fileName, URL.createObjectURL(fileModel.file));
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  // download the Jobs file for the s3
  downloadJobsFile(key: string): void {
    const path = key.split('/');
    const jobId = parseInt(path[3], 10);
    const drAddressId = parseInt(path[2], 10);
    const fileName = path[4];
    // The key is the S3 path in which the file was stored Eg.Job/Export/{DrAddressId}/{JobId}/{FileName}
    this.jobService.downloadDocument(drAddressId, jobId, key, '', '').subscribe((fileModel) => {
      this.downloadFile(fileName, URL.createObjectURL(fileModel.file));
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  // download the credit project file for the s3
  downloadCreditProjectFile(key: string): void {
    const path: string[] = key.split('/');
    const creditJobId: number = Number(path[2]);
    const fileName: string = path[3];
    // The key is the S3 path in which the file was stored Eg.Jobs/CreditProjects/{creditJobId}/{FileName}
    this.creditProjectService.downloadDocument(creditJobId, key).subscribe((fileModel) => {
      this.downloadFile(fileName, URL.createObjectURL(fileModel.file));
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  /**
   * Download the credit project history file from the s3
   * @param key - document key
   */
  downloadCreditProjectHistoryFile(key: string): void {
    const path: string[] = key.split('/');
    const creditJobId: number = Number(path[2]);
    const fileName: string = path[3];
    // The key is the S3 path in which the file was stored Eg.Jobs/CreditProjectHistory/{creditJobId}/{FileName}
    this.historyService.downloadDocument(creditJobId, key).subscribe((fileModel) => {
      this.downloadFile(fileName, URL.createObjectURL(fileModel.file));
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  // download the doc gen file for the s3
  downloadDocGenFile(key: string): void {
    const path: string[] = key.split('/');
    const drAddressId = Number(path[1]);
    const jobId = Number(path[2]);
    const documentPackageId = Number(path[3]);
    const version = Number(path[4]);
    // (prefixed with documentgeneration)
    // The key is the S3 path in which the file was stored Eg. generated-files/{draddressid}/{jobId}/{documentPackageId}/{version}
    this.documentService.getDocumentFileDownload(drAddressId, jobId, documentPackageId, version).subscribe((fileModel) => {
      this.downloadFile(fileModel.name, URL.createObjectURL(fileModel.file));
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  // download the file
  downloadFile(fileName: string, href: string): void {
    const element = document.createElement('a');
    element.href = href;
    element.download = fileName;
    element.click();
  }

  /**
   * Subscribe to catch click event emitter from header component
   * @returns void
   */
  enableErrorsAndWarningsPanel(): void {
    this.errorsAndWarningsPanelService.errorsAndWarningsPanel.subscribe((setFlag) => {
      if (setFlag) {
        this.showErrorsAndWarningsPanel();
      }
    });
  }

  /**
   * Enable errors and warnings side panel
   * @returns void
   */
  showErrorsAndWarningsPanel(): void {
    this.showErrorAndWarningsPanel = true;
  }

  /**
   * Disable errors and warnings panel
   * @returns void
   */
  hideErrorsAndWarningsPanel(): void {
    this.showErrorAndWarningsPanel = false;
    this.pinPanel = false;
    this.commonService.changeWidth(this.pinPanel);
  }


  // Pin/Unpin errors and warnings panel
  pinUnpinErrorsAndWarningPanel(action: string): void {
    this.pinPanel = action === 'pin';
    this.commonService.changeWidth(this.pinPanel);
  }

  /**
   * Redirect to the scope screen on clicking the conversion notification
   * @param - Event
   */
  redirectToScope(event: Event): void {
    window.open(event['urlPath']);
  }

  // Sets isClickInErrorsPanel value in header component on clicking anywhere in errors panel
  setClickInErrorsPanel(): void {
    if (this.headerComponent) {
      this.headerComponent.isClickInErrorsPanel = true;
    }
  }

  /**
   * Method to trigger prevalidations
   * @param - refreshEvent
   */
  triggerPreValidations(refreshEvent: boolean): void {
    if (refreshEvent) {
      this.commonService.startPreValidation.next(refreshEvent);
      this.headerComponent.clickRefreshIcon();
      this.commonService.refreshErrorsAndWarningPanel.subscribe((response) => {
        this.isRefresh = response;
      });
    }
    this.isRefresh = false;
  }
}
