import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { Constants, SharedCoreModule } from '@tsmt/shared-core';

@NgModule({
})
export class SharedCoreLibraryModule {

    public static forRoot(environment: any): ModuleWithProviders<SharedCoreModule> {

        return {
            ngModule: SharedCoreModule,
            providers: [
                Constants,
                {
                    provide: 'environment',
                    useValue: environment,
                },
            ],
        };
    }
}
