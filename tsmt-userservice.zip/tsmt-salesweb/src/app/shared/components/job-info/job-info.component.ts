import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-job-info',
  templateUrl: './job-info.component.html',
})
export class JobInfoComponent implements OnInit {
  public jobInfoForm: FormGroup;
  constructor() {
   }

  ngOnInit() {
    this.jobInfoForm = new FormGroup({
      type: new FormControl(),
      streetAddress1: new FormControl(),
      streetAddress2: new FormControl(),
      zipCode: new FormControl(),
      city: new FormControl(),
      state: new FormControl(),
      county: new FormControl(),
      country: new FormControl(),
      cityDDControl: new FormControl(),
      officePhoneNumber: new FormControl(),
      bidDate: new FormControl(),
      engineer: new FormControl(),
    });
  }
}
