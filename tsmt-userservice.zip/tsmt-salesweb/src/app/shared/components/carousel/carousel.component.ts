import { SlickCarouselComponent } from 'ngx-slick-carousel';
import { Component, Input, ViewEncapsulation, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { CommonService as CommonServiceService } from '@tsmt/shared-core-salesweb';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class CarouselComponent implements OnChanges {
  @Input() className?: string;
  @Input() data: any;
  @Input() slideConfig?: any;
  @ViewChild('slickModal') slickModal: SlickCarouselComponent;

  constructor(public commonService: CommonServiceService) { }

  /**
   * Gets details of slick once intialized
   * @param  {event} - Hold the all information related to slider
   */

  slickInit(event: any) {
    this.commonService.carouselActiveSlideIndex.next(event.slick.currentSlide);
  }

  /**
   * Gets details of clicking on the previous slide
   * @param  {event} - Hold the all information related to slider
   */

  afterChange(event: any) {
    this.commonService.setCarouselActiveIndex(event.currentSlide);
  }

  trackByFn(index: number): number {
    return index;
  }

  ngOnChanges(changes: SimpleChanges): void {
    const change = changes['slideConfig'];
    if (change?.previousValue !== change?.currentValue) {
      this.slickModal?.slickGoTo(change.currentValue.initialSlide);
      this.commonService.carouselActiveSlideIndex.next(change.currentValue.initialSlide);
    }
  }

}
