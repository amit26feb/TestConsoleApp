import { SlickCarouselComponent } from 'ngx-slick-carousel';
import { async, ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { SharedModule } from '../../modules/shared/shared.module';
import { CarouselComponent } from './carousel.component';

// service and mocks
import { CommonService as CommonServiceService } from '@tsmt/shared-core-salesweb';
import { CommonServiceMock } from '../../test-mocks/commonservice-mock';
import { SimpleChanges } from '@angular/core';

describe('CarouselComponent', () => {
  let component: CarouselComponent;
  let fixture: ComponentFixture<CarouselComponent>;
  const originReset = TestBed.resetTestingModule;
  let injector: TestBed;
  let commonService: CommonServiceService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: [CarouselComponent],
      providers: [{ provide: CommonServiceService, useClass: CommonServiceMock }],
    });
    injector = getTestBed();
    fixture = TestBed.createComponent(CarouselComponent);
    component = fixture.componentInstance;
    commonService = injector.inject(CommonServiceService);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the default slide to zero on slickInit', () => {
    const event = { slick: { currentSlide: 0 } };
    component.slickInit(event);
    commonService.carouselActiveSlideIndex.subscribe((index) => {
      expect(index).toBe(0);
    });
  });

  it('should emit active slide index on calling afterChange()', () => {
    const event = { currentSlide: 0 };
    component.afterChange(event);
    expect(event.currentSlide).toBe(0);
  });

  it('should return index on calling trackByFn', () => {
    expect(component.trackByFn(2)).toEqual(2);
  });

  it('should call slickGoTo on calling ngOnChanges', () => {
    component.slickModal = new SlickCarouselComponent(null, null, null);
    const changes: SimpleChanges =
      { slideConfig: { previousValue: { initialSlide: 0 }, currentValue: { initialSlide: 3 } } } as unknown as SimpleChanges;
    spyOn(component.slickModal, 'slickGoTo');
    spyOn(commonService.carouselActiveSlideIndex, 'next').and.callFake(() => { });
    component.ngOnChanges(changes);
    expect(component.slickModal.slickGoTo).toHaveBeenCalledWith(3);
  });

  it('should not call slickGoTo on calling ngOnChanges when current and previous value are same', () => {
    component.slickModal = new SlickCarouselComponent(null, null, null);
    const slide = { initialSlide: 0 };
    const changes: SimpleChanges =
      { slideConfig: { previousValue: slide, currentValue: slide } } as unknown as SimpleChanges;
    spyOn(component.slickModal, 'slickGoTo');
    spyOn(commonService.carouselActiveSlideIndex, 'next').and.callFake(() => { });
    component.ngOnChanges(changes);
    expect(component.slickModal.slickGoTo).not.toHaveBeenCalled();
  });

});
