import { Location } from '@angular/common';
import { async, ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { ExitComponent } from './exit.component';

describe('ExitComponent', () => {
  let component: ExitComponent;
  let fixture: ComponentFixture<ExitComponent>;
  const originReset = TestBed.resetTestingModule;
  let titleService: Title;
  let route: ActivatedRoute;
  let location: Location;

  function executeExitFromValidation(exitFrom: string) {
    const spyTitle = spyOn(titleService, 'setTitle');
    spyOn(location, 'getState').and.returnValue({ exitFrom, navigationId: 1 });
    component.ngOnInit();
    expect(component.message).toBe('You may close this browser tab');
    expect(spyTitle).toHaveBeenCalled();
  }

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [ExitComponent],
      providers: [Title, Location,
        {
          provide: ActivatedRoute, useValue: {
            snapshot: {
              params: { isLockedBySomeoneElse: 'true' },
            },
          },
        }],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    titleService = fixture.componentRef.injector.get(Title);
    route = TestBed.inject(ActivatedRoute);
    location = TestBed.inject(Location);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set message when exited from sales-order or isLockedBySomeoneElse is true on ngOnInit method', () => {
    executeExitFromValidation('sales-order');
  });

  it('should set message when exited from billing or isLockedBySomeoneElse is true on ngOnInit method', () => {
    executeExitFromValidation('billing');
  });

  it('should set message when exited from shipment-details or isLockedBySomeoneElse is true on ngOnInit method', () => {
    executeExitFromValidation('shipment-details');
  });

  it('should set message when exited from job-history or isLockedBySomeoneElse is true on ngOnInit method', () => {
    executeExitFromValidation('job-history');
  });

  it('should set message when exited from assign-sales-orders or isLockedBySomeoneElse is true on ngOnInit method', () => {
    executeExitFromValidation('assign-sales-orders');
  });

  it('should set message and exited from work package page on ngOnInit method', () => {
    const spyTitle = spyOn(titleService, 'setTitle');
    spyOn(location, 'getState').and.returnValue({ exitFrom: 'work package', navigationId: 1 });
    component.ngOnInit();
    expect(spyTitle).toHaveBeenCalled();
    expect(component.message).toBe('You may close this browser tab');
  });

});
