import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-exit',
  templateUrl: './exit.component.html',
  styleUrls: ['./exit.component.scss'],
})
export class ExitComponent implements OnInit {
  public message: string;
  public state: any;
  public exitFroms = ['sales-order', 'billing', 'shipment-details', 'job-history', 'change-order', 'credit-project', 'edit-credit-project',
    'work package', 'cost-forecast', 'assign-sales-orders'];
  constructor(private titleService: Title, private route: ActivatedRoute, private location: Location) { }

  ngOnInit() {
    this.setExitDetails();
  }

  // Set exit page details
  setExitDetails() {
    this.state = this.location.getState();
    const exitFrom = this.state ? this.state.exitFrom : null;
    this.titleService.setTitle('Exit');
    if ((this.exitFroms.indexOf(exitFrom) > -1) || this.route.snapshot.params['isLockedBySomeoneElse'] === 'true') {
      this.message = 'You may close this browser tab';
    } else {
      this.message = `This ${exitFrom} has been saved. You may close this browser tab`;
    }
  }
}
