import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { NgxPaginationModule } from 'ngx-pagination';
import { CreditProjectMock } from '@tsmt/salesweb-ordersmodule';
import { PaginationComponent } from './pagination.component';

describe('PaginationComponent', () => {
  let component: PaginationComponent;
  let fixture: ComponentFixture<PaginationComponent>;
  const originReset = TestBed.resetTestingModule;
  let testData: CreditProjectMock;
  let injector: TestBed;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [PaginationComponent],
      imports: [NgxPaginationModule, FormsModule, ReactiveFormsModule],
      providers: [CreditProjectMock],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(PaginationComponent);
    testData = injector.inject(CreditProjectMock);
    component = fixture.componentInstance;
    component.paginationConfig = {
      currentPage: 1,
      itemsPerPage: 5,
    };
    component.pageSizes = [5, 10, 15, 20];
    component.Data = testData.shipToAddresses;
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should call pageChange.emit() on call of page changed in pagination`, () => {
    spyOn(component.pageChange, 'emit');
    component.pageChanged(1);
    expect(component.pageChange.emit).toHaveBeenCalled();
  });

  it(`should check whether the emit event is called on call of pageSizeChange() method`, () => {
    const pagesize = 20;
    component.paginationConfig.itemsPerPage = pagesize;
    component.paginationConfig.currentPage = 5;
    spyOn(component.pageChange, 'emit');
    component.pageSizeChange(pagesize);
    expect(component.pageChange.emit).toHaveBeenCalledWith(5);
  });

  it('should return max items of the page when getter of maxItems is called', () => {
    component.paginationConfig.currentPage = 1;
    component.paginationConfig.itemsPerPage = 5;
    component.totalItems = [2];
    expect(component.maxItems).toBe(2);
  });

  it('should show initial page size when getter of showInitialPageSize is called', () => {
    component.paginationConfig.itemsPerPage = 5;
    expect(component.showInitialPageSize).toBe(false);
  });

  it(`should return 0 if the items.length is 0 on calling the getter of currentPageText`, () => {
    component.totalItems = [];
    expect(component.currentPageText).toBe(1);
  });

  it(`should return the calculated value  if the items.length is  not equal to 0 on calling the getter of currentPageText`, () => {
    component.totalItems = [2];
    component.paginationConfig.currentPage = 2;
    component.paginationConfig.itemsPerPage = 15;
    expect(component.currentPageText).toBe(16);
  });
});
