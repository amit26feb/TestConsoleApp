import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss'],
})
export class PaginationComponent implements OnInit {
  @Input() paginationConfig;
  @Input() pageSizes;
  @Input() totalItems;
  @Input() Data;
  @Output() pageChange: EventEmitter<number> = new EventEmitter<number>();
  constructor() { }

    ngOnInit() {
    }

    pageChanged(event: any) {
        this.pageChange.emit(event);
    }

    pageSizeChange(value: any): void {
        this.paginationConfig.itemsPerPage = value;
        this.pageChange.emit(this.paginationConfig.currentPage);
    }

    public get maxItems(): number {
        return Math.min(this.paginationConfig.currentPage * this.paginationConfig.itemsPerPage, this.totalItems);
    }

    public get currentPageText(): number {
        return this.Data.length ?
            (this.paginationConfig.currentPage - 1) * this.paginationConfig.itemsPerPage + 1 : 0;
    }

    public get showInitialPageSize(): boolean {
        return (this.pageSizes)
            .filter((num) => num === Number(this.paginationConfig.itemsPerPage))
            .length === 0;
    }
}
