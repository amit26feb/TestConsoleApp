import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { DataStateChangeEvent, GridModule } from '@progress/kendo-angular-grid';
import { LayoutModule, PanelBarExpandMode } from '@progress/kendo-angular-layout';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { MultiselectFilterService } from '@tsmt/salesweb-ordersmodule';
import { IBid } from './../../../modules/jobs-list-master/models/coordinate-job.model';
import { CoordinateStatusComponent } from './coordinate-status.component';

// tslint:disable-next-line: no-big-function
describe('CoordinateStatusComponent', () => {
  let component: CoordinateStatusComponent;
  let fixture: ComponentFixture<CoordinateStatusComponent>;
  let injector: TestBed;
  let multiselectFilterService: MultiselectFilterService;
  const originReset = TestBed.resetTestingModule;
  const assignedName = 'Tyler Joseph';
  const coordinationStatus = 'Not Submitted';
  const sampleLegacyJob = {
    coordinationId: '124',
    submittedOn: '2019-10-25T03:59:20',
    coordinationStatus: 'Recordinated',
    pricingSPANumber: '346793',
    assignedTo: 'Hendrix',
    coordinator: 'Zender',
    bids: ['Escalated', 'PO 123', 'Old Bid'],
    bidDetails: [],
  };

  let testData;
  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, LayoutModule, GridModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [CoordinateStatusComponent],
      providers: [MultiselectFilterService],
    });
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(CoordinateStatusComponent);
    component = fixture.componentInstance;
    multiselectFilterService = injector.inject(MultiselectFilterService);
    testData = [{
      coordinationId: '123',
      submittedOn: '2019-11-25T03:59:20',
      coordinationStatus: 'Submitted',
      pricingSPANumber: '346793',
      assignedTo: assignedName,
      coordinator: 'Timmy',
      bids: ['New Bid', 'Base Bid', 'Old Bid'],
    },
    {
      coordinationId: '124',
      submittedOn: '2019-10-25T03:59:20',
      coordinationStatus: 'Recordinated',
      pricingSPANumber: '346793',
      assignedTo: 'Hendrix',
      coordinator: 'Zender',
      bids: ['Escalated', 'PO 123', 'Old Bid'],
    },
    ];
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show request summary and change expand mode of the panel, when a request is selected in grid', () => {
    component.showRequestSummary = false;
    const testRequest = { coordinationStatus };
    component.onSelectRequest(testRequest);
    expect(component.showRequestSummary).toBe(true);
    expect(component.selectedRequest).toBe(testRequest);
    expect(component.panelExpandMode).toBe(PanelBarExpandMode.Multiple);
  });

  it(`should not show request summary and change expand mode of the panel,
      when the selected request's coordination status is other than Not Submitted and it has no bid details`, () => {
    component.showRequestSummary = false;
    const testRequest = sampleLegacyJob;
    component.onSelectRequest(testRequest);
    expect(component.showRequestSummary).toBe(false);
    expect(component.selectedRequest).not.toBe(testRequest);
    expect(component.panelExpandMode).not.toBe(PanelBarExpandMode.Multiple);
  });

  it('should hide request summary and change expand mode of the panel, when panel is expanded', () => {
    component.data = testData;
    component.showRequestSummary = true;
    const testExpandEventData = [{ expanded: true }];
    component.onPanelStateChange(testExpandEventData);
    expect(component.showRequestSummary).toBe(false);
    expect(component.panelExpandMode).toBe(PanelBarExpandMode.Single);
  });

  it('should call mapCoordinateRequests function on page load', () => {
    component.data = testData;
    spyOn(component, 'mapCoordinateRequests');
    const dataChange: SimpleChange = { currentValue: testData } as SimpleChange;
    component.ngOnChanges({ data: dataChange });
    expect(component.mapCoordinateRequests).toHaveBeenCalled();
  });

  it('should sort the bids while mapping Coordinate Request data', () => {
    component.data = testData;
    component.mapCoordinateRequests();
    expect(component.coordinationStatusGridData[0].bids).toEqual(['Base Bid', 'New Bid', 'Old Bid']);
  });

  it('should set coordinationStatusGridData to empty if data is null', () => {
    component.data = null;
    component.mapCoordinateRequests();
    expect(component.coordinationStatusGridData).toEqual([]);
  });

  it('should populate multiselect filter options if data is not null', () => {
    component.data = testData;
    const dataChange: SimpleChange = { currentValue: testData } as SimpleChange;
    component.ngOnChanges({ data: dataChange });
    expect(component.coordinationStatusList[0].text).toEqual('Submitted');
    expect(component.coordinationStatusList[0].coordinationStatus).toEqual('Submitted');
    expect(component.assignedToList[0].text).toEqual(assignedName);
    expect(component.assignedToList[0].assignedTo).toEqual(assignedName);
    expect(component.coordinatorList[0].text).toEqual('Timmy');
    expect(component.coordinatorList[0].coordinator).toEqual('Timmy');
  });

  it('should change the filter and process data on calling dataStateChange method', () => {
    spyOn(multiselectFilterService, 'transformMultiSelectFilterObject');
    const state: DataStateChangeEvent = {
      take: 10,
      skip: 0,
      filter: {
        logic: 'and',
        filters: [{
          filters: [{ field: 'submittedOn', operator: 'gt', value: '2019-12-01T18:30:00.000Z' },
          { field: 'submittedOn', operator: 'lt', value: '2019-12-31T18:30:00.000Z' }],
          logic: 'and',
        }, {
          filters: [{
            field: 'coordinationStatus', operator: 'eq',
            value: [{ text: coordinationStatus, coordinationStatus }]
          }],
          logic: 'and',
        }],
      },
    };
    component.coordinationStatusGridData = testData;
    component.dataStateChange(state);
    expect(component.state.take).toBe(10);
    expect(component.state.skip).toBe(0);
    expect(multiselectFilterService.transformMultiSelectFilterObject).toHaveBeenCalled();
  });

  it('should not change the filter and process data on calling dataStateChange method if there are no filters', () => {
    spyOn(multiselectFilterService, 'transformMultiSelectFilterObject');
    const state: DataStateChangeEvent = {
      take: 10,
      skip: 0,
      filter: {
        logic: 'and',
        filters: [],
      },
    };
    component.coordinationStatusGridData = testData;
    component.dataStateChange(state);
    expect(component.state.take).toBe(10);
    expect(component.state.skip).toBe(0);
    expect(multiselectFilterService.transformMultiSelectFilterObject).toHaveBeenCalledTimes(0);
  });

  it('should emit data on calling coordinationStatusSelectionChange method', () => {
    const spyUpdate = spyOn(component.selectionChange, 'emit');
    component.data = testData;
    component.mapCoordinateRequests();
    component.coordinationStatusSelectionChange(component.data[0].coordinationId);
    expect(spyUpdate).toHaveBeenCalledWith(component.data[0].coordinationId);
  });

  it('should emit selected record on load if there is only one record', () => {
    const sampleData = [{
      coordinationId: '123',
      submittedOn: '2019-11-25T03:59:20',
      coordinationStatus: 'Submitted',
      pricingSPANumber: '346793',
      assignedTo: assignedName,
      coordinator: 'Timmy',
      bids: ['New Bid', 'Base Bid', 'Old Bid'],
      bidDetails: [{
        bidAlternateId: 203033,
        bidAlternateName: 'Alt Bid',
      }],
    }];
    component.data = sampleData;
    const spy = spyOn(component.selectionChange, 'emit');
    const dataChange: SimpleChange = { currentValue: sampleData } as SimpleChange;
    component.ngOnChanges({ data: dataChange });
    expect(spy).toHaveBeenCalledWith(sampleData[0]);
  });

  it('should emit panel expand event on panelStateChange if there are multiple records', () => {
    const testExpandEventData = [{ expanded: true }];
    component.data = testData;
    const spy = spyOn(component.panelExpand, 'emit');
    component.onPanelStateChange(testExpandEventData);
    expect(spy).toHaveBeenCalled();
  });

  it('should update the bids in selected request when bids are changed', () => {
    component.selectedRequest = { bids: [] };
    const bids: IBid[] = [{ bidAlternateId: 123, bidName: 'TEST BID' } as IBid,
    { bidAlternateId: 456, bidName: 'REBID' } as IBid];
    component.updatedSelectedRequestBids = bids;
    const bidsChange: SimpleChange = { currentValue: bids } as SimpleChange;
    component.ngOnChanges({ updatedSelectedRequestBids: bidsChange });
    expect(component.selectedRequest.bids).toEqual(['REBID', 'TEST BID']);
    expect(component.selectedRequest.bidsView).toEqual('REBID, TEST BID');
  });

  it('should set bids view to null if the bids are empty', () => {
    const statusRequest = { bids: ['REBID', 'TEST BID'], bidsView: 'REBID, TEST BID' };
    statusRequest.bids = [];
    component.joinBidNames(statusRequest);
    expect(statusRequest.bidsView).toEqual(null);
  });

  it('should load request with given request when loadRequestIntoView is called', () => {
    const spy = spyOn(component, 'onSelectRequest').and.callFake(() => { });
    const notSubmittedRequest = { coordinationId: 2, coordinationStatus: 'Not Submitted' };
    component.loadRequestIntoView(notSubmittedRequest);
    expect(spy).toHaveBeenCalledWith(notSubmittedRequest);
  });
});
