import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { DataStateChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { PanelBarExpandMode } from '@progress/kendo-angular-layout';
import { process, State } from '@progress/kendo-data-query';
import { MultiselectFilterService } from '@tsmt/salesweb-ordersmodule';
import { IBid } from './../../../modules/jobs-list-master/models/coordinate-job.model';

@Component({
  selector: 'app-coordinate-status',
  templateUrl: './coordinate-status.component.html',
  styleUrls: ['./coordinate-status.component.scss'],
})
export class CoordinateStatusComponent implements OnChanges {
  @Input() isDataLoading = false;
  @Input() data: any[];
  @Input() updatedSelectedRequestBids: IBid[];
  panelExpandMode = PanelBarExpandMode.Single;
  showRequestSummary = false;
  selectedRequest;
  public coordinationStatusGridData: any[];
  public statusGridData: GridDataResult;
  public pagerSettings = {
    buttonCount: 1,
    info: true,
    type: 'numeric',
    previousNext: true,
  };
  public state: State = {
    skip: 0,
    take: 10,
    filter: {
      logic: 'and',
      filters: [],
    },
  };

  public coordinationStatusFilterOptions = [];
  public coordinatorFilterOptions = [];
  public assignedToFilterOptions = [];
  public coordinationStatusList = [];
  public assignedToList = [];
  public coordinatorList = [];

  public multiselectColumns = ['coordinationStatus', 'assignedTo', 'coordinator'];
  public dateColumns = ['submittedOn'];
  @Output() selectionChange: EventEmitter<any> = new EventEmitter();
  @Output() panelExpand: EventEmitter<any> = new EventEmitter();

  constructor(private multiselectFilterService: MultiselectFilterService) { }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['data']) {
      this.mapCoordinateRequests();
    }
    if (changes['updatedSelectedRequestBids']) {
      this.updateBidsInSelectedRequest();
    }
  }

  mapCoordinateRequests() {
    this.coordinationStatusGridData = [];
    if (this.data !== null) {
      if (this.data.length === 1) {
        this.onSelectRequest(this.data[0]);
      }
      this.coordinationStatusGridData = this.data.map((item: any) => {
        if (item.submittedOn !== null) {
          item.submittedOn = new Date(item.submittedOn);
        }
        this.joinBidNames(item);
        return item;
      });
      this.buildFilterOptions();
    }
    this.statusGridData = process(this.coordinationStatusGridData, this.updateFilter());
  }

  updateBidsInSelectedRequest() {
    if (this.selectedRequest && this.updatedSelectedRequestBids) {
      this.selectedRequest.bids = this.updatedSelectedRequestBids.map((bid) => bid.bidName);
      this.joinBidNames(this.selectedRequest);
    }
  }

  joinBidNames(request) {
    if (request.bids.length !== 0) {
      request.bids.sort();
      request.bidsView = request.bids.join(', ');
    } else {
      request.bidsView = null;
    }
  }

  coordinationStatusSelectionChange(data) {
    this.selectionChange.emit(data);
  }

  onSelectRequest(data) {
    if (!(data.coordinationStatus !== 'Not Submitted' && data.bidDetails.length < 1)) {
      this.selectedRequest = data;
      this.coordinationStatusSelectionChange(this.selectedRequest);
      // To enable collapse events on the panel item
      this.panelExpandMode = PanelBarExpandMode.Multiple;
      this.showRequestSummary = true;
    }
  }

  onPanelStateChange(panelBarItems: any): void {
    if (panelBarItems[0].expanded === true) {
      if (this.data.length > 1) {
        this.panelExpand.emit();
      }
      this.showRequestSummary = false;
      // To disable collapse events on the panel item
      this.panelExpandMode = PanelBarExpandMode.Single;
    }
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    const stateCopy = this.updateFilter();
    if (this.coordinationStatusGridData !== null) {
      this.statusGridData = process(this.coordinationStatusGridData, stateCopy);
    }
  }

  updateFilter() {
    const stateCopy = JSON.parse(JSON.stringify(this.state));
    stateCopy.filter.filters.map((obj: any) => {
      if ('filters' in obj) {
        if (this.dateColumns.includes(obj.filters[0].field)) {
          obj.filters.forEach((item) => {
            item.value = new Date(item.value);
          });
        } else if (this.multiselectColumns.includes(obj.filters[0].field)) {
          obj.filters = this.multiselectFilterService.transformMultiSelectFilterObject(obj.filters[0], obj.filters[0].field);
          obj.logic = 'or';
        }
      }
    });
    return stateCopy;
  }

  buildFilterOptions() {
    this.coordinationStatusGridData.forEach((option) => {
      if (option.coordinationStatus !== ' ') {
        this.coordinationStatusFilterOptions.push(option.coordinationStatus);
      }
      if (option.assignedTo !== ' ') {
        this.assignedToFilterOptions.push(option.assignedTo);
      }
      if (option.coordinator !== ' ') {
        this.coordinatorFilterOptions.push(option.coordinator);
      }
    });

    this.coordinationStatusList = this.assignFilterValues(this.coordinationStatusFilterOptions, 'coordinationStatus');
    this.assignedToList = this.assignFilterValues(this.assignedToFilterOptions, 'assignedTo');
    this.coordinatorList = this.assignFilterValues(this.coordinatorFilterOptions, 'coordinator');
  }

  assignFilterValues(filterOptions, fieldValue) {
    const returnItem = [];
    const distinctFilterOptions = filterOptions.filter(this.getUniqueItems);
    distinctFilterOptions.forEach((item) => {
      returnItem.push({ text: item, [fieldValue]: item });
    });
    return returnItem;
  }

  getUniqueItems(value, index, self) {
    return self.indexOf(value) === index;
  }

  loadRequestIntoView(request) {
    this.onSelectRequest(request);
  }
}
