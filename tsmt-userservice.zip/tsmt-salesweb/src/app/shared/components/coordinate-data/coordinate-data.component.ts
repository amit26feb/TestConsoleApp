import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ICoordinatedJobGeneralInfo } from './../../../modules/jobs-list-master/models/coordinate-job.model';

@Component({
  selector: 'app-coordinate-data',
  templateUrl: './coordinate-data.component.html',
  styleUrls: ['./coordinate-data.component.scss'],
})
export class CoordinateDataComponent implements OnInit, OnChanges {
  public coordinateDataForm: FormGroup;
  @Input() coordinatedJobGeneralInfo: ICoordinatedJobGeneralInfo;
  @Input() pricingSpaNumber: number;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createCoordinateForm();
    this.setCoordinateFormState();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.coordinateDataForm && changes['coordinatedJobGeneralInfo']) {
    this.setCoordinateFormData();
    }
  }

  setCoordinateFormState() {
    this.coordinateDataForm.disable({ emitEvent: false });
  }
  createCoordinateForm() {
      this.coordinateDataForm = this.formBuilder.group({
        submittedOn: new FormControl(this.coordinatedJobGeneralInfo.submittedOn),
        pricingSpaNumber: new FormControl(this.pricingSpaNumber),
        status: new FormControl(this.coordinatedJobGeneralInfo.coordinationStatus),
        assignedTo: new FormControl(this.coordinatedJobGeneralInfo.assignedTo),
        coordinator: new FormControl(this.coordinatedJobGeneralInfo.coordinator),
      });
  }

  setCoordinateFormData() {
    this.coordinateDataForm.controls.submittedOn.setValue(this.coordinatedJobGeneralInfo.submittedOn);
    this.coordinateDataForm.controls.status.setValue(this.coordinatedJobGeneralInfo.coordinationStatus);
    this.coordinateDataForm.controls.assignedTo.setValue(this.coordinatedJobGeneralInfo.assignedTo);
    this.coordinateDataForm.controls.coordinator.setValue(this.coordinatedJobGeneralInfo.coordinator);
  }
}
