import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { CoordinateService } from './../../../modules/jobs-list-master/services/coordinate.service';

import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SimpleChange } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { AppConstants } from '../../constants/constants';
import { CoordinateDataComponent } from './coordinate-data.component';

describe('CoordinateDataComponent', () => {
  let component: CoordinateDataComponent;
  let fixture: ComponentFixture<CoordinateDataComponent>;
  let injector: TestBed;
  let coordinateService: CoordinateService;
  const originReset = TestBed.resetTestingModule;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [CoordinateDataComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule, HttpClientModule],
      providers: [CoordinateService, AppConstants],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(CoordinateDataComponent);
    component = fixture.componentInstance;
    coordinateService = injector.inject(CoordinateService);
    component.coordinatedJobGeneralInfo = {
      submittedOn: 'March 01/02/2020',
      coordinationStatus: 'Submitted',
      coordinator: 'Din',
      assignedTo: 'raj',
    };
    component.pricingSpaNumber = 123;
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call setCoordinateFormState in ngOnInit', () => {
    const spyEnableOrDisableForm = spyOn(component, 'setCoordinateFormState');
    component.ngOnInit();
    expect(spyEnableOrDisableForm).toHaveBeenCalled();
  });

  it('should call createCoordinateForm in ngOnInit', () => {
    const spyCreateForm = spyOn(component, 'createCoordinateForm');
    component.ngOnInit();
    expect(spyCreateForm).toHaveBeenCalled();
  });

  it('should disable form in ngOnIt', () => {
    component.ngOnInit();
    const spy = spyOn(component.coordinateDataForm, 'disable').and.callThrough();
    component.setCoordinateFormState();
    expect(component.coordinateDataForm.disabled).toBe(true);
    expect(spy).toHaveBeenCalledWith({ emitEvent: false });
  });
  it('should call setCoordinateFormData if coordinatedJobGeneralInfo is changed', () => {
    const coordinateData = {
      submittedOn: 'March 01/02/2012',
      coordinationStatus: 'Submitted',
      coordinator: 'Din',
      assignedTo: 'raj',
    };
    component.coordinatedJobGeneralInfo = coordinateData;
    const coordinatedJobGeneralInfoChange: SimpleChange = { currentValue: coordinateData, isFirstChange: () => false } as SimpleChange;
    const spyAssignForm = spyOn(component, 'setCoordinateFormData');
    component.createCoordinateForm();
    component.ngOnChanges({ coordinatedJobGeneralInfo: coordinatedJobGeneralInfoChange });
    expect(spyAssignForm).toHaveBeenCalled();
  });
  it('should define the coordinateDataForm values', () => {
    component.createCoordinateForm();
    expect(component.coordinateDataForm.controls.assignedTo).toBeDefined();
    expect(component.coordinateDataForm.controls.coordinator).toBeDefined();
    expect(component.coordinateDataForm.controls.status).toBeDefined();
    expect(component.coordinateDataForm.controls.submittedOn).toBeDefined();
    expect(component.coordinateDataForm.controls.pricingSpaNumber).toBeDefined();
  });
  it('should set the values to the coordinateDataForm while calling the setCoordinateFormData', () => {
    const coordinateData = {
      submittedOn: 'March 01/02/2019',
      coordinationStatus: 'Submitted',
      coordinator: 'Din',
      assignedTo: 'raj',
    };
    component.pricingSpaNumber = 1234;
    component.coordinatedJobGeneralInfo = coordinateData;
    const coordinatedJobGeneralInfoChange: SimpleChange = { currentValue: coordinateData, isFirstChange: () => false } as SimpleChange;
    component.createCoordinateForm();
    component.ngOnChanges({ coordinatedJobGeneralInfo: coordinatedJobGeneralInfoChange });
    expect(component.coordinateDataForm.controls.assignedTo.value).toBe('raj');
    expect(component.coordinateDataForm.controls.coordinator.value).toBe('Din');
    expect(component.coordinateDataForm.controls.status.value).toBe('Submitted');
    expect(component.coordinateDataForm.controls.submittedOn.value).toBe('March 01/02/2019');
    expect(component.coordinateDataForm.controls.pricingSpaNumber.value).toBe(1234);
  });
});
