import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GridModule } from '@progress/kendo-angular-grid';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { ApiErrorService } from '../../services/apierror.service';
import { JobEditServiceMock } from '../../test-mocks/editjobservice-mock';
import { ICoordinateDocument } from './../../../modules/jobs-list-master/models/coordinate-job.model';
import { AppConstants } from './../../constants/constants';
import { JobCoordinationMergeService } from './../../services/job-coordination-merge.service';
import { ToasterService } from './../../services/toaster.service';
import { ApiErrorServiceMock } from './../../test-mocks/apierrorservice-mock';
import { ToasterMock } from './../../test-mocks/toasterservice-mock';
import { DocumentsComponent } from './documents.component';

// tslint:disable-next-line:no-big-function
describe('DocumentsComponent', () => {
  let component: DocumentsComponent;
  let fixture: ComponentFixture<DocumentsComponent>;
  let jobService: JobsServicesService;
  let injector: TestBed;
  let apiErrorService: ApiErrorService;
  let toasterService: ToasterService;
  let jobCoordinationMergeService: JobCoordinationMergeService;
  const serverErrorMessage = 'server error';

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [GridModule, InputsModule, ReactiveFormsModule, FormsModule, HttpClientTestingModule],
      declarations: [DocumentsComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [{ provide: JobsServicesService, useClass: JobEditServiceMock },
      { provide: ApiErrorService, useClass: ApiErrorServiceMock },
      { provide: ToasterService, useClass: ToasterMock },
      {
        provide: ActivatedRoute, useValue: {
          snapshot: { params: { jobId: 1212, drAddressId: 122 } },
          fragment: Observable.of('test'),
        },
      },
        HttpClient, HttpHandler, AppConstants, JobCoordinationMergeService],
    }).compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(DocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    jobService = injector.inject(JobsServicesService);
    apiErrorService = injector.inject(ApiErrorService);
    toasterService = injector.inject(ToasterService);
    jobCoordinationMergeService = injector.inject(JobCoordinationMergeService);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should call fetchDocumentList method on calling oninit', () => {
    const spyDocumentList = spyOn(component, 'fetchDocumentList');
    component.ngOnInit();
    expect(spyDocumentList).toHaveBeenCalled();
  });

  it('should get document list on calling fetchDocumentList method', () => {
    const spy = spyOn(jobService, 'getDocumentList').and.callThrough();
    const spyJobCoordinationMergeService = spyOn(jobCoordinationMergeService, 'buildDocumentData');
    component.fetchDocumentList();
    expect(spy).toHaveBeenCalled();
    expect(component.documentListView.total).toBe(1);
    expect(component.documentListView.data[0].documentVersion).toBe('TTAdNj3cvY2zDp0XCdTTsBTu1Vfe6WgU');
    expect(component.documentListView.data[0].notes).toBe('This is mock data');
    expect(spyJobCoordinationMergeService).toHaveBeenCalled();
  });

  it('should check null return value when calling getDocumentList', () => {
    const spy = spyOn(jobService, 'getDocumentList').and.returnValue(Observable.of(null));
    component.fetchDocumentList();
    expect(spy).toHaveBeenCalled();
    expect(component.documentListView.data).toEqual([]);
    expect(component.documentListView.total).toBe(0);
  });

  it('should display error on getDocumentList failure', () => {
    const spy = spyOn(jobService, 'getDocumentList').and.returnValue(Observable.throwError({}));
    const spyError = spyOn(toasterService, 'setToaster');
    component.fetchDocumentList();
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spyError).toHaveBeenCalledWith('error', 'Internal server error');
  });

  it('should assign "skip" and "take" value on pageChange event ', () => {
    const spy = spyOn(component, 'fetchDocumentList');
    component.onPageChange({ skip: 0, take: 10 });
    expect(component.state.skip).toBe(0);
    expect(component.state.take).toBe(10);
    expect(spy).toHaveBeenCalled();
  });

  it('should set the grid pagination button count for desktop view on call of setGridProperties method', () => {
    spyOnProperty(document.documentElement, 'clientWidth', 'get').and.returnValue(800);
    spyOnProperty(window, 'innerWidth', 'get').and.returnValue(825);
    component.setGridProperties();
    expect(component.pagerSettings.buttonCount).toBe(9);
  });

  it('should set the grid pagination button count for mobile view on call of setGridProperties method', () => {
    spyOnProperty(document.documentElement, 'clientWidth', 'get').and.returnValue(300);
    spyOnProperty(window, 'innerWidth', 'get').and.returnValue(null);
    component.setGridProperties();
    expect(component.pagerSettings.buttonCount).toBe(5);
  });

  it('should call fitcolumns,updateDocumentsView on invoking fetchDocumentList', () => {
    const spy = spyOn(component, 'fitColumns');
    const spyUpdateDocumentsView = spyOn(component, 'updateDocumentsView');
    spyOn(jobCoordinationMergeService, 'buildDocumentData');
    component.fetchDocumentList();
    expect(spy).toHaveBeenCalled();
    expect(spyUpdateDocumentsView).toHaveBeenCalled();
  });

  it('should call the grid autofitcolumns method on dataUpdated method call', () => {
    component.grid = {
      data: [], autoFitColumns: () => { },
    } as any;
    const spy = spyOn(component.grid, 'autoFitColumns');
    component.dataUpdated();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call downloadDocument service method on calling downloadDocument', () => {
    component.jobId = 23778;
    component.drAddressId = 122;
    const documentKey = 'Jobs/78/26613/text.txt';
    const documentVersion = 'jI9eTNWgMHDdfqjYF4luqFld_qC7UfzY';
    const documentName = 'text.txt';
    spyOn(jobService, 'downloadDocument').and.returnValue(Observable.of({ name: 'Test.txt', file: new Blob() }));
    const dummyElement = document.createElement('a');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
    component.downloadDocument(documentKey, documentVersion, documentName);
    expect(jobService.downloadDocument).toHaveBeenCalledWith(component.drAddressId, component.jobId, documentKey,
      documentVersion, '');
  });

  it('should call error service in job service method on downloadDocument', () => {
    const documentKey = 'Jobs/78/26613/upload.txt';
    const documentVersion = 'jI9eTNWgMHDdfqjYF4luqFld_qC7UfzY';
    const documentName = 'upload.txt';
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(jobService, 'downloadDocument').and.returnValue(Observable.throwError({ error: { messages: serverErrorMessage } }));
    component.downloadDocument(documentKey, documentVersion, documentName);
    expect(apiErrorService.show).toHaveBeenCalledWith(serverErrorMessage);
  });

  it('should return false from isEventTargetOutsideComponent if the focused element is inside the component', () => {
    expect(component.isEventTargetOutsideComponent(fixture.debugElement.children[0].nativeElement)).toBe(false);
  });

  it('should return true from isEventTargetOutsideComponent if the focused element is outside the component', () => {
    expect(component.isEventTargetOutsideComponent(document.getRootNode())).toBe(true);
  });

  it('should not emit save when there is no selection change and clicked outside component', () => {
    spyOn(component.save, 'emit');
    component.handleFocusChange({ target: document.getRootNode() });
    expect(component.isEdited).toBe(false);
    expect(component.save.emit).not.toHaveBeenCalled();
  });

  it('should not emit save when document is readonly and clicked outside component', () => {
    component.isReadOnly = true;
    spyOn(component.save, 'emit');
    component.handleFocusChange({ target: document.getRootNode() });
    expect(component.isReadOnly).toBe(true);
    expect(component.save.emit).not.toHaveBeenCalled();
  });

  it('should emit save when document is not readonly,change in document selection and clicked outside component', () => {
    component.isReadOnly = false;
    component.isEdited = true;
    spyOn(component.save, 'emit');
    component.handleFocusChange({ target: document.getRootNode() });
    expect(component.save.emit).toHaveBeenCalled();
    expect(component.isEdited).toBe(false);
  });

  it('should enable additional selection when enableDocumentSelection method is called', () => {
    component.isAdditionalSelectionEnabled = false;
    component.enableDocumentSelection();
    expect(component.isAdditionalSelectionEnabled).toBe(true);
  });

  it('should build coordinate document when buildCoordinateDocument method is called', () => {
    const doc = {
      checked: true,
      documentKey: 'Jobs/78/27443/testdoc.txt',
      jobDocumentId: 123,
      uploadedDate: new Date(),
      notes: 'test notes',
      documentName: 'test doc',
      uploadedUserId: 'ccefaa',
      documentUpdateStatus: '',
      documentVersion: '1',
      documentSource: 'test source',
    };
    const coordinateDocument = component.buildCoordinateDocument(doc);
    expect(coordinateDocument).toEqual({
      documentKey: doc.documentKey,
      jobDocumentId: doc.jobDocumentId,
      uploadedDate: doc.uploadedDate,
      notes: doc.notes,
      documentName: doc.documentName,
      uploadedUserId: doc.uploadedUserId,
      documentUpdateStatus: doc.documentUpdateStatus,
    });
  });

  it('should remove deleted documents and set the update status to empty when resetDocuments is called', () => {
    const doc = {
      jobDocumentId: 1, documentUpdateStatus: component.additionalStatuses.none,
    } as ICoordinateDocument;
    const addedDocument = {
      jobDocumentId: 2, documentUpdateStatus: component.additionalStatuses.insert,
    } as ICoordinateDocument;
    const deletedDocument = {
      jobDocumentId: 3, documentUpdateStatus: component.additionalStatuses.delete,
    } as ICoordinateDocument;
    component.sharedDocuments = [doc, addedDocument, deletedDocument];
    component.resetDocuments();
    expect(component.sharedDocuments.length).toBe(2);
    expect(component.sharedDocuments.indexOf(deletedDocument)).toBe(-1);
    expect(addedDocument.documentUpdateStatus).toBe(component.additionalStatuses.none);
    expect(doc.documentUpdateStatus).toBe(component.additionalStatuses.none);
  });

  it('should set document update status as none when document is checked and additional selection is not enabled', () => {
    const doc = { documentUpdateStatus: null, documentKey: 'Jobs/78/27445/testdoc.txt' };
    component.sharedDocuments = [];
    component.isAdditionalSelectionEnabled = false;
    const saveSpy = spyOn(component, 'saveData').and.callFake(() => { });
    component.handleDocumentAddition(doc);
    expect(saveSpy).not.toHaveBeenCalled();
    expect(doc.documentUpdateStatus).toBe(component.additionalStatuses.none);
    expect(component.sharedDocuments.length).toBe(1);
    expect(component.sharedDocuments[0].documentKey).toBe(doc.documentKey);
  });

  it('should set document update status as insert when document is checked and additional selection is enabled', () => {
    const doc = { documentUpdateStatus: null, documentKey: 'Jobs/78/27145/testdoc.txt' };
    component.sharedDocuments = [];
    component.isAdditionalSelectionEnabled = true;
    const saveSpy = spyOn(component, 'saveData').and.callFake(() => { });
    component.handleDocumentAddition(doc);
    expect(saveSpy).toHaveBeenCalled();
    expect(doc.documentUpdateStatus).toBe(component.additionalStatuses.insert);
    expect(component.sharedDocuments.length).toBe(1);
    expect(component.sharedDocuments[0].documentKey).toBe(doc.documentKey);
  });

  it('should set document update status as delete when document is unchecked and additional selection is enabled', () => {
    const doc = { documentUpdateStatus: null, documentKey: 'Jobs/78/27146/testdoc.txt' } as ICoordinateDocument;
    component.sharedDocuments = [doc];
    component.isAdditionalSelectionEnabled = true;
    const saveSpy = spyOn(component, 'saveData').and.callFake(() => { });
    component.handleDocumentRemoval(doc);
    expect(saveSpy).toHaveBeenCalled();
    expect(component.sharedDocuments.length).toBe(1);
    expect(doc.documentUpdateStatus).toBe(component.additionalStatuses.delete);
  });

  it('should remove document when document is unchecked and additional selection is not enabled', () => {
    const doc = { documentUpdateStatus: null, documentKey: 'Jobs/78/27146/testdoc.txt' } as ICoordinateDocument;
    component.sharedDocuments = [doc];
    component.isAdditionalSelectionEnabled = false;
    const saveSpy = spyOn(component, 'saveData').and.callFake(() => { });
    component.handleDocumentRemoval(doc);
    expect(saveSpy).not.toHaveBeenCalled();
    expect(component.sharedDocuments.length).toBe(0);
  });

  it('should call handleDocumentAddition when a document is selected', () => {
    const doc = { checked: true, documentKey: 'Jobs/78/27417/testdoc.txt' };
    component.isReadOnly = false;
    component.isEdited = false;
    component.isAdditionalSelectionEnabled = false;
    component.sharedDocuments = [];
    const resetSpy = spyOn(component, 'resetDocuments');
    const addSpy = spyOn(component, 'handleDocumentAddition');
    component.handleDocumentSelectionChange(doc);
    expect(resetSpy).toHaveBeenCalled();
    expect(addSpy).toHaveBeenCalled();
    expect(component.isEdited).toBe(true);
  });

  it('should call handleDocumentRemoval when a document is unselected', () => {
    const doc = { checked: false, documentKey: 'Jobs/78/27419/testdoc.txt' };
    component.isReadOnly = true;
    component.isEdited = false;
    component.isAdditionalSelectionEnabled = true;
    component.sharedDocuments = [{ documentKey: 'Jobs/78/27419/testdoc.txt' } as ICoordinateDocument];
    const resetSpy = spyOn(component, 'resetDocuments');
    const removeSpy = spyOn(component, 'handleDocumentRemoval');
    component.handleDocumentSelectionChange(doc);
    expect(resetSpy).toHaveBeenCalled();
    expect(removeSpy).toHaveBeenCalled();
    expect(component.isEdited).toBe(false);
  });

  it('should set checked as true if shared document is present in that page documnet list on calling updateDocumentsView', () => {
    component.sharedDocuments = [{
      documentKey: 'job/1/123/doc2', documentName: 'doc1', jobDocumentId: 1,
      notes: 'test', uploadedDate: new Date(), uploadedUserId: 'aaa', documentUpdateStatus: '',
    }];
    component.documentListView = {
      data: [{
        checked: false, jobDocumentId: 1, documentKey: 'job/1/123/doc1', documentName: 'doc1',
      }], total: 1,
    };
    component.updateDocumentsView();
    expect(component.documentListView.data[0].checked).toEqual(true);
  });

  it('should set checked as false if shared document is not present in that page documnet list on calling updateDocumentsView', () => {
    component.sharedDocuments = [{
      documentKey: 'job/1/123/doc2', documentName: 'doc1', jobDocumentId: 1,
      notes: 'test', uploadedDate: new Date(), uploadedUserId: 'aaa', documentUpdateStatus: '',
    }];
    component.documentListView = {
      data: [{
        checked: true, jobDocumentId: 2, documentKey: 'job/1/1234/doc1', documentName: 'doc1',
      }], total: 1,
    };
    component.updateDocumentsView();
    expect(component.documentListView.data[0].checked).toEqual(false);
  });

});
