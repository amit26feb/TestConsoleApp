import { Component, ElementRef, EventEmitter, HostListener, Input, NgZone, OnInit, Output, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { State } from '@progress/kendo-data-query';
import { take } from 'rxjs/operators';
import { IDocumentDetailsList } from '../../../modules/jobs-list-master/models/document-files-model';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { ApiErrorService } from '../../services/apierror.service';
import { ToasterService } from '../../services/toaster.service';
import { AutoSaveWidget } from '../autosave-widget/autosave-widget';
import { ICoordinateDocument } from './../../../modules/jobs-list-master/models/coordinate-job.model';
import { JobCoordinationMergeService } from './../../services/job-coordination-merge.service';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss'],
})
export class DocumentsComponent extends AutoSaveWidget implements OnInit {
  documentListView: GridDataResult;
  public loading = false;
  public drAddressId: number;
  public jobId: number;
  @Input() sharedDocuments: ICoordinateDocument[] = [];
  @Input() disableAddLink: boolean;
  public pagerSettings = {
    buttonCount: 9,
    info: true,
    type: 'numeric',
    previousNext: true,
  };
  public state: State = {
    skip: 0,
    take: 10,
  };
  isAdditionalSelectionEnabled = false;
  additionalStatuses = {
    insert: 'Insertion',
    delete: 'Deletion',
    none: '',
  };
  @Output() save: EventEmitter<any> = new EventEmitter<any>();
  @ViewChild('grid') documentSection: ElementRef;
  @ViewChild('grid', { static: true }) grid: GridComponent;
  constructor(private jobService: JobsServicesService, private ngZone: NgZone,
              private jobCoordinationMergeService: JobCoordinationMergeService, private apiErrorService: ApiErrorService,
              private route: ActivatedRoute, public toasterService: ToasterService, elementRef: ElementRef) {
              super(elementRef);
               }

  ngOnInit() {
    this.jobId = +this.route.snapshot.params['jobId'];
    this.drAddressId = +this.route.snapshot.params['drAddressId'];
    this.fetchDocumentList();
    this.setGridProperties();
  }

  handleDocumentSelectionChange(changedDocument) {
    if (!this.isReadOnly || this.isAdditionalSelectionEnabled) {
      this.isEdited = !this.isAdditionalSelectionEnabled;
      this.resetDocuments();
      if (changedDocument.checked) {
        this.handleDocumentAddition(changedDocument);
      } else {
        this.handleDocumentRemoval(changedDocument);
      }
    }
  }

  resetDocuments() {
    this.sharedDocuments = this.sharedDocuments.filter((sharedDocument) => {
      return sharedDocument.documentUpdateStatus !== this.additionalStatuses.delete;
    });
    this.sharedDocuments.forEach((sharedDocument) => {
      sharedDocument.documentUpdateStatus = this.additionalStatuses.none;
    });
  }

  handleDocumentAddition(addedDocument) {
      if (this.isAdditionalSelectionEnabled) {
        addedDocument.documentUpdateStatus = this.additionalStatuses.insert;
        this.sharedDocuments.push(this.buildCoordinateDocument(addedDocument));
        this.saveData();
      } else {
        addedDocument.documentUpdateStatus = this.additionalStatuses.none;
        this.sharedDocuments.push(this.buildCoordinateDocument(addedDocument));
      }
  }

  handleDocumentRemoval(deletedDocument) {
    const index = this.sharedDocuments.findIndex((sharedDocument) => {
      return sharedDocument.documentKey === deletedDocument.documentKey;
    });
    if (index !== -1) {
      if (this.isAdditionalSelectionEnabled) {
        this.sharedDocuments[index].documentUpdateStatus = this.additionalStatuses.delete;
        this.saveData();
      } else {
        this.sharedDocuments.splice(index, 1);
      }
    }
  }

  buildCoordinateDocument(sharedDocument): ICoordinateDocument {
    return {
      jobDocumentId: sharedDocument.jobDocumentId,
      documentKey: sharedDocument.documentKey,
      uploadedDate: sharedDocument.uploadedDate,
      notes: sharedDocument.notes,
      documentName: sharedDocument.documentName,
      uploadedUserId: sharedDocument.uploadedUserId,
      documentUpdateStatus: sharedDocument.documentUpdateStatus,
    };
  }

  @HostListener('window:resize')
  @HostListener('window:orientationchange')
  setGridProperties() {
    const docWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    if (docWidth < 780) {
      this.pagerSettings.buttonCount = 5;
    } else {
      this.pagerSettings.buttonCount = 9;
    }
  }

  @HostListener('window:orientationchange')
  public dataUpdated(): void {
    if (Math.max(document.documentElement.clientWidth, window.innerWidth || 0) < 1100) {
      this.grid.autoFitColumns();
    }
  }

  fetchDocumentList(): void {
    this.loading = true;
    this.jobService.getDocumentList(this.drAddressId, this.jobId, 0, 0, this.state.skip
      , this.state.take).subscribe((res: IDocumentDetailsList) => {
        if (res !== null) {
          this.jobCoordinationMergeService.buildDocumentData(res);
          this.documentListView = {
            data: res.documentList,
            total: res.totalItemCount,
          };
          this.updateDocumentsView();
          this.fitColumns();
        } else {
          this.documentListView = {
            data: [],
            total: 0,
          };
        }
        this.loading = false;
      }, (err) => {
        this.toasterService.setToaster('error', 'Internal server error');
        this.documentListView = {
          data: [],
          total: 0,
        };
        this.loading = false;
      });
  }

  public onPageChange(event: any): void {
    this.state.skip = event.skip;
    this.state.take = event.take;
    this.fetchDocumentList();
  }

  updateDocumentsView(): void {
    if (this.documentListView.data) {
      this.documentListView.data.forEach((document) => {
        document.checked = false;
        this.sharedDocuments.forEach((sharedDocument) => {
          if (sharedDocument.jobDocumentId === document.jobDocumentId) {
            document.checked = true;
          }
        });
      });
    }
  }

  public fitColumns(): void {
    this.ngZone.onStable.asObservable().pipe(take(1)).subscribe(() => {
      this.grid.autoFitColumns();
    });
  }

  downloadDocument(documentKey, documentVersion, documentName) {
    this.jobService.downloadDocument(this.drAddressId, this.jobId, documentKey, documentVersion, '').subscribe((fileModel) => {
      const element = document.createElement('a');
      element.href = URL.createObjectURL(fileModel.file);
      element.download = documentName;
      element.click();
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  saveData() {
    const documentsToSave = JSON.parse(JSON.stringify(this.sharedDocuments));
    this.save.emit(documentsToSave);
  }

  enableDocumentSelection() {
    this.isAdditionalSelectionEnabled = true;
  }
}
