import { ChangeDetectorRef, Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { JobCoordinationValidationService } from '../../../shared/services/job-coordination-validation.service';
import { CoordinateService } from './../../../modules/jobs-list-master/services/coordinate.service';

@Component({
  selector: 'app-coordinate-submit-button',
  templateUrl: './coordinate-submit-button.component.html',
  styleUrls: ['./coordinate-submit-button.component.scss'],
})
export class CoordinateSubmitButtonComponent implements OnInit, OnDestroy, AfterViewInit {
  validationErrors: any[] = [];
  submitJobExceptions: string[] = [];
  validationErrorsSubscription: Subscription;
  shouldButtonBeDisabled = true;
  shouldDisplayBadge = false;
  showPopup = false;
  showConfirmDialog = false;
  @ViewChild('submitExceptionsBadge') submitExceptionsBadge: ElementRef;
  @ViewChild('submitExceptionsPopup') submitExceptionsPopup: ElementRef;
  constructor(private jobCoordinationValidationService: JobCoordinationValidationService,
    private coordinateService: CoordinateService,
    private changeDetector: ChangeDetectorRef) { }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event) {
    if ((this.submitExceptionsBadge) && (this.submitExceptionsBadge.nativeElement.contains(event.target))) {
      this.togglePopup();
    } else if ((this.submitExceptionsPopup) && !(this.submitExceptionsPopup.nativeElement.contains(event.target))) {
      this.showPopup = false;
    }
  }

  ngOnInit() {
    this.subscribeToValidationErrors();
  }

  ngAfterViewInit(): void {
    const officeSelectorText: HTMLElement = document.querySelector('.common-title .office-selector-text');
    if (officeSelectorText) {
      officeSelectorText.style.width = '120px';
    }
  }

  subscribeToValidationErrors(): void {
    this.validationErrorsSubscription = this.jobCoordinationValidationService.getSubmitButtonValidationErrors().subscribe((data) => {
      this.validationErrors = data;
      this.submitJobExceptions = data;
      this.updateButtonAndBadgeState();
      this.changeDetector.detectChanges();
    });
  }

  updateButtonAndBadgeState(): void {
    this.checkShipLeadTimeValidation();
    this.shouldButtonBeDisabled = this.validationErrors.length > 0;
    if (this.validationErrors.includes('isJobLockedByMe') || this.validationErrors.includes('isCoordinationStatusValid')) {
      this.shouldDisplayBadge = false;
    } else {
      this.shouldDisplayBadge = this.validationErrors.length > 0;
    }
  }

  checkShipLeadTimeValidation(): void {
    const previouslyCoordinated = this.jobCoordinationValidationService.getHasBeenPreviouslyCoordinatedFlag();
    const hasSelectionErrors = this.jobCoordinationValidationService.getHasSelectionErrors();
    if (previouslyCoordinated && !hasSelectionErrors) {
      this.removeValidationError('isShipLeadTimeValid');
    }
  }

  removeValidationError(validationError: string): void {
    const index = this.validationErrors.indexOf(validationError);
    if (index !== -1) {
      this.validationErrors.splice(index, 1);
    }
  }

  isTheOnlySubmitJobException(exception) {
    return this.validationErrors.includes(exception) && this.validationErrors.length === 1;
  }

  togglePopup() {
    this.showPopup = !this.showPopup;
  }

  getExceptionSelected(exception) {
    this.showPopup = false;
    this.jobCoordinationValidationService.setSelectedException(exception);
  }

  ngOnDestroy() {
    this.validationErrorsSubscription.unsubscribe();
  }

  submitJob() {
    this.coordinateService.setJobMarkedForSubmit(true);
  }

  handleSubmit(): void {
    if (this.submitJobExceptions.includes('isShipLeadTimeValid')) {
      this.showConfirmDialog = true;
    } else {
      this.submitJob();
    }
  }

  closeConfirmDialog() {
    this.showConfirmDialog = false;
  }

  handleSubmitWithWarnings() {
    this.closeConfirmDialog();
    this.submitJob();
  }
}
