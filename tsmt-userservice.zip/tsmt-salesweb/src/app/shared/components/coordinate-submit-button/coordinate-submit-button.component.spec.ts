import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { PopupModule } from '@progress/kendo-angular-popup';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { of } from 'rxjs';
import { CoordinateService } from './../../../modules/jobs-list-master/services/coordinate.service';
import { AppConstants } from './../../../shared/constants/constants';
import { JobCoordinationValidationService } from './../../../shared/services/job-coordination-validation.service';
import { CoordinateSubmitButtonComponent } from './coordinate-submit-button.component';

// tslint:disable-next-line: no-big-function
describe('CoordinateSubmitButtonComponent', () => {
  let component: CoordinateSubmitButtonComponent;
  let injector: TestBed;
  let fixture: ComponentFixture<CoordinateSubmitButtonComponent>;
  let jobCoordinationValidationService: JobCoordinationValidationService;
  let coordinateService: CoordinateService;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [CoordinateSubmitButtonComponent],
      imports: [HttpClientTestingModule, PopupModule, BrowserAnimationsModule, DialogModule],
      providers: [
        {
          provide: AppConstants, useValue: { API_BASE_URL_JOB: '' },
        },
        JobCoordinationValidationService,
        CoordinateService,
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(CoordinateSubmitButtonComponent);
    component = fixture.componentInstance;
    jobCoordinationValidationService = injector.inject(JobCoordinationValidationService);
    coordinateService = injector.inject(CoordinateService);
    const newElement = document.createElement('div');
    newElement.setAttribute('class', 'common-title');
    newElement.setAttribute('id', 'title');
    const newElement1 = document.createElement('div');
    newElement1.setAttribute('class', 'office-selector-text');
    newElement.appendChild(newElement1);
    document.body.appendChild(newElement);
    fixture.detectChanges();
  });

  afterEach(() => {
    document.querySelector('.common-title').remove();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch invalid button flags on ngOnInit', () => {
    const spyFetchInvalidFlags = spyOn(component, 'subscribeToValidationErrors');
    component.ngOnInit();
    expect(spyFetchInvalidFlags).toHaveBeenCalled();
  });

  it('should set style width to office selector div on calling ngAfterViewInit', () => {
    component.ngAfterViewInit();
    const officeSelectorElement: HTMLElement = document.querySelector('.common-title .office-selector-text');
    expect(officeSelectorElement.style.width).toEqual('120px');
  });

  it('should update button and button state on validation error subscription', fakeAsync(() => {
    const spyUpdateButtonAndBadgeState = spyOn(component, 'updateButtonAndBadgeState');
    const sampleData = ['isJobLockedByMe'];
    spyOn(jobCoordinationValidationService, 'getSubmitButtonValidationErrors').and.returnValue(of(sampleData));
    component.subscribeToValidationErrors();
    expect(spyUpdateButtonAndBadgeState).toHaveBeenCalled();
  }));

  it('should set shouldButtonBeDisabled to false if there are no validation errors', () => {
    const sampleFlags = [];
    component.validationErrors = sampleFlags;
    component.updateButtonAndBadgeState();
    expect(component.shouldButtonBeDisabled).toBe(false);
  });

  it('should set shouldButtonBeDisabled to true if there are validation errors', () => {
    const sampleFlags = ['isJobLockedByMe'];
    component.validationErrors = sampleFlags;
    component.updateButtonAndBadgeState();
    expect(component.shouldButtonBeDisabled).toBe(true);
  });

  it('should set shouldDisplayBadge to false if validation errors include isJobLockedByMe', () => {
    const sampleData = ['isJobLockedByMe'];
    component.validationErrors = sampleData;
    component.updateButtonAndBadgeState();
    expect(component.shouldDisplayBadge).toBe(false);
  });

  it('should set shouldDisplayBadge to false if validation errors include isCoordinationStatusValid', () => {
    component.validationErrors = ['isCoordinationStatusValid'];
    component.updateButtonAndBadgeState();
    expect(component.shouldDisplayBadge).toBe(false);
  });

  it('sould set shouldDisplayBadge to true there are validation errors other than isJobLockedByMe or isCoordinationStatusValid', () => {
    const sampleData = ['isValidBidsSelection'];
    component.validationErrors = sampleData;
    component.updateButtonAndBadgeState();
    expect(component.shouldDisplayBadge).toBe(true);
  });

  it('should remove the isShipLeadTimeValid exception if the job is previously coordinated and no selection errors', () => {
    jobCoordinationValidationService.setHasBeenPreviouslyCoordinatedFlag(true);
    jobCoordinationValidationService.setHasSelectionErrors(false);
    component.validationErrors = ['isShipLeadTimeValid'];
    component.checkShipLeadTimeValidation();
    expect(component.validationErrors).toEqual([]);
  });

  it('should not remove the isShipLeadTimeValid exception if the job is previously coordinated and selection errors are present', () => {
    jobCoordinationValidationService.setHasBeenPreviouslyCoordinatedFlag(true);
    jobCoordinationValidationService.setHasSelectionErrors(true);
    component.validationErrors = ['isShipLeadTimeValid'];
    component.checkShipLeadTimeValidation();
    expect(component.validationErrors).toEqual(['isShipLeadTimeValid']);
  });

  it('should not remove the isShipLeadTimeValid exception if the job is not previously coordinated', () => {
    jobCoordinationValidationService.setHasBeenPreviouslyCoordinatedFlag(false);
    component.validationErrors = ['isShipLeadTimeValid'];
    component.checkShipLeadTimeValidation();
    expect(component.validationErrors.length).toBe(1);
  });

  it('should return true if the given exception is the only submit job exception', () => {
    component.validationErrors = ['isShipLeadTimeValid'];
    expect(component.isTheOnlySubmitJobException('isShipLeadTimeValid')).toBe(true);
  });

  it('should return false if the given exception is not the only submit job exception', () => {
    component.validationErrors = ['isShipLeadTimeValid', 'isValidBidsSelection'];
    expect(component.isTheOnlySubmitJobException('isShipLeadTimeValid')).toBe(false);
  });

  it('should return false if the given exception is not present in the submit job exceptions', () => {
    component.validationErrors = ['isValidBidsSelection'];
    expect(component.isTheOnlySubmitJobException('isShipLeadTimeValid')).toBe(false);
  });

  it('should setJobMarkedForSubmit when submitJob method is called', () => {
    const spy = spyOn(coordinateService, 'setJobMarkedForSubmit');
    component.submitJob();
    expect(spy).toHaveBeenCalledWith(true);
  });


  it('should toggle showPopup state when togglePopup is called', () => {
    component.showPopup = false;
    component.togglePopup();
    expect(component.showPopup).toBe(true);
    component.togglePopup();
    expect(component.showPopup).toBe(false);
  });

  it('should emit exception sections on calling getExceptionSelected method', () => {
    const spyExceptionSection = spyOn(jobCoordinationValidationService, 'setSelectedException');
    const exceptionSection = 'bomNotValid';
    component.getExceptionSelected(exceptionSection);
    expect(spyExceptionSection).toHaveBeenCalledWith(exceptionSection);
  });

  it('should call togglePopup on clicking error badge', () => {
    const spyTogglePopup = spyOn(component, 'togglePopup');
    component.shouldDisplayBadge = true;
    fixture.detectChanges();
    component.onDocumentClick({
      target: document.querySelectorAll('.error-count-badge')[0],
    });
    expect(spyTogglePopup).toHaveBeenCalled();
  });

  it('should not call togglePopup on clicking outside of error badge', () => {
    const spyTogglePopup = spyOn(component, 'togglePopup');
    component.shouldDisplayBadge = true;
    fixture.detectChanges();
    component.onDocumentClick({
      target: document.querySelectorAll('.coordinate-submit-wrapper')[0],
    });
    expect(spyTogglePopup).toHaveBeenCalledTimes(0);
  });

  it('should set showPopup to false on clicking outside of poupup content or error badge', () => {
    component.showPopup = true;
    fixture.detectChanges();
    component.onDocumentClick({
      target: document.querySelectorAll('.coordinate-submit-wrapper')[0],
    });
    expect(component.showPopup).toBe(false);
  });

  it('should not set showPopup to false on clicking inside of poupup content', () => {
    component.showPopup = true;
    fixture.detectChanges();
    component.onDocumentClick({
      target: document.querySelectorAll('.popup-content')[0],
    });
    expect(component.showPopup).toBe(true);
  });

  it('should close confirmation dialog and submit job when handleSubmitWithWarnings is called', () => {
    component.showConfirmDialog = true;
    const submitSpy = spyOn(component, 'submitJob').and.callFake(() => { });
    component.handleSubmitWithWarnings();
    expect(component.showConfirmDialog).toBe(false);
    expect(submitSpy).toHaveBeenCalled();
  });

  it('should submit job if no errors when handleSubmit is called', () => {
    component.submitJobExceptions = [];
    const submitSpy = spyOn(component, 'submitJob').and.callFake(() => { });
    component.handleSubmit();
    expect(submitSpy).toHaveBeenCalled();
  });

  it('should load confirmation dialog if there are ship lead time errors when handleSubmit is called', () => {
    component.showConfirmDialog = false;
    component.submitJobExceptions = ['isShipLeadTimeValid'];
    const submitSpy = spyOn(component, 'submitJob').and.callFake(() => { });
    component.handleSubmit();
    expect(submitSpy).not.toHaveBeenCalled();
    expect(component.showConfirmDialog).toBe(true);
  });

});
