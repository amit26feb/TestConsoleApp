import { async, ComponentFixture, fakeAsync, getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { ILoaderState } from '../../../shared/model/loader-state';
import { LoaderService } from './../../services/loader.service';
import { LoaderComponent } from './loader.component';

describe('LoaderComponent', () => {
    let component: LoaderComponent;
    let fixture: ComponentFixture<LoaderComponent>;
    let injector: TestBed;
    let loaderService: LoaderService;
    const originReset = TestBed.resetTestingModule;
    configureTestSuite(() => {
        TestBed.configureTestingModule({
            declarations: [LoaderComponent],
            providers: [{ provide: LoaderService, useValue: { loaderState: Observable.of({ show: false }) } }],
        });
        injector = getTestBed();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(LoaderComponent);
        component = fixture.componentInstance;
        loaderService = injector.inject(LoaderService);
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should set the show status on ngOnint', () => {
        component.ngOnInit();
        expect(component.show).toBeFalsy();
    });
});
