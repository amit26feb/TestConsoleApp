import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ILoaderState } from '../../../shared/model/loader-state';
import { LoaderService } from '../../../shared/services/loader.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
})
export class LoaderComponent implements OnInit {
  show = true;
  private subscription: Subscription;

  constructor(private loaderservice: LoaderService) { }

  ngOnInit() {
    this.loaderservice.loaderState
      .subscribe((state: ILoaderState) => {
        this.show = state.show;
      });
  }
}
