import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { JobEditSaveService, JobSaveFormType } from './../../../modules/jobs-list-master/services/jobeditsave.service';
import { JobsServicesService } from './../../../modules/jobs-list-master/services/jobs-services.service';
import { JobEditServiceMock } from './../../test-mocks/editjobservice-mock';
import { JobNotesComponent } from './job-notes.component';

describe('JobNotesComponent', () => {
  let component: JobNotesComponent;
  let fixture: ComponentFixture<JobNotesComponent>;
  let injector: TestBed;
  const originReset = TestBed.resetTestingModule;
  const Testroutes: Routes = [
    {
      path: '**',
      component: JobNotesComponent,
    }];


  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, HttpClientTestingModule, RouterTestingModule.withRoutes(Testroutes)],
      declarations: [JobNotesComponent],
      providers: [{ provide: JobsServicesService, useClass: JobEditServiceMock }, JobEditSaveService],
    });
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(JobNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should emit form and index on ngAfterViewinit()', () => {
    const spyFormUpdate = spyOn(component.formUpdate, 'emit');
    component.ngAfterViewInit();
    expect(spyFormUpdate).toHaveBeenCalledWith({ form: component.editJobNotesForm, index: JobSaveFormType.JobNotesForm });
  });

  it('should assign formData to notes control in editJobNotesForm on calling ngOnInit', () => {
    component.formData = { noteString: 'this is sample text', jobId: 8, drAddressId: 122 };
    component.ngOnInit();
    expect(component.editJobNotesForm.controls['notes'].value).toBe(component.formData.noteString);
  });
  it('should disable the text area for the CoordinateComponent ', () => {
    component.isReadOnly = true;
    component.ngOnInit();
    expect(component.editJobNotesForm.disabled).toBe(true);
  });
  it('should not disable the text area for the JobsListComponent', () => {
    component.ngOnInit();
    expect(component.editJobNotesForm.disabled).toBe(false);
  });
});
