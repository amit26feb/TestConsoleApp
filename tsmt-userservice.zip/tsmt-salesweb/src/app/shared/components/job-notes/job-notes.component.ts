import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { IJobNotesModel } from './../../../modules/jobs-list-master/modal/job-details-edit.model';
import { JobEditSaveService, JobSaveFormType } from './../../../modules/jobs-list-master/services/jobeditsave.service';
import { JobsServicesService } from './../../../modules/jobs-list-master/services/jobs-services.service';

@Component({
  selector: 'app-job-notes',
  templateUrl: './job-notes.component.html',
  styleUrls: ['./job-notes.component.scss'],
})
export class JobNotesComponent implements OnInit, AfterViewInit {
  @Input() formData: IJobNotesModel;
  @Input() isReadOnly = false;
  editJobNotesForm: FormGroup;
  notesPayload: any;
  jobId: number;
  drAddressId: number;
  public showNotes: boolean;
  public showNotValue: boolean;
  @Output() formUpdate: EventEmitter<any> = new EventEmitter();
  constructor(private fb: FormBuilder, private jobListService: JobsServicesService,
              private route: ActivatedRoute, private jobSave: JobEditSaveService) {
  }
  ngOnInit() {
    this.editJobNotesForm = this.fb.group({
      notes: this.formData ? [this.formData.noteString] : '',
    });
    if (this.isReadOnly) {
      this.editJobNotesForm.disable();
    }
  }

  ngAfterViewInit() {
    this.formUpdate.emit({ form: this.editJobNotesForm, index: JobSaveFormType.JobNotesForm });
  }
}
