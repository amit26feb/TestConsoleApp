import { Component, EventEmitter, Input, OnChanges, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-overlay-popup',
  templateUrl: './overlay-popup.component.html',
  styleUrls: ['./overlay-popup.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class OverlayPopupComponent implements OnChanges {
  @Input() isPopupOpen: boolean;
  @Input() overlayWidth: number;
  @Input() overlayTitle: string;
  @Input() maskWidth: number;
  @Input() isPanelExpanded: any;
  @Input() panelIcon: string;
  @Output() isPopupClose = new EventEmitter();

  pageOverlay: HTMLElement;
  pageTitle: string;
  panelMaskWidth: string;
  panelIconDisplay: string;

  constructor() { }

  ngOnChanges() {
    this.closeOverlayPopup(this.isPopupOpen, this.overlayWidth);
  }

  closeOverlayPopup(isPopUpOpen: boolean, overlayWidthPercent: number) {
    this.pageOverlay = document.querySelector('#page-mask');
    this.isPopupOpen = isPopUpOpen;
    this.pageOverlay.style.width = `${overlayWidthPercent}%`;
    this.pageTitle = this.overlayTitle;
    this.panelMaskWidth = `${this.maskWidth}px`;
    this.panelIconDisplay = this.panelIcon;

    // browser scroll will be disabled when popup opens
    if (this.isPopupOpen) {
      document.querySelector('body').classList.add('page-scroll-disable');
    } else {
      document.querySelector('body').classList.remove('page-scroll-disable');
      // emits the value to the parent component
      this.isPopupClose.emit({
        popupFlag: this.isPopupOpen,
        popupWidth: `{overlayWidthPercent}%`,
      });
    }
  }
}
