import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { OverlayPopupComponent } from './overlay-popup.component';

describe('OverlayPopupComponent', () => {
  let component: OverlayPopupComponent;
  let fixture: ComponentFixture<OverlayPopupComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [OverlayPopupComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverlayPopupComponent);
    component = fixture.componentInstance;
    const newElement = document.createElement('div');
    newElement.setAttribute('id', 'page-mask');
    document.body.appendChild(newElement);
    fixture.detectChanges();
  });

  afterEach(() => {
    const newElement = document.querySelector('#page-mask');
    document.body.removeChild(newElement);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnChanges ', () => {
    const spy = spyOn(component, 'closeOverlayPopup');
    component.ngOnChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should open the overlay popup on calling openPOAddendumPopup method', () => {
    fixture.detectChanges();
    const isPanelPopupOpen = true;
    const panelPopUp = 100;
    component.closeOverlayPopup(isPanelPopupOpen, panelPopUp);
    expect(component.isPopupOpen).toBe(true);
  });

  it('should close the overlay popup on calling openPOAddendumPopup method', () => {
    fixture.detectChanges();
    const isPanelPopupOpen = false;
    const panelPopUp = 0;
    component.closeOverlayPopup(isPanelPopupOpen, panelPopUp);
    expect(component.isPopupOpen).toBe(false);
  });

  it('should not contains the browser scroll when popup is open', () => {
    const isPanelPopupOpen = true;
    const panelPopUp = 100;
    component.closeOverlayPopup(isPanelPopupOpen, panelPopUp);
    expect(document.querySelector('body').classList.contains('page-scroll-disable')).toBe(true);
  });

  it('should contains the browser scroll when popup is closed ', () => {
    const isPanelPopupOpen = false;
    const panelPopUp = 0;
    component.closeOverlayPopup(isPanelPopupOpen, panelPopUp);
    expect(document.querySelector('body').classList.contains('page-scroll-disable')).toBe(false);
  });
});
