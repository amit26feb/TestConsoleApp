import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Renderer2, Type } from '@angular/core';
import { ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, NavigationEnd, Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { OktaAuthService, OKTA_CONFIG } from '@okta/okta-angular';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { MenuModule } from '@progress/kendo-angular-menu';
import { NotificationService } from '@progress/kendo-angular-notification';
import { PopupModule } from '@progress/kendo-angular-popup';
import {
  ChangeOrderService, CreateCreditProjectService,
  CreditProjectMock, CreditProjectService, IChangeOrderSummaryModel,
  IChangeOrderSummaryPayloadModel, IPagingItem, OrderLineMock, SalesOrderService, SourceType
} from '@tsmt/salesweb-ordersmodule';
import { NonTraneService } from '@tsmt/salesweb-selectionmodule';
import { JobCoordinationValidationService } from '@tsmt/shared-acquisition-dataservices';
import { MessageCountService, ToasterService as CommonToasterService } from '@tsmt/shared-core';
import {
  CommonService as CommonServiceService, ErrorsAndWarningsPanelService, IErrorsAndWarnings,
  JobHeaderService as SharedJobHeaderService, RoleService, ValidationErrorService
} from '@tsmt/shared-core-salesweb';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { BehaviorSubject, Observable, of, Subject, Subscription, throwError } from 'rxjs';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { AppConstants } from '../../constants/constants';
import { DisplayModeEnum } from '../../enums/display-mode-enum';
import { CamContext, CamStatus, ICamExecutionStatus, ICamInput } from '../../model/cam-data-model';
import { ApiErrorService } from '../../services/apierror.service';
import { CamGatewayService } from '../../services/cam-gateway.service';
import { GlobalFilterService } from '../../services/global-filter.service';
import { JobHeaderService } from '../../services/job-header.service';
import { ToasterService } from '@tsmt/shared-core';
import { WorkflowPopupService } from '../../services/workflow-popup.service';
import { CommonServiceMock } from '../../test-mocks/commonservice-mock';
import { ToasterMock } from '../../test-mocks/toasterservice-mock';
import oktaConfig from './../../../.okta.config';
import { BidsListModel } from './../../model/bids-model';
import { HeaderComponent } from './header.component';
import { AssignSalesOrderService } from '@tsmt/shared-acquisition-dataservices';

// tslint:disable-next-line:no-big-function
describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let injector: TestBed;
  let jobHeaderService: JobHeaderService;
  let jobService: JobsServicesService;
  let router: Router;
  let activatedRoute: ActivatedRoute;
  let oktaAuth: OktaAuthService;
  let menuItem: any;
  let eventToggleNotification: Event;
  let toasterService: ToasterService;
  let jobCoordinationValidationService: JobCoordinationValidationService;
  let salesOrderService: SalesOrderService;
  let appConstants: AppConstants;
  let fService: GlobalFilterService;
  let workflowPopupService: WorkflowPopupService;
  let commonService: CommonServiceService;
  let nonTraneService: NonTraneService;
  let messageCountService: MessageCountService;
  let validationErrorService: ValidationErrorService;
  let sharedJobHeaderService: SharedJobHeaderService;
  let renderer: Renderer2;
  let errorsAndWarningsPanelService: ErrorsAndWarningsPanelService;
  let apiErrorService: ApiErrorService;
  let orderLineMock: OrderLineMock;
  let createCreditProjectService: CreateCreditProjectService;
  let creditProjectService: CreditProjectService;
  let roleService: RoleService;
  let camGatewayService: CamGatewayService;
  let enableDisableAONSpy;
  let spyEnableDisableSalesOrderDetailsSubmenu;
  let changeOrderService: ChangeOrderService;
  let assignSalesOrdersService: AssignSalesOrderService;
  let testData: CreditProjectMock;
  const subMenuContainerClass = '.sub-menu-container';
  const jobsListUrl = '/jobs-list';
  const coordinateUrl = '/jobs-list/51533/101/coordinate';
  const costForecastSubMenuUrl = '/jobs-list/30/1234/projects/CreditJobs/2345/cost-forecast/Cost';
  const testJobId = 1406;
  const testDrAddressId = 121;
  const testCreditJobNumber = 43327;
  const spyEvent = {
    preventDefault: () => { return; },
    stopPropagation: () => { return; },
  } as Event;
  const salesOrderDetails = 'Sales Order Details';
  const assignSalesOrdersRoute = 'assign-sales-orders';
  const assignSalesOrdersText = 'Assign Sales Orders';
  const testProjectBidList = [{
    bidAlternateId: 656110,
    currentBidInd: 'Y',
    bidName: 'LO',
    description: 'LO Desc',
    creditJobNumber: 'L380997',
    purchaseOrderNumber: null,
    spaNumber: null,
    sellingPrice: '',
    baseBidYesNo: 1,
    foe2CreatedOrdersInd: 'Y',
    hqtrBidAlternateId: null,
    hqtrCreditJobId: null,
    isIncludeInCoordinatedJob: true,
    creditJobId: 2130356,
    isArchivedCreditJob: true,
    isCopiedDownCreditJob: true,
    isRemnant: false,
    localCreditJobId: 48901,
    archivedCreditJobId: 156,
    isTransmitted: true,
  }];
  const basicInfoData = {
    creditProjectNumber: 'R616366',
    creditProjectName: 'Sioux Center HS Tracer SC Upgrade',
    hasPeopleSoftProjectCreated: true,
    salesPersonFirstName: 'Matthew',
    salesPersonLastName: 'Davelaar',
    transmittedDate: '2016-07-22T08:42:48',
    hasChangeOrder: false,
    bidName: 'Base Bid',
    creditJobType: 1,
    plannedShipmentContractId: 'CID00084154',
    r12ProjectNumber: 'US-H600329',
    isOracleProjectIndicator: true
  };
  const testCreateProjectBidList = [{
    bidAlternateId: 656108,
    bidName: 'LO',
    description: 'LO Desc',
    creditJobNumber: null,
    creditJobId: 2130354,
  }, {
    bidAlternateId: 656109,
    bidName: 'LO-1',
    description: 'LO Desc-1',
    creditJobNumber: null,
    creditJobId: 2130355,
  }, {
    bidAlternateId: 656110,
    bidName: 'LO-2',
    description: 'LO Desc-2',
    creditJobNumber: 'L380997',
    creditJobId: 2130356,
  }, {
    bidAlternateId: 656111,
    bidName: 'LO-3',
    description: 'LO Desc-3',
    creditJobNumber: 'L380998',
    creditJobId: 2130357,
  }] as BidsListModel[];
  const testJobSubMenu = [{
    text: 'Configure',
    disabled: false,
    route: 'configure',
    cssClass: '',
    path: '',
  },
  ];
  const originReset = TestBed.resetTestingModule;
  const event = new MouseEvent('click');
  const oktaRoutingConfig = Object.assign({
    onAuthRequired: ({ oAuth, route }) => {
      // Redirect the user to your custom login page
      router.navigate(['']);
    },
  }, oktaConfig.oidc);
  const financialMenuItems = [{ text: 'Cost', modulePath: 'cost-forecast', route: 'Cost', path: '', cssClass: '' },
  { text: 'Rebalancing', modulePath: 'Rebalancing', route: 'PriceSummary', path: '', cssClass: '' }];

  const errorData: IErrorsAndWarnings = {
    pagingItems: [{
      rootEntityName: 'Job',
      rootEntityId: '168284',
      ruleId: 21,
      ruleGroupId: 3,
      message: 'Lorem ipsum dolor sit amet',
      ruleTarget: 'CreditJob, SalesOrder',
      lastUpdatedDate: '2021-01-18T09:51:28.323Z',
      entityId: 0,
      entityName: null,
      drAddressId: 1,
      ruleContext:
        [
          {
            context: 'TRN',
            messageType: 'ERROR',
            url: 'xxxx'
          }
        ]
    }, {
      rootEntityName: 'Job',
      rootEntityId: '1682284',
      ruleId: 21,
      ruleGroupId: 3,
      message: 'Lorem ipsum dolor sit amet',
      ruleTarget: 'CreditJob, SalesOrder',
      lastUpdatedDate: '2021-01-18T09:51:28.323Z',
      entityId: 0,
      entityName: null,
      drAddressId: 1,
      ruleContext:
        [
          {
            context: 'TRN',
            messageType: 'ERROR',
            url: 'xxxx'
          }
        ]
    }],
    pageNumber: 1,
    pageSize: 50,
    totalItemCount: 2,
    pageCount: 1,
    validationCount: {
      preValidationErrorCount: 1,
      preValidationWarningCount: 1,
      totalMessageContextCount: 2,
      transmitValidationErrorCount: 0,
      transmitValidationWarningCount: 0,
      assignSalesOrderErrorCount: 0
    }
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterModule, RouterTestingModule, BrowserAnimationsModule, HttpClientTestingModule,
        DialogModule, DropDownsModule, MenuModule, ButtonsModule, PopupModule, TranslateModule.forRoot()],
      providers: [
        MessageCountService, CamGatewayService, AssignSalesOrderService, CreditProjectMock,
        { provide: 'environment', useValue: { apiUrl: 'https://test', salesWebApplicationId: 'SalesWeb' } },
        {
          provide: OKTA_CONFIG,
          useValue: oktaRoutingConfig,
        }, AppConstants,
        JobHeaderService, OktaAuthService, JobsServicesService, JobCoordinationValidationService, SalesOrderService,
        WorkflowPopupService, CommonToasterService, NotificationService, Renderer2, ApiErrorService, OrderLineMock, ChangeOrderService,
        { provide: ToasterService, useClass: ToasterMock },
        {
          provide: ActivatedRoute, useValue: {
            queryParams: of({ projectType: 'History', navFrom: 'Bids' }),
            snapshot: { params: { jobId: 12, drAddressId: 121, bidId: 12345 } },
            root: {
              children: [{ snapshot: { params: { drAddressId: 121, jobId: 12 }, data: { subMenuRoute: 'testing' } }, children: [] }],
            },
            fragment: of('test'),
          }
        },
        { provide: CommonServiceService, useClass: CommonServiceMock },
        {
          provide: Router,
          useClass: class {
            url = '/job-list';
            navigate = jasmine.createSpy('navigate');
            routerState = {
              snapshot: { url: 'error=access_denied' },
            };
            events = new Observable((observer) => {
              observer.next(new NavigationEnd(0, '/home-page-list#documents', ''));
              observer.complete();
            });
            root = { children: [{ children: [], jobsListUrl }] };
          },
        },
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      declarations: [HeaderComponent],
    });
  });

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    jobHeaderService = injector.inject(JobHeaderService);
    jobService = injector.inject(JobsServicesService);
    fService = injector.inject(GlobalFilterService);
    oktaAuth = injector.inject(OktaAuthService);
    router = injector.inject(Router);
    activatedRoute = injector.inject(ActivatedRoute);
    toasterService = injector.inject(ToasterService);
    appConstants = injector.inject(AppConstants);
    jobCoordinationValidationService = injector.inject(JobCoordinationValidationService);
    salesOrderService = injector.inject(SalesOrderService);
    orderLineMock = injector.inject(OrderLineMock);
    workflowPopupService = injector.inject(WorkflowPopupService);
    commonService = injector.inject(CommonServiceService);
    messageCountService = injector.inject(MessageCountService);
    validationErrorService = TestBed.inject(ValidationErrorService);
    sharedJobHeaderService = TestBed.inject(SharedJobHeaderService);
    renderer = fixture.componentRef.injector.get<Renderer2>(Renderer2 as Type<Renderer2>);
    errorsAndWarningsPanelService = TestBed.inject(ErrorsAndWarningsPanelService);
    apiErrorService = TestBed.inject(ApiErrorService);
    nonTraneService = injector.inject(NonTraneService);
    createCreditProjectService = injector.inject(CreateCreditProjectService);
    creditProjectService = injector.inject(CreditProjectService);
    changeOrderService = injector.inject(ChangeOrderService);
    assignSalesOrdersService = injector.inject(AssignSalesOrderService);
    testData = injector.inject(CreditProjectMock);
    eventToggleNotification = { stopPropagation: () => { } } as Event;
    spyOn(eventToggleNotification, 'stopPropagation').and.callThrough();
    component.coordinateErrorBadge = fixture.debugElement.query(By.css('#errorBadge'));
    component.selectedIndex = 0;
    document.body.innerHTML += `<div class='sub-menu-container menu' #subMenuContainer><div class='sub-menu-0'>
    <div style='width: 300px' class='sub-menu-list active' id='menu_active'>test</div><div style='width: 300px' class='sub-menu-list'>test</div>
    <div style='width: 300px' class='sub-menu-list'>test</div></div><div class='sub-menu-1'><div class='sub-menu-list'>test</div><div class='stack-container'></div>
    <div class='sub-menu-2'>
    <div style='width: 300px' class='sub-menu-list'>test</div><div style='width: 300px' class='sub-menu-list'>test</div></div>`;
    fixture.detectChanges();
    component.subMenuContainer = { nativeElement: document.querySelector(subMenuContainerClass) };
    component.menuContainer = { nativeElement: document.querySelector('.menu') };
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'General',
        route: 'general',
        cssClass: '',
        path: '',
        disable: false,
      },
      {
        text: 'Address',
        route: 'address',
        cssClass: '',
        path: '',
        disable: false,
      }];
    messageCountService.isMessagePanelOpen$.next(true);
    commonService.isPreValidationErrorOrWarningExist = new BehaviorSubject<boolean>(false);
    component.currentState = 'Edit';
    component.enableMirrorSalesOrder = false;
    commonService.carouselActiveSlideIndex.next(null);
    roleService = injector.inject(RoleService);
    roleService.isUserHasEditAccess$.next(false);
    camGatewayService = injector.inject(CamGatewayService);
    enableDisableAONSpy = spyOn(component, 'enableDisableAON');
    spyEnableDisableSalesOrderDetailsSubmenu = spyOn(component, 'enableDisableSalesOrderDetailsSubmenu');
    const idToken = {
      idToken: {
        idToken: 'abc', claims: {
          sub: '00uksgcdp2UpmxPd40x7',
          name: 'Swati Tadaka', samAccountName: 'csqwe',
          Groups: [{
            0: 'tsmt-orderservices-user-edit-test'
          }]
        },
      },
    };
    localStorage.setItem('okta-token-storage', JSON.stringify(idToken));
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set showNotification to true  and prevUrlFragment to documents when the component is created', () => {
    expect(component.showNotification).toBe(true);
    expect(component.prevUrlFragment).toEqual('documents');
  });

  it('should call okta logout on logout', () => {
    const spy = spyOn(oktaAuth, 'logout');
    component.logout();
    expect(spy).toHaveBeenCalledWith('/');
  });

  it('should check CurrentRoute and hide projects link or workpackage link', () => {
    const jobsListRoute = new NavigationEnd(1, jobsListUrl, '');
    const showNavigation = component.checkCurrentRoute(jobsListRoute);
    expect(showNavigation).toBe(true);
  });

  it('should check workPackagePropertyRoute and show workpackage properties tabs', () => {
    const workPackageRoute = new NavigationEnd(1, '/home-page-list/105/work-packages/12345/properties', '');
    const workPackagePropertiesNavigationUrl = component.workPackagePropertyRoute(workPackageRoute);
    expect(workPackagePropertiesNavigationUrl).toBe('properties');
  });

  it('should workPackagePropertyRoute return empty when url is not not ending not equal to work-properties', () => {
    const workPackageRoute = new NavigationEnd(1, jobsListUrl, '');
    const workPackagePropertiesNavigationUrl = component.workPackagePropertyRoute(workPackageRoute);
    expect(workPackagePropertiesNavigationUrl).toBe('');
  });

  it('should hide the rightmenu on document click', () => {
    component.show = true;
    fixture.detectChanges();
    component.onDocumentClick({
      target:
        document.querySelectorAll('header')[0],
    });
    expect(component.show).toBe(false);
  });


  it('should not hide the rightmenu on click in the menu and toggle button', fakeAsync(() => {
    component.show = true;
    fixture.detectChanges();
    component.onDocumentClick({
      target:
        (component.menuToggle.nativeElement) as HTMLElement,
    });
    fixture.whenStable().then(() => {
      expect(component.show).toBe(true);
    });
    component.show = true;
    fixture.detectChanges();
    component.onDocumentClick({
      target:
        (document.querySelectorAll('.preference a')[0] as HTMLElement),
    });
    fixture.whenStable().then(() => {
      expect(component.show).toBe(true);
    });
  }));

  it('should set hideExtraMenuItems to true on calling onDocumentClick', () => {
    component.hideExtraMenuItems = false;
    component.onDocumentClick({
      target:
        (component.menuToggle.nativeElement) as HTMLElement,
    });
    expect(component.hideExtraMenuItems).toBe(true);
  });

  it('showSideNav value should not change when sideNav is null', () => {
    component.showSideNav = true;
    component.sideNav = { nativeElement: component.menuToggle.nativeElement } as any;
    component.sideNavLink = { nativeElement: component.menuToggle.nativeElement };
    component.onDocumentClick({
      target:
        (component.menuToggle.nativeElement) as HTMLElement,
    });
    expect(component.showSideNav).toBe(true);
  });

  it('should call toggle with initial click', () => {
    component.show = false;
    component.toggle();
    expect(component.show).toBe(true);
  });

  it('should call toggle with after click', () => {
    component.show = true;
    component.toggle();
    expect(component.show).toBe(false);
  });

  it('should set isClickInCoordinatePopup value as true on clicking on the coordinate popup', () => {
    component.isClickInCoordinatePopup = false;
    component.setClickInCoordinatePopup();
    expect(component.isClickInCoordinatePopup).toBe(true);
  });

  it('should return true on calling checkJobSubMenuItems() when route matches', () => {
    menuItem = { text: 'Details', items: [{ route: 'test', cssClass: '' }], route: 'details', path: '/jobs-list/54/78/details' };
    expect(component.checkJobSubMenuItems(menuItem)).toBe(true);
  });

  it('should update css class on menu select and route to appropriate context based on menuItem', () => {
    spyOn(component.renderer, 'removeClass');
    const checkJobSubMenuItemsSpy = spyOn(component, 'checkJobSubMenuItems').and.callThrough();
    menuItem = { text: 'Address', route: 'address', path: 'address', cssClass: '' };
    component.onMenuSelect(menuItem);
    expect(menuItem.cssClass).toBe(' active');
    expect(component.renderer.removeClass).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith([menuItem.path],
      { queryParams: { navFrom: 'Jobs', projectType: 'History' }, relativeTo: activatedRoute });
    menuItem = { text: 'Address', route: 'details', path: 'address', cssClass: '' };
    component.onMenuSelect(menuItem);
    expect(router.navigate).toHaveBeenCalledWith([menuItem.path], { relativeTo: activatedRoute });
    menuItem = { text: 'Details', items: [{ route: 'test', cssClass: '' }], route: 'details', path: '/jobs-list/54/78/details' };
    component.onMenuSelect(menuItem);
    expect(checkJobSubMenuItemsSpy).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith(['/jobs-list/54/78/details'], { relativeTo: activatedRoute });
  });

  it('should navigate to untransmitted credit project screen when menuItem route is Edit on calling onMenuSelect method', () => {
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Credit Project',
        route: 'Edit',
        cssClass: '',
        path: 'Edit',
        disable: true,
      }];
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: 'Untransmitted' }, relativeTo: activatedRoute,
    });
  });

  it('should navigate to history credit project screen when menuItem route is history on calling onMenuSelect method', () => {
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Credit Project',
        route: DisplayModeEnum.History,
        cssClass: '',
        path: DisplayModeEnum.History,
        disable: true,
      }];

    component.projectBidList = testCreateProjectBidList;
    component.projectBidList[0].isTransmitted = false;
    component.projectBidList[0].isCopiedDownCreditJob = false;
    component.creditJobId = 1234;
    component.projectType = DisplayModeEnum.History;
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: DisplayModeEnum.History }, relativeTo: activatedRoute,
    });
  });

  it('should navigate to transmitted credit project screen when menuItem route is credit-project-details on calling onMenuSelect', () => {
    window.name = 'ProjectLanding_Transmitted';
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Credit Project',
        route: 'credit-project-details',
        cssClass: '',
        path: 'credit-project-details',
        disable: false,
      }];
    component.projectType = DisplayModeEnum.Transmitted;
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: 'Transmitted' }, relativeTo: activatedRoute,
    });
  });

  it(`should navigate to transmitted credit project screen when menuItem route is credit-project-details
  and project type is undefined on calling onMenuSelect`, () => {
    window.name = 'ProjectLanding_Transmitted';
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Credit Project',
        route: 'credit-project-details',
        cssClass: '',
        path: 'credit-project-details',
        disable: false,
      }];
    component.projectType = undefined;
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: 'Transmitted' }, relativeTo: activatedRoute,
    });
  });

  it('should hide the Nav items on orientation change', () => {
    component.hideNav();
    expect(component.show).toBe(false);
    expect(component.showSideNav).toBe(false);
  });

  it('should should update job menu paths and display menu', () => {
    component.jobSubMenu = [{
      text: 'Configure',
      disabled: false,
      route: 'configure',
      cssClass: '',
      path: '',
    },
    ];
    // need to initialize to hook up message subscriber
    component.ngOnInit();

    // execute action
    component.updateJobMenu('100/10');

    expect(component.jobSubMenu[0].path).toEqual('/jobs-list/100/10/configure');
    expect(component.jobSubMenu[0].cssClass).toEqual('');

    // should be able to test this attribute, but not passing test
    //  might be related to need to use setTimeout() to avoid the changing value detection
    // expect(component.showJobNavigation).toBe(true);
  });

  it('should hide job menu when given empty message', () => {

    // ensure navigation is displayed
    component.showJobNavigation = true;

    // need to initialize to hook up message subscriber
    component.ngOnInit();

    // execute action
    component.updateJobMenu('');

    // verify
    expect(component.showJobNavigation).toBe(false);
  });

  it('should check details page validation status when click on menu on onMenuSelect', () => {
    const spy = spyOn(toasterService, 'setToaster');
    spyOn(jobHeaderService, 'getDetailsPageValidationStatus').and.
      returnValue([true, true, false, true, true, true, true, true, true, true, true]);
    menuItem = { item: { text: 'Details', items: [{ route: 'test', cssClass: '' }], route: 'details', path: '/jobs-list/64/122/details' } };
    component.onMenuSelect(menuItem.item);
    expect(spy).toHaveBeenCalledWith('error', appConstants.JOB_DETAILS_VALIDATION_ERROR_MESSAGE);
  });

  it('should check details page validation status when click on details page sub menu on onMenuSelect', () => {
    const spy = spyOn(toasterService, 'setToaster');
    spyOn(jobHeaderService, 'getDetailsPageValidationStatus').and.
      returnValue([true, true, false, true, true, true, true, true, true, true, true]);
    menuItem = { item: { text: 'Address', route: 'details', path: '/jobs-list/154/178/details', cssClass: '' } };
    component.onMenuSelect(menuItem.item);
    expect(spy).toHaveBeenCalledWith('error', appConstants.JOB_DETAILS_VALIDATION_ERROR_MESSAGE);
  });

  it('should show dialog popup message when usere selected or dropped file and navigate details page to other page on onMenuSelect', () => {
    spyOn(toasterService, 'setToaster');
    spyOn(jobHeaderService, 'getDetailsPageValidationStatus').and.
      returnValue([true, true, true, true, false, true, true, true, true, true, true]);
    menuItem = { item: { text: 'Address', route: 'details', path: '/jobs-list/156/170/details', cssClass: '' } };
    component.onMenuSelect(menuItem.item);
    expect(component.documentsWarning).toBe(true);
  });

  it('should close dialog popup window and navigate details page to other page when click on Yes button in dialog popup' +
    'message on closeDocumentsDialog', () => {
      component.navigationPath = '/jobs-list/156/170/details';
      component.closeDocumentsDialog('yes');
      expect(component.documentsWarning).toBe(false);
      expect(router.navigate).toHaveBeenCalledWith([component.navigationPath], { relativeTo: activatedRoute });
    });
  it('should not close dialog popup window when click on Yes button on closeDocumentsDialog', () => {
    component.closeDocumentsDialog('yes');
    expect(router.navigate).toHaveBeenCalled();
  });

  it('should close dialog popup window when click on No button on closeDocumentsDialog', () => {
    component.closeDocumentsDialog('no');
    expect(component.documentsWarning).toBe(false);
  });

  it('should enable the coordinate link when there are no validation errors', fakeAsync(() => {
    component.menuItems[0].subMenuItem[0].subMenu = [{
      text: 'Coordinate',
      route: 'coordinate',
      disabled: false,
      cssClass: 'active',
      path: '',
    }];
    const validationSummary = {
      errorCount: 0,
      validEarthwise: true,
      validClassifications: true,
      validBid: true,
    };
    spyOn(jobCoordinationValidationService, 'getJobDetailsValidationSummary').and.returnValue(of(validationSummary));
    component.subscribeForCoordinateLinkValidation(false);
    tick();
    const coordinateMenuItem = component.menuItems[0].subMenuItem[0].subMenu.filter((item) => item.text === 'Coordinate')[0];
    expect(coordinateMenuItem.disabled).toBe(false);
  }));

  it('should disable the coordinate link when there are validation errors', fakeAsync(() => {
    component.menuItems[0].subMenuItem[0].subMenu = [{
      text: 'Coordinate',
      route: 'coordinate',
      disabled: false,
      cssClass: 'active',
      path: coordinateUrl,
    }];
    const validationSummary = {
      errorCount: 1,
      validEarthwise: true,
      validClassifications: false,
      validBid: true,
    };
    component.coordinateLinkValidations.validEarthwise = validationSummary.validEarthwise;
    component.coordinateLinkValidations.validClassifications = validationSummary.validClassifications;
    spyOn(jobCoordinationValidationService, 'getJobDetailsValidationSummary').and.returnValue(of(validationSummary));
    component.subscribeForCoordinateLinkValidation(false);
    tick();
    const coordinateMenuItem = component.menuItems[0].subMenuItem[0].subMenu.filter((item) => item.text === 'Coordinate')[0];
    expect(coordinateMenuItem.disabled).toBe(true);
  }));

  it('should set coordinatePopupShow to false when there are no validation errors', fakeAsync(() => {
    component.menuItems[0].subMenuItem[0].subMenu = [{
      text: 'Coordinate',
      route: 'coordinate',
      disabled: false,
      cssClass: 'active',
      path: coordinateUrl,
    }];
    component.coordinatePopupShow = true;
    const validationSummary = {
      errorCount: 0,
      validEarthwise: true,
      validClassifications: true,
      validBid: true,
    };
    spyOn(jobCoordinationValidationService, 'getJobDetailsValidationSummary').and.returnValue(of(validationSummary));
    component.subscribeForCoordinateLinkValidation(false);
    tick();
    expect(component.coordinatePopupShow).toBe(false);
  }));

  it('should return validationErrorCount + coordinateErrorCount when getErrorCount is called', () => {
    component.validationErrorCount = 1;
    component.coordinateErrorCount = 1;
    expect(component.getErrorCount()).toBe(2);
  });

  it('should open import job window on openImportJob', () => {
    const spywindow = spyOn(window, 'open');
    component.openImportJob();
    expect(spywindow).toHaveBeenCalledWith('/jobs-list/121/importjob');
  });

  it('should open upload document packages window on openUploadDocumentPackages', () => {
    const spywindow = spyOn(window, 'open');
    component.openUploadDocumentPackages();
    expect(spywindow).toHaveBeenCalledWith('/jobs-list/121/uploaddocumentpackages');
  });

  it('should set import job dialog to false when click yes in dialog box on closeImportJobDialog', () => {
    component.closeImportJobDialog('yes');
    expect(component.importJobWarning).toBe(false);
  });

  it('should disable the notification icon when the notifiation count received is zero', () => {
    messageCountService.currentMessageCount$ = new BehaviorSubject(0);
    component.ngOnInit();
    expect(component.notificationCount).toBe(0);
    expect(component.disableNotificationIcon).toBe(true);
  });

  it('should toggle notification panel on clicking bell icon or notification badge', () => {
    const spy = spyOn(messageCountService.isMessagePanelOpen$, 'next').and.callThrough();
    const spyErrorsPanel = spyOn(component, 'toggleErrorsPanel');
    component.showNotification = false;
    component.toggleNotification(eventToggleNotification);
    expect(component.showNotification).toBe(true);
    expect(eventToggleNotification.stopPropagation).toHaveBeenCalled();
    expect(spy).toHaveBeenCalled();
    expect(spyErrorsPanel).toHaveBeenCalled();
  });

  it('should toggle notification panel on clicking bell icon and delete the notification', () => {
    const spy = spyOn(messageCountService.isMessagePanelOpen$, 'next').and.callThrough();
    component.showNotification = true;
    component.toggleNotification(eventToggleNotification);
    expect(component.showNotification).toBe(false);
    expect(eventToggleNotification.stopPropagation).toHaveBeenCalled();
    expect(spy).toHaveBeenCalled();
  });

  it('should call function to show workflowpopup', () => {
    const spyWorkflow = spyOn(workflowPopupService, 'workflowPopupClickEventHandler');
    component.showWorkflowPopup();
    expect(spyWorkflow).toHaveBeenCalled();
  });

  it('should call the setDetailsMenuItems in headerService on calling the ngOninit()', () => {
    spyOn(fService, 'getOfficeSelectorList').and.returnValue(Observable.of([{
      salesOfficeName: 'Billings',
      drAddressId: 121,
      country: 'USA',
      crmIntegrationInd: 'Y',
      groupName: 'CTXDBSELECTOR',
    }]));
    const spyJobUpdateMenu = spyOn(component, 'updateJobMenu');
    component.message = '';
    component.ngOnInit();
    expect(component.showJobNavigation).toBe(false);
    jobHeaderService.setJob(1000, 20);
    component.ngOnInit();
    expect(spyJobUpdateMenu).toHaveBeenCalledWith(component.message);
    expect(component.isShowImportJob).toBe(true);
    expect(component.sideMenu[1].isShow).toBe(true);
  });

  it('should update job menu when message is set', () => {
    const spy = spyOn(component, 'updateJobMenu');
    jobHeaderService.setJob(100, 10);
    expect(spy).toHaveBeenCalledTimes(1);
    expect(spy).toHaveBeenCalledWith('100/10');
  });

  it('should toggle the css class on toggleMenu method', () => {
    const MenuElement: HTMLElement = document.querySelector('header');
    spyOn(document, 'querySelector').and.returnValue(MenuElement);
    component.toggleMenu('menu-1');
    expect(MenuElement.classList.contains('collapse')).toBe(true);
    component.toggleMenu('menu-1');
    expect(MenuElement.classList.contains('collapse')).toBe(false);
  });

  it('should call querySelector exactly once when element is null on call of toggleMenu method', () => {
    const spy = spyOn(document, 'querySelector').and.returnValue(null);
    component.toggleMenu('menu-1');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should set projectCreditJobId based on active slide index', () => {
    component.createProjectBidList = testCreateProjectBidList;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 2094617,
      isArchivedCreditJob: false,
      isCopiedDownCreditJob: false,
      isRemnant: false,
      localCreditJobId: 0,
      archivedCreditJobId: 0,
      isTransmitted: false,
    }];
    const creditJobId = component.projectBidList[0].creditJobId;
    component.ngOnInit();
    expect(component.projectCreditJobId).toBe(creditJobId);
  });

  it('should set projectCreditJobId based on active slide index when isProdOrStageEnvironment is true on calling ngOnInit()', () => {
    component.createProjectBidList = testCreateProjectBidList;
    component.isProdOrStageEnvironment = true;
    component.enableMirrorSalesOrder = false;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: 4567831,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 2094617,
      isArchivedCreditJob: false,
      isCopiedDownCreditJob: true,
      isRemnant: false,
      localCreditJobId: 123450,
      archivedCreditJobId: 0,
      isTransmitted: false,
    }];
    const hqtrCreditJobId = component.projectBidList[0].hqtrCreditJobId;
    component.ngOnInit();
    expect(component.projectCreditJobId).toBe(hqtrCreditJobId);
  });

  it('should set projectCreditJobId based on active slide index for archived credit project on calling ngOnInit()', () => {
    component.createProjectBidList = testCreateProjectBidList;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      isRemnant: false,
      creditJobId: 2094617,
      isArchivedCreditJob: true,
      isCopiedDownCreditJob: false,
      localCreditJobId: 0,
      archivedCreditJobId: 156,
      isTransmitted: false
    }];
    const creditJobId = component.projectBidList[0].archivedCreditJobId;
    component.ngOnInit();
    expect(component.projectCreditJobId).toBe(creditJobId);
  });

  it('should fetch projectBidlist data and set zeroBids as false when getCreditJobNumberList() is called', fakeAsync(() => {
    const drAddressId = 101;
    const jobId = 53653;
    const setMenuSpy = spyOn(component, 'setMenuForZeroBidsCreditProject');
    spyOn(commonService, 'getBidsList').and.callThrough();
    component.getCreditJobNumberList(drAddressId, jobId);
    tick();
    expect(commonService.getBidsList).toHaveBeenCalled();
    expect(component.projectBidList.length).toBe(1);
    expect(component.zeroBids).toBe(false);
    expect(setMenuSpy).not.toHaveBeenCalled();
  }));

  it(`should set zeroBids as true and call setMenuForZeroBidsCreditProject method when getBidsList service returns null
    on calling getCreditJobNumberList()`, fakeAsync(() => {
    const drAddressId = 101;
    const jobId = 53653;
    component.activeBidAlternateId = 1;
    const setMenuSpy = spyOn(component, 'setMenuForZeroBidsCreditProject');
    const setTriggerPreValidation = spyOn(component, 'triggerPreValidation');
    spyOn(commonService, 'getBidsList').and.returnValue(Observable.of(null));
    component.getCreditJobNumberList(drAddressId, jobId);
    expect(commonService.getBidsList).toHaveBeenCalled();
    expect(component.projectBidList).toBe(null);
    expect(setMenuSpy).toHaveBeenCalled();
    expect(component.zeroBids).toBe(true);
    expect(setTriggerPreValidation).toHaveBeenCalled();
  }));

  it(`should set value for previousCreditJobId and activeProjectBidIndex from carouselActiveSlideIndex when ngOnInit
   method is called`, () => {
    component.createProjectBidList = testCreateProjectBidList;
    component.enableMirrorSalesOrder = true;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.projectBidList = [{
      bidAlternateId: 186419,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 2094617,
      isArchivedCreditJob: true,
      isCopiedDownCreditJob: false,
      isRemnant: false,
      localCreditJobId: 123,
      archivedCreditJobId: 156,
      isTransmitted: false
    }];
    const spy = spyOn(component, 'creditProjectType');
    const spyFetchBasicInfoDetails = spyOn(component, 'fetchBasicInfoDetails');
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    const spyFetchValidationMessagesCount = spyOn(component, 'fetchValidationMessagesCount');
    component.previousCreditJobId = 2094618;
    component.ngOnInit();
    expect(component.activeProjectBidIndex).toBe(0);
    expect(component.activeBidAlternateId).toBe(12345);
    expect(component.previousCreditJobId).toBe(2094618);
    expect(spy).toHaveBeenCalled();
    expect(spyFetchBasicInfoDetails).toHaveBeenCalled();
    expect(spyEnableDisableSalesOrderDetailsSubmenu).toHaveBeenCalled();
    expect(spyPreValidation).toHaveBeenCalled();
    expect(spyFetchValidationMessagesCount).toHaveBeenCalled();
  });

  it('should set the coordinatePopupShow to false on call of toggleCoordinatePopup method with event', () => {
    component.showJobNavigation = true;
    component.coordinatePopupShow = false;
    component.toggleCoordinatePopup(event);
    expect(component.coordinatePopupShow).toBe(false);
  });

  it(`should set the coordinatePopupShow to true when toggleCoordinatePopup
   is called with event when isEventTargetContainsErrorBadge is returning true value`, () => {
    component.coordinatePopupShow = false;
    spyOn(component, 'isEventTargetContainsErrorBadge').and.returnValue(true);
    component.toggleCoordinatePopup(event);
    expect(component.coordinatePopupShow).toBe(true);
  });

  it(`should not modify the coordinatePopupShow value when toggleCoordinatePopup
   is called with event when isEventTargetContainsErrorBadge is returning false value`, () => {
    component.isClickInCoordinatePopup = true;
    component.coordinatePopupShow = true;
    spyOn(component, 'isEventTargetContainsErrorBadge').and.returnValue(false);
    component.toggleCoordinatePopup(event);
    expect(component.coordinatePopupShow).toBe(true);
  });

  it('should call setOrderServicesSubMenu method on ngOnInit()', () => {
    component.isProdOrStageEnvironment = true;
    const spy = spyOn(component, 'setOrderServicesSubMenu');
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
    component.isProdOrStageEnvironment = false;
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should disable financialMenuItems when isProdOrStageEnvironment is true on calling updateJobMenu()', () => {
    component.isProdOrStageEnvironment = true;
    component.ngOnInit();
    component.updateJobMenu('100/10');
    expect(component.financialMenuItems[1].disabled).toBe(true);
  });

  it('should set path for financialMenuItems when isProdOrStageEnvironment is false on calling updateJobMenu()', () => {
    component.isProdOrStageEnvironment = false;
    component.ngOnInit();
    component.updateJobMenu('100/10');
    expect(component.financialMenuItems[0].path).toBeDefined();
    expect(component.financialMenuItems[0].cssClass).toBeDefined();
  });

  it('should set the jobSubMenu without the work packages on call of ngOnInit', () => {
    const menuListItem = [{
      text: 'Coordinate',
      route: 'coordinate',
      disabled: false,
      cssClass: 'active',
      path: '/jobs-list/100/10/coordinate',
    },
    {
      text: 'Work Packages',
      route: 'workPackage',
      disabled: false,
      cssClass: '',
      path: '/jobs-list/51533/101/workPackage',
    }];
    const res = {
      text: 'Coordinate',
      route: 'coordinate',
      disabled: false,
      cssClass: '',
      path: '/jobs-list/100/10/coordinate',
    };
    component.isProdOrStageEnvironment = true;
    component.isProdEnvironment = true;
    component.jobSubMenu = menuListItem;
    component.ngOnInit();
    component.updateJobMenu('100/10');
    expect(component.jobSubMenu).toEqual(menuListItem);
  });

  it('should call updateHistoryRoutes on call of updateOrderServicesMenu', () => {
    component.orderServiceMenuItems = [{
      text: 'history',
      disabled: true,
      route: 'History',
      cssClass: '',
      path: 'active',
    }];
    const spy = spyOn(component, 'updateHistoryRoutes');
    component.updateOrderServicesMenu('history', 100, 100, 1000);
    expect(spy).toHaveBeenCalled();
  });

  it('should update the path of the changeorder menu item on call of updateOrderServicesMenu', () => {
    component.orderServiceMenuItems = [{
      text: 'changeorders',
      disabled: true,
      route: 'ChangeOrders',
      cssClass: '',
      path: 'css',
    }];
    component.updateOrderServicesMenu('changeorders', 100, 100, 1000);
    expect(component.orderServiceMenuItems[0].path).toBe('/jobs-list/100/1000/projects/CreditJobs/100/ChangeOrders');
  });

  it('should enable financial and orderservice submenu when isBillingSummaryScreen is false on call of updateJobMenu', () => {
    const menu = [{
      text: 'Configure',
      disabled: true,
      route: 'context1.html',
      cssClass: '',
      path: 'active',
    }];
    component.isBillingScreen = false;
    component.financialMenuItems = menu;
    component.orderServiceMenuItems = menu;
    component.projectCreditJobId = 1234;
    component.isTransmitted = true;
    component.updateJobMenu('100/10');
    expect(component.financialMenuItems[0].disabled).toBe(false);
    expect(component.orderServiceMenuItems[0].disabled).toBe(false);
  });

  it('should enable financial and orderservice submenu when isBillingSummaryScreen is true on call of updateJobMenu', () => {
    const menu = [{
      text: 'Billing',
      route: 'billing',
      cssClass: '',
      path: 'billing/30/Projects/350149/billingSummary',
      disable: false,
    }];
    component.isBillingScreen = true;
    component.financialMenuItems = menu;
    component.orderServiceMenuItems = menu;
    component.projectCreditJobId = 1234;
    component.isTransmitted = true;
    component.updateJobMenu('100/10');
    expect(component.financialMenuItems[0].disabled).toBe(false);
    expect(component.orderServiceMenuItems[0].disabled).toBe(false);
  });

  it('should call setNavigateFromUrl when updateHistoryRoutes is called with history', () => {
    const spy = spyOn(jobHeaderService, 'setNavigateFromUrl');
    component.updateHistoryRoutes('history');
    expect(spy).toHaveBeenCalled();
  });

  it('should update the path of the credit detail menu item on call of updateOrderServicesMenu', () => {
    component.isTransmitted = true;
    component.projectCreditJobId = 1234;
    component.orderServiceMenuItems = [{
      text: 'Credit Project',
      disabled: true,
      route: 'credit-project-details',
      cssClass: '',
      path: 'css',
    }];
    component.updateOrderServicesMenu('ccreditDetails', 100, 100, 1000);
    expect(component.orderServiceMenuItems[0].path).toBe('/jobs-list/100/1000/projects/CreditJobs/100/credit-project-details');
  });

  it('should update the path of the credit detail menu item on call of updateOrderServicesMenu', () => {
    component.isTransmitted = false;
    component.projectCreditJobId = 1234;
    component.isArchivedCreditJobPresent = false;
    component.orderServiceMenuItems = [{
      text: 'Credit Project',
      disabled: true,
      route: 'Edit',
      cssClass: '',
      path: 'css',
    }];
    component.updateOrderServicesMenu('Edit', 100, 100, 1000);
    expect(component.orderServiceMenuItems[0].path).toBe('/jobs-list/100/1000/projects/CreditProject/100/Edit');
  });

  it('should update the path of the credit project menu item on call of updateOrderServicesMenu', () => {
    component.isTransmitted = true;
    component.projectCreditJobId = 1234;
    component.projectBidList = testProjectBidList;
    component.orderServiceMenuItems = [{
      text: 'Credit Project',
      disabled: false,
      route: 'Edit',
      cssClass: '',
      path: 'css',
    }];
    component.updateOrderServicesMenu('Edit', 100, 100, 1000);
    expect(component.orderServiceMenuItems[0].path).toBe('/jobs-list/100/1000/projects/CreditProject/48901/Edit');
  });

  it('should update the path of the history menuitem on call of updateOrderServicesMenu', () => {
    component.orderServiceMenuItems = [{
      text: 'History',
      disabled: true,
      route: 'History',
      cssClass: '',
      path: 'css',
    }];
    component.updateOrderServicesMenu('changeorders', 100, 100, 1000);
    expect(component.orderServiceMenuItems[0].path).toBe('/jobs-list/100/1000/projects/CreditJobs/100/History');
  });

  it('should update the route of the changeorder menuitem on call of updateOrderServicesMenu', () => {
    component.orderServiceMenuItems = [{
      text: 'changeorders',
      disabled: true,
      route: 'Change Orders',
      cssClass: '',
      path: 'css',
    }];
    component.updateOrderServicesMenu('changeorders', 100, 100, 1000);
    expect(component.orderServiceMenuItems[0].route).toBe('change-orders');
  });

  it(`should disable all financial sub menus if projectCreditJobId is null
   on call of enableDisableSubMenus`, () => {
    component.projectCreditJobId = null;
    component.financialMenuItems = [{
      text: 'billing',
      disabled: true,
      route: 'billing',
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.financialMenuItems[0].disabled).toBe(true);
    expect(component.financialMenuItems[0].path).toBe('');
    expect(component.isdisabled).toBe(true);
  });

  it(`should disable all order service sub menus if projectCreditJobId is null
  on call of enableDisableSubMenus`, () => {
    component.projectCreditJobId = null;
    component.orderServiceMenuItems = [{
      text: 'credit',
      disabled: true,
      route: 'credit',
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(true);
    expect(component.orderServiceMenuItems[0].path).toBe('');
    expect(component.isdisabled).toBe(true);
  });

  it(`should enable all financial sub menus on call of enableDisableSubMenus if projectCreditJobId is not null
  or isTransmitted is true`, () => {
    component.projectCreditJobId = 1234;
    component.isTransmitted = true;
    component.financialMenuItems = [{
      text: 'billing',
      disabled: true,
      route: 'billing',
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.financialMenuItems[0].disabled).toBe(false);
    expect(component.financialMenuItems[0].path).toBe('');
  });

  it(`should enable all order service sub menus on call of enableDisableSubMenus if projectCreditJobId is not
   null or isTransmitted is true`, () => {
    component.projectCreditJobId = 1234;
    component.isTransmitted = true;
    component.orderServiceMenuItems = [{
      text: 'credit',
      disabled: true,
      route: 'credit',
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(false);
    expect(component.orderServiceMenuItems[0].path).toBe('');
  });

  it('should update the initialSlide value once initialize the carousel', () => {
    const projectCarouselConfig = component.projectMenuCarouselConfig;
    component.ngOnInit();
    component.slideConfiguration(0);
    expect(component.projectMenuCarouselConfig['initialSlide']).toBe(0);
    expect(projectCarouselConfig).not.toBe(component.projectMenuCarouselConfig);
  });

  it('should redirect to details page if there are validation errors', () => {
    const validationSummary = {
      errorCount: 1,
      validEarthwise: true,
      validClassifications: false,
      validBid: true,
    };
    const menuListItem = [{
      text: 'Coordinate',
      route: 'coordinate',
      disabled: false,
      cssClass: 'active',
      path: '/jobs-list/51533/101/coordinate',
    },
    {
      text: 'Details',
      route: 'details',
      disabled: false,
      cssClass: '',
      path: '/jobs-list/51533/101/details',
    }];
    component.menuItems[0].subMenuItem[0].subMenu = menuListItem;
    component.jobSubMenu = menuListItem;
    component.coordinateLinkValidations.validEarthwise = validationSummary.validEarthwise;
    component.coordinateLinkValidations.validClassifications = validationSummary.validClassifications;
    spyOn(jobCoordinationValidationService, 'getJobDetailsValidationSummary').and.returnValue(of(validationSummary));
    validationSummary.errorCount = 3;
    component.subscribeForCoordinateLinkValidation(true);
    expect(router.navigate).toHaveBeenCalledWith([component.jobSubMenu[1].path], { relativeTo: activatedRoute });
  });

  it(`should set isCreditJobsUrl as true and get creditJobId from the current active route url
   when the url contains CreditJobs text`, () => {
    const url = 'projects/CreditJobs/1318149';
    const currentRoute = new NavigationEnd(1, url, '');
    component.creditJobId = component.getCreditJobId(currentRoute.url);
    expect(component.creditJobId).toBe(1318149);
    expect(component.isCreditJobsUrl).toBe(true);
  });

  it(`should get creditJobId from the current active route url when the url contains CreditProject text`, () => {
    const editurl = 'projects/CreditProject/1318140';
    const currentRoute = new NavigationEnd(1, editurl, '');
    component.creditJobId = component.getCreditJobId(currentRoute.url);
    expect(component.creditJobId).toBe(1318140);
  });

  it('should set zeroBids value to be false and disableRefreshIcon as true when getCreditJobNumberList() method called and updateViewState returns history', () => {
    const drAddressId = 101;
    const jobId = 53653;
    component.disableRefreshIcon = false;
    spyOn(commonService, 'getBidsList').and.callThrough();
    spyOn(component, 'updateViewState').and.returnValue('History');
    component.getCreditJobNumberList(drAddressId, jobId);
    expect(component.zeroBids).toBe(false);
    expect(component.fromHistory).toBe(true);
    expect(component.fromHistory).toBe(true);
    expect(component.disableRefreshIcon).toBe(true);
  });

  it('should set jobId and drAddressId from the current route on setJobIdAndDrAddress', () => {
    component.setJobIdAndDrAddress(activatedRoute);
    expect(component.jobId).toBe(12);
    expect(component.drAddressId).toBe(121);
  });

  it('should set the creditProjectNumber if projectCreditJobId is present when fetchBasicInfoDetails method is called', () => {
    creditProjectService.apiBaseUrl = appConstants.API_BASE_URL_CREDIT_JOBS;
    component.projectCreditJobId = 48901;
    spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));
    component.fetchBasicInfoDetails();
    expect(component.creditProjectNumber).toBe(basicInfoData.r12ProjectNumber);
  });

  it('should not set the creditProjectNumber if projectCreditJobId is not present when fetchBasicInfoDetails method is called', () => {
    creditProjectService.apiBaseUrl = appConstants.API_BASE_URL_CREDIT_JOBS;
    component.projectCreditJobId = null;
    spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));
    component.fetchBasicInfoDetails();
    expect(component.creditProjectNumber).toBe(undefined);
  });

  it(`should set cssClass as active when route matches currentView and routing path with modulePath & route
  with creditJobId of current bid when isTransmitted is true and isCopiedDownCreditJob is false and isCostForecastScreen
  is true when updateFinancialMenuItems is called`, () => {
    const creditJobId = 1234;
    const baseUrl = `${component.jobPageList}/${testJobId}/${testDrAddressId}`;
    const creditJobsBaseUrl = `${component.jobPageList}/${testDrAddressId}/${testJobId}/projects/CreditJobs/${creditJobId}`;
    component.financialMenuItems = financialMenuItems;
    component.isTransmitted = true;
    component.isCostForecastScreen = true;
    component.projectBidList = [{ creditJobId, isCopiedDownCreditJob: false }] as BidsListModel[];
    component.updateFinancialMenuItems('Cost', testJobId, testDrAddressId, testCreditJobNumber);
    expect(component.financialMenuItems[0].cssClass).toBe('active');
    expect(component.financialMenuItems[0].path)
      .toEqual(`${creditJobsBaseUrl}/${financialMenuItems[0].modulePath}/${financialMenuItems[0].route}`);
    expect(component.financialMenuItems[1].path)
      .toEqual(`${baseUrl}/${financialMenuItems[1].modulePath}/${financialMenuItems[1].route}`);
  });

  it(`should set cssClass as active when route matches currentView and routing path with modulePath & route
  with hqtrCreditJobId of current bid when isTransmitted is true, isCopiedDownCreditJob is true and isCostForecastScreen
  is true when updateFinancialMenuItems is called`, () => {
    const hqtrCreditJobId = 1234;
    const baseUrl = `${component.jobPageList}/${testJobId}/${testDrAddressId}`;
    const creditJobsBaseUrl = `${component.jobPageList}/${testDrAddressId}/${testJobId}/projects/CreditJobs/${hqtrCreditJobId}`;
    component.financialMenuItems = financialMenuItems;
    component.isTransmitted = true;
    component.projectBidList = [{ hqtrCreditJobId, isCopiedDownCreditJob: true }] as BidsListModel[];
    component.isCostForecastScreen = true;
    component.updateFinancialMenuItems('Cost', testJobId, testDrAddressId, testCreditJobNumber);
    expect(component.financialMenuItems[0].cssClass).toBe('active');
    expect(component.financialMenuItems[0].path)
      .toEqual(`${creditJobsBaseUrl}/${financialMenuItems[0].modulePath}/${financialMenuItems[0].route}`);
    expect(component.financialMenuItems[1].path)
      .toEqual(`${baseUrl}/${financialMenuItems[1].modulePath}/${financialMenuItems[1].route}`);
  });

  it(`should set cssClass as active when route matches currentView and routing path with modulePath & route
  with CreditJobNumber when isTransmitted is false and isCopiedDownCreditJob is false and isCostForecastScreen
  is true when updateFinancialMenuItems is called`, () => {
    const baseUrl = `${component.jobPageList}/${testJobId}/${testDrAddressId}`;
    const creditJobsBaseUrl = `${component.jobPageList}/${testDrAddressId}/${testJobId}/projects/CreditJobs/${testCreditJobNumber}`;
    component.financialMenuItems = financialMenuItems;
    component.isTransmitted = false;
    component.projectBidList = [{ creditJobId: 4567, hqtrCreditJobId: 1234, isCopiedDownCreditJob: false }] as BidsListModel[];
    component.isCostForecastScreen = true;
    component.updateFinancialMenuItems('Cost', testJobId, testDrAddressId, testCreditJobNumber);
    expect(component.financialMenuItems[0].cssClass).toBe('active');
    expect(component.financialMenuItems[0].path)
      .toEqual(`${creditJobsBaseUrl}/${financialMenuItems[0].modulePath}/${financialMenuItems[0].route}`);
    expect(component.financialMenuItems[1].path)
      .toEqual(`${baseUrl}/${financialMenuItems[1].modulePath}/${financialMenuItems[1].route}`);
  });

  it(`should set cssClass as active when route matches currentView and routing path with modulePath & route
  with CreditJobNumber isCostForecastScreen is false when updateFinancialMenuItems is called`, () => {
    const baseUrl = `${component.jobPageList}/${testJobId}/${testDrAddressId}`;
    const creditJobsBaseUrl = `${component.jobPageList}/${testDrAddressId}/${testJobId}/projects/CreditJobs/${testCreditJobNumber}`;
    component.financialMenuItems = financialMenuItems;
    component.isCostForecastScreen = false;
    component.billingModulePath = 'billing';
    const menu = [
      { text: 'Cost', modulePath: 'cost-forecast', route: 'Cost', path: '', cssClass: '' },
      { text: 'Rebalancing', modulePath: 'Rebalancing', route: 'PriceSummary', path: '', cssClass: '' },
      { text: 'Billing', modulePath: 'billing', route: 'billingSummary', path: '', cssClass: '' }
    ];
    component.financialMenuItems = menu;
    component.updateFinancialMenuItems('Cost', testJobId, testDrAddressId, testCreditJobNumber);
    expect(component.financialMenuItems[0].cssClass).toBe('active');
    expect(component.financialMenuItems[0].path)
      .toEqual(`${creditJobsBaseUrl}/${component.financialMenuItems[0].modulePath}/${component.financialMenuItems[0].route}`);
    expect(component.financialMenuItems[1].path)
      .toEqual(`${baseUrl}/${component.financialMenuItems[1].modulePath}/${component.financialMenuItems[1].route}`);
    expect(component.financialMenuItems[2].path)
      .toEqual(`${creditJobsBaseUrl}/${component.financialMenuItems[2].modulePath}/${component.financialMenuItems[2].route}`);
  });

  it(`should set cssClass as active when modulePath matches currentView if isBillingSummaryScreen is true
  and routing path with modulePath is true when updateFinancialMenuItems is called`, () => {
    const baseUrl = `${component.jobPageList}/${testJobId}/${testDrAddressId}`;
    const creditJobsBaseUrl = `${component.jobPageList}/${testDrAddressId}/${testJobId}/projects/CreditJobs/${testCreditJobNumber}`;
    component.financialMenuItems = financialMenuItems;
    component.isBillingScreen = true;
    component.billingModulePath = 'billing';
    const menu = [
      { text: 'Billing', modulePath: 'billing', route: 'billingSummary', path: '', cssClass: '' }
    ];
    component.financialMenuItems = menu;
    component.updateFinancialMenuItems('billing', testJobId, testDrAddressId, testCreditJobNumber);
    expect(component.financialMenuItems[0].cssClass).toBe('active');
    expect(component.financialMenuItems[0].path)
      .toEqual(`${creditJobsBaseUrl}/${component.financialMenuItems[0].modulePath}/${component.financialMenuItems[0].route}`);
  });

  it(`should set cssClass with empty string when route doesn't match currentView when updateFinancialMenuItems is called`, () => {
    component.financialMenuItems = financialMenuItems;
    component.updateFinancialMenuItems('Test', 1406, 121, 61495);
    expect(component.financialMenuItems[0].cssClass).toBe('');
  });

  it(`should set the displaymode according to commonservice current toggle value on the call of updateViewState()`, () => {
    commonService.currentToggle = 'History';
    component.windowName = 'T123456_Credt_642346_History';
    component.updateViewState();
    expect(component.displayMode).toEqual('History');
  });

  it('should set the sub menu items if the display mode is history on call of getCreditJobNumberList()', fakeAsync(() => {
    const drAddressId = 53653;
    const jobId = 101;
    component.zeroBids = true;
    component.fromHistory = true;
    const spy = spyOn(component, 'setSubmenuItems');
    component.getCreditJobNumberList(drAddressId, jobId);
    expect(component.setSubmenuItems).toHaveBeenCalled();
  }));

  it('should get the class "hide-menu-item" for project menu item if it is a transmitted job based on bids value', fakeAsync(() => {
    component.fromHistory = false;
    component.zeroBids = true;
    component.isCreateProjectScreen = false;
    const cssClass = component.getCssClass('Project');
    spyOn(component, 'getCssClass').and.returnValue('hide-menu-item');
    expect(cssClass).toEqual('hide-menu-item');
  }));

  it('should get the class "hide-menu-item" for project menu item if it is a history transmitted job based on bids value', fakeAsync(() => {
    component.projectType = DisplayModeEnum.History;
    component.zeroBids = true;
    component.isCreateProjectScreen = false;
    const cssClass = component.getCssClass('Project');
    spyOn(component, 'getCssClass').and.returnValue('hide-menu-item');
    expect(cssClass).toEqual('hide-menu-item');
  }));

  it('should not get css class for project menu item if it is a historical job based on bids value', fakeAsync(() => {
    component.fromHistory = true;
    component.zeroBids = true;
    component.isShowPreValidation = true;
    const cssClass = component.getCssClass('Project');
    spyOn(component, 'getCssClass').and.returnValue('');
    expect(cssClass).toEqual('');
  }));

  it('should show the error count if it is a transmitted job based on error count value', fakeAsync(() => {
    component.fromHistory = false;
    const showError = component.showErrorCount('Job', 1);
    expect(showError).toEqual(true);
  }));

  it('should not show the error count if it is a historical job based on error count value', fakeAsync(() => {
    component.fromHistory = true;
    const showError = component.showErrorCount('Job', 1);
    expect(showError).toEqual(false);
  }));

  it('should not show the error count if it is a transmitted job and disableJobMenu as true based on error count value', fakeAsync(() => {
    component.fromHistory = false;
    component.disableJobMenu = true;
    const showError = component.showErrorCount('Job', 1);
    expect(showError).toEqual(false);
  }));

  it('should get the job & drAddressId when subscribe it on calling ngOnInit', () => {
    sharedJobHeaderService.setJob(12, 121);
    const expcetResult = '12/121';
    component.ngOnInit();
    sharedJobHeaderService.message.subscribe((data) => {
      expect(expcetResult).toBe(data);
    });
  });

  it('should call updateJobMenu when subscribe it on calling ngOnInit', () => {
    sharedJobHeaderService.setJob(12, 121);
    const expcetResult = '12/121';
    const spyJob = spyOn(component, 'updateJobMenu');
    component.ngOnInit();
    sharedJobHeaderService.message.subscribe((data) => {
      expect(expcetResult).toBe(data);
      expect(spyJob).toHaveBeenCalled();
    });
  });

  it('should set showJobNavigation is false when observable is empty on calling ngOnInit', () => {
    sharedJobHeaderService.setJob(null, null);
    component.ngOnInit();
    sharedJobHeaderService.message.subscribe((data) => {
      expect(component.showJobNavigation).toBe(false);
    });
  });

  it('should set showJobNavigation value from showProjectsNavigation subject on calling ngOnInit', () => {
    sharedJobHeaderService.showProjectsNavigation.next(false);
    component.ngOnInit();
    expect(component.showJobNavigation).toBe(false);
  });

  it('should get the class "hide-menu-item" for project menu item if it is isShowPreValidation as false', fakeAsync(() => {
    component.isShowPreValidation = false;
    const cssClass = component.getCssClass('Project');
    spyOn(component, 'getCssClass').and.returnValue('hide-menu-item');
    expect(cssClass).toEqual('hide-menu-item');
  }));

  it('should get the class "hide-menu-item" for job menu item if fromHistory as false and disableJobMenu as true', fakeAsync(() => {
    component.fromHistory = false;
    component.disableJobMenu = true;
    const cssClass = component.getCssClass('Job');
    spyOn(component, 'getCssClass').and.returnValue('hide-menu-item');
    expect(cssClass).toEqual('hide-menu-item');
  }));

  it('should set false for showJobNavigation on hideAndShowJobAndProjectMenu', () => {
    component.workPackageUrl = appConstants.WORKPACKAGE_PAGE.configureContainer;
    component.hideAndShowJobAndProjectMenu();
    expect(component.showJobNavigation).toBe(false);

    component.workPackageUrl = appConstants.WORKPACKAGE_PAGE.addContainer;
    component.hideAndShowJobAndProjectMenu();
    expect(component.showJobNavigation).toBe(false);

    component.workPackageUrl = appConstants.WORKPACKAGE_PAGE.createCostContainer;
    component.hideAndShowJobAndProjectMenu();
    expect(component.showJobNavigation).toBe(false);

    component.workPackageUrl = appConstants.WORKPACKAGE_PAGE.create;
    component.hideAndShowJobAndProjectMenu();
    expect(component.showJobNavigation).toBe(false);

    component.workPackageUrl = appConstants.WORKPACKAGE_PAGE.placeholderToSiteInstall;
    component.hideAndShowJobAndProjectMenu();
    expect(component.showJobNavigation).toBe(false);
  });

  it('should set false for isShowPreValidation when isWorkPackagePage is true on hideAndShowJobAndProjectMenu', () => {
    component.isWorkPackagePage = true;
    component.hideAndShowJobAndProjectMenu();
    expect(component.isShowPreValidation).toBe(false);
  });

  it('should set true for isShowPreValidation when isWorkPackagePage is false on hideAndShowJobAndProjectMenu', () => {
    component.isWorkPackagePage = false;
    component.hideAndShowJobAndProjectMenu();
    expect(component.isShowPreValidation).toBe(true);
  });

  it(`should set disableJobMenu as true and call setSubmenuItems method when isCreditJobsUrl as true
   on calling setMenuForZeroBidsCreditProject() method`, () => {
    component.isCreditJobsUrl = true;
    const menuSpy = spyOn(component, 'setSubmenuItems');
    component.setMenuForZeroBidsCreditProject();
    expect(menuSpy).toHaveBeenCalled();
    expect(component.disableJobMenu).toBe(true);
  });

  it(`should set disableJobMenu as false and should not call setSubmenuItems method when isCreditJobsUrl as false
   on calling setMenuForZeroBidsCreditProject() method`, () => {
    component.isCreditJobsUrl = false;
    const menuSpy = spyOn(component, 'setSubmenuItems');
    component.setMenuForZeroBidsCreditProject();
    expect(menuSpy).not.toHaveBeenCalled();
    expect(component.disableJobMenu).toBe(false);
  });

  it('should call defaultToggleState method on calling updateOrderServicesMenu method', () => {
    const spy = spyOn(component, 'defaultToggleState');
    component.updateOrderServicesMenu('creditDetails', 100, 100, 1000);
    expect(spy).toHaveBeenCalled();
  });

  it('should call setSelectedToggle  with Transmitted on calling defaultToggleState if currentToggle is null', () => {
    commonService.currentToggle = null;
    component.projectType = null;
    const spy = spyOn(commonService, 'setSelectedToggle');
    component.defaultToggleState();
    expect(spy).toHaveBeenCalledWith('Transmitted');
  });

  it('should not call setSelectedToggle with Transmitted on calling defaultToggleState if currentToggle is not null', () => {
    component.projectType = null;
    commonService.currentToggle = 'Transmitted';
    const spy = spyOn(commonService, 'setSelectedToggle');
    component.defaultToggleState();
    expect(spy).not.toHaveBeenCalledWith('Transmitted');
  });

  it('should call setSelectedToggle with History on calling defaultToggleState if projectType is History', () => {
    component.projectType = 'History';
    const spy = spyOn(commonService, 'setSelectedToggle');
    component.defaultToggleState();
    expect(spy).toHaveBeenCalledWith('History');
  });

  it('should not call setSelectedToggle with History on calling defaultToggleState if projectType is null', () => {
    component.projectType = null;
    const spy = spyOn(commonService, 'setSelectedToggle');
    component.defaultToggleState();
    expect(spy).not.toHaveBeenCalledWith('History');
  });

  it(`should set isTransmitted true when hqtrCreditJobId is not null or if hqtrCreditJobId is null
  and foe2CreatedOrdersInd is 'N' or hqtrBidAlternateId is not null on calling creditProjectType()`, () => {
    component.projectCreditJobId = 2130356;
    testProjectBidList[0].foe2CreatedOrdersInd = 'N';
    component.projectBidList = testProjectBidList;
    const spy = spyOn(component, 'enableDisableSubMenus');
    component.creditProjectType();
    expect(component.isTransmitted).toBe(true);
    expect(spy).toHaveBeenCalled();
  });

  it(`should set isTransmitted false when hqtrCreditJobId is null, foe2CreatedOrdersInd is 'Y' on calling creditProjectType()`, () => {
    component.projectCreditJobId = 2130356;
    testProjectBidList[0].hqtrCreditJobId = null;
    testProjectBidList[0].foe2CreatedOrdersInd = 'Y';
    component.projectBidList = testProjectBidList;
    const spy = spyOn(component, 'enableDisableSubMenus');
    component.creditProjectType();
    expect(component.isTransmitted).toBe(false);
    expect(spy).toHaveBeenCalled();
  });

  it(`should not call enableDisableSubMenus method when projectCreditJobId and projectBidList is null
   on calling creditProjectType()`, () => {
    const spy = spyOn(component, 'enableDisableSubMenus');
    component.projectCreditJobId = null;
    component.projectBidList = null;
    component.creditProjectType();
    expect(spy).not.toHaveBeenCalled();
  });

  it(`should find the active project index value which match with localCreditProject of projectBidList to creditJobId
  if isLocalCreditJob is true on calling getActiveProjectIndex()`, () => {
    component.creditJobId = 48901;
    component.isLocalCreditJob = true;
    component.projectBidList = testProjectBidList;
    component.getActiveProjectIndex(component.projectBidList, component.creditJobId);
    expect(component.activeProjectBidIndex).toBe(0);
  });

  it(`should find the active project index value which match with creditJobId of projectBidList to creditJobId
  if isHostCreditJob is true on calling getActiveProjectIndex()`, () => {
    component.creditJobId = 2130356;
    component.isHostCreditJob = true;
    component.projectBidList = testProjectBidList;
    component.getActiveProjectIndex(component.projectBidList, component.creditJobId);
    expect(component.activeProjectBidIndex).toBe(0);
  });

  it(`should find the active project index value which match with archivedCreditJobId of projectBidList to creditJobId
  if isHistoryCreditJob is true on calling getActiveProjectIndex()`, () => {
    component.creditJobId = 156;
    component.isHistoryCreditJob = true;
    component.projectBidList = testProjectBidList;
    component.getActiveProjectIndex(component.projectBidList, component.creditJobId);
    expect(component.activeProjectBidIndex).toBe(0);
  });

  it(`should highlight the active sub menu when current route and currentState are equal and
  highlightActiveSubMenu method returns true`, () => {
    component.currentState = 'credit-project-details';
    menuItem = {
      text: 'Credit Project',
      route: 'credit-project-details',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130355/credit-project-details',
      cssClass: '',
    };
    component.creditProject = 'credit-project-details';
    component.fromHistory = false;
    component.creditJobId = 2130355;
    component.projectCreditJobId = 2130355;
    component.highlightActiveSubMenu(menuItem);
    expect(component.highlightActiveSubMenu(menuItem)).toBe(true);
  });

  it(`should highlight the active sub menu when currentState contains transmitted and current route are equal and
  highlightActiveSubMenu method returns true`, () => {
    component.currentUri = `/jobs-list/101/62172/projects/CreditJobs/2130357/credit-project-details
    ?navFrom=BidsPage&projectType=Transmitted`;
    component.currentState = 'credit-project-details?navFrom=BidsPage&projectType=Transmitted';
    menuItem = {
      text: 'Credit Project',
      route: 'credit-project-details',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130357/credit-project-details',
      cssClass: '',
    };
    component.creditProject = 'credit-project-details';
    component.fromHistory = false;
    component.creditJobId = 2130357;
    component.projectCreditJobId = 2130357;
    component.highlightActiveSubMenu(menuItem);
    expect(component.highlightActiveSubMenu(menuItem)).toBe(true);
  });

  it(`should highlight the active sub menu when currentState contains Untransmitted and current route are equal and
  highlightActiveSubMenu method returns true`, () => {
    component.currentUri = `/jobs-list/101/62172/projects/CreditProject/2130356/credit-project-details
    ?navFrom=BidsPage&projectType=UnTransmitted`;
    component.currentState = 'credit-project-details?navFrom=BidsPage&projectType=Untransmitted';
    menuItem = {
      text: 'Credit Project',
      route: 'Edit',
      path: '/jobs-list/101/62172/projects/CreditProject/2130356/Edit',
      cssClass: '',
    };
    component.creditProject = 'Edit';
    component.fromHistory = false;
    component.creditJobId = 2130356;
    component.projectCreditJobId = 2130356;
    component.highlightActiveSubMenu(menuItem);
    expect(component.highlightActiveSubMenu(menuItem)).toBe(true);
  });

  it(`should set local credit job as projectCreditJobId when local credit job id is not 0 on calling highlightActiveSubMenu method`, () => {
    component.projectCreditJobId = 1130356;
    component.localCreditJobId = 2130356;
    component.highlightActiveSubMenu(menuItem);
    expect(component.projectCreditJobId).toEqual(component.localCreditJobId);
  });

  it(`should not change projectCreditJobId value when local credit job id is 0 on calling highlightActiveSubMenu method`, () => {
    component.localCreditJobId = 0;
    component.projectCreditJobId = 2130356;
    component.highlightActiveSubMenu(menuItem);
    expect(component.projectCreditJobId).toEqual(2130356);
  });

  it(`should highlight the sub menu when fromhistory is true and highlightActiveSubMenu method returns true`, () => {
    component.currentUri = `/jobs-list/101/62172/projects/CreditJobs/2130356/credit-project-details`;
    component.currentState = 'credit-project-details';
    menuItem = {
      text: 'Credit Project',
      route: 'credit-project-details',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130356/credit-project-details',
      cssClass: '',
    };
    component.creditProject = 'credit-project-details';
    component.fromHistory = true;
    component.creditJobId = 2130356;
    component.highlightActiveSubMenu(menuItem);
    expect(component.highlightActiveSubMenu(menuItem)).toBe(true);
  });

  it(`should highlight the sub menu when isUserHasOnlyCommissionSplitAccess is true and highlightActiveSubMenu method returns true`, () => {
    component.currentUri = `/jobs-list/101/62172/projects/CreditJobs/2130356/credit-project-details`;
    component.currentState = 'credit-project-details';
    menuItem = {
      text: 'Credit Project',
      route: 'credit-project-details',
      path: '/jobs-list/101/62172/CreditJobs/2130356/credit-project-details',
      cssClass: '',
    };
    component.creditProject = 'credit-project-details';
    component.fromHistory = true;
    component.creditJobId = 2130356;
    component.isUserHasOnlyCommissionSplitAccess = true;
    expect(component.highlightActiveSubMenu(menuItem)).toBe(true);
  });

  it(`should highlight disabled sub menu when highlightDisabledSubMenu method returns true`, () => {
    menuItem = {
      text: 'Billing',
      route: 'billing',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130356/billing',
      cssClass: '',
    };
    component.projectType = DisplayModeEnum.Transmitted;
    component.creditProjectName = 'Credit Project';
    component.isProdOrStageEnvironment = false;
    component.fromHistory = false;
    component.isTransmitted = false;
    component.isdisabled = true;
    component.isUntransmittedCreditProject = true;
    component.isArchivedCreditJobPresent = false;
    component.disableSubMenu = false;
    component.highlightDisabledSubMenu(menuItem);
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(true);
  });

  it(`should highlight disabled sub menu when menuItem.text is equal to salesOrderDetailsName and highlightDisabledSubMenu method returns true`, () => {
    menuItem = {
      text: salesOrderDetails,
    };
    component.projectType = DisplayModeEnum.Untransmitted;
    component.salesOrderDetailsName = salesOrderDetails;
    component.isProdOrStageEnvironment = false;
    component.fromHistory = false;
    component.isUntransmittedCreditProject = true;
    component.isTransmitted = false;
    component.isdisabled = true;
    component.isArchivedCreditJobPresent = false;
    component.enableMirrorSalesOrder = false;
    component.isCreateProjectScreen = false;
    component.highlightDisabledSubMenu(menuItem);
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(true);
  });

  it(`should highlight disabled sub menu when menuItem.text is equal to salesOrderDetailsName
      and isSalesOrderDetailsDisable is true and highlightDisabledSubMenu method returns true`, () => {
    menuItem = {
      text: salesOrderDetails,
    };
    component.projectType = DisplayModeEnum.Untransmitted;
    component.salesOrderDetailsName = salesOrderDetails;
    component.isProdOrStageEnvironment = false;
    component.fromHistory = false;
    component.isUntransmittedCreditProject = true;
    component.isTransmitted = false;
    component.isdisabled = true;
    component.isArchivedCreditJobPresent = false;
    component.enableMirrorSalesOrder = true;
    component.isSalesOrderDetailsDisable = true;
    component.isCreateProjectScreen = false;
    component.disableSubMenu = false;
    component.highlightDisabledSubMenu(menuItem);
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(true);
  });

  it(`should highlight disabled sub menu in ProdOrStageEnvironment when highlightDisabledSubMenu method returns true`, () => {
    menuItem = {
      text: 'Billing',
      route: 'billing',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130356/billing',
      cssClass: '',
    };
    component.projectType = DisplayModeEnum.Untransmitted;
    component.isProdOrStageEnvironment = true;
    component.fromHistory = false;
    component.isTransmitted = false;
    component.isdisabled = true;
    component.isArchivedCreditJobPresent = false;
    component.highlightDisabledSubMenu(menuItem);
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(true);
  });

  it(`should return true when highlightDisabledSubMenu is called and isProdOrStageEnvironment is true and
  menuItem is from financialmenuItems `, () => {
    menuItem = component.financialMenuItems[0];
    component.creditProjectName = 'Credit Project';
    component.projectType = DisplayModeEnum.Untransmitted;
    component.isProdOrStageEnvironment = true;
    component.fromHistory = false;
    component.isTransmitted = false;
    component.isdisabled = false;
    component.isArchivedCreditJobPresent = false;
    component.highlightDisabledSubMenu(menuItem);
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(true);
  });

  it(`should return false when highlightDisabledSubMenu is called and isProdOrStageEnvironment is false and
  menuItem is from financialmenuItems `, () => {
    menuItem = component.financialMenuItems[0];
    component.creditProjectName = 'Credit Project';
    component.isProdOrStageEnvironment = false;
    component.fromHistory = false;
    component.isTransmitted = false;
    component.isdisabled = false;
    component.isArchivedCreditJobPresent = false;
    component.isUserHasOnlyCommissionSplitAccess = false;
    component.highlightDisabledSubMenu(menuItem);
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(false);
  });

  it(`should set the left postion of subMenuContainer on calling setSubMenuPosition()`, () => {
    component.winWidth = 100;
    component.subMenuContainer = { nativeElement: { style: { left: 0 } } };
    component.setSubMenuPosition();
    expect(component.subMenuContainer.nativeElement.style.left).toEqual('-10px');
  });


  it('should call showErrorsAndWarningsPopup function to show errors and warnings popup', () => {
    const spyErrors = spyOn(errorsAndWarningsPanelService, 'errorsAndWarningsPanelClickEventHandler');
    component.showErrorsAndWarningsPopup();
    expect(spyErrors).toHaveBeenCalled();
  });

  it('should set showErrorsAndWarningsPanel as true when pin class is present in the pin icon', () => {
    const newElement = document.createElement('i');
    newElement.setAttribute('id', 'pinUnpinIcon');
    newElement.setAttribute('class', 'pin');
    document.body.appendChild(newElement);
    component.pinUnpinErrorsAndWarningPanel();
    sharedJobHeaderService.showErrorsAndWarningsPanel.subscribe((data) => {
      expect(true).toBe(data);
    });
    document.body.removeChild(newElement);
  });

  it('should set showErrorsAndWarningsPanel as false when unpin class is present in the pin icon', () => {
    const newElement = document.createElement('i');
    newElement.setAttribute('id', 'pinUnpinIcon');
    newElement.setAttribute('class', 'unpin');
    document.body.appendChild(newElement);
    component.pinUnpinErrorsAndWarningPanel();
    sharedJobHeaderService.showErrorsAndWarningsPanel.subscribe((data) => {
      expect(false).toBe(data);
    });
    document.body.removeChild(newElement);
  });

  it(`should show the error count if isArchivedCreditJobPresent as false based on error count value
  on calling showErrorCount()`, fakeAsync(() => {
    component.isArchivedCreditJobPresent = false;
    const showError = component.showErrorCount('Job', 1);
    expect(showError).toEqual(true);
  }));

  it(`should not show the error count if isArchivedCreditJobPresent as true based on error count value
  on calling showErrorCount()`, fakeAsync(() => {
    component.isArchivedCreditJobPresent = true;
    const showError = component.showErrorCount('Job', 1);
    expect(showError).toEqual(false);
  }));

  it(`should get the class "hide-menu-item" for job menu item if isArchivedCreditJobPresent is true and projectType is History
  on calling getCssClass()`, fakeAsync(() => {
    component.isArchivedCreditJobPresent = true;
    component.projectType = 'History';
    const cssClass = component.getCssClass('Job');
    spyOn(component, 'getCssClass').and.returnValue('hide-menu-item');
    expect(cssClass).toEqual('hide-menu-item');
  }));

  it('should not get css class for job menu item if it is a untransmitted job on calling getCssClass()', fakeAsync(() => {
    component.fromHistory = false;
    component.disableJobMenu = false;
    component.isArchivedCreditJobPresent = false;
    component.projectType = 'Untransmitted';
    const cssClass = component.getCssClass('Job');
    spyOn(component, 'getCssClass').and.returnValue('');
    expect(cssClass).toEqual('');
  }));

  it(`should set isArchivedCreditJobPresent and disableRefreshIcon as false if no history job is present when getCreditJobNumberList() is called`,
    fakeAsync(() => {
      component.fromHistory = false;
      component.isArchivedCreditJobPresent = false;
      const data = testProjectBidList;
      data[0].isArchivedCreditJob = false;
      data[0].isTransmitted = false;
      spyOn(commonService, 'getBidsList').and.returnValue(Observable.of(data));
      component.getCreditJobNumberList(testDrAddressId, testJobId);
      expect(component.isArchivedCreditJobPresent).toBe(false);
      expect(component.disableRefreshIcon).toBe(false);
    }));

  it(`should set disableRefreshIcon as true when credit jobs are transmitted with no remnant in job level and getCreditJobNumberList() is called`,
    fakeAsync(() => {
      component.fromHistory = false;
      const data = testProjectBidList;
      data[0].isTransmitted = true;
      data[0].isRemnant = false;
      data[0].isCopiedDownCreditJob = false;
      spyOn(commonService, 'getBidsList').and.returnValue(Observable.of(data));
      component.getCreditJobNumberList(testDrAddressId, testJobId);
      expect(component.disableRefreshIcon).toBe(true);
    }));

  it(`should set disableRefreshIcon as true when current credit job is transmitted with no remnant and getCreditJobNumberList() is called`,
    fakeAsync(() => {
      component.fromHistory = false;
      component.creditJobId = 2130356;
      const data = testProjectBidList;
      data[0].isTransmitted = true;
      data[0].isRemnant = false;
      spyOn(commonService, 'getBidsList').and.returnValue(Observable.of(data));
      component.getCreditJobNumberList(testDrAddressId, testJobId);
      expect(component.disableRefreshIcon).toBe(true);
    }));

  it(`should set isArchivedCreditJobPresent and disableRefreshIcon as true if history job is present when getCreditJobNumberList() is called`, fakeAsync(() => {
    component.fromHistory = false;
    component.isArchivedCreditJobPresent = false;
    component.projectBidList = testProjectBidList;
    spyOn(commonService, 'getBidsList').and.returnValue(Observable.of(testProjectBidList));
    component.projectBidList[0].isArchivedCreditJob = true;
    component.getCreditJobNumberList(testDrAddressId, testJobId);
    expect(component.isArchivedCreditJobPresent).toBe(true);
    expect(component.disableRefreshIcon).toBe(true);
  }));

  it('should set projectType as History on calling ngOnInit', () => {
    TestBed.inject(ActivatedRoute).queryParams = of({ navFrom: 'BidsPage', projectType: 'History' });
    component.ngOnInit();
    expect(component.projectType).toBe('History');
  });

  it(`should set validationMessagesCount when messageCount data is valid
  and enablePrevalidation is true on calling fetchValidationMessagesCount`, () => {
    const spy = spyOn(errorsAndWarningsPanelService, 'getValidationMessages').and.returnValue(of(errorData));
    component.drAddressId = 100;
    component.jobId = 23457;
    component.creditJobId = 11;
    component.activeBidAlternateId = 22;
    component.enablePrevalidation = true;
    const spyCount = spyOn(errorsAndWarningsPanelService, 'getValidationMessagesCount');
    component.fetchValidationMessagesCount();
    errorsAndWarningsPanelService.messageCount.next(2);
    expect(component.validationMessagesCount).toEqual(2);
    expect(spyCount).toHaveBeenCalledWith(component.drAddressId, component.jobId, [component.creditJobId, component.activeBidAlternateId]);
  });

  it('should not set validationMessagesCount when enablePrevalidation is false on calling fetchValidationMessagesCount', () => {
    component.jobId = 10;
    component.drAddressId = 10;
    component.enablePrevalidation = false;
    const spy = spyOn(errorsAndWarningsPanelService, 'getValidationMessages');
    component.fetchValidationMessagesCount();
    expect(spy).not.toHaveBeenCalled();
    expect(component.validationMessagesCount).toEqual(0);
  });

  it('should set preValidationErrorCount, preValidationWarningCount and should call isPreValidationErrorOrWarningExist when validationCount data is valid on calling fetchPreValidationErrorAndWarningCount', () => {
    const spy = spyOn(errorsAndWarningsPanelService, 'getValidationMessages').and.returnValue(errorData.validationCount);
    const spyPreValidationErrorOrWarning = spyOn(commonService.isPreValidationErrorOrWarningExist, 'next');
    component.fetchPreValidationErrorAndWarningCount();
    errorsAndWarningsPanelService.errorAndWarningCount.next(errorData.validationCount);
    expect(component.preValidationErrorCount).toEqual(1);
    expect(component.preValidationWarningCount).toEqual(1);
    expect(spyPreValidationErrorOrWarning).toHaveBeenCalledWith(true);
  });

  it('should call isPreValidationErrorOrWarningExist with false value when validationCount data is valid on calling fetchPreValidationErrorAndWarningCount', () => {
    errorData.validationCount.preValidationErrorCount = 0;
    errorData.validationCount.preValidationWarningCount = 0;
    const spyPreValidationErrorOrWarning = spyOn(commonService.isPreValidationErrorOrWarningExist, 'next');
    component.fetchPreValidationErrorAndWarningCount();
    errorsAndWarningsPanelService.errorAndWarningCount.next(errorData.validationCount);
    expect(spyPreValidationErrorOrWarning).toHaveBeenCalledWith(false);
  });

  it('should set validationMessagesCount as 0 when messageCount data is invalid on calling fetchValidationMessagesCount', () => {
    const messages: IErrorsAndWarnings = null;
    component.drAddressId = 1;
    component.jobId = 2;
    component.creditJobId = null;
    component.activeBidAlternateId = 3;
    component.enablePrevalidation = true;
    const spy = spyOn(errorsAndWarningsPanelService, 'getValidationMessagesCount');
    component.fetchValidationMessagesCount();
    expect(component.validationMessagesCount).toEqual(0);
    expect(spy).toHaveBeenCalledWith(component.drAddressId, component.jobId, [null, null]);
  });

  it('should call setSubMenuWidth on calling onMainMenuSelect when item classlist doesnt have k-state-disabled class', () => {
    spyOn(component, 'setSubMenuWidth').and.callFake(() => { });
    component.onMainMenuSelect(document.querySelector('body') as HTMLElement, 2);
    expect(component.setSubMenuWidth).toHaveBeenCalled();
  });

  it(`should call addClass when hideExtraMenuItems is false on calling toggleRemainingMenu()`, () => {
    component.selectedIndex = 1;
    component.hideExtraMenuItems = false;
    const spy = spyOn(renderer, 'addClass');
    const spyErrorsPanel = spyOn(component, 'toggleErrorsPanel');
    const clickEvent = { stopPropagation: () => { } } as Event;
    spyOn(clickEvent, 'stopPropagation');
    component.toggleRemainingMenu(clickEvent);
    expect(spy).toHaveBeenCalled();
    expect(clickEvent.stopPropagation).toHaveBeenCalled();
    expect(spyErrorsPanel).toHaveBeenCalled();
  });

  it(`should call removeClass when hideExtraMenuItems is true on calling toggleRemainingMenu()`, () => {
    component.selectedIndex = 1;
    component.hideExtraMenuItems = true;
    const clickEvent = { stopPropagation: () => { } } as Event;
    spyOn(clickEvent, 'stopPropagation');
    const spy = spyOn(renderer, 'removeClass');
    component.toggleRemainingMenu(clickEvent);
    expect(spy).toHaveBeenCalled();
    expect(clickEvent.stopPropagation).toHaveBeenCalled();
  });

  it(`should call setSubMenuPosition when setSubMenuWidth is called`, fakeAsync(() => {
    component.selectedIndex = 1;
    component.showJobNavigation = true;
    spyOn(component, 'setSubMenuPosition');
    component.setSubMenuWidth();
    tick();
    expect(component.setSubMenuPosition).toHaveBeenCalled();
  }));

  it(`should call setSubMenuPosition when setSubMenuWidth is called`, fakeAsync(() => {
    component.selectedIndex = 1;
    component.menuContainer = { nativeElement: document.querySelector(subMenuContainerClass) };
    document.querySelector('.sub-menu-1').innerHTML += '<div class=\'stack-container\'></div>';
    spyOn(component, 'setSubMenuPosition');
    spyOn(renderer, 'appendChild').and.callFake(() => { });
    component.setSubMenuWidth();
    tick();
    expect(component.setSubMenuPosition).toHaveBeenCalled();
  }));

  it(`should call appendChild on renderer when setSubMenuWidth is called for submenu with
  items width exceeding max width`, fakeAsync(() => {
    component.selectedIndex = 2;
    component.menuContainer = { nativeElement: document.querySelector(subMenuContainerClass) };
    const spy = spyOn(renderer, 'appendChild');
    component.setSubMenuWidth();
    tick();
    expect(spy).toHaveBeenCalled();
  }));

  it('should set validationMessagesCount as 0 when drAddressId is invalid on calling fetchValidationMessagesCount', () => {
    component.drAddressId = 0;
    const spy = spyOn(errorsAndWarningsPanelService, 'getValidationMessages');
    component.fetchValidationMessagesCount();
    expect(spy).not.toHaveBeenCalled();
    expect(component.validationMessagesCount).toEqual(0);
  });

  it('should set validationMessagesCount as 0 when jobId is invalid on calling fetchValidationMessagesCount', () => {
    component.jobId = 0;
    const spy = spyOn(errorsAndWarningsPanelService, 'getValidationMessages');
    component.fetchValidationMessagesCount();
    expect(spy).not.toHaveBeenCalled();
    expect(component.validationMessagesCount).toEqual(0);
  });

  it('should set validationMessagesCount as 0 when jobId,drAddressId is invalid on calling fetchValidationMessagesCount', () => {
    component.jobId = 0;
    component.drAddressId = 0;
    const spy = spyOn(errorsAndWarningsPanelService, 'getValidationMessages');
    component.fetchValidationMessagesCount();
    expect(spy).not.toHaveBeenCalled();
    expect(component.validationMessagesCount).toEqual(0);
  });

  it(`should make isHistoryCreditJob true if url includes credit-project-details and currentToggle is History
   on calling findCreditJobState`, () => {
    commonService.currentToggle = 'History';
    component.isHistoryCreditJob = false;
    component.findCreditJobState('jobList/122/23457/credit-project-details');
    expect(component.isHistoryCreditJob).toBe(true);
  });

  it(`should make isHistoryCreditJob true if url includes History on calling findCreditJobState`, () => {
    component.isHistoryCreditJob = false;
    component.findCreditJobState('jobList/122/23457/History?navFrom=ProjectLanding&ProjectType=History');
    expect(component.isHistoryCreditJob).toBe(true);
  });

  it(`should make isLocalCreditJob true if url includes Edit on calling findCreditJobState`, () => {
    component.isLocalCreditJob = false;
    component.findCreditJobState('jobList/122/23457/Edit');
    expect(component.isLocalCreditJob).toBe(true);
  });

  it(`should make isLocalCreditJob true if url includes Untransmitted on calling findCreditJobState`, () => {
    component.isLocalCreditJob = false;
    component.findCreditJobState('jobList/122/23457/Untransmitted');
    expect(component.isLocalCreditJob).toBe(true);
  });

  it(`should make isHostCreditJob true if url includes credit-project-details and currentToggle is Transmitted
   on calling findCreditJobState`, () => {
    commonService.currentToggle = 'Transmitted';
    component.isHostCreditJob = false;
    component.findCreditJobState('jobList/122/23457/credit-project-details');
    expect(component.isHostCreditJob).toBe(true);
  });

  it(`should make isHostCreditJob true if url includes Transmitted on calling findCreditJobState`, () => {
    component.isHostCreditJob = false;
    component.findCreditJobState('jobList/122/23457/Transmitted');
    expect(component.isHostCreditJob).toBe(true);
  });

  it('should set the isClickInErrorsPanel to false on call of toggleErrorsPanel method when enablePrevalidation is true', () => {
    component.isClickInErrorsPanel = false;
    component.enablePrevalidation = true;
    const newElement = document.createElement('i');
    newElement.setAttribute('id', 'pinUnpinIcon');
    newElement.setAttribute('class', 'unpin');
    document.body.appendChild(newElement);
    spyOn(component, 'isEventTargetContainsErrorsIcon').and.returnValue(false);
    const errorPopupSpy = spyOn(sharedJobHeaderService.showErrorsAndWarningsPanel, 'next');
    component.toggleErrorsPanel(event);
    expect(errorPopupSpy).toHaveBeenCalledWith(false);
    document.body.removeChild(newElement);
  });

  it('should not call showErrorsAndWarningsPanel if enablePrevalidation is false on call of toggleErrorsPanel method', () => {
    component.enablePrevalidation = false;
    spyOn(component, 'isEventTargetContainsErrorsIcon').and.returnValue(true);
    const errorPopupSpy = spyOn(sharedJobHeaderService.showErrorsAndWarningsPanel, 'next');
    component.toggleErrorsPanel(event);
    expect(errorPopupSpy).not.toHaveBeenCalled();
  });

  it('should not call showErrorsAndWarningsPanel if the panel is in pinned state on call of toggleErrorsPanel method', () => {
    const newElement = document.createElement('i');
    newElement.setAttribute('id', 'pinUnpinIcon');
    newElement.setAttribute('class', 'pin');
    document.body.appendChild(newElement);
    spyOn(component, 'isEventTargetContainsErrorsIcon').and.returnValue(true);
    const errorPopupSpy = spyOn(sharedJobHeaderService.showErrorsAndWarningsPanel, 'next');
    component.toggleErrorsPanel(event);
    expect(errorPopupSpy).not.toHaveBeenCalled();
    document.body.removeChild(newElement);
  });

  it(`should set the isClickInErrorsPanel to true and refresh icon element should be added when toggleErrorsPanel
   is called with event and isEventTargetContainsErrorsIcon is returning true value`, () => {
    component.disableRefreshIcon = true;
    sharedJobHeaderService.showErrorsAndWarningsPanel = new BehaviorSubject(true);
    spyOn(component, 'isEventTargetContainsErrorsIcon').and.returnValue(true);
    const newElement = document.createElement('i');
    newElement.setAttribute('id', 'pinUnpinIcon');
    newElement.setAttribute('class', 'unpin');
    newElement.setAttribute('class', 'refresh-icon-disabled');
    document.body.appendChild(newElement);
    const refreshElement = document.createElement('div');
    refreshElement.setAttribute('id', 'refreshIcon');
    document.body.appendChild(refreshElement);
    component.toggleErrorsPanel(event);
    expect(component.isClickInErrorsPanel).toBe(false);
    expect(component.isEventTargetContainsErrorsIcon).toHaveBeenCalled();
    expect(document.querySelector('#refreshIcon')).toBeDefined();
    document.body.removeChild(newElement);
  });

  it(`should remove refresh-icon-disabled class when disableRefreshIcon is false and toggleErrorsPanel
   is called`, () => {
    // Arrange
    component.disableRefreshIcon = false;
    sharedJobHeaderService.showErrorsAndWarningsPanel = new BehaviorSubject(true);
    spyOn(component, 'isEventTargetContainsErrorsIcon').and.returnValue(true);
    const newElement = document.createElement('i');
    newElement.setAttribute('id', 'pinUnpinIcon');
    newElement.setAttribute('class', 'unpin');
    newElement.setAttribute('class', 'refresh-icon-disabled');
    document.body.appendChild(newElement);
    const refreshElement = document.createElement('div');
    refreshElement.setAttribute('id', 'refreshIcon');
    document.body.appendChild(refreshElement);
    // Act
    component.toggleErrorsPanel(event);
    // Assert
    expect(document.querySelector('#refreshIcon')).toBeDefined();
    expect(refreshElement.classList.contains('refresh-icon-disabled')).toBe(false);
  });

  it('should return true if the target element is inside the component on calling isEventTargetContainsErrorsIcon', () => {
    component.errorsAndWarningsIcon = { nativeElement: fixture.debugElement.children[0].nativeElement };
    expect(component.isEventTargetContainsErrorsIcon(fixture.debugElement.children[0].nativeElement)).toBe(true);
  });

  it(`should not return true if the target element is not inside the component on
       calling isEventTargetContainsErrorsIcon`, () => {
    component.errorsAndWarningsIcon = { nativeElement: fixture.debugElement.children[0].nativeElement };
    expect(component.isEventTargetContainsErrorsIcon(document.getRootNode())).not.toBe(true);
  });

  it(`should not return true if the target element is not a html element on calling isEventTargetContainsErrorsIcon`, () => {
    component.errorsAndWarningsIcon = { nativeElement: fixture.debugElement.children[0].nativeElement };
    expect(component.isEventTargetContainsErrorsIcon(window)).not.toBe(true);
  });

  it('should return true if getCssClass returns hide-menu-item and index is not equal to selectedIndex on calling hideSubMenu', () => {
    component.selectedIndex = 1;
    spyOn(component, 'getCssClass').and.returnValue('hide-menu-item');
    expect(component.hideSubMenu('Project', 1)).toBe(true);
  });

  it('should return the last child route on caling getLastChildRoute', () => {
    const activeRoute =
      { children: [{ children: [{ children: [], snapshot: { data: { subMenuRoute: 'test' } } }] }] } as unknown as ActivatedRoute;
    const leafNode = component.getLastChildRoute(activeRoute);
    expect(leafNode.snapshot.data.subMenuRoute).toBe('test');
  });

  it('should update menuItem path on calling updateRoutesForNonEdit', () => {
    const item = { route: 'nonEdit', path: 'test' };
    component.updateRoutesForNonEdit(item, 132, 12, 12234);
    expect(item.path).toContain('132/12/projects/CreditJobs/12234');
  });

  it('should update creditProject item path on calling updateRoutesForNonEdit', () => {
    const item = { route: component.creditProjectName, path: 'test' };
    component.updateRoutesForNonEdit(item, 12, 12, 12);
    expect(item.path).toContain(component.creditProjectDetailsName);
    expect(item.route).toEqual(component.creditProjectDetailsName);
  });

  it('should not update menuItem path on calling updateRoutesForNonEdit', () => {
    const editItem = { route: 'Edit', path: 'test' };
    component.updateRoutesForNonEdit(editItem, 12, 12, 12);
    expect(editItem.path).not.toContain('/projects/CreditJobs/');
  });

  it('should set route as Edit and path with localCreditJobId on calling updateCreditProjectRoutes', () => {
    const item = { route: '', path: '' };
    component.projectBidList = [{ localCreditJobId: 10, isCopiedDownCreditJob: true }] as BidsListModel[];
    component.isTransmitted = true;
    component.isProdOrStageEnvironment = false;
    component.activeProjectBidIndex = 0;
    component.updateCreditProjectRoutes(item, 134, 12, 12345);
    expect(item.route).toEqual('Edit');
    expect(item.path).toContain('134/12/projects/CreditProject/10');
  });

  it('should set route as Edit and path with creditNumber on calling updateCreditProjectRoutes', () => {
    const item = { route: '', path: '' };
    component.projectCreditJobId = 10;
    component.projectBidList = [{ localCreditJobId: 10, isCopiedDownCreditJob: false }] as BidsListModel[];
    component.isTransmitted = false;
    component.isProdOrStageEnvironment = false;
    component.activeProjectBidIndex = 0;
    component.isArchivedCreditJobPresent = false;
    component.updateCreditProjectRoutes(item, 134, 12, 12345);
    expect(item.route).toEqual('Edit');
    expect(item.path).toContain('134/12/projects/CreditProject/12345');
  });

  it('should set route when  isTransmitted is true on calling updateCreditProjectRoutes', () => {
    const item = { route: '', path: '' };
    component.projectCreditJobId = 10;
    component.projectBidList = [{ localCreditJobId: 10, isCopiedDownCreditJob: false }] as BidsListModel[];
    component.isTransmitted = true;
    component.activeProjectBidIndex = 0;
    component.isArchivedCreditJobPresent = false;
    component.updateCreditProjectRoutes(item, 134, 12, 12345);
    expect(item.route).toEqual(component.creditProjectDetailsName);
  });

  it('should set route when isTransmitted is true and isCopiedDownCreditJob is true on calling updateSalesOrderRoutes', () => {
    const item = { route: '', path: '' };
    component.projectBidList = [{ localCreditJobId: 10, isCopiedDownCreditJob: true }] as BidsListModel[];
    component.isTransmitted = true;
    component.isProdOrStageEnvironment = false;
    component.activeProjectBidIndex = 0;
    component.isArchivedCreditJobPresent = false;
    component.updateSalesOrderRoutes(item, 134, 12, 12345);
    expect(item.route).toEqual('SalesOrders');
    expect(item.path).toBe('/jobs-list/134/12/projects/CreditJobs/10/SalesOrders');
  });

  it('should set route when isTransmitted is true and isCopiedDownCreditJob is false or isTransmitted is false on calling updateSalesOrderRoutes', () => {
    const item = { route: '', path: '' };
    component.projectCreditJobId = 10;
    component.projectBidList = [{ localCreditJobId: 10, isCopiedDownCreditJob: false }] as BidsListModel[];
    component.isTransmitted = true;
    component.activeProjectBidIndex = 0;
    component.isArchivedCreditJobPresent = false;
    component.updateSalesOrderRoutes(item, 134, 12, 12345);
    expect(item.route).toEqual('SalesOrders');
  });

  it('should not call removeClass on renderer when there is not active class on calling onMenuSelect', () => {
    document.querySelectorAll('.sub-menu-list').forEach((item) => {
      item.classList.remove('active');
    });
    menuItem = { text: 'Address', route: 'address', path: 'address', cssClass: '' };
    spyOn(component.renderer, 'removeClass');
    component.onMenuSelect(menuItem);
    expect(component.renderer.removeClass).not.toHaveBeenCalled();
    document.querySelector('#menu_active').classList.add('active');
  });

  it('should set startValidation value from startPreValidation subject on calling ngOnInit', () => {
    commonService.startPreValidation = new BehaviorSubject(true);
    component.ngOnInit();
    expect(component.startValidation).toEqual(true);
  });

  it(`should show success toaster message if the response is success and exitPrevalidation is false on
  and the current state is assign sales orders calling triggerPreValidation method`, () => {
    commonService.isPreValidationExit = false;
    component.startValidation = false;
    component.startAssignSalesOrderValidation = false;
    component.currentState = 'assign-sales-orders';
    const preValidationPayload = {
      eventName: 'PreValidation',
      rootEntityName: 'Job',
      rootEntityId: component.jobId,
      additionalInfo: '{BidAlternateId:' + component.activeBidAlternateId + ',CreditJobId:' + component.creditJobId + '}',
    };
    const spyToaster = spyOn(toasterService, 'setToaster');
    const spyValidationMessagesCount = spyOn(component, 'fetchValidationMessagesCount');
    const spyRefresh = spyOn(commonService.refreshErrorsAndWarningPanel, 'next');
    spyOn(validationErrorService, 'postPreValidate').and.returnValue(of('Success'));
    const spySalesOrderValidationSubject = spyOn(assignSalesOrdersService.salesOrderValidationSubject, 'next');
    component.triggerPreValidation();
    expect(spyToaster).toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_START_MESSAGE);
    expect(spyValidationMessagesCount).toHaveBeenCalled();
    expect(spyToaster).toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_SUCCESS_MESSAGE);
    expect(spyRefresh).not.toHaveBeenCalled();
    expect(spySalesOrderValidationSubject).toHaveBeenCalledWith(true);
  });

  it(`should set refreshErrorsAndWarningPanel.next with true if the response is success and exitPrevalidation is false on
  calling triggerPreValidation method`, () => {
    commonService.isPreValidationExit = false;
    component.startValidation = true;
    const preValidationPayload = {
      eventName: 'PreValidation',
      rootEntityName: 'Job',
      rootEntityId: component.jobId,
      additionalInfo: '{BidAlternateId:' + component.activeBidAlternateId + ',CreditJobId:' + component.creditJobId + '}',
    };
    const spyValidationMessagesCount = spyOn(component, 'fetchValidationMessagesCount');
    const spyRefresh = spyOn(commonService.refreshErrorsAndWarningPanel, 'next');
    spyOn(validationErrorService, 'postPreValidate').and.returnValue(of('Success'));
    component.triggerPreValidation(true);
    expect(spyValidationMessagesCount).toHaveBeenCalled();
    expect(spyRefresh).toHaveBeenCalledWith(true);
    expect(component.messageCount).toEqual(0);
  });

  it('should not show success toaster message if the response is not success and exitPrevalidation is true on calling triggerPreValidation method', () => {
    component.startValidation = true;
    commonService.isPreValidationExit = true;
    const spyToaster = spyOn(toasterService, 'setToaster');
    spyOn(validationErrorService, 'postPreValidate').and.returnValue(of('Ok'));
    component.triggerPreValidation();
    expect(spyToaster).toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_START_MESSAGE);
    expect(spyToaster).not.toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_SUCCESS_MESSAGE);
  });

  it('should not call postPreValidate if startValidation is false on calling triggerPreValidation method', () => {
    component.startValidation = false;
    const spyToaster = spyOn(toasterService, 'setToaster');
    const spyPostPreValidationCall = spyOn(validationErrorService, 'postPreValidate');
    component.triggerPreValidation();
    expect(spyToaster).not.toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_START_MESSAGE);
    expect(spyToaster).not.toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_SUCCESS_MESSAGE);
    expect(spyPostPreValidationCall).not.toHaveBeenCalled();
  });

  it('should show api service error if the postPreValidate api call returns error on calling triggerPreValidation method', () => {
    component.startValidation = true;
    const spyToaster = spyOn(toasterService, 'setToaster');
    spyOn(validationErrorService, 'postPreValidate').and.returnValue(throwError({
      error: 'error',
      status: 404
    }));
    const spyApiErrorService = spyOn(apiErrorService, 'show');
    component.triggerPreValidation();
    expect(spyToaster).toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_START_MESSAGE);
    expect(spyApiErrorService).toHaveBeenCalledWith('error');
  });

  it(`should show toaster error message if the postPreValidate api call returns error with no status code on calling triggerPreValidation method`, () => {
    component.startValidation = true;
    const spyToaster = spyOn(toasterService, 'setToaster');
    spyOn(validationErrorService, 'postPreValidate').and.returnValue(throwError({
      error: 'error',
      status: 0
    }));
    component.triggerPreValidation();
    expect(spyToaster).toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_START_MESSAGE);
    expect(spyToaster).toHaveBeenCalledWith(appConstants.ERROR_VALUE, appConstants.PREVALIDATION_ERROR_MESSAGE);
  });

  it('should set value for activeBidAlternateId when ngOnInit method is called', () => {
    component.createProjectBidList = testCreateProjectBidList;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.projectBidList = [{
      bidAlternateId: 186419,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 2094617,
      isArchivedCreditJob: true,
      isCopiedDownCreditJob: false,
      localCreditJobId: 123,
      isRemnant: false,
      archivedCreditJobId: 156,
      isTransmitted: false,
    }];
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.ngOnInit();
    expect(spyPreValidation).toHaveBeenCalled();
    expect(component.activeBidAlternateId).toBe(12345);
  });

  it(`should set salesOrderType as Untransmitted if isCopiedDownCreditJob is true
      on calling ngOnInit()`, () => {
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    spyOn(commonService, 'getBaseUrl');
    testProjectBidList[0].isCopiedDownCreditJob = true;
    component.enableMirrorSalesOrder = true;
    component.projectBidList = testProjectBidList;
    component.ngOnInit();
    expect(component.salesOrderType).toEqual('Untransmitted');
  });

  it(`should set salesOrderType as Transmitted if isCopiedDownCreditJob is false
      on calling ngOnInit()`, () => {
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    spyOn(commonService, 'getBaseUrl');
    testProjectBidList[0].isTransmitted = true;
    testProjectBidList[0].isCopiedDownCreditJob = false;
    component.enableMirrorSalesOrder = true;
    component.projectBidList = testProjectBidList;
    component.ngOnInit();
    expect(component.salesOrderType).toEqual('Transmitted');
  });

  it(`should set isUntransmittedCreditProject as true if isTransmitted is false
      on calling ngOnInit()`, () => {
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    spyOn(commonService, 'getBaseUrl');
    testProjectBidList[0].isTransmitted = false;
    component.projectBidList = testProjectBidList;
    component.ngOnInit();
    expect(component.isUntransmittedCreditProject).toBe(true);
  });

  it(`should set isUntransmittedCreditProject as false if isTransmitted is true
      on calling ngOnInit()`, () => {
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    testProjectBidList[0].isTransmitted = true;
    component.projectBidList = testProjectBidList;
    component.ngOnInit();
    expect(component.isUntransmittedCreditProject).toBe(false);
  });

  it('should call triggerPreValidation from callValidation subject on calling ngOnInit', () => {
    commonService.callValidation = new BehaviorSubject(true);
    const spyTriggerPreValidation = spyOn(component, 'triggerPreValidation');
    component.ngOnInit();
    expect(spyTriggerPreValidation).toHaveBeenCalled();
  });

  it(`should trigger prevalidation with jobBidList on calling clickRefreshIcon method`, () => {
    component.jobBidList = testProjectBidList;
    commonService.isPreValidationExit = true;
    component.startValidation = true;
    const preValidationPayload = {
      eventName: 'PreValidation',
      rootEntityName: 'Job',
      rootEntityId: component.jobId,
      additionalInfo: '{BidAlternateId:' + 656110 + ',CreditJobId:' + 2130356 + '}',
    };
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.clickRefreshIcon();
    expect(spyPreValidation).toHaveBeenCalled();
  });

  it(`should not trigger prevalidation when jobBidList is null on calling clickRefreshIcon method`, () => {
    component.jobBidList = null;
    expect(component.jobBidList).toBe(null);
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.clickRefreshIcon();
    expect(spyPreValidation).not.toHaveBeenCalled();
  });

  it(`should trigger prevalidation when creditJobid and activeBidAlternateId has value on calling clickRefreshIcon method`, () => {
    component.jobBidList = testProjectBidList;
    component.creditJobId = 48901;
    component.activeBidAlternateId = 41;
    component.startValidation = true;
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.clickRefreshIcon();
    expect(spyPreValidation).toHaveBeenCalled();
  });

  it(`should trigger prevalidation when creditJobId has no data on calling clickRefreshIcon method`, () => {
    component.jobBidList = testProjectBidList;
    commonService.isPreValidationExit = true;
    component.creditJobId = 0;
    component.startValidation = true;
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.clickRefreshIcon();
    expect(spyPreValidation).toHaveBeenCalled();
  });

  it(`should call triggerPreValidationWithPricingRuleOnRefresh and trigger prevalidation if isUntransmittedCreditProject and isEditCreditProjectScreen values are true on calling clickRefreshIcon method`, () => {
    component.jobBidList = testProjectBidList;
    component.isUntransmittedCreditProject = true;
    component.isEditCreditProjectScreen = true;
    commonService.isPreValidationExit = true;
    component.creditJobId = 48901;
    component.activeBidAlternateId = 41;
    component.startValidation = true;
    commonService.shouldTriggerPricingRuleValidation = true;
    const spyTriggerPreValidationWithPricingRuleOnRefresh = spyOn(component, 'triggerPreValidationWithPricingRuleOnRefresh');
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.clickRefreshIcon();
    expect(spyTriggerPreValidationWithPricingRuleOnRefresh).toHaveBeenCalled();
    expect(spyPreValidation).toHaveBeenCalled();
  });

  it(`should set eventName as PreValidationWithPricingRule if shouldTriggerPricingRuleValidation value is true
  calling triggerPreValidation method`, () => {
    commonService.isPreValidationExit = false;
    component.startValidation = true;
    commonService.shouldTriggerPricingRuleValidation = true;
    component.triggerPreValidation(true);
    expect(component.eventName).toEqual('PreValidationWithPricingRule');
  });

  it(`should set eventName as PreValidation if shouldTriggerPricingRuleValidation value is false
  calling triggerPreValidation method`, () => {
    commonService.isPreValidationExit = false;
    component.startValidation = true;
    commonService.shouldTriggerPricingRuleValidation = false;
    component.triggerPreValidation(true);
    expect(component.eventName).toEqual('PreValidation');
  });

  it(`should set shouldTriggerPricingRuleValidation variable in common service as true if isUntransmittedCreditProject and
      isEditCreditProjectScreen are true calling triggerPreValidationWithPricingRuleOnRefresh method`, () => {
    component.isUntransmittedCreditProject = true;
    component.isEditCreditProjectScreen = true;
    commonService.shouldTriggerPricingRuleValidation = false;
    component.triggerPreValidationWithPricingRuleOnRefresh();
    expect(commonService.shouldTriggerPricingRuleValidation).toEqual(true);
  });

  it(`should set shouldTriggerPricingRuleValidation variable in common service as false if isUntransmittedCreditProject or
      isEditCreditProjectScreen is false calling triggerPreValidationWithPricingRuleOnRefresh method`, () => {
    component.isUntransmittedCreditProject = false;
    component.isEditCreditProjectScreen = false;
    commonService.shouldTriggerPricingRuleValidation = false;
    component.triggerPreValidationWithPricingRuleOnRefresh();
    expect(commonService.shouldTriggerPricingRuleValidation).toEqual(false);
  });

  it(`should trigger prevalidation while creditProject is untransmitted on calling clickRefreshIcon method`, () => {
    testProjectBidList[0].hqtrCreditJobId = null;
    testProjectBidList[0].foe2CreatedOrdersInd = 'Y';
    component.jobBidList = testProjectBidList;
    commonService.isPreValidationExit = true;
    component.startValidation = true;
    component.isTransmitted = true;
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.clickRefreshIcon();
    expect(spyPreValidation).toHaveBeenCalled();
  });

  it(`should not show success toaster message when bidCount not equal to messageCount on calling triggerPreValidation method`, () => {
    component.projectBidList = testProjectBidList;
    commonService.isPreValidationExit = true;
    component.startValidation = true;
    const spyToaster = spyOn(toasterService, 'setToaster');
    component.triggerPreValidation(true);
    expect(spyToaster).not.toHaveBeenCalledWith(appConstants.SUCCESS_VALUE, appConstants.PREVALIDATION_SUCCESS_MESSAGE);
  });

  it(`should trigger prevalidation when creditJobId is null on calling clickRefreshIcon method`, () => {
    testProjectBidList[0].creditJobId = null;
    component.jobBidList = testProjectBidList;
    commonService.isPreValidationExit = true;
    component.startValidation = true;
    const spyPreValidation = spyOn(component, 'triggerPreValidation');
    component.clickRefreshIcon();
    expect(spyPreValidation).toHaveBeenCalled();
  });

  it(`should call onMenuSelect if isFormModified in commonService is false and isNonTraneFormUpdated in nonTraneService
   is false on calling onSubMenuSelection`, () => {
    // Arrange
    component.jobSubMenu = testJobSubMenu;
    commonService.isFormModified = false;
    nonTraneService.isNonTraneFormUpdated = false;
    menuItem = { items: [], text: 'Address', route: 'address', path: 'address', cssClass: '' };
    const clickEvent = { stopPropagation: () => { } } as Event;
    spyOn(clickEvent, 'stopPropagation');
    const spy = spyOn(component, 'onMenuSelect');
    const spyUpdateProjectType = spyOn(component, 'updateProjectType');
    // Act
    component.onSubMenuSelection(menuItem, clickEvent);
    expect(clickEvent.stopPropagation).not.toHaveBeenCalled();
    expect(spy).toHaveBeenCalled();
    expect(spyUpdateProjectType).toHaveBeenCalledWith(menuItem);
  });

  it(`should assign true for shouldShowFormModifiedDialog and menuItem to subMenuInfo if isFormModified in commonService is true
   or isNonTraneFormUpdated in nonTraneService is true on calling onSubMenuSelection`, () => {
    // Arrange
    component.jobSubMenu = testJobSubMenu;
    commonService.isFormModified = true;
    nonTraneService.isNonTraneFormUpdated = true;
    menuItem = { text: 'Address', route: 'address', path: 'address', cssClass: '' };
    component.shouldShowFormModifiedDialog = false;
    component.subMenuInfo = null;
    component.isCreateProjectScreen = false;
    const clickEvent = { stopPropagation: () => { } } as Event;
    spyOn(clickEvent, 'stopPropagation');
    // Act
    component.onSubMenuSelection(menuItem, clickEvent);
    // Assert
    expect(component.shouldShowFormModifiedDialog).toBe(true);
    expect(component.subMenuInfo).toBe(menuItem);
    expect(clickEvent.stopPropagation).toHaveBeenCalled();
  });

  it(`should assign true for shouldShowFormModifiedDialog and menuItem to subMenuInfo if isFormModified in commonService is true
   or isNonTraneFormUpdated in nonTraneService is false on calling onSubMenuSelection`, () => {
    // Arrange
    component.jobSubMenu = testJobSubMenu;
    commonService.isFormModified = true;
    nonTraneService.isNonTraneFormUpdated = false;
    menuItem = { text: 'Address', route: 'address', path: 'address', cssClass: '' };
    component.shouldShowFormModifiedDialog = false;
    component.subMenuInfo = null;
    component.disableSubMenu = false;
    const clickEvent = { stopPropagation: () => { } } as Event;
    spyOn(clickEvent, 'stopPropagation');
    // Act
    component.onSubMenuSelection(menuItem, clickEvent);
    // Assert
    expect(component.shouldShowFormModifiedDialog).toBe(true);
    expect(component.subMenuInfo).toBe(menuItem);
    expect(clickEvent.stopPropagation).toHaveBeenCalled();
  });

  it(`should call onMenuSelect, make shouldShowFormModifiedDialog and isFormModified in commonService false if enableNavigation is true
  on calling handleFormModifiedDialogAction`, () => {
    // Arrange
    commonService.isFormModified = true;
    const spy = spyOn(component, 'onMenuSelect');
    component.shouldShowFormModifiedDialog = true;
    // Act
    component.handleFormModifiedDialogAction(true);
    // Assert
    expect(spy).toHaveBeenCalled();
    expect(commonService.isFormModified).toBe(false);
    expect(component.shouldShowFormModifiedDialog).toBe(false);
  });

  it('should not call onMenuSelect and make shouldShowFormModifiedDialog false if enableNavigation is false on calling handleFormModifiedDialogAction', () => {
    // Arrange
    const spy = spyOn(component, 'onMenuSelect');
    component.shouldShowFormModifiedDialog = true;
    // Act
    component.handleFormModifiedDialogAction(false);
    // Assert
    expect(spy).not.toHaveBeenCalled();
    expect(component.shouldShowFormModifiedDialog).toBe(false);
  });

  it(`should call releaseLockAndExit on calling handleFormModifiedDialogAction`, () => {
    component.isExitJobClick = true;
    component.currentState = 'assign-sales-orders';
    const spyOnPreventDefault = spyOn(spyEvent, 'preventDefault');
    const spyOnStopPropagation = spyOn(spyEvent, 'stopPropagation');
    const spyOnReleaseLockAndExit = spyOn(component, 'releaseLockAndExit');
    component.handleFormModifiedDialogAction(true, spyEvent);
    expect(spyOnReleaseLockAndExit).toHaveBeenCalled();
    expect(component.isExitJobClick).toBe(true);
    expect(spyOnPreventDefault).toHaveBeenCalled();
    expect(spyOnStopPropagation).toHaveBeenCalled();
  });

  it('should call navigateToBidsPage() when navFrom is empty on calling showSaveConfirmationDialog()', () => {
    const mockRouter = {
      url: '/jobs-list',
      events: new BehaviorSubject<NavigationEnd>(null),
      navigate: () => { },
      navigateByUrl: () => { }
    } as unknown as Router;
    const navigateToBidsPageSpy = spyOn(component, 'navigateToBidsPage').and.callThrough();
    component.onAssignSalesOrderExit();
    expect(navigateToBidsPageSpy).toHaveBeenCalled();
  });

  it(`should call deleteValidationMessage service when jobId, drAddressId and activeBidAlternateId are defined
  and set isValidationMesssageDeletionCompleted as true after successful deletion on calling handleFormModifiedDialogAction`, () => {
    // Arrange
    component.jobId = testJobId;
    component.drAddressId = testDrAddressId;
    component.activeBidAlternateId = 1;
    spyOn(component, 'onMenuSelect');
    const deleteValidationMessageSpy = spyOn(validationErrorService, 'deleteValidationMessage').and.returnValue(of(true));
    // Act
    component.handleFormModifiedDialogAction(true);
    // Assert
    expect(deleteValidationMessageSpy).toHaveBeenCalled();
    commonService.isValidationMesssageDeletionCompleted.subscribe((data) => {
      expect(data).toBe(true);
    });
  });

  it(`should not call deleteValidationMessage service when activeBidAlternateId is undefined
  on calling handleFormModifiedDialogAction`, () => {
    // Arrange
    component.jobId = testJobId;
    component.drAddressId = testDrAddressId;
    component.activeBidAlternateId = undefined;
    spyOn(component, 'onMenuSelect');
    const deleteValidationMessageSpy = spyOn(validationErrorService, 'deleteValidationMessage');
    // Act
    component.handleFormModifiedDialogAction(true);
    // Assert
    expect(deleteValidationMessageSpy).not.toHaveBeenCalled();
  });

  it('should call triggerPreValidation from callValidation subject on calling ngOnInit', () => {
    // Arrange
    commonService.isValidationMesssageDeletionCompleted = new BehaviorSubject(true);
    const spyFetchValidationMessagesCount = spyOn(component, 'fetchValidationMessagesCount');
    // Act
    component.ngOnInit();
    // Assert
    expect(spyFetchValidationMessagesCount).toHaveBeenCalled();
  });

  it('should not call postPreValidate if enablePrevalidation is false on calling triggerPreValidation method', () => {
    component.enablePrevalidation = false;
    component.startValidation = true;
    const spyPostPreValidationCall = spyOn(validationErrorService, 'postPreValidate');
    component.triggerPreValidation();
    expect(spyPostPreValidationCall).not.toHaveBeenCalled();
  });

  it('should call postPreValidate if enablePrevalidation and startValidation is true on calling triggerPreValidation method', () => {
    component.enablePrevalidation = true;
    component.startValidation = true;
    const spyPostPreValidationCall = spyOn(validationErrorService, 'postPreValidate').and.returnValue(of('Ok'));
    component.triggerPreValidation();
    expect(spyPostPreValidationCall).toHaveBeenCalled();
  });

  it('should call releaseCreditProjectNumber if no creditJobId and navigate to bids page when BackButtonHandler method called', () => {
    const eventTarget = {
      returnValue: null,
      preventDefault() { }
    } as Event;
    const spyToggleErrorsPanel = spyOn(component, 'toggleErrorsPanel');
    component.popstateHandler(eventTarget);
    expect(spyToggleErrorsPanel).toHaveBeenCalled();
  });

  it(`should emit showFormModifiedDialog when exitJob and showDialog is true on calling ngOnInit()`, () => {
    sharedJobHeaderService.showFormModifiedDialog.next({ exitJobClick: true, showDialog: true });
    component.ngOnInit();
    expect(component.isExitJobClick).toBe(true);
    expect(component.shouldShowFormModifiedDialog).toBe(true);
  });

  it(`should not emit showFormModifiedDialog when exitJob and showDialog is false on calling ngOnInit()`, () => {
    sharedJobHeaderService.showFormModifiedDialog.next({ exitJobClick: false, showDialog: false });
    component.ngOnInit();
    expect(component.isExitJobClick).toBe(false);
    expect(component.shouldShowFormModifiedDialog).toBe(false);
  });

  it(`should emit exitJob make isExitJobClick false if isExitJobClick is true on calling handleFormModifiedDialogAction`, () => {
    component.isExitJobClick = true;
    const spyOnExitJob = spyOn(sharedJobHeaderService.exitJob, 'next');
    const spyOnPreventDefault = spyOn(spyEvent, 'preventDefault');
    const spyOnStopPropagation = spyOn(spyEvent, 'stopPropagation');

    component.handleFormModifiedDialogAction(true, spyEvent);

    expect(spyOnExitJob).toHaveBeenCalledWith(true);
    expect(component.isExitJobClick).toBe(false);
    expect(spyOnPreventDefault).toHaveBeenCalled();
    expect(spyOnStopPropagation).toHaveBeenCalled();
  });

  it(`should call enableSalesOrderDetailsSubmenu method and set isSalesOrderDetailsDisable as false
      when getSalesOrders is having response on calling enableDisableSalesOrderDetailsSubmenu method`, () => {
    testProjectBidList[0].creditJobId = 2094617;
    testProjectBidList[0].isTransmitted = false;
    testProjectBidList[0].isCopiedDownCreditJob = false;
    component.projectBidList = testProjectBidList;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.enableMirrorSalesOrder = true;
    component.drAddressId = 1;
    spyEnableDisableSalesOrderDetailsSubmenu.and.callThrough();
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    const spyGetSalesOrderDetails = spyOn(salesOrderService, 'getSalesOrders').and.returnValue(of(orderLineMock.salesOrderData));
    const spyHandleSubmenu = spyOn(component, 'handleSubmenu');
    component.enableDisableSalesOrderDetailsSubmenu(component.projectBidList[0]);
    expect(spyBaseUrl).toHaveBeenCalled();
    expect(spyHandleSubmenu).toHaveBeenCalledWith(component.salesOrderDetailsName, true);
    expect(component.isSalesOrderDetailsDisable).toBe(false);
    expect(component.salesOrderType).toBe('Untransmitted');
    expect(spyGetSalesOrderDetails).toHaveBeenCalledWith(2094617, component.skip, component.take, component.salesOrderType);
  });

  it('should set isSalesOrderDetailsDisable as true if getSalesOrders is returning null on calling enableDisableSalesOrderDetailsSubmenu method ', () => {
    testProjectBidList[0].creditJobId = 2094617;
    testProjectBidList[0].isTransmitted = false;
    testProjectBidList[0].isCopiedDownCreditJob = false;
    component.projectBidList = testProjectBidList;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.enableMirrorSalesOrder = true;
    spyEnableDisableSalesOrderDetailsSubmenu.and.callThrough();
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    spyOn(salesOrderService, 'getSalesOrders').and.returnValue(of(null));
    component.creditJobIds.push(testProjectBidList[0].creditJobId);
    component.enableDisableSalesOrderDetailsSubmenu(component.projectBidList[0]);
    expect(spyBaseUrl).toHaveBeenCalled();
    expect(component.isSalesOrderDetailsDisable).toBe(true);
  });

  it('should set isSalesOrderDetailsDisable as true if getSalesOrders is returning null and creditjobIds is empty on calling enableDisableSalesOrderDetailsSubmenu method ', () => {
    testProjectBidList[0].creditJobId = 2094617;
    testProjectBidList[0].isTransmitted = false;
    testProjectBidList[0].isCopiedDownCreditJob = false;
    component.projectBidList = testProjectBidList;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.enableMirrorSalesOrder = true;
    spyEnableDisableSalesOrderDetailsSubmenu.and.callThrough();
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    spyOn(salesOrderService, 'getSalesOrders').and.returnValue(of(null));
    component.creditJobIds = [];
    component.enableDisableSalesOrderDetailsSubmenu(component.projectBidList[0]);
    expect(spyBaseUrl).toHaveBeenCalled();
    expect(component.isSalesOrderDetailsDisable).toBe(true);
  });

  it(`should set disabled property of menu item based on isEnabled flag on calling handleSubmenu`, () => {
    component.orderServiceMenuItems = [{
      text: salesOrderDetails,
      disabled: true,
    }];
    component.handleSubmenu(salesOrderDetails, true);
    expect(component.orderServiceMenuItems[0].disabled).toBe(false);

    component.handleSubmenu(salesOrderDetails, false);
    expect(component.orderServiceMenuItems[0].disabled).toBe(true);
  });

  it('should navigate to transmitted sales order details screen when menuItem route is SalesOrders on calling onMenuSelect', () => {
    window.name = 'ProjectLanding_Transmitted';
    component.salesOrderType = 'Transmitted';
    component.projectType = DisplayModeEnum.Transmitted;
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: salesOrderDetails,
        route: 'SalesOrders',
        cssClass: '',
        path: 'SalesOrders',
        disable: false,
      }];
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: 'Transmitted' }, relativeTo: activatedRoute,
    });
  });

  it('should navigate to history sales order details screen when menuItem route is SalesOrders on calling onMenuSelect', () => {
    window.name = 'ProjectLanding_Transmitted';
    component.salesOrderType = DisplayModeEnum.History;
    component.projectType = DisplayModeEnum.History;
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: salesOrderDetails,
        route: 'SalesOrders',
        cssClass: '',
        path: 'SalesOrders',
        disable: false,
      }];
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: DisplayModeEnum.History }, relativeTo: activatedRoute,
    });
  });

  it('should navigate to untransmitted sales order details screen when salesOrderType is untransmitted on calling onMenuSelect', () => {
    component.salesOrderType = 'Untransmitted';
    component.projectType = DisplayModeEnum.Untransmitted;
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: salesOrderDetails,
        route: 'SalesOrders',
        cssClass: '',
        path: 'SalesOrders',
        disable: false,
      }];
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: 'Untransmitted' }, relativeTo: activatedRoute,
    });
  });

  it(`should not get css class for project menu item when create credit project screen
    on calling getCssClass()`, () => {
    component.isCreateProjectScreen = true;
    const cssClass = component.getCssClass('Project');
    expect(cssClass).toEqual('');
  });

  it(`should generate create project bids list when buildCreateProjectBidsList() is called`, () => {
    const handleSelectedBidInCarouselSpy = spyOn(component, 'handleSelectedBidInCarousel');
    const handleSavedBidInCarouselSpy = spyOn(component, 'handleSavedBidInCarousel');
    component.jobBidList = testProjectBidList;
    component.jobBidList[0].creditJobNumber = null;
    component.projectBidList = [{
      bidAlternateId: 186418,
      bidName: 'Base Bid',
      creditJobNumber: 'T133458',
    } as BidsListModel];
    component.buildCreateProjectBidsList();
    expect(component.createProjectBidList.length).toBe(2);
    expect(handleSelectedBidInCarouselSpy).toHaveBeenCalled();
    expect(handleSavedBidInCarouselSpy).toHaveBeenCalled();
  });

  it('should call slideConfiguration with selected bid index when handleSelectedBidInCarousel() is called', () => {
    const spySlideConfiguration = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    testData.selectedBidData.bidData.bidName = 'LO';
    createCreditProjectService.selectedBid.next(testData.selectedBidData);
    component.handleSelectedBidInCarousel();
    expect(spySlideConfiguration).toHaveBeenCalledWith(0);
  });

  it(`should not call slideConfiguration when bidData in selected bid is null on calling
    handleSelectedBidInCarousel()`, () => {
    const spySlideConfiguration = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    testData.selectedBidData.bidData = null;
    createCreditProjectService.selectedBid.next(testData.selectedBidData);
    component.handleSelectedBidInCarousel();
    expect(spySlideConfiguration).not.toHaveBeenCalled();
  });

  it(`should not call slideConfiguration when selectedBidData is null on calling
    handleSelectedBidInCarousel()`, () => {
    const spySlideConfiguration = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    testData.selectedBidData = null;
    createCreditProjectService.selectedBid.next(testData.selectedBidData);
    component.handleSelectedBidInCarousel();
    expect(spySlideConfiguration).not.toHaveBeenCalled();
  });

  it(`should call buildCreateProjectBidsList if isCreateProjectScreen is true on calling
    getCreditJobNumberList()`, () => {
    const drAddressId = 101;
    const jobId = 53653;
    const spy = spyOn(component, 'buildCreateProjectBidsList');
    component.isCreateProjectScreen = true;
    component.getCreditJobNumberList(drAddressId, jobId);
    expect(spy).toHaveBeenCalled();
  });

  it(`should not call buildCreateProjectBidsList if isCreateProjectScreen is false on calling
    getCreditJobNumberList()`, () => {
    const drAddressId = 101;
    const jobId = 53653;
    const spy = spyOn(component, 'buildCreateProjectBidsList');
    component.isCreateProjectScreen = false;
    component.getCreditJobNumberList(drAddressId, jobId);
    expect(spy).not.toHaveBeenCalled();
  });

  it(`should update the initialSlide value if credit job id is null and not create project screen on calling
    slideConfiguration()`, () => {
    const projectCarouselConfig = component.projectMenuCarouselConfig;
    component.creditJobId = null;
    component.isCreateProjectScreen = false;
    component.slideConfiguration(2);
    expect(component.projectMenuCarouselConfig['initialSlide']).toBe(0);
    expect(projectCarouselConfig).not.toBe(component.projectMenuCarouselConfig);
  });

  it('should not update the initialSlide value in create project screen on calling slideConfiguration', () => {
    const projectCarouselConfig = component.projectMenuCarouselConfig;
    component.isCreateProjectScreen = true;
    component.slideConfiguration(2);
    expect(component.projectMenuCarouselConfig['initialSlide']).toBe(2);
    expect(projectCarouselConfig).not.toBe(component.projectMenuCarouselConfig);
  });

  it(`should modify createProjectBidList and call slideConfiguration when savedProjectCount is zero
    on calling handleSavedBidInCarousel()`, () => {
    const spy = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    component.savedProjectCount = 0;
    const savedProjectDetails = {
      bidAlternateId: 656108,
      creditJobNumber: 'L380995',
      updatedProjectBidList: testProjectBidList
    };
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(savedProjectDetails);
    expect(component.createProjectBidList.length).toBe(4);
    expect(component.createProjectBidList[3].bidName).toEqual('LO');
    expect(component.createProjectBidList[3].creditJobNumber).toEqual('L380995');
    expect(component.savedProjectCount).toEqual(1);
    expect(spy).toHaveBeenCalledWith(3);
  });

  it(`should not call slideConfiguration when saved bid index is invalid
    on calling handleSavedBidInCarousel()`, () => {
    const spy = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    component.savedProjectCount = 0;
    const savedProjectDetails = {
      bidAlternateId: 656100,
      creditJobNumber: 'L380995',
      updatedProjectBidList: testProjectBidList
    };
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(savedProjectDetails);
    expect(spy).not.toHaveBeenCalled();
    expect(component.savedProjectCount).toEqual(0);
  });

  it(`should modify createProjectBidList and call slideConfiguration when savedProjectCount is not zero and
    bid name is modified on calling handleSavedBidInCarousel()`, () => {
    const spy = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    component.savedProjectCount = 1;
    const savedProjectDetails = {
      bidAlternateId: 656109,
      creditJobNumber: 'L380998',
      updatedProjectBidList: testProjectBidList
    };
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(savedProjectDetails);
    expect(component.createProjectBidList.length).toBe(4);
    expect(component.createProjectBidList[3].bidName).toEqual('LO-1');
    expect(component.createProjectBidList[3].creditJobNumber).toEqual('L380998');
    expect(component.savedProjectCount).toEqual(2);
    expect(spy).toHaveBeenCalledWith(3);
  });

  it(`should modify createProjectBidList and call slideConfiguration when savedProjectCount is not zero and
    credit project number is modified on calling handleSavedBidInCarousel()`, () => {
    const spy = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    component.savedProjectCount = 1;
    const savedProjectDetails = {
      bidAlternateId: 656111,
      creditJobNumber: 'L380999',
      updatedProjectBidList: testProjectBidList
    };
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(savedProjectDetails);
    expect(component.createProjectBidList.length).toBe(4);
    expect(component.createProjectBidList[3].bidName).toEqual('LO-3');
    expect(component.createProjectBidList[3].creditJobNumber).toEqual('L380999');
    expect(component.savedProjectCount).toEqual(2);
    expect(spy).toHaveBeenCalledWith(3);
  });

  it(`should not call slideConfiguration when no saved bid on calling handleSavedBidInCarousel()`, () => {
    const spy = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    component.savedProjectCount = 0;
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(null);
    expect(spy).not.toHaveBeenCalled();
    expect(component.savedProjectCount).toEqual(0);
  });

  it('should unsubscribe selectedBidSubscription on calling ngOnDestroy()', () => {
    component.selectedBidSubscription = new Subscription(() => { });
    const spy = spyOn(component.selectedBidSubscription, 'unsubscribe').and.callThrough();
    component.ngOnDestroy();
    expect(spy).toHaveBeenCalled();
    expect(component.selectedBidSubscription.closed).toBe(true);
  });

  it('should unsubscribe savedProjectDetailsSubscription on calling ngOnDestroy()', () => {
    component.savedProjectDetailsSubscription = new Subscription(() => { });
    const spy = spyOn(component.savedProjectDetailsSubscription, 'unsubscribe').and.callThrough();
    component.ngOnDestroy();
    expect(spy).toHaveBeenCalled();
    expect(component.savedProjectDetailsSubscription.closed).toBe(true);
  });

  it('should return createProjectBidList if isCreateProjectScreen is true on calling getCarouselData()', () => {
    component.createProjectBidList = testCreateProjectBidList;
    component.projectBidList = testProjectBidList;
    component.isCreateProjectScreen = true;
    const result = component.getCarouselData();
    expect(result).toEqual(component.createProjectBidList);
  });

  it('should return createProjectBidList if isCreateProjectScreen is false on calling getCarouselData()', () => {
    component.createProjectBidList = testCreateProjectBidList;
    component.projectBidList = testProjectBidList;
    component.isCreateProjectScreen = false;
    const result = component.getCarouselData();
    expect(result).toEqual(component.projectBidList);
  });

  it(`should not set shouldShowFormModifiedDialog to true if isCreateProjectScreen and disableSubMenu
    are true on calling onSubMenuSelection`, () => {
    // Arrange
    component.jobSubMenu = testJobSubMenu;
    commonService.isFormModified = true;
    nonTraneService.isNonTraneFormUpdated = true;
    menuItem = { text: 'Address', route: 'address', path: 'address', cssClass: '' };
    component.isCreateProjectScreen = true;
    component.disableSubMenu = true;
    const clickEvent = { stopPropagation: () => { } } as Event;
    // Act
    component.onSubMenuSelection(menuItem, clickEvent);
    // Assert
    expect(component.shouldShowFormModifiedDialog).toBe(false);
  });

  it(`should set shouldShowFormModifiedDialog to true if isCreateProjectScreen is true and disableSubMenu
    is false on calling onSubMenuSelection`, () => {
    // Arrange
    component.jobSubMenu = testJobSubMenu;
    commonService.isFormModified = true;
    nonTraneService.isNonTraneFormUpdated = true;
    menuItem = { text: 'Address', route: 'address', path: 'address', cssClass: '' };
    component.shouldShowFormModifiedDialog = false;
    component.isCreateProjectScreen = true;
    component.disableSubMenu = false;
    const clickEvent = { stopPropagation: () => { } } as Event;
    // Act
    component.onSubMenuSelection(menuItem, clickEvent);
    // Assert
    expect(component.shouldShowFormModifiedDialog).toBe(true);
  });

  it(`should set disableSubMenu to false if active slide index bid has credit project number
    on calling ngOnInit()`, () => {
    component.createProjectBidList = testCreateProjectBidList;
    spyOn(commonService, 'getBidsList').and.returnValue(Observable.of(testProjectBidList));
    component.disableSubMenu = undefined;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(3);
    component.ngOnInit();
    expect(component.disableSubMenu).toBe(false);
  });

  it(`should set disableSubMenu to true if active slide index bid does not has credit project number
    on calling ngOnInit()`, () => {
    component.createProjectBidList = testCreateProjectBidList;
    spyOn(commonService, 'getBidsList').and.returnValue(Observable.of(testProjectBidList));
    component.disableSubMenu = false;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.ngOnInit();
    expect(component.disableSubMenu).toBe(true);
  });

  it(`should assign true for shouldShowFormModifiedDialog if job sub menu is selected
    on calling onSubMenuSelection`, () => {
    // Arrange
    component.jobSubMenu = testJobSubMenu;
    commonService.isFormModified = true;
    nonTraneService.isNonTraneFormUpdated = true;
    menuItem = { text: 'Configure', route: 'configure', path: 'configure', cssClass: '' };
    component.shouldShowFormModifiedDialog = false;
    component.isCreateProjectScreen = true;
    component.disableSubMenu = true;
    const clickEvent = { stopPropagation: () => { } } as Event;
    // Act
    component.onSubMenuSelection(menuItem, clickEvent);
    // Assert
    expect(component.shouldShowFormModifiedDialog).toBe(true);
  });

  it(`should set activeProjectBidIndex corresponding to projectBidList when active bid has credit project number
    on calling ngOnInit()`, () => {
    component.createProjectBidList = testCreateProjectBidList;
    component.projectBidList = testProjectBidList;
    component.activeProjectBidIndex = undefined;
    component.isCreateProjectScreen = true;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(2);
    component.ngOnInit();
    expect(component.activeProjectBidIndex).toBe(0);
  });

  it(`should not call triggerPreValidation when active bid does not has credit project number
    on calling ngOnInit()`, () => {
    const spy = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    component.projectBidList = testProjectBidList;
    component.isCreateProjectScreen = true;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(1);
    component.ngOnInit();
    expect(spy).not.toHaveBeenCalled();
  });

  it(`should set startValidation to false and call slideConfiguration on calling handleSavedBidInCarousel()`, () => {
    const spy = spyOn(component, 'slideConfiguration');
    component.createProjectBidList = testCreateProjectBidList;
    component.savedProjectCount = 0;
    const savedProjectDetails = {
      bidAlternateId: 656108,
      creditJobNumber: 'L380995',
      updatedProjectBidList: testProjectBidList
    };
    component.startValidation = true;
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(savedProjectDetails);
    expect(component.startValidation).toBe(false);
    expect(spy).toHaveBeenCalled();
  });

  it(`should update projectBidList when isCreateProjectScreen is true
    on calling handleSavedBidInCarousel()`, () => {
    component.createProjectBidList = testCreateProjectBidList;
    const savedProjectDetails = {
      bidAlternateId: 656108,
      creditJobNumber: 'L380995',
      updatedProjectBidList: testProjectBidList
    };
    component.isCreateProjectScreen = true;
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(savedProjectDetails);
    expect(component.projectBidList).toBe(savedProjectDetails.updatedProjectBidList);
  });

  it(`should not update projectBidList when isCreateProjectScreen is false
    on calling handleSavedBidInCarousel()`, () => {
    component.createProjectBidList = testCreateProjectBidList;
    const savedProjectDetails = {
      bidAlternateId: 656108,
      creditJobNumber: 'L380995',
      updatedProjectBidList: testProjectBidList
    };
    component.isCreateProjectScreen = false;
    component.handleSavedBidInCarousel();
    commonService.savedProjectDetails.next(savedProjectDetails);
    expect(component.projectBidList).toEqual([]);
  });

  it(`should call setBidsWithPricingError method  if creditJobId is zero on calling clickRefreshIcon method`, () => {
    component.jobBidList = testProjectBidList;
    component.creditJobId = 0;
    component.enablePricingValidation = true;
    const spySetBidsWithPricingError = spyOn(component, 'setBidsWithPricingError');
    component.clickRefreshIcon();
    expect(spySetBidsWithPricingError).toHaveBeenCalled();
  });

  it(`should not call getPricingValidationDetails method when creditJobNumber is not null on calling
      setBidsWithPricingError method`, () => {
    testProjectBidList[0].creditJobNumber = 'L123';
    component.jobBidList = testProjectBidList;
    component.creditJobId = 0;
    const spyGetPricingValidationDetails = spyOn(errorsAndWarningsPanelService, 'getPricingValidationDetails');
    component.setBidsWithPricingError(component.jobBidList);
    expect(spyGetPricingValidationDetails).not.toHaveBeenCalled();
  });

  it(`should call getPricingValidationDetails when creditJobNumber is null on calling setBidsWithPricingError method`, () => {
    testProjectBidList[0].creditJobNumber = null;
    component.jobBidList = testProjectBidList;
    component.creditJobId = 0;
    const bidsWithPricingError = [{ bidAlternateId: 656110, isPricingError: false }];
    const spyGetPricingValidationDetails = spyOn(errorsAndWarningsPanelService, 'getPricingValidationDetails').
      and.returnValue(of(bidsWithPricingError));
    component.setBidsWithPricingError(component.jobBidList);
    expect(spyGetPricingValidationDetails).toHaveBeenCalledWith(121, 12, [656110]);
  });

  it(`should set bidIdsWithoutPricingError if response has isPricingError as false when setBidsWithPricingError method is called`, () => {
    component.jobBidList = testProjectBidList;
    component.bidsWithPricingError = [];
    const bidsWithPricingError = [{ bidAlternateId: 656110, isPricingError: false }];
    spyOn(errorsAndWarningsPanelService, 'getPricingValidationDetails').and.returnValue(of(bidsWithPricingError));
    const spyBidsWithPricingError = spyOn(errorsAndWarningsPanelService.bidIdsWithPricingError, 'next');
    component.setBidsWithPricingError(component.jobBidList);
    expect(errorsAndWarningsPanelService.bidIdsWithoutPricingError).toEqual([656110]);
    expect(spyBidsWithPricingError).toHaveBeenCalled();
  });

  it(`should set bidIdsWithPricingError when response has isPricingError as true if setBidsWithPricingError is called`, () => {
    component.jobBidList = testProjectBidList;
    const bidsWithPricingError = [{ bidAlternateId: 656110, isPricingError: true }];
    spyOn(errorsAndWarningsPanelService, 'getPricingValidationDetails').and.returnValue(of(bidsWithPricingError));
    const spyBidsWithPricingError = spyOn(errorsAndWarningsPanelService.bidIdsWithPricingError, 'next');
    component.setBidsWithPricingError(component.jobBidList);
    expect(component.bidsWithPricingError).toEqual([656110]);
    expect(spyBidsWithPricingError).toHaveBeenCalled();
  });

  it(`should not set bidIdsWithPricingError if response is null when setBidsWithPricingError method is called`, () => {
    component.jobBidList = testProjectBidList;
    spyOn(errorsAndWarningsPanelService, 'getPricingValidationDetails').and.returnValue(of(null));
    const spyBidsWithPricingError = spyOn(errorsAndWarningsPanelService.bidIdsWithPricingError, 'next');
    component.setBidsWithPricingError(component.jobBidList);
    expect(spyBidsWithPricingError).not.toHaveBeenCalled();
  });

  it(`should not call setBidsWithPricingError method if enablePricingValidation is false on calling clickRefreshIcon method`, () => {
    component.jobBidList = testProjectBidList;
    component.creditJobId = 0;
    component.enablePricingValidation = false;
    const spySetBidsWithPricingError = spyOn(component, 'setBidsWithPricingError');
    component.clickRefreshIcon();
    expect(spySetBidsWithPricingError).not.toHaveBeenCalled();
  });

  it(`should disable all assign sales orders sub menu on call of enableDisableSubMenus if projectCreditJobId is not
   null or isTransmitted is true`, () => {
    component.projectCreditJobId = 1234;
    component.isTransmitted = true;
    component.orderServiceMenuItems = [{
      text: assignSalesOrdersText,
      disabled: true,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(true);
  });

  it('should update the path of the assign sales orders menu item on calling updateOrderServicesMenu', () => {
    component.orderServiceMenuItems = [{
      text: assignSalesOrdersText,
      disabled: true,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    }];
    component.updateOrderServicesMenu(assignSalesOrdersText, 100, 100, 1000);
    expect(component.orderServiceMenuItems[0].path).toBe('/jobs-list/100/1000/projects/CreditJobs/100/assign-sales-orders');
  });

  it('should set route when isTransmitted is true and isCopiedDownCreditJob is true on calling updateAssignSalesOrderRoutes', () => {
    const item = { route: '', path: '' };
    component.projectBidList = [{ localCreditJobId: 10, isCopiedDownCreditJob: true }] as BidsListModel[];
    component.isTransmitted = true;
    component.isProdOrStageEnvironment = false;
    component.activeProjectBidIndex = 0;
    component.isArchivedCreditJobPresent = false;
    component.updateAssignSalesOrderRoutes(item, 134, 12, 12345);
    expect(item.route).toEqual(component.assignSalesOrdersRoute);
    expect(item.path).toBe('/jobs-list/134/12/projects/CreditJobs/10/assign-sales-orders');
  });

  it('should set route when isTransmitted is true and isCopiedDownCreditJob is false or isTransmitted is false on calling updateAssignSalesOrderRoutes', () => {
    const item = { route: '', path: '' };
    component.projectCreditJobId = 10;
    component.projectBidList = [{ localCreditJobId: 10, isCopiedDownCreditJob: false }] as BidsListModel[];
    component.isTransmitted = true;
    component.activeProjectBidIndex = 0;
    component.isArchivedCreditJobPresent = false;
    component.updateAssignSalesOrderRoutes(item, 134, 12, 12345);
    expect(item.route).toEqual('assign-sales-orders');
  });

  it(`should navigate to transmitted assign sales order details screen when menuItem route
  is assign-sales-orders on calling onMenuSelect`, () => {
    component.assignSalesOrderType = 'Transmitted';
    component.projectType = DisplayModeEnum.Transmitted;
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Assign Sales Orders',
        route: 'assign-sales-orders',
        cssClass: '',
        path: 'assign-sales-orders',
        disable: false,
      }];
    const spyUpdateProjectType = spyOn(component, 'updateProjectType');
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(spyUpdateProjectType).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: 'Transmitted' }, relativeTo: activatedRoute,
    });
  });

  it(`should navigate to history assign sales order details screen when menuItem route
  is assign-sales-orders on calling onMenuSelect`, () => {
    component.projectType = 'History';
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Assign Sales Orders',
        route: 'assign-sales-orders',
        cssClass: '',
        path: 'assign-sales-orders',
        disable: false,
      }];
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: DisplayModeEnum.History }, relativeTo: activatedRoute,
    });
  });

  it(`should navigate to untransmitted assign sales order details screen when assignSalesOrderType
  is untransmitted on calling onMenuSelect`, () => {
    component.assignSalesOrderType = 'Untransmitted';
    component.projectType = DisplayModeEnum.Untransmitted;
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Assign Sales Orders',
        route: 'assign-sales-orders',
        cssClass: '',
        path: 'assign-sales-orders',
        disable: false,
      }];
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: 'Untransmitted' }, relativeTo: activatedRoute,
    });
  });

  it('should set event name as assign sales order when current state is assign sales order on calling setPrevalidationPayload()', () => {
    component.currentState = 'assign-sales-orders';
    const spyTriggerPreValidation = spyOn(component, 'triggerPreValidation');
    component.setPrevalidationPayload(component.activeBidAlternateId, component.creditJobId);
    expect(component.eventName).toEqual('AssignSalesOrder');
    expect(spyTriggerPreValidation).toHaveBeenCalled();
  });

  it(`should set value of doesUserHaveEditAccess to true when isUserHasEditAccess$ is true on calling ngOnInit`, () => {
    roleService.isUserHasEditAccess$ = new BehaviorSubject(true);
    component.doesUserHaveEditAccess = false;
    component.ngOnInit();
    expect(component.doesUserHaveEditAccess).toBe(true);
  });

  it(`should set value of doesUserHaveEditAccess to false when isUserHasEditAccess$ is false on calling ngOnInit`, () => {
    roleService.isUserHasEditAccess$ = new BehaviorSubject(false);
    component.doesUserHaveEditAccess = true;
    component.ngOnInit();
    expect(component.doesUserHaveEditAccess).toBe(false);
  });

  it(`should set isCopiedDownCreditProject as true if isTransmitted and isCopiedDownCreditJob is true
      on calling ngOnInit()`, () => {
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    testProjectBidList[0].isTransmitted = true;
    testProjectBidList[0].isCopiedDownCreditJob = true;
    component.projectBidList = testProjectBidList;
    component.ngOnInit();
    expect(component.isCopiedDownCreditProject).toBe(true);
  });

  it(`should set isCopiedDownCreditProject as false if isTransmitted is false and isCopiedDownCreditJob is false
      on calling ngOnInit()`, () => {
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    testProjectBidList[0].isTransmitted = false;
    testProjectBidList[0].isCopiedDownCreditJob = false;
    component.projectBidList = testProjectBidList;
    component.ngOnInit();
    expect(component.isCopiedDownCreditProject).toBe(false);
  });

  it(`should show success toaster message if the response is success
  and the current state is assign sales orders on calling triggerPreValidation`, () => {
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    commonService.isPreValidationExit = false;
    component.startValidation = true;
    component.startAssignSalesOrderValidation = true;
    component.currentState = '';
    const preValidationPayload = {
      eventName: 'PreValidation',
      rootEntityName: 'Job',
      rootEntityId: component.jobId,
      additionalInfo: '{BidAlternateId:' + component.activeBidAlternateId + ',CreditJobId:' + component.creditJobId + '}',
    };
    const spyValidationMessagesCount = spyOn(component, 'fetchValidationMessagesCount');
    const spyRefresh = spyOn(commonService.refreshErrorsAndWarningPanel, 'next');
    spyOn(validationErrorService, 'postPreValidate').and.returnValue(of('Success'));
    component.triggerPreValidation();
    expect(spyValidationMessagesCount).toHaveBeenCalled();
    expect(spyRefresh).not.toHaveBeenCalled();
    expect(spyBaseUrl).not.toHaveBeenCalled();
  });

  it(`should call enableDisableAON on calling ngOnInit()`, () => {
    component.createProjectBidList = testCreateProjectBidList;
    component.enableMirrorSalesOrder = true;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.projectBidList = testProjectBidList;
    component.previousCreditJobId = 2094618;
    spyOn(commonService, 'getBaseUrl');
    component.ngOnInit();
    expect(component.enableDisableAON).toHaveBeenCalled();
  });

  it(`should set isEditable to true when untransmittedProject is true, lock is allow and isOracleProjectIndicator
      is true on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = true;
    component.isCopiedDownCreditProject = false;
    enableDisableAONSpy.and.callThrough();
    component.drAddressId = testDrAddressId;
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDER);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Allow
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditUntransmittedContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(DisplayModeEnum.Untransmitted, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(true);
  });

  it(`should set isEditable to false when untransmittedProject is true, lock is deny and isOracleProjectIndicator
      is true on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = true;
    component.isCopiedDownCreditProject = false;
    enableDisableAONSpy.and.callThrough();
    component.drAddressId = testDrAddressId;
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDER);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Deny
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditUntransmittedContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(DisplayModeEnum.Untransmitted, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(false);
  });

  it(`should set isEditable to false when untransmittedProject is true, lock is allow and isOracleProjectIndicator
      is false on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = true;
    component.isCopiedDownCreditProject = false;
    basicInfoData.isOracleProjectIndicator = false;
    component.drAddressId = testDrAddressId;
    enableDisableAONSpy.and.callThrough();
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDER);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Allow
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditUntransmittedContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(DisplayModeEnum.Untransmitted, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(false);
  });

  it(`should set isEditable to false when untransmittedProject is true, lock is deny and isOracleProjectIndicator
      is false on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = true;
    component.isCopiedDownCreditProject = false;
    basicInfoData.isOracleProjectIndicator = false;
    component.drAddressId = testDrAddressId;
    enableDisableAONSpy.and.callThrough();
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDER);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Deny
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditUntransmittedContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(DisplayModeEnum.Untransmitted, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(false);
  });

  it(`should set isEditable to true when copiedDownProject is true, lock is allow and isOracleProjectIndicator
      is true on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = false;
    component.isCopiedDownCreditProject = true;
    component.projectBidList[0].localCreditJobId = testCreditJobNumber;
    basicInfoData.isOracleProjectIndicator = true;
    enableDisableAONSpy.and.callThrough();
    component.drAddressId = testDrAddressId;
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDERGATEWAY);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Allow
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditCopiedDownContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(appConstants.TransmittedCopiedDownDisplayMode, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(true);
  });

  it(`should set isEditable to false when copiedDownProject is true, lock is deny and isOracleProjectIndicator
      is true on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = false;
    component.isCopiedDownCreditProject = true;
    component.projectBidList[0].localCreditJobId = testCreditJobNumber;

    enableDisableAONSpy.and.callThrough();
    component.drAddressId = testDrAddressId;
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDERGATEWAY);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Deny
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditCopiedDownContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(appConstants.TransmittedCopiedDownDisplayMode, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(false);
  });

  it(`should set isEditable to false when copiedDownProject is true, lock is allow and isOracleProjectIndicator
      is false on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = false;
    component.isCopiedDownCreditProject = true;
    component.projectBidList[0].localCreditJobId = testCreditJobNumber;
    basicInfoData.isOracleProjectIndicator = false;
    component.drAddressId = testDrAddressId;
    enableDisableAONSpy.and.callThrough();
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDERGATEWAY);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Allow
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditCopiedDownContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(appConstants.TransmittedCopiedDownDisplayMode, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(false);
  });

  it(`should set isEditable to false when copiedDownProject is true, lock is deny and isOracleProjectIndicator
      is false on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUntransmittedCreditProject = false;
    component.isCopiedDownCreditProject = true;
    component.projectBidList[0].localCreditJobId = testCreditJobNumber;
    basicInfoData.isOracleProjectIndicator = false;
    component.drAddressId = testDrAddressId;
    enableDisableAONSpy.and.callThrough();
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDERGATEWAY);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Deny
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditCopiedDownContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;

    const checkLockSpy = spyOn(camGatewayService, 'checkCamGatewayStatus').and.returnValue(of(executionStatus));

    component.enableDisableAON(0);
    expect(checkLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(baseUrlSpy).toHaveBeenCalledWith(appConstants.TransmittedCopiedDownDisplayMode, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isEditable).toBe(false);
  });

  it(`should set isUserIdLocked to true when userId is not null on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUserIdLocked = false;
    component.isUntransmittedCreditProject = true;
    component.isCopiedDownCreditProject = false;
    creditProjectService.islockUserId = new Subject();
    enableDisableAONSpy.and.callThrough();
    component.drAddressId = testDrAddressId;
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDER);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Allow
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditUntransmittedContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;
    component.enableDisableAON(0);
    creditProjectService.islockUserId.next(camInputRequest.userId);
    expect(baseUrlSpy).toHaveBeenCalledWith(DisplayModeEnum.Untransmitted, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isUserIdLocked).toBe(true);
  });

  it(`should set isUserIdLocked to false when userId is null on calling enableDisableAON`, () => {
    component.projectBidList = testProjectBidList;
    component.projectCreditJobId = testCreditJobNumber;
    component.jobId = testJobId;
    component.isUserIdLocked = true;
    component.isUntransmittedCreditProject = true;
    component.isCopiedDownCreditProject = false;
    creditProjectService.islockUserId = new Subject();
    enableDisableAONSpy.and.callThrough();
    component.drAddressId = testDrAddressId;
    spyOn(jobHeaderService, 'getUserId').and.returnValue(null);
    const baseUrlSpy = spyOn(commonService, 'getBaseUrl').and.returnValue(appConstants.API_BASE_URL_ORDER);
    const basicInfoSpy = spyOn(creditProjectService, 'getBasicInfoDetails').and.returnValue(of(basicInfoData));

    const executionStatus = {
      status: CamStatus.Deny
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.EditUntransmittedContext,
      drAddressId: testDrAddressId,
      userId: null,
      localData: {
        creditJobId: testCreditJobNumber,
        jobId: testJobId
      }
    } as ICamInput;
    component.enableDisableAON(0);
    creditProjectService.islockUserId.next(camInputRequest.userId);
    expect(baseUrlSpy).toHaveBeenCalledWith(DisplayModeEnum.Untransmitted, testDrAddressId);
    expect(basicInfoSpy).toHaveBeenCalled();
    expect(component.isUserIdLocked).toBe(false);
  });

  it(`should disable assign sales order sub menus if job is transmitted on call of
      enableDisableSubMenus`, () => {
    component.isTransmitted = true;
    component.orderServiceMenuItems = [{
      text: assignSalesOrdersText,
      disabled: false,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(true);
  });

  it(`should disable assign sales order sub menus if job is from history on call of
      enableDisableSubMenus`, () => {
    component.fromHistory = true;
    component.orderServiceMenuItems = [{
      text: assignSalesOrdersText,
      disabled: false,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(true);
  });

  it(`should not highlight assign sales order sub menu when job is untransmitted,
        has locks and edit enabled on calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: assignSalesOrdersText,
      disabled: false,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    };
    component.projectType = DisplayModeEnum.Untransmitted;
    component.fromHistory = false;
    component.isTransmitted = false;
    component.isUntransmittedCreditProject = true;
    component.isEditable = true;
    component.doesUserHaveEditAccess = true;
    component.isUserIdLocked = true;
    component.isdisabled = false;
    component.isUserHasOnlyCommissionSplitAccess = false;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(false);
  });

  it(`should not highlight assign sales order sub menu when project type is history on calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: assignSalesOrdersText,
      disabled: false,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    };
    component.projectType = DisplayModeEnum.History;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(true);
  });

  it(`should highlight assign sales order sub menu when job is transmitted on calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: assignSalesOrdersText,
      disabled: false,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    };
    component.projectType = DisplayModeEnum.Transmitted;
    component.fromHistory = false;
    component.isTransmitted = true;
    component.isUntransmittedCreditProject = false;
    component.isEditable = true;
    component.doesUserHaveEditAccess = true;
    component.isdisabled = false;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(true);
  });

  it(`should not highlight assign sales order sub menu when job is copied down,
        has locks and edit enabled on calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: assignSalesOrdersText,
      disabled: false,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    };
    component.projectType = appConstants.TransmittedCopiedDownDisplayMode;
    component.fromHistory = false;
    component.isTransmitted = true;
    component.isCopiedDownCreditProject = true;
    component.isUntransmittedCreditProject = true;
    component.isEditable = true;
    component.doesUserHaveEditAccess = true;
    component.isUserIdLocked = true;
    component.isdisabled = false;
    component.isUserHasOnlyCommissionSplitAccess = false;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(false);
  });

  it(`should highlight assign sales order sub menu when job is from history on calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: assignSalesOrdersText,
      disabled: false,
      route: assignSalesOrdersRoute,
      cssClass: '',
      path: 'css',
    };
    component.fromHistory = true;
    component.isTransmitted = true;
    component.isUntransmittedCreditProject = false;
    component.isEditable = false;
    component.doesUserHaveEditAccess = false;
    component.isdisabled = false;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(true);
  });
  it(`should set isChangeOrderDetailsDisabled as true and call handleSubmenu when change order detail is exists on calling enableDisableChangeOrderSubmenu method`, () => {
    const projectBidList = { creditJobId: 2094617 } as BidsListModel;
    const changeOrderSummaryData: IChangeOrderSummaryModel = {
      pagingItems: [{ changeOrderId: 1546 } as IPagingItem],
      pageNumber: 1,
      pageSize: 50,
      totalItemCount: 1,
      pageCount: 1,
    };
    const payload: IChangeOrderSummaryPayloadModel = {
      skip: 0,
      take: 1,
      filters: [{ columnFilters: [{ field: 'creditJobId', operator: 'eq', value: 2094617 }], logic: 'and' }],
    };
    const spyGetChangeOrderSummaryData = spyOn(changeOrderService, 'getChangeOrderSummaryData').and.returnValue(of(changeOrderSummaryData));
    const spyHandleSubmenu = spyOn(component, 'handleSubmenu');
    component.enableDisableChangeOrderSubmenu(projectBidList);
    expect(spyHandleSubmenu).toHaveBeenCalledWith(component.ChangeOrdersName, true);
    expect(component.isChangeOrderDetailsDisabled).toBe(false);
    expect(spyGetChangeOrderSummaryData).toHaveBeenCalledWith(SourceType.Order, payload);
  });

  it(`should set isChangeOrderDetailsDisabled as false and call handleSubmenu when change order detail is null on calling enableDisableChangeOrderSubmenu method`, () => {
    const projectBidList = { creditJobId: 2094617 } as BidsListModel;
    const changeOrderSummaryData: IChangeOrderSummaryModel = {
      pagingItems: null,
      pageNumber: 1,
      pageSize: 50,
      totalItemCount: 1,
      pageCount: 1,
    };
    spyOn(changeOrderService, 'getChangeOrderSummaryData').and.returnValue(of(changeOrderSummaryData));
    const spyHandleSubmenu = spyOn(component, 'handleSubmenu');
    component.enableDisableChangeOrderSubmenu(projectBidList);
    expect(spyHandleSubmenu).toHaveBeenCalledWith(component.ChangeOrdersName, false);
    expect(component.isChangeOrderDetailsDisabled).toBe(true);
  });

  it(`should enable or disable based on isChangeOrderDetailsDisabled on calling enableDisableSubMenus if isTransmitted is true`, () => {
    component.isTransmitted = true;
    component.orderServiceMenuItems = [{
      text: 'Change Orders',
      disabled: true,
      route: 'ChangeOrders',
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(component.isChangeOrderDetailsDisabled);
  });

  it(`should return true when isSalesOrderDetailsDisable and istransmitted flag is true and menuItem is salesOrder on calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'Sales Order Details',
      route: 'SalesOrder',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130356/SalesOrder',
      cssClass: '',
    };
    component.projectType = DisplayModeEnum.Transmitted;
    component.creditProjectName = 'Credit Project';
    component.isProdOrStageEnvironment = true;
    component.fromHistory = false;
    component.isTransmitted = true;
    component.isdisabled = true;
    component.isArchivedCreditJobPresent = false;
    component.isSalesOrderDetailsDisable = true;
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(true);
  });

  it(`should return true when isChangeOrderDetailsDisabled and istransmitted flag is true and menuItem is changeOrder on calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'Change Orders',
      route: 'ChangeOrder',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130356/ChangeOrder',
      cssClass: '',
    };
    component.projectType = appConstants.TransmittedCopiedDownDisplayMode;
    component.creditProjectName = 'Credit Project';
    component.isProdOrStageEnvironment = true;
    component.fromHistory = false;
    component.isTransmitted = true;
    component.isdisabled = true;
    component.isArchivedCreditJobPresent = false;
    component.isChangeOrderDetailsDisabled = true;
    expect(component.highlightDisabledSubMenu(menuItem)).toBe(true);
  });

  it(`should set isChangeOrderDetailsDisabled as false and call handleSubmenu when change order detail is null on calling enableDisableChangeOrderSubmenu method`, () => {
    const projectBidList = { creditJobId: 2094617 } as BidsListModel;
    spyOn(changeOrderService, 'getChangeOrderSummaryData').and.returnValue(Observable.throwError({ error: { messages: 'Error' } }));
    const spyDisableChangeOrderMenu = spyOn(component, 'disableChangeOrderSubmenu');
    component.enableDisableChangeOrderSubmenu(projectBidList);
    expect(spyDisableChangeOrderMenu).toHaveBeenCalled();
  });

  it('should return true when isProdOrStageEnvironment is true on calling disableNavigationToAssignSalesOrderPage', () => {
    component.isProdOrStageEnvironment = true;
    const result = component.disableNavigationToAssignSalesOrderPage('Assign Sales Orders');
    expect(result).toBe(true);
  });

  it('should return true when disableNavigationToSalesOrderDetail is true on calling disableNavigationToAssignSalesOrderPage', () => {
    spyOn(component, 'disableNavigationToSalesOrderDetail').and.returnValue(true);
    const result = component.disableNavigationToAssignSalesOrderPage('Assign Sales Orders');
    expect(result).toBe(true);
  });

  it('should return true when menu item is not sales order on calling disableNavigationToAssignSalesOrderPage', () => {
    spyOn(component, 'disableNavigationToSalesOrderDetail').and.returnValue(false);
    const result = component.disableNavigationToAssignSalesOrderPage('Bids');
    expect(result).toBe(true);
  });

  it('should return false when menu item is sales order on calling disableNavigationToAssignSalesOrderPage', () => {
    spyOn(component, 'disableNavigationToSalesOrderDetail').and.returnValue(false);
    component.enableMirrorSalesOrder = true;
    const result = component.disableNavigationToAssignSalesOrderPage('Sales Order Details');
    expect(result).toBe(false);
  });

  it('should return false when menu item is Assign Sales Orders and user have no edit access on calling disableNavigationToAssignSalesOrderPage', () => {
    spyOn(component, 'disableNavigationToSalesOrderDetail').and.returnValue(false);
    component.enableMirrorSalesOrder = true;
    component.isUserIdLocked = true;
    spyOn(component, 'doesUserIsInReadOnlyCreditProjectScreen').and.returnValue(false);
    const result = component.disableNavigationToAssignSalesOrderPage('Assign Sales Orders');
    expect(result).toBe(false);
  });

  it('should return true if isSalesOrderDetailsDisable is true and selected menu item is sales order on calling disableNavigationToSalesOrderDetail', () => {
    component.isSalesOrderDetailsDisable = true;
    const result = component.disableNavigationToSalesOrderDetail('Sales Order Details');
    expect(result).toBe(true);
  });

  it('should return false if isSalesOrderDetailsDisable is true and selected menu item is not sales order on calling disableNavigationToSalesOrderDetail', () => {
    component.isSalesOrderDetailsDisable = true;
    const result = component.disableNavigationToSalesOrderDetail('Change Order');
    expect(result).toBe(false);
  });

  it('should return true if isChangeOrderDetailsDisabled is true and selected menu item is change order on calling disableNavigationToSalesOrderDetail', () => {
    component.isChangeOrderDetailsDisabled = true;
    const result = component.disableNavigationToChangeOrderDetail('Change Orders');
    expect(result).toBe(true);
  });

  it('should return false if isChangeOrderDetailsDisabled is true and selected menu item is not change order on calling disableNavigationToSalesOrderDetail', () => {
    component.isChangeOrderDetailsDisabled = true;
    const result = component.disableNavigationToChangeOrderDetail('Sales Order');
    expect(result).toBe(false);
  });

  it('should return true if doesUserHaveEditAccess is false on calling doesUserIsInReadOnlyCreditProjectScreen', () => {
    component.doesUserHaveEditAccess = false;
    const result = component.doesUserIsInReadOnlyCreditProjectScreen();
    expect(result).toBe(true);
  });

  it('should return false if doesUserHaveEditAccess, isEditable is true on calling doesUserIsInReadOnlyCreditProjectScreen', () => {
    component.doesUserHaveEditAccess = true;
    component.isEditable = true;
    component.isUntransmittedCreditProject = true;
    const result = component.doesUserIsInReadOnlyCreditProjectScreen();
    expect(result).toBe(false);
  });

  it(`should call getChangeOrderSummaryData with orderhistory source type when projectBidList is null on calling enableDisableChangeOrderSubmenu method`, () => {
    const projectBidList = null;
    component.creditJobId = 5678;
    const changeOrderSummaryData: IChangeOrderSummaryModel = {
      pagingItems: [{ changeOrderId: 1546 } as IPagingItem],
      pageNumber: 1,
      pageSize: 50,
      totalItemCount: 1,
      pageCount: 1,
    };
    const payload: IChangeOrderSummaryPayloadModel = {
      skip: 0,
      take: 1,
      filters: [{ columnFilters: [{ field: 'creditJobId', operator: 'eq', value: component.creditJobId }], logic: 'and' }],
    };
    const spyGetChangeOrderSummaryData = spyOn(changeOrderService, 'getChangeOrderSummaryData').and.returnValue(of(changeOrderSummaryData));
    const spyHandleSubmenu = spyOn(component, 'handleSubmenu');
    component.enableDisableChangeOrderSubmenu(projectBidList);
    expect(spyHandleSubmenu).toHaveBeenCalledWith(component.ChangeOrdersName, true);
    expect(component.isChangeOrderDetailsDisabled).toBe(false);
    expect(spyGetChangeOrderSummaryData).toHaveBeenCalledWith(SourceType.OrderHistory, payload);
  });

  it(`should call getSalesOrders with salesOrdertype as history if projectType is 'History' when projectBidList is null on calling enableDisableSalesOrderDetailsSubmenu method`, () => {
    const projectBidList = null;
    component.creditJobId = 5679;
    commonService.carouselActiveSlideIndex = new BehaviorSubject(0);
    component.enableMirrorSalesOrder = true;
    component.drAddressId = 1;
    spyEnableDisableSalesOrderDetailsSubmenu.and.callThrough();
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    const spyGetSalesOrderDetails = spyOn(salesOrderService, 'getSalesOrders').and.returnValue(of(orderLineMock.salesOrderData));
    const spyHandleSubmenu = spyOn(component, 'handleSubmenu');
    component.projectType = 'History';
    component.enableDisableSalesOrderDetailsSubmenu(projectBidList);
    expect(spyBaseUrl).toHaveBeenCalled();
    expect(spyHandleSubmenu).toHaveBeenCalledWith(component.salesOrderDetailsName, true);
    expect(component.isSalesOrderDetailsDisable).toBe(false);
    expect(component.salesOrderType).toBe('history');
    expect(spyGetSalesOrderDetails).toHaveBeenCalledWith(component.creditJobId, component.skip, component.take, component.salesOrderType);
  });

  it(`should not call getSalesOrders when projectBidList is null, project type is undefined and credit job id is null on calling enableDisableSalesOrderDetailsSubmenu method`, () => {
    const projectBidList = null;
    component.creditJobId = null;
    component.projectType = undefined;
    spyEnableDisableSalesOrderDetailsSubmenu.and.callThrough();
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    const spyGetSalesOrderDetails = spyOn(salesOrderService, 'getSalesOrders').and.returnValue(of(orderLineMock.salesOrderData));
    const spyHandleSubmenu = spyOn(component, 'handleSubmenu');
    component.enableDisableSalesOrderDetailsSubmenu(projectBidList);
    expect(spyBaseUrl).toHaveBeenCalled();
    expect(spyHandleSubmenu).not.toHaveBeenCalled();
    expect(component.salesOrderType).toBe('history');
    expect(spyGetSalesOrderDetails).not.toHaveBeenCalled();
  });

  it(`should not call getChangeOrderSummaryData when projectBidList is null and credit job id is null on calling enableDisableChangeOrderSubmenu method`, () => {
    const projectBidList = null;
    component.creditJobId = null;
    const changeOrderSummaryData: IChangeOrderSummaryModel = {
      pagingItems: [{ changeOrderId: 1546 } as IPagingItem],
      pageNumber: 1,
      pageSize: 50,
      totalItemCount: 1,
      pageCount: 1,
    };
    const spyGetChangeOrderSummaryData = spyOn(changeOrderService, 'getChangeOrderSummaryData').and.returnValue(of(changeOrderSummaryData));
    const spyHandleSubmenu = spyOn(component, 'handleSubmenu');
    component.enableDisableChangeOrderSubmenu(projectBidList);
    expect(spyHandleSubmenu).not.toHaveBeenCalledWith();
    expect(spyGetChangeOrderSummaryData).not.toHaveBeenCalled();
  });

  it(`should enable sub menus on call of enableDisableSubMenus if isCopiedDownCreditProject is true`, () => {
    component.isCopiedDownCreditProject = true;
    component.orderServiceMenuItems = [{
      text: 'history',
      disabled: true,
      route: 'history',
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(false);
  });

  it(`should call onAssignSalesOrderExit on calling releaseLockAndExit() when CamStatus is allow`, () => {
    component.basicInfo = testData.basicInfoData;
    component.basicInfo.isOracleProjectIndicator = true;
    component.localCreditJobId = 43327;
    component.jobId = 1406;
    const executionStatus = {
      status: CamStatus.Allow
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.ExitProjectContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: component.localCreditJobId,
        jobId: component.jobId
      }
    } as ICamInput;
    spyOn(component.jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const spyAssignSalesOrderExit = spyOn(component, 'onAssignSalesOrderExit');
    const checkAndApplyLockSpy = spyOn(camGatewayService, 'checkAndApplyLock').and.returnValue(of(executionStatus));
    component.releaseLockAndExit();
    expect(checkAndApplyLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(spyAssignSalesOrderExit).toHaveBeenCalled();
  });

  it(`should not call onAssignSalesOrderExit on calling releaseLockAndExit() when CamStatus is deny`, () => {
    component.basicInfo = testData.basicInfoData;
    component.basicInfo.isOracleProjectIndicator = true;
    component.localCreditJobId = 43327;
    component.jobId = 1406;
    const executionStatus = {
      status: CamStatus.Deny
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.ExitProjectContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: component.localCreditJobId,
        jobId: component.jobId
      }
    } as ICamInput;
    spyOn(component.jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const spyAssignSalesOrderExit = spyOn(component, 'onAssignSalesOrderExit');
    const checkAndApplyLockSpy = spyOn(camGatewayService, 'checkAndApplyLock').and.returnValue(of(executionStatus));
    component.releaseLockAndExit();
    expect(checkAndApplyLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(spyAssignSalesOrderExit).not.toHaveBeenCalled();
  });

  it(`should call onAssignSalesOrderExit on calling releaseLockAndExit()
  when isUntransmittedCreditProject is set to true`, () => {
    component.basicInfo = testData.basicInfoData;
    component.basicInfo.isOracleProjectIndicator = true;
    component.isUntransmittedCreditProject = true;
    component.projectCreditJobId = 0;
    component.jobId = 1406;
    const executionStatus = {
      status: CamStatus.Allow
    } as ICamExecutionStatus;

    const camInputRequest = {
      context: CamContext.ExitProjectContext,
      drAddressId: testDrAddressId,
      userId: 'ccjqce',
      localData: {
        creditJobId: component.projectCreditJobId,
        jobId: component.jobId
      }
    } as ICamInput;
    spyOn(component.jobHeaderService, 'getUserId').and.returnValue('ccjqce');
    const spyAssignSalesOrderExit = spyOn(component, 'onAssignSalesOrderExit');
    const checkAndApplyLockSpy = spyOn(camGatewayService, 'checkAndApplyLock').and.returnValue(of(executionStatus));
    component.releaseLockAndExit();
    expect(checkAndApplyLockSpy).toHaveBeenCalledWith(camInputRequest);
    expect(spyAssignSalesOrderExit).toHaveBeenCalled();
  });

  it('should call commissionSplitAccessStatus of common service with true when the current draddress id doesnot' +
    'matches with office selector list', () => {
      component.drAddressId = 122;
      component.isCreditJobsUrl = true;
      const spyGetOfficeSelectorList = spyOn(fService, 'getOfficeSelectorList').and.returnValue(Observable.of([{
        salesOfficeName: 'Billings',
        drAddressId: 121,
        country: 'USA',
        crmIntegrationInd: 'Y',
        groupName: 'CTXDBSELECTOR',
      }]));
      const spyCommissionSplitAccessStatus = spyOn(commonService, 'commissionSplitAccessStatus');
      component.setCommissionSplitAccessStatus();
      expect(spyGetOfficeSelectorList).toHaveBeenCalled();
      expect(spyCommissionSplitAccessStatus).toHaveBeenCalledWith(true);
    });

  it('should call commissionSplitAccessStatus of common service with false when the current draddress id' +
    'matches with office selector list', () => {
      component.drAddressId = 122;
      component.isCreditJobsUrl = true;
      const spyGetOfficeSelectorList = spyOn(fService, 'getOfficeSelectorList').and.returnValue(Observable.of([{
        salesOfficeName: 'Billings',
        drAddressId: 122,
        country: 'USA',
        crmIntegrationInd: 'Y',
        groupName: 'CTXDBSELECTOR',
      }]));
      const spyCommissionSplitAccessStatus = spyOn(commonService, 'commissionSplitAccessStatus');
      component.setCommissionSplitAccessStatus();
      expect(spyGetOfficeSelectorList).toHaveBeenCalled();
      expect(spyCommissionSplitAccessStatus).toHaveBeenCalledWith(false);
    });

  it('should not call getOfficeSelectorList when isCreditJobsUrl is false on calling setCommissionSplitAccessStatus', () => {
    component.drAddressId = 122;
    component.isCreditJobsUrl = false;
    const spyGetOfficeSelectorList = spyOn(fService, 'getOfficeSelectorList').and.returnValue(Observable.of());
    const spyCommissionSplitAccessStatus = spyOn(commonService, 'commissionSplitAccessStatus');
    component.setCommissionSplitAccessStatus();
    expect(spyGetOfficeSelectorList).not.toHaveBeenCalled();
    expect(spyCommissionSplitAccessStatus).not.toHaveBeenCalled();
  });

  it('should set value for isUserHasOnlyCommissionSplitAccess and call getCreditJobNumberList when commissionSplitAccessStatus is false on calling checksCommissionSplitAccessAndFetchHeaderDetails', () => {
    commonService.commissionSplitAccessStatus(false);
    const spyGetCreditJobDetails = spyOn(component, 'getCreditJobNumberList');
    const spyFetchValidationMessagesCount = spyOn(component, 'fetchValidationMessagesCount');
    component.checksCommissionSplitAccessAndFetchHeaderDetails();
    expect(spyGetCreditJobDetails).toHaveBeenCalled();
    expect(component.isUserHasOnlyCommissionSplitAccess).toBe(false);
    expect(spyFetchValidationMessagesCount).toHaveBeenCalled();
  });

  it('should set value for enablePrevalidation and call setMenuForZeroBidsCreditProject when commissionSplitAccessStatus is true on calling checksCommissionSplitAccessAndFetchHeaderDetails', () => {
    commonService.commissionSplitAccessStatus(true);
    const spySetMenuForZeroBidsCreditProject = spyOn(component, 'setMenuForZeroBidsCreditProject');
    component.checksCommissionSplitAccessAndFetchHeaderDetails();
    expect(spySetMenuForZeroBidsCreditProject).toHaveBeenCalled();
    expect(component.enablePrevalidation).toBe(false);
  });

  it('should call updateJobMenu on calling checkUrlFragmentChange', () => {
    component.jobId = 123;
    component.drAddressId = 142;
    spyOn(component, 'updateJobMenu');
    component.prevUrlFragment = '';
    component.checkUrlFragmentChange('test/url/with#fragment1');
    expect(component.updateJobMenu).toHaveBeenCalledWith('123/142');
  });

  it('should not call updateJobMenu on calling checkUrlFragmentChange when jobId is undefined', () => {
    component.jobId = undefined;
    component.drAddressId = 142;
    spyOn(component, 'updateJobMenu');
    component.prevUrlFragment = '';
    component.checkUrlFragmentChange('test/url/with#fragment2');
    expect(component.updateJobMenu).not.toHaveBeenCalled();
  });

  it('should not call updateJobMenu on calling checkUrlFragmentChange when drAddressId is null', () => {
    component.jobId = 123;
    component.drAddressId = null;
    spyOn(component, 'updateJobMenu');
    component.prevUrlFragment = '';
    component.checkUrlFragmentChange('test/url/with#fragment2');
    expect(component.updateJobMenu).not.toHaveBeenCalled();
  });

  it('should not call updateJobMenu on calling checkUrlFragmentChange when there is no change in fragment', () => {
    component.jobId = 123;
    component.drAddressId = 1234;
    spyOn(component, 'updateJobMenu');
    component.prevUrlFragment = 'fragment1';
    component.checkUrlFragmentChange('test/url/with#fragment1');
    expect(component.updateJobMenu).not.toHaveBeenCalled();
  });


  it(`should enable or disable 'Sales Order Details' sub menu based on isSalesOrderDetailsDisable on calling
  enableDisableSubMenus if isCopiedDownCreditProject is true`, () => {
    component.isCopiedDownCreditProject = true;
    component.salesOrderDetailsName = 'Sales Order Details';
    component.orderServiceMenuItems = [{
      text: 'Sales Order Details',
      disabled: true,
      route: 'Sales Order Details',
      cssClass: '',
      path: 'css',
    }];
    component.enableDisableSubMenus();
    expect(component.orderServiceMenuItems[0].disabled).toBe(component.isSalesOrderDetailsDisable);
  });

  it(`should call getSalesOrders with salesOrdertype as Untransmitted if projectType is 'Untransmitted' and projectBidList is null on calling enableDisableSalesOrderDetailsSubmenu method`, () => {
    const projectBidList = null;
    component.creditJobId = 5679;
    component.drAddressId = 1;
    spyEnableDisableSalesOrderDetailsSubmenu.and.callThrough();
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    const spyGetSalesOrderDetails = spyOn(salesOrderService, 'getSalesOrders').and.returnValue(of(orderLineMock.salesOrderData));
    component.projectType = 'Untransmitted';
    component.enableDisableSalesOrderDetailsSubmenu(projectBidList);
    expect(spyBaseUrl).toHaveBeenCalled();
    expect(component.salesOrderType).toBe('Untransmitted');
    expect(spyGetSalesOrderDetails).toHaveBeenCalledWith(component.creditJobId, component.skip, component.take, component.salesOrderType);
  });

  it('should not modify isSalesOrderDetailsDisable if getSalesOrders is returning null and creditJobId not matches with inital creditJobId on calling enableDisableSalesOrderDetailsSubmenu method', () => {
    testProjectBidList[0].creditJobId = 2094617;
    component.isSalesOrderDetailsDisable = false;
    spyEnableDisableSalesOrderDetailsSubmenu.and.callThrough();
    const spyBaseUrl = spyOn(commonService, 'getBaseUrl');
    spyOn(salesOrderService, 'getSalesOrders').and.returnValue(of(null));
    component.creditJobIds.push(125674);
    component.enableDisableSalesOrderDetailsSubmenu(component.projectBidList[0]);
    expect(spyBaseUrl).toHaveBeenCalled();
    expect(component.isSalesOrderDetailsDisable).toBe(false);
  });

  it('should return false when menu is "Change Orders" on calling checkArchivedCreditJobPresent', () => {
    component.isArchivedCreditJobPresent = true;
    expect(component.checkArchivedCreditJobPresent(component.ChangeOrdersName)).toBe(false);
  });

  it('should return isArchivedCreditJobPresent value when menu is "Change Orders" and isArchivedCreditJobPresent is false on calling checkArchivedCreditJobPresent', () => {
    component.isArchivedCreditJobPresent = false;
    expect(component.checkArchivedCreditJobPresent(component.ChangeOrdersName)).toBe(component.isArchivedCreditJobPresent);
  });

  it('should return isArchivedCreditJobPresent value when menu is not "Change Orders" on calling checkArchivedCreditJobPresent', () => {
    expect(component.checkArchivedCreditJobPresent(component.billingModulePath)).toBe(component.isArchivedCreditJobPresent);
  });

  it(`should return true when menu is "Change Orders" and checkArchivedCreditJobPresent returns false on
  calling highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'Change Orders',
      route: 'ChangeOrder',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130356/ChangeOrder',
      cssClass: '',
      disabled: false
    };
    component.projectType = DisplayModeEnum.Untransmitted;
    component.isArchivedCreditJobPresent = true;
    component.fromHistory = false;
    component.isCopiedDownCreditProject = true;
    component.doesUserHaveEditAccess = true;
    component.isdisabled = true;
    const spy = spyOn(component, 'checkArchivedCreditJobPresent');
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(spy).toHaveBeenCalled();
    expect(result).toBe(true);
  });

  it(`should highlight disabled sub menu in create credit project screen when disableSubMenu is true on calling
    highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'Create-credit-project',
      route: 'create-credit-project',
      path: '/jobs-list/38/350149/projects/salesOffice/38/Jobs/350149/Bids/1714595/create-credit-project',
      cssClass: '',
    };
    component.projectType = 'None';
    component.isCreateProjectScreen = true;
    component.disableSubMenu = true;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(true);
  });

  it(`should return false if isUserHasOnlyCommissionSplitAccess is true and sub menu is Credit Project on calling
  highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'Credit Project',
      route: 'credit-project',
      path: '/jobs-list/38/350149/projects/credit/1714595/credit-project',
    };
    component.isUserHasOnlyCommissionSplitAccess = true;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(false);
  });

  it(`should return false if isUserHasOnlyCommissionSplitAccess is true and sub menu is sales order details on calling
  highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'Sales Order Details',
      route: 'sales-order-details',
      path: '/jobs-list/38/350149/projects/350149/credit/1714595/sales-order-details',
      cssClass: '',
    };
    component.isUserHasOnlyCommissionSplitAccess = true;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(false);
  });

  it(`should return false if isUserHasOnlyCommissionSplitAccess is false and sub menu is sales order details on calling
  highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'Sales Order Details',
      route: 'sales-order-details',
      path: '/jobs-list/38/350149/projects/350149/credit/1714595/sales-order-details',
    };
    component.isUserHasOnlyCommissionSplitAccess = false;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(false);
  });

  it(`should return true if isUserHasOnlyCommissionSplitAccess is true and sub menu is billing details on calling
  highlightDisabledSubMenu`, () => {
    menuItem = {
      text: 'billing-details',
      route: 'billing-details',
      path: '/jobs-list/38/350149/projects/350149/credit/1714595/billing-details',
    };
    component.isUserHasOnlyCommissionSplitAccess = true;
    const result = component.highlightDisabledSubMenu(menuItem);
    expect(result).toBe(true);
  });

  it(`should set projectType is Transmitted when isTransmitted is
  true bid.isCopiedDownCreditJob is false on calling updateProjectType`, () => {
    component.creditJobId = 350149;
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 350149,
      isArchivedCreditJob: false,
      isCopiedDownCreditJob: false,
      isRemnant: false,
      localCreditJobId: 0,
      archivedCreditJobId: 0,
      isTransmitted: true,
    }];
    component.updateProjectType(menuItem);
    expect(component.projectType).toBe(DisplayModeEnum.Transmitted);
  });

  it(`should set projectType is Transmitted when bid properties isTransmitted is true, isCopiedDownCreditJob is true and enableCopyDown feature flag is false
  on calling updateProjectType`, () => {
    component.creditJobId = 350149;
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 350149,
      isArchivedCreditJob: false,
      isCopiedDownCreditJob: true,
      isRemnant: false,
      localCreditJobId: 0,
      archivedCreditJobId: 0,
      isTransmitted: true,
    }];
    component.enableCopyDown = false;
    component.updateProjectType(menuItem);
    expect(component.projectType).toBe(DisplayModeEnum.Transmitted);
  });

  it(`should set projectType is Untransmitted when isCopiedDownCreditJob is true on calling updateProjectType`, () => {
    component.creditJobId = 350149;
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 0,
      isArchivedCreditJob: false,
      isCopiedDownCreditJob: true,
      isRemnant: false,
      localCreditJobId: 350149,
      archivedCreditJobId: 0,
      isTransmitted: false,
    }];
    component.updateProjectType(menuItem);
    expect(component.projectType).toBe(DisplayModeEnum.Untransmitted);
  });

  it(`should set projectType is History when isArchivedCreditJob is true on calling updateProjectType`, () => {
    component.creditJobId = 350149;
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 0,
      isArchivedCreditJob: true,
      isCopiedDownCreditJob: false,
      isRemnant: false,
      localCreditJobId: 0,
      archivedCreditJobId: 350149,
      isTransmitted: false,
    }];
    component.updateProjectType(menuItem);
    expect(component.projectType).toBe(DisplayModeEnum.History);
  });

  it(`should set projectType is History and creditJobId is 2130356 when isArchivedCreditJob is true on calling updateProjectType`, () => {
    menuItem = {
      text: 'History',
      route: 'History',
      path: '/jobs-list/101/62172/projects/CreditJobs/2130356/History',
      cssClass: '',
    };
    component.creditJobId = null;
    component.projectBidList = [{
      bidAlternateId: 186418,
      currentBidInd: 'Y',
      bidName: 'Base Bid',
      description: null,
      creditJobNumber: 'T133458',
      purchaseOrderNumber: 'FRE1007319',
      spaNumber: null,
      sellingPrice: '290',
      baseBidYesNo: 1,
      hqtrBidAlternateId: 3602051,
      hqtrCreditJobId: null,
      foe2CreatedOrdersInd: 'Y',
      isIncludeInCoordinatedJob: true,
      creditJobId: 0,
      isArchivedCreditJob: true,
      isCopiedDownCreditJob: false,
      isRemnant: false,
      localCreditJobId: 2094617,
      archivedCreditJobId: 0,
      isTransmitted: false,
    }];
    component.updateProjectType(menuItem);
    expect(component.projectType).toBe(DisplayModeEnum.History);
    expect(component.creditJobId).toBe(2130356);
  });

  it('should navigate to Untransmitted credit project screen when menuItem route is credit-project-details on calling onMenuSelect', () => {
    window.name = 'ProjectLanding_Transmitted';
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Credit Project',
        route: 'credit-project-details',
        cssClass: '',
        path: '/jobs-list/100/1000/projects/CreditJobs/100/credit-project-details',
        disable: false,
      }];
    component.projectType = DisplayModeEnum.Untransmitted;
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(router.navigate).toHaveBeenCalledWith([component.menuItems[0].subMenuItem[0].subMenu[0].path], {
      queryParams: { navFrom: 'Jobs', projectType: DisplayModeEnum.Untransmitted }, relativeTo: activatedRoute,
    });
  });

  it(`should set projectType is Untransmitted and creditJobId
  when isCopiedDownCreditJob is true on calling updateProjectType`, () => {
    menuItem = {
      text: 'Untransmitted',
      route: 'Untransmitted',
      path: '/jobs-list/101/62172/projects/CreditProject/2130356/Edit',
      cssClass: '',
    };
    component.creditJobId = null;
    component.projectBidList = [{
      isCopiedDownCreditJob: true,
      localCreditJobId: 2130356,
    }] as BidsListModel[];
    component.updateProjectType(menuItem);
    expect(component.projectType).toBe(DisplayModeEnum.Untransmitted);
    expect(component.creditJobId).toBe(2130356);
  });

  it(`should set isJobSubMenuItem as false and enable financial and orderservice
   submenu if isRebalancingScreen is true when updateJobMenu is called`, () => {
    const menu = [{
      text: 'ReviewRevenueForecast',
      disabled: true,
      route: 'ReviewRevenueForecast',
      cssClass: '',
      path: 'jobs-list/161325/30/Rebalancing/PriceSummary',
    }];
    component.isRebalancingScreen = true;
    component.financialMenuItems = menu;
    component.orderServiceMenuItems = menu;
    component.projectCreditJobId = 1234;
    component.isTransmitted = true;
    component.updateJobMenu('100/10');
    expect(component.financialMenuItems[0].disabled).toBe(false);
    expect(component.orderServiceMenuItems[0].disabled).toBe(false);
    expect(component.isJobSubMenuItem).toBe(false);
  });

  it(`should navigate to costForecastRouteUrl which is returned from setPathForFinancialSubMenuItem if
  menuItem path contains cost-forecast when onMenuSelect is called`, () => {
    component.projectType = DisplayModeEnum.Untransmitted;
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'cost-forecast',
        route: 'Forecast',
        cssClass: '',
        path: '/jobs-list/30/1234/projects/CreditJobs/2345/cost-forecast/Forecast',
        disable: false,
      }];
    const costForecastRouteUrl = '/jobs-list/30/1234/projects/CreditJobs/2130356/cost-forecast/Forecast';
    const spyForSetPathForFinancialSubMenuItem = spyOn(component, 'setPathForFinancialSubMenuItem').and.returnValue(costForecastRouteUrl);
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(spyForSetPathForFinancialSubMenuItem).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith([costForecastRouteUrl], {
      queryParams: { navFrom: 'Jobs', projectType: DisplayModeEnum.Untransmitted }, relativeTo: activatedRoute,
    });
  });

  it(`should not call setPathForFinancialSubMenuItem if menuItem path doesn't contains
   cost-forecast or billing when onMenuSelect is called`, () => {
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'cost-forecast',
        route: 'Forecast',
        cssClass: '',
        path: '/jobs-list/30/1234/projects/CreditJobs/2345/test',
        disable: false,
      }];
    const spyForSetPathForFinancialSubMenuItem = spyOn(component, 'setPathForFinancialSubMenuItem');
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(spyForSetPathForFinancialSubMenuItem).not.toHaveBeenCalled();
  });

  it(`Should return costForecastHqtrCreditJobUrl if creditJobId
   is equals to localCreditJobId of projectbidList when setPathForFinancialSubMenuItem is called`, () => {
    component.jobId = 1234;
    component.creditJobId = 2345;
    component.drAddressId = 30;
    component.projectBidList = [{
      creditJobId: 2130356,
      isCopiedDownCreditJob: false,
      localCreditJobId: 2345,
      hqtrCreditJobId: 2130356,
    }] as BidsListModel[];
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'cost-forecast',
        route: 'Forecast',
        cssClass: '',
        path: costForecastSubMenuUrl,
        disable: false,
      }];
    const costForecastHqtrCreditJobUrl = '/jobs-list/30/1234/projects/CreditJobs/'
      + `${component.projectBidList[0].hqtrCreditJobId}` + '/cost-forecast/Cost';
    const modulePath = 'cost-forecast';
    const result = component.setPathForFinancialSubMenuItem(component.menuItems[0].subMenuItem[0].subMenu[0], modulePath);
    expect(result).toBe(costForecastHqtrCreditJobUrl);
  });

  it(`Should return costForecastCreditJobIdUrl if creditJobId
   is equals to creditJobId of projectbidList when setPathForCostForecast is called`, () => {
    component.jobId = 1234;
    component.drAddressId = 30;
    component.creditJobId = 2130356;
    component.projectBidList = [{
      creditJobId: 2130356,
      isCopiedDownCreditJob: false,
      localCreditJobId: 2345,
      hqtrCreditJobId: 2130356,
    }] as BidsListModel[];
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'cost-forecast',
        route: 'Forecast',
        cssClass: '',
        path: costForecastSubMenuUrl,
        disable: false,
      }];
    const costForecastCreditJobIdUrl = '/jobs-list/30/1234/projects/CreditJobs/'
      + `${component.projectBidList[0].creditJobId}` + '/cost-forecast/Cost';
    const modulePath = 'cost-forecast';
    const result = component.setPathForFinancialSubMenuItem(component.menuItems[0].subMenuItem[0].subMenu[0], modulePath);
    expect(result).toBe(costForecastCreditJobIdUrl);
  });

  it(`should navigate to billingRouteUrl which is returned from setPathForFinancialSubMenuItem if
  menuItem path contains billing when onMenuSelect is called`, () => {
    component.creditProjectNumber = 'US-F11871';
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Billing',
        route: 'billingSummary',
        cssClass: '',
        path: '/jobs-list/30/1234/projects/CreditJobs/2511873/billing/billingSummary',
        disable: false,
      }];
    const billingRouteUrl = '/jobs-list/30/1234/projects/CreditJobs/2130356/billing/billingSummary';
    const spyForSetPathForFinancialSubMenuItem = spyOn(component, 'setPathForFinancialSubMenuItem').and.returnValue(billingRouteUrl);
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(spyForSetPathForFinancialSubMenuItem).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith([billingRouteUrl], {
      queryParams: { navFrom: 'Jobs', projectNumber: 'US-F11871' }, relativeTo: activatedRoute,
    });
  });

  it(`should not call setPathForFinancialSubMenuItem if menuItem path doesn't contains
   billing when onMenuSelect is called`, () => {
    component.menuItems[0].subMenuItem[0].subMenu = [
      {
        text: 'Billing',
        route: 'billingSummary',
        cssClass: '',
        path: '/jobs-list/30/1234/projects/CreditJobs/2345/test',
        disable: false,
      }];
    const spyForSetPathForFinancialSubMenuItem = spyOn(component, 'setPathForFinancialSubMenuItem');
    component.onMenuSelect(component.menuItems[0].subMenuItem[0].subMenu[0]);
    expect(spyForSetPathForFinancialSubMenuItem).not.toHaveBeenCalled();
  });
});
