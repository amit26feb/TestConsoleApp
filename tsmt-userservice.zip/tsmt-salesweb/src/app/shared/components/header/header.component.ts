import { animate, state, style, transition, trigger } from '@angular/animations';
import {
  Component, ElementRef, EventEmitter, HostListener, OnInit, Output, Renderer2,
  ViewChild, ViewContainerRef, ViewEncapsulation
} from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { OktaAuthService } from '@okta/okta-angular';
import { Align } from '@progress/kendo-angular-popup';
// services
import { AssignSalesOrderService } from '@tsmt/shared-acquisition-dataservices';
import { JobCoordinationValidationService } from '@tsmt/shared-acquisition-dataservices';
import { MessageCountService } from '@tsmt/shared-core';
import {
  ChangeOrderService, CreateCreditProjectService, CreditProjectService,
  IBasicInfoModel, IChangeOrderSummaryPayloadModel, ISalesOrderModel, ISelectedBidModel, SalesOrderService, SourceType
} from '@tsmt/salesweb-ordersmodule';
import { isDeployedToProd, isDeployedToStage } from '../../../../environments/environment-helper';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { environment } from '../../../../environments/environment';
import { NonTraneService } from '@tsmt/salesweb-selectionmodule';
// constants
import { AppConstants } from '../../../shared/constants/constants';
import { GlobalFilterService } from '../../../shared/services/global-filter.service';
// models
import { BidsListModel } from '../../model/bids-model';
import { IHeaderItemModel } from '../../model/header-model';
import { IPreValidation } from '../../model/validation-errors-model';
import { JobHeaderService } from '../../services/job-header.service';
import { ToasterService } from '@tsmt/shared-core';
import { WorkflowPopupService } from '../../services/workflow-popup.service';
import { ApiErrorService } from '../../services/apierror.service';
import { HttpErrorResponse } from '@angular/common/http';
import { forkJoin, Subscription } from 'rxjs';
import {
  CommonService as CommonServiceService, ErrorsAndWarningsPanelService,
  JobHeaderService as SharedJobHeaderService, RoleService, ValidationErrorService
} from '@tsmt/shared-core-salesweb';
import { CamGatewayService } from '../../services/cam-gateway.service';
import { CamContext, CamStatus, ICamInput } from '../../model/cam-data-model';
import { DisplayModeEnum } from '../../enums/display-mode-enum';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('openClose', [
      state('open', style({
        width: '300px',
      })),
      state('closed', style({
        width: 0,
      })),
      transition('open => closed', [
        animate('1s'),
      ]),
      transition('closed => open', [
        animate('0.5s'),
      ]),
      state('show-overlay', style({
        width: '100%',
      })),
      state('hide-overlay', style({
        width: '0',
      })),
      transition('show-overlay => hide-overlay', [
        animate('1s'),
      ]),
      transition('hide-overlay => show-overlay', [
        animate('0.5s'),
      ]),
    ]),
  ],
})
export class HeaderComponent implements OnInit {
  public enableMirrorSalesOrder: boolean = environment.enableMirrorSalesOrder;
  public enableCopyDown: boolean = environment.enableCopyDown;
  isSalesOrderDetailsDisable: boolean;
  public validEarthwise: boolean;
  public validClassifications: boolean;
  public validBid: boolean;
  public coordinatePopupShow = false;
  public show = false;
  public loginUserId;
  public showJobNavigation = false;
  public isProdOrStageEnvironment = isDeployedToProd() || isDeployedToStage();
  public showNavigation = false;
  public showSideNav = false;
  public workPackageUrl: string;
  public menuItems: any[];
  public message: string;
  public drAddressId: number;
  public jobId: number;
  public sideMenu: any[];
  public jobLockedUserName: string;
  public isClickInCoordinatePopup = false;
  public disableNotificationIcon = true;
  public notificationCount: number;
  public showNotification: boolean;
  public showWorkflowIcon: boolean;
  public isUserIdLocked: boolean;
  public currentUserId: string;
  public coordinateErrorCount = 0;
  public validationErrorCount = 0;
  public currentUri: string;
  public previousCreditJobId: number;
  public isJobSubMenuItem = false;
  public displayMode: string;
  public fromHistory = false;
  public isExitJobClick: boolean;
  public windowName: string;
  public selectedIndex = -1;
  public subMenuRoute = '';
  public workPackageName = 'Work Packages';
  public navigatedFrom = 'ProjectLanding';
  public isProdEnvironment = isDeployedToProd();
  public isClickInErrorsPanel = false;
  public enablePrevalidation: boolean = environment.enablePrevalidation;
  public coordinateLinkValidations: any = {
    validEarthwise: false,
    validClassifications: false,
    validBid: false,
  };

  public jobSubMenu = [
    {
      text: 'Details',
      disabled: false,
      route: 'details',
      cssClass: '',
      path: '',
    },
    {
      text: 'Configure',
      disabled: false,
      route: 'configure',
      cssClass: '',
      path: '',
    },
    {
      text: this.workPackageName,
      route: 'work-packages',
      disabled: false,
      cssClass: '',
      path: '',
    },
    {
      text: 'Bids',
      route: 'bids',
      disabled: false,
      cssClass: '',
      path: '',
    },
    {
      text: 'Price',
      route: 'price',
      disabled: false,
      cssClass: '',
      path: '',
    },
    {
      text: 'Documents',
      route: 'packagesList',
      disabled: false,
      cssClass: '',
      path: '',
    },
    {
      text: 'Coordinate',
      route: 'coordinate',
      cssClass: '',
      disabled: true,
      path: '',
    }];

  public creditProjectName = 'Credit Project';
  public salesOrderDetailsName = 'Sales Order Details';
  public ChangeOrdersName = 'Change Orders';
  public billingModulePath = 'billing';
  public assignSalesOrders = 'Assign Sales Orders';
  public orderServicesSubMenu = [this.creditProjectName, this.assignSalesOrders, this.salesOrderDetailsName,
    'History', 'IOS Notices', this.ChangeOrdersName];
  public orderServicesSubMenuProd = [this.creditProjectName, this.salesOrderDetailsName, 'History', this.ChangeOrdersName];
  public costForecastModulePath = 'cost-forecast';
  public rebalancingModulePath = 'Rebalancing';
  public financialSubMenu = [{ text: 'Billing', modulePath: this.billingModulePath, route: 'billingSummary' },
  { text: 'Forecast', modulePath: this.costForecastModulePath, route: 'Forecast' },
  { text: 'Summary', modulePath: this.costForecastModulePath, route: 'Summary' },
  { text: 'Cost Details', modulePath: this.costForecastModulePath, route: 'Cost' },
  { text: 'Credits', route: 'Credits' },
  { text: 'Price Summary', modulePath: this.rebalancingModulePath, route: 'PriceSummary' }];
  public commissionSplitAccessMenu = [this.creditProjectName, this.salesOrderDetailsName];
  public orderServiceMenuItems = [];
  public financialMenuItems = [];
  public subMenuValues = [];
  private anchorAlign: Align = { horizontal: 'left', vertical: 'bottom' };
  private popupAlign: Align = { horizontal: 'right', vertical: 'top' };
  private mobileAnchorAlign: Align = { horizontal: 'right', vertical: 'top' };
  private mobilePopupAlign: Align = { horizontal: 'right', vertical: 'bottom' };
  public margin = { horizontal: -25, vertical: 30 };
  public margin1 = { horizontal: -40, vertical: 1700 };
  public kendotooltip1: any;
  public homePageList = '/home-page-list';
  public jobPageList = '/jobs-list';
  public isShowPreValidation = true;
  public isWorkPackagePage: boolean;
  validationMessagesCount = 0;
  preValidationErrorCount = 0;
  preValidationWarningCount = 0;
  bidCount = 0;
  messageCount = 0;
  public buttonText: string[] = ['STAY', 'LEAVE'];
  public isCreateProjectScreen = false;
  public isEditCreditProjectScreen = false;
  createProjectBidList = new Array<BidsListModel>();
  savedProjectCount = 0;
  public selectedBidSubscription: Subscription;
  public savedProjectDetailsSubscription: Subscription;
  public creditProjectNumber: string;
  disableSubMenu = true;
  eventName: string;
  @ViewChild('popOverContent') popOverContent: ElementRef;
  @ViewChild('menuToggle', { static: true }) menuToggle: ElementRef;
  @ViewChild('desktopAnchor') desktopAnchor: ElementRef;
  @ViewChild('sideNav', { static: true }) sideNav: ElementRef;
  @ViewChild('sideNavLink', { static: true }) sideNavLink: ElementRef;
  @ViewChild('coordinateErrorBadge') coordinateErrorBadge: ElementRef;
  @ViewChild('mobileCoordinateErrorBadge') mobileCoordinateErrorBadge: ElementRef;
  @ViewChild('notificationContainer') notificationContainer: ElementRef;
  @ViewChild('menuContainer') menuContainer: ElementRef;
  @ViewChild('subMenuContainer') subMenuContainer: ElementRef;
  @ViewChild('errorsAndWarningsIcon') errorsAndWarningsIcon: ElementRef;
  @ViewChild('header', { read: ViewContainerRef }) headerComponentRef;
  @Output()
  jobMenuClickEvt: EventEmitter<any> = new EventEmitter();
  @Output()
  isHeaderLoaded: EventEmitter<any> = new EventEmitter();
  documentsWarning = false;
  navigationPath: any;
  documentsForm = 4;
  isShowImportJob = false;
  importJobWarning = false;
  projectMenuCarouselConfig = {
    infinite: false,
  };
  public hideExtraMenuItems = true;
  winWidth: number;
  projectBidList = new Array<BidsListModel>();
  jobBidList = new Array<BidsListModel>();
  projectCreditJobId: number;
  creditJobId: number;
  activeProjectBidIndex = 0;
  zeroBids = true;
  isCreditJobsUrl = false;
  disableJobMenu = false;
  isTransmitted: boolean;
  creditProject: string;
  isdisabled: boolean;
  currentState: string;
  navigationFrom: string;
  showRemaining = false;
  projectType: string;
  isArchivedCreditJobPresent: boolean;
  isHostCreditJob: boolean;
  isLocalCreditJob: boolean;
  isHistoryCreditJob: boolean;
  creditProjectDetailsName = 'credit-project-details';
  subMenuClassPrefix = '.sub-menu-';
  childRoute: ActivatedRoute;
  activeBidAlternateId: number;
  startValidation: boolean;
  preValidationPayload: IPreValidation;
  public archivedCreditJobIds = [];
  disableRefreshIcon = false;
  transmittedWithNoRemnantCreditJobs = [];
  shouldShowFormModifiedDialog: boolean;
  subMenuInfo: IHeaderItemModel;
  salesOrderType = 'Transmitted';
  assignSalesOrderType = 'Transmitted';
  localCreditJobId = 0;
  isUntransmittedCreditProject = false;
  isCopiedDownCreditProject = false;
  isCostForecastScreen: boolean;
  isBillingScreen: boolean;
  isRebalancingScreen: boolean;
  public bidsWithPricingError: number[];
  enablePricingValidation: boolean = environment.enablePricingValidation;
  assignSalesOrdersRoute = 'assign-sales-orders';
  doesUserHaveEditAccess = false;
  basicInfo: IBasicInfoModel;
  isEditable = false;
  public startAssignSalesOrderValidation: boolean;
  isChangeOrderDetailsDisabled: boolean;
  skip = 0;
  take = 1;
  isUserHasOnlyCommissionSplitAccess: boolean;
  prevUrlFragment = '';
  creditJobIds: number[] = [];
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public jobHeaderService: JobHeaderService,
    private oktaAuth: OktaAuthService,
    private jobService: JobsServicesService,
    public toasterService: ToasterService,
    private appConstants: AppConstants,
    private jobCoordinationValidationService: JobCoordinationValidationService,
    private salesOrderService: SalesOrderService,
    private filterService: GlobalFilterService,
    private translateService: TranslateService,
    private workflowPopupService: WorkflowPopupService,
    private commonService: CommonServiceService,
    private messageCountService: MessageCountService,
    private validationErrorService: ValidationErrorService,
    private sharedJobHeaderService: SharedJobHeaderService,
    public renderer: Renderer2,
    private errorsAndWarningsPanelService: ErrorsAndWarningsPanelService,
    private apiErrorService: ApiErrorService,
    private nonTraneService: NonTraneService,
    private createCreditProjectService: CreateCreditProjectService,
    private creditProjectService: CreditProjectService,
    private roleService: RoleService,
    private camGatewayService: CamGatewayService,
    private changeOrderService: ChangeOrderService,
    private assignSalesOrdersService: AssignSalesOrderService
  ) {
    this.router.events.subscribe((e) => {
      let currentRoute = this.route.root;
      while (currentRoute.children[0] !== undefined) {
        // get the last child route to read the params
        currentRoute = currentRoute.children[0];
        this.setJobIdAndDrAddress(currentRoute);
      }
      if (e instanceof NavigationEnd) {
        this.checkUrlFragmentChange(e.url);
        if (!this.jobId && !this.drAddressId) {
          this.jobId = currentRoute.snapshot.params['jobId'];
          this.drAddressId = +currentRoute.snapshot.params['drAddressId'];
        }
        this.activeBidAlternateId = currentRoute.snapshot.params['bidId'];
        this.creditJobId = this.getCreditJobId(e.url);
        // Storing creditJobIds for enabling or disabling Sales Order Details menu
        if (this.creditJobId !== null) {
          this.creditJobIds.push(this.creditJobId);
        }
        this.setCommissionSplitAccessStatus();
        // History credit jobs won't have bid list information so passing it as null
        this.enableDisableSalesOrderDetailsSubmenu(null);
        this.enableDisableChangeOrderSubmenu(null);
        this.findCreditJobState(e.url);
        this.showNavigation = this.checkCurrentRoute(e);
        if (this.drAddressId && this.jobId) {
          this.jobCoordinationValidationService.setParams(this.drAddressId, this.jobId);
          this.subscribeForCoordinateLinkValidation(e.url.includes('/coordinate'));
        }
        this.workPackageUrl = this.workPackagePropertyRoute(e);
        this.disableJobMenu = false;
        this.checksCommissionSplitAccessAndFetchHeaderDetails();
        this.selectedIndex = -1;
        this.isCreateProjectScreen = this.router.url.includes('create-credit-project');
        this.isBillingScreen = this.router.url.includes(this.billingModulePath);
        this.isCostForecastScreen = this.router.url.includes('cost-forecast');
        this.isRebalancingScreen = this.router.url.includes(this.rebalancingModulePath);
        this.isEditCreditProjectScreen = this.router.url.includes('Edit') && this.router.url.includes('CreditProject');
        this.savedProjectCount = 0;
        this.createProjectBidList = new Array<BidsListModel>();
        this.disableSubMenu = true;
        this.winWidth = document.documentElement.clientWidth;
      }
    });
    this.jobHeaderService.isWorkflowPanelOpen.subscribe((workflowOpen) => {
      this.showWorkflowIcon = workflowOpen;
    });
  }

  // traverses through the activated route and returns the leaf node
  getLastChildRoute(activeRoute: ActivatedRoute): ActivatedRoute {
    while (activeRoute.children.length !== 0) {
      activeRoute = activeRoute.children[0];
    }
    return activeRoute;
  }

  /**
   * Find the credit job state as local or host or history
   * @param url - the credit project url
   */
  findCreditJobState(url: string): void {
    this.isHistoryCreditJob = (url.includes(this.creditProjectDetailsName) && this.commonService.currentToggle === 'History') ||
      url.toLowerCase().includes('projecttype=history');
    this.isLocalCreditJob = (!url.includes('SalesOrders') && (url.includes('Untransmitted') || url.includes('Edit')));
    this.isHostCreditJob = (url.includes(this.creditProjectDetailsName) && this.commonService.currentToggle === 'Transmitted') ||
      url.includes('Transmitted');
  }

  /**
   * Gets the credit project number from credit project service
   */
  fetchBasicInfoDetails(): void {
    this.creditProjectService.apiBaseUrl = this.appConstants.API_BASE_URL_CREDIT_JOBS;
    if (this.projectCreditJobId) {
      this.creditProjectService.getBasicInfoDetails(this.projectCreditJobId).subscribe((basicInfo: IBasicInfoModel) => {
        this.creditProjectNumber = basicInfo.r12ProjectNumber;
      });
    }
  }

  /**
   * get credit job id from the url.
   * @param {url} - current route url
   * @returns number - credit job id
   * 10 is a radix number which denotes decimal numeral
   */

  getCreditJobId(url: string): number {
    this.isCreditJobsUrl = false;
    const splitUrl = url.split('/');
    const creditJobIndex = splitUrl.indexOf('CreditJobs');
    const creditJobIndexEdit = splitUrl.indexOf('CreditProject');
    if (creditJobIndex !== -1 || creditJobIndexEdit !== -1) {
      this.isCreditJobsUrl = true;
      const jobIndex = creditJobIndex !== -1 ? creditJobIndex : creditJobIndexEdit;
      return parseInt(splitUrl[jobIndex + 1], 10);
    } else {
      return null;
    }
  }

  /**
   * set jobId and drAddressId from the current route
   * @param {string} currentRoute: Gets the current route details
   * @returns void.
   */
  setJobIdAndDrAddress(currentRoute): void {
    if (currentRoute.snapshot.params['jobId']) {
      this.jobId = currentRoute.snapshot.params['jobId'];
    }
    if (currentRoute.snapshot.params['drAddressId']) {
      this.drAddressId = +currentRoute.snapshot.params['drAddressId'];
    }
  }

  /**
   * Assign values for submenu items
   * @returns void
   */
  setSubmenuItems(): void {
    if (this.router.url && this.router.url.split('/').length > 2 && !this.router.url.includes('exit')) {
      this.jobHeaderService.setJob(this.jobId, this.drAddressId);
    }
    this.zeroBids = false;
    this.menuItems[1].subMenuItem = {
      0: {
        subMenu: this.orderServiceMenuItems,
        title: 'Order Services',
      },
      1: {
        subMenu: this.financialMenuItems,
        title: 'Financial',
      },
    };
  }

  /**
   *  * get credit job number list
   *  * @param {string} jobId: get the JobId
   *  * @param {string} drAddressId: gets the dr adress id
   *  * @returns void.
   */
  getCreditJobNumberList(drAddressId: number, jobId: number): void {
    this.disableJobMenu = false;
    this.fromHistory = (this.updateViewState() === 'History');
    if (this.fromHistory) {
      // Disable icon for history credit projects
      this.disableRefreshIcon = true;
    }
    if (jobId && drAddressId && !this.fromHistory) {
      this.commonService.getBidsList(this.drAddressId, this.jobId, this.fromHistory).subscribe((bidsListdata) => {
        this.projectBidList = (bidsListdata != null && bidsListdata.length > 0)
          ? bidsListdata.filter((obj) => obj['creditJobNumber'] !== null) : null;
        // Getting bid list with and without credit job number to trigger prevalidation on bid level and credit job level.
        this.jobBidList = (bidsListdata != null && bidsListdata.length > 0)
          ? bidsListdata : null;
        if (this.isCreateProjectScreen) {
          this.buildCreateProjectBidsList();
        }
        const data = bidsListdata?.find(x => x.isArchivedCreditJob);
        if (data && data !== undefined) {
          this.isArchivedCreditJobPresent = data.isArchivedCreditJob;
        }
        if (this.projectBidList !== null && this.projectBidList.length > 0) {
          // Make refresh icon disable when all credit projects archived
          this.archivedCreditJobIds = this.projectBidList.filter(x => x.isArchivedCreditJob);

          // Check transmitted with no remnant credit jobs
          this.transmittedWithNoRemnantCreditJobs = this.projectBidList.filter(bid => (bid.isTransmitted && !bid.isRemnant &&
            !bid.isCopiedDownCreditJob));

          // Disable refersh icon for archived, transmitted with no remnant credit jobs in job level
          //  and transmitted with no remnant credit job level
          if (this.archivedCreditJobIds.length === this.projectBidList.length ||
            (this.projectBidList.length === this.transmittedWithNoRemnantCreditJobs.length) || (this.creditJobId &&
              this.transmittedWithNoRemnantCreditJobs.length > 0 &&
              (this.transmittedWithNoRemnantCreditJobs.filter(x => x.creditJobId === this.creditJobId)).length > 0)) {
            this.disableRefreshIcon = true;
          } else {
            this.disableRefreshIcon = false;
          }
          this.getActiveProjectIndex(this.projectBidList, this.creditJobId);
          this.setSubmenuItems();
        } else {
          this.zeroBids = true;
          this.setMenuForZeroBidsCreditProject();
          if (this.activeBidAlternateId) {
            this.triggerPreValidation();
          }
        }
      });
    } else if (jobId && this.fromHistory && this.zeroBids) {
      this.setSubmenuItems();
    }
  }

  /**
   * This method displays the sub menu for projects and disbale job menu
   * when the route is credit jobs and there are no bids for the job of current credit project
   * @returns void
   */
  setMenuForZeroBidsCreditProject(): void {
    if (this.isCreditJobsUrl) {
      this.setSubmenuItems();
      this.disableJobMenu = true;
    }
  }

  /**
   * Gets css class for the menu-items
   * @param {string} menuItem: menu item name
   * @returns string - Returns css class based on the values
   */
  getCssClass(menuItem: string): string {
    if (this.isCreateProjectScreen && menuItem === 'Project') {
      return '';
    }
    return (((this.zeroBids && menuItem === 'Project' && (!this.fromHistory && this.projectType !== 'History')) ||
      (menuItem === 'Job' && (this.fromHistory || this.disableJobMenu)) ||
      (menuItem === 'Job' && this.isArchivedCreditJobPresent && this.projectType === 'History') ||
      (menuItem === 'Project' && !this.isShowPreValidation)) ? 'hide-menu-item' : '');
  }

  /**
   * Checks whether error count should be shown for the menu-item
   * @param {string} menuItem: menu item name
   * @param {number} coordinateErrorCount: coordinate error count
   * @returns boolean - Returns true or false based on the values
   */
  showErrorCount(menuItem: string, coordinateErrorCount: number): boolean {
    return (menuItem === 'Job' && coordinateErrorCount !== 0 && !this.fromHistory && !this.disableJobMenu
      && !this.isArchivedCreditJobPresent);
  }

  /**
   * getting current selected toggle information from common service
   */
  updateViewState(): string {
    if (!this.commonService.currentToggle) {
      this.windowName = window.name;
      if (this.windowName.split('_') && this.windowName.split('_')[3]) {
        this.displayMode = this.windowName.split('_')[3];
        this.commonService.setSelectedToggle(this.windowName.split('_')[3]);
      }
    } else {
      this.displayMode = this.commonService.currentToggle;
    }
    return this.displayMode;

  }

  /**
   * Gets the active project index
   * @param projectBidList - stored projectBid list
   * @param creditJobId - get creditJobId from route
   */
  getActiveProjectIndex(projectBidList: BidsListModel[], creditJobId: number): void {
    if (creditJobId !== null) {
      if (this.isLocalCreditJob) {
        this.activeProjectBidIndex = projectBidList.findIndex((obj) => obj.localCreditJobId === creditJobId);
      } else if (this.isHostCreditJob) {
        this.activeProjectBidIndex = projectBidList.findIndex((obj) => obj.creditJobId === creditJobId);
      } else if (this.isHistoryCreditJob) {
        this.activeProjectBidIndex = projectBidList.findIndex((obj) => obj.archivedCreditJobId === creditJobId);
      }
    }
    if (this.activeProjectBidIndex !== -1) {
      this.slideConfiguration(this.activeProjectBidIndex);
    }
  }


  workPackagePropertyRoute(e: NavigationEnd): string {
    this.isWorkPackagePage = e.url.includes('work-packages');
    const url = e.url.split('/').pop();
    return !this.checkCurrentRoute(e) ? url : '';
  }

  checkCurrentRoute(e: NavigationEnd): boolean {
    // hiding for projects page, billing page, workpackages page and for exit job
    if (e.url.includes('/home-page-list') || e.url.includes('exit') || e.url.includes('billing')
      || e.url.includes('projects') || e.url.includes('work-packages)') || e.url.includes('cost-forecast')) {
      return false;
    } else {
      return true;
    }
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event) {
    if (!(this.popOverContent && this.menuToggle && this.popOverContent.nativeElement.contains(event.target) ||
      this.menuToggle.nativeElement.contains(event.target))) {
      this.show = false;
    }
    if (!(this.sideNav && this.sideNavLink && (this.sideNav.nativeElement.contains(event.target) ||
      this.sideNavLink.nativeElement.contains(event.target)))) {
      this.showSideNav = false;
    }
    this.toggleCoordinatePopup(event);
    document.querySelectorAll('.stack-container')?.forEach((vMenu) => {
      vMenu.classList.add('d-none');
    });
    this.hideExtraMenuItems = true;
    this.toggleErrorsPanel(event);
  }

  @HostListener('window:orientationchange')
  public hideNav(): void {
    this.show = false;
    this.showSideNav = false;
    this.coordinatePopupShow = false;
  }

  // event fire on back button
  @HostListener('window:popstate', ['$event'])
  popstateHandler(event: Event): void {
    // To close the unpinned errors and warnings panel on click of back button
    this.toggleErrorsPanel(event);
  }

  ngOnInit() {
    this.startAssignSalesOrderValidation = false;
    this.translateService.setDefaultLang('en');
    if (this.isProdOrStageEnvironment) {
      this.orderServicesSubMenuProd.forEach((ele) => {
        this.setOrderServicesSubMenu(ele);
      });
    } else {
      this.orderServicesSubMenu.forEach((ele) => {
        this.setOrderServicesSubMenu(ele);
      });
    }
    this.activeBidAlternateId = +this.route.snapshot.params['bidId'];
    this.sharedJobHeaderService.showFormModifiedDialog.subscribe((shouldShowFormModifiedDialogBox) => {
      this.isExitJobClick = shouldShowFormModifiedDialogBox.exitJobClick;
      this.shouldShowFormModifiedDialog = shouldShowFormModifiedDialogBox.showDialog;
    });

    this.financialSubMenu.forEach((ele) => {
      this.financialMenuItems.push({
        text: ele.text,
        modulePath: ele.modulePath,
        route: ele.route,
        cssClass: '',
      });
    });

    this.roleService.isUserHasEditAccess$.subscribe((isUserHasEditAccess) => {
      this.doesUserHaveEditAccess = isUserHasEditAccess;
    });

    const projectMenuItems = this.orderServiceMenuItems.concat(this.financialMenuItems);
    this.menuItems = [
      {
        text: 'Job',
        name: 'Job',
        disabled: false,
        route: 'jobs',
        type: '',
        items: this.jobSubMenu,
        subMenuItem: {
          0: {
            subMenu: this.jobSubMenu,
            title: null,
          },
        },
      },
      {
        text: 'Project',
        route: '',
        disabled: false,
        type: 'Carousel',
        items: projectMenuItems,
        name: 'Project',
        subMenuItem: {},
      }];

    this.sideMenu = [
      {
        text: 'My Preferences',
        route: null,
        clickFn: 'openMyPreferences',
        isShow: true,
      },
      {
        text: 'Import Job',
        route: null,
        clickFn: 'openImportJob',
        isShow: false,
      },
      {
        text: 'Upload Proposal/Submittal',
        route: null,
        clickFn: 'openUploadDocumentPackages',
        isShow: true,
      },
      {
        text: 'logout',
        route: null,
        clickFn: 'logout',
        isShow: true,
      },
    ];
    // hide menu on exit from projects screens
    this.jobHeaderService.showProjectsNavigation.subscribe((showNav) => {
      this.showJobNavigation = showNav;
    });

    // To hide menu on exit from finance pages
    this.sharedJobHeaderService.showProjectsNavigation.subscribe((showNav) => {
      this.showJobNavigation = showNav;
    });

    this.messageCountService.isMessagePanelOpen$.subscribe((notificationStatus) => {
      this.showNotification = notificationStatus;
    });

    this.jobHeaderService.message.subscribe((message) => {
      this.message = message;
      // ensure a valid message exists before attempting to parse ID elements
      if (this.message !== '') {
        this.updateJobMenu(this.message);
      } else {
        // Since it was newly implemented moving job header service to shared-core-salesweb library.
        // Not consumed by all components at the moment only,Going farword removing the job header from salesweb.
        // That reason we have added duplicate code.
        this.sharedJobHeaderService.message.subscribe((res) => {
          this.message = res;
          if (this.message !== '') {
            this.updateJobMenu(this.message);
          } else {
            this.showJobNavigation = false;
          }
        });
      }
    });

    // Import Job menu show based on CTXDBSELECTOR AD group from office selector list
    // If user has CTXDBSELECTOR AD group we show import job otherwise hide the menu
    this.filterService.getOfficeSelectorList().subscribe((data) => {
      const filterDBSelector = data.filter((x) => x.groupName === 'CTXDBSELECTOR');
      this.isShowImportJob = filterDBSelector.length > 0;
      this.sideMenu.filter((menu) => menu.text === 'Import Job')[0].isShow = this.isShowImportJob;
    });
    this.jobHeaderService.isNotificationPanelOpen.subscribe((res) => {
      this.showNotification = res;
    });
    this.getNotificationCount();
    this.isHeaderLoaded.emit(true);

    this.commonService.carouselActiveSlideIndex.subscribe((activeIndex: number) => {
      const bidsWithIdNull = this.createProjectBidList.filter((bid) => {
        return !bid.creditJobNumber;
      });
      const activeBidIndex = activeIndex;
      this.disableSubMenu = !this.createProjectBidList[activeIndex]?.creditJobNumber;
      // Update activeIndex corresponding to projectBidList index
      if (this.isCreateProjectScreen && activeIndex >= bidsWithIdNull.length) {
        activeIndex -= bidsWithIdNull.length;
      }
      if (this.projectBidList.length > 0 && !(this.isCreateProjectScreen && activeBidIndex < bidsWithIdNull.length)) {
        this.activeProjectBidIndex = activeIndex;
        if (this.isProdOrStageEnvironment && this.projectBidList[activeIndex].isCopiedDownCreditJob &&
          this.projectBidList[activeIndex].hqtrCreditJobId) {
          this.projectCreditJobId = this.projectBidList[activeIndex].hqtrCreditJobId;
        } else {
          this.projectCreditJobId = this.projectBidList[activeIndex]?.creditJobId;
        }
        this.activeBidAlternateId = this.activeBidAlternateId ?
          this.activeBidAlternateId : this.projectBidList[activeIndex].bidAlternateId;
        if (this.projectBidList[activeIndex].isArchivedCreditJob) {
          this.projectCreditJobId = this.projectBidList[activeIndex].archivedCreditJobId;
        }

        if (this.projectBidList[activeIndex].isTransmitted) {
          this.isUntransmittedCreditProject = false;
          if (this.projectBidList[activeIndex].isCopiedDownCreditJob) {
            this.isCopiedDownCreditProject = true;
          }
        } else {
          this.isUntransmittedCreditProject = true;
        }

        if (this.projectBidList[activeIndex].isCopiedDownCreditJob && this.enableMirrorSalesOrder) {
          this.localCreditJobId = this.projectBidList[activeIndex].localCreditJobId;
          this.salesOrderType = DisplayModeEnum.Untransmitted;
        } else {
          this.salesOrderType = DisplayModeEnum.Transmitted;
        }

        this.enableDisableAON(activeIndex);
        this.fetchBasicInfoDetails();
        this.creditProjectType();
        this.enableDisableSalesOrderDetailsSubmenu(this.projectBidList[activeIndex]);
        this.enableDisableChangeOrderSubmenu(this.projectBidList[activeIndex]);
        // triggers the prevalidation for the current bid
        this.triggerPreValidation();
        // fetches the validation message count for the current bid
        this.fetchValidationMessagesCount();
        this.previousCreditJobId = this.previousCreditJobId ? this.previousCreditJobId : this.projectCreditJobId;
        if (this.router.url && this.router.url.split('/').length > 2
          && this.projectCreditJobId !== null && !this.router.url.includes('exit')) {
          this.updateJobMenu(this.jobId + '/' + this.drAddressId);
        }
      }
    });

    // hide menu for work package screen
    this.jobHeaderService.showWorkPackageNavigation.subscribe((res: boolean) => {
      this.showJobNavigation = res;
    });

    this.jobHeaderService.showPreValidation.subscribe((res: boolean) => {
      this.isShowPreValidation = res;
    });

    this.route.queryParams.subscribe((res) => {
      if (res['projectType']) {
        this.projectType = res['projectType'];
      }
    });

    // To trigger the prevlaidation
    this.commonService.startPreValidation.subscribe((startValidation) => {
      this.startValidation = startValidation;
    });

    // Call trigger prevalidation method
    this.commonService.callValidation.subscribe((triggerValidation) => {
      if (triggerValidation) {
        this.triggerPreValidation();
      }
    });

    // Call fetch validation count method to update the message count after successful deletion
    this.commonService.isValidationMesssageDeletionCompleted.subscribe(() => {
      this.fetchValidationMessagesCount();
    });
  }

  /**
   * To set isEditable to boolean
   * @param {activeIndex} number: receives current selected index from carousel
   */
  enableDisableAON(activeIndex: number): void {
    if (this.isUntransmittedCreditProject || this.isCopiedDownCreditProject) {
      // fetch basicInfo and set to localvariable
      const displayMode = this.isUntransmittedCreditProject ?
        DisplayModeEnum.Untransmitted : this.appConstants.TransmittedCopiedDownDisplayMode;
      this.creditProjectService.apiBaseUrl = this.commonService.getBaseUrl(displayMode, this.drAddressId);
      const creditService = this.creditProjectService.getBasicInfoDetails(this.projectCreditJobId);

      const camInputRequest = {
        context: this.isUntransmittedCreditProject ?
          CamContext.EditUntransmittedContext : CamContext.EditCopiedDownContext,
        drAddressId: +this.drAddressId,
        userId: this.jobHeaderService.getUserId(),
        localData: {
          creditJobId: this.isUntransmittedCreditProject ? this.projectCreditJobId : this.projectBidList[activeIndex].localCreditJobId,
          jobId: +this.jobId
        }
      } as ICamInput;

      const camCheckService = this.camGatewayService.checkCamGatewayStatus(camInputRequest);
      this.creditProjectService.islockUserId.subscribe(isAllowed => {
        this.isUserIdLocked = isAllowed !== null;
        this.orderServiceMenuItems.filter(menuItem => menuItem.text === this.assignSalesOrders)[0].disabled = !this.isUserIdLocked;
      });
      forkJoin([creditService, camCheckService]).subscribe(results => {
        this.basicInfo = results[0];
        this.isEditable = this.basicInfo.isOracleProjectIndicator && (results[1].status === CamStatus.Allow);
        this.isUserIdLocked = JSON.parse(localStorage.getItem('okta-token-storage')).idToken.claims.samAccountName.toLowerCase()
          === this.basicInfo.lockUserId;
        if (!this.isProdOrStageEnvironment
          && this.doesUserHaveEditAccess && this.isEditable && (this.isUntransmittedCreditProject || this.isCopiedDownCreditProject)) {
          this.orderServiceMenuItems.filter(menuItem => menuItem.text === this.assignSalesOrders)[0].disabled = false;
        }
        this.orderServiceMenuItems.filter(menuItem => menuItem.text === this.assignSalesOrders)[0].disabled = !this.isUserIdLocked;
      });
    }
  }

  setSubMenuPosition(): void {
    const docWidth = document.documentElement.clientWidth;
    const selectedContainerWidth = this.menuContainer.nativeElement
      .querySelector(this.subMenuClassPrefix + this.selectedIndex)?.offsetWidth;
    const centPos = Math.floor((docWidth / 2) - selectedContainerWidth / 2 - 10);
    if (this.subMenuContainer) {
      this.subMenuContainer.nativeElement.style.left = centPos + 'px';
    }
  }

  /**
   * To show/hide the remaining project menu items
   * @param {Event} event: triggered on click event
   */
  toggleRemainingMenu(event: Event): void {
    event.stopPropagation();
    this.hideExtraMenuItems = !this.hideExtraMenuItems;
    const action = this.hideExtraMenuItems ? 'addClass' : 'removeClass';
    const selectedSubMenu = this.subMenuClassPrefix + this.selectedIndex;
    const verticalMenu = this.menuContainer.nativeElement.querySelector(selectedSubMenu + ' .stack-container');
    if (verticalMenu) {
      this.renderer[action](this.menuContainer.nativeElement.querySelector(selectedSubMenu + ' .stack-container'), 'd-none');
    }
    // Toggles the errors and warnings panel
    this.toggleErrorsPanel(event);
  }

  @HostListener('window: resize')
  setSubMenuWidth(): void {
    let vMenuContainer: HTMLElement; // vertical menu items container
    this.showRemaining = false;
    const vMenuContainerClass = 'stack-container';
    const selectedSubMenu = this.subMenuClassPrefix + this.selectedIndex;
    if (!document.querySelector(selectedSubMenu)?.querySelector('.' + vMenuContainerClass)) {
      vMenuContainer = this.renderer.createElement('div');
      vMenuContainer.classList.add('d-none', vMenuContainerClass);
      const submenuItems = this.menuContainer.nativeElement.querySelectorAll(selectedSubMenu + ' .sub-menu-list');
      let subMenuItemWidth = 0;
      submenuItems?.forEach((submenuItem) => {
        subMenuItemWidth += submenuItem.offsetWidth;
        // add the menu items exceeding (document.documentElement.clientWidth / 2) to the stack-container
        // additional 40 is for the triangular edges
        if (subMenuItemWidth > (document.documentElement.clientWidth / 2) - 40) {
          this.renderer.appendChild(vMenuContainer, submenuItem);
          this.showRemaining = true;
        }
      });
      if (this.showRemaining) {
        this.renderer.appendChild(this.menuContainer.nativeElement.querySelector(selectedSubMenu), vMenuContainer);
      }
    } else {
      vMenuContainer = document.querySelector(selectedSubMenu).querySelector('.' + vMenuContainerClass);
      this.showRemaining = true;
    }
    setTimeout(() => {
      this.setSubMenuPosition();
    });
  }

  onMainMenuSelect(item: HTMLElement, index: number): void {
    if (!item.classList.contains('k-state-disabled')) {
      document.querySelectorAll('.stack-container')?.forEach((vmenu) => {
        vmenu.classList.add('d-none');
      });
      this.selectedIndex = index;
      this.setSubMenuWidth();
    }
  }

  /**
   * set intialSlide to carousel
   * @param {number} intialSlide: get active slide index from carousel
   */

  slideConfiguration(intialSlide: number): void {
    if (this.creditJobId === null && !this.isCreateProjectScreen) {
      intialSlide = 0;
    }
    const carouselConfig = JSON.parse(JSON.stringify(this.projectMenuCarouselConfig));
    carouselConfig['initialSlide'] = intialSlide;
    this.projectMenuCarouselConfig = carouselConfig;
  }

  /**
   * set values for orderServiceMenuItems
   * @param {string} submenu: Gets the submenu name of projects menu
   * @returns void.
   */
  setOrderServicesSubMenu(submenu: string): void {
    this.orderServiceMenuItems.push({
      text: submenu,
      route: submenu,
      cssClass: '',
    });
  }

  /**
   * Fetches the coordinate error count value
   * @param {boolean} isCoordinatePage: Sets whether the current loaded page is coordiante or not
   * @returns void
   */
  subscribeForCoordinateLinkValidation(isCoordinatePage: boolean): void {
    this.subMenuValues = this.menuItems[0].subMenuItem[0].subMenu;
    this.jobCoordinationValidationService.getJobDetailsValidationSummary().subscribe((validationSummary) => {
      if (validationSummary.errorCount > 0 && isCoordinatePage) {
        const [detailsMenuItem] = this.jobSubMenu.filter((menuItem) => menuItem.text === 'Details');
        this.router.navigate([detailsMenuItem.path], { relativeTo: this.route });
      }
      const coordinateMenuItem = this.subMenuValues.filter((menuItem) => menuItem.text === 'Coordinate')[0];
      coordinateMenuItem.validations = validationSummary;
      coordinateMenuItem.disabled = validationSummary.errorCount !== 0;
      this.coordinateLinkValidations.validEarthwise = coordinateMenuItem.validations.validEarthwise;
      this.coordinateLinkValidations.validClassifications = coordinateMenuItem.validations.validClassifications;
      this.coordinateLinkValidations.validBid = coordinateMenuItem.validations.validBid;
      this.coordinateErrorCount = validationSummary.errorCount;
      if (!validationSummary.errorCount) {
        this.coordinatePopupShow = false;
      }
    });
  }

  /**
   * gets the error count
   * returns number
   */
  getErrorCount(): number {
    return this.validationErrorCount + this.coordinateErrorCount;
  }

  toggle() {
    this.show = !this.show;
  }

  setClickInCoordinatePopup(): void {
    this.isClickInCoordinatePopup = true;
  }

  /**
   * Toggles the coordinate popup
   * @param {MouseEvent} event - Gets the event when clicking on the document
   * @returns void
   */
  toggleCoordinatePopup(event: MouseEvent): void {
    // For toggling the popup while clicking on the badge
    if (this.isEventTargetContainsErrorBadge(event.target)) {
      this.coordinatePopupShow = !this.coordinatePopupShow;
    } else {
      // For not showing the popup while clicking outside in the page
      if (!this.isClickInCoordinatePopup) {
        this.coordinatePopupShow = false;
      }
    }
    this.isClickInCoordinatePopup = false;
  }

  logout() {
    this.oktaAuth.logout('/');
    localStorage.clear();
  }

  // display/refresh job menu with correct URIs and highlighting current item
  updateJobMenu(message: string) {
    this.enableDisableSubMenus();
    // determine current location from URI
    this.currentUri = window.location.toString();
    const currentView = this.currentUri.substring(this.currentUri.lastIndexOf('/') + 1);
    const urlSplit = currentView.split('?');
    this.currentState = urlSplit[0];
    // job identifiers were passed as single string,
    // split into segments and store into local variables
    const idElements = message.split('/');
    const jobId = +idElements[0];
    const drAddressId = +idElements[1];
    const idElementsVal = this.currentUri.split('/');
    let originatingDrAddress;
    let watcomJobId;
    let creditNumber;

    this.childRoute = this.getLastChildRoute(this.route.root);
    this.subMenuRoute = this.childRoute.snapshot.data['subMenuRoute'];
    // If its a job's sub menu page, set the credit number
    const currentJobMenuSelect = this.jobSubMenu.filter((x) => (x.route === (this.currentUri.split('/').pop())) ||
      this.currentUri.indexOf('work-packages') !== -1 || x.route === this.subMenuRoute);
    if (currentJobMenuSelect.length > 0) {
      creditNumber = this.projectCreditJobId;
      originatingDrAddress = drAddressId;
      watcomJobId = jobId;
      this.isJobSubMenuItem = true;
    } else if (this.isRebalancingScreen) {
      watcomJobId = +idElementsVal[4];
      originatingDrAddress = +idElementsVal[5];
      this.projectCreditJobId !== creditNumber ? creditNumber = this.projectCreditJobId : creditNumber = +idElementsVal[8];
      this.isJobSubMenuItem = false;
    } else {
      watcomJobId = +idElementsVal[5];
      originatingDrAddress = +idElementsVal[4];
      this.projectCreditJobId !== creditNumber ? creditNumber = this.projectCreditJobId : creditNumber = +idElementsVal[8];
      this.isJobSubMenuItem = false;
    }
    // update menu item URI with proper link
    // identify current item as active
    for (const menuItem of this.jobSubMenu) {
      menuItem.cssClass = '';
      if (menuItem.text === this.workPackageName) {
        menuItem.path = `${this.homePageList}/${drAddressId}/${jobId}/${menuItem.route}`;
        if (this.currentUri.indexOf('work-packages') !== -1) {
          menuItem.cssClass = 'active';
        }
      } else {
        menuItem.path = `${this.jobPageList}/${jobId}/${drAddressId}/${menuItem.route}`;
        menuItem.cssClass = (menuItem.route === currentView || menuItem.route === this.subMenuRoute) ? 'active' : '';
      }

    }

    this.updateFinancialMenuItems(currentView, watcomJobId, drAddressId, creditNumber);
    this.updateOrderServicesMenu(currentView, originatingDrAddress, creditNumber, watcomJobId);

    // enable menu to be displayed
    //  use timeout to create separate microcycle to avoid changes during the same process
    //  https://blog.angularindepth.com/everything-you-need-to-know-about-the-expressionchangedafterithasbeencheckederror-error-e3fd9ce7dbb4
    setTimeout(() => {
      this.hideAndShowJobAndProjectMenu();
    });
  }

  // function to hide the submenupanel
  hideSubMenu(menuItemText, index): boolean {
    return this.getCssClass(menuItemText) === 'hide-menu-item' || index !== this.selectedIndex;
  }

  hideAndShowJobAndProjectMenu(): void {
    if (this.workPackageUrl === this.appConstants.WORKPACKAGE_PAGE.configureContainer ||
      this.workPackageUrl === this.appConstants.WORKPACKAGE_PAGE.addContainer ||
      this.workPackageUrl === this.appConstants.WORKPACKAGE_PAGE.createCostContainer ||
      this.workPackageUrl === this.appConstants.WORKPACKAGE_PAGE.create ||
      this.workPackageUrl === this.appConstants.WORKPACKAGE_PAGE.placeholderToSiteInstall) {
      this.showJobNavigation = false;
    } else {
      this.showJobNavigation = true;
      if (this.selectedIndex === -1) {
        this.isJobSubMenuItem ? this.selectedIndex = 0 : this.selectedIndex = 1;
      }
      setTimeout(() => {
        this.setSubMenuWidth();
      });

    }

    // Hide the validations menu for all the work packages screen
    this.isShowPreValidation = !this.isWorkPackagePage;
  }

  /**
   * should update the financialMenuItems route, css values
   * @params {string} currentView - currrent view from the route
   * @params {number} jobId - jobId of the current job selected from project's table
   * @params {number} drAddressId - drAddressId of the current job selected from project's table
   * @params {number} creditJobNumber - creditJobNumber of the current job selected from project's table
   * @returns void.
   */
  updateFinancialMenuItems(currentView: string, jobId: number, drAddressId: number, creditJobNumber: number): void {
    let creditJobsBaseUrl: string;
    let url = '';
    const baseUrl = `${this.jobPageList}/${jobId}/${drAddressId}`;
    if (this.isCostForecastScreen && this.projectBidList && this.projectBidList.length) {
      // form the base url for the cost-forecast screens.
      let creditJobNbr: number;
      // Get the active bid from the list of bids.
      const projectBid = this.projectBidList[this.activeProjectBidIndex];
      if (this.isTransmitted && projectBid && !projectBid.isCopiedDownCreditJob) {
        // If the credit job is transmitted but not copydown, then take the creditJobId from current bid
        creditJobNbr = projectBid.creditJobId;
      } else if (projectBid && this.isTransmitted && projectBid.isCopiedDownCreditJob) {
        // If the credit job is transmitted and copydown, then take the hqtrCreditJobId from current bid
        creditJobNbr = projectBid.hqtrCreditJobId;
      } else {
        creditJobNbr = creditJobNumber;
      }
      creditJobsBaseUrl = `${this.jobPageList}/${drAddressId}/${jobId}/projects/CreditJobs/${creditJobNbr}`;
    } else {
      // The base url for FinancialMenuItems other than cost-forecast screens.
      creditJobsBaseUrl = `${this.jobPageList}/${drAddressId}/${jobId}/projects/CreditJobs/${creditJobNumber}`;
    }
    for (const financialMenuItems of this.financialMenuItems) {
      if (this.isProdOrStageEnvironment) {
        financialMenuItems.disabled = true;
        financialMenuItems.path = '';
      } else {
        if (financialMenuItems.modulePath === this.rebalancingModulePath) {
          url = baseUrl;
        } else {
          url = creditJobsBaseUrl;
        }
        financialMenuItems.path = `${url}/${financialMenuItems.modulePath}/${financialMenuItems.route}`;
        const currentRoutePath = currentView.split('?')[0];
        financialMenuItems.cssClass = (financialMenuItems.route === currentRoutePath) ||
          (financialMenuItems.modulePath === currentRoutePath)
          ? 'active' : '';
      }

    }
  }

  /**
   * enable/disable sub menu based on the projectCreditJobId value and project type
   * @returns void.
   */
  enableDisableSubMenus(): void {
    if ((!this.fromHistory
      && this.projectCreditJobId !== null
      && (this.isUntransmittedCreditProject && !this.isCopiedDownCreditProject)
      && !this.isArchivedCreditJobPresent)
      || this.projectCreditJobId === null || this.isUserHasOnlyCommissionSplitAccess) {
      for (const financialMenuItems of this.financialMenuItems) {
        financialMenuItems.disabled = true;
        financialMenuItems.path = '';
      }
      for (const menuItem of this.orderServiceMenuItems) {
        menuItem.disabled = true;
        if ((menuItem.text === this.creditProjectName) && !this.isProdOrStageEnvironment) {
          menuItem.disabled = false;
        }
        menuItem.path = '';
      }
      this.isdisabled = true;
    } else {
      for (const financialMenuItems of this.financialMenuItems) {
        financialMenuItems.disabled = false;
        financialMenuItems.path = '';
      }
      for (const menuItem of this.orderServiceMenuItems) {
        if (menuItem.text === this.ChangeOrdersName) {
          menuItem.disabled = this.isChangeOrderDetailsDisabled;
        } else {
          menuItem.disabled = false;
          if (menuItem.text === this.salesOrderDetailsName) {
            menuItem.disabled = this.isSalesOrderDetailsDisable;
          }
          if (menuItem.text === this.assignSalesOrders && !this.isProdOrStageEnvironment) {
            menuItem.disabled = true;
          }
        }
        menuItem.path = '';
      }
    }
  }

  /**
   * display/refresh OrderServicesMenu with correct URIs and highlighting current item
   * @params {string} currentView - currrent view from the route
   * @params {number} watcomJobId - jobId of the current job selected from job's table
   * @params {number} originatingDrAddress - drAddressId of the current job selected from job's table
   * @params {number} creditNumber - credit number of the current project selected
   * @returns void.
   */
  updateOrderServicesMenu(currentView: string, originatingDrAddress: number, creditNumber: number, watcomJobId: number): void {
    this.defaultToggleState();
    const creditProjectRoute = this.creditProjectDetailsName;
    if (originatingDrAddress && creditNumber !== undefined && watcomJobId) {
      for (const menuItem of this.orderServiceMenuItems) {
        if (menuItem.route === 'History') {
          this.updateHistoryRoutes(currentView);
        } else if (menuItem.route === this.ChangeOrdersName) {
          const route: string = menuItem.route;
          menuItem.route = route.toString().toLowerCase().replace(' ', '-');
        } else if (menuItem.route === this.creditProjectName || menuItem.route === creditProjectRoute || menuItem.route === 'Edit') {
          this.updateCreditProjectRoutes(menuItem, originatingDrAddress, watcomJobId, creditNumber);
          // Navigation to Sales Order Screen from menu items
        } else if (menuItem.route === this.salesOrderDetailsName) {
          menuItem.route = 'SalesOrders';
        } else if (menuItem.route === this.assignSalesOrders || menuItem.route === this.assignSalesOrdersRoute) {
          menuItem.route = this.assignSalesOrdersRoute;
        }
        this.updateRoutesForNonEdit(menuItem, originatingDrAddress, watcomJobId, creditNumber);
      }
    }
  }

  updateRoutesForNonEdit(menuItem: { route, path }, originatingDrAddress: number, watcomJobId: number, creditNumber: number): void {
    if (menuItem.route !== 'Edit') {
      if (menuItem.route !== this.creditProjectName && (menuItem.route !== 'SalesOrders')
        && menuItem.route !== this.assignSalesOrdersRoute) {
        menuItem.path = `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditJobs/${creditNumber}/${menuItem.route}`;
      } else if (menuItem.route === 'SalesOrders') {
        this.updateSalesOrderRoutes(menuItem, originatingDrAddress, watcomJobId, creditNumber);
      } else if (menuItem.route === this.assignSalesOrders || menuItem.route === this.assignSalesOrdersRoute) {
        menuItem.route = this.assignSalesOrdersRoute;
        this.updateAssignSalesOrderRoutes(menuItem, originatingDrAddress, watcomJobId, creditNumber);
      } else {
        menuItem.path = `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditJobs/${creditNumber}/${this.creditProjectDetailsName}`;
        menuItem.route = this.creditProjectDetailsName;
      }
    }
  }

  updateCreditProjectRoutes(menuItem: { route, path }, originatingDrAddress: number, watcomJobId: number, creditNumber: number): void {
    const localCreditJobId = this.projectBidList[this.activeProjectBidIndex]?.localCreditJobId;
    if (this.isTransmitted && this.projectBidList[this.activeProjectBidIndex]?.isCopiedDownCreditJob
      && localCreditJobId > 0 && !this.isProdOrStageEnvironment) {
      menuItem.route = 'Edit';
      menuItem.path = `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditProject/${localCreditJobId}/${menuItem.route}`;
    } else if (this.projectCreditJobId && !this.isTransmitted && !this.isArchivedCreditJobPresent && !this.isProdOrStageEnvironment) {
      menuItem.route = 'Edit';
      menuItem.path = `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditProject/${creditNumber}/${menuItem.route}`;
    } else if (this.projectCreditJobId && this.isTransmitted) {
      menuItem.route = this.creditProjectDetailsName;
    }
  }

  checkUrlFragmentChange(url: string): void {
    const index = url.lastIndexOf('/') + 1;
    const currentView = url.substring(index).split('?')[0];
    const currentUrlFragment = currentView.substr(currentView.indexOf('#') + 1);
    if (this.prevUrlFragment !== currentUrlFragment && this.jobId && this.drAddressId) {
      this.prevUrlFragment = currentUrlFragment;
      this.updateJobMenu(this.jobId + '/' + this.drAddressId);
    }
  }

  updateSalesOrderRoutes(menuItem: { route, path }, originatingDrAddress: number, watcomJobId: number, creditNumber: number): void {
    const localCreditJobId = this.projectBidList[this.activeProjectBidIndex]?.localCreditJobId;
    if (this.isTransmitted && this.projectBidList[this.activeProjectBidIndex]?.isCopiedDownCreditJob
      && localCreditJobId > 0 && !this.isProdOrStageEnvironment) {
      menuItem.route = 'SalesOrders';
      this.commonService.isCopiedDown = true;
      menuItem.path =
        `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditJobs/${localCreditJobId}/${menuItem.route}`;
    } else {
      this.commonService.isCopiedDown = false;
      menuItem.route = 'SalesOrders';
      menuItem.path = `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditJobs/${creditNumber}/${menuItem.route}`;
    }
  }

  updateAssignSalesOrderRoutes(menuItem: { route, path }, originatingDrAddress: number, watcomJobId: number, creditNumber: number): void {
    const localCreditJobId = this.projectBidList[this.activeProjectBidIndex]?.localCreditJobId;
    menuItem.route = this.assignSalesOrdersRoute;
    if (this.isTransmitted && this.projectBidList[this.activeProjectBidIndex]?.isCopiedDownCreditJob
      && localCreditJobId > 0 && !this.isProdOrStageEnvironment) {
      this.assignSalesOrderType = DisplayModeEnum.Untransmitted;
      menuItem.path =
        `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditJobs/${localCreditJobId}/${menuItem.route}`;
    } else {
      this.assignSalesOrderType = DisplayModeEnum.Transmitted;
      menuItem.path = `${this.jobPageList}/${originatingDrAddress}/${watcomJobId}/projects/CreditJobs/${creditNumber}/${menuItem.route}`;
    }
  }

  // Defaults the toggle state
  defaultToggleState(): void {
    if (this.projectType === 'History') {
      this.commonService.setSelectedToggle('History');
    } else if (!this.commonService.currentToggle) {
      if (this.projectType !== null) {
        this.commonService.setSelectedToggle(this.projectType);
      } else {
        this.commonService.setSelectedToggle(DisplayModeEnum.Transmitted);
      }
    }
  }

  /**
   * update history routes
   * @params {string} currentView - currrent view from the route
   * @returns void.
   */
  updateHistoryRoutes(currentView): void {
    let previousUrl;
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        previousUrl = currentView;
        currentView = event.url;
        this.jobHeaderService.setNavigateFromUrl(previousUrl);
        this.sharedJobHeaderService.setNavigateFromUrl(previousUrl);
      }
    });
  }

  /**
   * Check if at least 1 jobs sub menu in route, if present returns true else false
   * @param  {IHeaderItemModel} item - submenu data.
   * @returns boolean.
   */
  checkJobSubMenuItems(item: IHeaderItemModel): boolean {
    return this.jobSubMenu.some((menu) => {
      return menu.route === item.route;
    });
  }

  /**
   * Handle the click event of sub menu
   * @param menuInfo - sub menu info
   * @returns void
   */
  onSubMenuSelection(menuInfo: IHeaderItemModel, event: Event): void {
    this.startAssignSalesOrderValidation = false;
    const index = this.jobSubMenu.findIndex((item) => item.text === menuInfo.text);
    if (this.commonService.isFormModified || this.nonTraneService.isNonTraneFormUpdated) {
      this.subMenuInfo = menuInfo;
      event.stopPropagation();
      if (!(this.isCreateProjectScreen && this.disableSubMenu && index === -1)) {
        this.shouldShowFormModifiedDialog = true;
      }
    } else {
      this.updateProjectType(menuInfo);
      this.onMenuSelect(menuInfo);
    }
  }

  /**
   * Navigates to the bids page
   */
  navigateToBidsPage(): void {
    this.router.navigate(['/jobs-list/' + this.jobId + '/' + this.drAddressId + '/bids']);
  }

  /**
   * Handles the form modified dialog actions
   * @param enableNavigation - Boolean value for enable navigation
   * @returns void
   */
  handleFormModifiedDialogAction(enableNavigation: boolean, event?: Event): void {
    if (enableNavigation) {
      if (this.isExitJobClick) {
        if (this.currentState === 'assign-sales-orders') {
          // handles exit and releases lock
          this.releaseLockAndExit();
        } else {
          this.sharedJobHeaderService.exitJob.next(true);
          this.isExitJobClick = false;
        }
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      this.onMenuSelect(this.subMenuInfo);
      // Deletes the validation messages for the bid
      if (this.drAddressId && this.jobId && this.activeBidAlternateId) {
        this.validationErrorService.deleteValidationMessage(this.drAddressId,
          this.jobId.toString(), this.activeBidAlternateId).subscribe(() => {
            // Set to update the message count after successfull deletion
            this.commonService.isValidationMesssageDeletionCompleted.next(true);
          });
      }
      this.commonService.isFormModified = false;
    }
    this.shouldShowFormModifiedDialog = false;
  }

  /**
   * handles click of exit on assign sales order page
   * @returns void.
   */
  onAssignSalesOrderExit(): void {
    if (this.router.url.includes(`navFrom=${this.navigatedFrom}`)) {
      // attempt to close the tab when its navigating from project landing page
      window.close();
      // hide menu on exit
      this.jobHeaderService.showProjectsNavigation.next(false);
      // route to exit page in case window close doesnt work
      // https://stackoverflow.com/questions/14373625/close-current-tab
      const exitUrl = `jobs-list/${this.drAddressId}/projects/assign-sales-orders`;
      this.router.navigateByUrl(exitUrl, { state: { exitFrom: 'assign-sales-orders' } });
    } else {
      this.shouldShowFormModifiedDialog = false;
      this.navigateToBidsPage();
    }
  }

  /**
   * Release lock through CAM gateway and exit credit project
   * @param creditJobId
   */
  releaseLockAndExit(): void {
    if (this.basicInfo.isOracleProjectIndicator) {
      const camInputRequest = {
        context: CamContext.ExitProjectContext,
        drAddressId: +this.drAddressId,
        userId: this.jobHeaderService.getUserId(),
        localData: {
          creditJobId: this.isUntransmittedCreditProject ? this.projectCreditJobId : this.localCreditJobId,
          jobId: +this.jobId
        }
      } as ICamInput;
      this.camGatewayService.checkAndApplyLock(camInputRequest).subscribe((executionResult) => {
        if (executionResult.status === CamStatus.Allow) {
          this.onAssignSalesOrderExit();
        }
      });
    }
  }

  /**
   * handle click event on submenu
   * @param  {IHeaderItemModel} item - submenu data.
   * @returns void.
   */
  // tslint:disable-next-line:cognitive-complexity
  onMenuSelect(item: IHeaderItemModel): void {
    const navigationFrom = this.router.url.includes(`navFrom=${this.navigatedFrom}`) ? this.navigatedFrom : 'Jobs';
    this.coordinatePopupShow = false;
    // check required field validation from job details page when click on menu select
    const detailsPageStatusIndicatesNoValidationErrors = (this.jobHeaderService.getDetailsPageValidationStatus() === undefined ||
      this.jobHeaderService.getDetailsPageValidationStatus().indexOf(false) === -1);
    if (!item.disabled) {
      if (!item.items) {
        if (detailsPageStatusIndicatesNoValidationErrors) {
          if (document.querySelector('.sub-menu-container .active')) {
            this.renderer.removeClass(document.querySelector('.sub-menu-container .active'), 'active');
          }
          item.cssClass = item.cssClass.concat(' active');
        }
        if (item.path.indexOf(item.route) === -1) {
          this.router.navigate([item.path], { relativeTo: this.route });
        } else {
          if (detailsPageStatusIndicatesNoValidationErrors) {
            if (!item.disabled) {
              if (this.projectCreditJobId && this.previousCreditJobId
                && (this.previousCreditJobId !== this.projectCreditJobId) && !this.isJobSubMenuItem) {
                this.router.routeReuseStrategy.shouldReuseRoute = () => false;
              }
              if (item.path.includes('Edit')) {
                this.router.navigate([item.path], {
                  queryParams: { navFrom: navigationFrom, projectType: 'Untransmitted' }, relativeTo: this.route,
                });
              } else if (item.path.includes(this.creditProjectDetailsName)) {
                if (this.projectType === DisplayModeEnum.Untransmitted) {
                  item.path = item.path.replace('CreditJobs', 'CreditProject').replace('credit-project-details', 'Edit');
                }
                const navigationType = this.projectType !== undefined ? this.projectType : DisplayModeEnum.Transmitted;
                this.router.navigate([item.path], {
                  queryParams: { navFrom: navigationFrom, projectType: navigationType }, relativeTo: this.route,
                });
              } else if (item.path.includes(this.billingModulePath)) {
                const billingSummaryRouteUrl = this.setPathForFinancialSubMenuItem(item, this.billingModulePath);
                this.router.navigate([billingSummaryRouteUrl], {
                  queryParams: { navFrom: navigationFrom, projectNumber: this.creditProjectNumber }, relativeTo: this.route,
                });
              } else if (item.path.includes(this.costForecastModulePath)) {
                const navigationType = this.projectType !== undefined ? this.projectType : DisplayModeEnum.Transmitted;
                const costForecastRouteUrl = this.setPathForFinancialSubMenuItem(item, this.costForecastModulePath);
                this.router.navigate([costForecastRouteUrl], {
                  queryParams: { navFrom: navigationFrom, projectType: navigationType },
                  relativeTo: this.route,
                });
              } else if (item.path.includes('SalesOrders') && !item.path.includes('AssignSalesOrders')) {
                const navigationType = this.projectType !== undefined ? this.projectType : this.salesOrderType;
                this.router.navigate([item.path], {
                  queryParams: { navFrom: navigationFrom, projectType: navigationType }, relativeTo: this.route,
                });
              } else if (item.path.includes('assign-sales-orders')) {
                this.updateProjectType(item);
                const navigationType = this.projectType !== undefined ? this.projectType : this.assignSalesOrderType;
                this.router.navigate([item.path], {
                  queryParams: { navFrom: navigationFrom, projectType: navigationType }, relativeTo: this.route,
                });
              } else if (this.checkJobSubMenuItems(item)) {
                this.router.navigate([item.path], { relativeTo: this.route });
              } else {
                if (this.projectType === undefined) {
                  this.updateProjectType(item);
                }
                this.router.navigate([item.path], {
                  queryParams: { navFrom: navigationFrom, projectType: this.projectType }, relativeTo: this.route
                });
              }
            }
          } else {
            const formArray = this.jobHeaderService.getDetailsPageValidationStatus();
            // when navigate one page to another page, we check file selected or dropped in document section in job details page
            // file is not selected then we show required field validation toaster message
            if (formArray[this.documentsForm]) {
              this.toasterService.setToaster('error', this.appConstants.JOB_DETAILS_VALIDATION_ERROR_MESSAGE);
              // file is selected then we show confirmation popup dialog message
            } else {
              this.navigationPath = item.path;
              this.documentsWarning = true;
            }
          }
        }
        this.previousCreditJobId = this.projectCreditJobId;
      } else {
        if (detailsPageStatusIndicatesNoValidationErrors) {
          this.router.navigate([item.path], { relativeTo: this.route });
        } else {
          this.toasterService.setToaster('error', this.appConstants.JOB_DETAILS_VALIDATION_ERROR_MESSAGE);
        }
      }
      this.pinUnpinErrorsAndWarningPanel();
    }
  }

  /**
   * set path for financial sub menu screens
   * @param item - {IHeaderItemModel} - accepts as input
   * @returns - {string} - sub menu item route url
   */
  setPathForFinancialSubMenuItem(item: IHeaderItemModel, modulePath: string): string {
    let creditJobNbr: number;
    let subMenuItemUrl: string;
    const [baseUrl, ...rest] = item.path.split(modulePath);
    const subMenuItemName = rest.join(modulePath);
    const itemElements = [baseUrl, subMenuItemName];
    const localCreditJobIdInndex = this.projectBidList.findIndex((obj) => obj.localCreditJobId === this.creditJobId);
    const hqtrCreditJobIdIndex = this.projectBidList.findIndex((obj) => obj.creditJobId === this.creditJobId);
    if (localCreditJobIdInndex !== -1) {
      creditJobNbr = this.projectBidList[localCreditJobIdInndex]?.hqtrCreditJobId;
    } else {
      creditJobNbr = this.projectBidList[hqtrCreditJobIdIndex]?.creditJobId;
    }
    const creditJobsBaseUrl = `${this.jobPageList}/${this.drAddressId}/${this.jobId}/projects/CreditJobs/${creditJobNbr}`;
    itemElements.forEach((itemElement, index) => {
      if (index > 0) {
        subMenuItemUrl = creditJobsBaseUrl + '/' + modulePath + itemElements[index];
      }
    });

    return subMenuItemUrl;
  }

  /**
   * Update project type based on bid details
   * @param {any} item - selected menu item
   */
  updateProjectType(item: IHeaderItemModel): void {
    const itemElements = item.path.split('/');
    itemElements.forEach((itemElement, index) => {
      if (itemElement === 'CreditJobs' || itemElement === 'CreditProject') {
        this.creditJobId = +itemElements[index + 1];
      }
    });

    this.projectBidList.forEach((bid) => {
      if (this.creditJobId === bid.creditJobId || this.creditJobId === bid.archivedCreditJobId
        || this.creditJobId === bid.localCreditJobId) {
        // Set project type as Transmitted for isTransmitted true and enableCopyDown feature flag false
        // Even if isCopiedDownCreditJob is true
        if (bid.isTransmitted && (!bid.isCopiedDownCreditJob || !this.enableCopyDown)) {
          this.projectType = DisplayModeEnum.Transmitted;
        } else if (bid.isArchivedCreditJob) {
          this.projectType = DisplayModeEnum.History;
        } else {
          this.projectType = DisplayModeEnum.Untransmitted;
        }
      }
    });
  }

  toggleMenu(id) {
    const menuItem = document.querySelector('#' + id);
    if (menuItem) {
      const cssList = document.querySelector('#' + id).classList;
      if (cssList.contains('collapse')) {
        document.querySelector('#' + id).classList.remove('collapse');
      } else {
        document.querySelector('#' + id).classList.add('collapse');
      }
    }
  }
  // if user select yes in documents confirmation popup message we redirect other page
  // if user select no in documents confirmation popup message we close popup dialog message
  closeDocumentsDialog(status) {
    if (status === 'yes') {
      this.router.navigate([this.navigationPath], { relativeTo: this.route });
    }
    this.documentsWarning = false;
  }

  /**
   * Checks if the target element contains error badge
   * @param {any} target - Gets the target element on clicking on the document
   * @returns boolean - Returns true or false based on the target value
   */
  isEventTargetContainsErrorBadge(target: any): boolean {
    if (this.coordinateErrorBadge && this.coordinateErrorBadge.nativeElement) {
      return this.coordinateErrorBadge.nativeElement.contains(target) ||
        (target.firstElementChild === this.coordinateErrorBadge.nativeElement) ||
        (this.mobileCoordinateErrorBadge.nativeElement.contains(target)) ||
        (target.firstElementChild === this.mobileCoordinateErrorBadge.nativeElement);
    }
  }

  // open import job page when clicking on Import Job menu
  openImportJob() {
    window.open('/jobs-list/' + this.drAddressId + '/importjob');
  }

  // open upload document packages page when clicking on Upload Proposal/Submittal menu
  openUploadDocumentPackages() {
    window.open('/jobs-list/' + this.drAddressId + '/uploaddocumentpackages');
  }

  openMyPreferences() {
    window.open('/my-preferences');
  }
  // close import job dialog when click close button (status parameter will use in next story)
  closeImportJobDialog(status) {
    this.importJobWarning = false;
  }

  toggleNotification(event: Event): void {
    event.stopPropagation();
    this.showNotification = !this.showNotification;
    this.messageCountService.isMessagePanelOpen$.next(this.showNotification);
    this.toggleErrorsPanel(event);
  }

  getNotificationCount() {
    this.messageCountService.currentMessageCount$.subscribe((count) => {
      this.notificationCount = count ? count : 0;
      this.disableNotificationIcon = (this.notificationCount <= 0);
    });
  }
  // Call Event Emitter WorkflowPopup service
  showWorkflowPopup() {
    this.jobHeaderService.isWorkflowPanelOpen.next(true);
    this.workflowPopupService.workflowPopupClickEventHandler();
  }

  /**
   * Checks whether the credit project is transmitted
   */
  creditProjectType(): void {
    if (this.projectBidList && this.projectCreditJobId) {
      this.projectBidList.forEach((bid) => {
        if ((bid.creditJobId === this.projectCreditJobId) && (bid.hqtrCreditJobId !== null || (bid.hqtrCreditJobId === null &&
          bid.foe2CreatedOrdersInd === 'N') || bid.hqtrBidAlternateId !== null)) {
          this.isTransmitted = true;
        } else {
          if ((bid.creditJobId === this.projectCreditJobId) && bid.foe2CreatedOrdersInd === 'Y') {
            this.isTransmitted = false;
          }
        }
        this.enableDisableSubMenus();
      });
    }
  }

  /**
   * enable sales order details menu if credit project is untransmitted and having sales order details
   * disable sales order details menu if credit project is untransmitted and not sales order details
   */
  enableDisableSalesOrderDetailsSubmenu(projectBidList: BidsListModel): void {
    let creditJobId = 0;
    if (projectBidList) {
      if (!projectBidList.isCopiedDownCreditJob) {
        this.salesOrderType = projectBidList.isTransmitted ? 'Transmitted' : 'Untransmitted';
        creditJobId = projectBidList.creditJobId;
      }
    } else {
      this.salesOrderType = (this.projectType !== undefined
        && this.projectType !== DisplayModeEnum.History) ? this.projectType : 'history';
      creditJobId = this.creditJobId;
    }
    this.salesOrderService.apiBaseUrl = this.commonService.getBaseUrl(this.salesOrderType, this.drAddressId);
    if (creditJobId > 0) {
      this.salesOrderService.drAddressId = this.drAddressId;
      // checking if sales order id is available for particular credit job id
      this.salesOrderService.getSalesOrders(creditJobId, this.skip, this.take, this.salesOrderType)
        .subscribe((response: ISalesOrderModel) => {
          if (response) {
            this.handleSubmenu(this.salesOrderDetailsName, true);
            this.isSalesOrderDetailsDisable = false;
          } else {
            // checks with initial creditJobId to enable or disable 'Sales Order Details' menu
            // when we are in page other than credit job creditjobIds will be undefined, so in this case creditJobId match not required
            if (this.creditJobIds[0] === undefined || this.creditJobIds[0] === creditJobId) {
              this.handleSubmenu(this.salesOrderDetailsName, false);
              this.isSalesOrderDetailsDisable = true;
            }
          }
        });
    }
  }

  /**
   * Enable/disable change order sub menu
   * @param projectBidList project bid list
   */
  enableDisableChangeOrderSubmenu(projectBidList: BidsListModel): void {
    const source = projectBidList ? SourceType.Order : SourceType.OrderHistory;
    const creditJobId = projectBidList ? projectBidList.creditJobId : this.creditJobId;
    const payload: IChangeOrderSummaryPayloadModel = {
      skip: this.skip,
      take: this.take,
      filters: [{ columnFilters: [{ field: 'creditJobId', operator: 'eq', value: creditJobId }], logic: 'and' }],
    };
    if (creditJobId > 0) {
      this.changeOrderService.getChangeOrderSummaryData(source, payload).subscribe((response) => {
        if (response.pagingItems) {
          this.handleSubmenu(this.ChangeOrdersName, true);
          this.isChangeOrderDetailsDisabled = false;
        } else {
          this.disableChangeOrderSubmenu();
        }
      }, (error: HttpErrorResponse) => {
        this.disableChangeOrderSubmenu();
      });
    }
  }

  /**
   * Disabling change order sub menu
   */
  disableChangeOrderSubmenu(): void {
    this.handleSubmenu(this.ChangeOrdersName, false);
    this.isChangeOrderDetailsDisabled = true;
  }

  /**
   * Enabling/disabling order service menu item based on menu item and isEnabled flag
   * @param menu menu item
   * @param isEnabled flag to enable sub menu
   */
  handleSubmenu(menu: string, isEnabled: boolean): void {
    for (const menuItem of this.orderServiceMenuItems) {
      if (menuItem.text === menu) {
        menuItem.disabled = !isEnabled;
      }
    }
  }

  /**
   * Highlight the active sub menu
   * @param  {IHeaderItemModel} item - submenu data.
   */
  highlightActiveSubMenu(menu: IHeaderItemModel): boolean {

    if (this.localCreditJobId !== 0) {
      this.projectCreditJobId = this.localCreditJobId;
    }
    if (this.currentState !== menu.route && (this.currentState.includes('Transmitted'))) {
      this.creditProject = this.creditProjectDetailsName;
    } else if (this.currentState !== menu.route && (this.currentState.includes('Untransmitted'))) {
      this.creditProject = 'Edit';
    } else {
      this.creditProject = this.currentState;
    }
    if (this.creditJobId !== null && (this.creditProject === menu.route) &&
      ((!this.fromHistory && (this.projectCreditJobId === this.creditJobId)) || this.fromHistory ||
        this.isUserHasOnlyCommissionSplitAccess)) {
      return true;
    }
  }
  /**
   * Highlight the disabled sub menu for untransmitted credit project and untransmitted sales order details
   * @param  {IHeaderItemModel} item - submenu data.
   */
  highlightDisabledSubMenu(menu: IHeaderItemModel): boolean {
    if (this.projectType && this.projectType === DisplayModeEnum.History && menu.text === this.assignSalesOrders) {
      return true;
    }
    return (((!this.fromHistory
      && (this.isUntransmittedCreditProject || this.isCopiedDownCreditProject)
      && this.isdisabled)
      || this.disableNavigationToSalesOrderDetail(menu.text)
      || this.disableNavigationToChangeOrderDetail(menu.text)
      || this.assignSalesOrders === menu.text)
      && !this.checkArchivedCreditJobPresent(menu.text)
      && this.disableNavigationToAssignSalesOrderPage(menu.text)
      || this.financialMenuItems.map((item) => item.text).includes(menu.text)
      && this.isProdOrStageEnvironment) || (this.isCreateProjectScreen && this.disableSubMenu)
      || (this.isUserHasOnlyCommissionSplitAccess && !this.commissionSplitAccessMenu.includes(menu.text));
  }

  /**
   * Disabling navigation to assign sales order screen when user has no edit acess and when credit project is transmitted
   * @param menuText Selected menu text
   */
  disableNavigationToAssignSalesOrderPage(menuText: string): boolean {
    return ((((this.salesOrderDetailsName !== menuText || !this.enableMirrorSalesOrder)
      || this.disableNavigationToSalesOrderDetail(menuText))
      && ((this.creditProjectName !== menuText && this.assignSalesOrders !== menuText) ||
        (this.assignSalesOrders === menuText && (!this.isUserIdLocked || this.doesUserIsInReadOnlyCreditProjectScreen())))
      && !this.isProdOrStageEnvironment) || (this.isProdOrStageEnvironment));
  }

  /**
   * Disabling navigation to sales order screen
   * @param menuText Selected menu text
   */
  disableNavigationToSalesOrderDetail(menuText: string): boolean {
    return this.isSalesOrderDetailsDisable && this.salesOrderDetailsName === menuText;
  }

  /**
   * Disabling navigation to change order screen
   * @param menuText Selected menu text
   */
  disableNavigationToChangeOrderDetail(menuText: string): boolean {
    return this.isChangeOrderDetailsDisabled && this.ChangeOrdersName === menuText;
  }

  /**
   * Checks if the user is in readonly screen
   */
  doesUserIsInReadOnlyCreditProjectScreen(): boolean {
    return !this.doesUserHaveEditAccess || !this.isEditable || (!this.isUntransmittedCreditProject && !this.isCopiedDownCreditProject);
  }

  /**
   * Shows errors and warnings side panel
   */
  showErrorsAndWarningsPopup(): void {
    this.errorsAndWarningsPanelService.errorsAndWarningsPanelClickEventHandler();
  }

  /**
   * Toggle errors and warnings side panel
   */
  pinUnpinErrorsAndWarningPanel(): void {
    const titleElement: HTMLElement = document.querySelector('#pinUnpinIcon');
    if (titleElement) {
      const showPanel = titleElement.classList.contains('pin');
      this.sharedJobHeaderService.showErrorsAndWarningsPanel.next(showPanel);
    }
  }

  // Fetch the validation messages count from api call
  fetchValidationMessagesCount(): void {
    if (this.enablePrevalidation && this.drAddressId > 0 && this.jobId > 0) {
      this.errorsAndWarningsPanelService.getValidationMessagesCount(this.drAddressId, this.jobId,
        [this.creditJobId > 0 ? this.creditJobId : null,
        (this.creditJobId > 0 && this.activeBidAlternateId > 0) ? this.activeBidAlternateId : null]);
      this.errorsAndWarningsPanelService.messageCount.subscribe((count) => {
        this.validationMessagesCount = count > 0 ? count : 0;
      });
      this.fetchPreValidationErrorAndWarningCount();
    }
  }

  // Fetch the Prevalidation error and warning count
  fetchPreValidationErrorAndWarningCount(): void {
    this.errorsAndWarningsPanelService.errorAndWarningCount.subscribe((response) => {
      this.preValidationErrorCount = response.preValidationErrorCount > 0 ? response.preValidationErrorCount : 0;
      this.preValidationWarningCount = response.preValidationWarningCount > 0 ? response.preValidationWarningCount : 0;
      if (this.preValidationErrorCount > 0) {
        this.commonService.isPreValidationErrorOrWarningExist.next(true);
      } else {
        this.commonService.isPreValidationErrorOrWarningExist.next(false);
      }
    });
  }
  /**
   * Checks if the target element contains error badge
   * @param {EventTarget} target - Gets the target element on clicking on the document
   * @returns boolean - Returns true or false based on the target value
   */
  isEventTargetContainsErrorsIcon(target: EventTarget): boolean {
    // Should check the target element only when the target is a html element
    if (this.errorsAndWarningsIcon && this.errorsAndWarningsIcon.nativeElement && target instanceof HTMLElement) {
      return this.errorsAndWarningsIcon.nativeElement.contains(target);
    }
  }

  /**
   * Toggles the error panel
   * @param event - Gets the event when clicking on the document
   */
  toggleErrorsPanel(event: Event): void {
    if (this.enablePrevalidation) {
      const titleElement: HTMLElement = document.querySelector('#pinUnpinIcon');
      const isUnpinned = titleElement && titleElement.classList.contains('unpin');
      // For toggling the popup while clicking on the badge
      if (this.isEventTargetContainsErrorsIcon(event.target)) {
        if (isUnpinned) {
          this.sharedJobHeaderService.showErrorsAndWarningsPanel.next(!this.sharedJobHeaderService.showErrorsAndWarningsPanel.value);
          this.isClickInErrorsPanel = false;
        }
      } else {
        // For not showing the popup while clicking anywhere in the page
        if (!this.isClickInErrorsPanel && isUnpinned) {
          this.sharedJobHeaderService.showErrorsAndWarningsPanel.next(false);
        }
      }
      this.isClickInErrorsPanel = false;

      // Disable refresh icon based on disable refresh icon value
      const refreshElement: HTMLElement = document.querySelector('#refreshIcon');
      if (this.disableRefreshIcon) {
        refreshElement?.classList.add('refresh-icon-disabled');
      } else {
        refreshElement?.classList.remove('refresh-icon-disabled');
      }
    }
  }

  // trigger prevalidation rules on click of refresh icon when credit projects under the jobs,
  // is untransmitted or transmiited with remnant or copy down but not transmitted
  clickRefreshIcon(): void {
    if (this.jobBidList) {
      if (!this.creditJobId || !this.activeBidAlternateId) {
        this.commonService.isPreValidationExit = true;
        // indicates that start of prevalidation
        this.toasterService.setToaster('success', this.appConstants.PREVALIDATION_START_MESSAGE);
        this.bidCount = 0;
        if (this.enablePricingValidation) {
          this.setBidsWithPricingError(this.jobBidList);
        }
        for (const bid in this.jobBidList) {
          if (this.jobBidList.hasOwnProperty(bid)) {
            this.triggerPrevalidationOnRefresh(this.jobBidList[bid]);
          }
        }
      } else {
        this.triggerPreValidationWithPricingRuleOnRefresh();
        this.startValidation = true;
        this.commonService.isPreValidationExit = false;
        this.triggerPreValidation(true);
      }
    }
  }

  /**
   * set bidAlternateId in bidIdsWithPricingError array if bid contains isPricingError as true
   * @param  { BidsListModel} jobBidList - bids List
   */
  setBidsWithPricingError(jobBidList: BidsListModel[]): void {
    const bidIdsWithoutCreditJobNumber = [];
    // check the bids not having credit project number
    jobBidList.forEach((bidsList) => {
      if (bidsList.creditJobNumber === null) {
        bidIdsWithoutCreditJobNumber.push(bidsList.bidAlternateId);
      }
    });
    if (bidIdsWithoutCreditJobNumber.length !== 0) {
      this.errorsAndWarningsPanelService.getPricingValidationDetails(this.drAddressId, this.jobId, bidIdsWithoutCreditJobNumber)
        .subscribe((response) => {
          if (response != null) {
            this.bidsWithPricingError = [];
            this.errorsAndWarningsPanelService.bidIdsWithoutPricingError = [];
            response.forEach((pricingErrorResponse) => {
              if (pricingErrorResponse.isPricingError) {
                this.bidsWithPricingError.push(pricingErrorResponse.bidAlternateId);
              } else {
                this.errorsAndWarningsPanelService.bidIdsWithoutPricingError.push(pricingErrorResponse.bidAlternateId);
              }
            });
            this.errorsAndWarningsPanelService.bidIdsWithPricingError.next(this.bidsWithPricingError);
          }
        });
    }
  }

  // set shouldTriggerPricingRuleValidation as true if credit project is untransmitted in edit credit project screen.
  triggerPreValidationWithPricingRuleOnRefresh(): void {
    if (this.isUntransmittedCreditProject && this.isEditCreditProjectScreen) {
      this.commonService.shouldTriggerPricingRuleValidation = true;
    } else {
      this.commonService.shouldTriggerPricingRuleValidation = false;
    }
  }

  triggerPrevalidationOnRefresh(jobBidList: BidsListModel): void {
    this.bidCount++;
    if (jobBidList.bidAlternateId && jobBidList.creditJobId) {
      if ((!(jobBidList.hqtrCreditJobId !== null || (jobBidList.hqtrCreditJobId === null &&
        jobBidList.foe2CreatedOrdersInd === 'N') || jobBidList.hqtrBidAlternateId !== null) &&
        (jobBidList.foe2CreatedOrdersInd === 'Y')) || jobBidList.isRemnant ||
        jobBidList.hqtrCreditJobId) {
        this.setPrevalidationPayload(jobBidList.bidAlternateId, jobBidList.creditJobId);
      }
    } else if (jobBidList.bidAlternateId) {
      this.setPrevalidationPayload(jobBidList.bidAlternateId, null);
    }
  }

  setPrevalidationPayload(BidAlternateId: number, CreditJobId: number): void {
    // payload to trigger the prevalidation and Assign Sales Orders
    if (this.currentState === 'assign-sales-orders') {
      this.startValidation = true;
      this.eventName = 'AssignSalesOrder';
      this.startAssignSalesOrderValidation = false;
    }
    this.preValidationPayload = {
      eventName: this.eventName,
      rootEntityName: 'Job',
      rootEntityId: this.jobId,
      additionalInfo: '{BidAlternateId:' + BidAlternateId +
        ',CreditJobId:' + CreditJobId + '}',
    };
    this.startValidation = true;
    this.triggerPreValidation(true);
  }
  // triggers the prevalidation for the current bid based on the startValidation which is set from various trigger points
  triggerPreValidation(isRefresh: boolean = false): void {
    if (this.currentState === 'assign-sales-orders' && (!this.startValidation) && (!this.startAssignSalesOrderValidation)) {
      this.startValidation = true;
      this.startAssignSalesOrderValidation = true;
    }
    if (this.enablePrevalidation && this.startValidation) {
      // payload to trigger the prevalidation and Assign Sales Orders
      if (!this.preValidationPayload) {
        if (this.currentState === 'assign-sales-orders') {
          this.eventName = 'AssignSalesOrder';
          this.startAssignSalesOrderValidation = true;
        } else {
          this.eventName = this.commonService.shouldTriggerPricingRuleValidation ? 'PreValidationWithPricingRule' : 'PreValidation';
        }
        this.toasterService.setToaster('success', this.appConstants.PREVALIDATION_START_MESSAGE);
        // indicates that start of prevalidation
        this.preValidationPayload = {
          eventName: this.eventName,
          rootEntityName: 'Job',
          rootEntityId: this.jobId,
          additionalInfo: '{BidAlternateId:' + this.activeBidAlternateId +
            ',CreditJobId:' + this.creditJobId + '}',
        };
      }
      this.validationErrorService.postPreValidate(this.drAddressId, this.preValidationPayload)
        .subscribe((response) => {
          this.messageCount++;
          if ((response.toLowerCase() === 'success' && !this.commonService.isPreValidationExit) ||
            (response.toLowerCase() === 'success' && isRefresh && this.messageCount === this.bidCount)) {
            // updates the errors&warnings count after the pre-vaidation process has been completed successfully
            this.fetchValidationMessagesCount();
            if (isRefresh) {
              this.commonService.refreshErrorsAndWarningPanel.next(true);
            }
            this.toasterService.setToaster('success', this.appConstants.PREVALIDATION_SUCCESS_MESSAGE);
            this.messageCount = 0;
          }
          this.assignSalesOrdersService.salesOrderValidationSubject.next(true);
        }, (error: HttpErrorResponse) => {
          if (!error.status) {
            this.toasterService.setToaster('error', this.appConstants.PREVALIDATION_ERROR_MESSAGE);
          } else {
            this.apiErrorService.show(error.error);
          }
        });
      this.startValidation = false;
      this.preValidationPayload = null;
      this.commonService.shouldTriggerPricingRuleValidation = false;
    }
  }

  /**
   * Builds bids list for create credit project screen.
   */
  buildCreateProjectBidsList(): void {
    const bidsWithIdNull = this.jobBidList.filter((bid) => {
      return bid.creditJobNumber === null;
    });

    const bidsWithId = this.jobBidList.filter((bid) => {
      return bid.creditJobNumber !== null;
    });

    // Pushing bids with null credit job number to createProjectBidList by mapping with bid alternate id
    bidsWithIdNull.forEach((element) => {
      if (bidsWithId.map((e) => e.bidAlternateId).indexOf(element.bidAlternateId) < 0) {
        this.createProjectBidList.push(element);
      }
    });

    this.createProjectBidList = this.createProjectBidList.concat(this.projectBidList);

    this.handleSelectedBidInCarousel();
    this.handleSavedBidInCarousel();
  }

  /**
   * Handles selected bid in carousel for create credit project screen.
   */
  handleSelectedBidInCarousel(): void {
    this.selectedBidSubscription = this.createCreditProjectService.selectedBid.subscribe((selectedBid: ISelectedBidModel) => {
      if (selectedBid?.bidData) {
        // Showing selected bid as current slide in carousel
        const selectedBidIndex = this.createProjectBidList.findIndex(bid => bid.bidName === selectedBid.bidData.bidName);
        if (selectedBidIndex >= 0) {
          this.slideConfiguration(selectedBidIndex);
        }
      }
    });
  }

  /**
   * Handles saved bid in carousel for create credit project screen.
   */
  handleSavedBidInCarousel(): void {
    this.savedProjectDetailsSubscription = this.commonService.savedProjectDetails.subscribe((savedProjectDetails) => {
      if (savedProjectDetails) {
        this.creditProjectNumber = savedProjectDetails.creditJobNumber;
        if (this.isCreateProjectScreen) {
          this.projectBidList = savedProjectDetails.updatedProjectBidList;
        }
        let savedBidIndex = this.createProjectBidList.findIndex(bid => bid.bidAlternateId === savedProjectDetails.bidAlternateId);
        if (savedBidIndex >= 0) {
          if (this.savedProjectCount > 0) {
            // Handling bid name change after the initial save.
            const bid = this.createProjectBidList[this.createProjectBidList.length - 1];
            if (bid.bidAlternateId !== savedProjectDetails.bidAlternateId) {
              /* Removing previously assigned bid with credit project number and
                pushing new bid with credit project number */
              this.createProjectBidList.pop();
              bid.creditJobNumber = null;
              this.createProjectBidList.unshift(bid);
              savedBidIndex++;
            }
          }
          // Displaying credit project number with bid name in carousel after successful save
          const savedBid = {
            bidName: this.createProjectBidList[savedBidIndex].bidName,
            bidAlternateId: this.createProjectBidList[savedBidIndex].bidAlternateId,
            creditJobNumber: savedProjectDetails.creditJobNumber
          } as BidsListModel;
          // Removing previous unassigned bid and pushing new bid with credit project number
          this.createProjectBidList.splice(savedBidIndex, 1);
          this.createProjectBidList.push(savedBid);
          this.slideConfiguration(this.createProjectBidList.length - 1);
          this.savedProjectCount++;
          this.startValidation = false;
        }
      }
    });
  }

  /**
   * Get carousel data.
   */
  getCarouselData(): BidsListModel[] {
    return this.isCreateProjectScreen ? this.createProjectBidList : this.projectBidList;
  }

  /**
   * Sets commission split access by checking whether current draddress id matches office selector list
   */
  setCommissionSplitAccessStatus(): void {
    if (this.drAddressId && this.isCreditJobsUrl) {
      this.filterService.getOfficeSelectorList().subscribe((data) => {
        const currentOfficeSelector = data.filter((x) => x.drAddressId === this.drAddressId);
        if (!currentOfficeSelector || currentOfficeSelector.length === 0) {
          this.commonService.commissionSplitAccessStatus(true);
        } else {
          this.commonService.commissionSplitAccessStatus(false);
        }
      });
    }
  }

  /**
   * checks for commission split only access and fetch header menu details
   */
  checksCommissionSplitAccessAndFetchHeaderDetails(): void {
    this.commonService.isUserHasOnlyCommissionSplitAccess.subscribe((value) => {
      this.isUserHasOnlyCommissionSplitAccess = value;
      if (!value) {
        this.getCreditJobNumberList(this.drAddressId, this.jobId);
        this.fetchValidationMessagesCount();
      } else {
        this.setMenuForZeroBidsCreditProject();
        this.enablePrevalidation = false;
      }
    });
  }

  /**
   * Destroy the observables
   */
  ngOnDestroy(): void {
    if (this.selectedBidSubscription) {
      this.selectedBidSubscription.unsubscribe();
    }
    if (this.savedProjectDetailsSubscription) {
      this.savedProjectDetailsSubscription.unsubscribe();
    }
  }

  /**
   * Checks and returns boolean value if archived credit job is present based on menu
   * @param  menuText - contains menu name.
   */
  checkArchivedCreditJobPresent(menuText: string): boolean {
    if (menuText === this.ChangeOrdersName && this.isArchivedCreditJobPresent) {
      return false;
    } else {
      return this.isArchivedCreditJobPresent;
    }
  }
}
