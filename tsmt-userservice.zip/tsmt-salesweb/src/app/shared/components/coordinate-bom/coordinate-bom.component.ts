import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
import { groupBy } from '@progress/kendo-data-query';
import { IBidSelections } from '../../../modules/jobs-list-master/models/coordinate-job.model';
import { AutoSaveWidget } from '../autosave-widget/autosave-widget';
import { ISelection } from './../../../modules/jobs-list-master/models/coordinate-job.model';
import { CoordinateService } from './../../../modules/jobs-list-master/services/coordinate.service';
import { JobCoordinationMergeService } from './../../services/job-coordination-merge.service';
import { JobCoordinationValidationService } from './../../services/job-coordination-validation.service';
import { ToasterService } from './../../services/toaster.service';

@Component({
    selector: 'app-coordinate-bom',
    templateUrl: './coordinate-bom.component.html',
    styleUrls: ['./coordinate-bom.component.scss'],
})

export class CoordinateBOMComponent extends AutoSaveWidget implements OnInit, OnChanges {
    @Input() bidIds: number[];
    @Input() bidsChanged = false;
    @Input() shippingLeadTimeValidations = [];
    jobId: number;
    drAddressId: number;
    bids: IBidSelections[] = [];
    bidsInFlight = [];
    bomData;
    gridData;
    shipQuarters = [1, 2, 3, 4];
    shipYears;
    globalShipQuarter = 0;
    globalShipYear = 0;
    gridPageSize = 10;
    skip = 0;
    currentQuarter = 0;
    currentYear = 0;
    isBomDataLoading = false;
    globalInvalidSelection: boolean;
    isFirstLoad = true;
    @Output() save: EventEmitter<any> = new EventEmitter<any>();

    constructor(
        private coordinateService: CoordinateService, private route: ActivatedRoute,
        private toasterService: ToasterService, private jobCoordinationMergeService: JobCoordinationMergeService,
        private validationService: JobCoordinationValidationService, elementRef: ElementRef) {
        super(elementRef);
    }

    ngOnInit() {
        this.currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth();
        this.currentQuarter = this.calculateQuarter(currentMonth);
        this.shipYears = [this.currentYear, this.currentYear + 1, this.currentYear + 2, this.currentYear + 3];
        this.jobId = +this.route.snapshot.params['jobId'];
        this.drAddressId = +this.route.snapshot.params['drAddressId'];
        this.buildBillOfMaterials(this.bidIds);
    }

    calculateQuarter(month) {
        return Math.ceil((month + 1) / 3);
    }

    ngOnChanges(changes: SimpleChanges) {
        const bidIdsChange = changes['bidIds'];
        if (bidIdsChange && !bidIdsChange.isFirstChange()) {
            this.updateBillOfMaterials();
        }
        if (changes['shippingLeadTimeValidations']) {
            this.validateShipLeadTime();
        }
    }

    updateBillOfMaterials() {
        this.bids = this.bids.filter((bid) => this.bidIds.includes(bid.bidAlternateId));
        this.buildBillOfMaterials(this.getNewBidIds());
        if (!this.isReadOnly && this.bidsChanged) {
            this.isEdited = true;
        }
    }

    getNewBidIds(): number[] {
        if (this.bidIds && this.bidIds.length > 0) {
            let bidIds = this.bidIds.filter((bidId) => {
                return !this.bids.some((bid) => {
                    return bidId === bid.bidAlternateId;
                });
            });
            bidIds = bidIds.filter((bidId) => !this.bidsInFlight.includes(bidId));
            this.bidsInFlight.push(...bidIds);
            return bidIds;
        }
        return [];
    }

    buildBillOfMaterials(bidIds: number[]) {
        if (bidIds && bidIds.length > 0) {
            this.isBomDataLoading = true;
            this.coordinateService.fetchBidsWithSelections(this.drAddressId, this.jobId, bidIds).subscribe((bids) => {
                this.removeBidsFromFlight(bidIds);
                if (this.isFirstLoad) {
                    bids = this.jobCoordinationMergeService.buildBomData(bids);
                    this.isFirstLoad = false;
                    this.isEdited = true;
                }
                this.updateSelections(bids);
                this.addBidsToList(bids);
                this.bids.sort((bid1, bid2) => (bid1.bidName < bid2.bidName ? -1 : 1));
                this.validateBids();
                this.setBOMData();
                this.isBomDataLoading = false;
            }, (error) => {
                this.toasterService.setToaster('error', 'An error occured while fetching Bill of Materials');
                this.removeBidsFromFlight(bidIds);
                this.isBomDataLoading = false;
            });
        } else {
            this.validateBids();
            this.setBOMData();
        }
    }

    validateBids() {
        let areDatesSelected = true;
        let areBidsValid = true;
        this.bids.forEach((bid) => {
            bid.selections.filter((selection) => this.shouldValidateSelection(selection))
                .forEach((selection: any) => {
                    if (this.isShipTimeSelected(selection)) {
                        const shipTimeInPast = this.isShipTimeInPast(selection);
                        if (shipTimeInPast) {
                            areBidsValid = false;
                            selection.pastTimeSelection = shipTimeInPast;
                        }
                    } else {
                        areDatesSelected = false;
                    }
                });
        });
        this.validationService.setBomDateValidFlag(areBidsValid);
        this.validationService.setBomDateSetFlag(areDatesSelected);
        this.validateShipLeadTime();
    }

    removeBidsFromFlight(bidIds) {
        this.bidsInFlight = this.bidsInFlight.filter((bidId) => !bidIds.includes(bidId));
    }

    addBidsToList(bids) {
        bids.forEach((bid) => {
            if (this.bidIds.includes(bid.bidAlternateId)) {
                this.bids.push(bid);
            }
        });
    }

    updateShippingTimeInSelections(newBids) {
        const existingSelections = this.getSelections(this.bids);
        const newSelections = this.getSelections(newBids);
        existingSelections.forEach((existingSelection) => {
            const shipQuarter = existingSelection.coordinationJobShipQuarter;
            const shipYear = existingSelection.coordinationJobShipYear;
            if (shipQuarter || shipYear) {
                newSelections.filter((selection) => selection.prodFamilyId === existingSelection.prodFamilyId)
                    .forEach((selection) => {
                        selection.coordinationJobShipQuarter = shipQuarter ? shipQuarter : selection.coordinationJobShipQuarter;
                        selection.coordinationJobShipYear = shipYear ? shipYear : selection.coordinationJobShipYear;
                    });
            }
        });
    }

    updateSelections(bids: IBidSelections[]) {
        if (!this.isReadOnly) {
            this.updateShippingTimeInSelections(bids);
        }
        bids.forEach((bid) => {
            bid.selections.forEach((selection) => {
                selection.bidName = bid.bidName;
                selection.bidAlternateId = bid.bidAlternateId;
                selection.bidNameAndId = bid.bidName + bid.bidAlternateId;
                this.checkAndSetDefaultShipTime(selection);
                if (selection.coordinationJobShipYear < this.currentYear) {
                    selection.oldShipYear = selection.coordinationJobShipYear;
                }
            });
            bid.selections.sort((selection1, selection2) => (selection1.description < selection2.description ? -1 : 1));
        });
    }

    checkAndSetDefaultShipTime(selection: ISelection): void {
        selection.displayShipQuarterError = false;
        selection.displayShipYearError = false;
        selection.displayPastTimeError = false;
        if (!selection.coordinationJobShipQuarter) {
            selection.coordinationJobShipQuarter = 0;
            selection.displayShipQuarterError = this.shouldValidateSelection(selection);
        }
        if (!selection.coordinationJobShipYear) {
            selection.coordinationJobShipYear = 0;
            selection.displayShipYearError = this.shouldValidateSelection(selection);
        }
        if (this.isShipTimeInPast(selection)) {
            selection.displayPastTimeError = this.shouldValidateSelection(selection);
        }
    }

    shouldValidateSelection(selection) {
        let hasBiddableSelection = false;
        if (selection.doesSeparatelyBiddableSelectionsExist) {
            hasBiddableSelection = selection.doesSeparatelyBiddableSelectionsExist;
        }
        return selection.selectionSource === 'C' && !hasBiddableSelection;
    }

    setBOMData() {
        // Selections should be grouped by bids and groups should be sorted by bidName
        // Because kendo grid groups and sorts using the same field,
        // we cannot use bidName to group as it might not be unique,
        // we cannot use bidAlternateId to sort, because the sorting should happen using bidName.
        // Hence, created a hybrid feild bidNameAndId to be unique and also acheieve the desired sorting
        this.bomData = groupBy(this.getSelections(this.bids), [{ dir: 'asc', field: 'bidNameAndId' }]);
        this.setGridData();
    }

    getSelections(bids) {
        return bids
            .reduce((selections, bid) => {
                selections.push(...bid.selections);
                return selections;
            }, []);
    }

    pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
        this.setGridData();
    }

    setGridData(): void {
        this.gridData = {
            data: this.bomData.slice(this.skip, this.skip + this.gridPageSize),
            total: this.bomData.length,
        };
    }

    handleGlobalSelectionShipTimeChange() {
        const globalShipTimeChange = {
            coordinationJobShipQuarter: this.globalShipQuarter,
            coordinationJobShipYear: this.globalShipYear,
        };
        this.globalInvalidSelection = this.isShipTimeSelected(globalShipTimeChange) && this.isShipTimeInPast(globalShipTimeChange);
    }

    updateShippingTimeForAllSelections() {
        if (!this.isReadOnly && this.globalShipQuarter && this.globalShipYear && !this.globalInvalidSelection) {
            this.bomData.forEach((bid) => {
                bid.items.forEach((selection) => {
                    selection.coordinationJobShipQuarter = this.globalShipQuarter;
                    selection.coordinationJobShipYear = this.globalShipYear;
                    selection.pastTimeSelection = false;
                    selection.displayShipQuarterError = false;
                    selection.displayShipYearError = false;
                    selection.displayPastTimeError = false;
                    this.updateErrorAndWarningIndicators(selection);
                });
            });
            this.isEdited = true;
            this.validationService.setBomDateValidFlag(true);
            this.validationService.setBomDateSetFlag(true);
        }
    }

    isShipTimeSelected(changedSelection): boolean {
        return changedSelection.coordinationJobShipQuarter > 0 && changedSelection.coordinationJobShipYear > 0;
    }

    isShipTimeInPast(changedSelection) {
        return (changedSelection.coordinationJobShipYear < this.currentYear) || (changedSelection.coordinationJobShipYear ===
            this.currentYear && changedSelection.coordinationJobShipQuarter < this.currentQuarter);
    }

    handleSelectionShipTimeChange(changedSelection, field) {
        if (!this.isReadOnly) {
            changedSelection.pastTimeSelection = this.isShipTimeSelected(changedSelection) && this.isShipTimeInPast(changedSelection);
            if (!changedSelection.pastTimeSelection && changedSelection[field]) {
                this.updateShippingTimeInAllBidsForSameSelection(changedSelection, field);
            }
            this.checkAndSetDefaultShipTime(changedSelection);
            this.validateBids();
            this.isEdited = true;
        }
    }

    updateShippingTimeInAllBidsForSameSelection(baseSelection, field) {
        this.bomData.forEach((bid) => {
            bid.items
                .filter((selection) => (selection.prodFamilyId === baseSelection.prodFamilyId))
                .forEach((selection) => {
                    selection[field] = baseSelection[field];
                    selection.pastTimeSelection = false;
                });
        });
    }

    handleCompetitorChange() {
        this.checkReadOnlyAndSetEditStatus();
    }

    handleSpecifiedUserChange() {
        this.checkReadOnlyAndSetEditStatus();
    }

    checkReadOnlyAndSetEditStatus() {
        if (!this.isReadOnly) {
            this.isEdited = true;
        }
    }

    saveData() {
        const selections = [];
        this.bids.forEach((bid) => {
            const validSelections = bid.selections.filter((selection: any) => {
                const shipTimeSelected = this.isShipTimeSelected(selection);
                const shipTimeInPast = this.isShipTimeInPast(selection);
                selection.pastTimeSelection = shipTimeSelected && shipTimeInPast;
                return (shipTimeSelected && !shipTimeInPast) || !this.shouldValidateSelection(selection);
            });
            selections.push(...validSelections);
        });
        this.save.emit(selections);
    }

    validateShipLeadTime() {
        const shipLeadTimeErrors = this.shippingLeadTimeValidations
            .filter((productFamily) => {
                const selectionErrors = productFamily.selectionErrors || [];
                return !productFamily.isValidShippingLeadTime || selectionErrors.length > 0;
            });
        this.setShipLeadTimeErrorsInSelections(shipLeadTimeErrors);
    }

    setShipLeadTimeErrorsInSelections(shipLeadTimeErrors) {
        let isShipLeadTimeValid = true;
        let hasSelectionErrors = false;
        this.bids.forEach((bid) => {
            bid.selections.forEach((selection) => {
                selection.isValidShippingLeadTime = true;
                selection.selectionErrors = [];
                if (this.shouldValidateSelection(selection)) {
                    shipLeadTimeErrors.forEach((productFamily) => {
                        if (selection.prodFamilyId === productFamily.productFamilyId) {
                            selection.isValidShippingLeadTime = productFamily.isValidShippingLeadTime;
                            selection.selectionErrors = productFamily.selectionErrors || [];
                            if (selection.selectionErrors.length > 0) {
                                hasSelectionErrors = true;
                            }
                            isShipLeadTimeValid = false;
                        }
                    });
                    this.updateErrorAndWarningIndicators(selection);
                }
            });
        });
        this.validationService.setHasSelectionErrors(hasSelectionErrors);
        this.validationService.setValidShipLeadTimeFlag(isShipLeadTimeValid);
    }

    updateErrorAndWarningIndicators(selection) {
        const errorsInSelection = selection.selectionErrors && selection.selectionErrors.length > 0;
        const isInvalidShipLeadTime = !selection.isValidShippingLeadTime;
        if (this.validationService.getHasBeenPreviouslyCoordinatedFlag()) {
            selection.error = selection.pastTimeSelection || errorsInSelection;
            selection.warning = !selection.error && isInvalidShipLeadTime;
        } else {
            selection.error = selection.pastTimeSelection || isInvalidShipLeadTime || errorsInSelection;
            selection.warning = false;
        }
        selection.showQuarterIcon = this.shouldShowException(selection, 'coordinationJobShipQuarter');
        selection.quarterClass = this.getExceptionClass(selection, 'coordinationJobShipQuarter');
        selection.showYearIcon = this.shouldShowException(selection, 'coordinationJobShipYear');
        selection.yearClass = this.getExceptionClass(selection, 'coordinationJobShipYear');
    }

    getExceptionClass(selection, field) {
        let exceptionClass = '';
        if (!selection[field] || selection.error) {
            exceptionClass = 'fas fa-info-circle error-info-icon';
        } else if (selection.warning) {
            exceptionClass = 'fas fa-exclamation-triangle warning-icon';
        }
        return exceptionClass;
    }

    shouldShowException(selection, field) {
        return !selection[field] || selection.error || selection.warning;
    }
}
