import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SimpleChange } from '@angular/core';
import { ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GridModule, PageChangeEvent } from '@progress/kendo-angular-grid';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { throwError } from 'rxjs';
import { of } from 'rxjs';
import { IBidSelections, ISelection } from './../../../modules/jobs-list-master/models/coordinate-job.model';
import { CoordinateService } from './../../../modules/jobs-list-master/services/coordinate.service';
import { AppConstants } from './../../constants/constants';
import { JobCoordinationMergeService } from './../../services/job-coordination-merge.service';
import { JobCoordinationValidationService } from './../../services/job-coordination-validation.service';
import { ToasterService } from './../../services/toaster.service';
import { CoordinateBOMComponent } from './coordinate-bom.component';

// tslint:disable-next-line:no-big-function
describe('CoordinateBOMComponent', () => {
    let component: CoordinateBOMComponent;
    let fixture: ComponentFixture<CoordinateBOMComponent>;
    let coordinateService: CoordinateService;
    let toasterService: ToasterService;
    let jobCoordinationMergeService: JobCoordinationMergeService;
    let validationService: JobCoordinationValidationService;
    let injector: TestBed;
    const originReset = TestBed.resetTestingModule;
    const testJobId = 1234;
    const testDrAddressId = 122;
    let testBomBid1;
    let testBomBid2;
    let testBid;
    let testCoordinateData;
    const errorClass = 'fas fa-info-circle error-info-icon';
    const warningClass = 'fas fa-exclamation-triangle warning-icon';

    configureTestSuite((() => {
        TestBed.configureTestingModule({
            imports: [GridModule, FormsModule, HttpClientTestingModule, TooltipModule],
            declarations: [CoordinateBOMComponent],
            providers: [CoordinateService, AppConstants, ToasterService, JobCoordinationMergeService, JobCoordinationValidationService,
                { provide: ActivatedRoute, useValue: { snapshot: { params: { jobId: testJobId, drAddressId: testDrAddressId } } } },
            ],
        });
    }));

    beforeEach(() => {
        injector = getTestBed();
        fixture = TestBed.createComponent(CoordinateBOMComponent);
        component = fixture.componentInstance;
        coordinateService = injector.inject(CoordinateService);
        jobCoordinationMergeService = injector.inject(JobCoordinationMergeService);
        validationService = injector.inject(JobCoordinationValidationService);
        toasterService = injector.inject(ToasterService);
        testBomBid1 = {
            items: [{
                prodFamilyId: 2006347,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2020,
            }],
        };
        testBomBid2 = {
            items: [{
                prodFamilyId: 2006348,
                coordinationJobShipQuarter: 2,
                coordinationJobShipYear: 2020,
            }],
        };
        testCoordinateData = null;
        fixture.detectChanges();
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should set jobId and drAddressId from the route parameters when component is initialized', () => {
        expect(component.jobId).toBe(testJobId);
        expect(component.drAddressId).toBe(testDrAddressId);
    });

    it('should set ship year options when component is initialized', () => {
        const year = new Date().getFullYear();
        expect(component.shipYears).toEqual([year, year + 1, year + 2, year + 3]);
    });

    it('should call buildBillOfMaterials method with bidIds when component is initialized', () => {
        const testBidIds = [123, 456];
        component.bidIds = testBidIds;
        const spy = spyOn(component, 'buildBillOfMaterials').and.callThrough();
        component.ngOnInit();
        expect(spy).toHaveBeenCalledWith(testBidIds);
    });

    it('should call updateBillOfMaterials when input bidIds are changed', () => {
        const newBidIds = [567, 678];
        component.bidIds = newBidIds;
        const bidIdsChange: SimpleChange = { currentValue: newBidIds, isFirstChange: () => false } as SimpleChange;
        const spy = spyOn(component, 'updateBillOfMaterials').and.callThrough();
        component.ngOnChanges({ bidIds: bidIdsChange });
        expect(spy).toHaveBeenCalled();
    });

    it('should remove corresponding bid when an input bidId is removed', () => {
        component.bids = [{ bidAlternateId: 123, bidName: 'Base bid', selections: [] },
        { bidAlternateId: 456, bidName: 'Rebid', selections: [] }] as IBidSelections[];
        const newBidIds = [456];
        component.bidIds = newBidIds;
        const bidIdsChange: SimpleChange = { currentValue: newBidIds, isFirstChange: () => false } as SimpleChange;
        component.ngOnChanges({ bidIds: bidIdsChange });
        expect(component.bids.length).toBe(1);
        expect(component.bids[0].bidAlternateId).toBe(456);
        expect(component.bids[0].bidName).toBe('Rebid');
    });

    it('should call buildBillOfMaterials when a new bidId is added to the input bidIds', () => {
        component.bids = [{ bidAlternateId: 123, bidName: 'Base bid', selections: [] }] as IBidSelections[];
        const newBidIds = [123, 456];
        component.bidIds = newBidIds;
        const bidIdsChange: SimpleChange = { currentValue: newBidIds, isFirstChange: () => false } as SimpleChange;
        const spy = spyOn(component, 'buildBillOfMaterials').and.callThrough();
        component.ngOnChanges({ bidIds: bidIdsChange });
        expect(spy).toHaveBeenCalledWith([456]);
    });

    it('should merge draft data when buildBillOfMaterials is called and isFirstLoad is true', fakeAsync(() => {
        component.bids = [];
        component.isFirstLoad = true;
        component.bidIds = [456];
        const newBidIds = [456];
        component.bidsInFlight = [456];
        const newBids = [{ bidAlternateId: 456, bidName: 'Base bid', selections: [] }] as IBidSelections[];
        const spy = spyOn(coordinateService, 'fetchBidsWithSelections').and.returnValue(of(newBids));
        const spyJobCoordinationMerge = spyOn(jobCoordinationMergeService, 'buildBomData').and.returnValue((newBids));
        component.buildBillOfMaterials(newBidIds);
        tick();
        expect(spy).toHaveBeenCalled();
        expect(spyJobCoordinationMerge).toHaveBeenCalled();
        expect(component.bids.length).toBe(1);
        expect(component.bids[0].bidName).toBe('Base bid');
        expect(component.bidsInFlight.length).toBe(0);
        expect(component.isFirstLoad).toBe(false);
        expect(component.isEdited).toBe(true);
    }));

    it('should append new bids and sort them when buildBillOfMaterials is called with bidIds', fakeAsync(() => {
        component.bids = [{ bidAlternateId: 123, bidName: 'Rebid', selections: [] }] as IBidSelections[];
        expect(component.bids.length).toBe(1);
        expect(component.bids[0].bidName).toBe('Rebid');
        component.bidIds = [123, 456];
        const newBidIds = [456];
        component.bidsInFlight = [456];
        component.isFirstLoad = false;
        const newBids = [{ bidAlternateId: 456, bidName: 'Base bid', selections: [] }] as IBidSelections[];
        const spy = spyOn(coordinateService, 'fetchBidsWithSelections').and.returnValue(of(newBids));
        const spyJobCoordinationMerge = spyOn(jobCoordinationMergeService, 'buildBomData');
        const validationSpy = spyOn(component, 'validateBids').and.callThrough();
        const spy2 = spyOn(component, 'setBOMData').and.callThrough();
        component.buildBillOfMaterials(newBidIds);
        tick();
        expect(spy).toHaveBeenCalled();
        expect(validationSpy).toHaveBeenCalled();
        expect(spy2).toHaveBeenCalled();
        expect(spyJobCoordinationMerge).not.toHaveBeenCalled();
        expect(component.bids.length).toBe(2);
        expect(component.bids[0].bidName).toBe('Base bid');
        expect(component.bids[1].bidName).toBe('Rebid');
        expect(component.bidsInFlight.length).toBe(0);
    }));

    it('should set a toaster message when fetching bill of materials is failed', fakeAsync(() => {
        component.bids = [{ bidAlternateId: 123, bidName: 'Rebid', selections: [] }] as IBidSelections[];
        component.bidIds = [123, 456];
        const newBidIds = [456];
        component.bidsInFlight = [456];
        const spy = spyOn(coordinateService, 'fetchBidsWithSelections').and.returnValue(throwError({}));
        const spy2 = spyOn(toasterService, 'setToaster').and.callThrough();
        component.buildBillOfMaterials(newBidIds);
        tick();
        expect(spy).toHaveBeenCalled();
        expect(spy2).toHaveBeenCalled();
        expect(component.bidsInFlight.length).toBe(0);
    }));

    it('should call setBOMData when buildBillOfMaterials is called with empty bidIds', () => {
        const spy = spyOn(component, 'setBOMData').and.callThrough();
        component.buildBillOfMaterials([]);
        expect(spy).toHaveBeenCalled();
    });

    it('should add bid name to selections and sort them when updateSelections is called', () => {
        component.isReadOnly = false;
        const testSelections = [{ description: 'Product B', coordinationJobShipQuarter: null },
        { description: 'Product A', coordinationJobShipYear: null, selectionSource: 'C' }] as ISelection[];
        const testBids = [{ bidAlternateId: 456, bidName: 'Base bid', selections: testSelections }] as IBidSelections[];
        component.updateSelections(testBids);
        expect(testBids[0].selections[0].description).toBe('Product A');
        expect(testBids[0].selections[1].description).toBe('Product B');
        expect(testBids[0].selections[0].bidName).toBe(testBids[0].bidName);
        expect(testBids[0].selections[1].bidName).toBe(testBids[0].bidName);
        expect(testBids[0].selections[0].coordinationJobShipQuarter).toBe(0);
        expect(testBids[0].selections[1].displayShipQuarterError).toBe(false);
        expect(testBids[0].selections[1].coordinationJobShipYear).toBe(0);
        expect(testBids[0].selections[0].displayShipYearError).toBe(true);
    });

    it('should group selections by bidNameAndId and set grid data when setBOMData method is called', () => {
        const testBid1NameAndId = 'Base bid123';
        const testBid2NameAndId = 'Rebid';
        component.skip = 0;
        component.gridPageSize = 10;
        const testSelection1 = {
            description: 'Product A',
            bidName: 'Base bid',
            bidNameAndId: testBid1NameAndId,
        };
        const testSelection2 = {
            description: 'Product B',
            bidName: 'Base bid',
            bidNameAndId: testBid1NameAndId,
        };
        const testSelection3 = {
            description: 'Product C',
            bidName: 'Rebid',
            bidNameAndId: testBid2NameAndId,
        };
        const testBid1 = {
            bidAlternateId: 123,
            bidName: 'Base bid',
            selections: [testSelection1, testSelection2],
        };
        const testBid2 = {
            bidAlternateId: 456,
            bidName: 'Rebid',
            selections: [testSelection3],
        };
        const testBids = [testBid1, testBid2] as IBidSelections[];
        component.bids = testBids;
        component.setBOMData();
        expect(component.bomData.length).toBe(2);
        expect(component.bomData[0].value).toBe(testBid1NameAndId);
        expect(component.bomData[0].field).toBe('bidNameAndId');
        expect(component.bomData[0].items.length).toBe(testBid1.selections.length);
        expect(component.bomData[1].value).toBe(testBid2NameAndId);
        expect(component.bomData[1].field).toBe('bidNameAndId');
        expect(component.bomData[1].items.length).toBe(testBid2.selections.length);
        expect(component.gridData.total).toBe(component.bomData.length);
        expect(component.gridData.data).toEqual(component.bomData.slice(0, 10));
    });

    it('should return empty bidIds from getNewBidIds() when input bidIds are empty', () => {
        component.bidIds = [];
        component.bids = [];
        expect(component.getNewBidIds().length).toBe(0);
    });

    it('should set skip and set grid data when page change event is triggered', () => {
        const event = { skip: 20 } as PageChangeEvent;
        const spy = spyOn(component, 'setGridData').and.callThrough();
        component.pageChange(event);
        expect(component.skip).toBe(event.skip);
        expect(spy).toHaveBeenCalled();
    });

    it('should update ship quarter and year for all the selections when updateShippingTimeForAllSelections is called', () => {
        component.isReadOnly = false;
        component.globalShipQuarter = 3;
        component.globalShipYear = 2021;
        component.bomData = [testBomBid1, testBomBid2];
        const spyDateSet = spyOn(validationService, 'setBomDateSetFlag');
        const spyDateValid = spyOn(validationService, 'setBomDateValidFlag');
        const errorUpdateSpy = spyOn(component, 'updateErrorAndWarningIndicators').and.callThrough();
        component.updateShippingTimeForAllSelections();
        expect(component.bomData[0].items[0].coordinationJobShipQuarter).toBe(3);
        expect(component.bomData[0].items[0].coordinationJobShipYear).toBe(2021);
        expect(component.bomData[1].items[0].coordinationJobShipQuarter).toBe(3);
        expect(component.bomData[1].items[0].coordinationJobShipYear).toBe(2021);
        expect(component.bomData[0].items[0].displayShipQuarterError).toBe(false);
        expect(component.bomData[0].items[0].displayShipYearError).toBe(false);
        expect(component.bomData[0].items[0].displayPastTimeError).toBe(false);
        expect(spyDateSet).toHaveBeenCalledWith(true);
        expect(spyDateValid).toHaveBeenCalledWith(true);
        expect(errorUpdateSpy).toHaveBeenCalled();
    });

    it('should not update ship quarter and year if component is read only', () => {
        component.isReadOnly = true;
        component.bomData = [testBomBid1];
        component.updateShippingTimeForAllSelections();
        expect(component.bomData[0].items[0].coordinationJobShipQuarter).toBe(1);
        expect(component.bomData[0].items[0].coordinationJobShipYear).toBe(2020);
    });

    it('should not update ship quarter and year if globalShipQuarter and globalShipYear are not set', () => {
        component.isReadOnly = false;
        component.bomData = [testBomBid1];
        component.updateShippingTimeForAllSelections();
        expect(component.bomData[0].items[0].coordinationJobShipQuarter).toBe(1);
        expect(component.bomData[0].items[0].coordinationJobShipYear).toBe(2020);
    });

    it('should call updateShippingTimeInAllBidsForSameSelection if ship quarter is changed in a selection', () => {
        component.isReadOnly = false;
        component.currentYear = 2020;
        const selection = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2021,
        };
        const spy = spyOn(component, 'updateShippingTimeInAllBidsForSameSelection');
        const validationSpy = spyOn(component, 'validateBids').and.callThrough();
        const defaultSpy = spyOn(component, 'checkAndSetDefaultShipTime').and.callThrough();
        component.handleSelectionShipTimeChange(selection, 'coordinationJobShipQuarter');
        expect(spy).toHaveBeenCalled();
        expect(validationSpy).toHaveBeenCalled();
        expect(defaultSpy).toHaveBeenCalled();
    });

    it('should not call updateShippingTimeInAllBidsForSameSelection if changed ship quarter is invalid', () => {
        component.isReadOnly = false;
        const selection = {
            coordinationJobShipQuarter: 0,
            coordinationJobShipYear: 2020,
        };
        const spy = spyOn(component, 'updateShippingTimeInAllBidsForSameSelection');
        const validationSpy = spyOn(component, 'validateBids').and.callThrough();
        component.handleSelectionShipTimeChange(selection, 'coordinationJobShipQuarter');
        expect(spy).not.toHaveBeenCalled();
        expect(validationSpy).toHaveBeenCalled();
    });

    it('should not call updateShippingTimeInAllBidsForSameSelection if component is read only', () => {
        component.isReadOnly = true;
        const selection = {
            coordinationJobShipQuarter: 3,
            coordinationJobShipYear: 2021,
        };
        const spy = spyOn(component, 'updateShippingTimeInAllBidsForSameSelection');
        component.handleSelectionShipTimeChange(selection, 'coordinationJobShipQuarter');
        expect(spy).not.toHaveBeenCalled();
    });

    it('should update same selections in all the bids when ship quarter is changed in a selection', () => {
        const bomBid1 = {
            items: [{
                prodFamilyId: 2006347,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2020,
            },
            {
                prodFamilyId: 2006348,
                coordinationJobShipQuarter: 2,
                coordinationJobShipYear: 2020,
            }],
        };
        const bomBid2 = {
            items: [{
                prodFamilyId: 2006348,
                coordinationJobShipQuarter: 2,
                coordinationJobShipYear: 2020,
            }],
        };
        component.bomData = [bomBid1, bomBid2];
        const selection = {
            prodFamilyId: 2006348,
            coordinationJobShipQuarter: 4,
            coordinationJobShipYear: 2020,
        };
        component.updateShippingTimeInAllBidsForSameSelection(selection, 'coordinationJobShipQuarter');
        expect(bomBid1.items[1].coordinationJobShipQuarter).toBe(selection.coordinationJobShipQuarter);
        expect(bomBid2.items[0].coordinationJobShipQuarter).toBe(selection.coordinationJobShipQuarter);
        expect(bomBid1.items[0].coordinationJobShipQuarter).toBe(1);
    });

    it('should update ship time in selection of a new bid if same selection is present in existing bid', () => {
        const testSelections = [
            { description: 'Product A', prodFamilyId: 41, coordinationJobShipQuarter: 3, coordinationJobShipYear: 2021 },
            { description: 'Product B', prodFamilyId: 42, coordinationJobShipQuarter: 2, coordinationJobShipYear: 2020 },
        ] as ISelection[];
        const testBids = [{ bidAlternateId: 456, bidName: 'Base bid', selections: testSelections }] as IBidSelections[];
        component.bids = testBids;
        const testNewSelections = [
            { description: 'Product A', prodFamilyId: 41, coordinationJobShipQuarter: 1, coordinationJobShipYear: 2020 },
            { description: 'Product C', prodFamilyId: 43, coordinationJobShipQuarter: 4, coordinationJobShipYear: 2022 },
        ] as ISelection[];
        const testNewBids = [{ bidAlternateId: 789, bidName: 'Alt bid', selections: testNewSelections }] as IBidSelections[];
        component.updateShippingTimeInSelections(testNewBids);
        expect(testNewSelections[0].coordinationJobShipQuarter).toBe(3);
        expect(testNewSelections[0].coordinationJobShipYear).toBe(2021);
        expect(testNewSelections[1].coordinationJobShipQuarter).toBe(4);
        expect(testNewSelections[1].coordinationJobShipYear).toBe(2022);
    });

    it('should not update ship time in selection of a new bid if same selection present in existing bid has no shipping time', () => {
        const testSelections = [
            { description: 'Product A', prodFamilyId: 41, coordinationJobShipQuarter: 0, coordinationJobShipYear: 0 },
        ] as ISelection[];
        const testBids = [{ bidAlternateId: 456, bidName: 'Base bid', selections: testSelections }] as IBidSelections[];
        component.bids = testBids;
        const testNewSelections = [
            { description: 'Product A', prodFamilyId: 41, coordinationJobShipQuarter: 1, coordinationJobShipYear: 2020 },
        ] as ISelection[];
        const testNewBids = [{ bidAlternateId: 789, bidName: 'Alt bid', selections: testNewSelections }] as IBidSelections[];
        component.updateShippingTimeInSelections(testNewBids);
        expect(testNewSelections[0].coordinationJobShipQuarter).toBe(1);
        expect(testNewSelections[0].coordinationJobShipYear).toBe(2020);
    });

    it('should add new bidId to bidsInFlight when getNewBidIds is called', () => {
        component.bids = [{ bidAlternateId: 123, bidName: 'Base bid', selections: [] },
        { bidAlternateId: 456, bidName: 'Rebid', selections: [] }] as IBidSelections[];
        component.bidIds = [123, 456, 789];
        component.getNewBidIds();
        expect(component.bidsInFlight).toEqual([789]);
    });

    it('should not add bidId to new bidIds, if that bidId is already in flight', () => {
        component.bids = [{ bidAlternateId: 123, bidName: 'Base bid', selections: [] }] as IBidSelections[];
        component.bidsInFlight = [456];
        component.bidIds = [123, 456, 789];
        const newBidIds = component.getNewBidIds();
        expect(newBidIds.length).toBe(1);
        expect(newBidIds[0]).toBe(789);
        expect(component.bidsInFlight.length).toBe(2);
        expect(component.bidsInFlight[1]).toBe(789);
    });

    it('should not add bid to list if the bidId is not present', () => {
        component.bids = [];
        component.bidIds = [456];
        const testBids = [{ bidAlternateId: 123, bidName: 'Base bid', selections: [] },
        { bidAlternateId: 456, bidName: 'Rebid', selections: [] }] as IBidSelections[];
        component.addBidsToList(testBids);
        expect(component.bids.length).toBe(1);
        expect(component.bids[0].bidAlternateId).toBe(456);
    });

    it(`should set the pastTimeSelection flag to true when past ship year is selected
    or when current ship year and past ship quarter is selected`, () => {
        component.currentQuarter = 4;
        component.currentYear = 2019;
        component.isReadOnly = false;
        const selection = {
            coordinationJobShipQuarter: 4,
            coordinationJobShipYear: 2018,
            pastTimeSelection: false,
        };
        const spy = spyOn(component, 'updateShippingTimeInAllBidsForSameSelection');
        component.handleSelectionShipTimeChange(selection, 'coordinationJobShipQuarter');
        expect(spy).not.toHaveBeenCalled();
        expect(selection.pastTimeSelection).toBe(true);
        selection.coordinationJobShipQuarter = 3;
        selection.coordinationJobShipYear = 2019;
        selection.pastTimeSelection = false;
        component.handleSelectionShipTimeChange(selection, 'coordinationJobShipQuarter');
        expect(spy).not.toHaveBeenCalled();
        expect(selection.pastTimeSelection).toBe(true);
    });

    it('should set the pastTimeSelection flag to false when future year is selected', () => {
        component.isReadOnly = false;
        const selection = {
            coordinationJobShipQuarter: 2,
            coordinationJobShipYear: 2100,
            pastTimeSelection: true,
        };
        const spy = spyOn(component, 'updateShippingTimeInAllBidsForSameSelection');
        component.handleSelectionShipTimeChange(selection, 'coordinationJobShipQuarter');
        expect(spy).toHaveBeenCalled();
        expect(selection.pastTimeSelection).toBe(false);
    });

    it('should set the globalInvalidSelection flag to true when past globalShipQuarter and globalShipYear is selected', () => {
        component.isReadOnly = false;
        component.globalShipQuarter = 1;
        component.globalShipYear = 2000;
        component.handleGlobalSelectionShipTimeChange();
        expect(component.globalInvalidSelection).toBe(true);
    });

    it('should not update ship quarter and year for all the selections when globalInvalidSelection is true', () => {
        component.globalInvalidSelection = true;
        component.globalShipQuarter = 1;
        component.globalShipYear = 2000;
        component.bomData = [testBomBid1];
        component.updateShippingTimeForAllSelections();
        expect(component.bomData[0].items[0].coordinationJobShipQuarter).toBe(1);
        expect(component.bomData[0].items[0].coordinationJobShipYear).toBe(2020);
    });

    it('should set isEdited to true when competitor field is edited', () => {
        component.isReadOnly = false;
        component.isEdited = false;
        component.handleCompetitorChange();
        expect(component.isEdited).toBe(true);
    });

    it('should set isEdited to true when who is specified field is edited', () => {
        component.isReadOnly = false;
        component.isEdited = false;
        component.handleSpecifiedUserChange();
        expect(component.isEdited).toBe(true);
    });

    it('should set isEdited to true when bids are changed in bom section', () => {
        component.isReadOnly = false;
        component.isEdited = false;
        component.bids = [{ bidAlternateId: 123, bidName: 'Base bid', selections: [] }] as IBidSelections[];
        const newBidIds = [123, 456];
        component.bidIds = newBidIds;
        component.bidsChanged = true;
        const bidIdsChange: SimpleChange = { currentValue: newBidIds, isFirstChange: () => false } as SimpleChange;
        const bidsChange: SimpleChange = { currentValue: true } as SimpleChange;
        component.ngOnChanges({ bidIds: bidIdsChange, bidsChanged: bidsChange });
        expect(component.isEdited).toBe(true);
    });

    it('should set the pastTimeSelection flag to true when ship quarter and ship year is in past during auto save', () => {
        component.isReadOnly = false;
        component.isEdited = true;
        testBid = [{
            bidAlternateId: 13,
            selections: [{
                prodFamilyId: 2006347,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2000,
                pastTimeSelection: false,
            }],
        }];
        component.bids = testBid;
        component.saveData();
        expect(testBid[0].selections[0].pastTimeSelection).toBe(true);
    });

    it('should set the pastTimeSelection flag to false when there is valid ship quarter and ship year is selected during auto save', () => {
        component.isReadOnly = false;
        component.isEdited = true;
        testBid = [{
            bidAlternateId: 13,
            selections: [{
                prodFamilyId: 2006347,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2100,
                pastTimeSelection: false,
            }],
        }];
        component.bids = testBid;
        component.saveData();
        expect(testBid[0].selections[0].pastTimeSelection).toBe(false);
    });

    it('should emit event when saveData method is called', () => {
        component.isReadOnly = false;
        component.isEdited = true;
        testBid = [{
            bidAlternateId: 13,
            selections: [{
                bidAlternateId: 13,
                prodFamilyId: 2006347,
                coordinationJobShipQuarter: 0,
                coordinationJobShipYear: 0,
                pastTimeSelection: false,
                selectionSource: 'C',
            },
            {
                bidAlternateId: 13,
                prodFamilyId: 2006348,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2100,
                pastTimeSelection: false,
                selectionSource: 'C',
            },
            {
                bidAlternateId: 13,
                prodFamilyId: 2006349,
                coordinationJobShipQuarter: 0,
                coordinationJobShipYear: 0,
                pastTimeSelection: false,
                selectionSource: 'N',
            },
            {
                bidAlternateId: 13,
                prodFamilyId: 2006350,
                coordinationJobShipQuarter: 0,
                coordinationJobShipYear: 0,
                pastTimeSelection: false,
                doesSeparatelyBiddableSelectionsExist: true,
            },
            ],
        }];
        const data = [{
            bidAlternateId: 13,
            prodFamilyId: 2006348,
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2100,
            pastTimeSelection: false,
            selectionSource: 'C',
        },
        {
            bidAlternateId: 13,
            prodFamilyId: 2006349,
            coordinationJobShipQuarter: 0,
            coordinationJobShipYear: 0,
            pastTimeSelection: false,
            selectionSource: 'N',
        },
        {
            bidAlternateId: 13,
            prodFamilyId: 2006350,
            coordinationJobShipQuarter: 0,
            coordinationJobShipYear: 0,
            pastTimeSelection: false,
            doesSeparatelyBiddableSelectionsExist: true,
        },
        ];
        component.bids = testBid;
        const spy = spyOn(component.save, 'emit');
        component.saveData();
        expect(spy).toHaveBeenCalledWith(data);
    });

    it('should not emit event if the component is read only', () => {
        component.isReadOnly = true;
        component.isEdited = true;
        testBid = [{
            bidAlternateId: 13,
            selections: [{
                bidAlternateId: 13,
                prodFamilyId: 2006347,
                coordinationJobShipQuarter: 0,
                coordinationJobShipYear: 0,
                pastTimeSelection: false,
            },
            {
                bidAlternateId: 13,
                prodFamilyId: 2006348,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2100,
                pastTimeSelection: false,
            },
            ],
        }];
        component.bids = testBid;
        spyOn(component.save, 'emit');
        component.handleFocusChange({ target: document.getRootNode() });
        expect(component.save.emit).not.toHaveBeenCalled();
    });

    it('should not emit event if the component is not edited', () => {
        component.isReadOnly = false;
        component.isEdited = false;
        testBid = [{
            bidAlternateId: 13,
            selections: [{
                bidAlternateId: 13,
                prodFamilyId: 2006347,
                coordinationJobShipQuarter: 0,
                coordinationJobShipYear: 0,
                pastTimeSelection: false,
            },
            {
                bidAlternateId: 13,
                prodFamilyId: 2006348,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2100,
                pastTimeSelection: false,
            },
            ],
        }];
        component.bids = testBid;
        spyOn(component.save, 'emit');
        component.handleFocusChange({ target: document.getRootNode() });
        expect(component.save.emit).not.toHaveBeenCalled();
    });

    it('should update oldShipYear when the coordinationJobShipYear is in past', () => {
        component.isReadOnly = false;
        component.currentYear = 2020;
        const testSelections = [{ description: 'Product A', coordinationJobShipQuarter: 2, coordinationJobShipYear: 1998 },
        { description: 'Product A', coordinationJobShipQuarter: 2, coordinationJobShipYear: 2021 }] as ISelection[];
        const testBids = [{ bidAlternateId: 456, bidName: 'Base bid', selections: testSelections }] as IBidSelections[];
        component.updateSelections(testBids);
        expect(testBids[0].selections[0].oldShipYear).toBe(testBids[0].selections[0].coordinationJobShipYear);
        expect(testBids[0].selections[1].oldShipYear).not.toBe(testBids[0].selections[1].coordinationJobShipYear);
    });

    it('should set valid flag to false when bids have past time selections', () => {
        const testBids: any = [{
            bidAlternateId: 13,
            selections: [{
                prodFamilyId: 2406347,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2019,
                pastTimeSelection: false,
                selectionSource: 'C',
            }],
        }];
        component.bids = testBids;
        const spy = spyOn(validationService, 'setBomDateValidFlag');
        component.validateBids();
        expect(component.bids[0].selections[0]['pastTimeSelection']).toBe(true);
        expect(spy).toHaveBeenCalledWith(false);
    });

    it('should ignore validations if the selection is not configured when it have past time selections', () => {
        const testBids: IBidSelections[] = [{
            bidAlternateId: 13,
            selections: [{
                prodFamilyId: 2406347,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2019,
                selectionSource: 'N',
            } as ISelection],
        }] as IBidSelections[];
        component.bids = testBids;
        const spy = spyOn(validationService, 'setBomDateValidFlag');
        component.validateBids();
        expect(spy).toHaveBeenCalledWith(true);
    });

    it('should ignore validations if the bid has separate biddable selections and the ship time is in past', () => {
        const testBids: IBidSelections[] = [{
            bidAlternateId: 13,
            selections: [{
                prodFamilyId: 2406347,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2019,
                doesSeparatelyBiddableSelectionsExist: true,
            } as ISelection],
        }] as IBidSelections[];
        component.bids = testBids;
        const spy = spyOn(validationService, 'setBomDateValidFlag');
        component.validateBids();
        expect(spy).toHaveBeenCalledWith(true);
    });

    it('should set valid flag to false when bids have selections with out shipping time', () => {
        component.currentYear = 2020;
        const testBids: any = [{
            bidAlternateId: 14,
            selections: [{
                prodFamilyId: 2406348,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2021,
                pastTimeSelection: false,
                selectionSource: 'C',
            },
            {
                prodFamilyId: 2406349,
                coordinationJobShipQuarter: 0,
                coordinationJobShipYear: 0,
                pastTimeSelection: false,
                selectionSource: 'C',
            }],
        }];
        component.bids = testBids;
        const spy = spyOn(validationService, 'setBomDateSetFlag');
        component.validateBids();
        expect(component.bids[0].selections[0]['pastTimeSelection']).toBe(false);
        expect(spy).toHaveBeenCalledWith(false);
    });

    it('should set valid flag to true when bids have valid selections', () => {
        component.currentYear = 2020;
        const testBids: any = [{
            bidAlternateId: 15,
            selections: [{
                prodFamilyId: 2406350,
                coordinationJobShipQuarter: 3,
                coordinationJobShipYear: 2022,
                pastTimeSelection: false,
            },
            {
                prodFamilyId: 2406351,
                coordinationJobShipQuarter: 4,
                coordinationJobShipYear: 2021,
                pastTimeSelection: false,
            }],
        }];
        component.bids = testBids;
        const spyDateSet = spyOn(validationService, 'setBomDateSetFlag');
        const spyDateValid = spyOn(validationService, 'setBomDateValidFlag');
        component.validateBids();
        expect(spyDateSet).toHaveBeenCalledWith(true);
        expect(spyDateValid).toHaveBeenCalledWith(true);
    });

    it('should call setValidShipLeadTimeFlag method with true if there are no errors', () => {
        component.shippingLeadTimeValidations = [{ prodFamilyId: 123, isValidShippingLeadTime: true }];
        const errorsSpy = spyOn(component, 'setShipLeadTimeErrorsInSelections').and.callThrough();
        component.validateShipLeadTime();
        expect(errorsSpy).toHaveBeenCalled();
    });

    it('should call setValidShipLeadTimeFlag method with false if there are ship lead time errors', () => {
        component.shippingLeadTimeValidations = [{ prodFamilyId: 123, isValidShippingLeadTime: false }];
        const errorsSpy = spyOn(component, 'setShipLeadTimeErrorsInSelections').and.callThrough();
        component.validateShipLeadTime();
        expect(errorsSpy).toHaveBeenCalled();
    });

    it('should call setValidShipLeadTimeFlag method with false if there are selection errors', () => {
        component.shippingLeadTimeValidations = [{
            prodFamilyId: 123,
            isValidShippingLeadTime: true,
            selectionErrors: ['test selection error'],
        }];
        const errorsSpy = spyOn(component, 'setShipLeadTimeErrorsInSelections').and.callThrough();
        component.validateShipLeadTime();
        expect(errorsSpy).toHaveBeenCalled();
    });

    it('should set validation errors in selections when setShipLeadTimeErrorsInSelections is called', () => {
        const testBids: any = [{
            bidAlternateId: 15,
            selections: [{
                prodFamilyId: 2408350,
                coordinationJobShipQuarter: 4,
                coordinationJobShipYear: 2021,
                pastTimeSelection: false,
                selectionSource: 'N',
            },
            {
                prodFamilyId: 2408351,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2022,
                pastTimeSelection: false,
                selectionSource: 'C',
            },
            {
                prodFamilyId: 2408352,
                coordinationJobShipQuarter: 3,
                coordinationJobShipYear: 2022,
                pastTimeSelection: false,
                selectionSource: 'C',
            },
            ],
        }];
        component.bids = testBids;
        const testSelectionErrors = ['test error 1', 'test error 2'];
        const testValidationErrors = [{
            productFamilyId: 2408350,
            isValidShippingLeadTime: false,
            selectionErrors: [],
        },
        {
            productFamilyId: 2408351,
            isValidShippingLeadTime: true,
            selectionErrors: testSelectionErrors,
        },
        {
            productFamilyId: 2408352,
            isValidShippingLeadTime: false,
            selectionErrors: [],
        },
        ];
        const spy = spyOn(component, 'updateErrorAndWarningIndicators').and.callThrough();
        const validationSpy = spyOn(validationService, 'setValidShipLeadTimeFlag');
        const errorSpy = spyOn(validationService, 'setHasSelectionErrors');
        component.setShipLeadTimeErrorsInSelections(testValidationErrors);
        expect(component.bids[0].selections[0].selectionErrors).toEqual([]);
        expect(component.bids[0].selections[0].isValidShippingLeadTime).toBe(true);
        expect(component.bids[0].selections[1].selectionErrors).toEqual(testSelectionErrors);
        expect(component.bids[0].selections[1].isValidShippingLeadTime).toBe(true);
        expect(component.bids[0].selections[2].selectionErrors).toEqual([]);
        expect(component.bids[0].selections[2].isValidShippingLeadTime).toBe(false);
        expect(spy).toHaveBeenCalledTimes(2);
        expect(validationSpy).toHaveBeenCalledWith(false);
        expect(errorSpy).toHaveBeenCalledWith(true);
    });

    it('should call setHasSelectionErrors with true when selection errors are present', () => {
        const testBids: any = [{
            bidAlternateId: 15,
            selections: [{
                prodFamilyId: 2408351,
                coordinationJobShipQuarter: 1,
                coordinationJobShipYear: 2022,
                pastTimeSelection: false,
                selectionSource: 'C',
            }],
        }];
        component.bids = testBids;
        const testSelectionErrors = ['test error 1', 'test error 2'];
        const testValidationErrors = [
            {
                productFamilyId: 2408351,
                isValidShippingLeadTime: true,
                selectionErrors: testSelectionErrors,
            }];
        const validationSpy = spyOn(validationService, 'setValidShipLeadTimeFlag');
        const errorSpy = spyOn(validationService, 'setHasSelectionErrors');
        component.setShipLeadTimeErrorsInSelections(testValidationErrors);
        expect(validationSpy).toHaveBeenCalledWith(false);
        expect(errorSpy).toHaveBeenCalledWith(true);
    });

    it('should call setHasSelectionErrors with false when selection errors are not present', () => {
        const testBids: any = [{
            bidAlternateId: 15,
            selections: [{
                prodFamilyId: 2408352,
                coordinationJobShipQuarter: 3,
                coordinationJobShipYear: 2022,
                pastTimeSelection: false,
                selectionSource: 'C',
            }],
        }];
        component.bids = testBids;
        const testValidationErrors = [{
            productFamilyId: 2408352,
            isValidShippingLeadTime: false,
            selectionErrors: [],
        }];
        const validationSpy = spyOn(validationService, 'setValidShipLeadTimeFlag');
        const errorSpy = spyOn(validationService, 'setHasSelectionErrors');
        component.setShipLeadTimeErrorsInSelections(testValidationErrors);
        expect(validationSpy).toHaveBeenCalledWith(false);
        expect(errorSpy).toHaveBeenCalledWith(false);
    });

    it('should call validateShipLeadTime method when validateBids method is called', () => {
        const testBidIds = [123, 456];
        component.bidIds = testBidIds;
        component.shippingLeadTimeValidations = [{ prodFamilyId: 123, isValidShippingLeadTime: false }];
        const spy = spyOn(component, 'validateShipLeadTime').and.callThrough();
        component.validateBids();
        expect(spy).toHaveBeenCalled();
    });

    it('should call validateShipLeadTime when input shippingLeadTimeValidations are changed', () => {
        const newBidIds = [567, 678];
        component.bidIds = newBidIds;
        const testShippingLeadTimeValidations = [{ prodFamilyId: 123, isValidShippingLeadTime: false }];
        component.shippingLeadTimeValidations = testShippingLeadTimeValidations;
        const shipTimeValidationChange: SimpleChange = { currentValue: testShippingLeadTimeValidations } as SimpleChange;
        const spy = spyOn(component, 'validateShipLeadTime').and.callThrough();
        component.ngOnChanges({ shippingLeadTimeValidations: shipTimeValidationChange });
        expect(spy).toHaveBeenCalled();
    });

    it('should set error and warning flags for selection with past time exceptions when job is not coordinated before', () => {
        const selectionPastTime: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2019,
            pastTimeSelection: true,
            isValidShippingLeadTime: true,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(false);
        component.updateErrorAndWarningIndicators(selectionPastTime);
        expect(selectionPastTime.error).toBe(true);
        expect(selectionPastTime.warning).toBe(false);
        expect(selectionPastTime.showQuarterIcon).toBe(true);
        expect(selectionPastTime.showYearIcon).toBe(true);
        expect(selectionPastTime.quarterClass).toBe(errorClass);
        expect(selectionPastTime.yearClass).toBe(errorClass);
    });

    it('should set error and warning flags for selection with invalid ship lead time, when job is not coordinated before', () => {
        const selectionInvalidShipLeadTime: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2021,
            pastTimeSelection: false,
            isValidShippingLeadTime: false,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(false);
        component.updateErrorAndWarningIndicators(selectionInvalidShipLeadTime);
        expect(selectionInvalidShipLeadTime.error).toBe(true);
        expect(selectionInvalidShipLeadTime.warning).toBe(false);
        expect(selectionInvalidShipLeadTime.showQuarterIcon).toBe(true);
        expect(selectionInvalidShipLeadTime.showYearIcon).toBe(true);
        expect(selectionInvalidShipLeadTime.quarterClass).toBe(errorClass);
        expect(selectionInvalidShipLeadTime.yearClass).toBe(errorClass);
    });
    it('should set error and warning flags for selection with errors, when job is not coordinated before', () => {
        const selectionWithErrors: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2021,
            pastTimeSelection: false,
            isValidShippingLeadTime: true,
            selectionErrors: ['test error'],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(false);
        component.updateErrorAndWarningIndicators(selectionWithErrors);
        expect(selectionWithErrors.error).toBe(true);
        expect(selectionWithErrors.warning).toBe(false);
        expect(selectionWithErrors.showQuarterIcon).toBe(true);
        expect(selectionWithErrors.showYearIcon).toBe(true);
        expect(selectionWithErrors.quarterClass).toBe(errorClass);
        expect(selectionWithErrors.yearClass).toBe(errorClass);
    });
    it('should set error and warning flags for valid selection, when job is not coordinated before', () => {
        const validSelection: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2021,
            pastTimeSelection: false,
            isValidShippingLeadTime: true,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(false);
        component.updateErrorAndWarningIndicators(validSelection);
        expect(validSelection.error).toBe(false);
        expect(validSelection.warning).toBe(false);
        expect(validSelection.showQuarterIcon).toBe(false);
        expect(validSelection.showYearIcon).toBe(false);
        expect(validSelection.quarterClass).toBe('');
        expect(validSelection.yearClass).toBe('');
    });

    it('should set error and warning flags for selection with past time exceptions when job is coordinated before', () => {
        const selectionPastTime: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2019,
            pastTimeSelection: true,
            isValidShippingLeadTime: true,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(true);
        component.updateErrorAndWarningIndicators(selectionPastTime);
        expect(selectionPastTime.error).toBe(true);
        expect(selectionPastTime.warning).toBe(false);
        expect(selectionPastTime.showQuarterIcon).toBe(true);
        expect(selectionPastTime.showYearIcon).toBe(true);
        expect(selectionPastTime.quarterClass).toBe(errorClass);
        expect(selectionPastTime.yearClass).toBe(errorClass);
    });

    it('should set error and warning flags for selection with invalid ship lead time, when job is coordinated before', () => {
        const selectionInvalidShipLeadTime: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2021,
            pastTimeSelection: false,
            isValidShippingLeadTime: false,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(true);
        component.updateErrorAndWarningIndicators(selectionInvalidShipLeadTime);
        expect(selectionInvalidShipLeadTime.error).toBe(false);
        expect(selectionInvalidShipLeadTime.warning).toBe(true);
        expect(selectionInvalidShipLeadTime.showQuarterIcon).toBe(true);
        expect(selectionInvalidShipLeadTime.showYearIcon).toBe(true);
        expect(selectionInvalidShipLeadTime.quarterClass).toBe(warningClass);
        expect(selectionInvalidShipLeadTime.yearClass).toBe(warningClass);
    });
    it('should set error and warning flags for selection with errors, when job is coordinated before', () => {
        const selectionWithErrors: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2021,
            pastTimeSelection: false,
            isValidShippingLeadTime: true,
            selectionErrors: ['test error'],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(true);
        component.updateErrorAndWarningIndicators(selectionWithErrors);
        expect(selectionWithErrors.error).toBe(true);
        expect(selectionWithErrors.warning).toBe(false);
        expect(selectionWithErrors.showQuarterIcon).toBe(true);
        expect(selectionWithErrors.showYearIcon).toBe(true);
        expect(selectionWithErrors.quarterClass).toBe(errorClass);
        expect(selectionWithErrors.yearClass).toBe(errorClass);
    });
    it('should set error and warning flags for valid selection, when job is coordinated before', () => {
        const validSelection: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2021,
            pastTimeSelection: false,
            isValidShippingLeadTime: true,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(true);
        component.updateErrorAndWarningIndicators(validSelection);
        expect(validSelection.error).toBe(false);
        expect(validSelection.warning).toBe(false);
        expect(validSelection.showQuarterIcon).toBe(false);
        expect(validSelection.showYearIcon).toBe(false);
        expect(validSelection.quarterClass).toBe('');
        expect(validSelection.yearClass).toBe('');
    });

    it('should set error and warning flags for selection with invalid ship quarter when job is not coordinated before', () => {
        const selectionInvalidShipQuarter: any = {
            coordinationJobShipQuarter: 0,
            coordinationJobShipYear: 2019,
            pastTimeSelection: false,
            isValidShippingLeadTime: true,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(false);
        component.updateErrorAndWarningIndicators(selectionInvalidShipQuarter);
        expect(selectionInvalidShipQuarter.error).toBe(false);
        expect(selectionInvalidShipQuarter.warning).toBe(false);
        expect(selectionInvalidShipQuarter.showQuarterIcon).toBe(true);
        expect(selectionInvalidShipQuarter.showYearIcon).toBe(false);
        expect(selectionInvalidShipQuarter.quarterClass).toBe(errorClass);
        expect(selectionInvalidShipQuarter.yearClass).toBe('');
    });

    it('should set error and warning flags for selection with invalid ship year when job is not coordinated before', () => {
        const selectionInvalidShipYear: any = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 0,
            pastTimeSelection: false,
            isValidShippingLeadTime: true,
            selectionErrors: [],
        };
        spyOn(validationService, 'getHasBeenPreviouslyCoordinatedFlag').and.returnValue(false);
        component.updateErrorAndWarningIndicators(selectionInvalidShipYear);
        expect(selectionInvalidShipYear.error).toBe(false);
        expect(selectionInvalidShipYear.warning).toBe(false);
        expect(selectionInvalidShipYear.showQuarterIcon).toBe(false);
        expect(selectionInvalidShipYear.showYearIcon).toBe(true);
        expect(selectionInvalidShipYear.quarterClass).toBe('');
        expect(selectionInvalidShipYear.yearClass).toBe(errorClass);
    });

    it('should calculate quarter based on the month when calculateQuarter is called', () => {
        expect(component.calculateQuarter(0)).toBe(1);
        expect(component.calculateQuarter(3)).toBe(2);
        expect(component.calculateQuarter(6)).toBe(3);
        expect(component.calculateQuarter(9)).toBe(4);
    });

    it('should ignore past time validation when selection is not configured', () => {
        const selection = {
            coordinationJobShipQuarter: 1,
            coordinationJobShipYear: 2019,
        } as ISelection;
        component.checkAndSetDefaultShipTime(selection);
        expect(selection.displayPastTimeError).toBe(false);
    });
});
