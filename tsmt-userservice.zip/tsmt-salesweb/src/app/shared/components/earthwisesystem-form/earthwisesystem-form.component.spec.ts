import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormArray, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { IEarthwiseSystemModel } from '../../../modules/jobs-list-master/modal/job-details-edit.model';
import { JobEditSaveService, JobSaveFormType } from '../../../modules/jobs-list-master/services/jobeditsave.service';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { LoaderService } from '../../../shared/services/loader.service';
import { ApiErrorService } from '../../services/apierror.service';
import { ApiErrorServiceMock } from './../../test-mocks/apierrorservice-mock';
import { JobEditServiceMock } from './../../test-mocks/editjobservice-mock';
import { EarthwiseSystemFormComponent } from './earthwisesystem-form.component';

describe('EarthwiseSystemFormComponent', () => {
  let component: EarthwiseSystemFormComponent;
  let fixture: ComponentFixture<EarthwiseSystemFormComponent>;
  let jobService: JobsServicesService;
  let injector: TestBed;
  let apiErrorService: ApiErrorService;
  const originReset = TestBed.resetTestingModule;
  const formData: IEarthwiseSystemModel = {
    sysTypeId: 1,
    description: 'Trane Ice-enhanced Air-cooled Chiller Plant',
    multiSelect: '',
    seqNbr: 1,
    isChecked: false,
    toolTip: 'Trane Ice-enhanced Air-cooled Chiller Plant',
  };

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [EarthwiseSystemFormComponent],
      providers: [{ provide: JobsServicesService, useClass: JobEditServiceMock },
        HttpClient, HttpHandler, JobEditSaveService, LoaderService, ApiErrorService, {
        provide: ActivatedRoute, useValue: {
          snapshot: { params: { jobId: 12, drAddressId: 121 } },
        },
      }],
      schemas: [NO_ERRORS_SCHEMA],
    });
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(EarthwiseSystemFormComponent);
    component = fixture.componentInstance;
    component.formData = formData;
    component.earthwiseSystemOptions = [
      { sysTypeId: 1, description: 'No System', multiSelect: 'N', seqNbr: 0, isChecked: false, toolTip: 'No System' },
      {
        sysTypeId: 13, description: 'Trane CoolSense™ Integrated Outdoor Air System', multiSelect: 'Y', seqNbr: 0,
        isChecked: false, toolTip: 'Includes CoolSense terminals, ',
      },
      {
        sysTypeId: 14, description: 'Trane Zoned Rooftop System (ZRS)', multiSelect: 'Y',
        seqNbr: 0, isChecked: false, toolTip: 'Includes Precedent or Voyager II rooftop(s)',
      }];
    component.earthwiseSystemFormData = component.earthwiseSystemOptions;
    component.checkboxes = component.earthwiseSystemOptions.map((chbox) =>
      new FormControl(false),
    );
    component.earthwiseSystemData = formData;
    component.editJobEarthwiseSystemForm = new FormGroup({
      earthwiseSystemOptions: new FormArray(component.checkboxes),
    });
    jobService = injector.inject(JobsServicesService);
    apiErrorService = injector.inject(ApiErrorService);
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should assign job id and dr address when calling ngOnInit', () => {
    const testJobId = 12;
    const drAddressId = 121;
    component.ngOnInit();
    expect(component.jobId).toBe(testJobId);
    expect(component.drAddressId).toBe(drAddressId);
  });
  it('should create checkboxes controls emit form and index on calling ngOnChanges', () => {
    const spyFormUpdate = spyOn(component.formUpdate, 'emit');
    component.ngOnChanges();
    expect(component.checkboxes.length).toBeGreaterThan(0);
    expect(component.checkboxes[0].value).toBe(false);
    expect(spyFormUpdate).toHaveBeenCalledWith({
      form: component.editJobEarthwiseSystemForm,
      index: JobSaveFormType.EarthwiseForm, options: component.earthwiseSystemOptions,
    });
  });
  it('should initialise the editJobEarthwiseSystemForm on ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.editJobEarthwiseSystemForm.controls['earthwiseSystemOptions']).toBeDefined();
    expect(((component.editJobEarthwiseSystemForm.controls['earthwiseSystemOptions']) as FormArray).length).toBeGreaterThan(0);
  });
  it('should initialise the form controls with earthwiseSystemData on calling setFormValues', () => {
    component.ngOnChanges();
    component.checkboxes = component.earthwiseSystemOptions.map((chbox) =>
      new FormControl(chbox.isChecked),
    );
    component.editJobEarthwiseSystemForm = new FormGroup({
      earthwiseSystemOptions: new FormArray(component.checkboxes),
    });
    component.earthwiseSystemData = component.formData;
    expect(((component.editJobEarthwiseSystemForm.controls['earthwiseSystemOptions']) as FormArray).length).toBeGreaterThan(0);

  });

  it('should mouse over show the text to the user as multiline with string more than 50 characters', () => {
    const dataitem = 'This is a test for text having characters more than Seventy Five characters';
    component.splitToolTip(dataitem);
    expect(component.toolTipText).toBe(dataitem);
    expect(component.toolTipLength).toBe(400);
  });

  it('should mouse over show the text to the user with string less than 50 characters', () => {
    const dataitem = 'This is a test';
    component.splitToolTip(dataitem);
    expect(component.toolTipText).toBe(dataitem);
    expect(component.toolTipLength).toBe(null);
  });

  it('should emit form and index on after view ngOnChanges', () => {
    component.formUpdate.subscribe((val) => {
      expect(val.form).toBe(component.editJobEarthwiseSystemForm);
      expect(val.index).toBe(10);
    });
  });

  it('should check all checkbox unchecked when select no system checkbox ', () => {
    component.earthwiseSystemOptions = [
      { sysTypeId: 1, description: 'No System', multiSelect: 'N', seqNbr: 0, isChecked: false, toolTip: 'No System' }];
    component.checkboxes = component.earthwiseSystemOptions.map(() =>
      new FormControl(false),
    );
    component.editJobEarthwiseSystemForm = new FormGroup({
      earthwiseSystemOptions: new FormArray(component.checkboxes),
    });
    const controls = ((component.editJobEarthwiseSystemForm.controls['earthwiseSystemOptions']) as FormArray).controls;
    component.checkNoSystem({ target: { value: '1' } });
    expect(controls[0].value).toBe(true);
  });

  it('should check no system checkbox unchecked when select other checkbox ', () => {
    component.earthwiseSystemOptions = [
      {
        sysTypeId: 13, description: 'Trane CoolSense™ Integrated Outdoor Air System', multiSelect: 'Y', seqNbr: 0,
        isChecked: false, toolTip: 'Includes CoolSense terminals, ',
      }];
    component.checkboxes = component.earthwiseSystemOptions.map(() =>
      new FormControl(false),
    );
    component.editJobEarthwiseSystemForm = new FormGroup({
      earthwiseSystemOptions: new FormArray(component.checkboxes),
    });
    const controls = ((component.editJobEarthwiseSystemForm.controls['earthwiseSystemOptions']) as FormArray).controls;
    component.checkNoSystem({ target: { value: '2' } });
    expect(controls[0].value).toBe(false);
  });
});
