import { Component, EventEmitter, Input, OnChanges, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { IEarthwiseSystemModel } from '../../../modules/jobs-list-master/modal/job-details-edit.model';
import { JobSaveFormType } from '../../../modules/jobs-list-master/services/jobeditsave.service';

@Component({
  selector: 'app-earthwisesystem-form',
  templateUrl: './earthwisesystem-form.component.html',
  styleUrls: ['./earthwisesystem-form.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class EarthwiseSystemFormComponent implements OnInit, OnChanges {

  @Input() formData: IEarthwiseSystemModel;

  editJobEarthwiseSystemForm: FormGroup;
  checkboxes: any;
  earthwiseSystemOptions: any;
  earthwiseSystemData: IEarthwiseSystemModel;
  toolTipLength: number;
  toolTipText: string;
  jobId: number;
  drAddressId: number;
  @Input() public earthwiseSystemFormData: IEarthwiseSystemModel;

  @Output() formUpdate: EventEmitter<any> = new EventEmitter();
  constructor(private fb: FormBuilder, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.jobId = +this.route.snapshot.params['jobId'];
    this.drAddressId = +this.route.snapshot.params['drAddressId'];
  }

  ngOnChanges() {
    this.earthwiseSystemOptions = [];
    this.checkboxes = [];
    this.editJobEarthwiseSystemForm = this.fb.group({
      earthwiseSystemOptions: new FormArray(this.checkboxes),
    });
    if (this.earthwiseSystemFormData) {
      this.earthwiseSystemOptions = JSON.parse(JSON.stringify(this.earthwiseSystemFormData));
      this.checkboxes = this.earthwiseSystemOptions.map((chkbox) =>
        new FormControl(chkbox.isChecked),
      );
      this.editJobEarthwiseSystemForm = this.fb.group({
        earthwiseSystemOptions: new FormArray(this.checkboxes),
      });

      this.formUpdate.emit({
        form: this.editJobEarthwiseSystemForm,
        index: JobSaveFormType.EarthwiseForm, options: this.earthwiseSystemOptions,
      });
    }
  }

  checkNoSystem(e) {
    if (e.target.value === '1') {
      const controls = ((this.editJobEarthwiseSystemForm.controls['earthwiseSystemOptions']) as FormArray).controls;
      controls[0].setValue(true);
      controls.forEach((cont, index) => {
        if (index !== 0) {
          cont.setValue(false);
        }
      });
    } else if (e.target.value !== '1') {
      const controls = ((this.editJobEarthwiseSystemForm.controls['earthwiseSystemOptions']) as FormArray).controls;
      controls[0].setValue(false);
    }
  }

  splitToolTip(dataItem) {
    this.toolTipText = dataItem;
    if (dataItem.length >= 50) {
      this.toolTipLength = 400;
    } else {
      this.toolTipLength = null;
    }
  }
}
