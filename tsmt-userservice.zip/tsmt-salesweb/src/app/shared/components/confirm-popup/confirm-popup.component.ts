import { Component, Input, ViewEncapsulation } from '@angular/core';
import { DialogContentBase, DialogRef } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'app-confirm-popup',
  templateUrl: './confirm-popup.component.html',
  styleUrls: ['./confirm-popup.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ConfirmPopupComponent extends DialogContentBase {
  @Input() title = '';
  @Input() content = '';

  constructor(public dialog: DialogRef) {
    super(dialog);
  }

  onCancelAction() {
    this.dialog.close({text: 'Cancel'});
  }

  onConfirmAction() {
      this.dialog.close();
  }

}
