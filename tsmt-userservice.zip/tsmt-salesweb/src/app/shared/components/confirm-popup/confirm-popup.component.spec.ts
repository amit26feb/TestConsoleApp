import { DebugElement } from '@angular/core';
import { ComponentFixture, fakeAsync, getTestBed, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DialogRef, DialogsModule } from '@progress/kendo-angular-dialog';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { ConfirmPopupComponent } from './confirm-popup.component';

class DialogMock {
  close() {
    return;
  }
}

describe('ConfirmPopupComponent', () => {
  let component: ConfirmPopupComponent;
  let fixture: ComponentFixture<ConfirmPopupComponent>;
  let injector: TestBed;
  let debugElement: DebugElement;
  const originReset = TestBed.resetTestingModule;
  let dialog: DialogRef;
  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [ConfirmPopupComponent],
      imports: [
        BrowserAnimationsModule,
        DialogsModule],
      providers: [
        { provide: DialogRef, useClass: DialogMock },
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(ConfirmPopupComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    dialog = TestBed.inject(DialogRef);
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onCancelAction when cancel button is clicked', fakeAsync(() => {
    spyOn(component, 'onCancelAction');
    debugElement.query(By.css('.cancel-btn')).triggerEventHandler('click', null);

    fixture.detectChanges();
    expect(component.onCancelAction).toHaveBeenCalled();
  }));

  it('should call onconfirmAction when save button is clicked', fakeAsync(() => {
    spyOn(component, 'onConfirmAction');
    debugElement.query(By.css('.save-btn')).triggerEventHandler('click', null);

    fixture.detectChanges();
    expect(component.onConfirmAction).toHaveBeenCalled();
  }));

  it('should dialog close return value set when onCancelAction is called', (() => {
    component.onCancelAction();
    spyOn(dialog, 'close').and.returnValue({ text: 'Cancel' });
  }));

  it('should dialog close return value set when onConfirmAction is called', (() => {
    component.onConfirmAction();
    spyOn(dialog, 'close').and.returnValue({ text: 'Submit', primary: true });
  }));

});
