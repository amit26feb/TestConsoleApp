import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { AppConstants } from '../../constants/constants';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterMock } from '../../../shared/test-mocks/routerMock';
import { OKTA_CONFIG, OktaAuthService } from '@okta/okta-angular';
import OktaConfig from '../../../.okta.config';
import { JobHeaderService } from '../../services/job-header.service';
import { IOfficeSelectorModel } from '../../model/office-selector-model';
import { GlobalFilterService } from '../../services/global-filter.service';
import { WorkflowPopupCardComponent } from './workflow-popup-card.component';
import { ToasterService } from '../../services/toaster.service';
import { FilterServiceMock } from '../../test-mocks/filterservice-mock';
import { Observable } from 'rxjs';
import { WorkflowChildNode, WorkflowContent, workflowData } from '../../model/workflow-content';
import { RoleService } from '@tsmt/shared-core-salesweb';
import { environment } from '../../../../environments/environment';

describe('WorkflowPopupCardComponent', () => {
  let component: WorkflowPopupCardComponent;
  let fixture: ComponentFixture<WorkflowPopupCardComponent>;
  let appConstants: AppConstants;
  let globalFilterService: GlobalFilterService;
  let toasterService: ToasterService;
  let roleService: RoleService;
  const workflowDataClone = JSON.parse(JSON.stringify(workflowData)) as WorkflowContent[];

  const oktaRoutingConfig = Object.assign({
    onAuthRequired: ({ oktaRouter }) => {
      oktaRouter.navigate(['']);
    },
  }, OktaConfig.oidc);

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [
        TreeViewModule,
        BrowserAnimationsModule,
      ],
      providers: [
        { provide: OKTA_CONFIG, useValue: oktaRoutingConfig },
        { provide: Router, useClass: RouterMock },
        {
          provide: ActivatedRoute, useValue: {
            snapshot: {
              params: {},
            },
          },
        },
        { provide: GlobalFilterService, useClass: FilterServiceMock },
        OktaAuthService,
        AppConstants,
        JobHeaderService,
        HttpClient,
        HttpHandler,
        ToasterService,
        RoleService,
        { provide: 'environment', useValue: environment }
      ],
      declarations: [WorkflowPopupCardComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkflowPopupCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    appConstants = TestBed.inject(AppConstants);
    globalFilterService = TestBed.inject(GlobalFilterService);
    toasterService = TestBed.inject(ToasterService);
    roleService = TestBed.inject(RoleService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should set isUserUnderIndependentSalesOffice indicator for users under an independent home office', () => {
    const mockSalesOffices: IOfficeSelectorModel[] = [
      {
        drAddressId: 1,
        salesOfficeName: 'Other Office',
        createJobInd: 'A',
      } as IOfficeSelectorModel,
      {
        drAddressId: 2,
        salesOfficeName: 'Home Office',
        createJobInd: 'A', // This is their home office, and they can freely add jobs, so it must be independent
        homeDrAddressId: 1,
      } as IOfficeSelectorModel,
    ];
    const spyGetOfficeSelectorList = spyOn(globalFilterService, 'getOfficeSelectorList').and.returnValue(Observable.of(mockSalesOffices));
    component.isUserUnderIndependentSalesOffice = false;

    component.ngOnInit();

    expect(component.isUserUnderIndependentSalesOffice).toEqual(true);
    expect(spyGetOfficeSelectorList).toHaveBeenCalled();
  });

  it('ngOnInit should set isUserUnderIndependentSalesOffice indicator for corporate users without a home sales office', () => {
    const mockSalesOffices: IOfficeSelectorModel[] = [
      {
        drAddressId: 1,
        salesOfficeName: 'Office 1',
        createJobInd: 'P',
      } as IOfficeSelectorModel,
      {
        drAddressId: 2,
        salesOfficeName: 'Office 2',
        createJobInd: 'W',
      } as IOfficeSelectorModel,
    ]; // notice, none of the offices are a home office
    const spyGetOfficeSelectorList = spyOn(globalFilterService, 'getOfficeSelectorList').and.returnValue(Observable.of(mockSalesOffices));
    component.isUserUnderIndependentSalesOffice = true;

    component.ngOnInit();

    expect(component.isUserUnderIndependentSalesOffice).toEqual(false);
    expect(spyGetOfficeSelectorList).toHaveBeenCalled();
  });

  it('ngOnInit should set isUserUnderIndependentSalesOffice indicator for users under a company owned home office', () => {
    const mockSalesOffices: IOfficeSelectorModel[] = [
      {
        drAddressId: 1,
        salesOfficeName: 'Other Office',
        createJobInd: 'P',
      } as IOfficeSelectorModel,
      {
        drAddressId: 2,
        salesOfficeName: 'Home Office',
        createJobInd: 'P', // This is their home office, and they can't freely create jobs, so it must be company owned
        homeDrAddressId: 1,
      } as IOfficeSelectorModel,
    ];
    const spyGetOfficeSelectorList = spyOn(globalFilterService, 'getOfficeSelectorList').and.returnValue(Observable.of(mockSalesOffices));
    component.isUserUnderIndependentSalesOffice = true;

    component.ngOnInit();

    expect(component.isUserUnderIndependentSalesOffice).toEqual(false);
    expect(spyGetOfficeSelectorList).toHaveBeenCalled();
  });

  it('should emit click event to close workflow popup side panel', () => {
    const sampleEvent = new Event('click');
    const spyEmit = spyOn(component.hideWorkflowPopup, 'emit');
    fixture.detectChanges();
    component.closeWorkflowPopup(sampleEvent);
    expect(spyEmit).toHaveBeenCalled();
  });

  it('should call window open on calling redirectPage function', () => {
    const event = { target: { attributes: { value: { value: 'demourl' } } } };
    const spyEmit = spyOn(window, 'open');
    component.redirectPage(event);
    expect(spyEmit).toHaveBeenCalled();
  });

  it('should not call window open on calling redirectPage function', () => {
    const event = { target: { attributes: { value: { value: '' } } } };
    const spyEmit = spyOn(window, 'open');
    component.redirectPage(event);
    expect(spyEmit).toHaveBeenCalledTimes(0);
  });

  it('should not call window open on calling redirectPage function for retractable URL within independent sales office', () => {
    const verbotenUrls = ['cat', 'hat'];
    const event = { target: { attributes: { value: { value: 'hat' } } } };
    const spyWindowOpen = spyOn(window, 'open');
    const spyToaster = spyOn(toasterService, 'setToaster');

    component.retractableRedirectURLs = verbotenUrls;
    component.isUserUnderIndependentSalesOffice = true;
    component.redirectPage(event);

    expect(spyWindowOpen).toHaveBeenCalledTimes(0);
    expect(spyToaster).toHaveBeenCalled();
  });

  it('should call window open on calling redirectPage function for retractable URL within company sales office', () => {
    const verbotenUrls = ['cat', 'hat'];
    const event = { target: { attributes: { value: { value: 'hat' } } } };
    const spyWindowOpen = spyOn(window, 'open');
    const spyToaster = spyOn(toasterService, 'setToaster');

    component.retractableRedirectURLs = verbotenUrls;
    component.isUserUnderIndependentSalesOffice = false;
    component.redirectPage(event);

    expect(spyWindowOpen).toHaveBeenCalled();
    expect(spyToaster).toHaveBeenCalledTimes(0);
  });

  it('should call window open on calling redirectPage function for normal URL within independent sales office', () => {
    const verbotenUrls = ['cat', 'hat'];
    const event = { target: { attributes: { value: { value: 'rat' } } } }; // normal URL, not one of the retractable ones.
    const spyWindowOpen = spyOn(window, 'open');
    const spyToaster = spyOn(toasterService, 'setToaster');

    component.retractableRedirectURLs = verbotenUrls;
    component.isUserUnderIndependentSalesOffice = true;
    component.redirectPage(event);

    expect(spyWindowOpen).toHaveBeenCalled();
    expect(spyToaster).toHaveBeenCalledTimes(0);
  });

  it('should call addDisabledKeys methods on calling ngOnInit()', () => {
    const spyAddDisabledKeys = spyOn(component, 'addDisabledKeys');
    component.ngOnInit();
    expect(spyAddDisabledKeys).toHaveBeenCalled();
  });

  it('should set disabledKeys if user has no edit access in prod environment on calling addDisabledKeys', () => {
    roleService.doesUserHasProdSupportAccess = false;
    roleService.doesUserHasEditAccess = false;
    environment.deployedEnv = appConstants.PROD_ENVIRONMENT;
    component.addDisabledKeys();
    expect(component.disabledKeys).toContain(appConstants.WORKFLOW_NODE);
  });

  it('should not set disabledKeys if user has edit access in prod environment on calling addDisabledKeys', () => {
    roleService.doesUserHasProdSupportAccess = false;
    roleService.doesUserHasEditAccess = true;
    environment.deployedEnv = appConstants.PROD_ENVIRONMENT;
    component.addDisabledKeys();
    expect(component.disabledKeys).not.toContain(appConstants.WORKFLOW_NODE);
  });

  it('should set disabledKeys if user has no support access in prod environment on calling addDisabledKeys', () => {
    roleService.doesUserHasProdSupportAccess = false;
    environment.deployedEnv = appConstants.PROD_ENVIRONMENT;
    component.addDisabledKeys();
    expect(component.disabledKeys).toContain(appConstants.WORKFLOW_SUPPORT_NODE);
  });

  it('should not set disabledKeys if user has support access in prod environment on calling addDisabledKeys', () => {
    roleService.doesUserHasProdSupportAccess = true;
    environment.deployedEnv = appConstants.PROD_ENVIRONMENT;
    component.addDisabledKeys();
    expect(component.disabledKeys).not.toContain(appConstants.WORKFLOW_SUPPORT_NODE);
  });

  it('should set disabledKeys if user has no edit access in non-prod environment on calling addDisabledKeys', () => {
    roleService.doesUserHasEditAccess = false;
    environment.deployedEnv = 'dev';
    component.addDisabledKeys();
    expect(component.disabledKeys).toContain(appConstants.WORKFLOW_SUPPORT_NODE);
    expect(component.disabledKeys).toContain(appConstants.WORKFLOW_NODE);
  });

  it('should not set disabledKeys if user has edit access in non-prod environment on calling addDisabledKeys', () => {
    roleService.doesUserHasEditAccess = true;
    environment.deployedEnv = 'dev';
    component.addDisabledKeys();
    expect(component.disabledKeys).not.toContain(appConstants.WORKFLOW_SUPPORT_NODE);
    expect(component.disabledKeys).not.toContain(appConstants.WORKFLOW_NODE);
  });
});
