import { Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { WorkflowContent, workflowData } from '../../../shared/model/workflow-content';
import { IOfficeSelectorModel } from '../../model/office-selector-model';
import { GlobalFilterService } from '../../services/global-filter.service';
import { JobHeaderService } from '../../services/job-header.service';
import { ToasterService } from '../../services/toaster.service';
import { RoleService } from '@tsmt/shared-core-salesweb';
import { AppConstants } from '../../constants/constants';

@Component({
  selector: 'app-workflow-popup-card',
  templateUrl: './workflow-popup-card.component.html',
  styleUrls: ['./workflow-popup-card.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class WorkflowPopupCardComponent implements OnInit {
  public workflowMockData: WorkflowContent[];
  public redirectPageURL: string;

  public isUserUnderIndependentSalesOffice = false;

  // URLs that we want to suppress, for users in independent sales offices:
  public retractableRedirectURLs = []; // NOTE: none currently being suppressed ... in the recent past we suppressed '/po-acknowledgement'.

  @Output() hideWorkflowPopup = new EventEmitter<string>();
  public disabledKeys: string[] = [];

  constructor(
    private jobHeaderService: JobHeaderService,
    private globalFilterService: GlobalFilterService,
    private toasterService: ToasterService,
    private roleService: RoleService,
    private appConstants: AppConstants
  ) { }

  ngOnInit() {
    this.workflowMockData = workflowData;

    this.isUserUnderIndependentSalesOffice = false;

    // Determine whether the current logged in user is under an Independent home sales office.
    this.globalFilterService.getOfficeSelectorList().subscribe((data) => {
      // NOTE: Corporate and power users won't have any offices marked as their "home office", and that's okay.
      //      ... We don't need to retract anything for these users, anyway.
      const filterHomeSalesOffice: IOfficeSelectorModel[] = data.filter((x) => x.homeDrAddressId > 0);
      if (filterHomeSalesOffice.length > 0) {
        // In the unlikely event that multiple offices are marked as the user's "home office", we'll honor the first one.
        const homeOffice: IOfficeSelectorModel = filterHomeSalesOffice[0];
        if (homeOffice.createJobInd !== 'W' && homeOffice.createJobInd !== 'P') {
          // When you can freely create new jobs (not Warned or Prevented), we infer that you are in an Independent sales office,
          // versus a Company-owned sales office.
          // For some reason, this logic is slightly better than relying on the crmIntegrationInd flag.
          this.isUserUnderIndependentSalesOffice = true;
        }
      }
    });
    this.addDisabledKeys();
  }

  // Emit click event to close WorkflowPopup panel
  closeWorkflowPopup(event) {
    event.stopPropagation();
    this.hideWorkflowPopup.emit();
    this.jobHeaderService.isWorkflowPanelOpen.next(false);
  }

  redirectPage(el) {
    this.redirectPageURL = el.target.attributes.value.value;
    if (this.redirectPageURL && this.redirectPageURL !== '') {
      // We will suppress some navigation, when the user is under an independent sales office.
      if (!this.isUserUnderIndependentSalesOffice || !this.retractableRedirectURLs.includes(this.redirectPageURL)) {
        window.open(this.redirectPageURL, this.redirectPageURL);
      } else {
        this.toasterService.setToaster('info', 'This feature is not yet available');
      }
    }
  }

  // Method to add disabledKeys variable with nodes that should be disabled based on user roles
  addDisabledKeys(): void {
    this.disabledKeys = [];
    if (environment.deployedEnv.toLowerCase() === this.appConstants.PROD_ENVIRONMENT) {
      if (!this.roleService.doesUserHasProdSupportAccess) {
        this.disabledKeys.push(this.appConstants.WORKFLOW_SUPPORT_NODE);
      }
      if (!this.roleService.doesUserHasEditAccess) {
        this.disabledKeys.push(this.appConstants.WORKFLOW_NODE);
      }
    } else {
      if (!this.roleService.doesUserHasEditAccess) {
        this.disabledKeys.push(this.appConstants.WORKFLOW_SUPPORT_NODE);
        this.disabledKeys.push(this.appConstants.WORKFLOW_NODE);
      }
    }
  }
}
