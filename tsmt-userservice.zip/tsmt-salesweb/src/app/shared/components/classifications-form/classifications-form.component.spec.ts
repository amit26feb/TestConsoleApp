import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Routes } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';

import { JobEditSaveService, JobSaveFormType } from '../../../modules/jobs-list-master/services/jobeditsave.service';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { ApiErrorService } from './../../../shared/services/apierror.service';
import { ApiErrorServiceMock } from './../../../shared/test-mocks/apierrorservice-mock';
import { JobListServiceMock } from './../../../shared/test-mocks/jobService-mock';
import { ClassificationsFormComponent } from './classifications-form.component';

describe('ClassificationsFormComponent', () => {
  let apiErrorService: ApiErrorService;
  let component: ClassificationsFormComponent;
  let fixture: ComponentFixture<ClassificationsFormComponent>;
  let service: JobsServicesService;
  let injector: TestBed;
  const originReset = TestBed.resetTestingModule;
  const Testroutes: Routes = [
    {
      path: '**',
      component: ClassificationsFormComponent,
    }];


  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(Testroutes), ReactiveFormsModule],
      declarations: [ClassificationsFormComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: ApiErrorService, useClass: ApiErrorServiceMock },
        JobEditSaveService,
        { provide: JobsServicesService, useClass: JobListServiceMock },
        {
          provide: ActivatedRoute, useValue: {
            snapshot: { params: { jobId: 83050, drAddressId: 34 } },
            fragment: Observable.of('test'),
          },
        },
      ],
    });
    injector = getTestBed();
  }));

  beforeEach(() => {
    apiErrorService = injector.inject(ApiErrorService);
    fixture = TestBed.createComponent(ClassificationsFormComponent);
    component = fixture.componentInstance;
    service = injector.inject(JobsServicesService);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onInit initiate data load', () => {
    const spyLoad = spyOn(component, 'loadData');
    component.ngOnInit();
    expect(spyLoad).toHaveBeenCalledTimes(1);
  });

  it('loadData should populate form and notify parent form', () => {

    component.jobId = 83050;
    component.drAddressId = 34;

    const spyClassification = spyOn(service, 'editClassificationDetails').and.callThrough();
    const spySelectedClassification = spyOn(service, 'getSelectedClassifications').and.callThrough();
    const spyEmit = spyOn(component.formUpdate, 'emit');

    component.loadData();

    expect(spyClassification).toHaveBeenCalled();
    expect(spySelectedClassification).toHaveBeenCalledWith(34, 83050);
    expect(spyEmit).toHaveBeenCalledWith({
      form: component.editClassificationForm, index: JobSaveFormType.ClassificationForm,
      options: component.classificationDropdownList,
    });

    // both Purchaser Class and Vertical Market be be enabled (not CRM)
    expect(component.editClassificationForm.controls['classificationOptions']['controls'][0].enabled).toBe(true);
    expect(component.editClassificationForm.controls['classificationOptions']['controls'][1].enabled).toBe(true);

    // get the classification job except transition job
    expect(component.classificationDropdownList.length).toBe(2);
  });

  it('disable Vertical Market class, if crm integrated', () => {

    component.crmJob = true;

    component.loadData();

    // Purchaser Class should be enabled, Vertical Market be be disabled
    expect(component.editClassificationForm.controls['classificationOptions']['controls'][0].enabled).toBe(true);
    expect(component.editClassificationForm.controls['classificationOptions']['controls'][1].disabled).toBe(true);
  });

  it('should display "no result" when no classifications exist', () => {

    // force zero records to be returned
    spyOn(service, 'editClassificationDetails').and.returnValue(Observable.of([]));

    component.ngOnInit();
    fixture.detectChanges();

    // confirm no records exist
    expect(component.classifications.length).toBe(0);

    // check content for message
    const element = fixture.debugElement.query(By.css('.EditJobSubTitle .noClassfication')).nativeElement;
    expect(element.textContent).toBe('[No Classifications Available]');
  });

  it('should display error message when job classification list fetch fails', () => {

    const spyApiError = spyOn(apiErrorService, 'show');

    // fake service error
    spyOn(service, 'editClassificationDetails').and.returnValue(Observable.throwError({ error: 'error' }));

    component.ngOnInit();

    // confirm no records exist
    expect(component.classifications).toBeUndefined();
    expect(spyApiError).toHaveBeenCalled();
  });

  it('should display error message when selected job classification list fetch fails', () => {

    const spyApiError = spyOn(apiErrorService, 'show');

    // fake service error
    spyOn(service, 'getSelectedClassifications').and.returnValue(Observable.throwError({ error: 'error' }));

    component.ngOnInit();

    // confirm no records exist
    expect(component.classifications.length).toBeGreaterThanOrEqual(1);
    expect(spyApiError).toHaveBeenCalled();
  });
});
