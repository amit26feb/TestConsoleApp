import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { IClassificationModel, IClassificationOptions } from '../../../modules/jobs-list-master/modal/job-details-edit.model';
import { JobSaveFormType } from '../../../modules/jobs-list-master/services/jobeditsave.service';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { ApiErrorService } from '../../services/apierror.service';


@Component({
  selector: 'app-classifications-form',
  templateUrl: './classifications-form.component.html',
  styleUrls: ['./classifications-form.component.scss'],
})
export class ClassificationsFormComponent implements OnInit {
  public classificationDropdownList: IClassificationModel[] = [];
  public classificationDropdown: IClassificationOptions[] = [];
  public classificationSelectedData: any;
  public classificationSelected: IClassificationModel[] = [];

  @Input() formData: IClassificationModel;
  @Input() crmJob: boolean;
  @Output() formUpdate: EventEmitter<any> = new EventEmitter();

  editClassificationForm: FormGroup;
  jobId: number;
  drAddressId: number;
  classifications: any;

  constructor(
    private apiErrorService: ApiErrorService,
    private fb: FormBuilder,
    private jobListService: JobsServicesService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.jobId = +this.route.snapshot.params['jobId'];
    this.drAddressId = +this.route.snapshot.params['drAddressId'];

    this.editClassificationForm = this.fb.group({
      classificationOptions: new FormArray([]),
    });

    this.loadData();
  }

  // encapsulate load process into method
  //  allows form to be reloaded if/when job is unlocked
  loadData() {

    // fetch all classification options expect transition job
    this.jobListService.editClassificationDetails(this.drAddressId, this.jobId).subscribe((res) => {
      this.classificationDropdownList = res.filter((x) => x.classificationDescription !== 'Transitional Job');

      // create controls
      this.classifications = this.classificationDropdownList.map(() =>
        new FormControl('none'),
      );

      // create form
      this.editClassificationForm = this.fb.group({
        classificationOptions: new FormArray(this.classifications),
      });

      // get current selections for this job
      this.jobListService.getSelectedClassifications(this.drAddressId, this.jobId).subscribe((selectedValues) => {

        this.classificationSelected = selectedValues;
        this.setClassificationSelectedValue();

        // if this is a CRM-integrated job
        //   disable the Vertical Market job class
        if (this.crmJob) {
          this.classificationDropdownList.forEach((element, index) => {
            if (element.classificationDescription === 'Vertical Market') {
              this.editClassificationForm.controls['classificationOptions']['controls'][index].disable();
            }
          });
        }

        // notify parent, to enable saves when changes are made on this form/component
        this.formUpdate.emit({
          form: this.editClassificationForm, index: JobSaveFormType.ClassificationForm,
          options: this.classificationDropdownList,
        });
      },
        (error) => {
          // lets write a line to the console, i the event we desire to get information from the user
          console.error('ClassificationsFormComponent::getSelectedClassifications(): %o', error);
          this.apiErrorService.show('An error occurred while loading selected class codes.  This view will be incomplete');
        });
    },
      (error) => {
        // lets write a line to the console, i the event we desire to get information from the user
        console.error('ClassificationsFormComponent::editClassificationDetails(): %o', error);
        this.apiErrorService.show('An error occurred while loading job class codes.  This view will be incomplete');
      });
  }

  setClassificationSelectedValue() {
    if (this.classificationSelected !== null) {
      // for each classification type (ie dropdown)
      this.classificationDropdownList.forEach((element, index) => {

        // pre-select the currently chosen value
        this.classificationSelected.forEach((sel) => {
          if (sel.classificationDescription === element.classificationDescription) {
            element.jobClassificationList.forEach((option) => {
              option.selected = false;
              if (sel.descriptionValues === option.description) {
                option.selected = true;
                this.editClassificationForm.
                  controls['classificationOptions']['controls'][index].setValue(sel.jobCodeId);
              }
            });
          }
        });
      });
    }
  }
}
