import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { BidsService } from '../../../modules/jobs-list-master/services/bids.service';
import { SalesCustomerService } from '../../../modules/jobs-list-master/services/sales-customer.service';
import { SelectionService } from '../../../modules/jobs-list-master/services/selection.service';
import { JobSummaryService } from '../../../shared/services/job-summary.service';
import { LoaderService } from '../../../shared/services/loader.service';
import { FilterServiceMock } from '../../../shared/test-mocks/filterservice-mock';
import { JobsRouterMock } from '../../../shared/test-mocks/jobs-router-mock';
import { IOfficeSelectorModel } from '../../model/office-selector-model';
import { GlobalFilterService } from '../../services/global-filter.service';
import { JobsServicesServiceMock } from '../../test-mocks/job-service-mock';
import { JobSummaryServiceMock } from '../../test-mocks/job-summary-service-mock';
import { JobsServicesService } from './../../../modules/jobs-list-master/services/jobs-services.service';
import { AppConstants } from './../../constants/constants';
import { OfficeSelectorComponent } from './office-selector.component';
const testDrAddressId = 121;
const testWorkPackages = 'work-packages';
const testProjects = 'projects';
const testjobs = '/jobs-list';
const testProjectsWithJobId = ':jobId/projects';
const salesOffice: IOfficeSelectorModel = {
    salesOfficeName: 'testoffice',
    drAddressId: testDrAddressId,
    country: 'testcountry',
    crmIntegrationInd: 'Y',
    homeDrAddressId: 0,
    groupName: 'CTXDBSELECTOR',
    createJobInd: 'A',
} as IOfficeSelectorModel;
describe('OfficeSelectorComponent', () => {
    let injector: TestBed;
    let component: OfficeSelectorComponent;
    let jobSummaryService: JobSummaryService;
    let fixture: ComponentFixture<OfficeSelectorComponent>;
    let globalFilterService: GlobalFilterService;
    let router: Router;
    let route: ActivatedRoute;
    let jobService: JobsServicesService;
    const originReset = TestBed.resetTestingModule;
    configureTestSuite((() => {
        TestBed.configureTestingModule({
            declarations: [OfficeSelectorComponent],
            imports: [
                HttpClientTestingModule,
                RouterTestingModule,
                DropDownsModule,
                FormsModule,
                TranslateModule.forRoot(),
            ],
            providers: [
                {
                    provide: ActivatedRoute, useValue: {
                        snapshot: {
                            params: { drAddressId: testDrAddressId },
                            routeConfig: {
                                children: [{
                                    path: testProjects, snapshot: {
                                        params: { jobId: '1234' },
                                    },
                                }, {
                                    path: testProjectsWithJobId, snapshot: {
                                        params: { jobId: '1234' },
                                    },
                                },
                                ],
                            },
                        },
                        children: [{
                            path: testProjects, snapshot: {
                                params: { jobId: '1234' },
                            },
                        }, {
                            path: testProjectsWithJobId, snapshot: {
                                params: { jobId: '1234' },
                            },
                        },
                        ],
                    },
                }, {
                    provide: Router, useClass: class {
                        navigate = jasmine.createSpy('navigate');
                        routerState = {
                            snapshot: { url: testWorkPackages },
                        };
                        events = new Observable((observer) => {
                            observer.next(new NavigationEnd(0, '/home-page-list', ''));
                            observer.complete();
                        });
                        root = { children: [testjobs] };
                    },
                },
                { provide: GlobalFilterService, useClass: FilterServiceMock },
                JobsServicesService, AppConstants, JobSummaryService, LoaderService,
                BidsService, LoaderService, SalesCustomerService, SelectionService,
            ],
        });
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(OfficeSelectorComponent);
        component = fixture.componentInstance;
        injector = getTestBed();
        jobSummaryService = injector.inject(JobSummaryService);
        globalFilterService = injector.inject(GlobalFilterService);
        route = injector.inject(ActivatedRoute);
        router = injector.inject(Router);
        jobService = injector.inject(JobsServicesService);
        let showJobSummary;
        jobSummaryService.jobSummaryPanelStatus$.subscribe((e) => {
            showJobSummary = e['showJobSummary'];
        });
        fixture.detectChanges();
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should call filter value change when checkOfficeSelector is called on ngOnInit', () => {
        const spyGetOfficeSelectors = spyOn(globalFilterService, 'getOfficeSelectorList').and.callThrough();
        const spyFilterValueChange = spyOn(component, 'filterValueChange').and.callThrough();
        globalFilterService.setOfficeSelectorList([]);
        component.ngOnInit();
        expect(spyGetOfficeSelectors).toHaveBeenCalled();
        expect(component.drAddressId).toBe(testDrAddressId);
        expect(component.officeSelectorList[0].salesOfficeName).toBe('Billings');
        expect(component.selectedOffice.country).toBe('USA');
        expect(spyFilterValueChange).toHaveBeenCalledWith(component.selectedOffice);
    });

    it('should set activeTab with selectedToggle value is Untransmitted when ngOnChanges is called', () => {
        component.selectedToggle = 'Untransmitted';
        component.ngOnChanges();
        expect(component.activeTab).toBe(component.selectedToggle);
    });

    it('should set activeTab to empty when ngOnChanges is called', () => {
        component.selectedToggle = 'Transmitted';
        component.ngOnChanges();
        expect(component.activeTab).toBe('');
    });
    it('should call filter value change and set default drAddressId when called on ngOnInit', () => {
        const salesOfficeList: IOfficeSelectorModel[] = [
            {
                salesOfficeName: 'test1', drAddressId: 101, country: 'USA', crmIntegrationInd: 'Y', homeDrAddressId: 101,
                groupName: 'CTXDBSELECTOR', createJobInd: 'A',
            },
            {
                salesOfficeName: 'test2', drAddressId: 121, country: 'USA', crmIntegrationInd: 'Y', homeDrAddressId: 101,
                groupName: 'CTXDBSELECTOR', createJobInd: 'A',
            }] as IOfficeSelectorModel[];
        route.snapshot.params = Observable.of({ drAddressId: undefined });
        const spyGetOfficeSelectors = spyOn(globalFilterService, 'getOfficeSelectorList').and.returnValue(Observable.of(salesOfficeList));
        const spyFilterValueChange = spyOn(component, 'filterValueChange').and.callThrough();
        component.ngOnInit();
        fixture.detectChanges();
        expect(spyGetOfficeSelectors).toHaveBeenCalled();
        expect(component.drAddressId).toBe(101);
        expect(component.officeSelectorList[0].salesOfficeName).toBe('test1');
        expect(component.selectedOffice.country).toBe('USA');
        expect(spyFilterValueChange).toHaveBeenCalledWith(component.selectedOffice);
    });

    it('should set the selected office to filterservice on filterValueChange and set the appropriate router navigation', () => {
        const spyEmit = spyOn(component.toggleFollowedJobCount, 'emit');
        component.showFollowedJobCount = false;
        component.filterValueChange(salesOffice);
        expect(component.routerUrl).toBe(testWorkPackages);
        expect(component.path).toBe(testWorkPackages);
        expect(spyEmit).toHaveBeenCalled();
    });



    it('should not perform any action when filterValueChange is called with undefined', () => {
        const spySetSelectedOffice = spyOn(globalFilterService, 'setSelectedOffice').and.callThrough();
        component.filterValueChange(undefined);
        expect(spySetSelectedOffice).not.toHaveBeenCalled();
    });

    it('should path value set empty value while children has undefined', () => {
        route.snapshot.routeConfig.children = undefined;
        component.filterValueChange(salesOffice);
        expect(component.path).toBe('');
    });
});

describe('OfficeSelectorComponent for jobs-list route', () => {
    let injector: TestBed;
    let component: OfficeSelectorComponent;
    let jobSummaryService: JobSummaryService;
    let fixture: ComponentFixture<OfficeSelectorComponent>;
    let globalFilterService: GlobalFilterService;
    let router: Router;
    let jobService: JobsServicesService;
    const originReset = TestBed.resetTestingModule;
    configureTestSuite((() => {
        TestBed.configureTestingModule({
            declarations: [OfficeSelectorComponent],
            imports: [
                HttpClientTestingModule,
                RouterTestingModule,
                DropDownsModule,
                FormsModule,
                TranslateModule.forRoot(),
            ],
            providers: [
                {
                    provide: ActivatedRoute, useValue: {
                        snapshot: {
                            params: { drAddressId: testDrAddressId },
                            routeConfig: {
                                children: [{
                                    path: testProjects, snapshot: {
                                        params: { jobId: '1234' },
                                    },
                                }, {
                                    path: testProjectsWithJobId, snapshot: {
                                        params: { jobId: '1234' },
                                    },
                                },
                                ],
                            },
                        },
                        children: [{
                            path: testProjects, snapshot: {
                                params: { jobId: '1234' },
                            },
                        }, {
                            path: testProjectsWithJobId, snapshot: {
                                params: { jobId: '1234' },
                            },
                        },
                        ],
                    },
                }, {
                    provide: Router, useClass: JobsRouterMock,
                },
                { provide: GlobalFilterService, useClass: FilterServiceMock },
                JobsServicesService, AppConstants, BidsService, LoaderService, SalesCustomerService,
                SelectionService, JobSummaryService,
            ],
            schemas: [NO_ERRORS_SCHEMA],
        });
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(OfficeSelectorComponent);
        component = fixture.componentInstance;
        injector = getTestBed();
        jobSummaryService = injector.inject(JobSummaryService);
        globalFilterService = injector.inject(GlobalFilterService);
        jobService = injector.inject(JobsServicesService);
        router = injector.inject(Router);
        fixture.detectChanges();
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should set the selected office to filterservice on filterValueChange and set the joblist router navigation and set' +
        'showJobSummary to false on calling filterValueChange', () => {
            let showJobSummary = true;
            jobSummaryService.jobSummaryPanelStatus$.subscribe((e) => {
                showJobSummary = e['showJobSummary'];
            });
            spyOn(router, 'navigate').and.callThrough();
            const spySetSelectedOffice = spyOn(globalFilterService, 'setSelectedOffice').and.callThrough();
            component.filterValueChange(salesOffice);
            fixture.detectChanges();
            expect(component.routerUrl).toBe('jobs-list');
            expect(showJobSummary).toBe(false);
        });

});

describe('OfficeSelectorComponent for Project route', () => {
    let injector: TestBed;
    let component: OfficeSelectorComponent;
    let jobSummaryService: JobSummaryService;
    let fixture: ComponentFixture<OfficeSelectorComponent>;
    let globalFilterService: GlobalFilterService;
    let jobService: JobsServicesService;
    const originReset = TestBed.resetTestingModule;
    configureTestSuite((() => {
        TestBed.configureTestingModule({
            declarations: [OfficeSelectorComponent],
            imports: [
                HttpClientTestingModule,
                RouterTestingModule,
                DropDownsModule,
                FormsModule,
                TranslateModule.forRoot(),
            ],
            providers: [
                {
                    provide: ActivatedRoute, useValue: {
                        snapshot: {
                            params: { drAddressId: testDrAddressId },
                            routeConfig: {
                                children: [{
                                    path: testProjects, snapshot: {
                                        params: { jobId: '1234' },
                                    },
                                }, {
                                    path: testProjectsWithJobId, snapshot: {
                                        params: { jobId: '1234' },
                                    },
                                },
                                ],
                            },
                        },
                        children: [{
                            path: testProjects, snapshot: {
                                params: { jobId: '1234' },
                            },
                        }, {
                            path: testProjectsWithJobId, snapshot: {
                                params: { jobId: '1234' },
                            },
                        },
                        ],
                    },
                }, {
                    provide: Router, useClass: class {
                        navigate = jasmine.createSpy('navigate');
                        routerState = {
                            snapshot: { url: '/jobs-list/101/projects' },
                        };
                        events = new Observable((observer) => {
                            observer.next(new NavigationEnd(0, '/jobs-list', ''));
                            observer.complete();
                        });
                        root = { children: [testjobs] };
                    },
                },
                { provide: GlobalFilterService, useClass: FilterServiceMock },
                { provide: JobSummaryService, useClass: JobSummaryServiceMock },
                { provide: JobsServicesService, useClass: JobsServicesServiceMock },

            ],
        });
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(OfficeSelectorComponent);
        component = fixture.componentInstance;
        injector = getTestBed();
        jobSummaryService = injector.inject(JobSummaryService);
        globalFilterService = injector.inject(GlobalFilterService);
        jobService = injector.inject(JobsServicesService);
        let showJobSummary;
        jobSummaryService.jobSummaryPanelStatus$.subscribe((e) => {
            showJobSummary = e['showJobSummary'];
        });
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should navigate to projects list screen if route path is :jobId/projects', () => {
        const spySetSelectedOffice = spyOn(globalFilterService, 'setSelectedOffice').and.callThrough();
        const spyEmit = spyOn(component.toggleFollowedJobCount, 'emit');
        component.showFollowedJobCount = false;
        component.filterValueChange(salesOffice);
        expect(component.routerUrl).toBe('/jobs-list/101/projects');
        expect(component.path).toBe(testProjects);
        expect(spyEmit).toHaveBeenCalled();
    });
});
