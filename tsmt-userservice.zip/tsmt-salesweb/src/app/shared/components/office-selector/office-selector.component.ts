import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IOfficeSelectorModel } from '../../model/office-selector-model';
import { GlobalFilterService } from '../../services/global-filter.service';
import { JobSummaryService } from '../../services/job-summary.service';
import { JobsServicesService } from './../../../modules/jobs-list-master/services/jobs-services.service';

@Component({
  selector: 'app-office-selector',
  templateUrl: './office-selector.component.html',
  styleUrls: ['./office-selector.component.scss'],
})
export class OfficeSelectorComponent implements OnInit, OnChanges {
  public officeSelectorList: IOfficeSelectorModel[] = [];
  public selectedOffice: IOfficeSelectorModel;
  public drAddressId: number;
  public path: string;
  public jobId: string;
  public routerUrl: string;
  public activeTab: string;
  @Input() isLabel: boolean;
  @Output() toggleFollowedJobCount = new EventEmitter();
  @Input() showFollowedJobCount: boolean;
  @Input() selectedToggle: string;
  constructor(
    private globalFilterService: GlobalFilterService,
    private route: ActivatedRoute,
    private router: Router,
    private jobSummaryService: JobSummaryService,
    private jobService: JobsServicesService,
  ) { }

  ngOnInit() {
    this.drAddressId = +this.route.snapshot.params['drAddressId'];
    // get the office selector list from the filter service
    this.globalFilterService.getOfficeSelectorList().subscribe((data) => {
      this.officeSelectorList = data;
      // set the default drAddressId if it is not set in route params
      const filterDefaultSalesOffice = this.officeSelectorList.filter((x) => x.homeDrAddressId > 0);
      const defaultDrAddressId = filterDefaultSalesOffice.length > 0 ?
        filterDefaultSalesOffice[0].homeDrAddressId : this.officeSelectorList[0].drAddressId;
      this.drAddressId = this.drAddressId ? this.drAddressId : defaultDrAddressId;
      this.selectedOffice = this.drAddressId ? this.officeSelectorList
        .filter((list) => list.drAddressId === this.drAddressId)[0] : this.officeSelectorList[0];
      this.filterValueChange(this.selectedOffice);
    });
  }

  ngOnChanges(): void {
    if (this.selectedToggle === 'Untransmitted' || this.selectedToggle === 'JobsList' ||
      this.selectedToggle === 'Work Packages') {
      this.activeTab = this.selectedToggle;
    } else {
      this.activeTab = '';
    }
  }

  // triggered whenever there is a selection made on the office selector dropdown
  filterValueChange(item: IOfficeSelectorModel) {
    // get the path for each tab
    if (this.route.snapshot.routeConfig) {
      this.routerUrl = this.router.routerState.snapshot.url;
      this.path = this.route.snapshot.routeConfig.children ? this.routerUrl.split('/').pop() : '';
      this.jobId = (this.route.snapshot.routeConfig.children && (this.route.children[0].snapshot.params['jobId']))
        ? this.route.children[0].snapshot.params['jobId'] : '';
    }
    this.jobSummaryService.jobSummaryPanelStatus$.next({ showJobSummary: false });
    if (!this.showFollowedJobCount) {
      this.toggleFollowedJobCount.emit();
    }
  }
}
