import { HttpClient } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { OktaAuthService, OKTA_CONFIG } from '@okta/okta-angular';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { UserInfoService } from '@tsmt/shared-core-salesweb';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { of } from 'rxjs';
import { UserService } from '../../../modules/jobs-list-master/services/user.service';
import { AppConstants } from '../../constants/constants';
import { GlobalFilterService } from '../../services/global-filter.service';
import { TileService, TileTypes } from '../../services/tile.service';
import { HttpServiceMock } from '../../test-mocks/http.service';
import { UserPreferencesComponent } from './user-preferences.component';
import oktaConfig from './../../../.okta.config';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

describe('UserPreferencesComponent', () => {
  let component: UserPreferencesComponent;
  let fixture: ComponentFixture<UserPreferencesComponent>;
  let injector: TestBed;
  let userInfoService: UserInfoService;
  let userService: UserService;
  let globalFilterService: GlobalFilterService;
  const creditApproverRole = 'tsmt-credit-approver';
  const oktaRoutingConfig = Object.assign({}, oktaConfig.oidc);

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [UserPreferencesComponent],
      imports: [InputsModule, ReactiveFormsModule],
      providers: [
        UserInfoService,
        TileService,
        UserService,
        GlobalFilterService,
        OktaAuthService,
        AppConstants,
        { provide: Router, useValue: {} },
        { provide: HttpClient, useClass: HttpServiceMock },
        { provide: OKTA_CONFIG, useValue: oktaRoutingConfig },
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
  });

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(UserPreferencesComponent);
    component = fixture.componentInstance;
    userInfoService = injector.inject(UserInfoService);
    userService = injector.inject(UserService);
    globalFilterService = injector.inject(GlobalFilterService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set userSelectableTiles based on roles', () => {
    spyOn(userInfoService, 'getUserRoles').and.returnValue([creditApproverRole]);

    component.ngOnInit();

    expect(component.userSelectableTiles.length).toBe(6);
  });

  it('should set up form controls based on user selectable tiles in ngOnInit', () => {
    spyOn(userInfoService, 'getUserRoles').and.returnValue([creditApproverRole]);
    spyOn(userService, 'getDashboardPreferences').and.returnValue(of({}));

    component.ngOnInit();

    expect(component.dashPreferencesForm.contains(TileTypes.CreditApprovalBacklog)).toBe(true);
    expect(component.dashPreferencesForm.contains(TileTypes.MyCreditApprovalAndPOAcks)).toBe(true);
    expect(component.dashPreferencesForm.contains(TileTypes.WorkPackageValidationRequests)).toBe(true);
  });

  it('should initialize form controls to true if there are no preferences in ngOnInit', () => {
    spyOn(userInfoService, 'getUserRoles').and.returnValue([creditApproverRole]);
    spyOn(userService, 'getDashboardPreferences').and.returnValue(of({}));

    component.ngOnInit();

    expect(component.dashPreferencesForm.get(TileTypes.CreditApprovalBacklog).value).toBe(true);
    expect(component.dashPreferencesForm.get(TileTypes.MyCreditApprovalAndPOAcks).value).toBe(true);
    expect(component.dashPreferencesForm.get(TileTypes.WorkPackageValidationRequests).value).toBe(true);
  });

  it('should initialize form controls to preference values if present in ngOnInit', () => {
    spyOn(userInfoService, 'getUserRoles').and.returnValue([creditApproverRole]);
    spyOn(userService, 'getDashboardPreferences').and
      .returnValue(of({
        tiles: [
          { name: TileTypes.MyCreditApprovalAndPOAcks, isVisible: false, sequence: 0 },
          { name: TileTypes.WorkPackageValidationRequests, isVisible: true, sequence: 1 },
        ]
      }));

    component.ngOnInit();

    expect(component.dashPreferencesForm.get(TileTypes.CreditApprovalBacklog).value).toBe(true);
    expect(component.dashPreferencesForm.get(TileTypes.MyCreditApprovalAndPOAcks).value).toBe(false);
    expect(component.dashPreferencesForm.get(TileTypes.WorkPackageValidationRequests).value).toBe(true);
  });

  it('should initialize userSelectableTiles to preference order if present in ngOnInit', () => {
    spyOn(userInfoService, 'getUserRoles').and.returnValue([creditApproverRole]);
    spyOn(userService, 'getDashboardPreferences').and
      .returnValue(of({
        tiles: [
          { name: TileTypes.WorkPackageValidationRequests, isVisible: true, sequence: 0 },
          { name: TileTypes.MyCreditApprovalAndPOAcks, isVisible: false, sequence: 1 },
        ]
      }));

    component.ngOnInit();

    expect(component.userSelectableTiles[0].type).toBe(TileTypes.WorkPackageValidationRequests);
    expect(component.userSelectableTiles[1].type).toBe(TileTypes.MyCreditApprovalAndPOAcks);
  });


  it('should initialize homeTabUrl on call to ngOnInit', () => {
    const someDrAddressId = 8675309;
    spyOn(globalFilterService, 'getDefaultOffice').and.returnValue(of({ drAddressId: someDrAddressId }));

    component.ngOnInit();

    expect(component.homeTabUrl).toBe('/home/' + someDrAddressId);
  });

  it('should call setDashboardPreferences with current state on call to onTileSelectChange', () => {
    spyOn(userInfoService, 'getUserRoles').and.returnValue([creditApproverRole]);
    const updateSpy = spyOn(userService, 'setDashboardPreferences').and.returnValue(of({}));
    component.ngOnInit();
    component.dashPreferencesForm.get(TileTypes.CreditApprovalBacklog).setValue(false);
    const expectedPayload = {
      tiles: [
        { name: TileTypes.CreditApprovalBacklog, isVisible: false, sequence: 0 },
        { name: TileTypes.CreditMetrics, isVisible: true, sequence: 1 },
        { name: TileTypes.MyCreditApprovalAndPOAcks, isVisible: true, sequence: 2 },
        { name: TileTypes.PlannedShipmentCommitted, isVisible: true, sequence: 3 },
        { name: TileTypes.PlannedShipmentUpcomingReleased, isVisible: true, sequence: 4 },
        { name: TileTypes.WorkPackageValidationRequests, isVisible: true, sequence: 5 }
      ]
    };

    component.onTileSelectChange();

    expect(updateSpy).toHaveBeenCalledWith(expectedPayload);
  });

  it('should call setDashboardPreferences with current state on call to onReorder', () => {
    spyOn(userInfoService, 'getUserRoles').and.returnValue([creditApproverRole]);
    const updateSpy = spyOn(userService, 'setDashboardPreferences').and.returnValue(of({}));
    component.ngOnInit();
    const expectedPayload = {
      tiles: [
        { name: TileTypes.CreditMetrics, isVisible: true, sequence: 0 },
        { name: TileTypes.MyCreditApprovalAndPOAcks, isVisible: true, sequence: 1 },
        { name: TileTypes.CreditApprovalBacklog, isVisible: true, sequence: 2 },
        { name: TileTypes.PlannedShipmentCommitted, isVisible: true, sequence: 3 },
        { name: TileTypes.PlannedShipmentUpcomingReleased, isVisible: true, sequence: 4 },
        { name: TileTypes.WorkPackageValidationRequests, isVisible: true, sequence: 5 }
      ]
    };

    component.onReorder({ previousIndex: 0, currentIndex: 2 } as CdkDragDrop<string[]>);

    expect(updateSpy).toHaveBeenCalledWith(expectedPayload);
  });
});
