import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { UserInfoService } from '@tsmt/shared-core-salesweb';
import { UserService } from '../../../modules/jobs-list-master/services/user.service';
import { IDashboardPreference } from '../../model/dashboard-preferences';
import { IOfficeSelectorModel } from '../../model/office-selector-model';
import { GlobalFilterService } from '../../services/global-filter.service';
import { ITileInfo, TileService } from '../../services/tile.service';

@Component({
  selector: 'app-user-preferences',
  templateUrl: './user-preferences.component.html',
})
export class UserPreferencesComponent implements OnInit {
  public userSelectableTiles: ITileInfo[]; // Tiles that the user can pick from
  public dashPreferencesForm: FormGroup;
  public homeTabUrl = '';

  constructor(
    private userInfoService: UserInfoService,
    private tileService: TileService,
    private userService: UserService,
    private globalFilterService: GlobalFilterService) {
  }

  ngOnInit(): void {
    // Get user roles and the tiles that the user has access to.
    const userRoles = this.userInfoService.getUserRoles() ?? [];
    this.userSelectableTiles = this.tileService.getUserAccessibleTiles(userRoles);

    // Set up controls for each tile a user has access to
    const tileSelectionControls: { [tileType: string]: FormControl } = {};
    this.userSelectableTiles.forEach(ust => {
      tileSelectionControls[ust.type] = new FormControl(true);
    });
    this.dashPreferencesForm = new FormGroup(tileSelectionControls);

    // Get saved preferences, and initialize any controls that have entries
    this.userService.getDashboardPreferences().subscribe((userDashPreferences: IDashboardPreference) => {
      userDashPreferences?.tiles?.forEach(tile => {
        const control = this.dashPreferencesForm.get(tile.name);
        if (control) {
          control.setValue(tile.isVisible);
        }
      });

      // Sort userSelectableTiles based on saved preferences
      this.userSelectableTiles.sort((tile1, tile2) => {
        const prefTile1 = userDashPreferences.tiles?.find(tile => tile.name === tile1.type);
        const prefTile2 = userDashPreferences.tiles?.find(tile => tile.name === tile2.type);
        if (prefTile1 && prefTile2) {
          return prefTile1.sequence - prefTile2.sequence;
        } else if (prefTile1) {
          return -1;
        } else if (prefTile2) {
          return 1;
        } else {
          return 0;
        }
      });
    });

    // Get user's default drAddressId so we can set up a Home link for them
    this.globalFilterService.getDefaultOffice().subscribe((data: IOfficeSelectorModel) => {
      if (data !== null) {
        this.homeTabUrl = `/home/${data.drAddressId}`;
      }
    });
  }

  /**
   * Handle the tile select control changing
   */
  public onTileSelectChange(): void {
    // Get all preferences
    const preferences: IDashboardPreference = {
      tiles: this.userSelectableTiles.map((ust, idx) => {
        return { name: ust.type, isVisible: this.dashPreferencesForm.get(ust.type).value, sequence: idx };
      })
    };

    // Save them to user service
    this.userService.setDashboardPreferences(preferences).subscribe();
  }

  /**
   * Handle reordering the tiles
   * @param event the event
   */
  public onReorder(event: CdkDragDrop<string[]>): void {
    // Reorder the tiles
    moveItemInArray(this.userSelectableTiles, event.previousIndex, event.currentIndex);

    // Get preferences
    const preferences: IDashboardPreference = {
      tiles: this.userSelectableTiles.map((ust, idx) => {
        return { name: ust.type, isVisible: this.dashPreferencesForm.get(ust.type).value, sequence: idx };
      })
    };

    // Save the preferences
    this.userService.setDashboardPreferences(preferences).subscribe();
  }
}
