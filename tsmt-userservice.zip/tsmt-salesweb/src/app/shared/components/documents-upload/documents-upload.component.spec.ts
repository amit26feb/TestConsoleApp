import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { UploadModule } from '@progress/kendo-angular-upload';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { AppConstants } from '../../constants/constants';
import { ApiErrorService } from '../../services/apierror.service';
import { ToasterService } from '../../services/toaster.service';
import { ApiErrorServiceMock } from '../../test-mocks/apierrorservice-mock';
import { ToasterMock } from '../../test-mocks/toasterservice-mock';
import { DocumentsUploadComponent } from './documents-upload.component';

// tslint:disable-next-line:no-big-function
describe('DocumentsUploadComponent', () => {
  let component: DocumentsUploadComponent;
  let fixture: ComponentFixture<DocumentsUploadComponent>;
  let toasterService: ToasterService;
  let appConstants: AppConstants;
  let apiErrorService: ApiErrorService;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, UploadModule],
      declarations: [DocumentsUploadComponent],
      providers: [
        { provide: ApiErrorService, useClass: ApiErrorServiceMock },
        { provide: ToasterService, useClass: ToasterMock },
        AppConstants,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsUploadComponent);
    component = fixture.componentInstance;
    toasterService = TestBed.inject(ToasterService);
    apiErrorService = TestBed.inject(ApiErrorService);
    appConstants = TestBed.inject(AppConstants);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show toaster message when dropped multiple files on onSelectEvent method call', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const event = {
      prevented: false, files: [{
        extension: '.pdf', name: 'index.pdf',
        rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-bf3d-02a918bbd30',
      }, {
        extension: '.doc', name: 'test2.doc',
        rawFile: File, size: 1179, uid: 'f7efc3b9-9ae1-4e6c-845b-3e3b2aa4bb17',
      }],
      preventDefault: () => { return; },
    };
    component.onSelectEvent(event);
    expect(spyToasterService).toHaveBeenCalledWith('warning', appConstants.JOB_DETAILS_DOCUMENTS_MULTIPLE_FILE_UPLOAD_MESSAGE);
  });

  it('should show toaster message when selects restricted file from kendo upload on onSelectEvent call', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const event = {
      prevented: false, files: [{
        extension: '.cmd', name: 'index.cmd',
        rawFile: File, size: 1188,
      }],
      preventDefault: () => { return; },
    };
    component.onSelectEvent(event);
    expect(spyToasterService).toHaveBeenCalledWith('warning', appConstants.JOB_DETAILS_DOCUMENTS_FORBIDDEN_MESSAGE);
  });

  it('should upload selected file and move focus to notes from kendo upload on onSelectEvent', fakeAsync(() => {
    const event = {
      prevented: false, files: [{
        extension: '.pdf', name: 'index.pdf',
        rawFile: File, size: 1175,
      }],
    };
    (component.uploadDocument.fileList as any) = {
      files: [],
      count: 0,
      clear: () => { },
    };
    spyOn(component.notesField.nativeElement, 'focus');
    component.onSelectEvent(event);
    tick();
    expect(component.notesField.nativeElement.focus).toHaveBeenCalled();
  }));

  it('should user selects file twice from kendo upload remove previous file on onSelectEvent', fakeAsync(() => {
    const event = {
      prevented: false, files: [{
        extension: '.pdf', name: 'index.pdf',
        rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-bf3d-02918b5bd31',
      }],
    };
    (component.uploadDocument.fileList as any) = {
      files: [
        [{
          extension: '.cmd', name: 'index.cmd',
          rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-b3d-02a918b5bd3066',
        }],
        [{
          extension: '.pdf', name: 'index.pdf',
          rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-bf3d-02a918b5bd31',
        }],
      ],
      count: 2,
      clear: () => { },
    };
    spyOn(component.uploadDocument, 'removeFilesByUid');
    spyOn(component.notesField.nativeElement, 'focus');
    component.onSelectEvent(event);
    tick();
    expect(component.notesField.nativeElement.focus).toHaveBeenCalled();
  }));

  it('should show error toaster message when click on upload button without selecting file on calling uploadFiles method',
    fakeAsync(() => {
      const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
      const event = {
        fileList: [],
      };
      component.uploadFiles(event);
      tick();
      expect(spyToasterService).toHaveBeenCalledWith('error', appConstants.JOB_DETAILS_DOCUMENTS_REQUIRED_FIELD_MESSAGE);
    }));

  it('should upload file when click on upload button after selecting file on calling uploadFiles method', fakeAsync(() => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const fileList = [{
      extension: '.cmd', name: 'index.cmd',
      rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-bf3d-02a918b5bd30',
    }];
    const event = {
      fileList,
      uploadFiles: () => { },
    };
    spyOn(event, 'uploadFiles');
    (component.uploadDocument.fileList as any) = {
      files: [fileList],
      count: 1,
      clear: () => { },
    };
    component.isShowSelectedDocuments = true;
    component.previousDocumentId = 3;
    component.uploadFiles(event);
    tick();
    expect(event.uploadFiles).toHaveBeenCalled();
    expect(spyToasterService).not.toHaveBeenCalled();
  }));

  it('should show success toaster message after upload success from successEventHandler', () => {
    (component.uploadDocument.fileList as any) = {
      files: [
        [{
          extension: '.txt', name: 'index.txt',
          rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-b3d-02a918b5bd311',
        }],
      ],
      count: 1,
      name: 'index.txt',
      clear: () => { },
    };
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const event = { response: { status: 200 } };
    component.successEventHandler(event);
    expect(spyToasterService).toHaveBeenCalledWith('success', appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_SUCCESS_MESSAGE);
  });

  it('should not show success toaster message when no content in response after upload success from successEventHandler ', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const event1 = { response: { status: 204 } };
    component.successEventHandler(event1);
    expect(event1.response.status).toBe(204);
    expect(spyToasterService).not.toHaveBeenCalledWith('success', appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_SUCCESS_MESSAGE);
  });

  it('should show error message for error scenario while upload from errorEventHandler', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const spyApiError = spyOn(apiErrorService, 'show');
    const event = { response: { message: '404 error' } };
    component.errorEventHandler(event);
    expect(spyApiError).toHaveBeenCalledWith(event.response.message);
    expect(spyToasterService).toHaveBeenCalledWith('error', appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_ERROR_MESSAGE);
  });

  it('should set documentWarning true on onSelectEvent', fakeAsync(() => {
    const event = {
      prevented: false, files: [{
        extension: '.pdf', name: 'index.pdf',
        rawFile: File, size: 1175,
      }],
    };
    component.documentList = [{ documentName: 'index.pdf', isLinked: true }];
    component.onSelectEvent(event);
    tick();
    expect(component.documentWarning).toBe(true);
  }));

  it('should set documentWarning to true on onSelectEvent', () => {
    const event = {
      prevented: false, files: [{}],
    };
    component.removeEventHandler(event);
    expect(component.selectedDocumentName).toBe('');
  });

  it('should emit downloadDocument on calling downloadSelectedDocument method', () => {
    const event = {
      prevented: false, files: [{}],
    };
    const spy = spyOn(component.downloadDocument, 'emit');
    component.multiselect = { preventDefault: false, toggle() { } };
    component.downloadSelectedDocument(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should set selectedDocuments from documentList on calling ngOnChanges method', () => {
    component.uploadedDocumentName = 'test.txt';
    component.isShowSelectedDocuments = true;
    component.documentList = [{ documentName: 'test.txt', documentId: 1, isLinked: true },
    { documentName: 'test1.txt', documentId: 2 }];
    component.ngOnChanges();
    expect(component.selectedDocuments[0].documentName).toBe('test.txt');
    expect(component.selectedDocuments[0].isOverwriteDocument).toBe(true);
  });

  it('should set selectedDocuments length 0 on calling ngOnChanges method', () => {
    component.uploadedDocumentName = '';
    component.ngOnChanges();
    expect(component.selectedDocuments.length).toBe(0);
  });

  it('should set isOverwriteDocument to true from documentList on calling ngOnChanges method', () => {
    component.uploadedDocumentName = 'cost1.txt';
    component.isShowSelectedDocuments = true;
    component.documentList = [{ documentName: 'cost.txt', documentId: 1, isOverwriteDocument: true },
    { documentName: 'cost1.txt', documentId: 2, isOverwriteDocument: true }];
    component.ngOnChanges();
    expect(component.selectedDocuments[0].isOverwriteDocument).toBe(true);
  });

  it('should set documentWarning to false on calling uploadSelectedDocument method', () => {
    (component.uploadDocument.fileList as any) = {
      files: [
        [{
          extension: '.txt', name: 'index123.txt',
          rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-b3d-02a918b5bd30',
        }],
      ],
      count: 1,
      clear: () => { },
    };
    component.documentList = [
      { documentName: 'index123.txt', documentId: 1, isLinked: true },
      { documentName: 'cost11.txt', documentId: 2, isLinked: false }];
    component.uploadSelectedDocument('yes');
    expect(component.documentWarning).toBe(false);
  });

  it('should user selects file twice from kendo upload remove previous file on onSelectEvent', fakeAsync(() => {
    (component.uploadDocument.fileList as any) = {
      files: [
        [{
          extension: '.cmd', name: 'index1.txt',
          rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-b3d-02a918b5bd30',
        }],
      ],
      count: 1,
      clear: () => { },
    };
    spyOn(component.uploadDocument, 'removeFilesByUid');
    component.uploadSelectedDocument('no');
    tick();
    expect(component.documentWarning).toBe(false);
  }));

  it('should emit selectedDocumentList on calling onValueChange method', () => {
    component.selectedDocuments = [{ documentName: 'costitem.txt' }];
    const spy = spyOn(component.selectedDocumentList, 'emit');
    component.onValueChange();
    expect(spy).toHaveBeenCalled();
  });

  it('should set length 1 for selectedDocuments when upload existing selected document on calling ngOnChanges method', () => {
    const fileName = 'cost11.txt';
    component.uploadedDocumentName = fileName;
    component.selectedDocuments = [{ documentName: fileName, documentId: 1 }];
    component.isShowSelectedDocuments = true;
    component.documentList = [{ documentName: fileName, documentId: 1 }, { documentName: 'cost1.txt', documentId: 2 }];
    component.ngOnChanges();
    expect(component.selectedDocuments.length).toBe(1);
  });

  it('should set selectedDocuments on calling ngOnInit method', () => {
    component.selectedDocumentsOnEdit = [
      {
        workPackageId: 1675020,
        uploadedUserId: null,
        uploadedBy: 'ccxxfq',
        notes: null,
        documentKey: null,
        documentName: 'sample.PNG',
        documentVersion: null,
        documentSource: null,
        documentId: 144,
        uploadedDate: '2020-05-24T12:35:49',
        documentCount: 19,
        isLinked: false,
        previousDocumentId: 0,
      },
    ];
    component.ngOnInit();
    expect(component.selectedDocuments).toBe(component.selectedDocumentsOnEdit);
  });
});
