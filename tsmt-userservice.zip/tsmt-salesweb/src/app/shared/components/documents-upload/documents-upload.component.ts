import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { UploadComponent } from '@progress/kendo-angular-upload';
import { AppConstants } from '../../constants/constants';
import { ApiErrorService } from '../../services/apierror.service';
import { ToasterService } from '../../services/toaster.service';

@Component({
  selector: 'app-documents-upload',
  templateUrl: './documents-upload.component.html',
  styleUrls: ['./documents-upload.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DocumentsUploadComponent implements OnInit, OnChanges {
  @ViewChild('notes') notesField: ElementRef;
  @ViewChild('uploadDocument') uploadDocument: UploadComponent;
  @ViewChild('multiselect') multiselect: any;
  @Input() uploadUrl: any;
  @Input() isShowMaxChar: boolean;
  @Input() maxChars: number;
  @Input() documentList: any;
  @Input() isShowSelectedDocuments: boolean;
  @Input() selectedDocumentsOnEdit: any;
  @Output() downloadDocument: EventEmitter<any> = new EventEmitter();
  @Output() fetchDocumentList: EventEmitter<any> = new EventEmitter();
  @Output() selectedDocumentList: EventEmitter<any> = new EventEmitter();
  public documentsForm: FormGroup;
  public documentNotes = '';
  public uploadSaveUrl = '';
  public uploadRemoveUrl = '';
  public selectedDocuments = [];
  public uploadedDocumentName: string;
  public documentWarning = false;
  public selectedDocumentName: string;
  public previousDocumentId: number;
  constructor(
    public apiErrorService: ApiErrorService,
    public toasterService: ToasterService,
    private appConstants: AppConstants) { }

  ngOnInit() {
    if (this.selectedDocumentsOnEdit) {
      this.getSelectedDocuments();
    }
  }

  // handles on document select event
  onSelectEvent(event: any) {
    // when drop multiple files simultaneously show warning toaster message
    this.previousDocumentId = 0;
    if (event.files.length > 1) {
      event.preventDefault();
      this.toasterService.setToaster('warning', this.appConstants.JOB_DETAILS_DOCUMENTS_MULTIPLE_FILE_UPLOAD_MESSAGE);
      // when drop or select restricted file show warning toaster message
    } else if (this.appConstants.JOB_DETAILS_DOCUMENTS_FORBIDDEN_FILE_LIST.filter((x) => x === event.files[0].extension).length > 0) {
      event.preventDefault();
      this.toasterService.setToaster('warning', this.appConstants.JOB_DETAILS_DOCUMENTS_FORBIDDEN_MESSAGE);
      // when drop or select existing uploaded file we show the confirmation message window
      // if user click yes we upload this file otherwise remove from select window
    } else if (this.documentList && this.documentList.filter((x) => x.documentName === event.files[0].name && x.isLinked).length > 0) {
      this.selectedDocumentName = event.files[0].name;
      this.documentWarning = true;
    } else {
      // After selecting file remove existing file from kendo files list if exists
      // use timeout for kendo upload count evalation
      setTimeout(() => {
        if (this.uploadDocument.fileList.count > 1) {
          this.uploadDocument.removeFilesByUid((this.uploadDocument.fileList.files[0][0].uid));
        }
        // we set files count in work package properties page component for documentStatus variable
        // this.documentSelectedStatus.emit({ filesCount: this.uploadDocument.fileList.count });
      });
      this.notesField.nativeElement.focus();
    }
  }

  // upload document when clicked on upload button
  uploadFiles(uploadEvent: any) {
    if (this.isShowSelectedDocuments) {
      this.uploadSaveUrl = this.uploadUrl + this.documentNotes + '&previousDocumentId=' + this.previousDocumentId;
    } else {
      this.uploadSaveUrl = this.uploadUrl + this.documentNotes;
    }
    setTimeout(() => {
      if (this.uploadDocument.fileList.count > 0) {
        uploadEvent.uploadFiles();
      } else {
        // when no file selected from kendo upload control user click on upload button we should so required validation message
        this.toasterService.setToaster('error', this.appConstants.JOB_DETAILS_DOCUMENTS_REQUIRED_FIELD_MESSAGE);
      }
    });
  }

  // file successfully uploaded we show success toaster message
  successEventHandler(e: any) {
    if (e.response.status === 200) {
      this.toasterService.setToaster('success', this.appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_SUCCESS_MESSAGE);
      this.uploadedDocumentName = this.uploadDocument.fileList.files[0][0].name;
      // after uploaded files we clear files and notes
      setTimeout(() => {
        this.uploadDocument.clearFiles();
        // we set files count value in work package properties component for documentStatus variable
        // this.documentSelectedStatus.emit({ filesCount: 0 });
      });
      this.documentNotes = '';
      this.fetchDocumentList.emit();
    }
  }
  // if we have any error after uploaded files we show error toaster message
  errorEventHandler(e: any) {
    this.apiErrorService.show(e.response.message);
    this.toasterService.setToaster('error', this.appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_ERROR_MESSAGE);
  }
  // remove selected document
  removeEventHandler(e) {
    this.selectedDocumentName = '';
  }
  // download selected document
  downloadSelectedDocument(event) {
    this.multiselect.toggle(false);
    this.downloadDocument.emit(event);
  }

  ngOnChanges() {
    // select uploaded document at multi select control
    if (this.uploadedDocumentName && this.isShowSelectedDocuments) {
      const filterUploadedDocument = this.documentList.filter((x) => x.documentName === this.uploadedDocumentName);
      // check uploaded document is already added or not at selectedDocuments
      // if already added in selectedDocuments we should not add again.
      if (filterUploadedDocument[0] && !this.selectedDocuments.filter((list) => list.documentName
        === (filterUploadedDocument[0].documentName)).length) {
        if (filterUploadedDocument[0].isLinked) {
          filterUploadedDocument[0].isOverwriteDocument = true;
        }
        this.selectedDocuments.push(filterUploadedDocument[0]);
      } else {
        const index = this.selectedDocuments.findIndex((x) => x.documentName === this.uploadedDocumentName);
        this.selectedDocuments.splice(index, 1);
        filterUploadedDocument[0].isOverwriteDocument = true;
        this.selectedDocuments.push(filterUploadedDocument[0]);
      }
      this.uploadedDocumentName = '';
      this.onValueChange();
    }
  }

  // select document when user confirms on clicking yes buttton otherwise not
  uploadSelectedDocument(status: string) {
    // select document when status is 'yes'
    if (status !== 'yes') {
      this.uploadDocument.removeFilesByUid(this.uploadDocument.fileList.files[0][0].uid);
    } else {
      this.previousDocumentId = this.documentList.find((x) => x.documentName ===
        this.uploadDocument.fileList.files[0][0].name && x.isLinked).documentId;
    }
    this.documentWarning = false;
  }
  // send selected document list for parent component
  onValueChange() {
    this.selectedDocumentList.emit(this.selectedDocuments);
  }
  /* To bind selected documents on edit of cost item */
  getSelectedDocuments(): void {
    this.selectedDocuments = this.selectedDocumentsOnEdit;
  }
}
