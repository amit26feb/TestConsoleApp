import { AfterViewInit, Component, ElementRef, EventEmitter, HostListener } from '@angular/core';
import { Input, OnChanges, OnInit, Output, ViewChild } from '@angular/core';
import { JobCoordinationValidationService } from '../../services/job-coordination-validation.service';
import { AutoSaveWidget } from '../autosave-widget/autosave-widget';
import { IBid } from './../../../modules/jobs-list-master/models/coordinate-job.model';

@Component({
    selector: 'app-coordinate-bids',
    templateUrl: './coordinate-bids.component.html',
    styleUrls: ['./coordinate-bids.component.scss'],
})
export class CoordinateBidsComponent extends AutoSaveWidget implements OnInit, AfterViewInit, OnChanges {
    @Input() bids: IBid[];
    pageCount = 0;
    currentPage = 0;
    left = 0;
    itemsPerPage = 5;
    itemMargin = 3;
    @ViewChild('bidsview') viewportViewChild: ElementRef;
    bidsContainerElement: HTMLElement;
    @Output() bidSelectionChange: EventEmitter<IBid[]> = new EventEmitter();
    @Output() save: EventEmitter<any> = new EventEmitter<any>();

    constructor(elementRef: ElementRef, private jobCoordinationValidationService: JobCoordinationValidationService) {
        super(elementRef);
    }

    ngOnInit() {
        this.setBidsValidationResult(this.getSelectedBids());
        this.setDisableStatusInBids();
    }

    ngOnChanges() {
        this.setDisableStatusInBids();
    }

    ngAfterViewInit() {
        this.updateLayout();
    }

    @HostListener('window:orientationchange')
    updateLayout() {
        setTimeout(() => {
            if (this.bids && this.bids.length > 0) {
                this.bidsContainerElement = this.viewportViewChild.nativeElement;
                const containerWidth = this.bidsContainerElement.offsetWidth;
                if (containerWidth >= 768) {
                    this.itemsPerPage = 5;
                } else if (containerWidth >= 576) {
                    this.itemsPerPage = 3;
                } else {
                    this.itemsPerPage = 1;
                }
                this.pageCount = Math.ceil(this.bids.length / this.itemsPerPage);
                this.setItemWidth();
            }
        });
    }

    next() {
        if (this.currentPage < this.pageCount - 1) {
            this.currentPage += 1;
            this.setLeft();
        }
    }

    prev() {
        if (this.currentPage > 0) {
            this.currentPage -= 1;
            this.setLeft();
        }
    }

    setLeft() {
        this.left = -(this.bidsContainerElement.offsetWidth * this.currentPage);
    }

    setItemWidth() {
        const items = this.bidsContainerElement.querySelectorAll('li');
        const spaceForMargin = this.itemMargin * 2 * this.itemsPerPage;
        const containerWidth = this.bidsContainerElement.offsetWidth;
        const itemWidth = (containerWidth - spaceForMargin) / this.itemsPerPage;
        items.forEach((item) => {
            item.style.width = itemWidth + 'px';
        });
    }

    handleBidSelectionChange(bid: IBid) {
        const selectedBids = this.getSelectedBids();
        if (!this.isReadOnly) {
            this.isEdited = true;
            this.bidSelectionChange
                .emit(selectedBids);
        }
        this.setBidsValidationResult(selectedBids);
        this.setDisableStatus(bid);
    }

    getSelectedBids(): IBid[] {
        return this.bids.filter((bid) => bid.isBidInCoordinationJob);
    }

    saveData() {
        this.save.emit(this.getSelectedBids());
    }

    setBidsValidationResult(selectedBids: IBid[]): void {
        const isAtleastOneBidSelected = selectedBids.length > 0;
        const areAllSelectedBidsValid = !selectedBids.some((bid) => !bid.isValid);
        const isValidSelection = isAtleastOneBidSelected && areAllSelectedBidsValid;
        this.jobCoordinationValidationService.setValidBidsSelection(isValidSelection);
    }

    setDisableStatusInBids(): void {
        this.bids.forEach((bid) => {
            this.setDisableStatus(bid);
        });
    }

    setDisableStatus(bid: IBid): void {
        // If bid is valid, enable selection of the bid
        // If bid is invalid and is already selected, enable deselection of the bid
        const enableBidSelection = bid.isValid || bid.isBidInCoordinationJob;
        bid.isDisabled = this.isReadOnly || !enableBidSelection;
    }
}
