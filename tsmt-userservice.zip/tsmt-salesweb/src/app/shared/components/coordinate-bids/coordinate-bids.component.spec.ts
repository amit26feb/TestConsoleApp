import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ElementRef } from '@angular/core';
import { ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { IBid } from './../../../modules/jobs-list-master/models/coordinate-job.model';
import { AppConstants } from './../../../shared/constants/constants';
import { JobCoordinationValidationService } from './../../services/job-coordination-validation.service';
import { CoordinateBidsComponent } from './coordinate-bids.component';

// tslint:disable-next-line: no-big-function
describe('CoordinateBidsComponent', () => {
    let component: CoordinateBidsComponent;
    let fixture: ComponentFixture<CoordinateBidsComponent>;
    let injector: TestBed;
    let jobCoordinationValidationService: JobCoordinationValidationService;
    const originReset = TestBed.resetTestingModule;
    const testCoordinationBidsInput: IBid[] = [];
    const bidCheckBoxClass = 'bid-checkbox';
    for (let i = 0; i < 20; i++) {
        testCoordinationBidsInput[i] = {} as IBid;
        testCoordinationBidsInput[i].bidAlternateId = i,
            testCoordinationBidsInput[i].bidName = 'bid' + i,
            testCoordinationBidsInput[i].isCurrentBid = false,
            testCoordinationBidsInput[i].isBidInCoordinationJob = true;
        if (i === 0) {
            testCoordinationBidsInput[i].isCurrentBid = true;
        }
    }
    const item1: HTMLElement = { style: { width: '0' } } as HTMLElement;
    const item2: HTMLElement = { style: { width: '0' } } as HTMLElement;

    configureTestSuite((() => {
        TestBed.configureTestingModule({
            imports: [FormsModule, HttpClientTestingModule, TooltipModule],
            declarations: [CoordinateBidsComponent],
            providers: [
                {
                    provide: AppConstants, useValue: { API_BASE_URL_JOB: '' },
                },
                JobCoordinationValidationService,
            ],
        });
    }));

    beforeEach(() => {
        injector = getTestBed();
        fixture = TestBed.createComponent(CoordinateBidsComponent);
        jobCoordinationValidationService = injector.inject(JobCoordinationValidationService);
        component = fixture.componentInstance;
        component.isReadOnly = false;
        component.bids = testCoordinationBidsInput;
        component.viewportViewChild = {} as ElementRef;
        component.viewportViewChild.nativeElement = {
            offsetWidth: 800,
            querySelectorAll(selector: string): NodeListOf<HTMLElement> {
                return [item1, item2] as any;
            },
        } as HTMLElement;
        component.ngAfterViewInit();
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should validate bids on load', () => {
        const sampleBids = [{
            bidAlternateId: 159371,
            bidName: '2014 Bid',
            isBaseBid: false,
            isBidInCoordinationJob: true,
            isCurrentBid: true,
            isSubmitted: false,
            isDisabled: false,
        },
        ];
        component.bids = sampleBids;
        const spyBidsValidation = spyOn(component, 'setBidsValidationResult');
        const spyDisableStatus = spyOn(component, 'setDisableStatusInBids');
        component.ngOnInit();
        expect(spyBidsValidation).toHaveBeenCalledWith(sampleBids);
        expect(spyDisableStatus).toHaveBeenCalled();
    });

    it('should call setDisableStatusInBids on changes', () => {
        const spyDisableStatus = spyOn(component, 'setDisableStatusInBids');
        component.ngOnChanges();
        expect(spyDisableStatus).toHaveBeenCalled();
    });

    it('should disable bid checkbox if job is read only', fakeAsync(() => {
        const sampleBids = [{
            bidAlternateId: 159371,
            bidName: '2014 Bid',
            isBaseBid: false,
            isBidInCoordinationJob: true,
            isCurrentBid: true,
            isValid: true,
            isSubmitted: false,
            isDisabled: false,
        },
        ];
        component.isReadOnly = true;
        component.bids = sampleBids;
        fixture.detectChanges();
        component.ngAfterViewInit();
        tick();
        const element = document.getElementsByClassName(bidCheckBoxClass)[0];
        expect(element['disabled']).toBeDefined();
        expect(sampleBids[0].isDisabled).toBe(true);
    }));

    it('should disable bid checkbox if bid is not valid', fakeAsync(() => {
        const sampleBids = [{
            bidAlternateId: 159371,
            bidName: '2014 Bid',
            isBaseBid: false,
            isBidInCoordinationJob: false,
            isCurrentBid: true,
            isValid: false,
            isSubmitted: false,
            isDisabled: false,
        },
        ];
        component.isReadOnly = false;
        component.bids = sampleBids;
        fixture.detectChanges();
        component.ngAfterViewInit();
        tick();
        const element = document.getElementsByClassName(bidCheckBoxClass)[0];
        expect(element['disabled']).toBeDefined();
        expect(sampleBids[0].isDisabled).toBe(true);
    }));

    it('should enable deselection of bid checkbox if bid is not valid and is already selected', fakeAsync(() => {
        const sampleBids = [{
            bidAlternateId: 159371,
            bidName: '2014 Bid',
            isBaseBid: false,
            isBidInCoordinationJob: true,
            isCurrentBid: true,
            isValid: false,
            isSubmitted: false,
            isDisabled: true,
        },
        ];
        component.isReadOnly = false;
        component.bids = sampleBids;
        fixture.detectChanges();
        component.ngAfterViewInit();
        tick();
        const element = document.getElementsByClassName(bidCheckBoxClass)[0];
        expect(element['disabled']).toBe(false);
        expect(sampleBids[0].isDisabled).toBe(false);
    }));

    it('should enable bid checkbox if job is not read only and bid is valid', fakeAsync(() => {
        const sampleBids = [{
            bidAlternateId: 159371,
            bidName: '2014 Bid',
            isBaseBid: false,
            isBidInCoordinationJob: true,
            isCurrentBid: true,
            isValid: true,
            isSubmitted: false,
            isDisabled: true,
        },
        ];
        component.isReadOnly = false;
        component.bids = sampleBids;
        fixture.detectChanges();
        component.ngAfterViewInit();
        tick();
        const element = document.getElementsByClassName(bidCheckBoxClass)[0];
        expect(element['disabled']).toBe(false);
        expect(sampleBids[0].isDisabled).toBe(false);
    }));

    it('should set number of pages after view initialized', fakeAsync(() => {
        component.ngAfterViewInit();
        tick();
        expect(component.pageCount).toBe(Math.ceil(testCoordinationBidsInput.length / component.itemsPerPage));
    }));

    it('should load the next page when next is clicked', fakeAsync(() => {
        component.updateLayout();
        tick();
        component.next();
        expect(component.currentPage).toBe(1);
        expect(component.left).toBe(-800);
        expect(item1.style.width).toBe('154px');
    }));

    it('should do nothing when clicked next on the last page', () => {
        component.currentPage = component.pageCount - 1;
        component.next();
        expect(component.currentPage).toBe(component.pageCount - 1);
    });

    it('should load the previous page when prev is clicked', fakeAsync(() => {
        component.currentPage = 3;
        component.updateLayout();
        tick();
        component.prev();
        expect(component.currentPage).toBe(2);
        expect(component.left).toBe(-1600);
        expect(item1.style.width).toBe('154px');
    }));

    it('should do nothing when clicked prev on the first page', () => {
        component.prev();
        expect(component.currentPage).toBe(0);
    });

    it('should not load the carousel when there is no bid', () => {
        fixture = TestBed.createComponent(CoordinateBidsComponent);
        component = fixture.componentInstance;
        component.bids = null;
        expect(component.pageCount).toBe(0);
    });

    it('should load the carousel when there is bid', fakeAsync(() => {
        component.bids = testCoordinationBidsInput;
        component.updateLayout();
        tick();
        expect(component.pageCount).toBeGreaterThan(0);
    }));

    it('should set number of items per page as per the width of the container', fakeAsync(() => {
        component.viewportViewChild.nativeElement.offsetWidth = 800;
        component.updateLayout();
        tick();
        expect(component.itemsPerPage).toBe(5);

        component.viewportViewChild.nativeElement.offsetWidth = 600;
        component.updateLayout();
        tick();
        expect(component.itemsPerPage).toBe(3);

        component.viewportViewChild.nativeElement.offsetWidth = 500;
        component.updateLayout();
        tick();
        expect(component.itemsPerPage).toBe(1);
    }));

    it('should emit an event with selected bids when bid selections are changed', () => {
        const testBid1: IBid = {
            bidAlternateId: 123,
            isCurrentBid: false,
            bidName: 'Test Bid 1',
            isBidInCoordinationJob: true,
            isSubmitted: false,
            isDisabled: false,
        };
        const testBid2: IBid = {
            bidAlternateId: 456,
            isCurrentBid: false,
            bidName: 'Test Bid 2',
            isBidInCoordinationJob: false,
            isSubmitted: false,
            isDisabled: false,
        };
        component.bids = [testBid1, testBid2];
        spyOn(component.bidSelectionChange, 'emit');
        component.isEdited = false;
        component.handleBidSelectionChange(testBid1);
        expect(component.bidSelectionChange.emit).toHaveBeenCalledWith([testBid1]);
        expect(component.isEdited).toBe(true);
    });

    it('should validate bids when bid selections are changed', () => {
        const sampleBids = [{
            bidAlternateId: 159371,
            bidName: '2014 Bid',
            isBaseBid: false,
            isBidInCoordinationJob: true,
            isCurrentBid: true,
            isSubmitted: false,
            isDisabled: false,
        }];
        component.bids = sampleBids;
        const spySelectedBids = spyOn(component, 'setBidsValidationResult');
        const spyDisableStatus = spyOn(component, 'setDisableStatus');
        component.handleBidSelectionChange(sampleBids[0]);
        expect(spySelectedBids).toHaveBeenCalledWith(sampleBids);
        expect(spyDisableStatus).toHaveBeenCalledWith(sampleBids[0]);
    });


    it('should not emit an event if the component is read only', () => {
        component.isReadOnly = true;
        const testBid: IBid = {
            bidAlternateId: 1223,
            isCurrentBid: false,
            bidName: 'Test Bid',
            isBidInCoordinationJob: true,
            isSubmitted: false,
            isDisabled: false,
        };
        component.bids = [testBid];
        spyOn(component.bidSelectionChange, 'emit');
        component.handleBidSelectionChange(testBid);
        expect(component.bidSelectionChange.emit).not.toHaveBeenCalled();
    });

    it('should emit save event with selected bids when saveData method is called', () => {
        const testBid1: IBid = {
            bidAlternateId: 123,
            isCurrentBid: false,
            bidName: 'Test Bid 1',
            isBidInCoordinationJob: true,
            isSubmitted: false,
            isDisabled: false,
        };
        const testBid2: IBid = {
            bidAlternateId: 456,
            isCurrentBid: false,
            bidName: 'Test Bid 2',
            isBidInCoordinationJob: false,
            isSubmitted: false,
            isDisabled: false,
        };
        component.bids = [testBid1, testBid2];
        const spy = spyOn(component.save, 'emit');
        component.saveData();
        expect(spy).toHaveBeenCalledWith([testBid1]);
    });

    it('should set isValidBidsSelection to true if atleast one bid is selected and all selected bids are valid', () => {
        const selectedBids: IBid[] = [
            { bidName: 'test bid 1', isValid: true } as IBid,
            { bidName: 'test bid 2', isValid: true } as IBid,
        ];
        jobCoordinationValidationService.submitButtonValidationFlags.isValidBidsSelection = false;
        const spy = spyOn(jobCoordinationValidationService, 'setValidBidsSelection').and.callThrough();
        component.setBidsValidationResult(selectedBids);
        expect(spy).toHaveBeenCalledWith(true);
        expect(jobCoordinationValidationService.submitButtonValidationFlags.isValidBidsSelection).toBe(true);
    });

    it('should set isValidBidsSelection to false if no bids are selected', () => {
        const selectedBids: IBid[] = [];
        jobCoordinationValidationService.submitButtonValidationFlags.isValidBidsSelection = true;
        const spy = spyOn(jobCoordinationValidationService, 'setValidBidsSelection').and.callThrough();
        component.setBidsValidationResult(selectedBids);
        expect(spy).toHaveBeenCalledWith(false);
        expect(jobCoordinationValidationService.submitButtonValidationFlags.isValidBidsSelection).toBe(false);
    });

    it('should set isValidBidsSelection to false if an invalid bid is selected', () => {
        const selectedBids: IBid[] = [
            { bidName: 'test bid 1', isValid: true } as IBid,
            { bidName: 'test bid 2', isValid: false } as IBid,
        ];
        jobCoordinationValidationService.submitButtonValidationFlags.isValidBidsSelection = true;
        const spy = spyOn(jobCoordinationValidationService, 'setValidBidsSelection').and.callThrough();
        component.setBidsValidationResult(selectedBids);
        expect(spy).toHaveBeenCalledWith(false);
        expect(jobCoordinationValidationService.submitButtonValidationFlags.isValidBidsSelection).toBe(false);
    });
});
