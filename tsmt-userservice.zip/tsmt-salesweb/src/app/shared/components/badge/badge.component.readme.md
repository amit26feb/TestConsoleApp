# Badge Component #

## Usage ##
<app-badge
    [message] = "variable with message"
    [badgeType] = "'primary'"
    [position] = "'float-left'"
    [hoverMessage] = "'somthings something count'"
>
</app-badge>

* badgeType - supported values
     * badge-primary
     * badge-secondary
     * badge-danger
     * badge-warning
     * badge-info
* position
     * float-left
     * float-right
* message
     * any string or number
* hoverMessage
     * any string you want