import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-panel-loader',
  templateUrl: './panel-loader.component.html',
  styleUrls: ['./panel-loader.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class PanelLoaderComponent implements OnInit {
  @Input() isVisible: boolean;
  @Input() type: string;
  @Input() themeColor: string;
  @Input() size: string;
  constructor() { }

  ngOnInit(): void {
  }

}
