import { ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { PanelLoaderComponent } from './panel-loader.component';

describe('PanelLoaderComponent', () => {
  let component: PanelLoaderComponent;
  let fixture: ComponentFixture<PanelLoaderComponent>;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [PanelLoaderComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PanelLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
