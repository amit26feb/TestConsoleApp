import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { JobCoordinationValidationService } from '../../services/job-coordination-validation.service';
import { AppConstants } from './../../../shared/constants/constants';
import { SubmissionNotesComponent } from './submission-notes.component';

// tslint:disable-next-line:no-big-function
describe('SubmissionNotesComponent', () => {
  let component: SubmissionNotesComponent;
  let fixture: ComponentFixture<SubmissionNotesComponent>;
  let injector: TestBed;
  let jobCoordinationValidationService: JobCoordinationValidationService;
  configureTestSuite((() => {

    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, HttpClientTestingModule],
      declarations: [SubmissionNotesComponent],
      providers: [
        {
          provide: AppConstants, useValue: { API_BASE_URL_JOB: '' },
        },
        JobCoordinationValidationService,
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(SubmissionNotesComponent);
    component = fixture.componentInstance;
    jobCoordinationValidationService = injector.inject(JobCoordinationValidationService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call setSubmissionNotesFormState in ngOnInit', () => {
    const spyEnableOrDisableForm = spyOn(component, 'setSubmissionNotesFormState');
    component.ngOnInit();
    expect(spyEnableOrDisableForm).toHaveBeenCalled();
  });

  it('should validate submission notes on load', () => {
    const spyValidateSubmissionNotes = spyOn(component, 'checkSubmissionNotesValidity');
    component.ngOnInit();
    expect(spyValidateSubmissionNotes).toHaveBeenCalled();
  });

  it('should call setSubmissionNotesFormState in ngOnChanges', () => {
    component.ngOnInit();
    const spyEnableOrDisableForm = spyOn(component, 'setSubmissionNotesFormState');
    component.ngOnChanges();
    expect(spyEnableOrDisableForm).toHaveBeenCalled();
  });

  it('should assign formData to notes control in submissionNotesForm on calling ngOnInit', () => {
    component.formData = { noteLine: 'this is sample text' };
    component.ngOnInit();
    expect(component.submissionNotesForm.controls['notes'].value).toBe(component.formData.noteLine);
  });

  it('should assign formData to notes control in submissionNotesForm on calling ngOnChanges', () => {
    component.formData = { noteLine: 'this is sample text' };
    component.ngOnChanges();
    expect(component.submissionNotesForm.controls['notes'].value).toBe(component.formData.noteLine);
  });

  it('should disable the text area if isReadOnly flag is true', () => {
    component.ngOnInit();
    component.isReadOnly = true;
    component.setSubmissionNotesFormState();
    expect(component.submissionNotesForm.disabled).toBe(true);
  });

  it('should enable the text area if isReadOnly flag is false', () => {
    component.ngOnInit();
    component.isReadOnly = false;
    component.setSubmissionNotesFormState();
    expect(component.submissionNotesForm.enabled).toBe(true);
  });

  it('should return false from isEventTargetOutsideComponent if the focused element is inside the component', () => {
    expect(component.isEventTargetOutsideComponent(fixture.debugElement.children[0].nativeElement)).toBe(false);
  });

  it('should return true from isEventTargetOutsideComponent if the focused element is outside the component', () => {
    expect(component.isEventTargetOutsideComponent(document.getRootNode())).toBe(true);
  });

  it('should set the formEdited flag to true when value is changed in form', fakeAsync(() => {
    component.submissionNotesForm.setValue({ notes: 'testNotes' });
    tick();
    expect(component.isFormEdited()).toBe(true);
  }));

  it('should not emit save when form is not edited and clicked outside component', () => {
    spyOn(component.save, 'emit');
    component.handleFocusChange({ target: document.getRootNode() });
    expect(component.isFormEdited()).toBe(false);
    expect(component.save.emit).not.toHaveBeenCalled();
  });

  it('should not emit save when form is not edited and clicked inside component', () => {
    spyOn(component.save, 'emit');
    component.handleFocusChange({ target: fixture.debugElement.children[0].nativeElement });
    expect(component.isFormEdited()).toBe(false);
    expect(component.save.emit).not.toHaveBeenCalled();
  });

  it('should not emit save when form is edited and clicked inside component', fakeAsync(() => {
    spyOn(component.save, 'emit');
    component.focusInside = true;
    component.submissionNotesForm.setValue({ notes: 'testNotes' });
    tick();
    component.handleFocusChange({ target: fixture.debugElement.children[0].nativeElement });
    tick();
    expect(component.isFormEdited()).toBe(true);
    expect(component.save.emit).not.toHaveBeenCalled();
  }));

  it('should emit save and reset form edit status when form is edited and clicked outside component', fakeAsync(() => {
    spyOn(component.save, 'emit');
    component.focusInside = true;
    const testNotes = 'test Notes';
    component.submissionNotesForm.setValue({ notes: testNotes });
    tick();
    expect(component.isFormEdited()).toBe(true);
    component.handleFocusChange({ target: document.getRootNode() });
    tick();
    expect(component.save.emit).toHaveBeenCalledWith(testNotes);
    expect(component.isFormEdited()).toBe(false);
    expect(component.focusInside).toBe(false);
  }));

  it('should return true from isAddDateAtStart() when old notes is empty', () => {
    component.oldNotes = '';
    component.submissionNotesForm.setValue({ notes: 'testNotes' });
    expect(component.isAddDateAtStart()).toBe(true);
  });

  it('should return true from isAddDateAtStart() when old notes is modified', () => {
    component.submissionNotesForm.setValue({ notes: 'test new Notes' });
    component.oldNotes = 'test notes';
    expect(component.isAddDateAtStart()).toBe(true);
  });

  it('should return true from isAddDateAtStart() when old notes is not at start', () => {
    component.submissionNotesForm.setValue({ notes: 'test new Notes test old notes' });
    component.oldNotes = 'test old notes';
    expect(component.isAddDateAtStart()).toBeTruthy();
  });

  it('should return false from isAddDateAtStart() when old notes is at start', () => {
    component.submissionNotesForm.setValue({ notes: 'test old notes test new Notes' });
    component.oldNotes = 'test old notes';
    expect(component.isAddDateAtStart()).toBe(false);
  });

  it('should add date to the notes at start in getNotesWithDateAdded()', () => {
    const testNotes = 'test new Notes test old Notes';
    component.submissionNotesForm.setValue({ notes: testNotes });
    component.oldNotes = 'test old Notes';
    const notes = component.getNotesWithDateAdded();
    expect(notes.includes(component.oldNotes)).toBe(true);
    expect(notes.indexOf(testNotes)).toBeGreaterThan(0);
  });

  it('should add date to the notes after old notes in getNotesWithDateAdded()', () => {
    const testNotes = 'test old Notes\ntest new Notes';
    component.submissionNotesForm.setValue({ notes: testNotes });
    component.oldNotes = 'test old Notes';
    const notes = component.getNotesWithDateAdded();
    expect(notes.includes(component.oldNotes)).toBe(true);
    expect(notes.indexOf(component.oldNotes)).toBe(0);
  });

  it('should add new line to the submission notes when addNewLineInSubmissionNotes() called', () => {
    component.submissionNotesForm.setValue({ notes: 'testNotes' });
    component.addNewLineInSubmissionNotes();
    const notes: string = component.submissionNotesForm.controls['notes'].value;
    expect(notes.charAt(0)).toBe(component.newLine);
  });

  it('should remove new line to the submission notes when addNewLineInSubmissionNotes() called', () => {
    component.submissionNotesForm.setValue({ notes: component.newLine + 'testNotes' });
    component.removeNewLineInSubmissionNotes();
    const notes: string = component.submissionNotesForm.controls['notes'].value;
    expect(notes.charAt(0)).not.toBe(component.newLine);
  });

  it('should do nothing when clicked in form and form is read only', () => {
    component.isReadOnly = true;
    component.handleFocusChange({ target: fixture.debugElement.children[0].nativeElement });
    expect(component.focusInside).toBe(false);
  });

  it('should set isSubmissionNotesValid to true if coordination status is other than Not Submitted', () => {
    component.isStatusNotSubmitted = false;
    component.checkSubmissionNotesValidity();
    expect(component.isSubmissionNotesValid).toBe(true);
  });

  it('should set isSubmissionNotesValid to false if submission notes is empty', () => {
    component.isStatusNotSubmitted = true;
    const sampleNote = 'Test string';
    const enteredNote = '';
    component.originalSubmissionNotes = sampleNote;
    component.submissionNotesForm.controls.notes.setValue(enteredNote);
    component.checkSubmissionNotesValidity();
    expect(component.isSubmissionNotesValid).toBe(false);
  });

  it('should set isSubmissionNotesValid to false if new entry has not been made after last submission', () => {
    component.isStatusNotSubmitted = true;
    const sampleNote = 'This is a test string';
    const enteredNote = sampleNote;
    component.originalSubmissionNotes = sampleNote;
    component.submissionNotesForm.controls.notes.setValue(enteredNote);
    component.checkSubmissionNotesValidity();
    expect(component.isSubmissionNotesValid).toBe(false);
  });

  it('should set isSubmissionNotesValid to true if new entry has been made after last submission', () => {
    component.isStatusNotSubmitted = true;
    const sampleNote = 'This is a test string';
    const enteredNote = 'This is a new test string';
    component.originalSubmissionNotes = sampleNote;
    component.submissionNotesForm.controls.notes.setValue(enteredNote);
    component.checkSubmissionNotesValidity();
    expect(component.isSubmissionNotesValid).toBe(true);
  });

  it('should add date to the notes when getNotesWithDate method is called', () => {
    const testNotes = 'test Notes';
    component.submissionNotesForm.setValue({ notes: testNotes });
    const year = new Date().getFullYear().toString();
    const notes = component.getNotesWithDate();
    expect(notes.includes(year)).toBe(true);
  });
});
