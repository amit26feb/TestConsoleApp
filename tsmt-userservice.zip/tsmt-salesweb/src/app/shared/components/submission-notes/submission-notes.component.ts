import {
  AfterViewInit, Component, ElementRef, EventEmitter,
  HostListener, Input, OnChanges, OnInit, Output, ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as moment from 'moment-timezone';
import { ISubmissionNotes } from '../../../modules/jobs-list-master/models/coordinate-job.model';
import { JobCoordinationValidationService } from '../../services/job-coordination-validation.service';

@Component({
  selector: 'app-submission-notes',
  templateUrl: './submission-notes.component.html',
  styleUrls: ['./submission-notes.component.scss'],
})
export class SubmissionNotesComponent implements OnInit, OnChanges, AfterViewInit {
  public submissionNotesForm: FormGroup;
  @Input() formData: ISubmissionNotes;
  @Input() originalSubmissionNotes: any;
  @Input() isStatusNotSubmitted: boolean;
  @Input() isReadOnly: boolean;
  formEdited = false;
  @Output() save: EventEmitter<any> = new EventEmitter<any>();
  oldNotes = '';
  newLine = '\n';
  @ViewChild('notes') notesSection: ElementRef;
  focusInside = false;
  isSubmissionNotesValid: boolean;
  constructor(private fb: FormBuilder, private elementRef: ElementRef,
              private jobCoordinationValidationService: JobCoordinationValidationService) { }

  // To identify when the focus is moved out of component and then trigger save
  @HostListener('document:click', ['$event'])
  @HostListener('document:focusin', ['$event'])
  handleFocusChange(event) {
    if (this.isReadOnly) {
      return;
    }
    if (this.focusInside) {
      if (this.isEventTargetOutsideComponent(event.target)) {
        this.focusInside = false;
        // On focus out, remove the new line and save the notes if edited
        this.removeNewLineInSubmissionNotes();
        if (this.isFormEdited()) {
          this.save.emit(this.submissionNotesForm.controls['notes'].value);
          this.resetFormEditStatus();
        }
      }
    } else if (!this.isEventTargetOutsideComponent(event.target)) {
      this.focusInside = true;
      // On focus, add new line and place the cursor at the start of the notes text area
      this.addNewLineInSubmissionNotes();
      this.moveCursorInSubmissionNotesToFirstCharacter();
    }
  }

  addNewLineInSubmissionNotes() {
    const notes: string = this.submissionNotesForm.controls['notes'].value ? this.submissionNotesForm.controls['notes'].value : '';
    this.submissionNotesForm.controls['notes'].setValue(this.newLine + notes, { emitEvent: false });
  }

  removeNewLineInSubmissionNotes() {
    let notes: string = this.submissionNotesForm.controls['notes'].value;
    if (notes.charAt(0) === this.newLine) {
      notes = notes.substring(1, notes.length);
      this.submissionNotesForm.controls['notes'].setValue(notes, { emitEvent: false });
    }
  }

  moveCursorInSubmissionNotesToFirstCharacter() {
    setTimeout(() => {
      const notesElement = this.notesSection.nativeElement;
      notesElement.selectionStart = 0;
      notesElement.selectionEnd = 0;
    });
  }

  getNotesWithDateAdded() {
    let finalNotes = '';
    const dateTime = (moment().tz('America/Chicago').format('MM/DD/YYYY hh:mmA z'));
    const newNotes: string = this.submissionNotesForm.controls['notes'].value;
    if (this.isAddDateAtStart()) {
      finalNotes = dateTime + this.newLine + newNotes;
    } else {
      finalNotes = this.oldNotes + this.newLine;
      let addedNotes = newNotes.substring(this.oldNotes.length, newNotes.length);
      while (addedNotes.charAt(0) === this.newLine) {
        addedNotes = addedNotes.substring(1, addedNotes.length);
        finalNotes += this.newLine;
      }
      finalNotes += dateTime + this.newLine + addedNotes;
    }
    return finalNotes;
  }

  isAddDateAtStart() {
    if (this.oldNotes === '') { // Old notes is empty
      return true;
    }
    const newNotes: string = this.submissionNotesForm.controls['notes'].value;
    // Old notes is not present in the new notes
    // OR Old notes is not at the start in the new notes
    if (!newNotes.includes(this.oldNotes) || newNotes.indexOf(this.oldNotes) !== 0) {
      return true;
    }
    return false;
  }

  resetFormEditStatus() {
    this.setFormEdited(false);
  }

  setFormEdited(status: boolean) {
    this.formEdited = status;
  }

  isFormEdited() {
    return this.formEdited;
  }

  isEventTargetOutsideComponent(target): boolean {
    return !this.elementRef.nativeElement.contains(target);
  }

  ngOnInit() {
    this.submissionNotesForm = this.fb.group({
      notes: this.formData ? this.formData.noteLine : '',
    });
    this.setSubmissionNotesFormState();
    this.checkSubmissionNotesValidity();
  }

  ngOnChanges() {
    // set form state when job is unlocked
    if (this.submissionNotesForm) {
      const noteLine = this.formData ? this.formData.noteLine : '';
      this.submissionNotesForm.controls.notes.setValue(noteLine);
      this.setSubmissionNotesFormState();
    }
    this.oldNotes = this.formData ? this.formData.noteLine : '';
  }

  ngAfterViewInit() {
    this.submissionNotesForm.valueChanges.subscribe(() => {
      this.setFormEdited(true);
    });
  }

  // enable or disable form based on read only state and crm job check
  setSubmissionNotesFormState() {
    this.isReadOnly ? this.submissionNotesForm.disable({ emitEvent: false }) : this.submissionNotesForm.enable({ emitEvent: false });
  }

  checkSubmissionNotesValidity() {
    if (this.isStatusNotSubmitted) {
      const newNotes = this.submissionNotesForm.controls.notes.value === null ? '' : this.submissionNotesForm.controls.notes.value;
      this.isSubmissionNotesValid = newNotes !== this.originalSubmissionNotes && newNotes !== '';
    } else {
      this.isSubmissionNotesValid = true;
    }
    this.jobCoordinationValidationService.setSubmissionNotesFlag(this.isSubmissionNotesValid);
  }

  getNotesWithDate(): string {
    const dateTime = (moment().tz('America/Chicago').format('MM/DD/YYYY hh:mmA z'));
    const notes: string = this.submissionNotesForm.controls['notes'].value;
    const updatedNotes = dateTime + this.newLine + notes;
    this.submissionNotesForm.controls['notes'].setValue(updatedNotes, { emitEvent: false });
    return updatedNotes;
  }
}
