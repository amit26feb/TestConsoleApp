import { Component } from '@angular/core';

@Component({
  selector: 'app-browser-support',
  templateUrl: './browser-support.component.html',
  styleUrls: ['./browser-support.component.scss'],
})
export class BrowserSupportComponent {

  public logoContent = [{
      imageURL: 'assets/images/chrome_logo.svg',
      browerName: 'Google Chrome',
    }, {
      imageURL: 'assets/images/firefox_logo.svg',
      browerName: 'Mozilla Firefox',
    }, {
      imageURL: 'assets/images/edge_logo.svg',
      browerName: 'Microsoft Edge',
    }, {
      imageURL: 'assets/images/safari_logo.svg',
      browerName: 'Safari 7+',
    }, {
      imageURL: 'assets/images/opera_logo.svg',
      browerName: 'Opera',
  }];

  constructor() { }

}
