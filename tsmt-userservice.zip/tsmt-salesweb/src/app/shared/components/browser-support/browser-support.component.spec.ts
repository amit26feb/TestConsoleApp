import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';

import { BrowserSupportComponent } from './browser-support.component';

describe('BrowserSupportComponent', () => {
  let component: BrowserSupportComponent;
  let fixture: ComponentFixture<BrowserSupportComponent>;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [BrowserSupportComponent],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrowserSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
