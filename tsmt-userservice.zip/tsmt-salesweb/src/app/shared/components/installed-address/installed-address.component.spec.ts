import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup } from '@angular/forms';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { InstalledAddressComponent } from './installed-address.component';

describe('InstalledAddressComponent', () => {
  let component: InstalledAddressComponent;
  let fixture: ComponentFixture<InstalledAddressComponent>;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [InstalledAddressComponent],
      providers: [FormBuilder],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [InputsModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstalledAddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call installedAddressForm method on calling ngOnInit method', () => {
    const spy = spyOn(component, 'createInstalledAddressForm');
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should disable installedAddressForm on calling ngOnInit method', () => {
    component.ngOnInit();
    expect(component.installedAddressForm.disabled).toBe(true);
  });

  it('should create installedAddressForm when createInstalledAddressForm method is called', () => {
    component.installedAddressForm = null;
    component.createInstalledAddressForm();
    expect(component.installedAddressForm).toBeDefined();
  });

});
