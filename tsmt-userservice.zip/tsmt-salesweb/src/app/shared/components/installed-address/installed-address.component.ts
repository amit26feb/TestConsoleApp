import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-installed-address',
  templateUrl: './installed-address.component.html',
  styleUrls: ['./installed-address.component.scss'],
})
export class InstalledAddressComponent implements OnInit {
  public installedAddressForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.createInstalledAddressForm();
  }

  createInstalledAddressForm() {
    this.installedAddressForm = this.fb.group({
      type: [''],
      country: [''],
      streetAddress1: [''],
      streetAddress2: [''],
      postalCode: [''],
      city: [''],
      state: [''],
      county: [''],
    });
    this.installedAddressForm.disable();
  }
}
