import { ElementRef, HostListener, Input, OnDestroy, Directive } from '@angular/core';
@Directive()
export abstract class AutoSaveWidget implements OnDestroy {
    @Input() isReadOnly = true;
    isEdited = false;

    constructor(private elementRef: ElementRef) {
    }

    ngOnDestroy() {
        if (!this.isReadOnly && this.isEdited) {
            this.saveData();
        }
    }

    // To identify when the focus is moved out of component and then trigger save
    @HostListener('document:click', ['$event'])
    @HostListener('document:focusin', ['$event'])
    handleFocusChange(event) {
        if (!this.isReadOnly && this.isEdited && this.isEventTargetOutsideComponent(event.target)) {
            this.saveData();
            this.isEdited = false;
        }
    }

    isEventTargetOutsideComponent(target): boolean {
        return !this.elementRef.nativeElement.contains(target);
    }

    abstract saveData();
}
