import { Component, ElementRef } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { AutoSaveWidget } from './autosave-widget';

@Component({
    template: `<div></div>`,
})
class TestAutoSaveWidgetComponent extends AutoSaveWidget {
    constructor(elementRef: ElementRef) {
        super(elementRef);
    }
    saveData() { }
}
describe('AutoSaveWidget', () => {
    let component: TestAutoSaveWidgetComponent;
    let fixture: ComponentFixture<TestAutoSaveWidgetComponent>;
    let injector: TestBed;
    const originReset = TestBed.resetTestingModule;

    configureTestSuite((() => {
        TestBed.configureTestingModule({
            declarations: [TestAutoSaveWidgetComponent],
        });
    }));

    beforeEach(() => {
        injector = getTestBed();
        fixture = TestBed.createComponent(TestAutoSaveWidgetComponent);
        component = fixture.componentInstance;
        component.isReadOnly = false;
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should not call saveData when component is not edited and clicked outside component', () => {
        component.isEdited = false;
        const spy = spyOn(component, 'saveData');
        component.handleFocusChange({ target: document.getRootNode() });
        expect(spy).not.toHaveBeenCalled();
    });

    it('should not call saveData when component is not edited and clicked inside component', () => {
        component.isEdited = false;
        const spy = spyOn(component, 'saveData');
        component.handleFocusChange({ target: fixture.debugElement.children[0].nativeElement });
        expect(spy).not.toHaveBeenCalled();
    });

    it('should not call saveData when component is edited and clicked inside component', () => {
        component.isEdited = true;
        const spy = spyOn(component, 'saveData');
        component.handleFocusChange({ target: fixture.debugElement.children[0].nativeElement });
        expect(spy).not.toHaveBeenCalled();
    });

    it('should call saveData and reset edit status when component is edited and clicked outside component', () => {
        component.isEdited = true;
        const spy = spyOn(component, 'saveData');
        component.handleFocusChange({ target: document.getRootNode() });
        expect(spy).toHaveBeenCalled();
        expect(component.isEdited).toBe(false);
    });

    it('should call saveData when component is edited and component is getting destroyed', () => {
        component.isEdited = true;
        const spy = spyOn(component, 'saveData');
        component.ngOnDestroy();
        expect(spy).toHaveBeenCalled();
    });

    it('should not call saveData when component is readonly and clicked inside component', () => {
        component.isReadOnly = true;
        const spy = spyOn(component, 'saveData');
        component.handleFocusChange({ target: fixture.debugElement.children[0].nativeElement });
        expect(spy).not.toHaveBeenCalled();
    });

    it('should not call saveData when component is readonly and clicked outside component', () => {
        component.isReadOnly = true;
        const spy = spyOn(component, 'saveData');
        component.handleFocusChange({ target: document.getRootNode() });
        expect(spy).not.toHaveBeenCalled();
    });

});
