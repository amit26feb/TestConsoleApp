import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { BaseFilterCellComponent, FilterService } from '@progress/kendo-angular-grid';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { DropDownListFilterComponent } from './drop-down-list-filter.component';

describe('DropDownListFilterComponent', () => {
  let component: DropDownListFilterComponent;
  let fixture: ComponentFixture<DropDownListFilterComponent>;
  const originReset = TestBed.resetTestingModule;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [DropDownListModule],
      declarations: [DropDownListFilterComponent],
      providers: [FilterService],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropDownListFilterComponent);
    component = fixture.componentInstance;
    component.column = 'selectionDesc';
    component.filter = { filters: [{ field: 'selectionDesc', value: 'test', operator: 'eq' }], logic: 'and' };
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call updateFilter with operator neq if value  is All on calling onChange', () => {
    const spy = spyOn(Object.getPrototypeOf(component), 'updateFilter');
    component.column = '655';
    component.onChange('All');
    expect(spy).toHaveBeenCalledWith({
      field: '655',
      operator: 'neq',
      value: 'All',
    });
  });

  it('should call updateFilter with operator eq if value  is not All on calling onChange', () => {
    const spy = spyOn(Object.getPrototypeOf(component), 'updateFilter');
    component.onChange('Selected');
    expect(spy).toHaveBeenCalledWith({
      field: 'selectionDesc',
      operator: 'eq',
      value: 'Selected',
    });
  });

  it('should get the selectedValue if the column exists in the filter', () => {
    expect(component.selectedValue).toBe('test');
  });


  it('should set the selectedValue to All if the column does not exist in the filter', () => {
    component.column = '5656';
    expect(component.selectedValue).toBe('All');
  });
});
