import { Component, Input, OnInit } from '@angular/core';
import { BaseFilterCellComponent, FilterService } from '@progress/kendo-angular-grid';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';

@Component({
  selector: 'app-drop-down-list-filter',
  templateUrl: './drop-down-list-filter.component.html',
  styleUrls: ['./drop-down-list-filter.component.scss'],
})
export class DropDownListFilterComponent extends BaseFilterCellComponent implements OnInit {

  @Input() public filter: CompositeFilterDescriptor;
  @Input() public data: any[];
  @Input() public textField: string;
  @Input() public valueField: string;
  @Input() public column: string;
  constructor(filterService: FilterService) {
    super(filterService);
  }

  ngOnInit() {
  }

  // onChange for modifying the root filter
  public onChange(value: any): void {
    value === 'All' ? // value of the default item
      this.updateFilter({ // add a filter for the field with the value
        field: this.column,
        operator: 'neq',
        value: 'All',
      }) : // remove the filter
      this.updateFilter({ // add a filter for the field with the value
        field: this.column,
        operator: 'eq',
        value,
      });
  }


  public get selectedValue(): any {
    const filter = this.filterByField(this.column);
    return filter ? filter.value : 'All';
  }

}
