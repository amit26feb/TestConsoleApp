import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-length',
  templateUrl: './input-length.component.html',
  styleUrls: ['./input-length.component.scss'],
})
export class InputLengthComponent implements OnInit {
  @Input() maxInputLimit: number;
  @Input() inputLength: number;
  constructor() { }

  ngOnInit(): void {
  }

}
