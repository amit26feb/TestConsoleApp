import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import {
  ICommissionCode, IJobContact, IJobCoordinationForm,
} from '../../../modules/jobs-list-master/models/coordinate-job.model';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { TraneSalesBusinessDataService } from '../../../modules/jobs-list-master/services/trane-sales-business-data.service';
import { JobCoordinationValidationService } from '../../services/job-coordination-validation.service';
import { AutoSaveWidget } from '../autosave-widget/autosave-widget';
import { JobHeaderService } from './../../services/job-header.service';
import { shouldShowErrorsMaster } from './../../validators/should-show-errors-validators';

@Component({
  selector: 'app-coordinate-form',
  templateUrl: './coordinate-form.component.html',
  styleUrls: ['./coordinate-form.component.scss'],
})
export class CoordinateFormComponent extends AutoSaveWidget implements OnInit, OnChanges, AfterViewInit, OnDestroy {
  public jobCoordinationForm: FormGroup;
  public salesPersonList: ICommissionCode[];
  public jobContactList: IJobContact[];
  public salesOfficeId: number;
  public currentDate;
  public isDateValid: boolean;
  public isJobContactValid: boolean;
  public isSalesPersonValid: boolean;
  public showSalesPersonError: boolean;
  public showQuickTurnAround = false;
  @Input() jobCoordinationInput: IJobCoordinationForm;
  @Input() drAddressId;
  @Input() jobId;
  @Output() save: EventEmitter<any> = new EventEmitter<any>();
  constructor(elementRef: ElementRef, private fb: FormBuilder, private jobService: JobsServicesService,
              private traneSalesBusinessDataService: TraneSalesBusinessDataService,
              private jobHeaderService: JobHeaderService, private jobCoordinationValidationService: JobCoordinationValidationService) {
    super(elementRef);
  }

  ngOnInit() {
    this.jobService.fetchJobDetails(this.jobId, this.drAddressId).subscribe((data) => {
      this.salesOfficeId = data.jobOfficeAndPeople.salesOfficeId;
      this.getJobContactDetails();
      this.getSalesPersonDetails();
    });
    this.createCoordinateForm();
    this.setCoordinationFormState();
    this.checkRequestedDateValidity();
  }

  ngOnChanges() {
    // set form state when job is unlocked
    if (this.jobCoordinationForm) {
      this.setCoordinationFormState();
    }
  }

  ngAfterViewInit() {
    this.jobCoordinationForm.valueChanges.subscribe(() => {
      this.isEdited = true;
    });
  }

  shouldShowErrors(controlName: string): boolean {
    return shouldShowErrorsMaster(this.jobCoordinationForm, controlName, true);
  }

  // enable or disable form based on read only state and crm job check
  setCoordinationFormState() {
    if (this.isReadOnly) {
      this.jobCoordinationForm.disable({ emitEvent: false });
    } else {
      this.jobCoordinationForm.enable({ emitEvent: false });
      if (this.jobCoordinationInput.crmOpportunityId) {
        this.jobCoordinationForm.controls.commissionCode.disable();
      }
    }
  }

  // create coordinate form group
  createCoordinateForm() {
    this.jobCoordinationForm = this.fb.group({
      requestedDate: new FormControl(this.getRequestedDate(this.jobCoordinationInput), Validators.required),
      quickTurnaroundIndicator: new FormControl(this.jobCoordinationInput ?
        this.jobCoordinationInput.quickTurnaroundIndicator === 'Y' : null),
      icsJobIndicator: new FormControl(this.jobCoordinationInput ?
        this.jobCoordinationInput.icsJobIndicator === 'Y' : null),
      jobContact: new FormControl(this.jobCoordinationInput.jobContact ?
        this.jobCoordinationInput.jobContact.trim() : null, Validators.required),
      commissionCode: new FormControl(this.jobCoordinationInput.commissionCode ?
        this.jobCoordinationInput.commissionCode.trim() : null, Validators.required),
    });
  }

  // return a date object of fetched date or next day's date to bind to requestedDate control
  getRequestedDate(data: IJobCoordinationForm): Date {
    if (data && data.requestedDate) {
      return new Date(data.requestedDate + 'Z'); // added 'Z' to mark the time in UTC format
    } else {
      return moment(new Date(), 'MM/DD/YYYY').add(1, 'day').toDate();
    }
  }

  // set invalidDate error for past date value
  onDateChange() {
    this.checkRequestedDateValidity();
  }

  checkRequestedDateValidity() {
    this.currentDate = new Date();
    const requestedDate = this.jobCoordinationForm.controls['requestedDate'].value;
    this.isDateValid = false;
    if (moment(requestedDate, 'day').isBefore(this.currentDate, 'day')) {
      this.jobCoordinationForm.get('requestedDate').setErrors({ invalidDate: true });
    } else {
      this.isDateValid = true;
    }
    this.jobCoordinationValidationService.setRequestedDateValidityFlag(this.isDateValid);
  }

  // get job contact list details
  getJobContactDetails() {
    this.traneSalesBusinessDataService.getJobContacts(this.salesOfficeId).subscribe((data) => {
      let addLoggedInUserToContactList = false;
      if (data == null) {
        this.jobContactList = [];
        addLoggedInUserToContactList = true;
      } else {
        this.jobContactList = data;
        const filteredData = data.filter((val) => val['userId'] === this.jobHeaderService.getUserId());
        addLoggedInUserToContactList = (filteredData.length === 0);
      }
      if (addLoggedInUserToContactList) {
        const loggedInUserContact = {
          userId: this.jobHeaderService.getUserId(),
          userName: this.jobHeaderService.getFullName(),
        };
        this.jobContactList.unshift(loggedInUserContact);
      }
      this.checkSelectedValueInOptions('jobContact', 'userId', this.jobContactList);
      this.checkJobContactValidity();
    });
  }

  // get sales person list details
  getSalesPersonDetails() {
    this.traneSalesBusinessDataService.getCommissionCodes(this.salesOfficeId).subscribe((data) => {
      this.salesPersonList = data;
      this.checkSelectedValueInOptions('commissionCode', 'commCode', this.salesPersonList);
      this.checkSalesPersonValidity();
    });
  }

  saveData() {
    this.checkRequestedDateValidity();
    this.save.emit(this.buildDataForSaving());
  }

  buildDataForSaving() {
    const jobDetails = {};
    this.mapValueFromJobCoordinationForm(jobDetails, 'quickTurnaroundIndicator');
    this.mapValueFromJobCoordinationForm(jobDetails, 'icsJobIndicator');
    this.mapValueFromJobCoordinationForm(jobDetails, 'requestedDate');
    this.mapValueFromJobCoordinationForm(jobDetails, 'jobContact');
    this.mapValueFromJobCoordinationForm(jobDetails, 'commissionCode');
    return jobDetails;
  }

  mapValueFromJobCoordinationForm(target, prop) {
    target[prop] = this.jobCoordinationForm.controls[prop].value;
  }

  checkJobContactValidity(): void {
    this.isJobContactValid = !!this.jobCoordinationForm.controls.jobContact.value;
    this.jobCoordinationValidationService.setJobContactFlag(this.isJobContactValid);
  }

  checkSalesPersonValidity(): void {
    this.isSalesPersonValid = !!this.jobCoordinationForm.controls.commissionCode.value;
    this.jobCoordinationValidationService.setSalesPersonFlag(this.isSalesPersonValid);
    const isSalesPersonReadOnly = this.isReadOnly || this.jobCoordinationInput.crmOpportunityId;
    this.showSalesPersonError = !isSalesPersonReadOnly && !this.isSalesPersonValid;
  }

  checkSelectedValueInOptions(property: string, key: string, options: any[]): void {
    const isSelectedValueInOptions = options.some((option) => {
      return option[key] === this.jobCoordinationInput[property];
    });
    if (!isSelectedValueInOptions) {
      this.jobCoordinationForm.controls[property].setValue('');
    }
  }
}
