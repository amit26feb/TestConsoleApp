import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { TraneSalesBusinessDataService } from '../../../modules/jobs-list-master/services/trane-sales-business-data.service';
import { AppConstants } from '../../constants/constants';
import { JobCoordinationValidationService } from '../../services/job-coordination-validation.service';
import { JobEditServiceMock } from '../../test-mocks/editjobservice-mock';
import { TraneSalesBusinessDataServiceMock } from '../../test-mocks/tranesalesbusinessdata-mock';
import { JobHeaderService } from './../../services/job-header.service';
import { CoordinateFormComponent } from './coordinate-form.component';

// tslint:disable-next-line:no-big-function
describe('CoordinateFormComponent', () => {
  let component: CoordinateFormComponent;
  let fixture: ComponentFixture<CoordinateFormComponent>;
  let injector: TestBed;
  let traneSalesBusinessDataService: TraneSalesBusinessDataService;
  let jobService: JobsServicesService;
  let jobCoordinationValidationService: JobCoordinationValidationService;
  let jobHeaderService: JobHeaderService;
  const originReset = TestBed.resetTestingModule;
  const testCoordinationInput = {
    requestedDate: '2020-04-28T05:08:42',
    quickTurnaroundIndicator: 'Y',
    icsJobIndicator: 'N',
    jobContact: 'cceenp',
    commissionCode: 'X00',
    crmOpportunityId: '1811024',
    pricingSpaNumber: null,
  };

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [DatePickerModule, FormsModule, ReactiveFormsModule, HttpClientTestingModule],
      declarations: [CoordinateFormComponent],
      providers: [{ provide: JobsServicesService, useClass: JobEditServiceMock },
        JobHeaderService,
        JobCoordinationValidationService,
      { provide: TraneSalesBusinessDataService, useClass: TraneSalesBusinessDataServiceMock }, AppConstants],
    });
  }));

  beforeEach(() => {
    injector = getTestBed();
    jobService = injector.inject(JobsServicesService);
    jobCoordinationValidationService = injector.inject(JobCoordinationValidationService);
    traneSalesBusinessDataService = injector.inject(TraneSalesBusinessDataService);
    jobHeaderService = injector.inject(JobHeaderService);
    fixture = TestBed.createComponent(CoordinateFormComponent);
    component = fixture.componentInstance;
    component.jobCoordinationInput = testCoordinationInput;
    spyOn(jobHeaderService, 'getUserId')
      .and.returnValue('ccefaa');
    spyOn(jobHeaderService, 'getUserName')
      .and.returnValue('Sreeram Basam');
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get sales office id in ngOnInit', () => {
    component.ngOnInit();
    expect(component.salesOfficeId).toBe(34);
  });

  it('should call setCoordinationFormState in ngOnInit', () => {
    const spyEnableOrDisableForm = spyOn(component, 'setCoordinationFormState');
    component.ngOnInit();
    expect(spyEnableOrDisableForm).toHaveBeenCalled();
  });

  it('should call setCoordinationFormState in ngOnChanges', () => {
    component.ngOnInit();
    const spyEnableOrDisableForm = spyOn(component, 'setCoordinationFormState');
    component.ngOnChanges();
    expect(spyEnableOrDisableForm).toHaveBeenCalled();
  });

  it('should create the jobCoordinationForm on ngOnInit', () => {
    component.ngOnInit();
    expect(component.jobCoordinationForm.controls.requestedDate).toBeDefined();
    expect(component.jobCoordinationForm.controls.quickTurnaroundIndicator).toBeDefined();
    expect(component.jobCoordinationForm.controls.icsJobIndicator).toBeDefined();
    expect(component.jobCoordinationForm.controls.jobContact).toBeDefined();
    expect(component.jobCoordinationForm.controls.commissionCode).toBeDefined();
  });

  it('should check date validity on ngOnInit', () => {
    const requestedDateValidationSpy = spyOn(component, 'checkRequestedDateValidity');
    component.ngOnInit();
    expect(requestedDateValidationSpy).toHaveBeenCalled();
  });

  it('should check date validity on date change', () => {
    const requestedDateValidationSpy = spyOn(component, 'checkRequestedDateValidity');
    component.onDateChange();
    expect(requestedDateValidationSpy).toHaveBeenCalled();
  });

  it('should emit false if requestedDate is before current date', () => {
    const spyDate = spyOn(jobCoordinationValidationService, 'setRequestedDateValidityFlag');
    const sampleDate = new Date();
    sampleDate.setDate(sampleDate.getDate() - 1);
    component.jobCoordinationForm.controls['requestedDate'].setValue(sampleDate);
    component.checkRequestedDateValidity();
    expect(spyDate).toHaveBeenCalledWith(false);
  });

  it('should emit true if requestedDate is current date', () => {
    const spyDate = spyOn(jobCoordinationValidationService, 'setRequestedDateValidityFlag');
    const sampleDate = new Date();
    component.jobCoordinationForm.controls['requestedDate'].setValue(sampleDate);
    component.checkRequestedDateValidity();
    expect(spyDate).toHaveBeenCalledWith(true);
  });

  it('should emit true if requestedDate is future date', () => {
    const spyDate = spyOn(jobCoordinationValidationService, 'setRequestedDateValidityFlag');
    const sampleDate = new Date();
    sampleDate.setDate(sampleDate.getDate() + 1);
    component.jobCoordinationForm.controls['requestedDate'].setValue(sampleDate);
    component.checkRequestedDateValidity();
    expect(spyDate).toHaveBeenCalledWith(true);
  });

  it('should disable form if isReadOnly flag is true', () => {
    component.ngOnInit();
    component.isReadOnly = true;
    const spy = spyOn(component.jobCoordinationForm, 'disable').and.callThrough();
    component.setCoordinationFormState();
    expect(component.jobCoordinationForm.disabled).toBe(true);
    expect(spy).toHaveBeenCalledWith({ emitEvent: false });
  });

  it('should enable form if isReadOnly flag is false', () => {
    component.ngOnInit();
    component.isReadOnly = false;
    const spy = spyOn(component.jobCoordinationForm, 'enable').and.callThrough();
    component.setCoordinationFormState();
    expect(component.jobCoordinationForm.enabled).toBe(true);
    expect(spy).toHaveBeenCalledWith({ emitEvent: false });
  });

  it('should disable crm field when crmOpportunityId is not null', () => {
    component.ngOnInit();
    component.isReadOnly = false;
    component.setCoordinationFormState();
    expect(component.jobCoordinationForm.controls.commissionCode.disabled).toBe(true);
  });

  it('should return a date object of requestedDate when date is not null', () => {
    component.ngOnInit();
    expect(component.jobCoordinationForm.controls.requestedDate.value)
      .toEqual(new Date(component.jobCoordinationInput.requestedDate + 'Z'));
  });

  it('should return a date object of next day date when requestedDate is null', () => {
    component.jobCoordinationInput.requestedDate = null;
    component.ngOnInit();
    expect(new Date(component.jobCoordinationForm.controls.requestedDate.value).toDateString()).
      toEqual(moment(new Date(), 'MM/DD/YYYY').add(1, 'day').toDate().toDateString());
  });

  it('should set invalidDate to true on date change event', () => {
    component.ngOnInit();
    component.jobCoordinationForm.controls.requestedDate
      .setValue(new Date('Mon Oct 07 2019 21:12:07 GMT+0530'));
    component.onDateChange();
    expect(component.jobCoordinationForm.controls.requestedDate.hasError('invalidDate')).toBeTruthy();
  });

  it('should get sales person details on getCommissionCodeDetails', () => {
    const salesPersonList = [
      {
        name: 'Joint Venture',
        commCode: 'J98',
        commCodeDisplay: 'Joint Venture [J98]',
        salesOfficeId: 103,
      },
    ];
    const spyCommissionCodes = spyOn(traneSalesBusinessDataService, 'getCommissionCodes')
      .and.returnValue(Observable.of(salesPersonList));
    component.getSalesPersonDetails();
    expect(spyCommissionCodes).toHaveBeenCalled();
    expect(component.salesPersonList).toEqual(salesPersonList);
  });

  it('should get job contact details on getJobContactDetails', () => {
    const jobContactList = [
      {
        userId: 'ccbrhi',
        userName: 'Alberts, Ryan',
      },
      {
        userId: 'ccefaa',
        userName: 'Sreeram Basam',
      },
    ];
    const spyJobContactDetails = spyOn(traneSalesBusinessDataService, 'getJobContacts')
      .and.returnValue(Observable.of(jobContactList));
    component.getJobContactDetails();
    expect(spyJobContactDetails).toHaveBeenCalled();
    expect(component.jobContactList).toEqual(jobContactList);
  });

  it('should add logged in user to contact list when job contacts list is null', () => {
    const spyJobContactDetails = spyOn(traneSalesBusinessDataService, 'getJobContacts')
      .and.returnValue(Observable.of(null));
    component.getJobContactDetails();
    expect(spyJobContactDetails).toHaveBeenCalled();
    expect(component.jobContactList[0].userId).toEqual('ccefaa');
  });

  it('should add logged in user to contact list when job contacts list do not have logged in user', () => {
    const jobContactList = [
      {
        userId: 'ccbrhi',
        userName: 'Alberts, Ryan',
      },
    ];
    const spyJobContactDetails = spyOn(traneSalesBusinessDataService, 'getJobContacts')
      .and.returnValue(Observable.of(jobContactList));
    component.getJobContactDetails();
    expect(spyJobContactDetails).toHaveBeenCalled();
    expect(component.jobContactList[0].userId).toEqual('ccefaa');
  });

  it('should emit save event with job details when saveData is called', () => {
    const testDate = new Date();
    const testContact = 'basam';
    const testSalesPerson = 'abc';
    component.jobCoordinationForm.controls.requestedDate.setValue(testDate);
    component.jobCoordinationForm.controls.quickTurnaroundIndicator.setValue(true);
    component.jobCoordinationForm.controls.icsJobIndicator.setValue(true);
    component.jobCoordinationForm.controls.jobContact.setValue(testContact);
    component.jobCoordinationForm.controls.commissionCode.setValue(testSalesPerson);
    const spy = spyOn(component.save, 'emit');
    const requestedDateValidationSpy = spyOn(component, 'checkRequestedDateValidity');
    component.saveData();
    expect(requestedDateValidationSpy).toHaveBeenCalled();
    expect(spy).toHaveBeenCalledWith({
      requestedDate: testDate,
      quickTurnaroundIndicator: true,
      icsJobIndicator: true,
      jobContact: testContact,
      commissionCode: testSalesPerson,
    });
  });

  it('should emit false to setJobContactFlag if Job Contact field is empty or has null data', () => {
    const spyJobContactValidity = spyOn(jobCoordinationValidationService, 'setJobContactFlag');
    component.jobCoordinationForm.controls.jobContact.setValue('');
    component.checkJobContactValidity();
    expect(spyJobContactValidity).toHaveBeenCalledWith(false);
    component.jobCoordinationForm.controls.jobContact.setValue(null);
    component.checkJobContactValidity();
    expect(spyJobContactValidity).toHaveBeenCalledWith(false);
  });

  it('should emit false to setJobContactFlag if Job Contact field is not empty', () => {
    const spyJobContactValidity = spyOn(jobCoordinationValidationService, 'setJobContactFlag');
    component.jobCoordinationForm.controls.jobContact.setValue('test');
    component.checkJobContactValidity();
    expect(spyJobContactValidity).toHaveBeenCalledWith(true);
  });

  it('should emit false to setSalesPersonFlag if Sales Person field is empty or has null data', () => {
    const spySalesPersonValidity = spyOn(jobCoordinationValidationService, 'setSalesPersonFlag');
    component.jobCoordinationForm.controls.commissionCode.setValue('');
    component.checkSalesPersonValidity();
    expect(spySalesPersonValidity).toHaveBeenCalledWith(false);
    component.jobCoordinationForm.controls.commissionCode.setValue(null);
    component.checkJobContactValidity();
    expect(spySalesPersonValidity).toHaveBeenCalledWith(false);
  });

  it('should emit false to setSalesPersonFlag if Job Contact field is not empty', () => {
    const spySalesPersonValidity = spyOn(jobCoordinationValidationService, 'setSalesPersonFlag');
    component.jobCoordinationForm.controls.commissionCode.setValue('test');
    component.checkSalesPersonValidity();
    expect(spySalesPersonValidity).toHaveBeenCalledWith(true);
  });

  it(`should show error on Job Contact and Sales Person field only if the respective fields are empty`, () => {
    let result;
    component.createCoordinateForm();
    component.jobCoordinationForm.controls['jobContact'].setValue('');
    component.jobCoordinationForm.controls['jobContact'].markAsTouched();
    result = component.shouldShowErrors('jobContact');
    expect(result).toBe(true);
    component.jobCoordinationForm.controls['jobContact'].setValue('test');
    component.jobCoordinationForm.controls['jobContact'].markAsTouched();
    result = component.shouldShowErrors('jobContact');
    expect(result).toBe(false);
    component.jobCoordinationForm.controls['commissionCode'].setValue('');
    component.jobCoordinationForm.controls['commissionCode'].markAsTouched();
    result = component.shouldShowErrors('commissionCode');
    expect(result).toBe(true);
    component.jobCoordinationForm.controls['commissionCode'].setValue('test');
    component.jobCoordinationForm.controls['commissionCode'].markAsTouched();
    result = component.shouldShowErrors('commissionCode');
    expect(result).toBe(false);
  });

  it('should set corresponding field to empty if user is not in userlist when checkSelectedValueInOptions method is called', () => {
    const fieldName = 'jobContact';
    const valueList = [{
      userId: '4567',
      userName: 'test1',
    },
    ];
    component.jobCoordinationInput[fieldName] = '4673';
    component.checkSelectedValueInOptions(fieldName, 'userId', valueList);
    expect(component.jobCoordinationForm.controls[fieldName].value).toBe('');
  });

  it('should not set corresponding field to empty if user is in userlist when checkSelectedValueInOptions method is called', () => {
    const fieldName = 'jobContact';
    const valueList = [{
      userId: '4556',
      userName: 'test1',
    },
    ];
    component.jobCoordinationInput[fieldName] = '4556';
    component.checkSelectedValueInOptions(fieldName, 'userId', valueList);
    expect(component.jobCoordinationForm.controls[fieldName].value).not.toBe('');
  });

  it('should not show sales person field error  when job is read only', () => {
    component.isReadOnly = true;
    component.jobCoordinationInput.crmOpportunityId = null;
    component.jobCoordinationForm.controls.commissionCode.setValue('');
    component.checkSalesPersonValidity();
    expect(component.isSalesPersonValid).toBe(false);
    expect(component.showSalesPersonError).toBe(false);
  });

  it('should not show sales person field error  when job is a CRM job', () => {
    component.isReadOnly = false;
    component.jobCoordinationInput.crmOpportunityId = '352';
    component.jobCoordinationForm.controls.commissionCode.setValue('');
    component.checkSalesPersonValidity();
    expect(component.isSalesPersonValid).toBe(false);
    expect(component.showSalesPersonError).toBe(false);
  });

  it('should not show sales person field error  when sales person is valid', () => {
    component.isReadOnly = false;
    component.jobCoordinationInput.crmOpportunityId = null;
    component.jobCoordinationForm.controls.commissionCode.setValue('U67');
    component.checkSalesPersonValidity();
    expect(component.isSalesPersonValid).toBe(true);
    expect(component.showSalesPersonError).toBe(false);
  });

  it('should show sales person field error  when sales person is invalid', () => {
    component.isReadOnly = false;
    component.jobCoordinationInput.crmOpportunityId = null;
    component.jobCoordinationForm.controls.commissionCode.setValue('');
    component.checkSalesPersonValidity();
    expect(component.isSalesPersonValid).toBe(false);
    expect(component.showSalesPersonError).toBe(true);
  });
});
