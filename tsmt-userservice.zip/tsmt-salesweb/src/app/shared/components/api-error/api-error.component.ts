import { Component, OnInit } from '@angular/core';
import { delay } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { IApiErrorState } from '../../../shared/model/apierror-state';
import { ApiErrorService } from '../../../shared/services/apierror.service';

@Component({
  selector: 'app-api-error',
  templateUrl: './api-error.component.html',
  styleUrls: ['./api-error.component.scss'],
})
export class ApiErrorComponent implements OnInit {
  errorMessage: any;
  show = false;
  private subscription: Subscription;
  constructor(private apiErrorService: ApiErrorService) { }

  ngOnInit() {
    this.apiErrorService.apiErrorState.pipe(delay(0))
      .subscribe((state: IApiErrorState) => {
        this.show = state.show;
        if (typeof (state.errorMessage) === 'string') {
          this.errorMessage = [state.errorMessage];
        } else {
          this.errorMessage = state.errorMessage;
        }
      });
  }
}


