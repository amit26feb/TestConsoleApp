import { Injectable } from '@angular/core';
import { async, ComponentFixture, fakeAsync, getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable, Subject } from 'rxjs';
import { delay } from 'rxjs/operators';
import { ApiErrorService } from '../../../shared/services/apierror.service';
import { ApiErrorServiceMock } from '../../../shared/test-mocks/apierrorservice-mock';
import { IApiErrorState } from '../../model/apierror-state';
import { ApiErrorComponent } from './api-error.component';

describe('ApiErrorComponent', () => {
  let component: ApiErrorComponent;
  let fixture: ComponentFixture<ApiErrorComponent>;
  let apiErrorService: ApiErrorService;
  let injector: TestBed;
  let apiMock: ApiErrorServiceMock;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [ApiErrorComponent],
      providers: [ApiErrorService, ApiErrorServiceMock],
    });
    injector = getTestBed();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApiErrorComponent);
    component = fixture.componentInstance;
    apiErrorService = injector.inject(ApiErrorService);
    apiMock = injector.inject(ApiErrorServiceMock);
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call on ngOnInit', fakeAsync(() => {
    spyOn(apiErrorService.apiErrorState, 'pipe').and.callFake(() => apiMock.show('error'));
    component.ngOnInit();
    jasmine.clock().tick(500);
    expect(component.show).toBeTruthy();
    expect(component.errorMessage).toEqual(['error']);
  }));

  it('should set show to true and errorMessage call on ngOnInit', fakeAsync(() => {
    const errorMessages = ['failure', 'Error'];
    spyOn(apiErrorService.apiErrorState, 'pipe').and.callFake(() => apiMock.show(errorMessages));
    component.ngOnInit();
    jasmine.clock().tick(500);
    expect(component.show).toBe(true);
    expect(component.errorMessage).toEqual(errorMessages);
  }));
});

