import { CurrencyPipe } from '@angular/common';
import { getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { CurrencyFormatterPipe } from './currencyFormatter.pipe';

describe('CurrencyFormatterPipe', () => {
  let injector: TestBed;
  let currencyPipe: CurrencyPipe;
  let pipe: CurrencyFormatterPipe;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [CurrencyFormatterPipe],
      imports: [],
      providers: [CurrencyPipe],
    });
  });

  beforeEach(() => {
    injector = getTestBed();
    currencyPipe = injector.inject(CurrencyPipe);
    pipe = new CurrencyFormatterPipe(currencyPipe);
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it(`transform() should format the negative values with paranthesis`, () => {
    expect(pipe.transform(-15.00)).toBe('($15.00)');
  });

  it(`transform() should format the positive values without paranthesis`, () => {
    expect(pipe.transform(15.00)).toBe('$15.00');
  });
});
