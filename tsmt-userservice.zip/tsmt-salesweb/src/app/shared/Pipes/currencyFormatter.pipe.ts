import { CurrencyPipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'currencyFormatter'
})
export class CurrencyFormatterPipe implements PipeTransform {
  amountPattern: RegExp = /[$,]/g;
  constructor(
    private currencyPipe: CurrencyPipe,
  ) { }

  transform(value: number): string {
    let formattedAmount: string;
    if (value !== null) {
      if (value < 0) {
        // (should format negative values to be '($xx.xx)'
        value = -1 * value;
        formattedAmount = '(' + this.currencyPipe.transform(value.toString().replace(this.amountPattern, '')) + ')';
      } else {
        // (should format positive values to be '$xx.xx'
        formattedAmount = this.currencyPipe.transform(value.toString().replace(this.amountPattern, ''));
      }
    }
    return formattedAmount;
  }
}
