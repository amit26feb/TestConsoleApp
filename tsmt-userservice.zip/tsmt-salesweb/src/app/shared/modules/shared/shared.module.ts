import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
// components
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { PopupModule } from '@progress/kendo-angular-popup';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { UploadModule } from '@progress/kendo-angular-upload';
import { SharedCoreModule } from '@tsmt/shared-core';
import { SharedCoreSaleswebModule } from '@tsmt/shared-core-salesweb';
import { NgxPaginationModule } from 'ngx-pagination';
import { SlickCarouselModule } from 'ngx-slick-carousel';
// tslint:disable-next-line:max-line-length
import { JobsServicesService } from '../../../modules/jobs-list-master/services/jobs-services.service';
import { UserService } from '../../../modules/jobs-list-master/services/user.service';
import { ApiErrorComponent } from '../../components/api-error/api-error.component';
import { BadgeComponent } from '../../components/badge/badge.component';
import { ConfirmPopupComponent } from '../../components/confirm-popup/confirm-popup.component';
import { CoordinateDataComponent } from '../../components/coordinate-data/coordinate-data.component';
import { CoordinateFormComponent } from '../../components/coordinate-form/coordinate-form.component';
import { CoordinateSubmitButtonComponent } from '../../components/coordinate-submit-button/coordinate-submit-button.component';
import { DocumentsUploadComponent } from '../../components/documents-upload/documents-upload.component';
import { DocumentsComponent } from '../../components/documents/documents.component';
import { ExitComponent } from '../../components/exit/exit.component';
import { InputLengthComponent } from '../../components/input-length/input-length.component';
import { InstalledAddressComponent } from '../../components/installed-address/installed-address.component';
import { JobInfoComponent } from '../../components/job-info/job-info.component';
import { LoaderComponent } from '../../components/loader/loader.component';
import { OfficeSelectorComponent } from '../../components/office-selector/office-selector.component';
import { OverlayPopupComponent } from '../../components/overlay-popup/overlay-popup.component';
import { PaginationComponent } from '../../components/pagination/pagination.component';
import { PanelLoaderComponent } from '../../components/panel-loader/panel-loader.component';
import { SubmissionNotesComponent } from '../../components/submission-notes/submission-notes.component';
import { CurrencyFormatterDirective } from '../../directives/currency-formatter.directive';
import { RestrictSpaceDirective } from '../../directives/restrict-space.directive';
import { ScrollWidthDirective } from '../../directives/scroll-width.directive';
import { GridFiltersService } from '../../services/grid-filters.service';
import { TraneSalesBusinessDataService } from './../../../modules/jobs-list-master/services/trane-sales-business-data.service';
import { CarouselComponent } from './../../components/carousel/carousel.component';
import { CoordinateBidsComponent } from './../../components/coordinate-bids/coordinate-bids.component';
import { CoordinateBOMComponent } from './../../components/coordinate-bom/coordinate-bom.component';
import { CoordinateStatusComponent } from './../../components/coordinate-status-grid/coordinate-status.component';
import { DropDownListFilterComponent } from './../../components/drop-down-list-filter/drop-down-list-filter.component';
import { JobNotesComponent } from './../../components/job-notes/job-notes.component';
import { CurrencyFormatterPipe } from '../../Pipes/currencyFormatter.pipe';
import { UserPreferencesComponent } from '../../components/user-preferences/user-preferences.component';
import { SalesWebOrdersLibraryModule } from '@tsmt/salesweb-ordersmodule';
import { environment } from '../../../../environments/environment';

export function httpLoaderFactory(httpClient: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(httpClient, './assets/i18n/', '.json');
}

@NgModule({
  imports: [
    CommonModule,
    DropDownListModule,
    ReactiveFormsModule,
    DropDownsModule,
    GridModule,
    TooltipModule,
    TreeViewModule,
    FormsModule,
    DialogsModule,
    ButtonsModule,
    DatePickerModule,
    InputsModule,
    LayoutModule,
    PopupModule,
    UploadModule,
    DragDropModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    NgxPaginationModule,
    SharedCoreModule,
    SlickCarouselModule,
    SharedCoreSaleswebModule,
    IndicatorsModule,
    SalesWebOrdersLibraryModule.forRoot(environment)
  ],
  declarations: [LoaderComponent, ApiErrorComponent, JobInfoComponent,
    DropDownListFilterComponent, JobNotesComponent, CoordinateFormComponent,
    CoordinateBidsComponent, SubmissionNotesComponent, OfficeSelectorComponent, DocumentsComponent,
    CoordinateStatusComponent, ConfirmPopupComponent, CoordinateBOMComponent, ExitComponent, CoordinateDataComponent,
    CoordinateSubmitButtonComponent, BadgeComponent, PaginationComponent,
    InstalledAddressComponent,
    OverlayPopupComponent, DocumentsUploadComponent,
    CurrencyFormatterDirective, RestrictSpaceDirective, InputLengthComponent,
    CarouselComponent, ScrollWidthDirective,
    PanelLoaderComponent, CurrencyFormatterPipe, UserPreferencesComponent],
  entryComponents: [ConfirmPopupComponent],
  exports: [LoaderComponent, ApiErrorComponent, PanelLoaderComponent,
    ReactiveFormsModule, JobInfoComponent, TooltipModule, DropDownListFilterComponent,
    JobNotesComponent, CoordinateFormComponent, CoordinateBidsComponent, SubmissionNotesComponent,
    OfficeSelectorComponent, DocumentsComponent, CoordinateStatusComponent, CoordinateBOMComponent,
    CoordinateDataComponent, CoordinateSubmitButtonComponent, BadgeComponent,
    PaginationComponent, NgxPaginationModule,
    InstalledAddressComponent, OverlayPopupComponent,
    DocumentsUploadComponent,
    CurrencyFormatterDirective, RestrictSpaceDirective, InputLengthComponent, SharedCoreModule,
    CarouselComponent, SharedCoreSaleswebModule, ScrollWidthDirective, CurrencyFormatterPipe
  ],
  providers: [JobsServicesService, TraneSalesBusinessDataService, UserService, GridFiltersService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
})
export class SharedModule { }
