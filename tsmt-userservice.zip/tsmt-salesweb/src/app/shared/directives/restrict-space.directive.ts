import { Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Directive({
  selector: '[appRestrictSpace]',
})

export class RestrictSpaceDirective implements OnInit {
  // tslint:disable-next-line:no-input-rename
  @Input('controlName') controlName: string;
  // tslint:disable-next-line:no-input-rename
  @Input('formName') formName: FormGroup;
  public htmlInput: HTMLInputElement;
  public targetValue: string;
  constructor(private elementRef: ElementRef) { }

  ngOnInit() {
    this.htmlInput = this.elementRef.nativeElement;
  }

  /**
   * Allows or Restricts input value based on few conditons when each keydown event is triggered.
   * @param event - event triggered on keydown.
   */
  @HostListener('keyup', ['$event'])
  onKeyUp(): void {
    this.targetValue = this.htmlInput.value;
    if (this.targetValue.trim().length === 0) {
      this.formName.controls[this.controlName].reset();
    }
  }
}
