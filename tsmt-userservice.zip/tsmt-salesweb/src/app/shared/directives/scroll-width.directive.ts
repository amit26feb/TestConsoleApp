import { AfterViewInit, Directive, ElementRef, HostBinding } from '@angular/core';

@Directive({
  selector: '[appScrollWidth]',
})
export class ScrollWidthDirective implements AfterViewInit {
  private scrollbarWidth: number;

  @HostBinding('class.no-scrollbar')
  get noScrollbarClass(): boolean {
    return this.scrollbarWidth === 0;
  }

  constructor(
    private _element: ElementRef,
  ) { }

  ngAfterViewInit() {
    this.scrollWidth();
  }

  // return scroll width for HTML element

  scrollWidth(): number {
    const htmlElement = this._element.nativeElement.querySelector('.custom-grid-content');
    this.scrollbarWidth = htmlElement.offsetWidth - htmlElement.scrollWidth - 2;
    return this.scrollbarWidth;
  }

}
