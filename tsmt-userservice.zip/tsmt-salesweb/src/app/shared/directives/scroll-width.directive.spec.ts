import { Component, DebugElement, ElementRef } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';

// components and directives
import { ScrollWidthDirective } from './scroll-width.directive';

@Component({
  template: `<div class="custom-grid-root" appScrollWidth><div class="custom-grid-content"></div></div>`,
})
class TestCustomGridComponent {

}

const className = 'no-scrollbar';

describe('ScrollWidthDirective', () => {
  const originReset = TestBed.resetTestingModule;
  let component: TestCustomGridComponent;
  let fixture: ComponentFixture<TestCustomGridComponent>;
  let injector: TestBed;
  let htmlElement: DebugElement;
  let directiveElement;
  let directiveInstance;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [ScrollWidthDirective, TestCustomGridComponent],
    });
    injector = getTestBed();
    fixture = TestBed.createComponent(TestCustomGridComponent);
    component = fixture.componentInstance;
    directiveElement = fixture.debugElement.query(By.directive(ScrollWidthDirective));
    directiveInstance = directiveElement.injector.get(ScrollWidthDirective);
    htmlElement = fixture.debugElement.query(By.css('.custom-grid-root'));
  }));

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();

  });

  it('should call scrollWidth() method when ngAfterViewInit() is triggered', () => {
    const spy = spyOn(directiveInstance, 'scrollWidth').and.callThrough();
    directiveInstance.ngAfterViewInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should not have no-scrollbar class if scrollWidth is not zero', () => {
    directiveInstance.ngAfterViewInit();
    expect(htmlElement.nativeElement.classList.contains(className)).toEqual(false);
  });

  it('should have no-scrollbar class if scrollWidth is zero', () => {
    htmlElement.nativeElement.classList.add(className);
    directiveInstance.ngAfterViewInit();
    expect(htmlElement.nativeElement.classList.contains(className)).toEqual(true);
  });

});
