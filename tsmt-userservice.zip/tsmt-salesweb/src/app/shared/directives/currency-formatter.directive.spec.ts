import { CurrencyPipe } from '@angular/common';
import { Component, DebugElement, Type } from '@angular/core';
import { Renderer2 } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { CurrencyFormatterDirective } from './currency-formatter.directive';

@Component({
    template: `<input type="text" class="form-control" appCurrencyFormatter>`,
})
class TestCurrencyFormatterComponent {

}

describe('CurrencyFormatterDirective', () => {
    let component: TestCurrencyFormatterComponent;
    let fixture: ComponentFixture<TestCurrencyFormatterComponent>;
    let directiveElement: DebugElement;
    let directiveInstance: CurrencyFormatterDirective;
    let debugElement: DebugElement;

    const originReset = TestBed.resetTestingModule;

    configureTestSuite(() => {
        TestBed.configureTestingModule({
            declarations: [CurrencyFormatterDirective, TestCurrencyFormatterComponent],
            providers: [CurrencyPipe, Renderer2],
        });
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(TestCurrencyFormatterComponent);
        component = fixture.componentInstance;
        directiveElement = fixture.debugElement.query(By.directive(CurrencyFormatterDirective));
        directiveInstance = directiveElement.injector.get(CurrencyFormatterDirective);
        debugElement = fixture.debugElement;
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should create', () => {
        expect(directiveElement).toBeDefined();
    });

    it('Should transform the input value into USD format when blur event is triggered', () => {
        const event = { key: '1234567890', target: { value: '1234567890' } };
        directiveInstance.onBlur(event.target.value);
        expect(directiveElement.nativeElement.value).toBe('$123,456,789.00');
    });

    it('Should assign empty value to the field when decimal pointer is entered with no numbers', () => {
        const event = { key: '.', target: { value: '.' } };
        directiveInstance.onBlur(event.target.value);
        expect(directiveElement.nativeElement.value).toEqual('');
    });
});
