import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { RestrictSpaceDirective } from './restrict-space.directive';

@Component({
  template: `<input type="text" class="form-control" [formName]="testForm"
    [controlName]="'description'" appRestrictSpace>`,
})

class TestRestrictSpaceComponent {
  public testForm = new FormGroup({
    description: new FormControl(''),
  });
}

describe('RestrictSpaceDirective', () => {
  let component: TestRestrictSpaceComponent;
  let directiveElement: DebugElement;
  let fixture: ComponentFixture<TestRestrictSpaceComponent>;
  let debugElement: DebugElement;
  let directiveInstance: RestrictSpaceDirective;
  let injector: TestBed;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [RestrictSpaceDirective, TestRestrictSpaceComponent],
    });
  });

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(TestRestrictSpaceComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    directiveElement = fixture.debugElement.query(By.directive(RestrictSpaceDirective));
    directiveInstance = directiveElement.injector.get(RestrictSpaceDirective);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set formvalue to null when user enters space value on keyUp event', () => {
    directiveInstance.targetValue = '';
    directiveInstance.onKeyUp();
    expect(directiveInstance.formName.controls[directiveInstance.controlName].value).toEqual(null);
  });

  it('should set user input value on keyUp event', () => {
    directiveInstance.htmlInput.value = 'a';
    directiveInstance.onKeyUp();
    expect(directiveInstance.targetValue).toBe('a');
  });
});
