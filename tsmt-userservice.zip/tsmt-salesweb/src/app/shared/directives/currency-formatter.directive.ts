import { CurrencyPipe } from '@angular/common';
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appCurrencyFormatter]',
})
export class CurrencyFormatterDirective {

  constructor(private elementRef: ElementRef, private currencyPipe: CurrencyPipe) { }

  /**
   * Transforms target value into USD format.
   * @param value - input value
   */
  @HostListener('blur', ['$event.target.value'])
  onBlur(value: string): void {
    if (value.length > 0) {
      value = (value !== '.') ? (value.replace(/[\$,]/g, '')) : '';
      if (value.indexOf('.') === -1 && value.length > 9) {
        value = value.substring(0, 9);
      }
      this.elementRef.nativeElement.value = this.currencyPipe.transform(value, 'USD');
    }
  }
}
