export interface IOfficeSelectorModel {
    salesOfficeName: string;
    drAddressId: number;
    country: string;
    crmIntegrationInd: string;
    homeDrAddressId: number;
    groupName: string;
    createJobInd: string;
    buInd: string;
}
