export interface IHeaderItemModel {
    items: {
        text: string;
        disabled?: boolean;
        route: string;
        cssClass: string;
        path: string;
    };
    text: string;
    disabled?: boolean;
    route: string;
    cssClass: string;
    path: string;
}
