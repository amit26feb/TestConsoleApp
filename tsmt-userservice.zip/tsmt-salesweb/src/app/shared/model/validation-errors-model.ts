export interface IPreValidation {
    additionalInfo: string;
    eventName: string;
    rootEntityName: string;
    rootEntityId: number;
}
