export interface IDashboardTilePreference {
  name: string;
  isVisible: boolean;
  sequence: number;
}
