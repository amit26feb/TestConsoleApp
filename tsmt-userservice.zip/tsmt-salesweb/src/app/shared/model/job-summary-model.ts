import { INonTraneListModel } from '../../modules/jobs-list-master/models/non-trane-model';
import { IEditJobModel } from './../../modules/jobs-list-master/modal/job-details-edit.model';
import { BidsListModel } from './bids-model';
import { IJobCustomerModel } from './job-customer-model';
import { IJobDocumentModel } from './job-document-model';
import { SelectionlistModel } from './selectionlist-model';

export interface IJobSummaryModel {
    bids: BidsListModel[];
    documents: IJobDocumentModel;
    nonTraneItems: INonTraneListModel;
    traneItems: SelectionlistModel;
    customers: IJobCustomerModel;
    basicInfo: IEditJobModel;
}
