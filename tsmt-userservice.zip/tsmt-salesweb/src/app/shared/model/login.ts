export interface ILoginForm {
    username: string;
    password: string;
}
