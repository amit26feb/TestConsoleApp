import { IJobAddress } from './../../modules/jobs-list-master/modal/job-details-edit.model';
export interface IJobBasicInfoModel {
    jobId: number;
    jobName: string;
    hqtrJobId: number;
    pricingSpaNumber: string;
    salesOfficeName: string;
    locationOfficeName: string;
    jobAddress: IJobAddress;
    jobStatus: string;
    lostToCompetitor: string;
}
