export interface IOrderListModel {
    pagingItems: IPagingItemsListModel[];
    pageNumber: 0;
    pageSize: 0;
    totalItemCount: 570;
    pageCount: 0;
}

export interface IPagingItemsListModel {
    jobName: string;
    creditJobId: number;
    creditJobName: string;
    purchaseOrderNumber: string;
    purchaseOrderAmount: number;
    legacyCreditJobNumber: string;
    customerAccountNumber: string;
    customerName: string;
    jobContactPersonFirstName: string;
    jobContactPersonLastName: string;
    salesPersonName: string;
    salesOrdersList: ISalesOrdersListModel[];
}

export interface ISalesOrdersListModel {
    creditJobId: number;
    legacyOrderNumber: string;
    salesOrderId: number;
    plannedShipmentDetails: IPlannedShipmentDetailsModel[];
}

export interface IPlannedShipmentDetailsModel {
    plannedShipmentNbr: string;
    salesOrderStatus: string;
    mfgStatus: string;
    mfgLocation: string;
    shippingInstructionName: string;
    shipFrom: string;
    mfgOpRule: number;
    estimatedShipDate: string;
    actualShipDate: string;
    enteredDollars: number;
    orderLineDetails: IOrderLineDetailsModel[];
}

export interface IOrderLineDetailsModel {
    earlierDeliveryWindowDate: string;
    latestDeliveryWindowDate: string;
    orderLineQty: number;
    orderLineDescription: string;
    orderLineNumber: number;
    orderLineType: string;
}
