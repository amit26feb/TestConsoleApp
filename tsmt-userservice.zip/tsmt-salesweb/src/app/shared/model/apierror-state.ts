export interface IApiErrorState {
    show: boolean;
    errorMessage: string | string[];
}
