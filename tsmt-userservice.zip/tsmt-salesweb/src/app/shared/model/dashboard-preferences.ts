import { IDashboardTilePreference } from './dashboard-tile-preference';

export interface IDashboardPreference {
  tiles: IDashboardTilePreference[];
}
