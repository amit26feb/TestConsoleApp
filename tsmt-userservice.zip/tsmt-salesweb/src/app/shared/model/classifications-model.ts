export interface IClassificationsModel {
  jobCodeId: number;
  jobId: number;
  drAddressId?: number;
  jobClassId: number;
  descriptionValues: string;
  classificationDescription: string;
  jobClassificationList?: IClassificationOptions[];
}
export interface IClassificationOptions {
  jobCodeId: number;
  description: string;
  selected: boolean;
}

export interface IJobCodeModel {
  code: string;
  indexVal: number;
}
