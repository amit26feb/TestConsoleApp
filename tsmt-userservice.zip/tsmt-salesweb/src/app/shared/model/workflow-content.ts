export interface WorkflowContent {
  parentNode: string;
  childNodes?: WorkflowChildNode[];
}

export interface WorkflowChildNode {
  parentNode: string;
  childNodes?: WorkflowChildNode[];
}

export const workflowData: WorkflowContent[] = [
  {
    parentNode: 'Projects',
    childNodes: [
      { parentNode: '<a value="" class="not-hyperlinked">TIP</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Job Booking</a>' },
      {
        parentNode: 'Tax',
        childNodes: [
          {
            parentNode: '<a value="https://taxexempt.trane.com/ebiz/tktaxexempt/landing.aspx">Exemptions</a>',
          },
          {
            parentNode: '<a value="" class="not-hyperlinked">Tax Exemption Maintenance</a>',
          },
          {
            parentNode: '<a value="" class="not-hyperlinked">Tax Determination</a>',
          },
        ],
      },
      { parentNode: '<a value="" class="not-hyperlinked">Final Finisher</a>' },
      {
        parentNode: 'Credit / Purchase Documents',
        childNodes: [
          {
            parentNode: '<a value="" class="not-hyperlinked">Change Orders</a>',
          },
          {
            parentNode: '<a value="/orders/credit-requests">Combined Dashboard</a>',
          },
          {
            parentNode: '<a value="" class="not-hyperlinked">Contract Management </a>',
          },
          {
            parentNode: '<a value="/orders/credit-approvals/create">Credit Review (Includes PO Ack)</a>',
          },
          {
            parentNode: '<a value="" class="not-hyperlinked">CSS</a>',
          },
          {
            parentNode: '<a value="/orders/po-acknowledgements/create">PO Acknowledgement (ONLY PO Ack)</a>',
          },
        ],
      },
      { parentNode: '<a value="" class="not-hyperlinked">Startup</a>' },
      {
        parentNode: 'Shipping',
        childNodes: [
          {
            parentNode: '<a value="" class="not-hyperlinked">Ship Status</a>',
          },
          {
            parentNode: '<a value="" class="not-hyperlinked">Ship Change Request</a>',
          },
        ],
      },
      { parentNode: '<a value="" class="not-hyperlinked">Issuing Vendor Purchase Orders</a>' },
    ],
  },
  {
    parentNode: 'Administration/Accounts',
    childNodes: [
      { parentNode: '<a value="" class="not-hyperlinked">Forecasting/Estimate/ Budget</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Manual Print List/Queue</a>' },
      {
        parentNode: '<a value="http://ebsprdas.ad.corp.global">iReceivables</a>',
      },
      {
        parentNode: '<a value="https://tranetechnologies.sharepoint.com/sites/' +
          'ClaimsProcessingTool/SitePages/My%20Claims%20Dashboard.aspx">Claims</a>'
      },
      { parentNode: '<a value="" class="not-hyperlinked">LOA Approvals</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">CRM Setup/Maintenance</a>' },
      {
        parentNode: '<a value="https://tranetechnologies.sharepoint.com/sites/' +
          'BillingRequests/SitePages/Home.aspx">Billing Requests</a>'
      },
      { parentNode: '<a value="" class="not-hyperlinked">COJO</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Reporting Links</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Setting up Vendors</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Commissions and Splits</a>' },
      { parentNode: '<a value="https://tranetechnologies.sharepoint.com/sites/SCD5KNYC/SitePages/Home.aspx">A/R Disputes</a>' },
    ],
  },
  {
    parentNode: 'Customer Maintenance',
    childNodes: [
      { parentNode: '<a value="" class="not-hyperlinked">New Customer Application</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Reactivate/Inactivate Customer Accounts</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Tax Exemption Maintenance</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Validate Account Information</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Collections</a>' },
      { parentNode: '<a value="" class="not-hyperlinked">Credit Limit</a>' },
      {
        parentNode: 'Customer Payments',
        childNodes: [
          { parentNode: '<a value="" class="not-hyperlinked">Credit Card via Mobile</a>' },
          { parentNode: '<a value="" class="not-hyperlinked">ACH/EFT/WIRE</a>' },
        ],
      },
    ],
  },
  {
    parentNode: 'Work Flows',
    childNodes: [
      { parentNode: '<a value="manual-payment-request">Manual Payment</a>' },
    ],
  },
  {
    parentNode: 'Support',
    childNodes: [
      { parentNode: '<a value="support">Exception Queue</a>' },
      { parentNode: '<a value="orders/cms-commission-view">Gross Commission View</a>' },
    ],
  },
  {
    parentNode: 'Reporting',
    childNodes: [
      {
        parentNode: '<a value="https://obi.tranetechnologies.com/analytics/saw.dll?bipublisherEntry&Action=open&itemType=.xdo' +
          '&bipPath=%2FBI%20Published%20Reporting%2FHVAC%2FNA%2FAcquisition%2FAcquisition%2FShared%2FShip%20Cycle%20Report.xdo' +
          '&path=%2Fshared%2FBI%20Published%20Reporting%2FHVAC%2FNA%2FAcquisition%2FAcquisition%2FShared%2FShip%20Cycle%20Report.xdo">Ship Cycle Report</a>'
      },
    ],
  },
];
