export class SelectionlistModel {
  'pageNumber': number;
  'pageSize': number;
  'totalItemCount': number;
  'pageCount': number;
  'selectionList': [{
    'isConfiguredItem': boolean;
    'selectionId': number;
    'pricedIndicator': string;
    'orderedIndicator': string;
    'legacyOrderNumber': string;
    'tag': string;
    'productFamily': string;
    'selectionDescription': string;
    'qty': number;
    'reviseDate': any;
    'listPrice': number;
    'netPrice': number;
  }];
}
