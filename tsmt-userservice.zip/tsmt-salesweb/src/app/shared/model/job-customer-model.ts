export interface IJobCustomerModel {
    pageNumber: number;
    pageSize: number;
    totalItemCount: number;
    pageCount: number;
    customerList: ICustomerList[];
}

export interface ICustomerList {
    salesCustId: number;
    customerName: string;
    streetAddress1: string;
    streetAddress2: string;
    state: string;
    zipPlus: string;
    zipCode: string;
    phoneNbr: string;
    province: string;
    nonUsPostalCode: string;
    city: string;
    fipsCode: string;
    custAcctNbr: string;
    jobRoleTypeId: number;
    commCode: string;
    country: string;
    county: string;
    bidderInd: string;
    winningBidderInd: string;
    address: string;
    phoneExt: string;
    faxNbr: string;
    totalCount: number;
    firstName: string;
    lastName: string;
    region: string;
    jobRoleAsnId: string;
    crmCompanyId: string;
    jobRoleTypeName: string;
    customerCreditCategoryCode: string;
    customerChannelId: string;
}
