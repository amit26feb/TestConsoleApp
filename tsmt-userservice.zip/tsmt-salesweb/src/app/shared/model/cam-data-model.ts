export interface ICamInput {
    context: string;
    drAddressId: number;
    userId: string;
    hostData: ICamInputMetaData;
    localData: ICamInputMetaData;
}

export interface ICamInputMetaData {
    creditJobId: number;
    jobId: number;
}

export interface ICamExecutionStatus {
    status: string;
    notificationHeaderMessage: string;
    toasterMessage: string;
    messages: string[];
}

export enum CamContext {
    EditCopiedDownContext = 'EditCopiedDown',
    EditUntransmittedContext = 'EditUntransmitted',
    DeleteUntransmittedCreditJob = 'DeleteUntransmitted',
    ExitProjectContext = 'ExitProject',
    ExitProjectAndJobContext = 'ExitProjectAndJob',
    DeleteCopyDownCreditJob = 'DeleteCopyDown',
    ShipToSubmit = 'ShipToSubmit'
}

export enum CamStatus {
    Allow = 'ALLOW',
    Deny = 'DENY'
}
