export interface ILoginService {
    setauthenticationToken(value: string): void;
    getauthenticationToken();
}
