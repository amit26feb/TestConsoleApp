export interface IOfficePeopleModel {
    salesOfficeName: string;
    salesOfficeId: number;
    locationOffice: number;
    name: string;
    jobContactPersonFirstName: string;
    jobContactPersonLastName: string;
    managerContact: string;
    projectManagerContact: string;
    projectManagerUserId: string;
    buMfgLocationId?: number;
    changeAllowedIndicator: string;
    jobContact: string;
    commissionCode: string;
}
