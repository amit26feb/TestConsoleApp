export interface IWorkPackageBaseModel {
    workPackageName: string;
    workPackageId: number;
    crmOpportunityId: string;
    revenueStreamType: string;
    salesStage: string;
    salesOfficeId: number;
    revenueStreamName: string;
    siteId: number;
}
