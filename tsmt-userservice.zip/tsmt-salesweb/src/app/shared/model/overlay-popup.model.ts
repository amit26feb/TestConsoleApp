export interface IPopupClose {
    popupFlag: boolean;
    popupWidth: string;
}
