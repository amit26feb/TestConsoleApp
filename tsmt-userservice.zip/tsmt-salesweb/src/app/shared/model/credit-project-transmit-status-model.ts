export interface ICreditProjectTransmitStatus {
    isTransmitted: boolean;
    isCopiedDown: boolean;
    isRemnant: boolean;
}
