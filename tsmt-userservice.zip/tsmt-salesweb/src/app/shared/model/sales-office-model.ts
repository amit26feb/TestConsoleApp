export interface ISalesOfficeModel {
    salesOfficeId: number;
    salesOfficeName: string;
}
