export interface IJobModel {
    userId: string;
    nameFirst: string;
    nameLast: string;
    jobGeneral: IJobGeneral;
}

export interface IJobGeneral {
    jobId: number;
    drAddressId: number;
    jobName: string;
    tcpnNbr: string;
    tcpnContractNbr: string;
}
