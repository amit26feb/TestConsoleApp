export class BidsListModel {
  bidAlternateId: number;
  currentBidInd: string;
  bidName: string;
  description: string;
  creditJobNumber: string;
  purchaseOrderNumber: string;
  spaNumber: string;
  sellingPrice: string;
  baseBidYesNo: number;
  foe2CreatedOrdersInd: string;
  hqtrBidAlternateId: number;
  hqtrCreditJobId: number;
  isIncludeInCoordinatedJob: boolean;
  creditJobId: number;
  isRemnant: boolean;
  isCopiedDownCreditJob: boolean;
  isArchivedCreditJob: boolean;
  localCreditJobId: number;
  archivedCreditJobId: number;
  isTransmitted: boolean;
}

export class CarouselProjectDetailsModel {
  bidAlternateId: number;
  creditJobNumber: string;
  updatedProjectBidList: BidsListModel[];
}
