export interface ICommonTitle {
    jobId: number;
    drAddressId: number;
    nameToDisplay: string;
    currentUserId: string;
    lockedUserId: string;
    item: string;
    routeName: string;
    exitComponentName: string;
    isOfficeSelectorLabel: boolean;
    showExitButton: boolean;
    workPackageId?: number;
    workPackageLoggedUser?: string;
    action?: string;
}
