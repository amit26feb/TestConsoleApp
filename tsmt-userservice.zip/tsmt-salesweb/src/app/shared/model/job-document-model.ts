export interface IJobDocumentModel {
    pageNumber: number;
    pageSize: number;
    totalItemCount: number;
    pageCount: number;
    documentList: IDocumentList[];
}

export interface IDocumentList {
    jobId: number;
    drAddressId: number;
    documentSource: string;
    documentVersion: string;
    uploadedBy: string;
    totalCount: number;
    documentCount: number;
    jobDocumentId: number;
    documentKey: string;
    uploadedDate: any;
    notes: string;
    documentName: string;
    uploadedUserId: string;
    documentUpdateStatus: string;
}
