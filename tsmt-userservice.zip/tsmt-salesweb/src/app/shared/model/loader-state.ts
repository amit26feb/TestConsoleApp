export interface ILoaderState {
    show: boolean;
}
