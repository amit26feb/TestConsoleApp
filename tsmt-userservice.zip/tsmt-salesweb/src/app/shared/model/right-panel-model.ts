import { Type } from '@angular/core';
import { ICommissionSplits, IFinalFinisherModel,
    IOrderLineDetailRightPanel, ISeparateBillingModel, IShipmentAndDeliveryModel } from '../../modules/orders/models/order-line.model';
export interface IRightPanelModel {
    rightPanel: boolean;
    rightPanelTitle: string;
    menuList: IMenuList[];
    rightPanelContent: IRightPanelContentModel;
}

export interface IMenuList<T = any> {
    text: string;
    route: string;
    componentName: Type<T>;
}

export interface IRightPanelContentModel {
    shippingAndDeliveryData?: IShipmentAndDeliveryModel;
    finalFinisherData?: IFinalFinisherModel;
    orderLineData?: IOrderLineDetailRightPanel;
    commissionSplitsData?: ICommissionSplits[];
    salesOrderNote?: string;
    separateBillingData?: ISeparateBillingModel;
    orderLineNote?: string;
}
