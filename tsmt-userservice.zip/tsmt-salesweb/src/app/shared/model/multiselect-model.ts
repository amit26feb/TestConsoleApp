export interface IMultiselectModel {
    text: string;
    status: string;
}
