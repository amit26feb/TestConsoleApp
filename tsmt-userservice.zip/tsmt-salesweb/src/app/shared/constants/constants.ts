import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable()
export class AppConstants {
  public SHIP_TO_ADDRESSES_DELIVERY_INFO_MESSAGE = 'Fill in all mandatory fields in the Delivery tab';
  public HISTORY_GRID_HEIGHT = 116;
  public SECRET_KEY = 'IRPOC';
  public applicationId = 'SalesWeb';
  public baseUrl = environment.apiUrl;
  public SIGNIN = `${this.baseUrl}/techfoundation/api/v1/login/ValidateUser`;
  public API_BASE_URL_BIDS = `${this.baseUrl}/bid/api`;
  public API_BASE_URL_JOB_SELECTION = `${this.baseUrl}/jobselection/api/v1`;
  public API_BASE_URL_USER = `${this.baseUrl}/user/api/v1`;
  public API_BASE_URL_USER_V2 = `${this.baseUrl}/user/api/v2`;
  public API_BASE_URL_LOGIN = `${this.baseUrl}/techfoundation/api/v1`;
  public API_BASE_URL_PRODUCT = `${this.baseUrl}/product/api/v1`;
  public API_BASE_URL_JOB = `${this.baseUrl}/job/api/v1`;
  public BUSINESSDATA_BASE_URL = `${this.baseUrl}/businessdata/api/v1`;
  public API_BASE_URL_SALESWEBGATEWAY = `${this.baseUrl}/saleswebgateway/api/v1`;
  public API_BASE_URL_SALESROLLUP = `${this.baseUrl}/salesrollup/api/v1`;
  public API_BASE_URL_WORKPACKAGE = `${this.baseUrl}/workpackage/api/v1`;
  public API_BASE_URL_INTERVENTION = `${this.baseUrl}/intervention/api/v1`;
  public API_BASE_URL_DOCUMENTPACKAGE = `${this.baseUrl}/documentpackage/api/v1`;
  public API_BASE_URL_COMMISSION = `${this.baseUrl}/orderingcommission/api/v1`;
  public API_BASE_URL_ORDERED_COMMISSION = `${this.baseUrl}/orderedcommission/api/v1`;
  public API_BASE_URL_CREDIT_JOBS = `${this.baseUrl}/order/api/v1`;
  public API_BASE_URL_ORDER_HISTORY = `${this.baseUrl}/orderhistory/api/v1`;
  public API_BASE_URL_BILLING_BUSINESS = `${this.baseUrl}/billingbusiness/api/v1`;
  public API_BASE_URL_ORDER = `${this.baseUrl}/ordering/api/v1`;
  public API_BASE_URL_PRICEROLLUP = `${this.baseUrl}/pricerollup/api/v1`;
  public API_BASE_URL_BUSINESS_RULES_ENGINE = `${this.baseUrl}/businessrulesengine/api/v1`;
  public MTOPSS_BASE_URL = `${environment.mTopssUrl}`;
  public API_BASE_URL_JOBSCORING = `${this.baseUrl}/jobscoring/api/v1`;
  public API_BASE_URL_ORDERGATEWAY = `${this.baseUrl}/ordergateway/api/v1`;
  public API_BASE_URL_SHIPPING_HISTORY = `${this.baseUrl}/manufacturingordermaintenance/api/v1`;
  public API_BASE_URL_CAMGATEWAY = `${this.baseUrl}/camgateway/api/v1`;
  public API_BASE_URL_DOCUMENT = `${this.baseUrl}/document/api/v1`;
  public ACCESS_DENIED = 'This user does not have permission to access this application,<br>' +
    ' please contact your application support team for assistance.';
  public OKTA_ACCESS_DENIED = 'This user is unauthorized to access this application,<br>' +
    ' please contact your application support team for assistance.';
  public TRANE_CRM_COMPANY_URL = `${environment.crmCompanyUrl}`;
  public TRANE_CRM_OPPY_URL = `${environment.crmOppyUrl}`;
  public BID_NAME_UNIQUE_MESSAGE = 'Bid Name should be unique';
  public BASE_BID_UNIQUE_MESSAGE = 'Bid name cannot start with ‘Base’ and contain ‘bid’';
  public REQUIRED_FIELD_MESSAGE = 'Field is required';
  public EDIT_BID_NAME_UNIQUE_MESSAGE = 'Please try to use unique bid name';
  public STATUS_LIST = [{ text: 'Open', status: 'Open' }, { text: 'Closed - Abandoned', status: 'Closed - Abandoned' },
  { text: 'Closed - Committed', status: 'Closed - Committed' }, { text: 'Closed - Lost', status: 'Closed - Lost' },
  { text: 'Closed - Ordered', status: 'Closed - Ordered' }, { text: 'Closed - Transitioned', status: 'Closed - Transitioned' },
  { text: 'Closed - Won', status: 'Closed - Won' }, { text: 'Inactive', status: 'Inactive' },
  ];
  public KENDO_GRID_HEIGHT_INFO = {
    classNames: ['header', 'footer', '.header', '.gridOptions', '.panel-box-shadow', '.project-header', '.center-header-text'],
    overlayClassNames: ['.project-type', '.form-group', '.selected-information'],
    gridType: 'kendo',
  };
  public CUST_CHANNEL_ID = [{ text: '$USD', custChannelId: 'COMMSALE' }, { text: '$CDN', custChannelId: 'CANADA' }];
  public CREDIT_PROJECT_TYPE = [{ text: 'JIS', value: 'JIS' }, { text: 'OIS', value: 'OIS' },
  { text: 'PRI', value: 'PRI' }, { text: 'TST', value: 'TST' }];
  public CREDIT_PROJECT_TYPE_JIS_DROPDOWN = [{ text: 'JIS', value: 'JIS' }];
  public CREDIT_PROJECT_TYPE_OIS_DROPDOWN = [{ text: 'OIS', value: 'OIS' }];
  public PEOPLESOFT_PROJECT_CREATED = [
    { text: 'Y', value: 'Y', selected: false },
    { text: 'N', value: 'N', selected: false },
  ];
  public TYPE_CONFIGURED = 'Configured';
  public TYPE_SEPARATELY_BIDDABLE = 'Separately Biddable';
  public TYPE_NON_TRANE = 'Non-Trane';
  public TYPE_NON_CONFIGURED = 'Non-Configured';
  public DOC_PACK_DEFAULT_GREETING_MESSAGE = '<LegalEntityLongName> is pleased to provide ' +
    'the following <DocumentTypeShortName> for your review and approval.';
  public BIDS_SELECTIONS_UNCHECKED_ORDER_CHECKBOX_MESSAGE = 'Selections cannot be removed from the bid on which they were ordered.';
  public BIDS_CURRENTLY_LOCKED_USER_MESSAGE = 'Changes cannot be saved as the job is currently locked to ';
  public BIDS_ADD_REMOVE_SEPARATELY_BIDDABLE_MESSAGE = 'Separately biddable items cannot removed or added to the bid for ' +
    'this product. \n In order to create an equipment only bid please reconfigure the selection and remove selected control items. ' +
    'For a controls only bid please reference the controls product code pricing in the price rollup.';
  public BIDS_SEPARATELY_BIDDABLE_UNCHECKED_ORDER_CHECKBOX_MESSAGE = 'Separately biddable items cannot be ' +
    'removed from the bid on which they were ordered.';
  public BIDS_VARIATIONS_UNCHECKED_ORDER_CHECKBOX_MESSAGE = 'Variations cannot be removed from the bid on which they were ordered.';
  public BIDS_ALL_SELECTIONS_UNCHECKED_ORDER_CHECKBOX_MESSAGE = 'Some or all selections could not be removed from the bid on which ' +
    'they were ordered';
  public DEFAULT_TERMS_AND_CONDITIONS = 'Installation';
  public CREATE_COST_CONTAINER_WARNING_MESSAGE = `There is unsaved data on the page.<br/> Do you want to go back without saving?`;
  public PO_MATCH_DETAILS_SAVE_SUCCESS_MESSAGE = 'Purchase Order details have been saved.';
  public PO_MATCH_DETAILS_UPDATE_SUCCESS_MESSAGE = 'Purchase Order details have been updated.';
  public PO_MATCH_DETAILS_UPDATE_FAILURE_MESSAGE = 'Purchase Order details could not be updated due to internal issues.';
  public PO_MATCH_DETAILS_SAVE_STORE_MESSAGE = 'PO match details saved';
  public PO_MATCH_DETAILS_UPDATE_STORE_MESSAGE = 'PO match details updated';
  public PO_MATCH_DETAILS_DELETE_MESSAGE = 'PO match details deleted successfully';
  public JOB_DETAILS_SUCCESS_MESSAGE = 'section data has been saved.';
  public JOB_DETAILS_DATABASE_ERROR_MESSAGE = 'section data could not be saved due to internal issues.';
  public JOB_DETAILS_VALIDATION_ERROR_MESSAGE = 'Please enter all the highlighted fields';
  public JOB_DETAILS_DOCUMENTS_FORBIDDEN_FILE_LIST = ['.exe', '.com', '.dll', '.sh', '.ps', '.bat', '.cmd', '.vbs', '.py', '.cs'];
  public JOB_DETAILS_DOCUMENTS_MULTIPLE_FILE_UPLOAD_MESSAGE = 'Multiple files cannot be uploaded. Please select single file to proceed';
  public JOB_DETAILS_DOCUMENTS_FORBIDDEN_MESSAGE = 'File types .exe, .com, .dll, .sh, .ps, .bat, .cmd, .vbs, .py cannot be uploaded';
  public JOB_DETAILS_DOCUMENTS_JOB_CURRENTLY_LOCKED_USER_MESSAGE = 'File cannot be staged for upload as the job is locked by';
  public JOB_DETAILS_DOCUMENTS_EXIT_CONFIRMATION_MESSAGE = 'The selected file and notes will no longer be available to ' +
    'upload and save. Do you want to proceed?';
  public JOB_DETAILS_DOCUMENTS_REQUIRED_FIELD_MESSAGE = 'Please select a file to proceed';
  public JOB_DETAILS_DOCUMENTS_UPLOAD_JOB_CURRENTLY_LOCKED_USER_MESSAGE = 'File cannot be uploaded as the job is locked by';
  public JOB_DETAILS_DOCUMENTS_UPLOAD_SUCCESS_MESSAGE = 'File uploaded successfully';
  public JOB_DETAILS_DOCUMENTS_UPLOAD_ERROR_MESSAGE = 'Request timeout';
  public COORDINATE_JOB_SAVE_ERROR_MESSAGE = 'Error occurred while saving. Please try again';
  // tslint:disable-next-line: max-line-length
  public LEGAL_ENTITY_HELP_URL = 'https://tranetechnologies.sharepoint.com/:w:/r/sites/ClimateSolutionsLegal/ServicesandContracting/State%20Contractor%20Licensing/Guidelines%20on%20use%20of%20Trane%20Energy%20Services%20LLC.docx';
  public IMPORT_JOB_DOCUMENTS_FORBIDDEN_MESSAGE = 'File extension type other than .json cannot be uploaded';
  public IMPORT_JOB_DOCUMENTS_VALID_FILE_LIST = ['.json'];
  public IMPORT_JOB_EXIT_CONFIRMATION_MESSAGE = 'The selected file and data entered will no longer be available for import. ' +
    'Do you want to proceed?';
  public ROLLUP_UNPRICED_SELECTIONS_MESSAGE = 'The current bid contains unpriced selections that will not be in the rollup.';
  public ROLLUP_UNABLE_TO_EDIT_BECAUSE_LOCK_MESSAGE = 'Unable to edit the rollup because the job is locked by another user';
  public DOCUMENTS_SERVER_ERROR_MESSAGE = 'Internal server error';
  public DOCUMENT_LINKED_MESSAGE = 'This document is linked. ';
  public DOCUMENT_OVERWRITE_MESSAGE = 'Are you sure you want to overwrite ';
  public DOCUMENT = ' document?';
  public DOCUMENT_NOTIFICATION_MESSAGE = ' its history and notes?';
  public DOCUMENTS_DELETE_SUCCESS_MESSAGE = 'Document deleted successfully';
  public DOCUMENTS_DELETE_FAILED_MESSAGE = 'Document delete failed';
  public PROPERTIES_EXIT_WARNING_MESSAGE = 'Invalid Data entered / Mandatory fields are not filled.<br>'
    + 'Do you want to exit without saving?';
  public NOTIFICATION_TEXT = 'You have new notifications';
  public NOTIFICATION_INTERVAL = 15000;
  public ORDER_LINE_NO_DATA_MESSAGE = 'No order line details found.';
  public EXCEL_FILE_MIME_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  public INTERNAL_SERVER_ERROR_MESSAGE = 'Internal server error';
  public GRID_NO_DATA_MESSAGE = 'No records available.';
  public GRID_NO_EVENTS_MESSAGE = 'No events found.';
  public BILLING_HISTORY_EXCEL_HEADER_OPTION = { background: '#fff', color: '#f00' };
  public BILL_LINE_DETAILS_EXCEL_HEADER_OPTION = { background: '#fff', color: '#00f' };
  public BILLING_HISTORY_COLUMNS = [
    { title: 'Status', field: 'eventStatus' },
    { title: 'Entry Type', field: 'entryType' },
    { title: 'Bill Source', field: 'billSource' },
    { title: 'Order #', field: 'orderId' },
    { title: 'P/S #', field: 'plannedShipmentId' },
    { title: 'R12 Ship to Site #', field: 'shipToSiteId' },
    { title: 'Event Date', field: 'eventDate' },
    { title: 'Trans. #', field: 'transactionId' },
    { title: 'Trans. Date', field: 'transactionDate' },
    { title: 'Total Pretax Amount', field: 'totalPretaxAmount', cellOption: { format: '$#,##0.00' } },
    { title: 'Total Tax Amount', field: 'totalTaxAmount', cellOption: { format: '$#,##0.00' } },
    { title: 'Total Invoice Amount', field: 'totalInvoiceAmount', cellOption: { format: '$#,##0.00' } },
  ];
  public BILL_LINE_DETAILS_COLUMNS = [
    { title: 'Qty.', field: 'quantityBilled', width: 200 },
    { title: 'Prod. Code', field: 'manufacturingProductCode', width: 200 },
    { title: 'Line Type', field: 'lineType', width: 200 },
    { title: 'Line Description', field: 'lineDescription', width: 500 },
    { title: 'Pretax Amount', field: 'preTaxAmount', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Tax Amount', field: 'taxAmount', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Invoice Amount', field: 'invoiceAmount', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Line Note', field: 'lineNote', width: 500 },
  ];
  public CUSTOM_INVOICE_COLUMNS = [
    { title: 'Status', field: 'eventStatus', width: 200 },
    { title: 'Entry Type', field: 'entryType', width: 200 },
    { title: 'Bill Source', field: 'billSource', width: 200 },
    { title: 'Trans. #', field: 'transactionId', width: 200 },
    { title: 'Trans. Date', field: 'transactionDate', width: 200 },
    { title: 'Custom Invoice Total Pretax Amount', field: 'totalPretaxAmount', cellOption: { format: '$#,##0.00' }, width: 250 },
    { title: 'Custom Invoice Total Tax Amount', field: 'totalTaxAmount', cellOption: { format: '$#,##0.00' }, width: 250 },
    { title: 'Custom Invoice Total Invoice Amount', field: 'totalInvoiceAmount', cellOption: { format: '$#,##0.00' }, width: 250 },
    { title: 'Custom Invoice Event Note', field: 'eventNote', width: 500 },
    { title: 'Custom Invoice Qty', field: 'quantityBilled', width: 200 },
    { title: 'Custom Invoice Line Description', field: 'lineDescription', width: 500 },
    { title: 'Custom Invoice Unit Price', field: 'unitPrice', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Custom Invoice Pretax Amount', field: 'preTaxAmount', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Custom Invoice Line Note', field: 'lineNote', cellOption: { format: '$#,##0.00' }, width: 500 },
  ];
  public SHIPMENT_DETAILS_COLUMNS = [
    { title: 'Order#', field: 'orderId', width: 200 },
    { title: 'P/S #', field: 'plannedShipmentId', width: 200 },
    { title: 'R12 Ship to Site #', field: 'shipToSiteId', width: 200 },
    { title: 'Event Date', field: 'eventDate', width: 200 },
    { title: 'Total Shipment Pretax Amount', field: 'totalPretaxAmount', cellOption: { format: '$#,##0.00' }, width: 250 },
    { title: 'Total Shipment Tax Amount', field: 'totalTaxAmount', cellOption: { format: '$#,##0.00' }, width: 250 },
    { title: 'Total Shipment Invoice Amount', field: 'totalInvoiceAmount', cellOption: { format: '$#,##0.00' }, width: 250 },
    { title: 'Shipment Event Note', field: 'eventNote', cellOption: { format: '$#,##0.00' }, width: 500 },
    { title: 'Qty', field: 'quantityBilled', width: 200 },
    { title: 'Prod. Code', field: 'manufacturingProductCode', width: 200 },
    { title: 'Line Type', field: 'lineType', width: 200 },
    { title: 'Line Description', field: 'lineDescription', width: 500 },
    { title: 'Pretax Amount', field: 'preTaxAmount', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Tax Amount', field: 'taxAmount', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Invoice Amount', field: 'invoiceAmount', cellOption: { format: '$#,##0.00' }, width: 200 },
    { title: 'Line Note', field: 'lineNote', cellOption: { format: '$#,##0.00' }, width: 500 },
  ];
  public PENDING_CONSOLIDATION_COLUMNS = [{ title: 'Status', field: 'eventStatus' },
  { title: 'Bill Source', field: 'billSource' },
  { title: 'Order #', field: 'orderId' },
  { title: 'P/S #', field: 'plannedShipmentId' },
  { title: 'R12 Ship to Site #', field: 'shipToSiteId' },
  { title: 'Event Date', field: 'eventDate', width: 100 },
  { title: 'Total Pretax Amount', field: 'totalPretaxAmount', cellOption: { format: '$#,##0.00' } },
  { title: 'Event Note', field: 'eventNote', cellOption: { format: '$#,##0.00' }, width: 500 },
  { title: 'Qty.', field: 'quantityBilled', width: 100 },
  { title: 'Prod. Code', field: 'manufacturingProductCode', width: 100 },
  { title: 'Line Type', field: 'lineType', width: 100 },
  { title: 'Line Description', field: 'lineDescription', width: 500 },
  { title: 'Pretax Amount', field: 'preTaxAmount', cellOption: { format: '$#,##0.00' }, width: 150 },
  { title: 'Line Note', field: 'lineNote', width: 500 },
  ];
  public CONSOLIDATED_BILLING_HEADER_OPTION = { background: '#fff', color: '#000', bold: true };
  public POST_CONSOLIDATION_FILENAME = 'Consolidated Billing Export.xlsx';
  public PENDING_CONSOLIDATION_FILENAME = 'Pending Consolidation Export.xlsx';
  public SHIP_TO_ADDRESSES_CREATE_INFO_MESSAGE = 'Fill in all mandatory fields in the Addresses and Delivery tabs ' +
    'to enable the Next button.';
  public SHIP_TO_ADDRESSES_EDIT_INFO_MESSAGE = 'Fill in all mandatory fields in the Addresses and Delivery tabs.';
  public PO_MATCH_INFO_MESSAGE = 'To remove PO Match Template, change the Invoice Method above.';
  public EQUIPMENT_COMMISSION_TYPE = 'EQUIPMENT';
  public CONTRACT_COMMISSION_TYPE = 'CONTRACT';
  public NON_TRANE_EDIT_WARNING = 'Non-Trane item cannot be edited as the non-trane items is in Ordered status';
  public NON_TRANE_DATA_LOST_WARNING = 'There is unsaved data in the Non-Trane Details section.  Do you want to continue without saving?';
  public ERROR_TEXT = 'ERROR';
  public PENDING_TEXT = 'Pending';
  public PENDING_CONSOLIDATION_TEXT = 'Pending Consolidation';
  public COMPLETED_TEXT = 'Completed';
  public FAILED_TEXT = 'Failed';
  public WARNING_TEXT = 'warning';
  public ERROR_VALUE = 'error';
  public ALL_EVENTS_TEXT = 'All Events';
  public NON_TRANE_ADDED_FAILURE = 'Error occurred while saving the Non-Trane item';
  public NON_TRANE_UPDATED_SUCCESS = 'Non Trane item updated successfully';
  public PO_ADDENDUM_SAVE_SUCCESS = 'PO Addendum has been saved';
  public SUPPORT_DATABASE_DR_ADDRESS_ID = 142;
  public APPLICATION_JSON = 'application/json';
  public DELETE_BUTTON_TEXT = ['CANCEL', 'DELETE'];
  public UNSAVED_DATA_WARNING_MESSAGE = `There is unsaved data on the page.<br/>Do you want to continue without saving?`;
  public NOT_ENABLED = 'This is currently not enabled';
  public CREDIT_SUPPLEMENT_ACCEPTED_INFO_MESSAGE = 'This Credit Supplement Sheet has been accepted and may not be modified.';
  public ADDITIONAL_INVOICE_DELIVERY_EMAILS_INFO_MESSAGE = 'Supplements Oracle Customer Delivery Method';
  public OVERRIDE_EMAILS_WARNING_MESSAGE = 'Overrides Oracle customer delivery method - valid for Print or Email delivery method only.';
  public PLANNED_SHIPMENT_COLUMNS = [
    {
      columnName: 'P/S',
      class: 'col w-grid-80',
    },
    {
      columnName: 'R12 SO',
      class: 'col',
    },
    {
      columnName: 'Ordr. Stat.',
      class: 'col',
    },
    {
      columnName: 'Mfg. Stat.',
      class: 'col',
    },
    {
      columnName: 'Shp. Instr.',
      class: 'col',
    },
    {
      columnName: 'Partial Ship OK',
      class: 'col',
    },
    {
      columnName: 'Req. Dlv. Win.',
      class: 'col',
    },
    {
      columnName: 'Est. Shp. Date',
      class: 'col',
    },
    {
      columnName: 'Shp. Date',
      class: 'col',
    },
    {
      columnName: '',
      class: 'col w-grid-40',
    },
  ];

  public CREDIT_JOB_HISTORY = 'Credit';
  public SALES_ORDER_HISTORY = 'SalesOrder';
  public PLANNED_SHIPMENT_HISTORY = 'PlannedShipment';
  public WORK_PACKAGE_URL = '/WorkPackages/';
  public DATE_FORMAT = 'MM/dd/yyyy';
  public GRID_PAGE_LENGTH = 10;
  public PROJECT_HEADER_COLUMNS = [
    {
      columnName: 'Job Name',
      class: 'col-2 jobName',
    },
    {
      columnName: 'Project Nbr.',
      class: 'col-2 projectNbr',
    },
    {
      columnName: 'Project Name',
      class: 'col-2 projectName',
    },
    {
      columnName: 'Job Contact',
      class: 'col-2 jobContact',
    },
    {
      columnName: 'Customer Name',
      class: 'col-2 customerName',
    },
    {
      columnName: 'Date',
      class: 'col-1',
    },
  ];
  public SHIPPING_HISTORY_HEADER_COLUMNS = [
    {
      columnName: 'Serial Number',
      class: 'col-1 serialNumber',
    },
    {
      columnName: 'Order Number',
      class: 'col-1 orderName',
    },
    {
      columnName: 'Mfg Location',
      class: 'col-2 buMfgLocation',
    },
    {
      columnName: 'Job Name',
      class: 'col-1 jobName',
    },
    {
      columnName: 'Ship Date',
      class: 'col-1 shipDate',
    },
    {
      columnName: 'Ship To',
      class: 'col-1 shipTo',
    },
    {
      columnName: 'Model Number',
      class: 'col-2 modelNum',
    },
    {
      columnName: 'File Name',
      class: 'col-1 fileName',
    }
  ];
  public TRANSMIT_BALANCE_INFO = `There has been changes to the project that has caused it to be out of balance with R12 Financials. The date is the last date it was in balance. Please review Price Summary and transmit changes.`;
  public DELETE_CONFIRMATION = 'Are you sure you want to delete ';
  public FORM_STATUS_INVALID = 'INVALID';
  public FORM_STATUS_VALID = 'VALID';
  public DROPDOWN_LIST = [{ text: 'Fs Review', status: 'Fs Review' }, { text: 'Bu Pending', status: 'Bu Pending' },
  { text: 'Cancelled', status: 'Cancelled' }, { text: 'Bu Review', status: 'Bu Review' }, { text: 'So Cancel', status: 'So Cancel' },
  { text: 'Bu Cancel', status: 'Bu Cancel' }, { text: 'Fs Pending', status: 'Fs Pending' }, { text: 'Approved', status: 'Approved' }];
  public PO_ADDENDUM_CANCELLED = 'Cancelled';
  public No_JOBS_CRITERIA = 'No jobs meet criteria.';
  public BIDDING_IN_THE_NEXT_90_DAYS = 'Bidding in the next 90 days';
  public SALESPERSON = 'Sales Person';
  public JOBCONTACT = 'Job Contact';
  public SALESMANAGER = 'Sales Manager';
  public SALES_ORDERS_NO_DATA_MESSAGE = 'No sales order(s) available';
  public CREDIT_PROJECT_TYPE_JIS = 'JIS';
  public CREDIT_PROJECT_TYPE_OIS = 'OIS';
  public JOBS_BY_JOB_CONTACT = 'Jobs by Job Contact';
  public NON_TRANE = 'Non-Trane';
  public TRANE_PARTS = 'Trane Parts';
  public TRANE = 'Trane';
  public DEFAULT_CAROUSEL_CONFIG = {
    infinite: false,
  };
  // These class codes are corresponding to Transistional Job, Vertical Market, BOD on Equipments, BOD on Controls respectively.
  // since these class codes are already available in genral section, we are excluding from classification.
  public CRM_CLASSIFICATION_EXCLUDED_CLASSCODES = [7, 38, 108, 109];
  public UPDATE_FORM = 'UPDATE_FORM';
  public AD_INVALID_MAILID = '@irco365.com';
  public REVENUE_STREAM_TYPE = { contracting: 'Controls-Contracting', services: 'Service' };
  public FILE_GENERATION_INPROGRESS = 'Document package has been saved; file generation in process.';
  public MANDATORY_FIELDS_ERRMSG = 'Required fields must be input to continue.';
  public FILE_NOT_GENERATED = 'Document package could not be saved. File cannot be generated.';
  public SUCCESS_VALUE = 'success';
  public COMMISSIONSPLIT_SAVE_FAILURE = 'Error occurred while saving commission splits';
  public SPECIAL_KEYS = ['ArrowLeft', 'ArrowRight', 'Home', 'End', 'Backspace', 'Delete', 'Enter', 'Tab', 'Control'];
  public CREDIT_JOB_COMMISSION_SPLIT_SAVE_SUCESS = 'Changes applied to credit job Commission split are saved. Use \'Apply To Orders\' button to cascade changes to sales orders.';
  public COMMISSION_SPLIT_SAVE_SUCESS = 'Commission split data has been saved';
  public COMMISSION_SPLIT_SAVE_FAILURE = 'Changes in commission split panel could not be saved';
  public EDIT_PROJECT = 'Are you sure that you would like to edit this project?';
  public UNDO_TRANSMITTED_CREDIT_PROJECT = 'Undo any untransmitted changes that have been made since the '
    + 'last transmit for this Credit Project from your Sales Office database. Changes made to pending '
    + 'committed (CMTD) Sales orders will not be removed. Do you wish to continue?';
  public DELETE_UNTRANSMITTED_CREDIT_PROJECT = `Are you sure that you want to delete the credit project and all the
  attached sales orders from your local database?`;
  public DELETE_COPIED_DOWN_CREDIT_PROJECT = `Any changes since the last transmit will be removed
  from your sales office database for this credit job. Changes made to pending committed (CMTD) sales
  orders will not be removed.<br><br>`
    + 'Do you wish to continue?';
  public EXPORT_TO_EXCEL_SUCCESS_TOASTER =
    'Your Export request has been accepted. You will receive a notification shortly on the request status';
  public EXPORT_TO_EXCEL_ERROR_TOASTER = 'Error occured while exporting to file';

  public TRANSMIT_PROJECT = 'Are you sure that you want to transmit?';
  public TRANSMIT_CREDIT_PROJECT_ERROR_TOASTER = 'Error occured during Transmit';
  public TRANSMIT_CREDIT_PROJECT_SUCCESS_TOASTER = 'Transmission is successfully completed';
  public COPYDOWN_ERROR_TOASTER = 'Error occurred while trying to enable editing, please contact support for resolution.';
  public COMMISSIONSPLIT_SALESORDER_SAVE_SUCCESS =
    'The below list of Sales Orders were updated as indicated by the ‘Will be Updated’ column.';
  public YES_NO_BUTTON_TEXT = ['NO', 'YES'];
  public INFO_DIALOG_BUTTON_TEXT = ['OK'];
  public DELETE_CONFIRM_STATUS = 'delete';
  public TransmittedCopiedDownDisplayMode = 'TransmittedCopiedDown';
  public ShippingHistoryDisplayMode = 'Shipping History';
  public CUSTOM_SENDER_SAVED = 'The Custom Sender is saved';
  public CUSTOM_SENDER_UPDATED = 'The Custom Sender is updated';
  public SENDER_NAME_WARNING_MESSAGE = ' has already been saved as a Custom Sender';
  public CUSTOM_SENDER_NOT_UPDATED = 'The Custom Sender could not be updated';
  public SHIPPING_HISTORY_DOWNLOAD_REQUEST = 'Your download request has been accepted. You will receive a notification shortly on the request status';
  public WORKPACKAGE_PAGE = {
    configureContainer: 'configure-container',
    addContainer: 'add-container', createCostContainer: 'create-cost-container',
    workPackage: 'work-package', properties: 'properties', workPackages: 'work-packages', create: 'create',
    placeholderToSiteInstall: 'placeholder-to-siteinstall', contract: 'contract', fulfillment: 'fulfillment',
  };
  public ENTER_VALID_EMAIL_MESSAGE = 'Please enter a valid email address';
  public VALID_EMAIL_REGEX_PATTERN: RegExp = /^[a-z0-9._%+-]+@[a-z0-9.]+\.[a-z]{2,4}$/;
  public VALIDATE_EMAIL_REGEX_PATTERN_UPPERCASE: RegExp = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.]+\.[A-Za-z]{2,4}$/;
  public INVOICE_METHOD_PROFORMA_CODE = 'PRO';
  public INVOICE_METHOD_LIST = [{
    name: 'Default',
    code: 'DEF',
    isOracleMethod: true,
  },
  {
    name: 'Consolidated Non PO Match',
    code: 'CON',
    isOracleMethod: true,
  },
  {
    name: 'Consolidated PO Match',
    code: 'CPO',
    isOracleMethod: true,
  }];
  public INVOICE_METHOD_PROFORMA_VALUE = {
    name: 'Proforma',
    code: this.INVOICE_METHOD_PROFORMA_CODE,
    isOracleMethod: true
  };
  public INVOICE_FORMAT_DROPDOWN_LIST = [{
    name: 'Lump Sum',
    code: 'LS',
  },
  {
    name: 'Net Each',
    code: 'NE',
  }];
  public INVOICE_METHOD_DROPDOWN_LIST = [{
    name: 'Default',
    code: 'DEF',
    isOracleMethod: true,
  },
  {
    name: 'Consolidated Non PO Match',
    code: 'CON',
    isOracleMethod: true,
  },
  {
    name: 'Consolidated PO Match',
    code: 'CPO',
    isOracleMethod: true,
  },
  {
    name: 'Progressive',
    code: 'PRG',
    isOracleMethod: true,
  },
  {
    name: 'Custom',
    code: 'CUS',
    isOracleMethod: false,
  },
  {
    name: 'Prepaid Commission',
    code: 'PPC',
    isOracleMethod: false,
  },
  {
    name: 'Proforma',
    code: 'PRO',
    isOracleMethod: false,
  },
  {
    name: 'Regular',
    code: 'REG',
    isOracleMethod: false,
  },
  {
    name: 'Review',
    code: 'REV',
    isOracleMethod: false,
  }];

  public INVOICE_FORMAT_ORACLE_DEFAULT_CODE = 'NE';
  public INVOICE_FORMAT_NONORACLE_DEFAULT_CODE = 'LS';
  public INVOICE_METHOD_ORACLE_DEFAULT_CODE = 'DEF';
  public INVOICE_METHOD_CONSOLIDATED_PO_MATCH = 'CPO';
  public INVOICE_METHOD_CONSOLIDATED_NON_PO_MATCH = 'CON';
  public INVOICE_METHOD_NONORACLE_DEFAULT_CODE = 'REG';
  public VERTICAL_MARKET_CLASS_CODE = 38;
  public BOD_ON_CONTROLS_CLASS_CODE = 109;
  public BOD_ON_EQUIPMENTS_CLASS_CODE = 108;
  public CREDIT_PROJECT_SAVE_MESSAGE = 'Credit Project Saved';
  public JOB_DATA_SAVE_MESSAGE = 'Job Data Saved';
  public REVENUE_DROP_DOWN = [{
    text: 'Contracting',
    type: 'Contracting',
    fieldValue: 'Turnkey'
  },
  {
    text: 'Equipment',
    type: 'System',
    fieldValue: 'Indirect'
  },
  {
    text: 'Service',
    type: 'Service',
    fieldValue: 'Service'
  }];
  public CONTACT_GRID = 'Contact';
  public SITE_GRID = 'Site';
  public COMPANY_GRID = 'Company';
  public DELETE_CREDIT_PROJECT_SUCCESS_MESSAGE = 'Credit project has been deleted successfully.';
  public DELETE_UNTRANSMITTED_CREDIT_PROJECT_SUCCESS_MESSAGE = 'Untransmitted changes have been successfully deleted.';
  public DELETE_CREDIT_PROJECT_FAILURE_MESSAGE = 'Credit project could not be deleted';
  public MFG_STATUS_FOR_GRIDFILTER = [{
    text: 'SHPD',
    mfgStatus: 'SHPD'
  },
  {
    text: 'RLSD',
    mfgStatus: 'RLSD'
  },
  {
    text: 'CMTD',
    mfgStatus: 'CMTD'
  },
  {
    text: 'OIP',
    mfgStatus: 'OIP'
  },
  {
    text: 'DESN',
    mfgStatus: 'DESN'
  },
  {
    text: 'TSCH',
    mfgStatus: 'TSCH'
  },
  {
    text: 'PLAN',
    mfgStatus: 'PLAN'
  },
  {
    text: 'MFG',
    mfgStatus: 'MFG'
  },
  {
    text: 'BILT',
    mfgStatus: 'BILT'
  },
  {
    text: 'ALLO',
    mfgStatus: 'ALLO'
  },
  {
    text: 'TPLN',
    mfgStatus: 'TPLN'
  },
  {
    text: 'OSHP',
    mfgStatus: 'OSHP'
  },
  {
    text: 'TSHP',
    mfgStatus: 'TSHP'
  },
  {
    text: 'USHP',
    mfgStatus: 'USHP'
  },
  {
    text: 'SHFF',
    mfgStatus: 'SHFF'
  },
  {
    text: 'CANC',
    mfgStatus: 'CANC'
  }];
  public ORDER_STATUS_FOR_GRIDFILTER = [{
    text: 'SHPD',
    salesOrderStatus: 'SHPD'
  },
  {
    text: 'RLSD',
    salesOrderStatus: 'RLSD'
  },
  {
    text: 'CMTD',
    salesOrderStatus: 'CMTD'
  },
  {
    text: 'OIP',
    salesOrderStatus: 'OIP'
  },
  {
    text: 'DESN',
    salesOrderStatus: 'DESN'
  },
  {
    text: 'TSCH',
    salesOrderStatus: 'TSCH'
  },
  {
    text: 'PLAN',
    salesOrderStatus: 'PLAN'
  },
  {
    text: 'MFG',
    salesOrderStatus: 'MFG'
  },
  {
    text: 'BILT',
    salesOrderStatus: 'BILT'
  },
  {
    text: 'ALLO',
    salesOrderStatus: 'ALLO'
  },
  {
    text: 'TPLN',
    salesOrderStatus: 'TPLN'
  },
  {
    text: 'OSHP',
    salesOrderStatus: 'OSHP'
  },
  {
    text: 'TSHP',
    salesOrderStatus: 'TSHP'
  },
  {
    text: 'USHP',
    salesOrderStatus: 'USHP'
  },
  {
    text: 'SHFF',
    salesOrderStatus: 'SHFF'
  },
  {
    text: 'CANC',
    salesOrderStatus: 'CANC'
  }];
  public MFG_STATUS = [{
    status: 'SHPD',
    statusName: 'Shipped'
  },
  {
    status: 'RLSD',
    statusName: 'Released'
  },
  {
    status: 'CMTD',
    statusName: 'Committed'
  },
  {
    status: 'OIP',
    statusName: 'Order In Progress'
  },
  {
    status: 'DESN',
    statusName: 'Design'
  },
  {
    status: 'TSCH',
    statusName: 'In Scheduling'
  },
  {
    status: 'PLAN',
    statusName: 'In Planning'
  },
  {
    status: 'MFG',
    statusName: 'In Manufacturing'
  },
  {
    status: 'BILT',
    statusName: 'Manufacturing is Complete'
  },
  {
    status: 'ALLO',
    statusName: 'Inventory Allocation'
  },
  {
    status: 'TPLN',
    statusName: 'In Transportation Planning'
  },
  {
    status: 'OSHP',
    statusName: 'Out of Shipping'
  },
  {
    status: 'TSHP',
    statusName: 'In Shipping'
  },
  {
    status: 'USHP',
    statusName: 'Unshipped'
  },
  {
    status: 'SHFF',
    statusName: 'Final Finisher Shipment'
  },
  {
    status: 'CANC',
    statusName: 'Canceled'
  }];
  public LINETYPE_STATUS = [{
    lineType: 'U',
    lineTypeName: 'Unit'
  },
  {
    lineType: 'A',
    lineTypeName: 'Accessory'
  },
  {
    lineType: 'W',
    lineTypeName: 'Warranty'
  },
  {
    lineType: 'C',
    lineTypeName: 'Charge'
  },
  {
    lineType: 'V',
    lineTypeName: 'Variation'
  }];
  public ORDERLINE_ORDER_STATUS_FOR_GRIDFILTER = [{
    text: 'SHPD',
    orderStatusCode: 'SHPD'
  },
  {
    text: 'RLSD',
    orderStatusCode: 'RLSD'
  },
  {
    text: 'CMTD',
    orderStatusCode: 'CMTD'
  },
  {
    text: 'OIP',
    orderStatusCode: 'OIP'
  },
  {
    text: 'DESN',
    orderStatusCode: 'DESN'
  },
  {
    text: 'TSCH',
    orderStatusCode: 'TSCH'
  },
  {
    text: 'PLAN',
    orderStatusCode: 'PLAN'
  },
  {
    text: 'MFG',
    orderStatusCode: 'MFG'
  },
  {
    text: 'BILT',
    orderStatusCode: 'BILT'
  },
  {
    text: 'ALLO',
    orderStatusCode: 'ALLO'
  },
  {
    text: 'TPLN',
    orderStatusCode: 'TPLN'
  },
  {
    text: 'OSHP',
    orderStatusCode: 'OSHP'
  },
  {
    text: 'TSHP',
    orderStatusCode: 'TSHP'
  },
  {
    text: 'USHP',
    orderStatusCode: 'USHP'
  },
  {
    text: 'SHFF',
    orderStatusCode: 'SHFF'
  },
  {
    text: 'CANC',
    orderStatusCode: 'CANC'
  }];

  // Folder list error constants
  public INVALID_FOLDER_NAME = 'Folder name must be unique. Please enter a unique name';
  public INVALID_SUBFOLDER_NAME = 'Sub-folder name must be unique within that Level-1 folder. Please enter a unique name';
  public ALREADY_EXIST_FOLDER_SERVER_ERROR_MESSAGE = 'Document folder already exists with the same name. Please enter a different folder name';
  // API integration will be done in future sprint.
  public shipAdressToolTipArray = [
    {
      title: 'Shp. Address:',
      description: `799 Bennett Drive LONGWOOD<br> PO Box 37068 <br> Street 4 <br> Jacksonville, FL, 32236-1236, <br> Duval, US`,
    },
    {
      title: 'Delivery Contact:',
      description: `John Smith<br> john.smith@associatesllc.com. <br> 608 787 2000`,
    }];
  public FINAL_FINISHER_INFORMATION_MESSAGE = `Please remember to complete the Final Finisher Information tab located on the Sales Order Detail window. <br/><br/>For complete instructions, please refer to the Final Finisher Process instructions on the IOS Special Order Types Web page.`;
  public COMMITTED_SALESORDER_MESSAGE = 'Your Job contains one or more committed (CMTD) sales orders.';
  public TRANSMIT_WARNING_MESSAGE = 'Warning validation messages were found. Would you like to review before Transmitting?';
  public PREVALIDATION_WARNING_MESSAGE = 'Warning(s) were found. Do you want to proceed to Transmit?';
  public RESPONSE_CODE = {
    conflict: 409,
  };
  public CHANGE_ORDER_SOLDTO_SUCCESS_FAILURE = 'Sold To Change data not saved successfully';
  public DOWNLOAD_ERROR_MESSAGE = 'Error occured while downloading file';
  public PREVALIDATION_START_MESSAGE = 'System is running prevalidation rules in the background';
  public PREVALIDATION_SUCCESS_MESSAGE = 'System has completed running prevalidation rules. Please review Errors/Warnings panel';
  public PREVALIDATION_ERROR_MESSAGE = 'System could not complete prevalidation check due to network/connectivity issue. Please check your connection status and try again';
  public SERVER_USER = 'SERVER';
  public FOE_APPLICATION = 'FOE';
  public ESTIMATOR_USER_ROLES = ['tsmt-estimate-approver', 'tsmt-estimate-fulfillment'];
  public ORDER_LINE_SHIPPED_STATUS = 'SHPD';
  public readonly DEFAULT_CLASSIFICATION_TRANSITIONAL_JOB_CODE_ID = '76';
  public readonly DEFAULT_CLASSIFICATION_TRANSITIONAL_DESCRIPTION = 'Transitional Job';
  public readonly TRANSLATION_LANGUAGE = 'en';
  public PENDING_CHANGE_ORDER_WARNING_MESSAGE = 'Customer Change Order data is pending. Recent updates will be displayed on the page.';
  public CHANGE_ORDER_DOCUMENT = 'ChangeOrder';
  public PURCHASE_ORDER_DOCUMENT_TYPE_ID = 6;
  public CHANGE_ORDER_FOLDER_TYPE_ID = 6;
  public TIME_ZONE = 'CST';
  // Url for mendix margin pricing tool
  public MENDIX_MARGIN_PRICING_TOOL_BASE_URL = environment.mendixMarginPricingToolUrl;
  public readonly LABEL_HISTORY = 'History';
  public readonly LABEL_FILE_NAME = 'File Name';
  public readonly LABEL_FILE_HISTORY = 'File History';
  public readonly LABEL_SELECT_SINGLE_FILE = 'Select file';
  public readonly LABEL_SELECT_MULTIPLE_FILE = 'Select file(s)';
  public readonly FREIGHT_TERMS_INFO_MESSAGE = 'The Freight Terms you selected require specific detailed steps in order to process. Please follow the business<br>' +
    'process and required approvals. The process document can be found by clicking on this link-<br>' +
    '<a href="https://hub.tranetechnologies.com/docs/DOC-118772" target="_blank"><span class="hyperlink-text">https://hub.tranetechnologies.com/docs/DOC-118772</span></a>';
  public readonly FA_SITE_FREIGHT_TERM = 'FA-SITE';
  // Default planned shipment and order line grid height in landing page
  public readonly DEFAULT_PLANNED_SHIPMENT_GRID_HEIGHT = 100;
  public readonly WORKFLOW_SUPPORT_NODE = 'Support';
  public readonly PROD_ENVIRONMENT = 'production';
  public readonly WORKFLOW_NODE = 'Work Flows';
  public readonly DOCUMENT_PACKAGE_VIEW_NAME = 'packages';
  public readonly DOCUMENT_FILE_VIEW_NAME = 'files';
  public readonly DOCUMENT_NOT_GENERATED = 'Not Generated';
  public readonly DOCUMENT_GENERATION_WORKPACKAGE_VERSION = 20;
  // SharePoint
  public SHAREPOINT = 'SharePoint';
  public readonly DEFAULT_ORDER_LINE_GRID_HEIGHT = 92;
  public readonly SALES_ORDERS_GRID_HEADER_HEIGHT = 62;
  public readonly PLANNED_SHIPMENT_GRID_ROW_HEIGHT = 38;
  public readonly ORDER_LINE_GRID_ROW_HEIGHT = 30;
  public readonly MAXIMUM_PLANNED_SHIPMENT_GRID_HEIGHT = 250;
  public readonly MAXIMUM_ORDER_LINE_GRID_HEIGHT = 192;
}
