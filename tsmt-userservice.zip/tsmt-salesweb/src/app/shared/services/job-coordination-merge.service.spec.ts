import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { of } from 'rxjs';
import { ISelection } from './../../modules/jobs-list-master/models/coordinate-job.model';
import { CoordinateService } from './../../modules/jobs-list-master/services/coordinate.service';
import { AppConstants } from './../constants/constants';
import { JobCoordinationMergeService } from './job-coordination-merge.service';

// tslint:disable-next-line: no-big-function
describe('JobCoordinationMergeService', () => {
    let service: JobCoordinationMergeService;
    let coordinateService: CoordinateService;
    let testCoordinationStatus;
    let testCoordinateData;
    let billOfMaterials;
    const notSubmittedStatus = 'Not Submitted';
    const descript = 'Chilled Water Sensible Cooling Terminal Unit';
    const competitor = 'Daikin York';
    const originReset = TestBed.resetTestingModule;
    const testOriginalDate = '2019-03-07T00:00:00';
    const testDraftDate = '2021-03-07T00:00:00';
    const discountIndicatorOptions = {
        notApplicable: 'N/A',
        yes: 'YES',
        no: 'NO',
    };

    const discountIndicatorClassOptions = {
        notApplicable: 'not-applicable',
        no: 'no-icon',
        yes: 'yes-icon',
    };
    configureTestSuite(() => {
        TestBed.configureTestingModule({
            providers: [JobCoordinationMergeService, CoordinateService, AppConstants],
            imports: [HttpClientTestingModule],
        });

        service = TestBed.inject(JobCoordinationMergeService);
        coordinateService = TestBed.inject(CoordinateService);
    });
    beforeEach(() => {
        billOfMaterials = [{
            bidAlternateId: 100,
            productFamilyId: 101,
            shipQuarter: 1,
            shipYear: 1882,
            competitor: 'Nero',
            specifiedUser: 'Job',
        }];
        testCoordinateData = {
            items: [{
                billOfMaterials,
            }],
        };
        testCoordinationStatus = notSubmittedStatus;
    });
    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should set the coordinationDraftData', () => {
        service.setCoordinateDraftData(testCoordinateData);
        expect(service.coordinateDraftData).toBe(testCoordinateData);
    });

    it('should set the coordinationStatus', () => {
        service.setCoordinationStatus(testCoordinationStatus);
        expect(service.coordinationStatus).toBe(testCoordinationStatus);
    });

    it('should return the bids without merging the draft data when status is not submitted and the job is never coordinated', () => {
        service.coordinateDraftData = {
            billOfMaterials: [],
        };
        service.coordinationStatus = notSubmittedStatus;

        const bids = [{
            bidAlternateId: 100,
            bidName: 'rex',
            selections: [
                {
                    selectionId: 101,
                    description: descript,
                    coordinationJobShipQuarter: 3,
                    coordinationJobShipYear: 2019,
                    coordinationJobCompetitor: competitor,
                    coordinationJobSpecifiedUser: null,
                    prodFamilyId: 101,
                    selectionIds: [456],
                } as ISelection],
        },
        ];
        const resultBids = service.buildBomData(bids);
        expect(resultBids).toEqual(bids);
    });

    it('should merge the draft data when the status is not submitted and the job coordination is in progress', () => {
        service.coordinateDraftData = {
            billOfMaterials,
        };
        service.coordinationStatus = notSubmittedStatus;

        const bids = [
            {
                bidAlternateId: 100,
                bidName: 'rex',
                selections: [
                    {
                        selectionId: 101,
                        description: descript,
                        coordinationJobShipQuarter: 3,
                        coordinationJobShipYear: 2019,
                        coordinationJobCompetitor: competitor,
                        coordinationJobSpecifiedUser: null,
                        prodFamilyId: 101,
                    } as ISelection],
            },
            {
                bidAlternateId: 147,
                bidName: 'rebid',
                selections: [
                    {
                        selectionId: 104,
                        description: descript,
                        coordinationJobShipQuarter: 3,
                        coordinationJobShipYear: 2021,
                        coordinationJobCompetitor: competitor,
                        coordinationJobSpecifiedUser: null,
                        prodFamilyId: 101,
                    } as ISelection,
                ],
            },
        ];
        const spy = spyOn(service, 'setSelectionsInfoFromDraft').and.callThrough();
        const newSelectionsSpy = spyOn(service, 'updateShipTimeForNewSelections').and.callThrough();
        const resultBids = service.buildBomData(bids);
        expect(resultBids[0].selections[0].coordinationJobShipQuarter).toBe(billOfMaterials[0].shipQuarter);
        expect(resultBids[0].selections[0].coordinationJobShipYear).toBe(billOfMaterials[0].shipYear);
        expect(resultBids[0].selections[0].coordinationJobCompetitor).toBe(billOfMaterials[0].competitor);
        expect(resultBids[0].selections[0].coordinationJobSpecifiedUser).toBe(billOfMaterials[0].specifiedUser);
        expect(resultBids[0].selections[0].isNewlyAdded).toBe(false);
        expect(resultBids[1].selections[0].coordinationJobShipQuarter).toBe(billOfMaterials[0].shipQuarter);
        expect(resultBids[1].selections[0].coordinationJobShipYear).toBe(billOfMaterials[0].shipYear);
        expect(resultBids[1].selections[0].isNewlyAdded).toBe(true);
        expect(spy).toHaveBeenCalled();
        expect(newSelectionsSpy).toHaveBeenCalled();
    });

    it('should set shipping details to new selections when updateShipTimeForNewSelections is called', () => {
        const newSelection = {
            selectionId: 104,
            description: descript,
            coordinationJobShipQuarter: 3,
            coordinationJobShipYear: 2021,
            coordinationJobCompetitor: competitor,
            coordinationJobSpecifiedUser: null,
            prodFamilyId: 101,
            isNewlyAdded: true,
        } as ISelection;
        const bid = {
            bidAlternateId: 100,
            bidName: 'rex',
            selections: [newSelection],
        };
        service.updateShipTimeForNewSelections(bid, billOfMaterials);
        expect(newSelection.coordinationJobShipQuarter).toBe(billOfMaterials[0].shipQuarter);
        expect(newSelection.coordinationJobShipYear).toBe(billOfMaterials[0].shipYear);
    });

    it('should update the bids with draft selections when the status is submitted or above', () => {
        service.coordinateDraftData = {
            billOfMaterials,
        };
        service.coordinationStatus = 'Submitted';

        const bids = [{
            bidAlternateId: 100,
            bidName: 'rex',
            selections: [
                {
                    selectionId: 101,
                    description: descript,
                    coordinationJobShipQuarter: 3,
                    coordinationJobShipYear: 2019,
                    coordinationJobCompetitor: competitor,
                    coordinationJobSpecifiedUser: null,
                    prodFamilyId: 101,
                    selectionIds: [123],
                } as ISelection,
                {
                    selectionId: 102,
                    description: 'Chiller is needed',
                    coordinationJobShipQuarter: 4,
                    coordinationJobShipYear: 2020,
                    coordinationJobCompetitor: 'New lanten',
                    coordinationJobSpecifiedUser: null,
                    prodFamilyId: 102,
                } as ISelection,
            ],
        }];
        const resultBids = service.buildBomData(bids);
        expect(resultBids[0].selections.length).toBe(1);
        expect(resultBids[0].selections[0].coordinationJobShipQuarter).toBe(billOfMaterials[0].shipQuarter);
        expect(resultBids[0].selections[0].coordinationJobShipYear).toBe(billOfMaterials[0].shipYear);
        expect(resultBids[0].selections[0].coordinationJobCompetitor).toBe(billOfMaterials[0].competitor);
        expect(resultBids[0].selections[0].coordinationJobSpecifiedUser).toBe(billOfMaterials[0].specifiedUser);
        expect(resultBids[0].selections[0].selectionIds).toEqual(billOfMaterials[0].selectionIds);
        expect(resultBids[0].selections[0].description).toBe(billOfMaterials[0].description);
        expect(resultBids[0].selections[0].prodFamilyId).toBe(billOfMaterials[0].productFamilyId);
    });

    it('should mark the selected documents when there is data in the draft', () => {
        service.coordinateDraftData = {
            documents: [{
                documentKey: 'Jobs/101/59603/MDP-PickRule-InChgOutChgDiscardObsolete.xlsx',
            },
            ],
        };
        const documents = {
            documentList: [
                {
                    jobId: 59603,
                    documentKey: 'Jobs/101/59603/MDP-PickRule-InChgOutChgDiscardObsolete.xlsx',
                    documentName: 'MDP-PickRule-InChgOutChgDiscardObsolete.xlsx',
                    checked: false,
                },
                {
                    jobId: 59603,
                    documentKey: 'Jobs/101/59603/Sprint Capacity Planning-MDP-5.xlsx',
                    documentName: 'Sprint Capacity Planning-MDP-5.xlsx',
                    checked: false,
                },
            ],
        };
        service.buildDocumentData(documents);
        expect(documents.documentList[0].checked).toBe(true);
        expect(documents.documentList[1].checked).toBe(false);
    });

    it('should not mark the documents when there is no data in the draft', () => {
        service.coordinateDraftData = {
            documents: [],
        };
        const documents = {
            documentList: [
                {
                    jobId: 59603,
                    documentKey: 'Jobs/101/59603/MDP-PickRule-InChgOutChgDiscardObsolete.doc',
                    documentName: 'MDP-PickRule-InChgOutChgDiscardObsolete.xlsx',
                    checked: false,
                },
                {
                    jobId: 59603,
                    documentKey: 'Jobs/101/59603/Sprint Capacity Planning-MDP-5.doc',
                    documentName: 'Sprint Capacity Planning-MDP-5.xlsx',
                    checked: false,
                },
            ],
        };
        service.buildDocumentData(documents);
        expect(documents.documentList[0].checked).toBe(false);
        expect(documents.documentList[1].checked).toBe(false);
    });

    it('should set discount indicator to N/A and class to not-applicable if bid has never been coordinated', () => {
        const bidData = [
            {
                bidAlternateId: 81579,
                bidName: 'REBID',
                isBaseBid: false,
                isBidInCoordinationJob: true,
                isCurrentBid: true,
                isSubmitted: false,
            },
        ];
        const coordinateDraft = {
            bidDetails: [{
                bidAlternateId: 81579,
                bidAlternateName: 'REBID',
            }],
        };
        const generalJobData = {};
        service.coordinationStatus = service.coordinationStatusOptions.notSubmitted;
        service.coordinateDraftData = coordinateDraft;
        service.assignBidDiscountConfirmation(bidData, generalJobData);
        expect(bidData[0]['discountIndicator']).toEqual(discountIndicatorOptions.notApplicable);
        expect(bidData[0]['discountIndicatorClass']).toEqual(discountIndicatorClassOptions.notApplicable);
    });

    it('should set discount indicator to N/A and class to not-applicable if Confirmation of Discount is not defined', () => {
        const bidData = [
            {
                bidAlternateId: 81579,
                bidName: 'REBID',
                isBaseBid: false,
                isBidInCoordinationJob: true,
                isCurrentBid: true,
                isSubmitted: true,
            },
        ];
        const coordinateDraft = {
            bidDetails: [{
                bidAlternateId: 81579,
                bidAlternateName: 'REBID',
            }],
        };
        service.coordinationStatus = service.coordinationStatusOptions.submitted;
        service.coordinateDraftData = coordinateDraft;
        const generalData = {
            discountConfirmationDetails: [],
        };
        service.assignBidDiscountConfirmation(bidData, generalData);
        expect(bidData[0]['discountIndicator']).toEqual(discountIndicatorOptions.notApplicable);
        expect(bidData[0]['discountIndicatorClass']).toEqual(discountIndicatorClassOptions.notApplicable);
    });

    it(`should set discount indicator to YES and class to yes-icon if Confirmation of Discount is issued `, () => {
        const bidData = [
            {
                bidAlternateId: 81579,
                bidName: 'REBID',
                isBaseBid: false,
                isBidInCoordinationJob: true,
                isCurrentBid: true,
                isSubmitted: true,
            },
        ];
        const coordinateDraft = {
            bidDetails: [{
                bidAlternateId: 81579,
                bidAlternateName: 'REBID',
            }],
        };
        service.coordinationStatus = service.coordinationStatusOptions.pricingComplete;
        service.coordinateDraftData = coordinateDraft;
        const generalJobData = {
            discountConfirmationDetails: [{
                bidAlternateId: 81579,
                bidName: 'REBID',
                isDiscountConfirmed: true,
            }],
        };
        service.assignBidDiscountConfirmation(bidData, generalJobData);

        expect(bidData[0]['discountIndicator']).toEqual(discountIndicatorOptions.yes);
        expect(bidData[0]['discountIndicatorClass']).toEqual(discountIndicatorClassOptions.yes);
    });

    it(`should set discount indicator to NO and class to no-icon if Confirmation of Discount is not issued`, () => {
        const bidData = [
            {
                bidAlternateId: 81579,
                bidName: 'REBID',
                isBaseBid: false,
                isBidInCoordinationJob: true,
                isCurrentBid: true,
                isSubmitted: true,
            },
        ];
        const coordinateDraft = {
            bidDetails: [{
                bidAlternateId: 81579,
                bidAlternateName: 'REBID',
            }],
        };
        service.coordinationStatus = service.coordinationStatusOptions.pricingComplete;
        service.coordinateDraftData = coordinateDraft;
        const generalJobData = {
            discountConfirmationDetails: [{
                bidAlternateId: 81579,
                bidName: 'REBID',
                isDiscountConfirmed: false,
            }],
        };
        service.assignBidDiscountConfirmation(bidData, generalJobData);
        expect(bidData[0]['discountIndicator']).toEqual(discountIndicatorOptions.no);
        expect(bidData[0]['discountIndicatorClass']).toEqual(discountIndicatorClassOptions.no);
    });

    it('should take job details from draft data if present, else from original data, when status is not submitted', () => {
        const originalData = {
            requestedDate: testOriginalDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'Y',
            jobContact: 'ccefaa',
            commissionCode: 'N97',
        };
        service.coordinateDraftData = {
            requestedDate: testDraftDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'N',
            jobContact: null,
            commissionCode: null,
        };
        service.coordinationStatus = service.coordinationStatusOptions.notSubmitted;
        const jobDetails = service.buildJobDetails(originalData);
        expect(jobDetails.requestedDate).toEqual(service.coordinateDraftData.requestedDate);
        expect(jobDetails.quickTurnaroundIndicator).toEqual(service.coordinateDraftData.quickTurnaroundIndicator);
        expect(jobDetails.icsJobIndicator).toEqual(service.coordinateDraftData.icsJobIndicator);
        expect(jobDetails.jobContact).toEqual(originalData.jobContact);
        expect(jobDetails.commissionCode).toEqual(originalData.commissionCode);
    });

    it('should take requested date always from draft data, when status is not submitted', () => {
        const originalData = {
            requestedDate: testOriginalDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'Y',
            jobContact: 'ccefaa',
            commissionCode: 'N97',
        };
        service.coordinateDraftData = {
            requestedDate: testDraftDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'N',
            jobContact: null,
            commissionCode: null,
        };
        service.coordinationStatus = service.coordinationStatusOptions.notSubmitted;
        let jobDetails = service.buildJobDetails(originalData);
        expect(jobDetails.requestedDate).toEqual(service.coordinateDraftData.requestedDate);
        service.coordinateDraftData = {
            requestedDate: null,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'N',
            jobContact: null,
            commissionCode: null,
        };
        jobDetails = service.buildJobDetails(originalData);
        expect(jobDetails.requestedDate).toEqual(service.coordinateDraftData.requestedDate);
    });

    it('should always take crmOpportunityId from original data', () => {
        const originalData = {
            requestedDate: testOriginalDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'Y',
            jobContact: 'ccefaa',
            commissionCode: 'N97',
            crmOpportunityId: '234679',
        };
        service.coordinateDraftData = {
            requestedDate: null,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'N',
            jobContact: null,
            commissionCode: null,
        };
        service.coordinationStatus = service.coordinationStatusOptions.notSubmitted;
        let jobDetails = service.buildJobDetails(originalData);
        expect(jobDetails.crmOpportunityId).toEqual(originalData.crmOpportunityId);
        service.coordinationStatus = service.coordinationStatusOptions.submitted;
        jobDetails = service.buildJobDetails(originalData);
        expect(jobDetails.crmOpportunityId).toEqual(originalData.crmOpportunityId);
    });

    it('should return draft data other than  crmOpportunityId from buildJobDetails method when status is other than not submitted', () => {
        const originalData = {
            requestedDate: testOriginalDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'Y',
            jobContact: 'ccefaa',
            commissionCode: 'N97',
            crmOpportunityId: '234679',
        };
        service.coordinateDraftData = {
            requestedDate: testDraftDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'N',
            jobContact: null,
            commissionCode: null,
        };
        const expectedData = {
            requestedDate: testDraftDate,
            quickTurnaroundIndicator: 'N',
            icsJobIndicator: 'N',
            jobContact: null,
            commissionCode: null,
            crmOpportunityId: '234679',
        };
        service.coordinationStatus = service.coordinationStatusOptions.submitted;
        const jobDetails = service.buildJobDetails(originalData);
        expect(jobDetails).toEqual(expectedData);
    });

    it('should set isBidInCoordinationJob to true for a bid if the bidAlternateId is present in coordination draft data', () => {
        const draftBids = [{ bidAlternateId: 202468 }];
        service.coordinateDraftData = { bidDetails: draftBids };
        const sampleBidData = [
            {
                bidAlternateId: 202468,
                bidName: 'Base Bid',
                isBidInCoordinationJob: false,
            },
        ];
        service.buildBidData(sampleBidData);
        expect(sampleBidData[0].isBidInCoordinationJob).toBe(true);
    });

    it('should set isBidInCoordinationJob to false for a bid if the bidAlternateId is not present in coordination draft data', () => {
        const draftBids = [{ bidAlternateId: 202468 }];
        service.coordinateDraftData = { bidDetails: draftBids };
        const sampleBidData = [
            {
                bidAlternateId: 202668,
                bidName: 'Base Bid',
                isBidInCoordinationJob: true,
            },
        ];
        service.buildBidData(sampleBidData);
        expect(sampleBidData[0].isBidInCoordinationJob).toBe(false);
    });

    it('should call checkForDeletedBidsAndUpdateDraft method if draft data is present', () => {
        service.coordinateDraftData = { bidDetails: [{ bidAlternateId: 123 }] };
        service.coordinationStatus = service.coordinationStatusOptions.notSubmitted;
        const spy = spyOn(service, 'checkForDeletedBidsAndUpdateDraft').and.callFake(() => { });
        service.buildBidData([]);
        expect(spy).toHaveBeenCalled();
    });

    it('should not call checkForDeletedBidsAndUpdateDraft method if status is other than Not Submitted', () => {
        service.coordinateDraftData = { bidDetails: [{ bidAlternateId: 123 }] };
        service.coordinationStatus = service.coordinationStatusOptions.submitted;
        const spy = spyOn(service, 'checkForDeletedBidsAndUpdateDraft').and.callFake(() => { });
        service.buildBidData([]);
        expect(spy).not.toHaveBeenCalled();
    });

    it('should set bid as valid if all of isPricingValid, hasBidWithSelection and hasCompletePricing are true', () => {
        const draftBids = [{ bidAlternateId: 202468 }];
        service.coordinateDraftData = { bidDetails: draftBids };
        const sampleBidData = [
            {
                bidAlternateId: 202468,
                bidName: 'Base Bid',
                hasBidWithSelection: true,
                hasCompletePricing: true,
                isPricingValid: true,
                isValid: false,
            },
        ];
        service.buildBidData(sampleBidData);
        expect(sampleBidData[0].isValid).toBe(true);
    });

    it('should set bid as invalid if any of isPricingValid, hasBidWithSelection or hasCompletePricing is false', () => {
        const draftBids = [{ bidAlternateId: 202468 }, { bidAlternateId: 202469 }, { bidAlternateId: 202470 }];
        service.coordinateDraftData = { bidDetails: draftBids };
        const sampleBidData = [
            {
                bidAlternateId: 202468,
                bidName: 'Base Bid',
                hasBidWithSelection: true,
                hasCompletePricing: true,
                isPricingValid: false,
                isValid: true,
            },
            {
                bidAlternateId: 202469,
                bidName: 'Base Bid',
                hasBidWithSelection: true,
                hasCompletePricing: false,
                isPricingValid: true,
                isValid: true,
            },
            {
                bidAlternateId: 202470,
                bidName: 'Base Bid',
                hasBidWithSelection: false,
                hasCompletePricing: true,
                isPricingValid: true,
                isValid: true,
            },
        ];
        service.buildBidData(sampleBidData);
        expect(sampleBidData[0].isValid).toBe(false);
        service.buildBidData(sampleBidData);
        expect(sampleBidData[0].isValid).toBe(false);
        service.buildBidData(sampleBidData);
        expect(sampleBidData[0].isValid).toBe(false);
    });

    it('should update draft bids and bom, if original bids are deleted', () => {
        const draftBidIds = [123, 456];
        const originalBids = [{ bidAlternateId: 123 }];
        const deletedBidIds = [456];
        const bidsSpy = spyOn(service, 'updateDraftBids').and.callFake(() => { });
        const bomSpy = spyOn(service, 'updateDraftBom').and.callFake(() => { });
        service.checkForDeletedBidsAndUpdateDraft(draftBidIds, originalBids);
        expect(bidsSpy).toHaveBeenCalledWith(deletedBidIds);
        expect(bomSpy).toHaveBeenCalledWith(deletedBidIds);
    });

    it('should remove deleted bids from draft bids data', () => {
        const draftBids = [{ bidAlternateId: 123 }, { bidAlternateId: 456 }];
        const deletedBidIds = [456];
        service.coordinateDraftData = { bidDetails: draftBids };
        service.jobId = 63702;
        service.drAddressId = 101;
        service.coordinationId = 66;
        const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(of({}));
        const expectedPayload = {
            jobCoordinationViewModel: {
                jobId: service.jobId,
                drAddressId: service.drAddressId,
                coordinationId: service.coordinationId,
                bids: [{ bidAlternateId: 123 }],
            },
        };
        service.updateDraftBids(deletedBidIds);
        expect(spy).toHaveBeenCalledWith(expectedPayload, service.drAddressId, service.jobId);
    });

    it('should remove deleted bids from draft bom data', () => {
        const draftBoms = [{ bidAlternateId: 123, productFamilyId: 41 }, { bidAlternateId: 456, productFamilyId: 42 }];
        const deletedBidIds = [456];
        service.coordinateDraftData = { billOfMaterials: draftBoms };
        service.jobId = 63702;
        service.drAddressId = 101;
        service.coordinationId = 66;
        const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(of({}));
        const expectedPayload = {
            jobCoordinationViewModel: {
                jobId: service.jobId,
                drAddressId: service.drAddressId,
                coordinationId: service.coordinationId,
                billOfMaterials: [{ bidAlternateId: 123, productFamilyId: 41 }],
            },
        };
        service.updateDraftBom(deletedBidIds);
        expect(spy).toHaveBeenCalledWith(expectedPayload, service.drAddressId, service.jobId);
    });

});
