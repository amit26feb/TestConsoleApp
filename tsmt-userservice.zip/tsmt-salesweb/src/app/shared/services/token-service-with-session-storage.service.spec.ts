import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { SessionStorageService } from './token-service-with-session-storage.service';

describe('SessionStorageService', () => {
  let service: SessionStorageService;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [SessionStorageService],
    });
    service = TestBed.inject(SessionStorageService);
  });

  afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set authentication token', () => {
    service.setauthenticationToken('1234');
    expect(sessionStorage.getItem('auth')).toBe('1234');
  });

  it('should get authentication token', () => {
    service.setauthenticationToken('1234');
    expect(service.getauthenticationToken()).toBe('1234');
  });

});
