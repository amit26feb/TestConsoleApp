import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { OktaAuthService } from '@okta/okta-angular';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { AppConstants } from '../constants/constants';
import { IOfficeSelectorModel } from '../model/office-selector-model';
import { OktaServiceMock } from '../test-mocks/oktaservice-mock';
import { GlobalFilterService } from './global-filter.service';

describe('GlobalFilterService', () => {
  let filterService: GlobalFilterService;
  // let httpTestingController: HttpTestingController;
  let officeSelected: IOfficeSelectorModel;
  let officeSelectorList: IOfficeSelectorModel[];
  let appConstants: AppConstants;
  let httpClient: HttpClient;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        AppConstants,
        GlobalFilterService,
        {
          provide: OktaAuthService,
          useClass: OktaServiceMock,
        },
      ],
      imports: [
        HttpClientTestingModule
      ],
    });

    officeSelected = {
      salesOfficeName: 'Billings',
      drAddressId: 121,
    } as IOfficeSelectorModel;
    officeSelectorList = [officeSelected];

    httpClient = TestBed.inject(HttpClient);
    // httpTestingController = TestBed.inject(HttpTestingController);
  });

  beforeEach(() => {
    filterService = TestBed.inject(GlobalFilterService);
    appConstants = TestBed.inject(AppConstants);
  });

  /*  TODO - this tests need to be re-examined
    it('should have fetched the office selector list when FilterService is created', () => {
      const req = httpTestingController.expectOne(
        appConstants.API_BASE_URL_JOB + '/Jobs/SalesOffices',
      );
      expect(req.request.method).toEqual('GET');
    });
  
    it('should not call the api when okta authentication fails', () => {
      TestBed.overrideProvider(OktaAuthService, { useValue: { isAuthenticated: () => Promise.resolve(false) } });
      httpTestingController.expectNone(
        appConstants.API_BASE_URL_JOB + '/Jobs/SalesOffices',
      );
    });
  */

  it('should set the officeSelector from api on creating a filterService instance', () => {
    spyOn(httpClient, 'get').and.returnValue(Observable.of(officeSelectorList));

    filterService.getOfficeSelectorList().subscribe((selectorList) => {
      expect(selectorList).toEqual(officeSelectorList);
    });
  });

  it('should not set the officeSelector when api throws error on creating a filterService instance ', () => {
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));

    filterService.getOfficeSelectorList().subscribe((selectorList) => {
      expect(selectorList).toBe(undefined);
    });
  });

  it('should emit the selected office value on setSelectedOffice', () => {
    filterService.setSelectedOffice(officeSelected);
    filterService.getSelectedOffice().subscribe((val) => {
      expect(val).toEqual(officeSelected);
    });
  });

  it('should emit the office selector list on setOfficeSelectorList', () => {
    filterService.setOfficeSelectorList(officeSelectorList);
    filterService.getOfficeSelectorList().subscribe((val) => {
      expect(val).toEqual(officeSelectorList);
    });
  });

  it('should get office selector list on fetchOfficeSelector', () => {
    filterService.fetchOfficeSelector().subscribe((val) => {
      expect(val).toBeGreaterThan(0);
    });

    // check exception scenario in service
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    filterService.fetchOfficeSelector().subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should identify default as support database, if exists', () => {
    const offices = [
      { drAddressId: 63, salesOfficeName: 'Dallas Main Office' } as IOfficeSelectorModel,
      { drAddressId: appConstants.SUPPORT_DATABASE_DR_ADDRESS_ID, salesOfficeName: 'SUPPORT' } as IOfficeSelectorModel,
    ] as IOfficeSelectorModel[];

    // act
    filterService.setDefaultOffice(offices);

    // assert
    filterService.getDefaultOffice().subscribe((data) => {
      expect(data.drAddressId).toEqual(appConstants.SUPPORT_DATABASE_DR_ADDRESS_ID);
    });
  });

  it('should identify default as first record with home id', () => {
    // arrange - typical scenario will have several offices in the home office's sales district
    const offices = [
      { drAddressId: 105, salesOfficeName: 'Appleton', homeDrAddressId: 101 } as IOfficeSelectorModel,
      { drAddressId: 97, salesOfficeName: 'Fargo', homeDrAddressId: 101 } as IOfficeSelectorModel,
      { drAddressId: 101, salesOfficeName: 'Madison', homeDrAddressId: 101 } as IOfficeSelectorModel,
      { drAddressId: 119, salesOfficeName: 'Timbuktu', homeDrAddressId: 101 } as IOfficeSelectorModel,
    ] as IOfficeSelectorModel[];

    // act
    filterService.setDefaultOffice(offices);

    // assert
    filterService.getDefaultOffice().subscribe((data) => {
      expect(data.drAddressId).toEqual(101);
    });
  });

  it('should identify default as first record when support and home id is not present', () => {
    const offices = [
      { drAddressId: 7, salesOfficeName: 'Appleton' } as IOfficeSelectorModel,
      { drAddressId: 63, salesOfficeName: 'Dallas', homeDrAddressId: 0 } as IOfficeSelectorModel,
      { drAddressId: 59, salesOfficeName: 'Honolulu' } as IOfficeSelectorModel,
    ] as IOfficeSelectorModel[];

    // act
    filterService.setDefaultOffice(offices);

    // assert
    filterService.getDefaultOffice().subscribe((data) => {
      expect(data.drAddressId).toEqual(7);
    });
  });
});
