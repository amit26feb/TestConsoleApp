import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable, of } from 'rxjs';
import { AppConstants } from '../constants/constants';
import { ICreditProjectTransmitStatus } from '../model/credit-project-transmit-status-model';
import { ProjectService } from './project.service';

describe('ProjectService', () => {
  let projectService: ProjectService;
  let httpClient: HttpClient;
  const originReset = TestBed.resetTestingModule;
  const creditProjectTransmitStatus = {
    isTransmitted: false,
    isCopiedDown: true,
    isRemnant: false
  } as ICreditProjectTransmitStatus;
  configureTestSuite(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ProjectService, AppConstants],
  }));

  beforeEach(() => {
    projectService = TestBed.inject(ProjectService);
    httpClient = TestBed.inject(HttpClient);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(projectService).toBeTruthy();
  });

  it('should return null in response when exportToExcel method triggered ', () => {
    const drAddressId = 122;
    const creditJobId = 164571;
    const jobId = 147295;
    const isTransmitted = true;
    spyOn(httpClient, 'get').and.returnValue(of(null));
    projectService.exportToExcel(drAddressId, jobId, creditJobId, isTransmitted).subscribe((data) => {
      expect(data).toBe(null);
    });
  });

  it('should return error when invalid creditJobID is passed to exportToExcel method', () => {
    const drAddressId = 122;
    const creditJobId = 0;
    const jobId = 147295;
    const isTransmitted = false;
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    projectService.exportToExcel(drAddressId, jobId, creditJobId, isTransmitted).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should return credit project transmit status in response on calling getCreditProjectTransmitStatus()', () => {
    const drAddressId = 122;
    const creditJobId = 164571;
    spyOn(httpClient, 'get').and.returnValue(of(creditProjectTransmitStatus));
    projectService.getCreditProjectTransmitStatus(drAddressId, creditJobId).subscribe((status) => {
      expect(status).toEqual(creditProjectTransmitStatus);
    });
  });

  it('should return error when invalid creditJobId is passed on calling getCreditProjectTransmitStatus()', () => {
    const drAddressId = 122;
    const creditJobId = 0;
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    projectService.getCreditProjectTransmitStatus(drAddressId, creditJobId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
});
