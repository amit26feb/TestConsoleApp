import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { IApiErrorState } from '../model/apierror-state';

@Injectable()
export class ApiErrorService {
 private apiErrorSubject = new Subject<IApiErrorState>();
    apiErrorState = this.apiErrorSubject.asObservable();
    constructor() { }

    show(message: any) {
        this.apiErrorSubject.next({ show: true, errorMessage: message  } as IApiErrorState);
    }
    hide() {
        this.apiErrorSubject.next({ show: false, errorMessage: '' } as IApiErrorState);
    }
}
