import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { getTestBed, TestBed } from '@angular/core/testing';
import { OKTA_CONFIG, OktaAuthService } from '@okta/okta-angular';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { AppConstants } from '../constants/constants';
import { OktaServiceMock } from '../test-mocks/oktaservice-mock';
import { GlobalSearchService } from './global-search.service';
import { SearchProjectMock } from '@tsmt/salesweb-ordersmodule';
import { JobsService } from '@tsmt/salesweb-jobsmodule';
import { BehaviorSubject } from 'rxjs';
import { DisplayModeEnum } from '../enums/display-mode-enum';

// tslint:disable-next-line:no-big-function
describe('GlobalSearchService', () => {
  let globalSearchService: GlobalSearchService;
  let appConstants: AppConstants;
  let httpTestingController: HttpTestingController;
  let oktaAuth: OktaAuthService;
  let httpClient: HttpClient;
  let searchDataMock: SearchProjectMock;
  let jobsService: JobsService;

  const workPackage = 'Work Packages';
  const originReset = TestBed.resetTestingModule;
  const payload = {
    skip: 0,
    take: 50,
    sort: [{ sortBy: 'serialNumber', sortDirection: 'Ascending' }],
    filters: [{
      columnFilters: [{ field: 'OrderName', operator: 'contains', value: '12' }],
      logic: 'or'
    },
    {
      columnFilters: [{ field: 'historicalStatus', operator: 'eq', value: 'all' }],
      logic: 'and'
    },
    {
      columnFilters: [{ field: 'isShipped', operator: 'eq', value: 'true' }],
      logic: 'and'
    }],
  };
  const excelPayload = {
    orderId: 4327,
    serialNumber: 'N04L18621',
    orderName: 'S00034MM',
    orderBillLetter: 'A',
    orderRevision: 1,
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [AppConstants, SearchProjectMock,
        {
          provide: OktaAuthService,
          useClass: OktaServiceMock,
        },
        {
          provide: JobsService,
          useValue: { triggerSearch: new BehaviorSubject('test') },
        }
      ],
      imports: [HttpClientTestingModule],
    });
    const injector = getTestBed();
    globalSearchService = injector.inject(GlobalSearchService);
    httpTestingController = injector.inject(HttpTestingController);
    appConstants = injector.inject(AppConstants);
    oktaAuth = injector.inject(OktaAuthService);
    httpClient = TestBed.inject(HttpClient);
    searchDataMock = TestBed.inject(SearchProjectMock);
    jobsService = TestBed.inject(JobsService);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(globalSearchService).toBeTruthy();
  });

  it(`should assign response from API if status is 200 on the calling downloadPDF method`, () => {
    const documentKey = 'abac';
    spyOn(httpClient, 'get').and.returnValue(Observable.of({ status: 200, body: '', headers: { get: (x) => { 'test'; } } }));
    globalSearchService.downloadPDF(documentKey).subscribe((value) => {
      expect(value).toBeDefined();
    });
  });

  it(`should return error be on calling downloadPDF method`, () => {
    const documentKey = 'abac';
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    globalSearchService.downloadPDF(documentKey).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should check tabname, form url with search params and trigger fetchList on calling searchList', () => {
    const api_base_url = appConstants.API_BASE_URL_WORKPACKAGE;
    spyOn(globalSearchService, 'fetchList').and.returnValue(Observable.of([]));
    TestBed.compileComponents();
    globalSearchService.searchList('test', workPackage, 101);
    expect(globalSearchService.BASE_URL).toBe(api_base_url + '/101/WorkPackages');
    expect(globalSearchService.options).toBeDefined();
    expect(globalSearchService.fetchList).toHaveBeenCalled();
  });

  it('should form the BASE_URL when the tab name is Projects and selected toggle value is History', () => {
    const apiBaseUrl = appConstants.API_BASE_URL_ORDER_HISTORY;
    TestBed.compileComponents();
    globalSearchService.searchList('1437419', 'Projects', 82, 'History');
    expect(globalSearchService.BASE_URL).toBe(`${apiBaseUrl}/CreditJobs`);
  });

  it('should call the triggerSearch on jobsService when searchList is called with jobs tabname', () => {
    jobsService.triggerSearch = new BehaviorSubject('test');
    spyOn(jobsService.triggerSearch, 'next');
    globalSearchService.searchList('searchText', 'Jobs', 82);
    expect(jobsService.triggerSearch.next).toHaveBeenCalledWith('searchText');
  });

  it('should form the BASE_URL when the tab name is Projects and selected toggle value is Untransmitted', () => {
    const apiBaseUrl = appConstants.API_BASE_URL_ORDERGATEWAY;
    TestBed.compileComponents();
    globalSearchService.searchList('1437419', 'Projects', 82, 'Untransmitted');
    expect(globalSearchService.BASE_URL).toBe(`${apiBaseUrl}/CreditJobs`);
  });

  it('should form the BASE_URL when the tab name is Projects and selected toggle value is Shippping History', () => {
    TestBed.compileComponents();
    globalSearchService.searchList('1437419', 'Projects', 82, 'Shipping History');
    expect(globalSearchService.BASE_URL).toBe(`${appConstants.API_BASE_URL_SHIPPING_HISTORY}/Orders/SearchableItems`);
  });

  it('should form url without params and trigger fetchList on calling searchList', () => {
    spyOn(globalSearchService, 'fetchList').and.returnValue(Observable.of([]));
    TestBed.compileComponents();
    globalSearchService.searchList('', workPackage, 101);
    expect(globalSearchService.options).toBe(null);
  });

  it('should return searched list on calling fetchList method', () => {
    const workPackages = [{
      drAddressId: 105,
      workPackageName: 'Sacred Heart - Tomahawk - Boiler Modulation Contro!',
      bidDate: '2019-12-19T05:46:19',
      startDate: '2019-12-19T06:46:19',
      endDate: '2019-12-19T04:46:19',
      workPackageId: 626,
      workPackagePrice: 2279.4,
      salesEngineer: 'Tom Schafer [D31]',
      salesStage: null,
    },
    {
      drAddressId: 105,
      workPackageName: 'Sacred Heart - Tomahawk',
      bidDate: '2009-12-02T00:00:00',
      startDate: '2009-11-02T00:00:00',
      endDate: '2012-11-02T00:00:00',
      workPackageId: 627,
      workPackagePrice: 2279.4,
      salesEngineer: 'Tom Schafer',
      salesStage: 'Budget',
    },
    {
      drAddressId: 105,
      workPackageName: 'Sacred Heart - Boiler Modulation Contro',
      bidDate: '2009-10-02T00:00:00',
      startDate: '2009-15-02T00:00:00',
      endDate: '2015-11-02T00:00:00',
      workPackageId: 526,
      workPackagePrice: 2279.4,
      salesEngineer: 'Tom Schafer [D3]',
      salesStage: 'Design',
    }];
    const bidDate = new Date(workPackages[0].bidDate).setHours(0, 0, 0);
    const startDate = new Date(workPackages[0].startDate).setHours(0, 0, 0);
    const endDate = new Date(workPackages[0].endDate).setHours(0, 0, 0);
    spyOn(httpClient, 'get').and.returnValue(Observable.of(workPackages));
    globalSearchService.fetchList().subscribe((res) => {
      expect(res.length).toBeGreaterThan(0);
      expect(res[0].bidDate).toEqual(bidDate);
      expect(res[0].startDate).toEqual(startDate);
      expect(res[0].endDate).toEqual(endDate);
      expect(res[0].salesStage).toBe(' ');
    });
  });

  it('should return searched list and transform data on calling fetchList method', () => {
    const searchList = [{
      drAddressId: 105,
      workPackageName: 'Sacred Heart - Tomahawk - Boiler Modulation Control',
      workPackageId: 626,
      workPackagePrice: 2279.4,
    },
    {
      drAddressId: 105,
      workPackageName: 'Sacred Heart - Tomahawk - Boiler Modulation',
      workPackageId: 627,
      workPackagePrice: 2279.4,
    },
    {
      drAddressId: 105,
      workPackageName: 'Sacred Heart - Tomahawk - Boiler Modulation Contro',
      workPackageId: 526,
      workPackagePrice: 2279.4,
    }];
    spyOn(httpClient, 'get').and.returnValue(Observable.of(searchList));
    globalSearchService.fetchList().subscribe((res) => {
      expect(res[0].bidDate).toEqual('');
      expect(res[0].startDate).toEqual('');
      expect(res[0].endDate).toEqual('');
    });
  });

  it('should return error be on calling fetchList method', () => {
    // check exception scenario in service
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    globalSearchService.fetchList().subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
  it('should set the options to null when tabname is Projects', () => {
    globalSearchService.tabName = '';
    spyOn(globalSearchService, 'fetchList').and.returnValue(Observable.of([]));
    TestBed.compileComponents();
    globalSearchService.searchList('1437419', 'Projects', 82);
    expect(globalSearchService.tabName).toBe('Projects');
    expect(globalSearchService.options).toBeDefined();
  });
  it('should set the tabName property to "" when tabName is otherthan Projects and Work Packages', () => {
    globalSearchService.tabName = '';
    spyOn(globalSearchService, 'fetchList').and.returnValue(Observable.of([]));
    TestBed.compileComponents();
    globalSearchService.searchList('', '', 0);
    expect(globalSearchService.tabName).toEqual('');
    expect(globalSearchService.options).toEqual(null);
    globalSearchService.searchList('1437419', 'Order', 82);
    expect(globalSearchService.tabName).toBe('');
    expect(globalSearchService.options).toBe(null);
  });
  it('should return error when API throws error', () => {
    spyOn(globalSearchService, 'fetchList').and.callFake(() => {
      return Observable.throwError({ error: 'Internal server error' });
    });
    globalSearchService.searchList('1437419', workPackage, 82);
    globalSearchService.fetchedData.subscribe((data) => {
      expect(data).toEqual({ error: 'Internal server error' });
    });
  });

  it('should call fetchList method on calling getOrderList method', () => {
    const skip = 0;
    const take = 100;
    globalSearchService.searchVal = 'R12234';
    const drAddressId = [101];
    const spyFetchList = spyOn(globalSearchService, 'fetchList');
    globalSearchService.getOrderList(skip, take, drAddressId, DisplayModeEnum.Untransmitted);
    expect(spyFetchList).toHaveBeenCalledWith(DisplayModeEnum.Untransmitted, drAddressId);
  });

  it('should call fetchList method with drAddress id as list on calling getOrderList method', () => {
    const skip = 0;
    const take = 100;
    globalSearchService.searchVal = 'R143434';
    const drAddressId = [101, 122];
    const spyFetchList = spyOn(globalSearchService, 'fetchList');
    globalSearchService.getOrderList(skip, take, drAddressId, DisplayModeEnum.Transmitted);
    expect(spyFetchList).toHaveBeenCalledWith(DisplayModeEnum.Transmitted, drAddressId);
  });

  it('should call fetchList method with HistoryDisplayMode on calling getOrderList method', () => {
    const skip = 0;
    const take = 100;
    globalSearchService.searchVal = 'R143434';
    const drAddressId = [101, 122];
    const spyFetchList = spyOn(globalSearchService, 'fetchList');
    globalSearchService.getOrderList(skip, take, drAddressId, DisplayModeEnum.History);
    expect(spyFetchList).toHaveBeenCalledWith(DisplayModeEnum.History, drAddressId);
  });

  it('should call setToggleBaseURL method and return the baseURL when currentDataSelected is Transmitted', () => {
    const tabName = 'Projects';
    const searchValue = '1';
    const drAddressId = 101;
    const currentDataSelected = 'Transmitted';
    globalSearchService.setToggleBaseURL(tabName, searchValue, drAddressId, currentDataSelected);
    expect(globalSearchService.BASE_URL).toBe(`${appConstants.API_BASE_URL_ORDERGATEWAY}/CreditJobs`);
  });

  it('should call setToggleBaseURL method and return the baseURL when currentDataSelected is Transmitted', () => {
    const tabName = 'Projects';
    const searchValue = 'R143434';
    const drAddressId = 142;
    const currentDataSelected = 'Projects';
    globalSearchService.setToggleBaseURL(tabName, searchValue, drAddressId, currentDataSelected);
    expect(globalSearchService.BASE_URL).toBe(`${appConstants.API_BASE_URL_ORDERGATEWAY}/CreditJobs`);
  });

  it('should form the BASE_URL on calling searchList with job id', () => {
    const jobId = 34;
    const drAddressId = 101;
    const searchText = '';
    const api_base_url = appConstants.API_BASE_URL_WORKPACKAGE;
    TestBed.compileComponents();
    globalSearchService.searchList(searchText, workPackage, drAddressId, null, jobId);
    expect(globalSearchService.BASE_URL).toBe(api_base_url + '/101/WorkPackages');
    expect(globalSearchService.options).toBeDefined();
  });

  it(`should assign response from API if status is 200 on the calling getShippingHistory method`, () => {
    spyOn(httpClient, 'post').and.returnValue(Observable.of({ status: 200, body: searchDataMock.shippingHistoryData }));
    globalSearchService.getShippingHistory(payload).subscribe((value) => {
      expect(value.pagingItems).toEqual(searchDataMock.shippingHistoryData.pagingItems);
    });
  });

  it(`should return [] if the status is 204 on calling getShippingHistory method`, () => {
    spyOn(httpClient, 'post').and.returnValue(Observable.of({ status: 204, body: [] }));
    globalSearchService.getShippingHistory(payload).subscribe((value) => {
      expect(value.pagingItems).toEqual([]);
    });
  });

  it(`should check for Undefind if the status is not 200 or 204 on calling getShippingHistory method`, () => {
    spyOn(httpClient, 'post').and.returnValue(Observable.of({ status: 500, body: [] }));
    globalSearchService.getShippingHistory(payload).subscribe((value) => {
      expect(value).toBeUndefined();
    });
  });

  it(`should return error be on calling getShippingHistory method`, () => {
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    globalSearchService.getShippingHistory(payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  describe('downloadShippingHistoryReports', () => {
    it('should download the file given http request succeeds', () => {
      const downloadFile = {
        status: 200,
        file: new Blob(),
        headers: new HttpHeaders({
          'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'Content-Disposition': 'filename=FILE0000.TIF;'
        }),
      };
      const documentKey = 'ShippingHistory/VO/VDrive/trane31d/MCN/F000/25/64/FILE0000.TIF';
      const orderName = 'M8O884A';
      spyOn(httpClient, 'get').and.returnValue(Observable.of(downloadFile));
      globalSearchService.downloadShippingHistoryReports(documentKey, orderName).subscribe((data) => {
        expect(globalSearchService.shippingHistoryDownloadUrl).toBe(`${appConstants.API_BASE_URL_DOCUMENT}/ShippingHistoryDocuments/Download`);
        expect(data).toBeDefined();
      });
    });

    it('should make a http get call with documentKey, orderNumber and orderType=VO given serialNumber and orderType are falsy', () => {
      const downloadFile = {
        status: 200,
        file: new Blob(),
        headers: new HttpHeaders({
          'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'Content-Disposition': 'filename=FILE0000.TIF;'
        }),
      };
      const documentKey = 'ShippingHistory/VO/VDrive/trane31d/MCN/F000/25/64/FILE0000.TIF';
      const serialNumber = null;
      const orderName = 'M8O884A';
      const spyHttpGet = spyOn(httpClient, 'get').and.returnValue(Observable.of(downloadFile));
      const params = new HttpParams()
        .set('documentKey', documentKey)
        .set('orderNumber', orderName)
        .set('orderType', 'VO');

      globalSearchService.downloadShippingHistoryReports(documentKey, orderName, serialNumber).subscribe((data) => {
        expect(spyHttpGet).toHaveBeenCalledWith(jasmine.any(String), jasmine.objectContaining({ params }));
      });
    });

    it('should make a http get call with provided documentKey, orderNumber, serialNumber and orderType', () => {
      const downloadFile = {
        status: 200,
        file: new Blob(),
        headers: new HttpHeaders({
          'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'Content-Disposition': 'filename=FILE0000.TIF;'
        }),
      };
      const documentKey = 'fakeymcfakepath.bmr';
      const orderName = 'M8O884A';
      const serialNumber = 'C00A01661';
      const orderType = 'YO';
      const spyHttpGet = spyOn(httpClient, 'get').and.returnValue(Observable.of(downloadFile));
      const params = new HttpParams()
        .set('documentKey', documentKey)
        .set('orderNumber', orderName)
        .set('orderType', orderType)
        .set('serialNumber', serialNumber);

      globalSearchService.downloadShippingHistoryReports(documentKey, orderName, serialNumber, orderType).subscribe((data) => {
        expect(spyHttpGet)
          .toHaveBeenCalledWith(jasmine.any(String), jasmine.objectContaining({ params }));
      });
    });

    it('should return error given http request fails', () => {
      const documentKey = 'ShippingHistory/VO/VDrive/trane31d/MCN/F000/21/66/FILE0001.TIF';
      const orderName = 'M8O884A';
      spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ status: 500, error: 'error' }));
      globalSearchService.downloadShippingHistoryReports(documentKey, orderName).subscribe(() => {
      }, (err) => { expect(err.error).toBe('error'); });
    });

    it('should download the file on calling downloadFile()', () => {
      const testPayload = {
        orderId: null, serialNumber: 'C00A01661', orderName: 'M8O884A',
        orderBillLetter: 'A', orderRevision: 1, sourceType: 'Current'
      };
      spyOn(httpClient, 'post').and.returnValue(Observable.of('saak'));
      globalSearchService.downloadFile(testPayload).subscribe((data) => {
        expect(globalSearchService.shippingHistoryDownloadUrl).toBe(`${appConstants.API_BASE_URL_SHIPPING_HISTORY}/Orders/PcbHeaders/GeneratePdf`);
        expect(data).toEqual('saak');
      });
    });

    it('should return error on calling downloadFile()', () => {
      const testPayload = {
        orderId: null, serialNumber: 'C00A01661', orderName: 'M8O884A',
        orderBillLetter: 'A', orderRevision: 1, sourceType: 'Current'
      };
      spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
      globalSearchService.downloadFile(testPayload).subscribe(() => {
      }, (err) => { expect(err.error).toBe('error'); });
    });
  });

  describe('getFilenameFromContentDisposition', () => {
    it('should parse out the filename', () => {
      const contentDisposition = `attachment; filename=660404.pdf; filename*=UTF-8''660404.pdf`;
      const expectedFilename = '660404.pdf';
      expect(globalSearchService.getFilenameFromContentDisposition(contentDisposition))
        .toEqual(expectedFilename);
    });

    it('should trim quotes from filename given filename with spaces', () => {
      const contentDisposition = `attachment; filename="660404 RTAF 1 Point Test.pdf"; filename*=UTF-8''660404%20RTAF%201%20Point%20Test.pdf`;
      const expectedFilename = '660404 RTAF 1 Point Test.pdf';
      expect(globalSearchService.getFilenameFromContentDisposition(contentDisposition))
        .toEqual(expectedFilename);
    });
  });
});
