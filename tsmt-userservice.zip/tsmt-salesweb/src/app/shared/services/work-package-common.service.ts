import { Injectable } from '@angular/core';
import { IWorkPackageBaseModel } from '../model/work-package-base-model';

@Injectable()
export class WorkPackageCommonService {
    private workPackageBaseProperties: IWorkPackageBaseModel;
    private selectedPropertyName: string;
    private editCostItemValue: any;
    setWorkPackageBaseProperties(workPackageBaseProperties: IWorkPackageBaseModel): void {
        this.workPackageBaseProperties = workPackageBaseProperties;
    }

    getWorkPackageBaseProperties(): IWorkPackageBaseModel {
        return this.workPackageBaseProperties;
    }

    setPropertySectionName(link: string) {
        this.selectedPropertyName = link;
    }

    getPropertySectionName(): string {
        return this.selectedPropertyName;
    }
    // In this method we set 5 types of cost items set so parameter type setting as any
    setEditCostItemValue(editValue: any): void {
        this.editCostItemValue = editValue;
    }

    getEditCostItemValue(): any {
        return this.editCostItemValue;
    }
}
