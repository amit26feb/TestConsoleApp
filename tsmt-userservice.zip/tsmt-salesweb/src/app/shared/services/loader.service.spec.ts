import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Subject } from 'rxjs';
import { ILoaderState } from '../model/loader-state';
import { LoaderService } from './loader.service';

describe('LoaderService', () => {
  const loaderSubject = new Subject<ILoaderState>();
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [LoaderService],
    });
  });

  afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

  it('should call on show() for loader service', inject([LoaderService], (service: LoaderService) => {
    service.show();
    expect(loaderSubject).toBeTruthy();
  }));

  it('should call on hide() for loader service', inject([LoaderService], (service: LoaderService) => {
    service.hide();
    const loaderResult = { show: false } as ILoaderState;
    expect(loaderSubject).toBeTruthy(loaderResult);
  }));
});
