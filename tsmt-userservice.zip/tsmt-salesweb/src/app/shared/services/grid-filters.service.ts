import { Injectable } from '@angular/core';
import * as moment from 'moment';


@Injectable()
export class GridFiltersService {
    dateColumns = ['reviseDate'];
    multiselectColumns = [];

    //  modifying the filter object
    multiSelectFilter(statusObj, fieldName): any[] {
        const arr = [];
        statusObj.value.forEach((val) => {
            const multiselectobj = {
                field: statusObj.field,
                operator: statusObj.operator,
                value: val[fieldName],
            };
            arr.push(multiselectobj);
        });
        return arr;
    }


    // modifying the filter object
    // tslint:disable-next-line:cognitive-complexity
    modifyFilterObj(filterObject, payloadKey?: string): any[] {
        const dateFormat = 'MM/DD/YYYY';
        let logicVal;
        return filterObject.map((obj) => {
            if ('filters' in obj) {
                if (this.dateColumns.includes(obj.filters[0].field)) {
                    if (obj.filters.length > 1) {
                        obj.filters[1].value = moment(new Date(obj.filters[1].value)).format(dateFormat);
                    }
                    obj.filters[0].value = moment(new Date(obj.filters[0].value)).format(dateFormat);
                } else if (this.multiselectColumns.includes(obj.filters[0].field)) {
                    obj.filters = this.multiSelectFilter(obj.filters[0], obj.filters[0].field);
                    obj.logic = 'or';
                }
                if (payloadKey) {
                    return { filters: obj.filters, logic: obj.logic };
                } else {
                    return { columnFilters: obj.filters, logic: obj.logic };
                }
            } else {
                logicVal = 'and';
                if (this.dateColumns.includes(obj.field)) {
                    obj.value = moment(new Date(obj.value)).format(dateFormat);
                    obj = [obj];
                } else if (this.multiselectColumns.includes(obj.field)) {
                    obj = this.multiSelectFilter(obj, obj.field);
                    logicVal = 'or';
                } else {
                    obj = [obj];
                }
                if (payloadKey) {
                    return { filters: obj, logic: logicVal };
                } else {
                    return { columnFilters: obj, logic: logicVal };
                }
            }
        });
    }

}
