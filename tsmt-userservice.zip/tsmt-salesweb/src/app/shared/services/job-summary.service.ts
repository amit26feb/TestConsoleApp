import { Injectable, NgZone } from '@angular/core';
import { forkJoin, Observable, of, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { INonTraneListModel } from '../../modules/jobs-list-master/models/non-trane-model';
import { BidsService } from '../../modules/jobs-list-master/services/bids.service';
import { JobsServicesService } from '../../modules/jobs-list-master/services/jobs-services.service';
import { SalesCustomerService } from '../../modules/jobs-list-master/services/sales-customer.service';
import { SelectionService } from '../../modules/jobs-list-master/services/selection.service';
import { IEditJobModel } from './../../modules/jobs-list-master/modal/job-details-edit.model';
import { LoaderService } from './../../shared/services/loader.service';
import { BidsListModel } from './../model/bids-model';
import { IJobCustomerModel } from './../model/job-customer-model';
import { IJobDocumentModel } from './../model/job-document-model';
import { IJobSummaryModel } from './../model/job-summary-model';
import { SelectionlistModel } from './../model/selectionlist-model';


@Injectable()
export class JobSummaryService {

  jobSummaryData;
  constructor(
    private salesCustomerService: SalesCustomerService,
    public loaderService: LoaderService,
    private selectionService: SelectionService,
    private bidsService: BidsService,
    private jobService: JobsServicesService,
    private ngZone: NgZone,
  ) {

  }
  jobSummaryPanelStatus$ = new Subject<{ showJobSummary: boolean }>();
  jobSummaryServices$: [Observable<IJobCustomerModel>, Observable<INonTraneListModel>, Observable<SelectionlistModel>,
    Observable<BidsListModel[]>, Observable<IJobDocumentModel>, Observable<IEditJobModel>];
  jobSummaryDetails$ = new Subject<{ jobSummaryData: IJobSummaryModel }>();
  // make api calls to fetch data for all jobSummary sections
  fetchSummaryData(jobId: number, drAddressId: number): void {
    this.loaderService.show();
    const payloadTrane = { skip: 0, take: 50, sort: [{ sortBy: 'sequenceNumber', sortDirection: 'Ascending' }], filters: [] };
    const payloadNonTrane = {
      skip: 0, take: 50, sort: [{ sortBy: 'variationType', sortDirection: 'Ascending' },
      { sortBy: 'description', sortDirection: 'Ascending' }], filters: [],
    };
    this.jobSummaryServices$ = [this.salesCustomerService.getAssignCustomers(0, 50, jobId, drAddressId).pipe(
      catchError((err) => of(undefined)),
    ),
    this.selectionService.getNonTraneData(payloadNonTrane, drAddressId, jobId).pipe(
      catchError((err) => of(undefined)),
    ),
    this.selectionService.getSelectionListData(payloadTrane, drAddressId, jobId)
      .pipe(
        catchError((err) => of(undefined)),
      ),
    (this.bidsService.getBidsList(drAddressId, jobId).pipe(
      catchError((err) => of(undefined)),
    ) as Observable<BidsListModel[]>),
      this.jobService.getDocumentList(drAddressId, jobId, 0, 0, 0, 50).pipe(
      catchError((err) => of(undefined)),
    ),
    this.jobService.fetchJobDetails(jobId, drAddressId).pipe(
      catchError((err) => of(undefined)),
    ),
    ];
    forkJoin(this.jobSummaryServices$).subscribe((data) => {
      this.jobSummaryData = data;
      this.loaderService.hide();
      const jobSummaryInfo: IJobSummaryModel = {
        customers: data[0],
        nonTraneItems: data[1],
        traneItems: data[2],
        bids: data[3],
        documents: data[4],
        basicInfo: data[5],
      };
      this.ngZone.run(() => this.jobSummaryDetails$.next({ jobSummaryData: jobSummaryInfo }));
    });
  }
}
