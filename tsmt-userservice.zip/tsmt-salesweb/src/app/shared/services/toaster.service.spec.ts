import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { ToasterService } from './toaster.service';

describe('ToasterService', () => {
  let service: ToasterService;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [ToasterService],
    });

    service = TestBed.inject(ToasterService);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should emit success mesasge and status', () => {
    service.setToaster('success', 'msg');
    (service as any).toasterStatus.subscribe((data) => {
      expect(data).toBe('success');
    });
    (service as any).toasterMsg.subscribe((data) => {
      expect(data.message).toBe('msg');
    });
  });

  it('should emit toaster status', () => {
    service.setToaster('success', 'msg');
    service.getToasterStatus().subscribe((data) => {
      expect(data).toBe('success');
    });
  });

  it('should emit toaster msg', () => {
    service.setToaster('success', 'msg');
    service.getToasterMsg().subscribe((data) => {
      expect(data.message).toBe('msg');
    });
  });

  it('should return toaster close status value', () => {
    service.setCloseStatus(true);
    service.getCloseStatus();
    expect(service.toasterCloseStatus).toBe(true);
  });

});
