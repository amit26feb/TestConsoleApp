import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConstants } from '../constants/constants';
import { ICreditProjectTransmitStatus } from '../model/credit-project-transmit-status-model';

@Injectable({
  providedIn: 'root',
})
export class ProjectService {

  constructor(private http: HttpClient, private appConstants: AppConstants) { }

  // Implements get call to get the exportToExcel data from the API
  exportToExcel(drAddressId: number, JobId: number, creditJobId: number, isTransmitted: boolean): Observable<any> {
    return this.http.get(
      `${this.appConstants.API_BASE_URL_SALESWEBGATEWAY}/${drAddressId}/Jobs/${JobId}/CreditJobs/${creditJobId}/CreditProjects?isTransmitted=${isTransmitted}`)
      .catch((error: any) => Observable.throwError(error));
  }

  // Implements get call to get the credit project transmit status from the API
  getCreditProjectTransmitStatus(drAddressId: number, creditJobId: number): Observable<ICreditProjectTransmitStatus> {
    return this.http.get<ICreditProjectTransmitStatus>(
      `${this.appConstants.API_BASE_URL_ORDERGATEWAY}/${drAddressId}/CreditJobs/${creditJobId}/TransmitStatus`)
      .catch((error: any) => Observable.throwError(error));
  }
}
