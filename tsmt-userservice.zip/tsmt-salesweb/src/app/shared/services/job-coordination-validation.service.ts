import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { Observable, Subject, Subscription, timer } from 'rxjs';
import { AppConstants } from '../constants/constants';

@Injectable({ providedIn: 'root' })
export class JobCoordinationValidationService implements OnDestroy {
    private BASE_URL = this.appConstants.API_BASE_URL_SALESWEBGATEWAY;
    jobId: number;
    drAddressId: number;
    jobDetailsValidationSummary: any;
    private jobDetailsValidationSubject: Subject<any> = new Subject();
    public submitButtonValidationSubject: Subject<any> = new Subject();
    public selectedExceptionSubject: Subject<any> = new Subject();
    jobDetailsValidationTimer: Subscription;
    hasBeenPreviouslyCoordinated = false;
    hasSelectionErrors = false;

    submitButtonValidationFlags = {
        isJobLockedByMe: false,
        isRequestedDateValid: false,
        isValidBidsSelection: false,
        isShipLeadTimeValid: false,
        isCoordinationStatusValid: false,
        isSubmissionNotesValid: false,
        hasNoActiveRequest: true,
        isBomDateSet: true,
        isBomDateValid: true,
        isJobContactValid: true,
        isSalesPersonValid: true,
        isJobReleasedFromCojo: false,
    };

    setJobLockedByMeFlag(data) {
        this.submitButtonValidationFlags.isJobLockedByMe = data;
        this.updateSubmitButtonValidationErrors();
    }

    setRequestedDateValidityFlag(data) {
        this.submitButtonValidationFlags.isRequestedDateValid = data;
        this.updateSubmitButtonValidationErrors();
    }

    setValidBidsSelection(isValid: boolean): void {
        this.submitButtonValidationFlags.isValidBidsSelection = isValid;
        this.updateSubmitButtonValidationErrors();
    }

    setBomDateSetFlag(data) {
        this.submitButtonValidationFlags.isBomDateSet = data;
        this.updateSubmitButtonValidationErrors();
    }

    setBomDateValidFlag(data) {
        this.submitButtonValidationFlags.isBomDateValid = data;
        this.updateSubmitButtonValidationErrors();
    }

    setValidShipLeadTimeFlag(data) {
        this.submitButtonValidationFlags.isShipLeadTimeValid = data;
        this.updateSubmitButtonValidationErrors();
    }

    setCoordinationStatusFlag(data) {
        this.submitButtonValidationFlags.isCoordinationStatusValid = data;
        this.updateSubmitButtonValidationErrors();
    }

    setSubmissionNotesFlag(data) {
        this.submitButtonValidationFlags.isSubmissionNotesValid = data;
        this.updateSubmitButtonValidationErrors();
    }

    setHasBeenPreviouslyCoordinatedFlag(data) {
        this.hasBeenPreviouslyCoordinated = data;
    }

    getHasBeenPreviouslyCoordinatedFlag() {
        return this.hasBeenPreviouslyCoordinated;
    }

    setHasSelectionErrors(hasErrors: boolean): void {
        this.hasSelectionErrors = hasErrors;
    }

    getHasSelectionErrors(): boolean {
        return this.hasSelectionErrors;
    }

    setActiveRequestFlag(data) {
        this.submitButtonValidationFlags.hasNoActiveRequest = !data;
        this.updateSubmitButtonValidationErrors();
    }

    setJobContactFlag(isJobContactValid: boolean) {
        this.submitButtonValidationFlags.isJobContactValid = isJobContactValid;
        this.updateSubmitButtonValidationErrors();
    }

    setSalesPersonFlag(isSalesPersonValid: boolean) {
        this.submitButtonValidationFlags.isSalesPersonValid = isSalesPersonValid;
        this.updateSubmitButtonValidationErrors();
    }

    setJobReleasedFromCojo(isJobReleasedFromCojo: boolean): void {
        this.submitButtonValidationFlags.isJobReleasedFromCojo = isJobReleasedFromCojo;
        this.updateSubmitButtonValidationErrors();
    }

    constructor(private http: HttpClient, private appConstants: AppConstants) {
    }

    ngOnDestroy() {
        this.clearTimerForJobDetailsValidation();
    }

    createTimerForJobDetailsValidation() {
        this.jobDetailsValidationTimer = timer(15000, 15000).subscribe(() => {
            this.validateJobDetailsForCoordination();
        });
    }

    clearTimerForJobDetailsValidation() {
        if (this.jobDetailsValidationTimer) {
            this.jobDetailsValidationTimer.unsubscribe();
        }
    }

    setParams(jobId, drAddressId) {
        this.jobId = jobId;
        this.drAddressId = drAddressId;
        this.validateJobDetailsForCoordination();
        if (!this.jobDetailsValidationTimer || this.jobDetailsValidationTimer.closed) {
            this.createTimerForJobDetailsValidation();
        }
    }

    setJobDetailsValidationSummary(validations) {
        this.jobDetailsValidationSubject.next(validations);
    }

    getJobDetailsValidationSummary() {
        return this.jobDetailsValidationSubject.asObservable();
    }

    validateJobDetailsForCoordination() {
        const validationSummary: any = {};
        validationSummary.errorCount = 0;
        if (this.jobId && this.drAddressId) {
            this.validateJobDetails(this.jobId, this.drAddressId).subscribe((res: any) => {
                validationSummary.validEarthwise = res.hasAnyEarthwiseSystems;
                validationSummary.validClassifications = res.hasAllDefinedClassifications;
                validationSummary.validBid = res.hasBeenPreviouslyCoordinated ||
                    (res.hasBidWithSelection && res.hasCompletePricing && res.isPricingValid);
                this.setErrorCount(validationSummary);
                if (!this.jobDetailsValidationSummary
                    || this.hasValidationSummaryChanged(this.jobDetailsValidationSummary, validationSummary)) {
                    this.setJobDetailsValidationSummary(validationSummary);
                    this.jobDetailsValidationSummary = validationSummary;
                }
            });
        }
    }

    setErrorCount(validationSummary) {
        validationSummary.errorCount += !validationSummary.validEarthwise ? 1 : 0;
        validationSummary.errorCount += !validationSummary.validClassifications ? 1 : 0;
        validationSummary.errorCount += !validationSummary.validBid ? 1 : 0;
    }

    hasValidationSummaryChanged(oldValidationSummary, newValidationSummary) {
        const props = Object.getOwnPropertyNames(oldValidationSummary);
        for (const prop of props) {
            if (oldValidationSummary[prop] !== newValidationSummary[prop]) {
                return true;
            }
        }
        return false;
    }

    validateJobDetails(jobId, drAddressId) {
        return this.http.get(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/JobCoordination/Validate');
    }

    updateSubmitButtonValidationErrors() {
        let validationErrors = [];
        if (!this.submitButtonValidationFlags.isJobLockedByMe) {
            validationErrors.push('isJobLockedByMe');
        } else if (!this.submitButtonValidationFlags.isCoordinationStatusValid) {
            validationErrors.push('isCoordinationStatusValid');
        } else {
            const validationFlags = Object.keys(this.submitButtonValidationFlags);
            validationErrors = validationFlags.filter((flag) => {
                return this.submitButtonValidationFlags[flag] === false;
            });
        }
        this.submitButtonValidationSubject.next(validationErrors);
    }

    getSubmitButtonValidationErrors(): Observable<any> {
        return this.submitButtonValidationSubject.asObservable();
    }

    setSelectedException(exception) {
        this.selectedExceptionSubject.next(exception);
    }

    getSelectedException() {
        return this.selectedExceptionSubject.asObservable();
    }
}
