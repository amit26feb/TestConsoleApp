import { CamStatus } from './../model/cam-data-model';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable, of } from 'rxjs';
import { AppConstants } from '../constants/constants';
import { CamContext, ICamExecutionStatus, ICamInput } from '../model/cam-data-model';
import { CamGatewayService } from './cam-gateway.service';

describe('CamGatewayService', () => {
    let camGatewayService: CamGatewayService;
    let httpClient: HttpClient;
    const originReset = TestBed.resetTestingModule;
    configureTestSuite(() => TestBed.configureTestingModule({
        imports: [HttpClientTestingModule],
        providers: [CamGatewayService, AppConstants],
    }));

    beforeEach(() => {
        camGatewayService = TestBed.inject(CamGatewayService);
        httpClient = TestBed.inject(HttpClient);
    });

    it('should be created', () => {
        expect(camGatewayService).toBeTruthy();
    });

    it('should return camExecutionStatus on successful execution of CheckAndApplyLock', () => {
        const executionStatus = {
            status: CamStatus.Allow
        } as ICamExecutionStatus;
        const camInputRequest = {
            context: CamContext.EditUntransmittedContext
        } as ICamInput;
        spyOn(httpClient, 'post').and.returnValue(of(executionStatus));
        camGatewayService.checkAndApplyLock(camInputRequest).subscribe((data) => {
            expect(data).toBe(executionStatus);
        });
    });

    it('should return error when invalid creditJobID is passed to exportToExcel method', () => {
        const camInputRequest = {
            context: CamContext.EditUntransmittedContext
        } as ICamInput;
        spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
        camGatewayService.checkAndApplyLock(camInputRequest).subscribe(() => {
        }, (err) => { expect(err.error).toBe('error'); });
    });


    it('should return camExecutionStatus on successful execution of checkCamGatewayStatus', () => {
        const executionStatus = {
            status: 'ALLOW'
        } as ICamExecutionStatus;
        const camInputRequest = {
            context: CamContext.ShipToSubmit
        } as ICamInput;
        spyOn(httpClient, 'post').and.returnValue(of(executionStatus));
        camGatewayService.checkCamGatewayStatus(camInputRequest).subscribe((data) => {
            expect(data).toBe(executionStatus);
        });
    });

    it('should return error on calling checkCamGatewayStatus', () => {
        const camInputRequest = {
            context: CamContext.ShipToSubmit
        } as ICamInput;
        spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
        camGatewayService.checkCamGatewayStatus(camInputRequest).subscribe(() => {
        }, (err) => { expect(err.error).toBe('error'); });
    });
});
