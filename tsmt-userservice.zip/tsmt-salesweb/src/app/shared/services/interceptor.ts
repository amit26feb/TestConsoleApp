import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Injectable, InjectionToken, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import 'rxjs/add/operator/mergeMap';
import { Observable } from 'rxjs';
import { from as fromPromise } from 'rxjs';
export const WINDOW_LOCATION = new InjectionToken<Location>('Location', {
    providedIn: 'root',
    factory: () => location
});


@Injectable()
export class LoginInterceptor implements HttpInterceptor {
    constructor(@Inject(WINDOW_LOCATION) public iLocation: Location, public oktaAuth: OktaAuthService, private router: Router) { }

    // intercepting all the API calls to add JWT token except login API call
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // concating token
        return this.getAuthDetails()
            .mergeMap((data) => {
                const jwtToken = `${data}`;
                const clonerequest = req.clone({ setHeaders: { Authorization: `Bearer ${jwtToken}` } });
                return next.handle(clonerequest).catch((err) => {
                    // Leads to error when access token is expired.
                    // Clear the localstorage and reload the page to navigate to login again.
                    if (err instanceof HttpErrorResponse && err.status === 401) {
                        localStorage.clear();
                        localStorage.setItem('okta_error', 'timeout');
                        this.iLocation.reload();
                    }
                    return Observable.throwError(err);
                }) as any;
            });
    }

    getAuthDetails() {
        return fromPromise(this.oktaAuth.getAccessToken());
    }
}
