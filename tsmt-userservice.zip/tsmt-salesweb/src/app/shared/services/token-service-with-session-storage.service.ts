import { Injectable } from '@angular/core';
import { ILoginService } from '../model/login-service';

@Injectable()

export class SessionStorageService implements ILoginService {

    constructor() { }
    // setter for JWT token
    setauthenticationToken(value: string): void {
        sessionStorage.setItem('auth', value);
    }
    // getter for JWT token
    getauthenticationToken() {
        return sessionStorage.getItem('auth');
    }
}
