import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OktaAuthService } from '@okta/okta-angular';
import { Observable, ReplaySubject } from 'rxjs';
import { AppConstants } from '../constants/constants';
import { IOfficeSelectorModel } from '../model/office-selector-model';

@Injectable({
  providedIn: 'root',
})
export class GlobalFilterService {
  private defaultOffice$ = new ReplaySubject<IOfficeSelectorModel>(1);
  private selectedOffice$ = new ReplaySubject<IOfficeSelectorModel>(1);
  private officeSelectorList$ = new ReplaySubject<IOfficeSelectorModel[]>(1);

  private BASE_URL = this.appConstants.API_BASE_URL_JOB;

  // fetches the office selector values on instantiation.
  constructor(private http: HttpClient, private appConstants: AppConstants, private oktaAuth: OktaAuthService) {
    this.oktaAuth.isAuthenticated().then((value) => {
      if (value) {
        this.fetchOfficeSelector().subscribe((data) => {
          // .slice is used to clone the data array here to avoid just reference assignment.
          const officeList = data.slice(0);
          this.setOfficeSelectorList(officeList);
          this.setDefaultOffice(officeList);
        });
      }
    });
  }

  // it sets the selectedOffice$ with the new selected office
  setSelectedOffice(selectedOffice: IOfficeSelectorModel) {
    this.selectedOffice$.next(selectedOffice);
  }

  // it  sets the officeSelectorList$ with the office list
  setOfficeSelectorList(officeList: IOfficeSelectorModel[]) {
    this.officeSelectorList$.next(officeList);
  }

  public getDefaultOffice() {
    return this.defaultOffice$;
  }

  // returns the selectedOffice$ Subject for other components to subscribe to its changes
  getSelectedOffice() {
    return this.selectedOffice$;
  }

  // returns the officeSelectorList$ Subject for other components to subscribe to its changes
  getOfficeSelectorList() {
    return this.officeSelectorList$;
  }

  // return the officeSelectorList data response from the GET service call
  fetchOfficeSelector() {
    return this.http.get<IOfficeSelectorModel[]>(this.BASE_URL + '/Jobs/SalesOffices')
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  /**
   * Identify the default database for the current user
   *
   * If the logged in user has access to the support database, it is the default
   * Otherwise, attempt to use the office identified as a "home" sales office
   * If a home office isn't identified, use the first office from the available list
   */
  setDefaultOffice(officeList: IOfficeSelectorModel[]): void {

    let defaultOffice = officeList.find((x) => x.drAddressId === this.appConstants.SUPPORT_DATABASE_DR_ADDRESS_ID);

    if (defaultOffice === undefined) {
      const officesWithSpecifiedHome = officeList.filter((x) => x.homeDrAddressId > 0 && x.homeDrAddressId === x.drAddressId);
      defaultOffice = officesWithSpecifiedHome.length > 0 ? officesWithSpecifiedHome[0] : officeList[0];
    }

    this.defaultOffice$.next(defaultOffice);
  }
}
