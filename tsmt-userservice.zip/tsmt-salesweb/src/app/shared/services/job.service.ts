import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IDeleteDocumentModel } from '../../modules/jobs-list-master/models/document.model';
import { AppConstants } from '../constants/constants';
import { IJobModel } from '../model/job-model';

@Injectable({
  providedIn: 'root',
})
export class JobService {
  private BASE_URL = this.appConstants.API_BASE_URL_JOB;
  constructor(
    private http: HttpClient,
    private appConstants: AppConstants) { }

  getJobDetails(drAddressId: number, jobId: number): Observable<IJobModel> {
    return this.http.get<IJobModel>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  /**
   * Deletes document
   * @param drAddressId DrAddress id
   * @param jobId Job id
   * @param documentModel delete document request
   */
  public deleteDocuments(drAddressId: number, jobId: number, documentModel: IDeleteDocumentModel[]): Observable<boolean> {
    const url = this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Documents';
    const options = {
      headers: new HttpHeaders({
        CONTENT_TYPE: this.appConstants.APPLICATION_JSON,
      }),
      body: documentModel,
    };
    return this.http.delete<boolean>(url, options).catch((error: any) => {
      return Observable.throwError(error);
    });
  }
}
