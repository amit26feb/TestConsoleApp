import { EventEmitter, Injectable } from '@angular/core';
@Injectable()
export class ToasterService {
    private toasterStatus: EventEmitter<any>;
    toasterCloseStatus: any;
    private toasterMsg: EventEmitter<any>;
    constructor() {
        this.toasterStatus = new EventEmitter<any>();
        this.toasterMsg = new EventEmitter<any>();
    }

    // emiting the toaster message and status
    public setToaster(status: string, msg: string) {
        this.toasterStatus.emit(status);
        this.toasterMsg.emit({ message: msg, messageStatus: status });
    }

    // returning current toaster status
    public getToasterStatus() {
        return this.toasterStatus;
    }

    // getter for toaster message
    public getToasterMsg() {
        return this.toasterMsg;
    }

    public setCloseStatus(status: boolean) {
        this.toasterCloseStatus = status;
    }

    public getCloseStatus() {
        return this.toasterCloseStatus;
    }
}
