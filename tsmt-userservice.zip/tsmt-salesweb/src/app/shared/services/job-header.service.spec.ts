import { getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { JobHeaderService } from './job-header.service';

describe('JobHeaderService', () => {

  let injector: TestBed;
  let service: JobHeaderService;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        JobHeaderService,
      ],
    });

    injector = getTestBed();
    service = injector.inject(JobHeaderService);
  });



  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create message when calling setJob', () => {
    service.setJob(100, 10);
    const subscription1 = service.message.subscribe((data) => {
      expect(data).toBe('100/10');
    });
    subscription1.unsubscribe();
  });

  it('should sent empty message when calling clearJob', () => {
    service.clearJob();
    const subscription2 = service.message.subscribe((data) => {
      expect(data).toBe('');
    });
    subscription2.unsubscribe();
  });

  it('should set the  detailsMenuClick subject on setDetailsMenuClick', () => {
    service.setDetailsMenuClick({ item: 'address' });

    service.detailsMenuClick.subscribe((data) => {
      expect(data).toBe({ item: 'address' });
    });
  });

  it('should set the detailsMenu items on setDetailsMenuItems', () => {
    service.setDetailsMenuItems([{ item: 'general' }, { item: 'address' }]);
    expect(service.getDetailsMenuItems()[0].item).toBe('general');
    expect(service.getDetailsMenuItems()[1].item).toBe('address');
  });

  it('should set the userId on calling setUserId', () => {
    service.setUserId('ccfbsb');
    expect(service.getUserId()).toBe('ccfbsb');
  });

  it('should set the userId to lowercase on calling setUserId', () => {
    service.setUserId('CCFBSB');
    expect(service.getUserId()).toBe('ccfbsb');
  });

  it('should set the userId to undefined when logged in userId is null on calling setUserId', () => {
    service.setUserId(null);
    expect(service.getUserId()).toBe(undefined);
  });

  it('should set the userName on calling setUserName', () => {
    service.setUserName('John');
    expect(service.getUserName()).toBe('John');
  });

  it('should set the fullName on calling setFullName', () => {
    service.setFullName('Christianson, Jaimie');
    expect(service.getFullName()).toBe('Christianson, Jaimie');
  });

  it('should set the details page form status items on setDetailsPageValidationStatus', () => {
    service.setDetailsPageValidationStatus([true, true, false, true, true, true, true, true, true, true, true]);
    expect(service.getDetailsPageValidationStatus()[0]).toBe(true);
    expect(service.getDetailsPageValidationStatus()[2]).toBe(false);
  });

  it('should set the import job page open status on calling setImportJobOpenStatus', () => {
    service.setImportJobOpenStatus(true);
    expect(service.getImportJobOpenStatus()).toBe(true);
  });

  it('should set the work package version on calling setWorkPackageVersion', () => {
    service.setWorkPackageVersion(10);
    expect(service.getWorkPackageVersion()).toBe(10);
  });

  it('should set the navigateFromUrl on calling setNavigateFromUrl', () => {
    service.setNavigateFromUrl('/home-page-list/96/projects/CreditJobs/2093621/credit-project-details');
    expect(service.getNavigateFromUrl()).toBe('/home-page-list/96/projects/CreditJobs/2093621/credit-project-details');
  });

  it('should set the jobId on setJobId', () => {
    service.setJobId(12345);
    expect(service.getJodId()).toBe(12345);
  });
});
