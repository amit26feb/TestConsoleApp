import { getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { TileService, TileTypes } from './tile.service';

describe('TileService', () => {
  let tileService: TileService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [TileService],
    });
  });

  beforeEach(() => {
    const injector = getTestBed();
    tileService = TestBed.inject(TileService);
  });

  it('should be created', () => {
    expect(tileService).toBeTruthy();
  });

  it('should return true for inclusive tile if user has matching role on call to userCanSeeTile', () => {
    const userRoles = ['tsmt-credit-approver'];
    const result = tileService.userCanSeeTile(TileTypes.CreditApprovalBacklog, userRoles);
    expect(result).toBe(true);
  });

  it('should return false for inclusive tile if user does not have matching role on call to userCanSeeTile', () => {
    const userRoles = ['non-matching-role'];
    const result = tileService.userCanSeeTile(TileTypes.CreditApprovalBacklog, userRoles);
    expect(result).toBe(false);
  });

  it('should return false for exclusive tile if user has matching role on call to userCanSeeTile', () => {
    const userRoles = ['tsmt-estimate-approver'];
    const result = tileService.userCanSeeTile(TileTypes.WorkPackageValidationRequests, userRoles);
    expect(result).toBe(false);
  });

  it('should return true for inclusive tile if user does not have matching role on call to userCanSeeTile', () => {
    const userRoles = ['non-matching-role'];
    const result = tileService.userCanSeeTile(TileTypes.WorkPackageValidationRequests, userRoles);
    expect(result).toBe(true);
  });

  it('should return appropriate tiles for no role', () => {
    const userRoles = [];
    const result = tileService.getUserAccessibleTiles(userRoles);
    expect(result.length).toBe(4);
    expect(result[0].type).toBe(TileTypes.MyCreditApprovalAndPOAcks);
    expect(result[1].type).toBe(TileTypes.PlannedShipmentCommitted);
    expect(result[2].type).toBe(TileTypes.PlannedShipmentUpcomingReleased);
    expect(result[3].type).toBe(TileTypes.WorkPackageValidationRequests);
  });

  it('should return appropriate tiles for tsmt-credit-approver role', () => {
    const userRoles = ['tsmt-credit-approver'];
    const result = tileService.getUserAccessibleTiles(userRoles);
    expect(result.length).toBe(6);
    expect(result[0].type).toBe(TileTypes.CreditApprovalBacklog);
    expect(result[1].type).toBe(TileTypes.CreditMetrics);
    expect(result[2].type).toBe(TileTypes.MyCreditApprovalAndPOAcks);
    expect(result[3].type).toBe(TileTypes.PlannedShipmentCommitted);
    expect(result[4].type).toBe(TileTypes.PlannedShipmentUpcomingReleased);
    expect(result[5].type).toBe(TileTypes.WorkPackageValidationRequests);
  });

  it('should return appropriate tiles for tsmt-estimate-approver role', () => {
    const userRoles = ['tsmt-estimate-approver'];
    const result = tileService.getUserAccessibleTiles(userRoles);
    expect(result.length).toBe(4);
    expect(result[0].type).toBe(TileTypes.MyCreditApprovalAndPOAcks);
    expect(result[1].type).toBe(TileTypes.PlannedShipmentCommitted);
    expect(result[2].type).toBe(TileTypes.PlannedShipmentUpcomingReleased);
    expect(result[3].type).toBe(TileTypes.WorkPackageApprovalRequests);
  });

  it('should return title for given TileType on call to getTileTitle', () => {
    const result = tileService.getTileTitle(TileTypes.WorkPackageApprovalRequests);
    expect(result).toBe('Work Package Approval Requests');
  });
});
