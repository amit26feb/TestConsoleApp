import { HomePageTitlesEnum } from './../../modules/home-page/models/home-page-title.model';
import { HttpParams, HttpErrorResponse } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { ISearchProjectModel, ISearchProjectShippingHistoryModel, IShippingHistoryPayloadModel, IFilePayloadModel } from '@tsmt/salesweb-ordersmodule';
import { AppConstants } from '../constants/constants';
import { JobsService } from '@tsmt/salesweb-jobsmodule';
import { DisplayModeEnum } from '../enums/display-mode-enum';

@Injectable({
  providedIn: 'root',
})
export class GlobalSearchService {
  public BASE_URL: string;
  public fetchedData = new Subject<any>();
  public searchValue = new Subject<string>();
  public TabName = new BehaviorSubject(null);
  public tabName: string;
  public searchVal: string;
  public options: HttpParams;
  public workPackage = 'Work Packages';
  public shippingHistoryDownloadUrl: string;
  public source: string;

  constructor(private http: HttpClient, private appConstants: AppConstants, private jobsService: JobsService) { }

  searchList(searchText: string, tabName: string, drAddressId: number, currentDataSelected?: string, jobId?: number) {
    this.options = null;
    if (tabName && drAddressId) {
      // other tabs will be integrated later
      if (tabName === this.workPackage) {
        this.tabName = tabName;
        if (searchText !== '') {
          const options = new HttpParams()
            .set('searchText', searchText);
          this.options = options;
        } else if (jobId > 0) {
          const options = new HttpParams()
            .set('jobId', jobId.toString());
          this.options = options;
        } else {
          this.options = null;
        }
        this.BASE_URL = this.appConstants.API_BASE_URL_WORKPACKAGE + '/' + drAddressId + '/WorkPackages';
      } else if (tabName === 'Projects' && searchText !== '') {
        this.setToggleBaseURL(tabName, searchText, drAddressId, currentDataSelected);
      } else if (tabName === HomePageTitlesEnum.Jobs) {
        this.jobsService.triggerSearch.next(searchText);
      }
      // sets the search value
      this.TabName.next(this.tabName);
      this.searchValue.next(searchText);
      if (tabName === this.workPackage) {
        this.fetchList().subscribe((data) => {
          // sets the searched data
          this.fetchedData.next(data);
        }, (err) => {
          this.fetchedData.next(err);
        });
      }
    }
  }

  /**
   * Sets the BASE_URL according to toggle value selected
   * * @returns void
   */
  setToggleBaseURL(tabName: string, searchText: string, drAddressId: number, currentDataSelected: string): void {
    this.tabName = tabName;
    this.searchVal = searchText;
    if (currentDataSelected === 'Transmitted' || currentDataSelected === 'Projects') {
      this.BASE_URL = `${this.appConstants.API_BASE_URL_ORDERGATEWAY}/CreditJobs`;
    } else if (currentDataSelected === 'History') {
      this.BASE_URL = `${this.appConstants.API_BASE_URL_ORDER_HISTORY}/CreditJobs`;
    } else if (currentDataSelected === 'Untransmitted') {
      this.BASE_URL = `${this.appConstants.API_BASE_URL_ORDERGATEWAY}/CreditJobs`;
    } else if (currentDataSelected === 'Shipping History') {
      this.BASE_URL = `${this.appConstants.API_BASE_URL_SHIPPING_HISTORY}/Orders/SearchableItems`;
    }
  }


  fetchList(currentToggle?: string, drAddressList?: number[]) {
    if (currentToggle === DisplayModeEnum.Transmitted || currentToggle === DisplayModeEnum.History
      || currentToggle === DisplayModeEnum.Untransmitted) {
      return this.http
        .post(`${this.BASE_URL}`, drAddressList, { params: this.options })
        .pipe(map((response: any[]) => this.transformData(response)))
        .catch((error: any) => Observable.throwError(error));
    } else {
      return this.http
        .get(`${this.BASE_URL}`, { params: this.options })
        .pipe(map((response: any[]) => this.transformData(response)))
        .catch((error: any) => Observable.throwError(error));
    }
  }
  getOrderList(skip, take, drAddressId, currentToggle?: string): Observable<ISearchProjectModel> {
    if (currentToggle === DisplayModeEnum.History) {
      this.options = new HttpParams()
        .set('searchValue', this.searchVal).set('skip', skip).set('take', take);
      return this.fetchList(currentToggle, drAddressId);
    } else if (currentToggle === DisplayModeEnum.Untransmitted) {
      this.source = 'Ordering';
      this.options = new HttpParams()
        .set('searchValue', this.searchVal).set('skip', skip).set('take', take).set('source', this.source);
      return this.fetchList(currentToggle, drAddressId);
    } else if (currentToggle === DisplayModeEnum.Transmitted) {
      this.source = 'Order';
      this.options = new HttpParams()
        .set('searchValue', this.searchVal).set('skip', skip).set('take', take).set('source', this.source);
      return this.fetchList(currentToggle, drAddressId);
    }
  }

  /**
   * Gets the shipping history pdf
   * @param {string} - payload contains document key
   * @returns file - shipping history pdf
   */
  downloadPDF(documentKey: string): Observable<{ file: Blob }> {
    this.options = new HttpParams().set('documentKey', documentKey);
    const shippingHistoryDownloadUrl = `${this.appConstants.API_BASE_URL_SHIPPING_HISTORY}/Orders/Document/Download`;
    return this.http.get(shippingHistoryDownloadUrl, { params: this.options, observe: 'response', responseType: 'blob' })
      .map((response) => {
        return {
          file: new Blob([response.body], { type: response.headers.get('Content-Type') }),
        };
      }).catch((err: HttpErrorResponse) => {
        return Observable.throwError(err);
      });
  }

  /**
   * Gets the shipping history details
   * @param {IShippingHistoryPayloadModel} - payload that contains paging and sorting options
   * @returns ISearchProjectShippingHistoryModel - shipping history response
   */
  getShippingHistory(payload: IShippingHistoryPayloadModel): Observable<ISearchProjectShippingHistoryModel> {
    return this.http.post<ISearchProjectShippingHistoryModel>(`${this.BASE_URL}`,
      payload, { observe: 'response' }).map(
        (res) => {
          if (res.status === 200) {
            return res.body;
          } else if (res.status === 204) {
            return { pagingItems: [], pageNumber: 0, pageSize: 0, totalItemCount: 0, pageCount: 0 };
          }
        }).catch((error: HttpErrorResponse) => Observable.throwError(error));
  }

  /**
   * Download File
   * @param {payload} -  payload for pdf request
   */
  downloadFile(payload: IFilePayloadModel): Observable<string> {
    this.shippingHistoryDownloadUrl = `${this.appConstants.API_BASE_URL_SHIPPING_HISTORY}/Orders/PcbHeaders/GeneratePdf`;
    return this.http.post(this.shippingHistoryDownloadUrl, payload, { responseType: 'text' })
      .catch((err: HttpErrorResponse) => {
        return Observable.throwError(err);
      });
  }

  /**
   * Download vo report
   * @param {documentKey} - document Key
   * @param {orderType} - the order type (VO|SIL)
   */
  downloadShippingHistoryReports(documentKey: string, orderName: string, serialNumber?: string, orderType?: string)
    : Observable<{ file: Blob, filename: string }> {
    let options = new HttpParams()
      .set('documentKey', documentKey)
      .set('orderNumber', orderName)
      .set('orderType', orderType || 'VO');
    if (serialNumber != null) {
      options = options.set('serialNumber', serialNumber);
    }
    this.shippingHistoryDownloadUrl = `${this.appConstants.API_BASE_URL_DOCUMENT}/ShippingHistoryDocuments/Download`;
    return this.http.get(this.shippingHistoryDownloadUrl, { observe: 'response', responseType: 'blob', params: options })
      .map((res) => {
        if (res.status === 200) {
          const contentDisposition = res.headers.get('content-disposition');
          return {
            file: new Blob([res.body], { type: res.headers.get('Content-Type') }),
            filename: this.getFilenameFromContentDisposition(contentDisposition).trim()
          };
        } else {
          return null;
        }
      }).catch((err: HttpErrorResponse) => {
        return Observable.throwError(err);
      });
  }

  transformData(data: any) {
    const searchedList = data;
    if (data && this.tabName === 'Work Packages') {
      searchedList.map((workPackage: any) => {
        // transform the bidDate, stateDate and endDate to date format.
        workPackage.bidDate = workPackage.bidDate ? new Date(workPackage.bidDate).setHours(0, 0, 0) : '';
        workPackage.startDate = workPackage.startDate ? new Date(workPackage.startDate).setHours(0, 0, 0) : '';
        workPackage.endDate = workPackage.endDate ? new Date(workPackage.endDate).setHours(0, 0, 0) : '';
        // trasform null to ' ' so that we can filter null values in multiselect
        workPackage.salesStage = workPackage.salesStage === null ? ' ' : workPackage.salesStage;
        return workPackage;
      });
    }
    return searchedList;
  }

  /**
   * Parses a filename from the content disposition header
   * @param {contentDisposition} - the content disposition header value
   */
  getFilenameFromContentDisposition(contentDisposition: string): string {
    const regex = /filename=(?<filename>[^,;]+);/g;
    const match = regex.exec(contentDisposition);
    // remove any whitespace (trim) or quotes
    return match.groups.filename.trim().replace(/\"/g, '');
  }
}
