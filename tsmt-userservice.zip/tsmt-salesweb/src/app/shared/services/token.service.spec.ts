import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { CookieService } from 'ngx-cookie-service';
import { TokenServiceCI } from './token.service';

describe('TokenService', () => {
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [TokenServiceCI, CookieService],
    });
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([TokenServiceCI], (service: TokenServiceCI) => {
    expect(service).toBeTruthy();
  }));

  it('set method should set the value', inject([TokenServiceCI], (service: TokenServiceCI) => {
    const cookieSer = TestBed.inject(CookieService);
    service.setauthenticationToken('auth');
    expect(cookieSer.get('auth')).toBe('auth');
  }));

  it('get method should get the value', inject([TokenServiceCI], (service: TokenServiceCI) => {
    service.setauthenticationToken('auth');
    expect(service.getauthenticationToken()).toBe('auth');
  }));

});
