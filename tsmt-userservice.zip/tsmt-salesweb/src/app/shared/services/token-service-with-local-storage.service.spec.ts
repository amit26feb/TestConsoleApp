import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { TokenServiceLS } from './token-service-with-local-storage.service';

describe('TokenServiceWithLocalStorageService', () => {
  let service: TokenServiceLS;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [TokenServiceLS],
    });
    service = TestBed.inject(TokenServiceLS);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set authentication token', () => {
    service.setauthenticationToken('1234');
    expect(localStorage.getItem('auth')).toBe('1234');
  });

  it('should get authentication token', () => {
    service.setauthenticationToken('1234');
    expect(service.getauthenticationToken()).toBe('1234');
  });

});
