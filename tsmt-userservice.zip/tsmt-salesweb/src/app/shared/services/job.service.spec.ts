import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { IDeleteDocumentModel } from '../../modules/jobs-list-master/models/document.model';
import { AppConstants } from '../constants/constants';
import { IJobModel } from '../model/job-model';
import { JobListServiceMock } from '../test-mocks/jobService-mock';
import { JobService } from './job.service';

describe('JobService', () => {
  let jobService: JobService;
  let appConstants: AppConstants;
  let httpClient: HttpClient;
  let mockData: JobListServiceMock;
  const originReset = TestBed.resetTestingModule;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [JobService, AppConstants, JobListServiceMock],
      imports: [HttpClientTestingModule],
    });
    const injector = getTestBed();
    jobService = injector.inject(JobService);
    appConstants = injector.inject(AppConstants);
    httpClient = TestBed.inject(HttpClient);
    mockData = TestBed.inject(JobListServiceMock);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should get job details on getJobDetails', () => {
    const jobId = 53574;
    const drAddressId = 122;
    spyOn(httpClient, 'get').and.returnValue(Observable.of(mockData.jobDetails));
    jobService.getJobDetails(drAddressId, jobId).subscribe((res: IJobModel) => {
      expect(res).toEqual(mockData.jobDetails);
    });
  });

  it('should check error on service method getJobDetails', () => {
    const jobId = 0;
    const drAddressId = 122;
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    jobService.getJobDetails(drAddressId, jobId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should delete document on calling deleteDocuments', () => {
    const drAddressId = 78;
    const jobId = 34;
    const documentDetails: IDeleteDocumentModel[] = [{
      documentKey: 'Jobs/78/34/test.txt',
      documentName: 'test',
      documentVersion: 'hkmnbikletgsaisdbdhdj',
      jobDocumentTypeId: 1,
    } as IDeleteDocumentModel];
    const spyDelete = spyOn(httpClient, 'delete').and.returnValue(Observable.of(true));
    jobService.deleteDocuments(drAddressId, jobId, documentDetails).subscribe((res) => {
      expect(spyDelete).toHaveBeenCalled();
    });
  });

  it('should catch the error thrown from the service on calling deleteDocuments', () => {
    const drAddressId = 78;
    const jobId = 34;
    const url = appConstants.API_BASE_URL_JOB + '/' + drAddressId + '/Jobs/' + jobId + '/Documents';
    const documentDetails: IDeleteDocumentModel[] = [{
      documentKey: 'Jobs/78/34/test.txt',
      documentName: 'test',
      documentVersion: 'hkmnbikletgsaisdbdhdj',
      jobDocumentTypeId: 1,
    } as IDeleteDocumentModel];
    const options = {
      headers: new HttpHeaders({
        CONTENT_TYPE: appConstants.APPLICATION_JSON,
      }),
      body: documentDetails,
    };
    const spyDelete = spyOn(httpClient, 'delete').and.returnValue(Observable.throwError({ error: 'error' }));
    jobService.deleteDocuments(drAddressId, jobId, documentDetails).subscribe(() => {
    }, (err) => {
      expect(err.error).toBe('error');
    });
  });
});
