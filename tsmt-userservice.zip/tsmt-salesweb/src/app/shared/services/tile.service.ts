import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class TileService {
  public userCanSeeTile(tileType: TileTypes, userRoles: string[]) {
    const tileSecurity = TileInformation.find(ts => ts.type === tileType);
    if (tileSecurity.exclude) {
      return !userRoles.some(r => tileSecurity.roles.includes(r));
    } else {
      return userRoles.some(r => tileSecurity.roles.includes(r)) || !tileSecurity.roles.length;
    }
  }

  public getUserAccessibleTiles(userRoles: string[]): ITileInfo[] {
    const accessibleTiles = [];
    Object.keys(TileTypes).forEach(tileType => {
      if (this.userCanSeeTile(tileType as TileTypes, userRoles)) {
        accessibleTiles.push(TileInformation.find(ti => ti.type === tileType));
      }
    });

    return accessibleTiles;
  }

  public getTileTitle(tileType: TileTypes): string {
    return TileInformation.find(ti => ti.type === tileType).title;
  }
}

export enum TileTypes {
  CreditApprovalBacklog = 'CreditApprovalBacklog',
  CreditMetrics = 'CreditMetrics',
  MyCreditApprovalAndPOAcks = 'MyCreditApprovalAndPOAcks',
  PlannedShipmentCommitted = 'PlannedShipmentCommitted',
  PlannedShipmentUpcomingReleased = 'PlannedShipmentUpcomingReleased',
  WorkPackageValidationRequests = 'WorkPackageValidationRequests',
  WorkPackageApprovalRequests = 'WorkPackageApprovalRequests',
}

export interface ITileInfo {
  type: TileTypes; // Tile type for security entry
  title: string; // The title for the tile
  roles: string[]; // Roles associated to tile type
  exclude: boolean; // Should roles exclude access to the tile?  Or permit access to the tile?
}

export const TileInformation: ITileInfo[] = [
  {
    type: TileTypes.CreditApprovalBacklog,
    title: 'Credit Approval Backlog',
    roles: ['tsmt-credit-approver'],
    exclude: false,
  },
  {
    type: TileTypes.CreditMetrics,
    title: 'Team Metrics/MDI',
    roles: ['tsmt-credit-approver'],
    exclude: false,
  },
  {
    type: TileTypes.MyCreditApprovalAndPOAcks,
    title: 'My Credit Approval And POAcks',
    roles: [],
    exclude: false,
  },
  {
    type: TileTypes.PlannedShipmentCommitted,
    title: 'Committed P/S (based on Product Release Date',
    roles: [],
    exclude: false,
  },
  {
    type: TileTypes.PlannedShipmentUpcomingReleased,
    title: 'Upcoming Released P/S (based on Estimated Ship Date',
    roles: [],
    exclude: false,
  },
  {
    type: TileTypes.WorkPackageValidationRequests,
    title: 'Work Package Validation Requests',
    roles: ['tsmt-estimate-approver', 'tsmt-estimate-fulfillment'],
    exclude: true,
  },
  {
    type: TileTypes.WorkPackageApprovalRequests,
    title: 'Work Package Approval Requests',
    roles: ['tsmt-estimate-approver'],
    exclude: false,
  },
];
