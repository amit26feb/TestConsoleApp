import { Injectable } from '@angular/core';
import { ILoginService } from '../model/login-service';

@Injectable()

export class TokenServiceLS implements ILoginService {

    constructor() { }
    // setter for JWT token
    setauthenticationToken(value: string): void {
        localStorage.setItem('auth', value);
    }
    // getter for JWT token
    getauthenticationToken() {
        return localStorage.getItem('auth');
    }
}
