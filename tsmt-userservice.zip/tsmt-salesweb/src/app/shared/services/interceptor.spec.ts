import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { getTestBed, inject, TestBed } from '@angular/core/testing';
import { Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { OKTA_CONFIG, OktaAuthService } from '@okta/okta-angular';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { of } from 'rxjs';
import { LoginComponent } from '../../../app/login/login.component';
import { AppConstants } from '../constants/constants';
import oktaConfig from './../../.okta.config';
import { SelectionService } from './../../modules/jobs-list-master/services/selection.service';
import { LoginInterceptor, WINDOW_LOCATION } from './interceptor';

describe(`LoginInterceptor`, () => {
    let service: SelectionService;
    let httpMock: HttpTestingController;
    let appConstants: AppConstants;
    let oktaAuth: OktaAuthService;
    let injector: TestBed;
    let interceptor: LoginInterceptor;
    let iLocation: Location;
    const originReset = TestBed.resetTestingModule;
    const oktaRoutingConfig = Object.assign({
        onAuthRequired: ({ okta, router }) => {
            // Redirect the user to your custom login page
            router.navigate(['']);
        },
    }, oktaConfig.oidc);

    const TestRoutes: Routes = [
        {
            path: '**',
            component: LoginComponent,
        }];



    configureTestSuite(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                RouterTestingModule.withRoutes(TestRoutes),
            ],
            declarations: [LoginComponent],
            providers: [
                SelectionService,
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: LoginInterceptor,
                    multi: true,
                },
                { provide: OKTA_CONFIG, useValue: oktaRoutingConfig },
                AppConstants,
                OktaAuthService,
                { provide: Location, useValue: { reload: () => { } } },
                { provide: WINDOW_LOCATION, useValue: { reload: () => { } } }
            ],
        });
        injector = getTestBed();
        service = injector.inject(SelectionService);
        appConstants = injector.inject(AppConstants);
        oktaAuth = injector.inject(OktaAuthService);
        httpMock = injector.inject(HttpTestingController);
        iLocation = injector.inject(Location);
        interceptor = injector.get(HTTP_INTERCEPTORS);
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });


    it('should add an Authorization header', inject([HTTP_INTERCEPTORS],
        (http: LoginInterceptor) => {
            const spy = spyOn(interceptor[1], 'getAuthDetails').and.returnValue(of('JWTTOKEN'));
            const payload = {
                skip: 0,
                take: 20,
                sort: [
                    {
                        sortBy: 'prod_Family',
                        sortDirection: 'Ascending',
                    },
                    { // Hidden secondary sort by Revised asc.
                        sortBy: 'reviseDate',
                        sortDirection: 'Ascending',
                    },
                ],
            };

            service.getSelectionListData(payload, 121, 1234).subscribe((response) => {
                expect(response.data).toBeTruthy();
            });
            expect(spy).toHaveBeenCalled();
            const httpRequest = httpMock.expectOne(`${appConstants.API_BASE_URL_JOB_SELECTION}/121/Jobs/1234/Selections/TraneItems`);
            expect(httpRequest.request.headers.has('Authorization')).toEqual(true);
            httpRequest.flush({ data: true }, { status: 200, statusText: 'OK' });
        }));

    it('should return an Observable on calling getAuthDetails', () => {
        spyOn(oktaAuth, 'getAccessToken').and.returnValue(Promise.resolve('jwttoken'));
        const obs = interceptor[1].getAuthDetails();
        obs.subscribe((res) => {
            expect(res).toBe('jwttoken');
        });
    });

    it('should check undefined Authorization header', inject([HTTP_INTERCEPTORS],
        (http: LoginInterceptor) => {
            const spy = spyOn(interceptor[1], 'getAuthDetails').and.returnValue(of('undefined'));
            const payload = {
                skip: 0,
                take: 20,
                sort: [
                    {
                        sortBy: 'productFamily',
                        sortDirection: 'Ascending',
                    },
                    { // Hidden secondary sort by Revised asc.
                        sortBy: 'reviseDate',
                        sortDirection: 'Ascending',
                    },
                ],
            };

            service.getSelectionListData(payload, 121, 1234).subscribe((response) => {
                expect(response).toBeNull();
            });
            expect(spy).toHaveBeenCalled();
            httpMock.expectOne(`${appConstants.API_BASE_URL_JOB_SELECTION}/121/Jobs/1234/Selections/TraneItems`);

        }));


    it('should call location reload when HttpHandler returns 401', inject([HTTP_INTERCEPTORS, WINDOW_LOCATION],
        (http: LoginInterceptor, ilocation: Location) => {
            const spy = spyOn(interceptor[1], 'getAuthDetails').and.returnValue(of(Promise.resolve('jwttoken')));
            const payload = {
                skip: 0,
                take: 20,
                sort: [
                    {
                        sortBy: 'productFamily',
                        sortDirection: 'Ascending',
                    },
                    { // Hidden secondary sort by Revised asc.
                        sortBy: 'reviseDate',
                        sortDirection: 'Ascending',
                    },
                ],
            };
            const spyLocationReload = spyOn(ilocation, 'reload');

            service.getSelectionListData(payload, 121, 1234).subscribe(() => {
            }, (err) => {
                expect(err.status).toEqual(401);
            });
            const httpRequest = httpMock.expectOne(`${appConstants.API_BASE_URL_JOB_SELECTION}/121/Jobs/1234/Selections/TraneItems`);
            httpRequest.flush({}, { status: 401, statusText: 'UnAuthorised' });
            expect(spyLocationReload).toHaveBeenCalled();
        }));


    afterEach(() => {
        httpMock.verify();
    });
});
