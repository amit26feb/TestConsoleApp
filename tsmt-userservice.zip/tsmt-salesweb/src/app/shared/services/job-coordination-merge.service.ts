import { Injectable } from '@angular/core';
import { IBidSelections, IDraftSelection, ISelection } from './../../modules/jobs-list-master/models/coordinate-job.model';
import { CoordinateService } from './../../modules/jobs-list-master/services/coordinate.service';

@Injectable({ providedIn: 'root' })
export class JobCoordinationMergeService {
    coordinateDraftData: any;
    coordinationStatus: any;
    jobId: number;
    drAddressId: number;
    coordinationId: number;
    jobPreviouslyCoordinated: boolean;
    coordinationStatusOptions = {
        notSubmitted: 'Not Submitted',
        submitted: 'Submitted',
        pendingPricing: 'Pending Pricing',
        escalated: 'Escalated',
        escalationComplete: 'Escalation Complete',
        pricingComplete: 'Pricing Complete',
        spaIssuedDiscountActive: 'SPA Issued/Discount Active',
        recoordinated: 'Recoordinated',
    };
    setCoordinateDraftData(data) {
        this.coordinateDraftData = data;
    }
    setCoordinationStatus(data) {
        this.coordinationStatus = data;
    }

    setJobId(jobId: number) {
        this.jobId = jobId;
    }

    setDrAddressId(drAddressId: number) {
        this.drAddressId = drAddressId;
    }

    setCoordinationId(coordinationId: number) {
        this.coordinationId = coordinationId;
    }

    constructor(private coordinateService: CoordinateService) {
    }

    buildBomData(bids: IBidSelections[]): IBidSelections[] {
        const draftSelections: IDraftSelection[] = this.coordinateDraftData.billOfMaterials;
        // loading the BOM details for the Not Submitted or above status from original and draft
        if (this.coordinationStatus === this.coordinationStatusOptions.notSubmitted && draftSelections && draftSelections.length > 0) {
            bids.forEach((bid) => {
                this.setSelectionsInfoFromDraft(bid, draftSelections);
                this.updateShipTimeForNewSelections(bid, draftSelections);
            });
        }
        if (this.coordinationStatus !== this.coordinationStatusOptions.notSubmitted) {
            // loading the BOM details for the submitted or above status from draft
            bids = this.buildBomDraftData(bids, draftSelections);
        }
        return bids;
    }

    setSelectionsInfoFromDraft(bid: IBidSelections, draftSelections: IDraftSelection[]): void {
        bid.selections.forEach((selection) => {
            selection.isNewlyAdded = true;
            draftSelections.forEach((draftSelection) => {
                if (draftSelection.productFamilyId === selection.prodFamilyId && draftSelection.bidAlternateId === bid.bidAlternateId) {
                    selection.coordinationJobShipQuarter = draftSelection.shipQuarter;
                    selection.coordinationJobCompetitor = draftSelection.competitor;
                    selection.coordinationJobShipYear = draftSelection.shipYear;
                    selection.coordinationJobSpecifiedUser = draftSelection.specifiedUser;
                    selection.isNewlyAdded = false;
                }
            });
        });
    }

    updateShipTimeForNewSelections(bid: IBidSelections, draftSelections: IDraftSelection[]): void {
        bid.selections
            .filter((selection) => selection.isNewlyAdded)
            .forEach((selection) => {
                draftSelections.forEach((draftSelection) => {
                    if (draftSelection.productFamilyId === selection.prodFamilyId) {
                        selection.coordinationJobShipQuarter = draftSelection.shipQuarter;
                        selection.coordinationJobShipYear = draftSelection.shipYear;
                    }
                });
            });
    }

    buildBomDraftData(bids: IBidSelections[], draftSelections: IDraftSelection[]): IBidSelections[] {
        bids = bids.filter((bid) => {
            return draftSelections.some((bomBid) => bomBid.bidAlternateId === bid.bidAlternateId);
        });
        bids.forEach((bid) => {
            this.mapDraftSelectionsToBid(bid, draftSelections);
        });
        return bids;
    }

    mapDraftSelectionsToBid(bid: IBidSelections, draftSelections: IDraftSelection[]): void {
        bid.selections = draftSelections
            .filter((draftSelection) => draftSelection.bidAlternateId === bid.bidAlternateId)
            .map((draftSelection) => {
                return {
                    selectionIds: draftSelection.selectionIds,
                    description: draftSelection.description,
                    coordinationJobShipQuarter: draftSelection.shipQuarter,
                    coordinationJobShipYear: draftSelection.shipYear,
                    coordinationJobCompetitor: draftSelection.competitor,
                    coordinationJobSpecifiedUser: draftSelection.specifiedUser,
                    prodFamilyId: draftSelection.productFamilyId,
                    selectionSource: draftSelection.selectionSource,
                    doesSeparatelyBiddableSelectionsExist: draftSelection.doesSeparatelyBiddableSelectionsExist,
                } as ISelection;
            });
    }

    buildDocumentData(documents) {
        const documentKeys = this.coordinateDraftData.documents;
        documents.documentList.forEach((document) => {
            documentKeys.forEach((key) => {
                if (key.documentKey === document.documentKey) {
                    document.checked = true;
                }
            });
        });
    }

    buildBidData(bids) {
        const draftBidIds = this.coordinateDraftData.bidDetails.map((bidDetail) => {
            return bidDetail.bidAlternateId;
        });
        if (draftBidIds.length > 0 && this.coordinationStatus === this.coordinationStatusOptions.notSubmitted) {
            this.checkForDeletedBidsAndUpdateDraft(draftBidIds, bids);
        }
        bids.forEach((bid) => {
            bid.isBidInCoordinationJob = draftBidIds.includes(bid.bidAlternateId);
            if (!bid.isPricingValid || !bid.hasBidWithSelection || !bid.hasCompletePricing) {
                bid.isValid = false;
            } else {
                bid.isValid = true;
            }
       });
    }

    assignBidDiscountConfirmation(bids, generalJobData?) {
        generalJobData = generalJobData || {};
        const discountConfirmationDetails = generalJobData.discountConfirmationDetails || [];
        bids.forEach((bid) => {
            this.confirmDiscount(bid, 'N/A', 'not-applicable');
            const [discount] = discountConfirmationDetails.filter((detail) => {
                return detail.bidName === bid.bidName;
            });
            if (discount) {
                if (discount.isDiscountConfirmed) {
                    this.confirmDiscount(bid, 'YES', 'yes-icon');
                } else {
                    this.confirmDiscount(bid, 'NO', 'no-icon');
                }
            }
        });
    }

    confirmDiscount(bid, indicator, indicatorClass) {
        bid['discountIndicator'] = indicator;
        bid['discountIndicatorClass'] = indicatorClass;
    }

    checkForDeletedBidsAndUpdateDraft(draftBidIds: number[], originalBids: any[]) {
        const deletedBidIds = draftBidIds.filter((draftBidId) => {
            return !originalBids.some((bid) => bid.bidAlternateId === draftBidId);
        });
        if (deletedBidIds.length > 0) {
            this.updateDraftBids(deletedBidIds);
            this.updateDraftBom(deletedBidIds);
        }
    }

    updateDraftBids(deletedBidIds) {
        const updatedDraftBids = this.coordinateDraftData.bidDetails
            .filter((draftBid) => !deletedBidIds.includes(draftBid.bidAlternateId));
        const bidsPayload = this.buildPayload('bids', updatedDraftBids);
        this.coordinateService.saveCoordinateJobData(bidsPayload, this.drAddressId, this.jobId).subscribe((res) => {
        });
    }

    updateDraftBom(deletedBidIds) {
        const updatedDraftBom = this.coordinateDraftData.billOfMaterials
            .filter((draftBom) => !deletedBidIds.includes(draftBom.bidAlternateId));
        const bomPayload = this.buildPayload('billOfMaterials', updatedDraftBom);
        this.coordinateService.saveCoordinateJobData(bomPayload, this.drAddressId, this.jobId).subscribe((res) => {
        });
    }

    buildPayload(key, value) {
        const payload = {
            jobCoordinationViewModel: {
                jobId: this.jobId,
                drAddressId: this.drAddressId,
                coordinationId: this.coordinationId,
            },
        };
        payload.jobCoordinationViewModel[key] = value;
        return payload;
    }

    buildJobDetails(originalData: any) {
        const jobDetails: any = {};
        jobDetails.crmOpportunityId = originalData.crmOpportunityId;
        if (this.coordinationStatus === this.coordinationStatusOptions.notSubmitted) {
            jobDetails.requestedDate = this.coordinateDraftData.requestedDate;
            this.mapProperty(jobDetails, this.coordinateDraftData, originalData, 'quickTurnaroundIndicator');
            this.mapProperty(jobDetails, this.coordinateDraftData, originalData, 'icsJobIndicator');
            this.mapProperty(jobDetails, this.coordinateDraftData, originalData, 'jobContact');
            this.mapProperty(jobDetails, this.coordinateDraftData, originalData, 'commissionCode');
        } else {
            jobDetails.requestedDate = this.coordinateDraftData.requestedDate;
            jobDetails.quickTurnaroundIndicator = this.coordinateDraftData.quickTurnaroundIndicator;
            jobDetails.icsJobIndicator = this.coordinateDraftData.icsJobIndicator;
            jobDetails.jobContact = this.coordinateDraftData.jobContact;
            jobDetails.commissionCode = this.coordinateDraftData.commissionCode;
        }
        return jobDetails;
    }

    mapProperty(target, draft, original, prop) {
        target[prop] = (draft[prop] !== null) ? draft[prop] : original[prop];
    }
}
