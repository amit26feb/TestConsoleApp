import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { of } from 'rxjs';
import { AppConstants } from './../constants/constants';
import { JobCoordinationValidationService } from './job-coordination-validation.service';

// tslint:disable-next-line:no-big-function
describe('JobCoordinationValidationService', () => {
    let service: JobCoordinationValidationService;
    let injector: TestBed;
    let httpClient: HttpClient;
    let jobCoordinationValidationService: JobCoordinationValidationService;
    const testJobId = 123;
    const testDrAddressId = 141;
    const originReset = TestBed.resetTestingModule;
    let testJobDetailsValidationResponse;

    configureTestSuite(() => {
        TestBed.configureTestingModule({
            providers: [JobCoordinationValidationService, AppConstants],
            imports: [HttpClientTestingModule],
        });
    });

    beforeEach(() => {
        injector = getTestBed();
        service = injector.inject(JobCoordinationValidationService);
        jobCoordinationValidationService = TestBed.inject(JobCoordinationValidationService);
        httpClient = TestBed.inject(HttpClient);
        testJobDetailsValidationResponse = {
            hasBeenPreviouslyCoordinated: true,
            hasAnyEarthwiseSystems: false,
            hasAllDefinedClassifications: false,
            hasBidWithSelection: false,
            hasCompletePricing: false,
            isPricingValid: false,
        };
        service.setParams(testJobId, testDrAddressId);
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should fetch vaidation summary for job details when validateEarthwiseAndClassifications method is called', () => {
        spyOn(httpClient, 'get').and.returnValue(of(testJobDetailsValidationResponse));
        service.validateJobDetails(testJobId, testDrAddressId).subscribe((data) => {
            expect(data).toEqual(testJobDetailsValidationResponse);
        });
    });

    it('should set validations error count based on API response', fakeAsync(() => {
        spyOn(httpClient, 'get').and.returnValue(of(testJobDetailsValidationResponse));
        service.validateJobDetailsForCoordination();
        tick();
        expect(service.jobDetailsValidationSummary.validEarthwise)
            .toBe(testJobDetailsValidationResponse.hasAnyEarthwiseSystems);
        expect(service.jobDetailsValidationSummary.validClassifications)
            .toBe(testJobDetailsValidationResponse.hasAllDefinedClassifications);
        expect(service.jobDetailsValidationSummary.errorCount).toBe(2);
    }));

    it('should update the job details validation summary when response from API is changed', fakeAsync(() => {
        const validationSummary = {
            validEarthwise: false,
            validClassifications: true,
            validBid: true,
            errorCount: 1,
        };
        service.jobDetailsValidationSummary = validationSummary;
        spyOn(httpClient, 'get').and.returnValue(of(testJobDetailsValidationResponse));
        service.validateJobDetailsForCoordination();
        tick();
        const updatedValidationSummary = service.jobDetailsValidationSummary;
        expect(updatedValidationSummary).not.toBe(validationSummary);
    }));

    it('should not update the validations when validation result from API is not changed', fakeAsync(() => {
        const validationSummary = {
            validEarthwise: false,
            validClassifications: false,
            validBid: true,
            errorCount: 2,
        };
        service.jobDetailsValidationSummary = validationSummary;
        spyOn(httpClient, 'get').and.returnValue(of(testJobDetailsValidationResponse));
        service.validateJobDetailsForCoordination();
        tick();
        const updatedValidationSummary = service.jobDetailsValidationSummary;
        expect(updatedValidationSummary).toBe(validationSummary);

    }));

    it('should update the bid validation when the bid is previously coordinated', fakeAsync(() => {
        const validationResults = {
            hasBeenPreviouslyCoordinated: true,
            hasBidWithSelection: false,
            hasCompletePricing: false,
            isPricingValid: false,
            validEarthwise: true,
            validClassifications: true,
        };
        const validationSummary = {
            validEarthwise: false,
            validClassifications: false,
            validBid: false,
        };
        service.jobDetailsValidationSummary = validationSummary;
        spyOn(httpClient, 'get').and.returnValue(of(validationResults));
        service.validateJobDetailsForCoordination();
        tick();
        const updatedValidationSummary = service.jobDetailsValidationSummary;
        expect(updatedValidationSummary.validBid).toBe(true);
    }));

    it('should update the bid validation when the bid is valid', fakeAsync(() => {
        const validationResults = {
            hasBeenPreviouslyCoordinated: false,
            hasBidWithSelection: true,
            hasCompletePricing: true,
            isPricingValid: true,
            validEarthwise: true,
            validClassifications: true,
        };
        const validationSummary = {
            validEarthwise: false,
            validClassifications: false,
            validBid: false,
        };
        service.jobDetailsValidationSummary = validationSummary;
        spyOn(httpClient, 'get').and.returnValue(of(validationResults));
        service.validateJobDetailsForCoordination();
        tick();
        const updatedValidationSummary = service.jobDetailsValidationSummary;
        expect(updatedValidationSummary.validBid).toBe(true);
    }));

    it('should not update the bid validation when the bid is invalid and it is not previously coordinated', fakeAsync(() => {
        const validationResults = {
            hasBeenPreviouslyCoordinated: false,
            hasBidWithSelection: true,
            hasCompletePricing: true,
            isPricingValid: false,
            validEarthwise: true,
            validClassifications: true,
        };
        const validationSummary = {
            validEarthwise: false,
            validClassifications: false,
            validBid: false,
        };
        service.jobDetailsValidationSummary = validationSummary;
        spyOn(httpClient, 'get').and.returnValue(of(validationResults));
        service.validateJobDetailsForCoordination();
        tick();
        const updatedValidationSummary = service.jobDetailsValidationSummary;
        expect(updatedValidationSummary.validBid).not.toBe(true);
    }));
    it('should emit validation result to subscribers of JobDetailsValidationResults', () => {
        service.getJobDetailsValidationSummary().subscribe((validations) => {
            expect(validations.errorCount).toBe(2);
        });
        spyOn(httpClient, 'get').and.returnValue(of(testJobDetailsValidationResponse));
        service.validateJobDetailsForCoordination();
    });

    it('should unsubscribe from timer when service is destroyed', () => {
        service.ngOnDestroy();
        expect(service.jobDetailsValidationTimer.closed).toBe(true);
    });

    it('should create job details validation timer subscription when setParams is called', () => {
        service.jobDetailsValidationTimer = null;
        const spy = spyOn(service, 'validateJobDetailsForCoordination').and.callFake(() => { });
        service.setParams(testJobId, testDrAddressId);
        expect(spy).toHaveBeenCalled();
        expect(service.jobDetailsValidationTimer.closed).toBe(false);
        service.jobDetailsValidationTimer.unsubscribe();
        expect(service.jobDetailsValidationTimer.closed).toBe(true);
        service.setParams(testJobId, testDrAddressId);
        expect(service.jobDetailsValidationTimer.closed).toBe(false);
    });

    it('should emit jobLockedByMe error if validation error includes jobLockedByMe', () => {
        const spyEmitValidationError = spyOn(jobCoordinationValidationService.submitButtonValidationSubject, 'next');
        const sampleError: any = {
            isJobLockedByMe: false,
            isRequestedDateValid: true,
            isValidBidsSelection: true,
            isCoordinationStatusValid: true,
            isSubmissionNotesValid: true,
            hasNoActiveRequest: true,
        };
        service.submitButtonValidationFlags = sampleError;
        service.updateSubmitButtonValidationErrors();
        expect(spyEmitValidationError).toHaveBeenCalledWith(['isJobLockedByMe']);
    });

    it('should emit isCoordinationStatusValid error if validation error includes isCoordinationStatusValid', () => {
        const spyEmitValidationError = spyOn(jobCoordinationValidationService.submitButtonValidationSubject, 'next');
        const sampleError: any = {
            isJobLockedByMe: true,
            isRequestedDateValid: true,
            isValidBidsSelection: true,
            isCoordinationStatusValid: false,
            isSubmissionNotesValid: true,
            hasNoActiveRequest: true,
        };
        service.submitButtonValidationFlags = sampleError;
        service.updateSubmitButtonValidationErrors();
        expect(spyEmitValidationError).toHaveBeenCalledWith(['isCoordinationStatusValid']);
    });

    it('should emit other validation errors if jobLockedByMe and isCoordinationStatusValid are valid', () => {
        const spyEmitValidationError = spyOn(jobCoordinationValidationService.submitButtonValidationSubject, 'next');
        const sampleError: any = {
            isJobLockedByMe: true,
            isRequestedDateValid: false,
            isValidBidsSelection: false,
            isCoordinationStatusValid: true,
            hasNoActiveRequest: true,
        };
        service.submitButtonValidationFlags = sampleError;
        service.updateSubmitButtonValidationErrors();
        expect(spyEmitValidationError).toHaveBeenCalledWith(['isRequestedDateValid', 'isValidBidsSelection']);
    });

    it('should set the BOM date set flag and update the validation errors when setBomDateSetFlag is called', () => {
        service.submitButtonValidationFlags = {
            isJobLockedByMe: true,
            isCoordinationStatusValid: true,
            isBomDateSet: true,
            hasNoActiveRequest: true,
        } as any;
        const spy = spyOn(service, 'updateSubmitButtonValidationErrors');
        service.setBomDateSetFlag(false);
        expect(service.submitButtonValidationFlags.isBomDateSet).toBe(false);
        expect(spy).toHaveBeenCalled();
    });

    it('should set isJobReleasedFromCojo flag and update the validation errors when setJobReleasedFromCojo is called', () => {
        service.submitButtonValidationFlags = {
            isJobLockedByMe: true,
            isCoordinationStatusValid: true,
            isBomDateSet: true,
            isJobReleasedFromCojo: false,
        } as any;
        const spy = spyOn(service, 'updateSubmitButtonValidationErrors');
        service.setJobReleasedFromCojo(true);
        expect(service.submitButtonValidationFlags.isJobReleasedFromCojo).toBe(true);
        expect(spy).toHaveBeenCalled();
    });

    it('should set the BOM date valid flag and update the validation errors when setBomDateValidFlag is called', () => {
        service.submitButtonValidationFlags = {
            isJobLockedByMe: true,
            isCoordinationStatusValid: true,
            isBomDateValid: true,
            hasNoActiveRequest: true,
        } as any;
        const spy = spyOn(service, 'updateSubmitButtonValidationErrors');
        service.setBomDateValidFlag(false);
        expect(service.submitButtonValidationFlags.isBomDateValid).toBe(false);
        expect(spy).toHaveBeenCalled();
    });

    it('should set the ship lead time valid flag and update the validation errors when setValidShipLeadTimeFlag is called', () => {
        service.submitButtonValidationFlags = {
            isJobLockedByMe: true,
            isCoordinationStatusValid: true,
            isShipLeadTimeValid: true,
        } as any;
        const spy = spyOn(service, 'updateSubmitButtonValidationErrors');
        service.setValidShipLeadTimeFlag(false);
        expect(service.submitButtonValidationFlags.isShipLeadTimeValid).toBe(false);
        expect(spy).toHaveBeenCalled();
    });

    it('should set the coordinated flag when setHasBeenPreviouslyCoordinatedFlag is called', () => {
        service.setHasBeenPreviouslyCoordinatedFlag(false);
        expect(service.hasBeenPreviouslyCoordinated).toBe(false);
    });

    it('should get the coordinated flag when getHasBeenPreviouslyCoordinatedFlag is called', () => {
        service.hasBeenPreviouslyCoordinated = true;
        expect(service.getHasBeenPreviouslyCoordinatedFlag()).toBe(true);
    });

    it('should emit exceptions sections to subscribers of selectedExceptions on calling setSelectedException', () => {
        const sectionSpy = spyOn(jobCoordinationValidationService.selectedExceptionSubject, 'next');
        const section = 'bomDateNotValid';
        service.setSelectedException(section);
        expect(sectionSpy).toHaveBeenCalledWith(section);
    });
});
