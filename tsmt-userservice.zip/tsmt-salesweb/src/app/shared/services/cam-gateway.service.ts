import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConstants } from '../constants/constants';
import { ICamInput, ICamExecutionStatus } from '../model/cam-data-model';

@Injectable({
    providedIn: 'root',
})
export class CamGatewayService {
    constructor(private http: HttpClient, private appConstants: AppConstants) { }

    /**
     * Check if the context is allowed for locking and if so apply lock
     * @param camImput - Input required to perform cam lock
     */
    checkAndApplyLock(camImput: ICamInput): Observable<ICamExecutionStatus> {
        return this.http.post<ICamExecutionStatus>(
            `${this.appConstants.API_BASE_URL_CAMGATEWAY}/CamGateway/Locks`, camImput)
            .catch((error: HttpErrorResponse) => Observable.throwError(error));
    }

    /**
     * Check cam gateway status.
     * @param camImput - Input required to check cam gateway status
     * @returns ICamExecutionStatus - cam execution status
     */
    checkCamGatewayStatus(camImput: ICamInput): Observable<ICamExecutionStatus> {
        return this.http.post<ICamExecutionStatus>(
            `${this.appConstants.API_BASE_URL_CAMGATEWAY}/CamGateway/Check`, camImput)
            .catch((error: HttpErrorResponse) => Observable.throwError(error));
    }
}
