import { getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { IWorkPackageBaseModel } from '../model/work-package-base-model';
import { WorkPackageCommonService } from './work-package-common.service';

describe('WorkPackageCommonService', () => {
    let injector: TestBed;
    let service: WorkPackageCommonService;
    const originReset = TestBed.resetTestingModule;
    configureTestSuite(() => {
        TestBed.configureTestingModule({
            providers: [
                WorkPackageCommonService,
            ],
        });

        injector = getTestBed();
        service = injector.inject(WorkPackageCommonService);
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should set the work package base properties on setWorkPackageBaseProperties', () => {
        const param: IWorkPackageBaseModel = {
            workPackageName: 'Test',
            workPackageId: 23,
            crmOpportunityId: '11',
            revenueStreamType: 'SRV',
            salesStage: 'Propose',
            salesOfficeId: 322,
            revenueStreamName: 'Services',
            siteId: 6,
        };
        service.setWorkPackageBaseProperties(param);
        expect(service.getWorkPackageBaseProperties().workPackageName).toBe('Test');
        expect(service.getWorkPackageBaseProperties().workPackageId).toBe(23);
        expect(service.getWorkPackageBaseProperties().crmOpportunityId).toBe('11');
        expect(service.getWorkPackageBaseProperties().revenueStreamType).toBe('SRV');
    });

    it('should set selectedPropertyName to test on setPropertySectionName', () => {
        const param = 'test';
        service.setPropertySectionName(param);
        expect(service.getPropertySectionName()).toBe('test');
    });

    it('should set labor editCostItemValue on setEditCostItemValue', () => {
        const editLaborCostItem = {
            laborItemId: 355,
            containerType: 'LABOR',
            containerId: 5333,
        };
        service.setEditCostItemValue(editLaborCostItem);
        expect(service.getEditCostItemValue().laborItemId).toBe(355);
        expect(service.getEditCostItemValue().containerType).toBe('LABOR');
        expect(service.getEditCostItemValue().containerId).toBe(5333);
    });
});
