import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { WorkflowPopupService } from './workflow-popup.service';

describe('WorkflowPopupService', () => {
  let service: WorkflowPopupService;
  let http: HttpClient;
  let injector: TestBed;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        WorkflowPopupService,
      ],
      imports: [HttpClientTestingModule],
    }),
      injector = getTestBed();
  });

  beforeEach(() => {
    service = injector.inject(WorkflowPopupService);
    http = injector.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set flag and emit flag to event emitter', () => {
    const workflowPopupSpy = spyOn(service.workflowPopup, 'next');
    service.workflowPopupClickEventHandler();
    expect(workflowPopupSpy).toHaveBeenCalledWith(true);
  });

});
