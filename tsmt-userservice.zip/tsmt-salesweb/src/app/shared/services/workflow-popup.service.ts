import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class WorkflowPopupService {
  workflowPopup = new BehaviorSubject(false);
  constructor() { }
  // Emit click event to workflow popup component
  workflowPopupClickEventHandler() {
    this.workflowPopup.next(true);
  }
}
