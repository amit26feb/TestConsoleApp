import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { ILoginService } from '../model/login-service';
@Injectable()
export class TokenServiceCI implements ILoginService {

    constructor(private cookieService: CookieService) { }

    //  setter for JWT token
    setauthenticationToken(value: string): void {
        this.cookieService.set('auth', value);
    }

    // getter for JWT token
    getauthenticationToken() {
        return this.cookieService.get('auth');

    }
}
