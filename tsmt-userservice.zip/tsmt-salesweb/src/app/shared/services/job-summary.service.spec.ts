import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { BidsService } from '../../modules/jobs-list-master/services/bids.service';
import { JobsServicesService } from '../../modules/jobs-list-master/services/jobs-services.service';
import { SalesCustomerService } from '../../modules/jobs-list-master/services/sales-customer.service';
import { SelectionService } from '../../modules/jobs-list-master/services/selection.service';
import { AppConstants } from './../../shared/constants/constants';
import { LoaderService } from './../../shared/services/loader.service';

import { Observable } from 'rxjs';
import { JobSummaryService } from './job-summary.service';

describe('JobSummaryService', () => {
  let jobSummaryService: JobSummaryService;
  let salesCustomerService: SalesCustomerService;
  let selectionService: SelectionService;
  let bidsService: BidsService;
  let jobService: JobsServicesService;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [JobSummaryService, AppConstants,
        SalesCustomerService, LoaderService, SelectionService, BidsService, JobsServicesService],
    });
    jobSummaryService = TestBed.inject(JobSummaryService);
    salesCustomerService = TestBed.inject(SalesCustomerService);
    selectionService = TestBed.inject(SelectionService);
    bidsService = TestBed.inject(BidsService);
    jobService = TestBed.inject(JobsServicesService);
  });

  it('should be created', () => {
    expect(jobSummaryService).toBeTruthy();
  });

  it('should call service methods on calling fetchSummaryData', () => {
    const salesCustomerSpy = spyOn(salesCustomerService, 'getAssignCustomers').and.returnValue(Observable.of([]));
    const selectionServiceSpy = spyOn(selectionService, 'getNonTraneData').and.returnValue(Observable.of([]));
    const selectionListDataSpy = spyOn(selectionService, 'getSelectionListData').and.returnValue(Observable.of([]));
    const bidListSpy = spyOn(bidsService, 'getBidsList').and.returnValue(Observable.of([]));
    const jobServiceSpy = spyOn(jobService, 'getDocumentList').and.returnValue(Observable.of([]));
    const jobBasicInfoSpy = spyOn(jobService, 'fetchJobDetails').and.returnValue(Observable.of([]));
    jobSummaryService.fetchSummaryData(10, 200);
    expect(salesCustomerSpy).toHaveBeenCalled();
    expect(selectionServiceSpy).toHaveBeenCalled();
    expect(bidListSpy).toHaveBeenCalled();
    expect(jobServiceSpy).toHaveBeenCalled();
    expect(selectionListDataSpy).toHaveBeenCalled();
    expect(jobBasicInfoSpy).toHaveBeenCalled();
  });

  it('should return undefined when service returns error on calling fetchSummaryData', () => {
    spyOn(salesCustomerService, 'getAssignCustomers').and.returnValue(Observable.throwError({ status: 409 }));
    spyOn(selectionService, 'getNonTraneData').and.returnValue(Observable.of([10]));
    spyOn(selectionService, 'getSelectionListData').and.returnValue(Observable.of([]));
    spyOn(bidsService, 'getBidsList').and.returnValue(Observable.of([]));
    spyOn(jobService, 'getDocumentList').and.returnValue(Observable.of([]));
    spyOn(jobService, 'fetchJobDetails').and.returnValue(Observable.throwError({ status: 500 }));
    jobSummaryService.fetchSummaryData(10, 200);
    expect(jobSummaryService.jobSummaryData[0]).toBeUndefined();
    expect(jobSummaryService.jobSummaryData[1][0]).toEqual(10);
    expect(jobSummaryService.jobSummaryData[5]).toBeUndefined();
  });
});
