import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Subject } from 'rxjs';
import { IApiErrorState } from '../model/apierror-state';
import { ApiErrorService } from './apierror.service';

describe('ApiErrorService', () => {
  const apiErrorSubject = new Subject<IApiErrorState>();
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [ApiErrorService],
    });
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([ApiErrorService], (service: ApiErrorService) => {
    expect(service).toBeTruthy();
  }));

  it('should be call on Show for apierrormessage', inject([ApiErrorService], (service: ApiErrorService) => {
    service.show('Invalid Request');
    expect(apiErrorSubject).toBeTruthy();
  }));

  it('should be call on Hide for apierrormessage', inject([ApiErrorService], (service: ApiErrorService) => {
    service.hide();
    const apiErrorResult = { show: false, errorMessage: '' } as IApiErrorState;
    expect(apiErrorSubject).toBeTruthy(apiErrorResult);
  }));
});
