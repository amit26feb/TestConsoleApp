import { async, ComponentFixture, getTestBed, inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { GridFiltersService } from './grid-filters.service';

describe('GridFiltersService', () => {
    let injector: TestBed;
    let service: GridFiltersService;
    const statusClosed = 'Closed';
    const originReset = TestBed.resetTestingModule;

    configureTestSuite(() => {
        TestBed.configureTestingModule({
            providers: [GridFiltersService],
        });
    });


    beforeEach(() => {
        injector = getTestBed();
        service = injector.inject(GridFiltersService);
        service.dateColumns = ['lastUpdate', 'bidDate', 'reviseDate'];
        service.multiselectColumns = ['status', 'custChannelId'];
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should call multiselect filter method to return an updated array', () => {
        const obj = { field: 'status', operator: 'Eq', value: [{ text: 'Open', status: 'Open' }] };
        const field = 'status';
        const filter = service.multiSelectFilter(obj, field);
        expect(filter[0].value).toBe('Open');
    });


    it(`should modify the filter object on call of modifyFilterObj`, () => {
        const filter = [{
            field: 'lastUpdate', operator: 'gte', value: '03/19/2019',
        },
        ];

        expect(service.modifyFilterObj(filter)).toEqual([{
            columnFilters:
                [{ field: 'lastUpdate', operator: 'gte', value: '03/19/2019' }], logic: 'and',
        },
        ]);
    });

    it(`should modify the filter object with non date column on call of modifyFilterObj`, () => {
        const filter = [{
            field: 'drAddressId', operator: 'eq', value: '121',
        },
        ];

        expect(service.modifyFilterObj(filter, 'filters')).toEqual([{
            filters:
                [{ field: 'drAddressId', operator: 'eq', value: '121' }], logic: 'and',
        },
        ]);
    });

    it(`should modify the multiselectfilter with filter object on call of modifyFilterObj`, () => {
        const filter = [{
            filters: [{
                field: 'status', operator: 'contains', value: [{
                    text: statusClosed,
                    status: statusClosed,
                }],
            }], logic: 'or',
        },
        ];

        expect(service.modifyFilterObj(filter)).toEqual([{
            columnFilters: [{ field: 'status', operator: 'contains', value: statusClosed }], logic: 'or',
        },
        ]);
    });

    it(`should modify the multiselectfilter with filter object on call of modifyFilterObj`, () => {
        const filter = [{
            field: 'custChannelId', operator: 'Eq', value: [{ text: '$USD', custChannelId: 'COMMSALE' }],
        },
        {
            filters: [{ field: 'lastUpdate', operator: 'gte', value: '05/19/2019' }], logic: 'and',
        },
        {
            filters: [{ field: 'bidDate', operator: 'gte', value: '02/19/2019' },
            { field: 'bidDate', operator: 'gte', value: '02/18/2019' }], logic: 'and',
        },
        ];

        expect(service.modifyFilterObj(filter)).toEqual([{
            columnFilters: [{ field: 'custChannelId', operator: 'Eq', value: 'COMMSALE' }], logic: 'or',
        },
        { columnFilters: [{ field: 'lastUpdate', operator: 'gte', value: '05/19/2019' }], logic: 'and' },
        {
            columnFilters: [{ field: 'bidDate', operator: 'gte', value: '02/19/2019' },
            { field: 'bidDate', operator: 'gte', value: '02/18/2019' }], logic: 'and',
        },
        ]);
    });

    it(`should modify the filter object and return with formatted date value on call of modifyFilterObj`, () => {
        const filter = [{
            filters: [{
                field: 'reviseDate', operator: 'eq', value: '06/12/2019',
            }], logic: 'and',
        },
        ];

        const formattedDate = [{
            filters: [{
                field: 'reviseDate', operator: 'eq', value: '06/12/2019',
            }], logic: 'and',
        },
        ];

        expect(service.modifyFilterObj(filter, 'filters')).toEqual(formattedDate);
    });
});

