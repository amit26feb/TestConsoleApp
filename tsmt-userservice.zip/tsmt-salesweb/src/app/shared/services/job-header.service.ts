import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable()
export class JobHeaderService {

  private source = new BehaviorSubject('');
  detailsMenuClick = new Subject();
  message = this.source.asObservable();
  public userIdSubject = new Subject();
  public showProjectsNavigation = new BehaviorSubject<boolean>(false);
  public isNotificationPanelOpen = new BehaviorSubject(false);
  public isWorkflowPanelOpen = new BehaviorSubject(false);
  public showWorkPackageNavigation = new BehaviorSubject<boolean>(false);
  public showPreValidation = new BehaviorSubject<boolean>(false);
  public jobUpdateFromGeneralForm = new BehaviorSubject<number>(0);
  public invokeCalculationStatusValidation = new BehaviorSubject<boolean>(false);
  public isBackgroundCalculationActive = new BehaviorSubject<boolean>(false);
  private userId: string;
  private userName: string;
  private detailsMenuItems: any[];
  private fullName: string;
  private detailsPageStatus: any;
  private importJobPageOpenStatus: boolean;
  private workPackageVersion: any;
  private navigateFromUrl: string;
  public jobId: number;
  constructor() { }

  setJob(jobId: number, drAddressId: number) {
    this.source.next(jobId + '/' + drAddressId);
  }

  clearJob() {
    this.source.next('');
  }


  setDetailsMenuClick(item) {
    this.detailsMenuClick.next(item);
  }


  setUserId(userId) {
    this.userId = userId?.toLowerCase();
    this.userIdSubject.next(userId);
  }

  setUserName(userName) {
    this.userName = userName;
  }

  getUserId() {
    return this.userId;
  }

  getUserName() {
    return this.userName;
  }

  setDetailsMenuItems(list) {
    this.detailsMenuItems = list;
  }

  getDetailsMenuItems() {
    return this.detailsMenuItems;
  }

  setFullName(fullName) {
    this.fullName = fullName;
  }

  getFullName() {
    return this.fullName;
  }

  setDetailsPageValidationStatus(formArray) {
    this.detailsPageStatus = formArray;
  }

  getDetailsPageValidationStatus() {
    return this.detailsPageStatus;
  }

  setImportJobOpenStatus(pageOpenStatus) {
    this.importJobPageOpenStatus = pageOpenStatus;
  }

  getImportJobOpenStatus() {
    return this.importJobPageOpenStatus;
  }

  setWorkPackageVersion(version) {
    this.workPackageVersion = version;
  }

  getWorkPackageVersion() {
    return this.workPackageVersion;
  }

  setNavigateFromUrl(url) {
    this.navigateFromUrl = url;
  }

  getNavigateFromUrl() {
    return this.navigateFromUrl;
  }

  /**
   * Method sets the job id when user updates the job in general section
   * @param jobId
   */
  setJobId(jobId): void {
    this.jobId = jobId;
  }

  /**
   * Method returns the job id
   * @returns jobId
   */
  getJodId(): number {
    return this.jobId;
  }
}
