import { inject, TestBed } from '@angular/core/testing';
import { Route, UrlSegment } from '@angular/router';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { DevEnvGuard } from './dev-env.guard';

describe('DevEnvGuard', () => {
  const r: Route = {};
  const segments: UrlSegment[] = [];
  const originReset = TestBed.resetTestingModule;
  configureTestSuite((() => {
    TestBed.configureTestingModule({
      providers: [DevEnvGuard],
    });
  }));

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('DevEnvGuard Should Exists', inject([DevEnvGuard], (guard: DevEnvGuard) => {
    expect(guard).toBeTruthy();
  }));

  it('should load module', inject([DevEnvGuard], (guard: DevEnvGuard) => {
    const mod = guard.canLoad(r, segments);
    expect(mod).toBe(true);
  }));
});
