import { AbstractControl } from '@angular/forms';

/*
 * dollarValueValidation is a custom validator to check if value of dollar field is greater than zero
 * @param control - FormControl to which validator is set
 * @returns error if validation fails and null if validation passes
 */
export function dollarValueValidation(control: AbstractControl): { [key: string]: boolean } | null {
    if (control.value === 0 || control.value?.length > 0) {
        const unFormattedValue = control.value.toString().replace(/[$,]/g, '');
        if (control.value === '$0.00' || unFormattedValue <= 0) {
            return { dollarValueInvalid: true };
        }
    }
    return null;
}

/*
 * dollarCustomValidation is a generic function to allow or restrict user input based on conditions like pattern, special keys etc
 * @param control - FormControl to which validator is set
 * @returns booloean - true if condition fails and false if condition passes
 */
export function dollarCustomValidation(pattern: RegExp, event: KeyboardEvent, digitLimit = 9): boolean | any {
    const previousValue = (event.target as HTMLInputElement).value;
    const index = (event.target as HTMLInputElement).selectionStart;
    const specialKeys: string[] = ['ArrowLeft', 'ArrowRight', 'Home', 'End', 'Backspace', 'Delete', 'Enter', 'Tab', 'Control'];

    if (specialKeys.indexOf(event.key) !== -1 || (event.ctrlKey && event.key === 'a')) {
        return false;
    }

    if ((!pattern.test(event.key)) || (pattern.test(event.key) && previousValue.indexOf('.') !== -1 && event.key === '.')) {
        event.preventDefault();
        return true;
    } else {
        const currentValue = previousValue.substring(0, index) + event.key + previousValue.substring(index);
        const unFormattedValue = (currentValue).replace(/[\$,]/g, '');
        const maxValue = unFormattedValue.split('.');
        if ((maxValue[0].length > digitLimit) || (maxValue[1] && maxValue[1].length > 2)) {
            event.preventDefault();
        }
        return false;
    }
}
