import { FormGroup } from '@angular/forms';

/*
 * shouldShowErrorsMaster is a generic function which is called from many different modules.
 * Returns a boolean determined by logic which decides if an error should appear or not.
 * Parameters
 *  @form: FormGroup. The form from the calling module. Need to grab the control properties of off this form
 *  @controlName: string. The control name whose properties we want to examine. This is used to index the form to the correct control.
 *  @isSubmitted: boolean. The value of the module executing this.submitted
 *
 */
export function shouldShowErrorsMaster(form: FormGroup, controlName: string, isSubmitted: boolean) {
    // Want the value's of these three form control properties.
    const isErrorsObj = form.controls[controlName].errors;
    const isTouched = form.controls[controlName].touched;
    const isDirty = form.controls[controlName].dirty;

    // isErrorsObj is of type ValidationErrors. Want this to be a boolean instead
    let isErrors = true;
    if (isErrorsObj == null) {
        isErrors = false;
    }

    // The logic if an error should be returned
    return isErrors && (isTouched || isDirty || isSubmitted);
}
