export enum DisplayModeEnum {
    History = 'History',
    Transmitted = 'Transmitted',
    Untransmitted = 'Untransmitted'
}
