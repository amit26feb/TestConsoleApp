import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { ToasterMock } from './toasterservice-mock';

describe('ToasterService', () => {
    let service: ToasterMock;
    configureTestSuite(() => {
        TestBed.configureTestingModule({
            providers: [ToasterMock],
        });

        service = TestBed.inject(ToasterMock);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should emit success mesasge and status', () => {
        spyOn(service.status, 'emit');
        service.setToaster('success', 'msg');
        expect(service.status.emit).toHaveBeenCalled();
    });

    it('should emit toaster status', () => {
        spyOn(service.status, 'emit');
        service.setToaster('success', 'msg');
        service.getToasterStatus();
        expect(service.msg).toBeDefined();
    });

    it('should emit toaster msg', () => {
        spyOn(service.status, 'emit');
        service.setToaster('success', 'msg');
        service.getToasterMsg();
        expect(service.status).toBeDefined();
    });

});
