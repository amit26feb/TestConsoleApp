import 'rxjs/add/observable/of';
import { Observable } from 'rxjs';
import { IClassification, IEarthwiseSystem, IProgram, IRevenueStream } from './../../modules/jobs-list-master/models/create-crm.model';
import { ISalesOfficeModel } from '../model/sales-office-model';
export class TraneSalesBusinessDataServiceMock {
  getSalesOffices() {
    return Observable.of([{
      sales_office_id: 925,
      code: 'AD',
      sales_office_name: '2 J Supply',
      sales_district: '844',
      sales_office_id_parent: null,
      country: 'USA',
    },
    {
      sales_office_id: 515,
      code: 'AE',
      sales_office_name: 'A C Supply Inc',
      sales_district: '844',
      sales_office_id_parent: null,
      country: 'USA',
    },
    {
      sales_office_id: 442,
      code: 'AF',
      sales_office_name: 'AFRICA',
      sales_district: '144',
      sales_office_id_parent: 357,
      country: 'USA',
    },
    {
      sales_office_id: 4205,
      code: 'AX',
      sales_office_name: 'Ottawa Parts Supply',
      sales_district: '119',
      sales_office_id_parent: 133,
      country: 'CAN',
    },
    {
      sales_office_id: 376,
      code: 'AY',
      sales_office_name: 'Ottawa East Parts Supply - OLD',
      sales_district: '119',
      sales_office_id_parent: 133,
      country: 'CAN',
    },
    {
      sales_office_id: 157,
      code: 'AZ',
      sales_office_name: 'Ottawa',
      sales_district: '119',
      sales_office_id_parent: 133,
      country: 'CAN',
    },
    ]);
  }
  getSalesOffice(salesId) {
    return Observable.of([
      {
        id: 1116,
        code: 'AC',
        name: 'Aiken',
        address1: '3635 Whiskey Road',
        address2: null,
        city: 'AIKEN',
        state: 'SC',
        province: null,
        zip: 29803,
        zipPlus: null,
        country: 'USA',
        phone: '803-648-1564',
        fax: '803-648-1769',
      },
    ]);
  }
  getSalesOfficeByDrAddressId(drAddressId) {
    return Observable.of([
      {
        id: 1117,
        code: 'AX',
        name: 'Dasdasf',
        address1: '3600 State St',
        address2: null,
        city: 'La Crosse',
        state: 'WI',
        province: null,
        zip: 54601,
        zipPlus: null,
        country: 'USA',
      },
    ]);
  }
  getCommissionCodes() {
    return Observable.of([
      {
        salesOfficeId: 442,
        name: 'Todd Warvel',
        commCode: 'A00',
        commCodeDisplay: 'Todd Warvel[A00]',
      },
    ]);
  }
  getJobContacts() {
    return Observable.of([
      {
        userId: 'fefzh',
        UserName: 'Camacho, Rich(A00)',
      },
      {
        userId: 'lamsp',
        UserName: 'Christianson, Jaimie',
      },
      {
        userId: 'ccaabk',
        UserName: 'Chisolm, Nate(A00)',
      },
      {
        userId: 'fehhy',
        UserName: 'Chuck, Foster(A00)',
      },
      {
        userId: 'ccbyvb',
        UserName: 'Hartman, Ernest(A00)',
      },
      {
        userId: 'fegik',
        UserName: 'Hawkins, Amanda(A00)',
      },
    ]);
  }

  getDomainList(arrListType) {
    return Observable.of([
      {
        listType: 'cojob_status',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'billing_frequency',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'cojo',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'contract_type',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'invoice_print_option',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'invoice_style_option',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'job phase',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'quality spec',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
      {
        listType: 'est_confidence',
        codeValue: '',
        displayValue: '',
        activeInd: 'Y',
        displayOrder: null,
      },
    ]);
  }

  getCompetitors(drAddressId) {
    return Observable.of([
      {
        CompetitorId: 38,
        CompetitorName: 'AAON Inc',
        CrmCompanyId: 27,
        CompetitorStatus: 'C',
      },
      {
        CompetitorId: 116,
        CompetitorName: 'AC Systems',
        CrmCompanyId: 198087,
        CompetitorStatus: 'C',
      },
      {
        CompetitorId: 110,
        CompetitorName: 'AIR ENTERPRISES LLC',
        CrmCompanyId: 487498,
        CompetitorStatus: 'C',
      },
      {
        CompetitorId: 55,
        CompetitorName: 'AMERESCO',
        CrmCompanyId: 249234,
        CompetitorStatus: 'C',
      },
      {
        CompetitorId: 123,
        CompetitorName: 'Aces',
        CrmCompanyId: 372084,
        CompetitorStatus: 'C',
      },
      {
        CompetitorId: 26,
        CompetitorName: 'Air Therm',
        CrmCompanyId: null,
        CompetitorStatus: 'C',
      },

    ]);
  }

  getAllSalesOffices() {
    return Observable.of([
      {
        country: null,
        crmIntegrationInd: 'N',
        drAddressId: 78,
        salesDistrict: '40',
        salesOfficeId: 78,
        salesOfficeIdParent: 74,
        salesOfficeName: 'Akron Canton',
      },
      {
        country: null,
        crmIntegrationInd: 'N',
        drAddressId: 167,
        salesDistrict: null,
        salesOfficeId: -3,
        salesOfficeIdParent: 0,
        salesOfficeName: '<Business Unit> LOUISVILLE BU',
      },
    ]);
  }
  getAllSalesOfficesIncludingChildren(): Observable<ISalesOfficeModel[]> {
    return Observable.of([
      {
        salesOfficeId: 1135,
        salesOfficeName: 'Savannah',
      },
      {
        salesOfficeId: 39,
        salesOfficeName: 'Augusta',
      },
      {
        salesOfficeId: 38,
        salesOfficeName: 'Atlanta',
      },
    ]);
  }
  getProviders() {
    return Observable.of([
      {
        vendorId: 167,
        vendorName: 'Camacho, Rich',
        status: 'C',
      },
      {
        vendorId: 5,
        vendorName: 'Others',
        status: 'C',
      },
    ]);
  }
  getEquipments() {
    return Observable.of([
      {
        productId: 73,
        productName: 'Modular chiller plants',
        status: 'C',
        vendorId: 60,
      },
      {
        productId: 76,
        productName: 'Pumping Packages',
        status: 'C',
        vendorId: 60,
      },
    ]);
  }
  getClassifications(): Observable<IClassification[]> {
    return Observable.of([{
      jobClassId: 1,
      description: 'test classification',
      codes: [
        {
          jobCodeId: 1,
          description: 'test description',
        },
      ],
    },
    {
      jobClassId: 7,
      description: 'Vertical Market',
      codes: [
        {
          jobCodeId: 1,
          description: 'Service',
        },
      ],
    }] as unknown as IClassification[]);
  }
  getEarthwiseSystems(): Observable<IEarthwiseSystem[]> {
    return Observable.of([
      {
        systemTypeId: 1,
        description: 'No System',
        toolTip: 'test',
      }] as unknown as IEarthwiseSystem[]);
  }
  getPrograms(): Observable<IProgram[]> {
    return Observable.of([
      {
        programCode: 'CLTC',
        programDescription: 'Critical to Close',
      }] as IProgram[]);
  }
  getRevenueStream(): Observable<IRevenueStream[]> {
    return Observable.of([
      {
        revenueStreamFieldValue: 'CSNG',
        description: 'Contracting - CS No Guarantee',
      },
      {
        revenueStreamFieldValue: 'APNC',
        description: 'System - Applied no Control',
      },
      {
        revenueStreamFieldValue: 'SESH',
        description: 'Service - Controls Scheduled',
      }] as IRevenueStream[]);
  }
}
