import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { IOfficeSelectorModel } from '../model/office-selector-model';

@Injectable({
  providedIn: 'root',
})
export class FilterServiceMock {
  public selectedOffice$ = new Subject<IOfficeSelectorModel>();
  public selectedOffice: IOfficeSelectorModel;
  public officeSelectorList$ = new Subject<IOfficeSelectorModel[]>();
  public officeSelectorList: IOfficeSelectorModel[];
  public officeSelected: IOfficeSelectorModel;

  constructor() {
    this.officeSelected = {
      salesOfficeName: 'Billings',
      drAddressId: 121,
      country: 'USA',
      crmIntegrationInd: 'Y',
      homeDrAddressId: 0,
      buInd: 'Y',
    } as IOfficeSelectorModel;
    this.officeSelectorList = [this.officeSelected];
  }


  // it sets the selectedOffice$ with the new selected office
  setSelectedOffice(selectedOffice: IOfficeSelectorModel) {
    this.selectedOffice$.next(this.officeSelected);
  }

  // it  sets the officeSelectorList$ with the office list
  setOfficeSelectorList(officeList: IOfficeSelectorModel[]) {
    this.officeSelectorList$.next(this.officeSelectorList);
  }

  // returns the selectedOffice$ Subject for other components to subscribe to its changes
  getSelectedOffice() {
    return this.selectedOffice$;
  }

  // returns the officeSelectorList$ Subject for other components to subscribe to its changes
  getOfficeSelectorList() {
    return this.officeSelectorList$;
  }

}
