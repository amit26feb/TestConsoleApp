import { Observable, ReplaySubject } from 'rxjs';

export class GlobalSearchServiceMock {
  public fetchedData = new ReplaySubject<any>(1);
  public searchValue = new ReplaySubject<string>(1);
  public gridlist = [{
    drAddressId: 105,
    workPackageName: 'Sacred Heart - Tomahawk - Boiler Modulation Contro!',
    bidDate: '2009-11-02T00:00:00',
    workPackageId: 626,
    workPackagePrice: 2279.4,
    salesEngineer: 'Tom Schafer [D31]',
  },
  {
    drAddressId: 105,
    workPackageName: 'Sacred Heart - Tomahawk - Boiler Modulation Contro',
    bidDate: '2009-12-02T00:00:00',
    workPackageId: 627,
    workPackagePrice: 2279.4,
    salesEngineer: 'Tom Schafer [D30]',
  },
  {
    drAddressId: 105,
    workPackageName: 'Sacred Heart - Tomahawk - Boiler Modulation Contro',
    bidDate: '2009-10-02T00:00:00',
    workPackageId: 526,
    workPackagePrice: 2279.4,
    salesEngineer: 'Tom Schafer [D30]',
  }];
  public searchText: string;

  constructor() {
    this.searchText = 'test';
  }

  searchList(searchText: string, tabName: string, drAddressId: number) {
    // sets the search value
    this.searchValue.next(this.searchText);
    this.fetchList().subscribe((data) => {
      // sets the searched data
      this.fetchedData.next(this.gridlist);
    });
  }

  downloadPDF(documentKey: string): Observable<{ file: Blob }> {
    return Observable.of({ file: new Blob([]) });
  }

  fetchList(): Observable<any> {
    return Observable.of(this.gridlist);
  }
}
