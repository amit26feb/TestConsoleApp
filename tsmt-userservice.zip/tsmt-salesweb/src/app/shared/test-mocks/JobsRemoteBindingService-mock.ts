
import { BehaviorSubject } from 'rxjs';

const invalidDate = '0001-01-01T00:00:00';

const gridData = [{ bidDate: invalidDate, lastUpdate: invalidDate, dateCreated: invalidDate, jobContactName: null, crmOpportunityId: null },
      { bidDate: '08/04/2019', lastUpdate: '04/04/2019', dateCreated: '01/01/2009', jobContactName: 'test', crmOpportunityId: 'test' },
      { bidDate: '12/04/2019', lastUpdate: '10/04/2019', dateCreated: '01/01/2009', jobContactName: null, crmOpportunityId: null  }];


export class JobsRemoteBindingServiceMock extends BehaviorSubject<any> {
  public sortParameter = new BehaviorSubject<any>([{ field: '', dir: '' }]);
  public sortParameterValue$ = this.sortParameter.asObservable();
  constructor() {
    super({
      data: gridData , total: 1000,
    });
  }

  public query(state: any) {
    super.next({
      data: gridData, total: 1000,
    });
  }



}
