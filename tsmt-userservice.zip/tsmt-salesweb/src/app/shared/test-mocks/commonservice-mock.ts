import 'rxjs/add/observable/of';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AppConstants } from '../../shared/constants/constants';
import { IActiveDirectory, IFilterConditions } from '../../modules/jobs-list-master/models/user-model';
import { CarouselProjectDetailsModel } from '../model/bids-model';
import { DisplayModeEnum } from '../enums/display-mode-enum';
export class CommonServiceMock {

  activeCC = [];
  headerTitle = 'xyz';
  filterValue = [];
  autocompleteList = [];
  carouselActiveSlideIndex = new BehaviorSubject<number>(0);
  projectCarouselActiveIndex: number;
  activeToggleState = new BehaviorSubject('');
  currentToggle: string;
  apiBaseUrl: string;
  appconstants: AppConstants;
  startPreValidation = new BehaviorSubject<boolean>(false);
  exitPreValidation = true;
  callValidation = new BehaviorSubject<boolean>(false);
  refreshErrorsAndWarningPanel = new BehaviorSubject<boolean>(false);
  isValidationMesssageDeletionCompleted = new BehaviorSubject<boolean>(false);
  savedProjectDetails = new Subject<CarouselProjectDetailsModel>();
  isUserHasOnlyCommissionSplitAccess = new BehaviorSubject<boolean>(false);

  getBidsList(drAddressId, jobId) {
    return Observable.of([
      {
        bidAlternateId: 186418,
        currentBidInd: 'Y',
        bidName: 'Base Bid',
        description: null,
        creditJobNumber: 'T133458',
        purchaseOrderNumber: 'FRE1007319',
        spaNumber: null,
        sellingPrice: 290,
        baseBidYesNo: 1,
        hqtrBidAlternateId: 3602051,
        hqtrCreditJobId: null,
        foe2CreatedOrdersInd: 'Y',
        isIncludeInCoordinatedJob: true,
        creditJobId: 2094617,
      },
    ]);
  }

  setCarouselActiveIndex(activeSlide: number): void {
    this.projectCarouselActiveIndex = activeSlide;
    this.carouselActiveSlideIndex.next(activeSlide);
  }

  setSelectedToggle(selectedToggle: string): void {
    this.activeToggleState.next(selectedToggle);
    this.currentToggle = selectedToggle;
  }

  triggerPreValidation(startPreValidation: boolean): void {
    this.startPreValidation.next(startPreValidation);
  }

  /**
   * Gets the api base url according to the display mode selected
   * @param {displayMode} - the display mode selected
   * @param {drAddressId} - dr address id
   * @returns string - api base url
   */
  getBaseUrl(displayMode: string, drAddressId: number = 0): string {
    if (displayMode?.toLowerCase() === this.appconstants.ShippingHistoryDisplayMode) {
      return `${this.appconstants.API_BASE_URL_SHIPPING_HISTORY}`;
    } else if (displayMode?.toLowerCase() === DisplayModeEnum.History) {
      return this.appconstants.API_BASE_URL_ORDER_HISTORY;
    } else if (displayMode?.toLowerCase() === DisplayModeEnum.Untransmitted) {
      return `${this.appconstants.API_BASE_URL_ORDER}/${drAddressId}`;
    } else {
      this.apiBaseUrl = this.appconstants.API_BASE_URL_CREDIT_JOBS;
    }
    return this.apiBaseUrl;
  }

  /**
   * Gets the user details based on filter condtions from azure active directory
   * @param {IFilterConditions} filterConditions - the filter condtions
   * @returns {IActiveDirectory} response - user details
   */
  getUserDetails(filterConditions: IFilterConditions[]): Observable<IActiveDirectory[]> {
    return Observable.of([
      {
        displayName: 'Test, User',
        onPremisesSamAccountName: 'ccfbok'
      },
      {
        displayName: 'Test, User2',
        onPremisesSamAccountName: 'CCFBOO'
      }
    ] as IActiveDirectory[]);
  }

  /**
   * Sets commission split access status
   * @param isUserHasAccess Access status
   */
  commissionSplitAccessStatus(isUserHasAccess: boolean): void {
    this.isUserHasOnlyCommissionSplitAccess.next(isUserHasAccess);
  }
}
