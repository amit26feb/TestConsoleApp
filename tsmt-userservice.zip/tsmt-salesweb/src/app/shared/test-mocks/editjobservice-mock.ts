
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import * as EditModel from '../../modules/jobs-list-master/modal/job-details-edit.model';

export const FinancialFormData = {
  jobReportId: 40382,
  jobId: 59297,
  drAddressId: 34,
  estEquipment: 7658,
  estControl: 8768,
  contractMargin: 49687,
  contractTaxes: 8476,
  contractTraneEquipDlrs: 95876,
  contractNonTraneEquipDlrs: 98576,
  contractSubContractDlrs: 9857,
  contractDirectJobExpenses: 58578,
};

export const dateFormValues = {
  createdDate: '9/14/2018',
  updatedDate: '9/15/2018',
  bidDate: '9/12/2018',
  submitalApprovalDate: '10/15/2018',
  reqProjectCompDate: '9/15/2019',
  startUpDate: '11/15/2019',
};
export const indicatorsOptions = [
  { id: 1, name: 'Acoustics', checked: false },
  { id: 2, name: 'ADP', checked: false },
  { id: 3, name: 'Hieff', checked: false },
  { id: 4, name: 'ICS', checked: false },
  { id: 5, name: 'LLWT', checked: false },
  { id: 6, name: 'Low Temp Air', checked: false },
  { id: 7, name: 'Natl Acct', checked: false },
  { id: 8, name: 'Pact', checked: false },
  { id: 9, name: 'Penalty Job', checked: false },
  { id: 10, name: 'Service Contract', checked: false },
  { id: 11, name: 'Stacked', checked: false },
  { id: 12, name: 'Target Job', checked: false },
];
export const IClassificationOptions = [{
  jobCodeId: 0,
  description: 'test',
  selected: true,
},
{
  jobCodeId: 1,
  description: 'test1',
  selected: false,
}];


export const ClassificationData = [{
  jobCodeId: 0,
  jobId: 0,
  drAddressId: 0,
  jobClassId: 0,
  descriptionValues: 'test',
  classificationDescription: 'test',
  jobClassificationList: IClassificationOptions,
},
{
  jobCodeId: 0,
  jobId: 0,
  drAddressId: 0,
  jobClassId: 0,
  descriptionValues: 'test',
  classificationDescription: 'test',
  jobClassificationList: IClassificationOptions,
}];

export const SalesOfficeData = {
  commCodeList: [{
    name: 'Temp',
    commCode: 'A01',
    commCodeDisplay: 'Temp(A01)',
    salesOfficeId: '1856',

  },
  {
    name: 'Temp',
    commCode: 'A01',
    commCodeDisplay: 'Temp(A01)',
    salesOfficeId: '1856',

  },
  ]
  ,
  jobContactList: [{
    userId: 'tslsa328',
    userName: 'Abram, Nicole(D00)',
  }],

};
export const EarthWiseData = [
  {
    jobId: 0,
    sysTypeId: 0,
    drAddressId: 0,
  },
  {
    jobId: 1,
    sysTypeId: 1,
    drAddressId: 1,
  },
];
export const postalData = [{
  countryCode: '10000',
  mainCityInd: '10000',
  fipsCode: '10000',
  stateProvinceCode: '10000',
  CITY: '10000',
  city: '10000',
  postalCode: '10000',
  countyName: '10000',
}, {
  countryCode: '2000000',
  mainCityInd: '2000000',
  fipsCode: '2000000',
  stateProvinceCode: '2000000',
  CITY: '2000000',
  city: '2000000',
  postalCode: '2000000',
  countyName: '2000000',
}];
export const postalData1 = [{
  countryCode: '10000',
  mainCityInd: '10000',
  fipsCode: '10000',
  stateProvinceCode: '10000',
  CITY: '10000',
  city: '10000',
  postalCode: '10000',
  countyName: '10000',
}, {
  countryCode: '10000',
  mainCityInd: '10000',
  fipsCode: '10000',
  stateProvinceCode: '10000',
  CITY: '10000',
  city: '10000',
  postalCode: '10000',
  countyName: '10000',
}];



@Injectable()
export class JobEditServiceMock {
  sortParameter = new BehaviorSubject<any>([{ field: 'joB_NAME', dir: 'asc' }]);
  summarySelectionSubject = new BehaviorSubject<any>(1);
  sortParameterValue$ = this.sortParameter.asObservable();
  private jobId = 77574;
  private drAddressId = 34;
  private jobReportId = '12345';

  public salesOfficeId;
  public jobGeneral: EditModel.IJobGeneral = {
    jobId: 77574,
    jobReportId: '51634',
    drAddressId: 34,
    jobName: 'Gantt Fire Dept',
    status: 'E',
    crmOpportunityId: '1799005',
    qualitySpecDescr: null,
    jobPhaseDescr: 'Lead',
    influencedById: '0',
    quoteNbr: null,
    pricingSpaNbr: null,
    dodgeNbr: null,
    distanceToJob: '0',
    sourceOfLead: null,
    tcpnNbr: null,
    tcpnContractNbr: null,
    falloutReason: null,
    lostToCompetitor: null,
    hqtrJobId: '12',
    crmIntegrationInd: 'Y',
    sellingPrice: 0,
    custChannelId: '',
    isCplpafLocked: false,
  };
  private jobAddress: EditModel.IJobAddress = {
    jobId: 77574,
    drAddressId: 34,
    domesticInternationlInd: 'D',
    streetAddress1: null,
    streetAddress2: null,
    city: null,
    state: null,
    zipCode: null,
    zipPlus: null,
    country: 'USA',
    county: null,
    province: null,
    nonUsPostalCode: null,
  };

  private jobNotes: EditModel.IJobNotesModel = {
    jobId: 0,
    noteString: 'test',
    drAddressId: 0,
  };
  private jobOfficeAndPeople: EditModel.IJobOfficeAndPeople = {
    jobId: 77574,
    jobReportId: '51634',
    drAddressId: 34,
    salesOfficeId: 34,
    locationOffice: 34,
    commCode: 'D33',
    takeoffCommCode: null,
    controlsCommCode: null,
    crmOppurtunityId: '1799005',
    salesOfficeName: 'Business Transformation Test',
    locationOfficeName: 'Business Transformation Test',
  };
  private jobDomainList: EditModel.IJobDomainList[] = [
    {
      listType: 'cojo',
      codeValue: ' ',
      displayValue: ' ',
      activeInd: 'Y',
      displayOrder: null,
    },
    {
      listType: 'job status',
      codeValue: 'W',
      displayValue: 'Closed - Won',
      activeInd: 'Y',
      displayOrder: '2',
    }];
  private jobRoleTypeList: EditModel.IJobRoleTypeList[];
  private competitorList: EditModel.ICompetitorList[];
  private salesOfficeList: EditModel.ISalesOfficeList[];
  private commCodeList: EditModel.ICommCodeList[] = [
    {
      name: 'Greenville Commission Summary',
      commCode: '000',
      commCodeDisplay: 'Greenville Commission Summary(000)',
      salesOfficeId: '34',
    },
    {
      name: 'Dean Hackett',
      commCode: 'D02',
      commCodeDisplay: 'Dean Hackett(D02)',
      salesOfficeId: '34',
    },
    {
      name: 'Joseph Cain',
      commCode: 'D03',
      commCodeDisplay: 'Joseph Cain(D03)',
      salesOfficeId: '34',
    }];
  private jobContactList = [{
    userId: 'ts12f3',
    userName: 'Adams..',
  },
  {
    userId: 'ts12f163',
    userName: 'Akers, Jeffrey(J00)',
  }];
  private jobDates: EditModel.IJobDateModel = {
    jobId: 0,
    jobReportId: 0,
    drAddressId: 0,
    bidDate: '9/14/2018',
    submittalDateApproved: '9/15/2018',
    reqProjectCompletionDate: '9/12/2018',
    startUpDate: '10/15/2018',
    lastUpdate: '9/15/2019',
    dateCreated: '9/15/2019',
    crmOpportunityId: '1799005',
  };
  private jobIndicatorView: EditModel.IJobIndicatorsModel;
  private jobFinancial: EditModel.IJobEditFinancialModel = FinancialFormData;

  payLoad: any;
  private params: any;
  public latestJobName$ = new Subject<string>();
  constructor(private http: HttpClient) { }
  getCountryCode(data) {
    return Observable.of([
      {
        countryCode: 'AF',
        countryName: 'AFGANISTHAN',
      },
      {
        countryCode: 'IND',
        countryName: 'INDIA',
      },
      {
        countryCode: 'IDN',
        countryName: 'INDONESIA',
      },
    ]);
  }

  fetchJobDetails(jobId, drAddressId) {

    return Observable.of({
      jobId: 10,
      userId: 'lamsp',
      nameFirst: 'first',
      nameLast: 'last',
      jobGeneral: this.jobGeneral,
      jobAddress: this.jobAddress,
      jobNotes: this.jobNotes,
      jobOfficeAndPeople: this.jobOfficeAndPeople,
      jobDomainList: this.jobDomainList,
      jobRoleTypeList: this.jobRoleTypeList,
      competitorList: this.competitorList,
      salesOfficeList: this.salesOfficeList,
      jobContactAndCommCodeList: { commCodeList: this.commCodeList, jobContactList: this.jobContactList },
      jobDates: this.jobDates,
      jobIndicatorView: this.jobIndicatorView,
      jobFinancial: this.jobFinancial,
      // jobClassificationList: this.jobClassificationList,
    });

  }

  getJobUpdateData(data) {
    return Observable.of({});
  }


  setJobReportId(jobReportId) {
    this.jobReportId = jobReportId;
  }

  getPostalCode(data) {
    return Observable.of(null);
  }


  editClassificationDetails() {
    return Observable.of(ClassificationData);
  }
  getSelectedClassifications() {
    return Observable.of(ClassificationData);
  }
  EarthwiseSystemDetails() {
    return Observable.of(EarthWiseData);
  }
  setSalesOfficeId(salesOfficeId) {
    this.salesOfficeId = salesOfficeId;
  }
  getJobRoleTypes(drAddressId) {
    return Observable.of([
      {
        roleTypeId: '2',
        roleTypeName: 'Architect',
      },
      {
        roleTypeId: '4',
        roleTypeName: 'Contractor',
      },
      {
        roleTypeId: '3',
        roleTypeName: 'Engineer',
      },
      {
        roleTypeId: '1',
        roleTypeName: 'Owner',
      },
      {
        roleTypeId: '5',
        roleTypeName: 'Unknown',
      },
    ]);
  }
  getDocumentList(skip, take, jobId, drAddressId) {
    return Observable.of({
      pageNumber: 1,
      pageSize: 10,
      totalItemCount: 1,
      pageCount: 1,
      documentList: [
        {
          jobId: 60243,
          drAddressId: 0,
          uploadedDate: Date.now(),
          uploadedUserId: 'abcde',
          notes: 'This is mock data',
          documentKey: 'Jobs/101/60243/ASP.Net Core.pptx',
          documentName: 'ASP.Net Core.pptx',
          documentVersion: 'TTAdNj3cvY2zDp0XCdTTsBTu1Vfe6WgU',
          documentSource: 'data',
          uploadedBy: 'Harry',
          totalCount: 1,
          documentCount: 1,
        },
      ],
    });
  }

  getJobDocumentHistoryDetails(drAddressId, jobId, documentKey, folderId: number) {
    return Observable.of([{
      documentKey: 'Jobs/142/575651/BidsCrossReference(1).xlsx',
      documentName: 'BidsCrossReference(1).xlsx',
      documentSource: null,
      documentVersion: '37llYHcjWF9viSLqynIvv3kHpsWwND7q',
      drAddressId: 0,
      jobId: 0,
      uploadedBy: 'ccfbyo',
      notes: 'testdoc',
      uploadedDate: '2019-09-25T07:05:53',
      uploadedUserId: 'ccfbyo',
    }]);
  }

  getJobLockedUserDetails(drAddressId, jobId) {
    return Observable.of({
      userId: 'lcfgsa',
      firstName: 'Hendry',
      lastName: 'Board',
      userName: 'Board, Hendry',
    });
  }

  deleteDocument(drAddressId, jobId, documentKey) {
    return Observable.of({});
  }

  downloadDocument(drAddressId, jobId, documentKey, documentVersion) {
    return Observable.of({});
  }

  latestJobName(jobName) {
    this.latestJobName$.next(jobName);
  }

  moveDocumentToSharePoint() {
    return Observable.of({});
  }
}




