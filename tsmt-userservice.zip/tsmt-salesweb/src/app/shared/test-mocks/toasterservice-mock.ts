import { EventEmitter } from '@angular/core';
import 'rxjs/add/observable/of';
export class ToasterMock {
    public msg: EventEmitter<any>;
    public status: EventEmitter<any>;
    constructor() {
        this.status = new EventEmitter<any>();
        this.msg = new EventEmitter<any>();
    }
    public getToasterMsg() {
        return this.msg;
    }

    public getToasterStatus() {
        return this.status;
    }

    public setToaster(status: string, msg: string) {
        this.status.emit(status);
        this.msg.emit(msg);
    }
}
