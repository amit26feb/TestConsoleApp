import 'rxjs/add/observable/empty';
import 'rxjs/add/observable/of';
import { BehaviorSubject, Observable } from 'rxjs';

export class SelectionServiceMock {

  public sortParameter = new BehaviorSubject<any>([{ field: 'selectionId', dir: 'asc' }]);
  public sortParameterValue$ = this.sortParameter.asObservable();

  sortParameterNonTrane = new BehaviorSubject<any>([{ field: 'variationType', dir: 'asc' }]);
  sortParameterNonTraneValue$ = this.sortParameterNonTrane.asObservable();

  getSelectionListData(payload) {
    return Observable.of(
      {
        pageNumber: 1,
        pageSize: 10,
        totalItemCount: 1,
        pageCount: 1,
        selectionList: [{
          pricedIndicator: 'P',
          selectionDescription: 'Indoor Gas Heating Products',
          selectionId: 987654,
          listPrice: 5045,
          qty: 2,
          tag: 'ABC-123',
          productFamily: 'ZYXW',
          orderedIndicator: 'O',
          reviseDate: '04/10/2006 17:42:42',
        }],
      });
  }
  sortValue(sort) {
    return Observable.of(sort);
  }
  sortValueNonTrane(sort) {
    return Observable.of(sort);
  }
  getNonTraneData(payload) {
    return Observable.of(
      {
        pageNumber: 1,
        pageSize: 10,
        totalItemCount: 1,
        pageCount: 1,
        nonTraneItems: [{
          variationType: 'P',
          description: 'Indoor Gas Heating Products',
          variationId: 987654,
          provider: 'P',
          qty: 1,
          cost: 1740,
          markup: 19,
          sellingPrice: 32547,
          status: 'C',
          materialCount: 6,
          laborCount: 2,
          facilitationFeeCount: 1,
        }],
      });
  }
}
