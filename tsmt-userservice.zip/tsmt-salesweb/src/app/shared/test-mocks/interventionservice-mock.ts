import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IModelNumberPrefixModel } from '../../modules/work-package/models/model-number-prefix';
import { IProductFamilyModel } from '../../modules/work-package/models/product-family';

@Injectable({
  providedIn: 'root',
})

export class InterventionServiceMock {
  public modelNumberPrefixMock = [
    { manufacturerName: 'CVHE500', modelNumberPrefix: '1111' },
    { manufacturerName: 'CVHE501', modelNumberPrefix: '2222' },
  ];
  public productFamilyMock = [
    { productFamily: '13TC', description: 'test - Regression Testing' },
    { productFamily: '13WC', description: 'TAutomation - To verify the Edit functionality' },
  ];
  constructor() { }

  retrieveModelNumberPrefixes(): Observable<IModelNumberPrefixModel[]> {
    return of(this.modelNumberPrefixMock);
  }

  retrieveProductFamilies(): Observable<IProductFamilyModel[]> {
    return of(this.productFamilyMock);
  }
}
