export const selectedBidList = [
    {
        bidAlternateId: 657456,
        bidAlternateXrefId: 19,
        selectedPricingParmId: null,
        selectionId: 1,
        variationId: null,
    }, {
        bidAlternateId: 657456,
        bidAlternateXrefId: 19,
        selectedPricingParmId: 18,
        selectionId: null,
        variationId: null,
    }, {
        bidAlternateId: 657456,
        bidAlternateXrefId: 19,
        selectedPricingParmId: null,
        selectionId: null,
        variationId: 17379,
    },
    {
        bidAlternateId: 657456,
        bidAlternateXrefId: 19,
        selectedPricingParmId: null,
        selectionId: null,
        variationId: 17379,
    },
];
export const selectionList = [{
    selectionId: 1,
    isParentSelection: false,
    separatelyBiddableId: null,
    selectionVariationId: null,
    type: 'Configured',
    isSeparatelyBiddableInPractice: true,
  },
  {
    selectionId: 1,
    isParentSelection: false,
    separatelyBiddableId: null,
    selectionVariationId: 17379,
    type: 'Configured',
    isSeparatelyBiddableInPractice: true,
  },
  {
    selectionId: 1,
    isParentSelection: false,
    separatelyBiddableId: 18,
    selectionVariationId: null,
    type: 'Configured',
    isSeparatelyBiddableInPractice: true,
  }, {
    selectionId: 2,
    isParentSelection: false,
    separatelyBiddableId: null,
    selectionVariationId: null,
    type: 'Configured',
    isSeparatelyBiddableInPractice: true,
  },
  ];
export const variationList = [{
    jobVariationId: 17380,
},
{
    jobVariationId: 17381,
}];

export const selectionsForBid = [{
    selectionId: 1,
    isParentSelection: false,
    separatelyBiddableId: null,
    selectionVariationId: null,
    type: 'Configured',
    isSeparatelyBiddableInPractice: true,
},
{
    selectionId: 1,
    isParentSelection: false,
    separatelyBiddableId: null,
    selectionVariationId: 17379,
    type: 'Configured',
    isSeparatelyBiddableInPractice: true,
},
{
    selectionId: 1,
    isParentSelection: false,
    separatelyBiddableId: 18,
    selectionVariationId: null,
    isSeparatelyBiddableInPractice: false,
    type: 'Configured',
},
{
    selectionId: 2,
    isParentSelection: false,
    separatelyBiddableId: null,
    selectionVariationId: null,
    type: 'Configured',
    isSeparatelyBiddableInPractice: true,
},
{
    selectionId: 4,
    isParentSelection: false,
    separatelyBiddableId: null,
    selectionVariationId: null,
    type: 'Non-Trane',
    isSeparatelyBiddableInPractice: true,
},
];
export const variationsForBid = [{
    jobVariationId: 17380,
},
{
    jobVariationId: 17381,
}];
