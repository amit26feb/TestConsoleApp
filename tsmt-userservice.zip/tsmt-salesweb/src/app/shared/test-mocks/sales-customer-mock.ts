import 'rxjs/add/observable/of';
import { Observable } from 'rxjs';
import { ISearchCustomerListModel } from '../../modules/jobs-list-master/modal/job-details-edit.model';
export class SalesCustomerServiceMock {

    createCustomer() {
        return Observable.of('30100');
    }

    getSearchCustomers(skip, take, searchText, drAddressId): Observable<ISearchCustomerListModel> {
        const searchCustomerData = {
            pageNumber: 1,
            pageSize: 1,
            totalItemCount: 1,
            pageCount: 1,
            customerList: [{
                salesCustId: 101,
                firstName: 'Doug ',
                lastName: ' Romine',
                customerName: 'Air Controls Co. Inc.',
                streetAddress1: '2115 2nd Ave. North',
                streetAddress2: '88 Fort Rd.',
                state: 'MT',
                zipCode: '59101',
                nonUsPostalCode: null,
                city: 'BILLINGS',
                custAcctNbr: '4507083',
                jobRoleTypeId: 4,
                commCode: 'A02',
                address: '2115 2nd Ave. North 88 Fort Rd. BILLINGS MT 30111 USA',
                phoneNumber: '406-245-6416',
                faxNumber: null,
                totalCount: 7,
                contactPhoneNumber: '3345567789',
                contactFaxNumber: '6678897776',
                contactPhoneExtension: '7786654432',
                crmCompanyId: "123",
            }],
        } as ISearchCustomerListModel;
        return Observable.of(searchCustomerData);
    }

    assignCustomer(data, drAddressId) {
        return Observable.of(true);
    }

    getAssignCustomers(skip, take, jobId, drAddressId) {
        const assignCustomerData = {
            customerList: [{
                salesCustId: 191,
                firstName: 'Bob ',
                lastName: '   Prill',
                customerName: 'Prill Brothers Inc.',
                streetAddress1: 'P.O. Drawer S-82801-0639',
                streetAddress2: '44 Fort Rd.',
                state: 'WY',
                zipPlus: null,
                zipCode: '82801',
                phoneNbr: '307-674-4436',
                province: null,
                nonUsPostalCode: null,
                city: 'SHERIDAN',
                fipsCode: '56033',
                custAcctNbr: '9369653',
                jobRoleTypeId: 4,
                commCode: 'A02',
                country: 'USA',
                county: 'SHERIDAN',
                bidderInd: 'Y',
                winningBidderInd: null,
                address: 'P.O. Drawer S-82801-0639 44 Fort Rd. SHERIDAN WY 56033 USA',
                totalCount: 5,
                isAssigned: null,
                phoneExt: '191',
                faxNbr: null,
                jobId: 0,
            }],

        };
        return Observable.of(assignCustomerData);
    }

    unassignCustomer(jobRoleAsnId, drAddressId, jobId) {
        return Observable.of(1);
    }

    getCustomerAndContactsList(selectedCustId, drAddressId) {
        const customerContactData = {
            salesCustId: 713,
            custChannelId: 'COMMSALE',
            customerName: 'custcheck',
            salesOfficeId: 442,
            accountNumber: '3424234',
            addressLine1: 'test',
            addressLine2: 'test1',
            city: null,
            commCode: 'A00',
            country: 'USA',
            crmCompanyId: null,
            custCreditCatgCode: null,
            faxNumber: '3453453453',
            fipsCode: '42015',
            jobId: 0,
            jobRoleAsnId: 0,
            jobRoleType: 4,
            lastEcSyncChangeId: 0,
            nonUSPostalCode: null,
            parentCustId: 0,
            phoneNumber: '3253453453',
            province: null,
            state: null,
            statusFlag: 'C',
            usedForOrderEntryInd: null,
            zipCode: '18810',
            zipPlus: null,
            salesCustomerContactView: [{
                customerContactId: 212,
                salesCustId: 713,
                firstName: 'Jack',
                lastName: 'Dill',
                phoneNbr: '6456464564',
                assignContact: true,
                faxNbr: '4564564564',
                jobRoleAsnId: 2567,
                jobRoleContactId: 743,
                phoneExtension: '666',
            },
            {
                customerContactId: 213,
                salesCustId: 713,
                firstName: 'Jamesh',
                lastName: 'Kane',
                phoneNbr: '4534534534',
                assignContact: true,
                faxNbr: '3534534534',
                jobRoleAsnId: 2568,
                jobRoleContactId: 744,
                phoneExtension: '555',
            },
            ],
        };
        return Observable.of(customerContactData);

    }

    deleteCustomerContact(salesCustId, drAddressId, customerContactId) {
        return Observable.of(1);
    }

    deleteCustomer(salectedCustId, drAddressId) {
        return Observable.of();
    }

    updateAssignCustomer(data, drAddressId) {
        return Observable.of(2718);
    }

}
