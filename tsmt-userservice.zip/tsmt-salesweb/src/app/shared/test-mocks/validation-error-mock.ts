export const ValidationErrorsMock = [{
    rootEntityName: 'EnityName',
    rootEntityId: 9,
    ruleId: 10,
    ruleGroupId: 11,
    message: 'warning message',
    messageType: 'Warning',
    lastUpdatedDate: new Date('2020-06-19T12:25:31.501Z'),
    ruleTarget: 'Warning',
    ruleEvent: 'Pre-Validation',
}];
