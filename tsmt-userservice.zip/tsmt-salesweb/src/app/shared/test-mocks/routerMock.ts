import { Injectable } from '@angular/core';
import { NavigationEnd } from '@angular/router';

import { BehaviorSubject } from 'rxjs';

@Injectable()
export class RouterMock {
  events = new BehaviorSubject<NavigationEnd>(null);
  navigate(value) {
  }
  navigateByUrl() { }

}
