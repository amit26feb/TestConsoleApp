import { IJobSummaryModel } from '../model/job-summary-model';
import {
    IEditJobModel, IJobAddress, IJobGeneral, IJobNotesModel,
    IJobOfficeAndPeople,
} from './../../modules/jobs-list-master/modal/job-details-edit.model';

const streetAddress1 = '708 Heartland Trail';
const streetAddress2 = 'Suite 1600';

export const jobSummaryInfo: IJobSummaryModel = {
    documents: {
        pageNumber: 1,
        pageSize: 20,
        totalItemCount: 10,
        pageCount: 1,
        documentList: [{
            jobId: 3456,
            drAddressId: 67,
            documentSource: null,
            documentVersion: 'ELHGJqU.6YFbqfJkGjEa68_fEEtZjaK3',
            uploadedBy: 'Test, User',
            totalCount: 1,
            documentCount: 1,
            jobDocumentId: 175,
            documentKey: 'Jobs/142/13120/sample_Test.txt',
            uploadedDate: '2020-05-28T03:06:28',
            notes: null,
            documentName: 'sample_Test.txt',
            uploadedUserId: 'ccfbey',
            documentUpdateStatus: null,
        }],
    },
    nonTraneItems: {
        pageNumber: 1,
        pageSize: 20,
        totalItemCount: 10,
        pageCount: 1,
        nonTraneItems: [],
    },
    traneItems: {
        pageNumber: 123,
        pageSize: 30,
        totalItemCount: 30,
        pageCount: 12,
        selectionList: [{
            isConfiguredItem: true,
            legacyOrderNumber: '1234',
            selectionId: 12345,
            pricedIndicator: 'P',
            orderedIndicator: 'N',
            tag: 'GEHV-1',
            productFamily: 'GEHV',
            selectionDescription: 'Standard Efficiency WSHP',
            qty: 1,
            reviseDate: '12/05/2020',
            listPrice: 6030,
            netPrice: 6030,
        }],
    },
    basicInfo: {
        jobId: 1,
        drAddressId: 1,
        userId: 'ccspde',
        nameFirst: 'Test',
        nameLast: 'User',
        coordinationStatus: 'Pending',
        jobGeneral: {
            pricingSpaNbr: '15-50800',
        } as IJobGeneral,
        jobOfficeAndPeople: {
            jobId: 4567,
            salesOfficeName: 'Appleton',
            locationOfficeName: 'Appleton',
        } as IJobOfficeAndPeople,
        jobAddress: {
            streetAddress1: '1600 Aspen Commons',
            streetAddress2: null,
            city: 'MIDDLETON',
            state: 'WI',
            zipCode: '53562',
            nonUsPostalCode: null,
            country: 'USA',
        } as IJobAddress,
        jobNotes: {
            jobId: 60690,
            noteString: 'Artis\nLiberty\n1600\nAspen\nLiberty\nMutualHP',
            drAddressId: 0,
        } as IJobNotesModel,
    } as IEditJobModel,
} as IJobSummaryModel;

export const jobSummaryInfoWithoutData = {} as IJobSummaryModel;

export const jobSummaryInfoWithCustomerInfo = {
    customers: {
        pageNumber: 1,
        pageSize: 50,
        totalItemCount: 1,
        pageCount: 1,
        customerList: [{
            salesCustId: 10677,
            customerName: 'AX Madison Greenway, L.P.',
            streetAddress1,
            streetAddress2,
            state: 'WI',
            zipPlus: null,
            zipCode: '53717',
            phoneNbr: '',
            province: null,
            nonUsPostalCode: null,
            city: 'MADISON',
            fipsCode: '55025',
            custAcctNbr: null,
            jobRoleTypeId: 16,
            commCode: null,
            country: 'USA',
            county: null,
            bidderInd: null,
            winningBidderInd: null,
            address: '708 Heartland Trail Suite 1600 MADISON WI 53717 USA',
            phoneExt: null,
            faxNbr: '',
            totalCount: 1,
            firstName: null,
            lastName: ' ',
            region: 'United States',
            jobRoleAsnId: '33054',
            crmCompanyId: '680152',
        }],
    },
} as IJobSummaryModel;

export const jobSummaryInfoWithStreetAddressAsNull = {
    basicInfo: {
        jobGeneral: {
            pricingSpaNbr: '15-50800',
        } as IJobGeneral,
        jobOfficeAndPeople: {
            jobId: 4567,
            salesOfficeName: 'Business Transformation Test',
            locationOfficeName: 'Business Transformation Test',
        } as IJobOfficeAndPeople,
        jobAddress: {
            streetAddress1: null,
        } as IJobAddress,
    } as IEditJobModel,
} as IJobSummaryModel;

export const jobSummaryInfoWithStreetAddressAsEmpty = {
    basicInfo: {
        jobGeneral: {
            pricingSpaNbr: '21-8765',
        } as IJobGeneral,
        jobOfficeAndPeople: {
            jobId: 4567,
            salesOfficeName: 'Billings',
            locationOfficeName: 'Billings',
        } as IJobOfficeAndPeople,
        jobAddress: {
            streetAddress1: '',
        } as IJobAddress,
    } as IEditJobModel,
} as IJobSummaryModel;

export const jobSummaryInfoWithoutNoteString = {
    bids: null,
    documents: null,
    nonTraneItems: null,
    traneItems: null,
    customers: null,
    basicInfo: {
        jobId: 1,
        drAddressId: 1,
        userId: 'ccspde',
        nameFirst: 'Test',
        nameLast: 'User',
        coordinationStatus: 'Pending',
        jobGeneral: {
            pricingSpaNbr: '15-50800',
        } as IJobGeneral,
        jobNotes: {
            jobId: 60690,
            noteString: null,
            drAddressId: 0,
        } as IJobNotesModel,
    } as IEditJobModel,
} as IJobSummaryModel;

export const jobSummaryInfoWithNoteString = {
    bids: null,
    documents: null,
    nonTraneItems: null,
    traneItems: null,
    customers: null,
    basicInfo: {
        jobId: 1,
        drAddressId: 1,
        userId: 'ccspde',
        nameFirst: 'Test',
        nameLast: 'User',
        coordinationStatus: 'Pending',
        jobGeneral: {
            pricingSpaNbr: '15-50800',
        } as IJobGeneral,
        jobNotes: {
            jobId: 60690,
            noteString: 'test',
            drAddressId: 0,
        } as IJobNotesModel,
    } as IEditJobModel,
} as IJobSummaryModel;

export const jobSummaryInfoWithoutSectionData = {
    bids: null,
    documents: null,
    nonTraneItems: null,
    traneItems: null,
    customers: null,
    basicInfo: {
        jobId: 1,
        drAddressId: 1,
        userId: 'ccspde',
        nameFirst: 'Test',
        nameLast: 'User',
        coordinationStatus: 'Pending',
        jobAddress: {
            streetAddress1,
            streetAddress2,
        } as IJobAddress,
        jobGeneral: {
            pricingSpaNbr: '15-50800',
        } as IJobGeneral,
        jobNotes: null,
    } as IEditJobModel,
} as IJobSummaryModel;

export const jobSummaryWithSectionInformation = {
    bids: [{
        bidAlternateId: 658063,
    }],
    documents: {
        pageNumber: 1,
        pageSize: 20,
        totalItemCount: 10,
        pageCount: 1,
        documentList: [{
            jobId: 3456,
            drAddressId: 67,
            documentSource: null,
            documentVersion: 'ELHGJqU.6YFbqfJkGjEa68_fEEtZjaK3',
            uploadedBy: 'Test, User',
            totalCount: 1,
            documentCount: 1,
            jobDocumentId: 175,
            documentKey: 'Jobs/142/13120/sample_Test.txt',
            uploadedDate: '2020-05-28T03:06:28',
            notes: null,
            documentName: 'sample_Test.txt',
            uploadedUserId: 'ccfbey',
            documentUpdateStatus: null,
        }],
    },
    nonTraneItems: {
        pageNumber: 1,
        pageSize: 20,
        totalItemCount: 10,
        pageCount: 1,
        nonTraneItems: [],
    },
    traneItems: {
        pageNumber: 123,
        pageSize: 30,
        totalItemCount: 30,
        pageCount: 12,
        selectionList: [{
            isConfiguredItem: true,
            legacyOrderNumber: '1234',
            selectionId: 12345,
            pricedIndicator: 'P',
            orderedIndicator: 'N',
            tag: 'GEHV-1',
            productFamily: 'GEHV',
            selectionDescription: 'Standard Efficiency WSHP',
            qty: 1,
            reviseDate: '12/05/2020',
            listPrice: 6030,
            netPrice: 6030,
        }],
    },
    customers: {
        pageNumber: 1,
        pageSize: 50,
        totalItemCount: 1,
        pageCount: 1,
        customerList: [{
            salesCustId: 10677,
            customerName: 'AX Madison Greenway, L.P.',
            streetAddress1,
            streetAddress2,
            state: 'WI',
            zipPlus: null,
            zipCode: '53717',
            phoneNbr: '',
            province: null,
            nonUsPostalCode: null,
            city: 'MADISON',
            fipsCode: '55025',
            custAcctNbr: null,
            jobRoleTypeId: 16,
            commCode: null,
            country: 'USA',
            county: null,
            bidderInd: null,
            winningBidderInd: null,
            address: '708 Heartland Trail Suite 1600 MADISON WI 53717 USA',
            phoneExt: null,
            faxNbr: '',
            totalCount: 1,
            firstName: null,
            lastName: ' ',
            region: 'United States',
            jobRoleAsnId: '33054',
            crmCompanyId: '680152',
        }],
    },
    basicInfo: {
        jobId: 1,
        drAddressId: 1,
        userId: 'ccspde',
        nameFirst: 'Test',
        nameLast: 'User',
        coordinationStatus: 'Pending',
        jobGeneral: {
            pricingSpaNbr: '15-50800',
        } as IJobGeneral,
        jobAddress: {
            streetAddress1,
            streetAddress2,
        } as IJobAddress,
        jobNotes: {
            jobId: 60690,
            noteString: 'test',
            drAddressId: 0,
        } as IJobNotesModel,
    } as IEditJobModel,
} as IJobSummaryModel;

