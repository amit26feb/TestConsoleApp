import { BehaviorSubject, Subject } from 'rxjs';

export class JobsServicesServiceMock {
    sortParameter = new BehaviorSubject<any>([{ field: 'joB_NAME', dir: 'asc' }]);
    summarySelectionSubject = new BehaviorSubject<any>(1);
}
