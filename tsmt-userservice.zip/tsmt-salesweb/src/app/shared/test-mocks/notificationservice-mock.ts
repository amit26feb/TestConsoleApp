export class NotificationServiceMock {
    show(options: any) {
    }
}
