import 'rxjs/add/observable/of';
import { Observable, Subject } from 'rxjs';
import * as EditModel from '../../modules/jobs-list-master/modal/job-details-edit.model';
import { IJobModel } from '../model/job-model';
export class JobListServiceMock {
  public jobId: number;
  public drAddressId: number;
  public salesOfficeId = 1;
  public sort: any;
  public descriptionValues = 'PROCTOR AND GAMBLE';
  public latestJobName$ = new Subject<string>();
  public jobSummaryPanelStatus$ = new Subject<{ showJobSummary: boolean }>();
  private jobGeneral: EditModel.IJobGeneral = {
    jobId: 77574,
    jobReportId: '51634',
    drAddressId: 34,
    jobName: 'Gantt Fire Dept',
    status: 'C',
    crmOpportunityId: '1799005',
    qualitySpecDescr: null,
    jobPhaseDescr: 'Lead',
    influencedById: '0',
    quoteNbr: null,
    pricingSpaNbr: null,
    dodgeNbr: null,
    distanceToJob: '0',
    sourceOfLead: null,
    tcpnNbr: null,
    tcpnContractNbr: null,
    falloutReason: null,
    lostToCompetitor: null,
    hqtrJobId: null,
    crmIntegrationInd: 'Y',
    sellingPrice: 1050,
    custChannelId: '',
    isCplpafLocked: false,
  };

  public jobDetails: IJobModel = {
    userId: 'aaaaaa',
    nameFirst: 'Jhon',
    nameLast: 'Kenn',
    jobGeneral: {
      jobId: 53574,
      drAddressId: 122,
      jobName: 'Gantt Fire Dept',
      tcpnNbr: 'AT0331',
      tcpnContractNbr: null,
    },
  };

  private setSortConfig(sort) {
    this.sort = sort;
  }

  private getSortConfig() {
    return this.sort;
  }

  CreateJob({ JOB_ID: Number }) {
    return Observable.of(Boolean);
  }

  editClassificationDetails() {
    return Observable.of([
      {
        jobCodeId: 0,
        jobId: 0,
        drAddressId: 0,
        jobClassId: 1,
        descriptionValues: this.descriptionValues,
        classificationDescription: 'Purchaser Class',
        jobClassificationList: [
          {
            jobCodeId: 946,
            description: this.descriptionValues,
          }],
      },
      {
        jobCodeId: 0,
        jobId: 0,
        drAddressId: 0,
        jobClassId: 38,
        descriptionValues: null,
        classificationDescription: 'Vertical Market',
        jobClassificationList: [
          {
            jobCodeId: 974,
            description: 'Agriculture-All Applications',
          }],
      },
      {
        jobCodeId: 0,
        jobId: 0,
        drAddressId: 0,
        jobClassId: 7,
        descriptionValues: null,
        classificationDescription: 'Transitional Job',
        jobClassificationList: [
          {
            jobCodeId: 76,
            description: 'Yes',
          }],
      },
    ]);
  }

  getSelectedClassifications() {
    return Observable.of([
      {
        jobCodeId: 0,
        jobId: 0,
        drAddressId: 0,
        jobClassId: 1,
        descriptionValues: this.descriptionValues,
        classificationDescription: 'Purchaser Class',
        jobClassificationList: null,
      }]);
  }

  LockAndUnLockJob(data): Observable<any> {
    return Observable.of({
      userId: 'ccfbsb',
      nameFirst: 'Swati',
      nameLast: 'Tadaka',
    });
  }

  fetchJobDetails(jobId, drAddressId) {

    return Observable.of({
      jobId: 10,
      userId: 'xxabc',
      nameFirst: 'first',
      nameLast: 'last',
      jobGeneral: this.jobGeneral,
    });
  }


  getPostalCode(data) {
    return Observable.of([
      {
        countryCode: 'USA',
        mainCityInd: null,
        fipsCode: '25017',
        stateProvinceCode: 'MA',
        city: 'WAKEFIELD',
        postalCode: '01880',
        countyName: 'MIDDLESEX',
      },
      {
        countryCode: 'USA',
        mainCityInd: null,
        fipsCode: '25009',
        stateProvinceCode: 'MA',
        city: 'WEST BOXFORD',
        postalCode: '01885',
        countyName: 'ESSEX',
      },
      {
        countryCode: 'USA',
        mainCityInd: null,
        fipsCode: '25017',
        stateProvinceCode: 'MA',
        city: 'GRANITEVILLE',
        postalCode: '01886',
        countyName: 'MIDDLESEX',
      },
      {
        countryCode: 'USA',
        mainCityInd: null,
        fipsCode: '25017',
        stateProvinceCode: 'MA',
        city: 'WESTFORD',
        postalCode: '01886',
        countyName: 'MIDDLESEX',
      }]);
  }


  getSalesOfficeId() {
    return 126;
  }


  getJobRoleTypes(drAddressId) {
    return Observable.of([
      {
        roleTypeId: '2',
        roleTypeName: 'Architect',
      },
      {
        roleTypeId: '4',
        roleTypeName: 'Contractor',
      },
      {
        roleTypeId: '3',
        roleTypeName: 'Engineer',
      },
      {
        roleTypeId: '1',
        roleTypeName: 'Owner',
      },
      {
        roleTypeId: '5',
        roleTypeName: 'Unknown',
      },
    ]);
  }

  getJobLockedUserDetails(drAddressId, jobId) {
    return Observable.of({
      userId: 'lcfgsa',
      firstName: 'Hendry',
      lastName: 'Board',
      userName: 'Board, Hendry',
    });
  }

  latestJobName(jobName) {
    this.latestJobName$.next(jobName);
  }

  transmitJob(data) {
    return Observable.of('35135b6d-0158-4369-b2bd-af3fb827cf74');
  }

  exportJob(data) {
    return Observable.of({
      crmValidationWarningMessage: 'Do you want to create a new job in the Alaska sales office not related to an Opportunity Id?',
      IsExported: false,
    });
  }

  importJob(data) {
    return Observable.of(true);
  }

  getFollowedJobCount(drAddressId) {
    const followedJobCount = 4;
    return Observable.of(followedJobCount);
  }

  updateFavorite(drAddressId: number, jobId: number): Observable<any> {
    return Observable.of(null);
  }

  getJobBasicInfo(jobId: number, drAddressId: number): Observable<any> {
    const basicInfo = {
      jobId: 0,
      jobName: 'Test',
      hqtrJobId: 0,
      pricingSpaNumber: null,
      salesOfficeName: 'International',
      locationOfficeName: 'Int',
      salesDistrict: '144',
    };
    return Observable.of(basicInfo);
  }

  getJobDetails(drAddressId: number, jobId: number): Observable<IJobModel> {
    return Observable.of(this.jobDetails);
  }
}



