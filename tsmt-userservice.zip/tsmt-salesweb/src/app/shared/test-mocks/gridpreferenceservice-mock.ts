import { Injectable } from '@angular/core';
import { State } from '@progress/kendo-data-query';
import {
    IPreference,
} from '@tsmt/shared-core';
import {
    IDefaultPreference,
    IGridPreferenceAppInfo,
    IGridPreferenceState,
} from '@tsmt/shared-core/lib/models/grid-preference-model';
import { Observable, Subject } from 'rxjs';


export class GridPreferenceServiceMock {
    preference: IPreference = {
        gridPreferenceId: 'test',
        userId: 'test',
        applicationId: 'test',
        route: 'test',
        gridName: 'test',
        gridPreferenceName: 'test',
        gridPreferenceSetting: 'test',
        isPublic: false,
        isDefault: false,
    };
    appInfoData: IGridPreferenceAppInfo;
    gridPreferenceState: IGridPreferenceState;
    public preferenceUpdate = new Subject<boolean>();
    updatePref: boolean;
    createPref: boolean;
    detfaultPreference: IDefaultPreference;


    constructor() { }


    saveAppInfoData(data: IGridPreferenceAppInfo): void {
        this.appInfoData = data;
    }


    buildPreferenceAndUpdate(state: State) {
        this.gridPreferenceState = {
            state,
            columnConfig: null,
        };
    }


    fetchGridPreferences(): Observable<IPreference[]> {
        return Observable.of([this.preference]);
    }

    updatePreference(): void {
        this.updatePref = true;
    }

    setDefaultPreference(defaultPref: IDefaultPreference): void {
        this.detfaultPreference = defaultPref;
    }

    createPreference(): void {
        this.createPref = true;
    }

}
