import 'rxjs/add/observable/of';
import { Observable } from 'rxjs';
import { IApiErrorState } from '../model/apierror-state';

export class ApiErrorServiceMock {
  show(message: any) {
    return Observable.of({ show: true, errorMessage: message  } as IApiErrorState);
  }

  hide() {
    return Observable.of({ show: false, errorMessage: ''  } as IApiErrorState);
  }
}
