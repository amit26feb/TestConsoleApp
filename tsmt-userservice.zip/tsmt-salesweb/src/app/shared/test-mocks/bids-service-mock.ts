import 'rxjs/add/observable/of';
import { Observable } from 'rxjs';

export class BidsServiceMock {
  public bidsList = [{
    bidAlternateId: 656110,
    currentBidInd: 'Y',
    bidName: 'LO',
    description: 'LO Desc',
    creditJobNumber: 'L380997',
    purchaseOrderNumber: null,
    spaNumber: null,
    sellingPrice: '',
    baseBidYesNo: 1,
    foe2CreatedOrdersInd: 'Y',
    hqtrBidAlternateId: 3671493,
    hqtrCreditJobId: 37165,
    isIncludeInCoordinatedJob: true,
    creditJobId: 2130356,
  },
  {
    bidAlternateId: 0,
    currentBidInd: 'N',
    bidName: 'Air Bid',
    description: 'Base Bid Desc',
    creditJobNumber: 'L381131',
    purchaseOrderNumber: null,
    spaNumber: null,
    sellingPrice: '',
    baseBidYesNo: 1,
    foe2CreatedOrdersInd: 'Y',
    hqtrBidAlternateId: 3671493,
    hqtrCreditJobId: null,
    isIncludeInCoordinatedJob: true,
    creditJobId: 0,
  }];

  getBids(drAddressId, jobId){
    return this.getBidsList(drAddressId, jobId);
  }

  getBidsList(drAddressId, jobId) {
    return Observable.of([
      {
        bidAlternateId: 656110,
        currentBidInd: 'Y',
        bidName: 'Base Bid',
        description: null,
        creditJobNumber: null,
        purchaseOrderNumber: null,
        spaNumber: null,
        sellingPrice: null,
        baseBidYesNo: 0,
        isIncludeInCoordinatedJob: false,
      },
      {
        bidAlternateId: 657058,
        currentBidInd: 'N',
        bidName: 'Alt Bid',
        description: null,
        creditJobNumber: null,
        purchaseOrderNumber: null,
        spaNumber: null,
        sellingPrice: null,
        baseBidYesNo: 0,
        isIncludeInCoordinatedJob: false,
      },
      {
        bidAlternateId: 1603,
        bidName: 'Air bio',
        creditJobNumber: null,
        currentBidInd: 'N',
        description: 'Airside Bio',
        purchaseOrderNumber: null,
        sellingPrice: 0,
        spaNumber: null,
        baseBidYesNo: 0,
        isIncludeInCoordinatedJob: false,
      },
      {
        bidAlternateId: 1604,
        bidName: 'LO',
        creditJobNumber: 'F512555',
        currentBidInd: 'N',
        description: 'LO',
        purchaseOrderNumber: null,
        sellingPrice: 0,
        spaNumber: null,
        baseBidYesNo: 0,
        foe2CreatedOrdersInd: 'Y',
        hqtrBidAlternateId: null,
        hqtrCreditJobId: null,
        isIncludeInCoordinatedJob: false,
      },
      {
        bidAlternateId: 1605,
        bidName: 'Bio',
        creditJobNumber: 'F512411',
        currentBidInd: 'N',
        description: 'Bio',
        purchaseOrderNumber: null,
        sellingPrice: 0,
        spaNumber: null,
        baseBidYesNo: 0,
        isIncludeInCoordinatedJob: false,
      },
      {
        baseBidYesNo: 0,
        bidAlternateId: 657428,
        bidName: 'test bid',
        creditJobNumber: 'F512311',
        currentBidInd: 'N',
        description: 'cc',
        foe2CreatedOrdersInd: 'Y',
        hqtrBidAlternateId: null,
        hqtrCreditJobId: 454,
        purchaseOrderNumber: 'P1.740.6',
        sellingPrice: 0,
        spaNumber: null,
        isIncludeInCoordinatedJob: false,
      },
      {
        baseBidYesNo: 0,
        bidAlternateId: 657428,
        bidName: 'test bid',
        creditJobNumber: 'F512356',
        currentBidInd: 'N',
        description: null,
        foe2CreatedOrdersInd: 'Y',
        hqtrBidAlternateId: null,
        hqtrCreditJobId: null,
        purchaseOrderNumber: 'P1.740.8',
        sellingPrice: 0,
        spaNumber: '81-29659',
        isIncludeInCoordinatedJob: false,
      },

    ]);
  }

  updateCurrentBidsStatus(drAddressId, jobId, bidAlternativeId) {
    return Observable.of(6);
  }

  saveBids(jobId, drAddressId, payload) {
    return Observable.of(1);
  }
  deleteBid(drAddressId, jobId, bidAlternativeId) {
    return Observable.of(1);
  }
  editBid(drAddressId, jobId, bidAlternateId, data) {
    return Observable.of(1);
  }

  getBidSelections(drAddressId, jobId) {
    return Observable.of([
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 196586,
        selectedPricingParmId: null,
        selectionId: null,
        variationId: 17379,
      },
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 196590,
        selectedPricingParmId: null,
        selectionId: 70937,
        variationId: null,
      },
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 1,
        selectedPricingParmId: null,
        selectionId: 1,
        variationId: null,
      },
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 3,
        selectedPricingParmId: 3,
        selectionId: null,
        variationId: null,
      },
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 10,
        selectedPricingParmId: null,
        selectionId: null,
        variationId: 2,
      },
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 11,
        selectedPricingParmId: null,
        selectionId: 5,
        variationId: null,
      },
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 265,
        selectedPricingParmId: 4,
        selectionId: null,
        variationId: null,
      },
      {
        bidAlternateId: 1,
        bidAlternateXrefId: 19,
        selectedPricingParmId: 18,
        selectionId: null,
        variationId: null,
      },
      {
        bidAlternateId: 657151,
        bidAlternateXrefId: 196588,
        selectedPricingParmId: 18,
        selectionId: null,
        variationId: null,
      },
      {
        bidAlternateId: 657151,
        bidAlternateXrefId: 196587,
        selectedPricingParmId: null,
        selectionId: 5,
        variationId: null,
      },
      {
        bidAlternateId: 657151,
        bidAlternateXrefId: 196589,
        selectedPricingParmId: null,
        selectionId: null,
        variationId: 17380,
      },
    ]);
  }

  deleteBidSelections(drAddressId, jobId, removePayload) {
    return Observable.of(true);
  }
  addSelectionsForBid(drAddressId, jobId, bidAlternateId, payload) {
    return Observable.of(true);
  }
}
