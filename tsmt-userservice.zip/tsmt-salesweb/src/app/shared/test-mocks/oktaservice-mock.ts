import { UserClaims } from '@okta/okta-angular';
import 'rxjs/add/observable/of';
import { Observable } from 'rxjs';

export class OktaServiceMock {
    isAuthentication = false;
    $authenticationState = Observable.of(false);

    isAuthenticated(): Promise<boolean> {
        return Promise.resolve(true);
    }

    getUser(): Promise<UserClaims> {
        return Promise.resolve({ sub: 'test' });
    }
}
