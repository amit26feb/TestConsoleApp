import 'rxjs/add/observable/of';

export class LoaderServiceMock {
  show() {
    return true;
  }
  hide() {
    return false;
  }
}
