import { Injectable } from '@angular/core';
import { NavigationEnd } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class JobsRouterMock {
    routerState = {
        snapshot: { url: 'jobs-list' },
    };
    events = new BehaviorSubject<NavigationEnd>(null);
    root = { children: ['/jobs-list'] };
    navigate() { }
}
