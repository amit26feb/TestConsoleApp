import { Subject } from 'rxjs';

export class JobSummaryServiceMock {
    jobSummaryPanelStatus$ = new Subject<{ showJobSummary: boolean }>();
}
