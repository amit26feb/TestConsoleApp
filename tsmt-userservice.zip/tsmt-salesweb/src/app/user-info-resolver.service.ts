import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';

import { RoleService, UserInfoService } from '@tsmt/shared-core-salesweb';
import { JobHeaderService } from './shared/services/job-header.service';
import { environment } from './../environments/environment';

@Injectable()
export class UserInfoResolver implements Resolve<any> {
    constructor(private oktaAuth: OktaAuthService,
        private jobHeaderService: JobHeaderService,
        private userInfoService: UserInfoService,
        private roleService: RoleService
    ) { }

  resolve() {
        // return the logged in user details to the JobsListMasterModule so that all the components
        // in the module will have access to it before they are initialised.
        return this.oktaAuth.getUser().then((user) => {
            // if the user is returned as null/undefined log off the user and redirect to
            // login else return the user claims
            if (!user) {
                this.oktaAuth.logout();
            } else {
              const userId = user['samAccountName'];
              const userName = user['given_name'] + ' (' + userId + ')';
              const userFullName = user['name'];
              const userRoles = user['Groups'];
              this.jobHeaderService.setUserId(userId);
              this.jobHeaderService.setUserName(userName);
              this.jobHeaderService.setFullName(userFullName);
              // Storing the logged user information into library service,
              // So that it be can accessible the user information values across the multiple libraries.
              // To reduce the OKTA calls
              this.userInfoService.setUserId(userId);
              this.userInfoService.setUserName(userName);
              this.userInfoService.setFullName(userFullName);
              this.userInfoService.setUserRoles(userRoles);
              // Checks the access permission of the user in prod & non-prod environments
              this.roleService.checkUserRoles(environment.deployedEnv.toLowerCase() === 'production', userRoles);
              return user;
          }
        });
    }
}
