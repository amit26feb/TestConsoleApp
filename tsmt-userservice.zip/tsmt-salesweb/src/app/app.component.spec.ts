import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ElementRef, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { OktaAuthModule, OktaAuthService } from '@okta/okta-angular';
import { NotificationModule, NotificationService, NotificationSettings } from '@progress/kendo-angular-notification';
import { CreditProjectService, HistoryService } from '@tsmt/salesweb-ordersmodule';
import { MessageCountService, ToasterService } from '@tsmt/shared-core';
import {
  ApiErrorService, CommonService as CommonServiceService, ErrorsAndWarningsPanelService,
  JobHeaderService as SharedJobHeaderService,
  UserInfoService
} from '@tsmt/shared-core-salesweb';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from './../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DocumentService } from './modules/jobs-list-master/services/document.service';
import { JobsServicesService } from './modules/jobs-list-master/services/jobs-services.service';
import { FooterComponent } from './shared/components/footer/footer.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { AppConstants } from './shared/constants/constants';
import { GlobalSearchService } from './shared/services/global-search.service';
import { JobHeaderService } from './shared/services/job-header.service';
import { WorkPackageCommonService } from './shared/services/work-package-common.service';
import { WorkflowPopupService } from './shared/services/workflow-popup.service';
import { GlobalSearchServiceMock } from './shared/test-mocks/global-search-mock';
import { OktaServiceMock } from './shared/test-mocks/oktaservice-mock';

// tslint:disable-next-line:no-big-function
describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let router: Router;
  let injector: TestBed;
  let workflowPopupService: WorkflowPopupService;
  let userInfoService: UserInfoService;
  let jobService: JobsServicesService;
  let creditProjectService: CreditProjectService;
  let documentService: DocumentService;
  let apiErrorService: ApiErrorService;
  let serverError: string;
  let messageCountService: MessageCountService;
  let evt: Event;
  let errorsAndWarningsPanelService: ErrorsAndWarningsPanelService;
  let sharedJobHeaderService: SharedJobHeaderService;
  let commonService: CommonServiceService;
  let toasterService: ToasterService;
  let historyService: HistoryService;
  let globalSearchService: GlobalSearchService;

  const originReset = TestBed.resetTestingModule;

  const event = {
    urlType: 'Redirect',
    urlPath: 'home-page-list/63/202661/work-packages/1944916/work-package',
  } as unknown as Event;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, TranslateModule.forRoot(), HttpClientTestingModule, AppRoutingModule,
        OktaAuthModule, NotificationModule, BrowserAnimationsModule],
      declarations: [
        AppComponent,
        HeaderComponent,
        FooterComponent,
        LoginComponent,
      ],
      providers: [
        { provide: OktaAuthService, useClass: OktaServiceMock },
        {
          provide: 'environment',
          useValue: environment,
        },
        { provide: GlobalSearchService, useClass: GlobalSearchServiceMock },
        CommonServiceService,
        ToasterService,
        MessageCountService,
        CookieService,
        AppConstants,
        JobHeaderService,
        WorkflowPopupService,
        JobsServicesService,
        CreditProjectService,
        DocumentService,
        NotificationService,
        ApiErrorService,
        WorkPackageCommonService,
        ErrorsAndWarningsPanelService,
        SharedJobHeaderService,
        CommonServiceService,
        HistoryService,
        {
          provide: Router,
          useClass: class {
            navigate = jasmine.createSpy('navigate');
            routerState = {
              snapshot: { url: 'error=access_denied' },
            };
            events = new Observable((observer) => {
              observer.next(new NavigationEnd(0, '', ''));
              observer.complete();
            });
          },
        },
        {
          provide: NotificationService, useValue: {
            show(): NotificationSettings {
              return {
                content: '.',
                animation: { type: 'fade', duration: 100 },
                position: { horizontal: 'center', vertical: 'top' },
                type: { style: 'success', icon: true },
                height: 50,
                closable: false,
              };
            },
          },
        }
      ],
      schemas: [NO_ERRORS_SCHEMA, NO_ERRORS_SCHEMA],
    });
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(AppComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
    injector = getTestBed();
    router = injector.inject(Router);
    workflowPopupService = injector.inject(WorkflowPopupService);
    userInfoService = injector.inject(UserInfoService);
    jobService = injector.inject(JobsServicesService);
    creditProjectService = injector.inject(CreditProjectService);
    documentService = injector.inject(DocumentService);
    messageCountService = injector.inject(MessageCountService);
    apiErrorService = injector.inject(ApiErrorService);
    errorsAndWarningsPanelService = injector.inject(ErrorsAndWarningsPanelService);
    sharedJobHeaderService = injector.inject(SharedJobHeaderService);
    toasterService = fixture.componentRef.injector.get(ToasterService); // As it was used in component level provider.
    commonService = fixture.componentRef.injector.get(CommonServiceService); // As it was used in component level provider.
    historyService = injector.inject(HistoryService);
    globalSearchService = injector.inject(GlobalSearchService);
    localStorage.setItem('okta-cache-storage', 'test');
    localStorage.setItem('okta-token-storage', 'test');
    const newElement = document.createElement('div');
    newElement.setAttribute('id', 'page-mask');
    spyOn(URL, 'createObjectURL').and.callFake(() => { });
    document.body.appendChild(newElement);
    component.routerOutlet = {
      component: LoginComponent,
      isActivated: true,
    } as unknown as RouterOutlet;
    serverError = 'server error';
    evt = { urlPath: 'Jobs/Export/78/28186/28186_abcCopy.json', urlType: 'Download' } as unknown as Event;
  });

  afterEach(() => {
    const newElement = document.querySelector('#page-mask');
    document.body.removeChild(newElement);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should set the notification count on calling ngOnInit`, () => {
    component.ngOnInit();
    expect(+localStorage.getItem('notificationCount')).toBe(0);
  });

  it(`should set the browser validation on calling ngOnInit`, () => {
    spyOnProperty(window.navigator, 'userAgent', 'get').and.returnValue('chrome');
    component.ngOnInit();
    expect(component.browserValidation).toBe(false);
  });

  it(`should set the browser validation as true on calling ngOnInit`, () => {
    spyOnProperty(window.navigator, 'userAgent', 'get').and.returnValue('trident/7.0');
    component.ngOnInit();
    expect(component.browserValidation).toBe(true);
  });

  it(`should set minHeight to content-container on calling ngAfterViewInit`, () => {
    fixture.detectChanges();
    const contentContainer: HTMLElement = document.querySelector('.content-container');
    component.ngAfterViewInit();
    expect(contentContainer.style.minHeight).not.toBeNull();
  });


  it(`should emit true for on calling openNotificationPanel`, () => {
    const spy = spyOn(messageCountService.isMessagePanelOpen$, 'next');
    const e = { stopPropagation: () => { } } as Event;
    component.openNotificationPanel(e);
    expect(spy).toHaveBeenCalledWith(true);
  });

  it('should call showWorkflowPopup function to enable workflowPopup panel when workflowpopupService return true ', () => {
    const spyFunction = spyOn(component, 'showWorkflowPopup');
    workflowPopupService.workflowPopup = new BehaviorSubject(true);
    component.enableWorkflowPanel();
    expect(spyFunction).toHaveBeenCalled();
  });

  it('should not call showWorkflowPopup function when workflowpopupService return false', () => {
    const spyFunction = spyOn(component, 'showWorkflowPopup');
    workflowPopupService.workflowPopup = new BehaviorSubject(false);
    component.enableWorkflowPanel();
    expect(spyFunction).toHaveBeenCalledTimes(0);
  });

  it('should set showNotification to true if current component is not JobsListComponent on calling enableNotification', () => {
    const spyGetUserId = spyOn(userInfoService, 'getUserId');
    messageCountService.isMessagePanelOpen$.next(true);
    component.enableNotification();
    expect(component.messageContainerConfig.showPopover).toBe(true);
    expect(component.docWidth).toBeLessThan(800);
    expect(spyGetUserId).toHaveBeenCalled();
    expect(component.showNotification).toBe(true);
  });

  it('should set showNotification to false if isMessagePanelOpen$ is false on calling enableNotification', () => {
    spyOn(userInfoService, 'getUserId');
    messageCountService.isMessagePanelOpen$.next(false);
    component.enableNotification();
    expect(component.showNotification).toBe(false);
  });

  it('should set showNotification to true on calling enableNotification', () => {
    spyOn(userInfoService, 'getUserId');
    component.headerComponent = {
      notificationContainer: 'test' as unknown as ElementRef<any>,
    } as HeaderComponent;
    messageCountService.isMessagePanelOpen$.next(true);
    component.enableNotification();
    expect(component.messageContainerConfig.notificationContainer).toBe(component.headerComponent.notificationContainer);
    expect(component.showNotification).toBe(true);
  });

  it('should hide notification side panel when hideNotification function is called', () => {
    const spyFunction = spyOn(messageCountService.isMessagePanelOpen$, 'next');
    component.hideNotification();
    expect(component.showNotification).toBe(false);
    expect(spyFunction).toHaveBeenCalledWith(false);
  });

  it('should show workflow side panel when showWorkflowpopup function is called', () => {
    fixture.detectChanges();
    component.showWorkflowPopup();
    expect(component.showWorkflowPanel).toBe(true);
  });

  it('should hide workflow side panel when hideWorkflowpopup function is called', () => {
    fixture.detectChanges();
    component.hideWorkflowPopup();
    expect(component.showWorkflowPanel).toBe(false);
  });

  it('should download document if urlType is equal to Download on calling clickAction', () => {
    spyOn(jobService, 'downloadDocument').and.returnValue(Observable.of({ name: '28186_abcCopy.json', file: new Blob() }));
    const downloadDummyElement = document.createElement('a');
    spyOn(document, 'getElementById').and.returnValue(downloadDummyElement);
    component.clickAction(evt);
    expect(jobService.downloadDocument).toHaveBeenCalled();
  });

  it('should call error service when calling downloadDocument throws error', () => {
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(jobService, 'downloadDocument').and.returnValue(Observable.throwError({ error: { messages: serverError } }));
    component.downloadJobsFile('Jobs/Export/78/28186/28186_abcCopy.json');
    expect(apiErrorService.show).toHaveBeenCalledWith(serverError);
  });

  it('should call downloadPDF of globalSearchService on calling downloadShippingHistoryFile', () => {
    spyOn(globalSearchService, 'downloadPDF').and.returnValue(Observable.of({ file: '' }));
    component.downloadShippingHistoryFile('orderrepository/28186/28186_abcCopy.json');
    expect(globalSearchService.downloadPDF).toHaveBeenCalled();
  });

  it('should call error service when calling downloadPDF throws error', () => {
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(globalSearchService, 'downloadPDF').and.returnValue(Observable.throwError({ error: { messages: serverError } }));
    component.downloadShippingHistoryFile('orderrepository/28186/28186_abcCopy.json');
    expect(apiErrorService.show).toHaveBeenCalledWith(serverError);
  });

  it('should show error when clickAction method called', () => {
    evt['urlType'] = 'Redirect';
    const spyJobService = spyOn(jobService, 'LockAndUnLockJob').and.returnValue(Observable.throwError({
      error: {
        messages: serverError,
      },
    }));
    spyOn(apiErrorService, 'show');
    component.clickAction(evt);
    expect(spyJobService).toHaveBeenCalled();
    expect(apiErrorService.show).toHaveBeenCalled();
  });

  it('should navigate to job details page on calling clickAction', () => {
    evt['urlType'] = 'Redirect';
    const spywindow = spyOn(window, 'open');
    const spyJobService = spyOn(jobService, 'LockAndUnLockJob').and.returnValue(Observable.throwError({ status: 409 }));
    spyOn(apiErrorService, 'show');
    component.clickAction(evt);
    expect(spyJobService).toHaveBeenCalled();
    expect(spywindow).toHaveBeenCalledWith(evt['urlPath'], evt['urlPath']);
  });

  it('should navigate to job details page of the exported job if urlType is equal to Redirect', () => {
    evt['urlType'] = 'Redirect';
    const spywindow = spyOn(window, 'open');
    spyOn(userInfoService, 'getUserId').and.returnValue('ccfbhj');
    const spyLock = spyOn(jobService, 'LockAndUnLockJob').and.returnValue(Observable.of({
      userId: 'ccfbsb',
      nameFirst: 'First',
      nameLast: 'Last',
    }));
    component.clickAction(evt);
    expect(spyLock).toHaveBeenCalledWith({ jobId: '78', drAddressId: '28186', userId: 'ccfbhj', lockJob: true, allowLockOverride: true });
    expect(spywindow).toHaveBeenCalledWith(evt['urlPath'], evt['urlPath']);
  });

  it(`should download credit project file if urlType is equal to Download and urlPath contains
  {Jobs/CreditProjects} on calling clickAction`, () => {
    evt['urlType'] = 'Download';
    evt['urlPath'] = 'Jobs/CreditProjects/1310916/1310916.xlsx';
    spyOn(creditProjectService, 'downloadDocument').and.returnValue
      (Observable.of({ name: 'Jobs_CreditProjects_1310916_1310916.xlsx', file: new Blob() }));
    const downloadDummyElement = document.createElement('a');
    spyOn(document, 'getElementById').and.returnValue(downloadDummyElement);
    component.clickAction(evt);
    expect(creditProjectService.downloadDocument).toHaveBeenCalled();
  });

  it(`should download shipping history file if urlType is equal to Download and urlPath contains
  {orderreport/} on calling clickAction`, () => {
    evt['urlType'] = 'Download';
    evt['urlPath'] = 'orderreport/1310916/1310916.pdf';
    spyOn(globalSearchService, 'downloadPDF').and.returnValue
      (Observable.of({ file: new Blob() }));
    const downloadDummyElement = document.createElement('a');
    spyOn(document, 'getElementById').and.returnValue(downloadDummyElement);
    component.clickAction(evt);
    expect(globalSearchService.downloadPDF).toHaveBeenCalled();
  });

  it('should call error service when calling creditProjectService downloadDocument throws error', () => {
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(creditProjectService, 'downloadDocument').and.returnValue(Observable.throwError({ error: { messages: serverError } }));
    component.downloadCreditProjectFile('Jobs/CreditProjects/1310916/1310916.xlsx');
    expect(apiErrorService.show).toHaveBeenCalledWith(serverError);
  });

  it(`should download credit project history file if urlType is equal to Download and urlPath contains
  {Jobs/CreditProjectHistory} on calling clickAction`, () => {
    evt['urlType'] = 'Download';
    evt['urlPath'] = 'Jobs/CreditProjectHistory/1310916/1310916.xlsx';
    spyOn(historyService, 'downloadDocument').and.returnValue
      (Observable.of({ name: 'Jobs_CreditProjectHistory_1310916_1310916.xlsx', file: new Blob() }));
    const downloadDummyElement = document.createElement('a');
    spyOn(document, 'getElementById').and.returnValue(downloadDummyElement);
    component.clickAction(evt);
    expect(historyService.downloadDocument).toHaveBeenCalled();
  });

  it('should call error service when calling historyService downloadDocument throws error', () => {
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(historyService, 'downloadDocument').and.returnValue(Observable.throwError({ error: { messages: serverError } }));
    component.downloadCreditProjectHistoryFile('Jobs/CreditProjectHistory/1310916/1310916.xlsx');
    expect(apiErrorService.show).toHaveBeenCalledWith(serverError);
  });

  it(`should download document gen file if urlType is equal to Download and urlPath contains
  {documentgeneration} on calling clickAction`, () => {
    evt['urlType'] = 'Download';
    evt['urlPath'] = 'documentgeneration/122/14861/705/22';
    spyOn(documentService, 'getDocumentFileDownload').and.returnValue
      (Observable.of({ name: 'File.zip', file: new Blob() }));
    const downloadDummyElement = document.createElement('a');
    spyOn(document, 'getElementById').and.returnValue(downloadDummyElement);
    component.clickAction(evt);
    expect(documentService.getDocumentFileDownload).toHaveBeenCalledWith(122, 14861, 705, 22);
  });

  it('should call error service when calling creditProjectService downloadDocument throws error', () => {
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(documentService, 'getDocumentFileDownload').and.returnValue(Observable.throwError({ error: { messages: serverError } }));
    component.downloadDocGenFile('documentgeneration/122/14861/705/22');
    expect(apiErrorService.show).toHaveBeenCalledWith(serverError);
  });

  it('should call showErrorsPopup to enable errors and warnings panel when errors and warnings panel service returns true ', () => {
    const spyFunction = spyOn(component, 'showErrorsAndWarningsPanel');
    errorsAndWarningsPanelService.errorsAndWarningsPanel = new BehaviorSubject(true);
    component.enableErrorsAndWarningsPanel();
    expect(spyFunction).toHaveBeenCalled();
  });

  it('should not call showErrorsPopup function when errors and warnings panel service returns false', () => {
    const spyFunction = spyOn(component, 'showErrorsAndWarningsPanel');
    errorsAndWarningsPanelService.errorsAndWarningsPanel = new BehaviorSubject(false);
    component.enableErrorsAndWarningsPanel();
    expect(spyFunction).toHaveBeenCalledTimes(0);
  });

  it('should show errors and warnings side panel when showErrorsAndWarningsPanel function is called', () => {
    fixture.detectChanges();
    component.showErrorsAndWarningsPanel();
    expect(component.showErrorAndWarningsPanel).toBe(true);
  });

  it('should hide errors and warnings side panel when hideErrorsAndWarningPanel function is called', () => {
    fixture.detectChanges();
    const spy = spyOn(commonService, 'changeWidth');
    component.hideErrorsAndWarningsPanel();
    expect(component.showErrorAndWarningsPanel).toBe(false);
    expect(component.pinPanel).toBe(false);
    expect(spy).toHaveBeenCalledWith(false);
  });

  it('should set pinPanel to true based if the action id pin on calling pinUnpinErrorsAndWarningPanel', () => {
    fixture.detectChanges();
    const spy = spyOn(commonService, 'changeWidth');
    component.pinUnpinErrorsAndWarningPanel('pin');
    expect(spy).toHaveBeenCalledWith(true);
    expect(component.pinPanel).toBe(true);
  });

  it('should set pinPanel to false based if the action id unpin on calling pinUnpinErrorsAndWarningPanel', () => {
    fixture.detectChanges();
    const spy = spyOn(commonService, 'changeWidth');
    component.pinUnpinErrorsAndWarningPanel('unpin');
    expect(spy).toHaveBeenCalledWith(false);
    expect(component.pinPanel).toBe(false);
  });

  it('should call redirectToScope when urlPath contains work-packages and urlType is Redirect on clickAction', () => {
    const spy = spyOn(component, 'redirectToScope');
    component.clickAction(event);
    expect(spy).toHaveBeenCalled();
  });

  it('should open the scope screen on clickAction when click on work package notification', () => {
    const spyWindow = spyOn(window, 'open');
    component.clickAction(event);
    expect(spyWindow).toHaveBeenCalledWith(event['urlPath']);
  });

  it('should set isClickInErrorsPanel in header component on clicking anywhere in errors panel', () => {
    component.headerComponent = {
      isClickInErrorsPanel: false,
    } as HeaderComponent;
    component.setClickInErrorsPanel();
    expect(component.headerComponent.isClickInErrorsPanel).toBe(true);
  });

  it(`should call startPreValidation.next with true value and clickRefreshIcon,
  triggerPreValidation method when input to the method is true`, () => {
    component.headerComponent = { clickRefreshIcon: () => { } } as HeaderComponent;
    const startPreValidationSpy = spyOn(commonService.startPreValidation, 'next');
    const refreshIconTriggerSpy = spyOn(component.headerComponent, 'clickRefreshIcon');
    component.triggerPreValidations(true);
    expect(startPreValidationSpy).toHaveBeenCalledWith(true);
    expect(refreshIconTriggerSpy).toHaveBeenCalledWith();
  });

  it(`should not call startPreValidation.next with true value and clickRefreshIcon,
  triggerPreValidation method when input to the method is false`, () => {
    component.headerComponent = { clickRefreshIcon: () => { } } as HeaderComponent;
    const startPreValidationSpy = spyOn(commonService.startPreValidation, 'next');
    const refreshIconTriggerSpy = spyOn(component.headerComponent, 'clickRefreshIcon');
    component.triggerPreValidations(false);
    expect(startPreValidationSpy).not.toHaveBeenCalled();
    expect(refreshIconTriggerSpy).not.toHaveBeenCalled();
  });

  it('should open to scope screen on redirectToScope', () => {
    // Arrange
    const spyWindow = spyOn(window, 'open');
    // Act
    component.redirectToScope(event);
    // Assert
    expect(spyWindow).toHaveBeenCalledWith(event['urlPath']);
  });
});
