import { CommonModule, CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ExcelModule, GridModule } from '@progress/kendo-angular-grid';
import { IconsModule } from '@progress/kendo-angular-icons';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { NumberPipe } from '@progress/kendo-angular-intl';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { MenusModule } from '@progress/kendo-angular-menu';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { UploadModule } from '@progress/kendo-angular-upload';
import { SalesWebWorkpackageLibraryModule, WorkPackageEffects, workPackageReducer } from '@tsmt/salesweb-workpackagemodule';
import { GridFilterService } from '@tsmt/shared-core-salesweb';
import { environment } from '../../../environments/environment';
import { SharedModule } from '../../shared/modules/shared/shared.module';

@NgModule({
  declarations: [],
  imports: [
    ButtonsModule,
    CommonModule,
    DropDownsModule,
    ExcelModule,
    GridModule,
    DialogModule,
    LayoutModule,
    SharedModule,
    DateInputsModule,
    UploadModule,
    FormsModule,
    InputsModule,
    TreeViewModule,
    MenusModule,
    IndicatorsModule,
    IconsModule,
    SalesWebWorkpackageLibraryModule.forRoot(environment),
    StoreModule.forRoot({ workPackage: workPackageReducer }),
    EffectsModule.forRoot([WorkPackageEffects]),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
      logOnly: environment.production, // Restrict extension to log-only mode
    }),
  ],
  providers: [GridFilterService, NumberPipe, CurrencyPipe, DecimalPipe, DatePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
})
export class WorkPackageModule { }
