import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DialogModule, WindowModule } from '@progress/kendo-angular-dialog';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ExcelModule, FilterService, GridModule } from '@progress/kendo-angular-grid';
import { IconModule } from '@progress/kendo-angular-icons';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { UploadModule } from '@progress/kendo-angular-upload';
import { CreditProjectModuleReducer, OrdersModuleEffects, OrdersModuleReducer, SalesWebOrdersModule } from '@tsmt/salesweb-ordersmodule';
import { GridFilterService as SharedGridFilterService } from '@tsmt/shared-core-salesweb';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
// officeSelector
import { OfficeSelectorComponent } from '../../shared/components/office-selector/office-selector.component';
import { SharedModule } from '../../shared/modules/shared/shared.module';
import { GridFilterService } from '../jobs-list-master/services/grid-filter.service';
import { TraneSalesBusinessDataService } from '../jobs-list-master/services/trane-sales-business-data.service';
import { ProjectComponent } from './components/project/project.component';
import { OrdersRoutingModule } from './orders-routing.module';
import { OrdersComponent } from './orders.component';

@NgModule({
  declarations: [
    OrdersComponent,
    ProjectComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    DialogModule,
    DropDownsModule,
    ExcelModule,
    GridModule,
    LayoutModule,
    TooltipModule,
    OrdersRoutingModule,
    ButtonsModule,
    ReactiveFormsModule,
    FormsModule,
    DatePickerModule,
    InputsModule,
    WindowModule,
    StoreModule.forRoot({ creditProject: CreditProjectModuleReducer }),
    StoreModule.forFeature('ordersModule', OrdersModuleReducer),
    EffectsModule.forRoot([OrdersModuleEffects]),
    InfiniteScrollModule,
    UploadModule,
    IndicatorsModule,
    IconModule,
    SalesWebOrdersModule
  ],
  entryComponents: [
    OfficeSelectorComponent,
  ],
  providers: [DatePipe, CurrencyPipe, GridFilterService, SharedGridFilterService, TraneSalesBusinessDataService, FilterService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
})
export class OrdersModule { }
