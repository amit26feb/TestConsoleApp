import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TSMTMenuGuard } from '../../auth/menu-guard.service';
import { ProjectComponent } from './components/project/project.component';
import { OrdersComponent } from './orders.component';
import { ExitComponent, RouteGuard } from '@tsmt/shared-core-salesweb';
import {
  CreditProjectDocumentsComponent, ChangeOrdersComponent, CreateCreditProjectComponent,
  CreditProjectDetailsComponent, EditCreditProjectComponent, JobHistoryComponent, SalesOrderComponent, CreateCreditProjectGuard
  , ShipToChangeComponent, ShipmentDetailsComponent, SoldToChangeComponent, PoAddendumChangeOrderComponent,
} from '@tsmt/salesweb-ordersmodule';

const orderRoutes: Routes = [
  {
    path: '',
    component: OrdersComponent,
    children: [
      {
        path: '',
        component: ProjectComponent,
      },
      {
        path: 'CreditJobs/:creditJobId/SalesOrders',
        component: SalesOrderComponent,
      },
      {
        path: `CreditJobs/:creditJobId/SalesOrders/:salesOrderId/` +
          `LegacyOrder/:legacyOrderNumber/PsNumber/:plannedShipmentNbr/ShipmentDetails`,
        component: ShipmentDetailsComponent,
      },
      {
        path: ':creditJobId/sales-order-details-exit',
        component: ExitComponent,
      },
      {
        path: 'CreditJobs/:creditJobId/credit-project-details',
        component: CreditProjectDetailsComponent,
      },
      {
        path: ':creditJobId/credit-project-details-exit',
        component: ExitComponent,
      },
      {
        path: 'CreditJobs/:creditJobId/History',
        component: JobHistoryComponent,
      },
      {
        path: 'shipment-details-exit',
        component: ExitComponent,
      },
      {
        path: 'history-exit',
        component: ExitComponent,
      },
      {
        path: 'credit-project-exit',
        component: ExitComponent,
      },
      {
        path: 'sales-order-exit',
        component: ExitComponent,
      },
      {
        path: 'change-order-exit',
        component: ExitComponent,
      },
      {
        path: 'assign-sales-orders',
        component: ExitComponent,
      },
      {
        path: 'CreditJobs/:creditJobId/change-orders',
        component: ChangeOrdersComponent,
      },
      {
        path: 'salesOffice/:salesOfficeId/Jobs/:jobId/Bids/:bidId/create-credit-project',
        canActivate: [CreateCreditProjectGuard],
        component: CreateCreditProjectComponent,
      },
      {
        path: 'CreditProject/:creditJobId/Edit',
        component: EditCreditProjectComponent,
      },
      {
        path: 'CreditProject/:creditJobId/SoldToChange',
        canActivate: [RouteGuard],
        component: SoldToChangeComponent,
      },
      {
        path: 'CreditProjects/:creditJobId/PoAddendumChange',
        canActivate: [RouteGuard],
        component: PoAddendumChangeOrderComponent,
      },
      {
        path: 'credit-project/:creditJobId/ship-to-change',
        canActivate: [RouteGuard],
        component: ShipToChangeComponent,
      },
      {
        path: ':creditJobId/ChangeType/:changeOrderType/Documents',
        canActivate: [RouteGuard],
        component: CreditProjectDocumentsComponent,
      },
      {
        path: 'edit-credit-project-exit',
        component: ExitComponent,
      },
      {
        path: 'cost-forecast-exit',
        component: ExitComponent,
      },
      {
        path: 'CreditJobs/:creditJobId',
        children: [
          {
            path: 'billing',
            loadChildren: () => import('@tsmt/salesweb-billingmodule').then((module) => module.SaleswebBillingModule),
            canActivate: [TSMTMenuGuard],
            data: { routeName: 'billing' },
          },
          {
            path: 'cost-forecast',
            loadChildren: () => import('@tsmt/cost-forecast').then((module) => module.CostForecastModule),
            canActivate: [TSMTMenuGuard],
            data: { routeName: 'cost-forecast' },
          },
          {
            path: 'defect-resolution',
            loadChildren: () => import('@tsmt/salesweb-ordersmodule').then((module) => module.SalesWebOrdersModule),
            canActivate: [TSMTMenuGuard],
            data: { routeName: 'order-line-details' },
          },
          {
            path: '',
            loadChildren: () => import('@tsmt/salesweb-ordersmodule').then((module) => module.SalesWebOrdersModule),
            canActivate: [TSMTMenuGuard],
            data: { routeName: 'assign-sales-orders' },
          },
        ],
      },
    ],
  },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(orderRoutes),
  ],
  exports: [RouterModule],
})
export class OrdersRoutingModule { }
