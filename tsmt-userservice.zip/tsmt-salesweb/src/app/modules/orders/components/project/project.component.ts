import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  IFilePayloadModel, IOrderLineSummariesModel, IPlannedShipmentColumnModel,
  IPlannedShipmentDetail, IProjectPagingItems, IProjectShippingHistoryPagingItems, ISalesOrdersList, ISearchProjectModel,
  ISearchProjectShippingHistoryModel, ISelectEvent, IShippingHistoryPayloadModel, IToggleData, ProjectType, SalesOrderService
} from '@tsmt/salesweb-ordersmodule';
import { TraneSalesBusinessDataService } from '@tsmt/shared-acquisition-dataservices';
import { ILockUser, LoaderService, ToasterService } from '@tsmt/shared-core';
import { ApiErrorService, CommonService as CommonServiceService, JobHeaderService, OfficeSelectorService, UserInfoService } from '@tsmt/shared-core-salesweb';
import { Subscription, timer } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { isDeployedToProd, isDeployedToStage } from '../../../../../environments/environment-helper';
import { AppConstants } from '../../../../shared/constants/constants';
import { GlobalSearchService } from '../../../../shared/services/global-search.service';
import { ProjectService } from '../../../../shared/services/project.service';
import { DisplayModeEnum } from '../../../../shared/enums/display-mode-enum';
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ProjectComponent implements OnInit, AfterViewInit, OnDestroy {
  public enableMirrorSalesOrder: boolean = environment.enableMirrorSalesOrder;
  salesOrderUrl: string;
  copiedDown: string;
  public projectHeaderColumns: IPlannedShipmentColumnModel[];
  public shippingHistoryHeaderColumns: IPlannedShipmentColumnModel[];
  public tabName: string;
  public searchVal: string;
  public skip = 0;
  public take = 50;
  public downloadFileName: string;
  public drAddressId: number;
  public salesOfficeId: number;
  public projectDetails: IProjectPagingItems[];
  public projectShippingHistoryDetails: IProjectShippingHistoryPagingItems[];
  public projectDetailsWithoutHighlighting: IProjectPagingItems[];
  public projectShippingHistoryDetailsWithoutHighlighting: IProjectShippingHistoryPagingItems[];
  public plannedShipmentColumns: IPlannedShipmentColumnModel[];
  public toggleData: IToggleData[];
  public isSalesOrderExpanded: boolean[][];
  public searchColumns = [
    'jobName',
    'legacyCreditJobNumber',
    'creditJobName',
    'customerAccountNumber',
    'r12SiteNumber',
    'r12CustomerNumber',
    'purchaseOrderNumber',
    'jobContactPersonName',
    'salesPersonName',
    'orderName',
    'serialNumber',
  ];
  public projectExpand: boolean[] = [];
  public salesOrderList = [];
  public salesOrderId: number[];
  public salesOrderListArray = [];
  public orderLinesResponse: IOrderLineSummariesModel[];
  showLoader: boolean;
  shippingInstrArray: any[];
  plannedShipmentDetailsArray: IPlannedShipmentDetail[];
  public scrollDistance = 0;
  public scrollThrottle = 100;
  public totalItemCount: number;
  public isInitialLoad = true;
  public isExpandAll = false;
  public isExpandedView = false;
  public existingProjArray = 0;
  public infoData: string;
  public displayMode = '';
  public progress = false;
  public selectedIndex = -1;
  public isProdOrStageEnvironment = isDeployedToProd() || isDeployedToStage();
  isProjectTransmitted: boolean;
  updateGridRecordTimer: Subscription;
  searchSubscription: Subscription;
  isDeletedRecord: boolean;
  public enableRebalancing: boolean = environment.enableRebalancing;
  public transmitBalanceInfo = this.appConstants.TRANSMIT_BALANCE_INFO;
  public shippingHistoryPayload: IShippingHistoryPayloadModel;
  public downloadFilePayload: IFilePayloadModel;
  currentUserDetail: ILockUser;
  public enableCopyDown: boolean = environment.enableCopyDown;
  public untransmittedStatusColumn = {
    columnName: '',
    class: 'untransmitted',
  } as IPlannedShipmentColumnModel;
  public transmittedStatusColumn = {
    columnName: '',
    class: 'transmitted',
  } as IPlannedShipmentColumnModel;
  enableLockStatus: boolean = environment.enableLockStatus;
  constructor(
    public globalSearchService: GlobalSearchService,
    public officeSelectorService: OfficeSelectorService,
    private appConstants: AppConstants,
    private loaderService: LoaderService,
    private apiErrorService: ApiErrorService,
    private salesOrderService: SalesOrderService,
    public traneSalesBusinessDataService: TraneSalesBusinessDataService,
    private commonService: CommonServiceService,
    private toasterService: ToasterService,
    private projectService: ProjectService,
    private headerService: JobHeaderService,
    private userService: UserInfoService,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.globalSearchService.TabName.subscribe((data) => {
      this.tabName = data;
    });
    this.searchSubscription = this.globalSearchService.searchValue.subscribe((data) => {
      this.searchVal = data;
      this.projectDetailsWithoutHighlighting = [];
      this.projectShippingHistoryDetailsWithoutHighlighting = [];
      if (this.tabName === 'Projects' && this.searchVal !== '') {
        this.skip = 0;
        this.projectDetails = [];
        this.projectShippingHistoryDetails = [];
        this.projectExpand = [];
        this.fetchProjectDetails();
      } else {
        this.projectDetails = [];
        this.projectShippingHistoryDetails = [];
      }
    });
    this.buildProjectHeaderColumns('Transmitted');
    this.shippingHistoryHeaderColumns = this.appConstants.SHIPPING_HISTORY_HEADER_COLUMNS;
    this.plannedShipmentColumns = this.appConstants.PLANNED_SHIPMENT_COLUMNS;
    this.toggleData = [
      {
        title: 'Transmitted',
        infoText: 'You are viewing Transmitted information',
      },
      {
        title: 'Untransmitted',
        infoText: 'You are viewing Untransmitted information',
      },
      {
        title: 'History',
        infoText: 'You are viewing only Historical Jobs',
      },
      {
        title: 'Shipping History',
        infoText: 'You are viewing Shipping History information',
      },
    ];
    this.setToggleDefault();
    this.salesOrderService.apiBaseUrl = this.commonService.getBaseUrl(this.displayMode, this.drAddressId);
    this.fetchSalesOfficeList();
    timer(15000, 15000).subscribe(() => {
      this.isDeletedRecord = Boolean(localStorage.getItem('deleteCreditProject'));
      if (this.isDeletedRecord) {
        this.projectDetails = [];
        this.fetchProjectDetails();
        localStorage.removeItem('deleteCreditProject');
      }
    });
    this.currentUserDetail = { userId: this.userService.getUserId() } as ILockUser;
  }

  ngAfterViewInit(): void {
    this.loaderService.hide();
  }

  ngOnDestroy(): void {
    this.isSalesOrderExpanded = [];
    localStorage.removeItem('deleteCreditProject');
    this.searchSubscription?.unsubscribe();
  }

  // fetches the sales offices list
  fetchSalesOfficeList(): void {
    this.officeSelectorService.getSelectedOffice().subscribe((val) => {
      this.projectDetails = [];
      this.projectDetailsWithoutHighlighting = [];
      this.projectShippingHistoryDetails = [];
      this.projectShippingHistoryDetailsWithoutHighlighting = [];
      this.drAddressId = val.drAddressId;
    });
    this.officeSelectorService.getOfficeSelectorList().subscribe((data) => {
      this.salesOrderList = data.map((a) => a.drAddressId);
    });
  }

  // functionality for expanding and collapsing individual rows for selected arrow
  expandProjectContent(i: number): void {
    this.isSalesOrderExpanded[i] = [];
    this.projectDetails.forEach((data, index) => {
      if (index === i) {
        this.projectExpand[i] = !this.projectExpand[i];
      } else {
        this.projectExpand[index] = false;
      }
    });
    this.isExpandAll = this.projectExpand.includes(true);
  }

  // Fetches the project details
  fetchProjectDetails(): void {
    this.isInitialLoad = false;
    this.loaderService.show();
    let drAddressIds;
    if (this.displayMode === DisplayModeEnum.Untransmitted) {
      drAddressIds = [this.route.snapshot.params['drAddressId']];
    } else {
      drAddressIds = this.salesOrderList;
    }
    if (this.displayMode !== this.appConstants.ShippingHistoryDisplayMode) {
      this.globalSearchService.getOrderList(this.skip, this.take, drAddressIds, this.displayMode).subscribe((data: ISearchProjectModel) => {
        if (data !== null && data.pagingItems.length > 0) {
          this.projectDetails.push(...data.pagingItems);
          this.totalItemCount = data.totalItemCount;
          this.loadExpandedSalesOrder();
          this.setJobContactPersonName();
          // storing the project details data before highlighting the searched value for the title
          this.projectDetailsWithoutHighlighting.push(...JSON.parse(JSON.stringify(data.pagingItems)));
          this.highlightSearchText();
          this.setStatusIconColumnWidth();
        }
        this.loaderService.hide();
      }, (err: HttpErrorResponse) => {
        this.apiErrorService.show(err.error?.messages);
        this.loaderService.hide();
      });
    } else {
      this.shippingHistoryPayload = {
        skip: this.skip,
        take: this.take,
        sort: [{ sortBy: 'serialNumber', sortDirection: 'Ascending' }],
        filters: [{
          columnFilters: [
            { field: 'orderName', operator: 'contains', value: this.searchVal },
            { field: 'serialNumber', operator: 'contains', value: this.searchVal }
          ],
          logic: 'or'
        }],
      };
      this.globalSearchService.getShippingHistory(this.shippingHistoryPayload).subscribe((data: ISearchProjectShippingHistoryModel) => {
        if (data !== null && data.pagingItems.length > 0) {
          this.projectShippingHistoryDetails.push(...data.pagingItems);
          if (this.skip === 0) {
            this.totalItemCount = data.totalItemCount;
          }
          // storing the project details data before highlighting the searched value for the title
          this.projectShippingHistoryDetailsWithoutHighlighting.push(...JSON.parse(JSON.stringify(data.pagingItems)));
          this.highlightSearchText();
        }
        this.loaderService.hide();
      }, (err: HttpErrorResponse) => {
        this.apiErrorService.show(err.error.messages);
        this.loaderService.hide();
      });
    }
  }

  /**
   * Sets the status icon and header width by finding the maximun width of all the status icon elements
   */
  setStatusIconColumnWidth(): void {
    if (this.displayMode === DisplayModeEnum.Transmitted) {
      // Used setTimeOut to run below thread once all the main threads has been completed
      // So that offSetWidth of all the elements will be available
      setTimeout(() => {
        const statusIconElements: HTMLElement[] = Array.from(document.querySelectorAll('.status-icon'));
        const headerElement: HTMLElement = document.querySelector('.transmitted');
        // Finding the max width of all the elements
        const maxWidth = Math.max.apply(Math, statusIconElements?.map((el: HTMLElement) => el.offsetWidth));
        headerElement.style.width = maxWidth + 'px';
        statusIconElements?.forEach((el: HTMLElement) => {
          el.style.minWidth = maxWidth + 'px';
        });
      });
    }
  }

  // Concatenates job contact person name
  setJobContactPersonName(): void {
    this.projectDetails.forEach((res) => {
      if (res.jobContactPersonLastName && res.jobContactPersonFirstName) {
        res.jobContactPersonName = res.jobContactPersonLastName + ', ' + res.jobContactPersonFirstName;
      } else {
        res.jobContactPersonName = res.jobContactPersonFirstName !== '' ? res.jobContactPersonFirstName : res.jobContactPersonLastName;
      }
    });
  }

  /**
   * Request to download shipping details
   */
  downloadShippingDetails(dataItem: IProjectShippingHistoryPagingItems): void {
    this.progress = true;
    this.downloadFilePayload = {
      orderId: dataItem.orderId,
      serialNumber: dataItem.serialNumber,
      orderName: dataItem.orderName,
      orderBillLetter: dataItem.orderBillLetter,
      orderRevision: dataItem.orderRevision,
      sourceType: 'Current',
    };
    this.globalSearchService.downloadFile(this.downloadFilePayload).subscribe((fileModel) => {
      this.progress = false;
      this.toasterService.setToaster('success', this.appConstants.SHIPPING_HISTORY_DOWNLOAD_REQUEST);
    }, (err: HttpErrorResponse) => {
      this.progress = false;
      this.toasterService.setToaster('error', this.appConstants.DOWNLOAD_ERROR_MESSAGE);
    });
  }

  // Navigate to Credit project page from Projects page.
  navigateToCreditProjectPage(dataItem: IProjectPagingItems, event: Event): void {
    const navigationFrom = 'ProjectLanding';
    if ((this.displayMode === DisplayModeEnum.Transmitted && !dataItem.isCopiedDownCreditJob)
      || this.displayMode === DisplayModeEnum.History) {
      const creditProjectUrl = `/jobs-list/${dataItem.originatingDrAddress}/${dataItem.watcomJobId}/projects/CreditJobs/${dataItem.creditJobId}/credit-project-details?navFrom=${navigationFrom}&projectType=${this.displayMode}`;
      // named window so that it does not duplicate
      window.open(creditProjectUrl, dataItem.originatingDrAddress + '_' +
        dataItem.creditJobId + '_' + dataItem.legacyCreditJobNumber + '_' + this.displayMode);
    } else if (this.displayMode === DisplayModeEnum.Transmitted && dataItem.isCopiedDownCreditJob && this.enableCopyDown) {
      // Setting project type as untransmitted since it has pending changes to be transmitted
      const creditProjectUrl = `/jobs-list/${dataItem.originatingDrAddress}/${dataItem.watcomJobId}/projects/CreditProject/${dataItem.localCreditJobId}/Edit?navFrom=${navigationFrom}&projectType=${ProjectType.Untransmitted}`;
      // named window so that it does not duplicate
      window.open(creditProjectUrl, dataItem.originatingDrAddress + '_' +
        dataItem.creditJobId + '_' + dataItem.legacyCreditJobNumber + '_' + (this.displayMode));
    } else if (this.displayMode === DisplayModeEnum.Transmitted && dataItem.isCopiedDownCreditJob && !this.enableCopyDown) {
      const creditProjectUrl = `/jobs-list/${dataItem.originatingDrAddress}/${dataItem.watcomJobId}/projects/CreditJobs/${dataItem.creditJobId}/credit-project-details?navFrom=${navigationFrom}&projectType=${this.displayMode}`;
      // named window so that it does not duplicate
      window.open(creditProjectUrl, dataItem.originatingDrAddress + '_' +
        dataItem.creditJobId + '_' + dataItem.legacyCreditJobNumber + '_' + (this.displayMode));
    } else {
      const editCreditURL = `/jobs-list/${dataItem.originatingDrAddress}/${dataItem.jobId}/projects/CreditProject/${dataItem.creditJobId}/Edit?navFrom=${navigationFrom}&projectType=${this.displayMode}`;
      window.open(editCreditURL, dataItem.originatingDrAddress + '_' +
        dataItem.creditJobId + '_' + dataItem.legacyCreditJobNumber + '_' + this.displayMode);
    }
    event.preventDefault();
    event.stopPropagation();
  }

  /* Finds the searh value in each row of projectDetails or projectShippingHistoryDetails and
     append with <em> tag to highlight the searched text in project details grid
  */
  highlightSearchText(): void {
    this.searchVal = this.searchVal.toLowerCase();
    const searchlength = this.searchVal.length;
    const projectDetailsHighlight =
      this.displayMode !== this.appConstants.ShippingHistoryDisplayMode ? this.projectDetails : this.projectShippingHistoryDetails;
    projectDetailsHighlight.forEach((orderList) => {
      for (const key in orderList) {
        if (orderList.hasOwnProperty(key) && orderList[key] != null && this.searchColumns.includes(key)) {
          orderList[key] = orderList[key].toString();
          const orderSearchValue = orderList[key].toLowerCase();
          let index = orderSearchValue.indexOf(this.searchVal, 0);
          while (index !== -1) {
            orderList[key] = orderList[key].slice(0, index) + '<em>' + orderList[key].slice(index, index + searchlength) +
              '</em>' + orderList[key].slice(index + searchlength);
            index = orderList[key].indexOf(this.searchVal, index + 9);
          }
        }
      }
    });
  }

  // Navigate to sales orders page from projects page.
  navigateToSalesOrderPage(dataItemProjectDetails: IProjectPagingItems, dataItem: IProjectPagingItems, index: number, event: Event): void {
    if (this.displayMode === DisplayModeEnum.Transmitted && !dataItemProjectDetails.isCopiedDownCreditJob) {
      this.copiedDown = null;
      this.generateSalesOrderUrl(dataItemProjectDetails.originatingDrAddress, dataItemProjectDetails.watcomJobId,
        dataItem.creditJobId, this.displayMode);
    } else if (this.displayMode === DisplayModeEnum.Transmitted && dataItemProjectDetails.isCopiedDownCreditJob && this.enableCopyDown) {
      this.copiedDown = 'CopiedDown';
      this.generateSalesOrderUrl(dataItemProjectDetails.originatingDrAddress, dataItemProjectDetails.watcomJobId,
        dataItemProjectDetails.localCreditJobId, ProjectType.Untransmitted);
    } else if (this.displayMode === DisplayModeEnum.Transmitted && dataItemProjectDetails.isCopiedDownCreditJob &&
      !this.enableCopyDown) {
      this.copiedDown = null;
      this.generateSalesOrderUrl(dataItemProjectDetails.originatingDrAddress, dataItemProjectDetails.watcomJobId,
        dataItemProjectDetails.creditJobId, this.displayMode);
    } else {
      this.copiedDown = null;
      this.generateSalesOrderUrl(dataItemProjectDetails.originatingDrAddress, dataItemProjectDetails.jobId,
        dataItem.creditJobId, this.displayMode);
    }
    // named window so that it does not duplicate
    localStorage.setItem('selectedSalesOrder', index.toString());
    const creditJobId = this.copiedDown ? dataItemProjectDetails.localCreditJobId : dataItem.creditJobId;
    localStorage.setItem(`displayMode-${creditJobId}`, this.displayMode);
    localStorage.setItem(`copiedDown-${creditJobId}`, this.copiedDown);
    window.open(this.salesOrderUrl, dataItemProjectDetails.originatingDrAddress + '_' +
      dataItem.creditJobId + '_' + dataItemProjectDetails.salesPersonName + '_'
      + (this.copiedDown ? (this.displayMode + this.copiedDown) : this.displayMode));
    event.preventDefault();
    event.stopPropagation();
  }

  /**
   * Generate salesOrderUrl to navigate sales order page
   * @param originatingDrAddress - originating DrAddressId
   * @param jobId - JobId or watcomJobId
   * @param creditJobId - host creditJobId or localCreditJobId
   * @param displayMode - displayMode for projectType
   */
  generateSalesOrderUrl(originatingDrAddress: number, jobId: number, creditJobId: number, displayMode: string): void {
    this.salesOrderUrl = `/jobs-list/${originatingDrAddress}/${jobId}/projects/CreditJobs/${creditJobId}/SalesOrders?navFrom=ProjectLanding&projectType=${displayMode}`;
  }

  // loadMore method is to fetch new data when grid is scrolled to the bottom
  loadMore(): void {
    if ((this.displayMode !== this.appConstants.ShippingHistoryDisplayMode && this.projectDetails.length < this.totalItemCount) ||
      (this.displayMode === this.appConstants.ShippingHistoryDisplayMode &&
        this.projectShippingHistoryDetails.length < this.totalItemCount)) {
      this.skip += this.take;
      this.fetchProjectDetails();
    }
  }

  /**
   * Fetch order lines data for selected sales order and grouped by planned shipment number
   * @param salesOrderDetails - sales order details
   * @param salesOrderId - sales order id
   * @param projectIndex - project index
   * @param salesOrderIndex - sales order index
   */
  loadOrderLinesDetails(salesOrderDetails: ISalesOrdersList, salesOrderId: number, projectIndex: number, salesOrderIndex: number): void {
    this.projectDetails.forEach((element, index) => {
      if (index === projectIndex) {
        element.salesOrdersList.forEach((ele, i) => {
          if (i !== salesOrderIndex) {
            this.isSalesOrderExpanded[index][i] = false;
          } else {
            this.isSalesOrderExpanded[projectIndex][salesOrderIndex] = !this.isSalesOrderExpanded[projectIndex][salesOrderIndex];
          }
        });
      }
    });
    this.salesOrderService.getOrderLinesBySalesOrderId(salesOrderId)
      .subscribe((res) => {
        this.orderLinesResponse = res;
        this.shippingInstrArray = [];
        salesOrderDetails.plannedShipmentDetails.forEach((plannedShipment) => {
          plannedShipment.orderLineSummaries = this.orderLinesResponse?.
            filter((orderLine) => orderLine.plannedShipmentNbr === plannedShipment.plannedShipmentNbr);
          plannedShipment.shippingInstArray = [{
            psNumber: plannedShipment.plannedShipmentNbr,
            shippingInstructionId: plannedShipment.shippingInstructionId,
            shippingInstructionDescription: plannedShipment.shippingInstructionDescription,
          }];
        });
        this.salesOrderService.setFirstPlannedShipmentOrderLine$.next(true);
      });
  }

  // load the expanded sales order when fetching more records
  loadExpandedSalesOrder(): void {
    const newProjectArray = new Array(this.projectDetails.length);
    this.existingProjArray = this.isSalesOrderExpanded ? this.isSalesOrderExpanded.length : 0;
    if (this.isSalesOrderExpanded) {
      for (let i = 0; i < this.projectDetails.length - this.existingProjArray; i++) {
        this.isSalesOrderExpanded.push(new Array());
      }
    } else {
      this.isSalesOrderExpanded = new Array(newProjectArray);
    }
    this.projectDetails.forEach((element, index) => {
      if (index > this.existingProjArray) {
        this.isSalesOrderExpanded[index] = [];
        element.salesOrdersList.forEach((ele, i) => {
          this.isSalesOrderExpanded[index][i] = false;
        });
      }
    });
  }

  // toggles the planned shipment grid view
  expandAllPSgrid(): void {
    if (this.projectDetails.length <= 10) {
      this.isExpandAll = !this.isExpandAll;
      this.projectExpand = [];
      this.projectDetails.forEach((data) => {
        this.projectExpand.push(this.isExpandAll);
      });
    }
  }

  /**
   * Sets the default value to the toggle and the info icon
   * * @returns void
   */
  setToggleDefault(): void {
    this.displayMode = this.toggleData[0].title;
    this.infoData = this.toggleData[0].infoText;
  }

  /**
   * Sets the selected toggle value to common service and sets the info icon data based on the current toggle
   *  * @param  {toggleSelectionEvent} - active toggle event
   * * @returns void
   */
  onTabSelect(dataSelectionEvent: ISelectEvent): void {
    this.displayMode = dataSelectionEvent.title;
    this.commonService.setSelectedToggle(this.displayMode);
    this.infoData = this.toggleData.filter((data) => data.title === this.displayMode)[0].infoText;
    this.salesOrderService.apiBaseUrl = this.commonService.getBaseUrl(this.displayMode, this.drAddressId);
    this.fetchSalesOfficeList();
    this.buildProjectHeaderColumns(this.displayMode);
    this.apiErrorService.hide();
  }

  exportToExcel(event: Event, dataItem: IProjectPagingItems): void {
    this.isProjectTransmitted = this.displayMode === DisplayModeEnum.Transmitted;
    this.projectService.exportToExcel(dataItem.originatingDrAddress, dataItem.jobId, dataItem.creditJobId, this.isProjectTransmitted)
      .subscribe((data) => {
        this.toasterService.setToaster('success', this.appConstants.EXPORT_TO_EXCEL_SUCCESS_TOASTER);
      }, (err) => {
        this.toasterService.setToaster('error', this.appConstants.EXPORT_TO_EXCEL_ERROR_TOASTER);
      });
    event.preventDefault();
    event.stopPropagation();
  }

  /**
   * display the header columns
   * @param columnName {string} - takes column name as input
   * @param isIcon - {boolean} - true: show header icon for columns, false: show header heading for columns
   * returns boolean
   */
  canShowColumnHeader(columnName: string, isIcon: boolean): boolean {
    if (isIcon) {
      return (this.canDisplayData() && columnName === 'Date');
    } else {
      if (columnName !== 'Date') {
        return true;
      } else {
        return this.canDisplayData();
      }
    }
  }

  /**
   * display the date data in date column
   * @param isBalanced {boolean} - takes isBalanced as input
   * @param type {string} - accepts type as data or div of the column as input
   * returns boolean
   */
  canShowDateData(isBalanced: boolean, type: string): boolean {
    if (this.enableRebalancing && this.displayMode === 'Transmitted') {
      if (type === 'data') {
        return !isBalanced;
      } else {
        return true;
      }
    }
  }

  /**
   * navigate to the price summary page in new tab
   * @param projectDetails {IProjectPagingItems} - takes project details as input for jobId, drAddressId
   */
  navigateToPriceSummary(projectDetails: IProjectPagingItems): void {
    const priceSummaryUrl = `jobs-list/${projectDetails.watcomJobId}/${projectDetails.originatingDrAddress}/Rebalancing/PriceSummary`;
    window.open(priceSummaryUrl, projectDetails.watcomJobId + '_' + projectDetails.originatingDrAddress);
  }

  /**
   * Sets class for the column header
   * @param className {string} - accepts class name as input
   * returns string
   */
  columnHeaderClass(className: string): string {
    if (className.includes('projectNbr')) {
      return this.canDisplayData() ? 'col-1 px-0 projectNbr' : 'col-2 projectNbr';
    } else {
      return className;
    }
  }

  /**
   * sets class for column data
   * @param columnName {string} - accepts column name as string
   * returns string
   */
  columnDataClass(columnName: string): string {
    switch (columnName) {
      case 'ProjectNumber':
        if (this.enableRebalancing) {
          return this.displayMode === 'Transmitted' ? 'col-1 px-0' : 'col-2 px-3';
        } else {
          return 'col-2';
        }
      case 'CustomerName':
        return this.canDisplayData() ? 'col-2' : 'col-3';
      case 'Excel':
        if (this.canDisplayData()) {
          return 'pl-2';
        }
    }
  }

  // when to display the data
  canDisplayData(): boolean {
    return (this.enableRebalancing && this.displayMode === 'Transmitted');
  }

  onSalesReportIconClick(event: Event): void {
    event.preventDefault();
    event.stopPropagation();
  }

  /**
   * To check for no records
   * * @returns boolean
   */
  checkNoRecords(): boolean {
    return (this.displayMode !== this.appConstants.ShippingHistoryDisplayMode && !this.projectDetails?.length)
      || (this.displayMode === this.appConstants.ShippingHistoryDisplayMode && !this.projectShippingHistoryDetails?.length);
  }

  /**
   * Determines if there is a report to download for a given dataItem.
   * @param {IProjectShippingHistoryPagingItems} - the data item.
   * @returns true if there is a report to download, false otherwise.
   */
  showDownloadLink(dataItem: IProjectShippingHistoryPagingItems): boolean {
    if (dataItem.orderType === 'VO' || dataItem.orderType === 'SIL') {
      return dataItem.filePath && dataItem.filePath !== '';
    } else {
      // mdp orderType, always show a link.
      return true;
    }
  }

  /**
   * Triggered when file icon is clicked
   * @param {IProjectShippingHistoryPagingItems} - payload that contains shipping history details
   */
  downloadReports(dataItem: IProjectShippingHistoryPagingItems, index: number): void {
    this.selectedIndex = index;
    if (dataItem.orderType === 'VO' || dataItem.orderType === 'SIL') {
      this.progress = true;
      this.globalSearchService
        .downloadShippingHistoryReports(dataItem.filePath, dataItem.orderName, dataItem.serialNumber, dataItem.orderType)
        .subscribe((fileModel) => {
          this.progress = false;
          if (fileModel) {
            const element = document.createElement('a');
            element.href = URL.createObjectURL(fileModel.file);
            element.download = fileModel.filename;
            this.downloadFileName = fileModel.filename;
            element.click();
          } else {
            this.toasterService.setToaster('error', this.appConstants.DOWNLOAD_ERROR_MESSAGE);
          }
        }, (err: HttpErrorResponse) => {
          this.progress = false;
          this.toasterService.setToaster('error', this.appConstants.DOWNLOAD_ERROR_MESSAGE);
        });
    } else {
      this.downloadShippingDetails(dataItem);
    }
  }

  /**
   * Gets lock user id detail as ILockUser
   * @param lockUserId lock user id
   * @param lockUserName lock user name
   */
  getLockedUserDetail(lockUserId: string, lockUserName: string): ILockUser {
    return {
      userId: lockUserId,
      displayName: lockUserName,
    } as ILockUser;
  }

  /**
   * Gets formatted credit job/sales order legacy number
   * @param legacyNumber Legacy nummber
   */
  getFormattedLegacyNumber(legacyNumber: string): string {
    if (this.displayMode === 'Untransmitted') {
      return `(${legacyNumber})`;
    }
    return legacyNumber;
  }

  /**
   * Builds project header columns
   * @param projectType Project type
   */
  buildProjectHeaderColumns(projectType: string): void {
    this.projectHeaderColumns = this.appConstants.PROJECT_HEADER_COLUMNS;
    if (projectType === 'Transmitted') {
      this.projectHeaderColumns = [this.transmittedStatusColumn].concat(this.appConstants.PROJECT_HEADER_COLUMNS);
    } else if (projectType === 'Untransmitted') {
      this.projectHeaderColumns = [this.untransmittedStatusColumn].concat(this.appConstants.PROJECT_HEADER_COLUMNS);
    }
  }

  /**
   * Checks and navigate credit project based on transmit status
   * @param dataItemProjectDetails Credit project details
   * @param event Hyperlink click event
   * @param dataItem Sales order details
   * @param index Sales order index
   */
  checkAndNavigateCreditProject(dataItemProjectDetails: IProjectPagingItems, event: Event,
    dataItem?: IProjectPagingItems, index?: number): void {
    if (this.displayMode === DisplayModeEnum.Transmitted) {
      this.projectService.getCreditProjectTransmitStatus(dataItemProjectDetails.originatingDrAddress, dataItemProjectDetails.creditJobId)
      .subscribe((status) => {
        dataItemProjectDetails.isCopiedDownCreditJob = status.isCopiedDown;
        this.navigateCreditProject(dataItemProjectDetails, event, dataItem, index);
      });
    } else {
      this.navigateCreditProject(dataItemProjectDetails, event, dataItem, index);
    }
  }

  /**
   * Navigates credit project to details screen or sales order screen based on dataItem
   * @param dataItemProjectDetails Credit project details
   * @param event Hyperlink click event
   * @param dataItem Sales order details
   * @param index Sales order index
   */
  navigateCreditProject(dataItemProjectDetails: IProjectPagingItems, event: Event,
    dataItem?: IProjectPagingItems, index?: number): void {
    if (dataItem) {
      this.navigateToSalesOrderPage(dataItemProjectDetails, dataItem, index, event);
    } else {
      this.navigateToCreditProjectPage(dataItemProjectDetails, event);
    }
  }
}
