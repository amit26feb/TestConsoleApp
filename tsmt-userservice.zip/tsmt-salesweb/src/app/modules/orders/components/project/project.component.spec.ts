import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { OktaAuthService, OKTA_CONFIG } from '@okta/okta-angular';
import { NotificationService, NotificationSettings } from '@progress/kendo-angular-notification';
import { IProjectPagingItems, IProjectShippingHistoryPagingItems, OrderLineMock, SalesOrderService, SearchProjectMock } from '@tsmt/salesweb-ordersmodule';
import { TraneSalesBusinessDataService } from '@tsmt/shared-acquisition-dataservices';
import { ILockUser, LoaderService, ToasterService } from '@tsmt/shared-core';
import {
  ApiErrorService, CommonService as CommonServiceService, JobHeaderService,
  OfficeSelectorService
} from '@tsmt/shared-core-salesweb';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable, of, Subscription, throwError } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import OktaConfig from '../../../../.okta.config';
import { AppConstants } from '../../../../shared/constants/constants';
import { DisplayModeEnum } from '../../../../shared/enums/display-mode-enum';
import { GlobalSearchService } from '../../../../shared/services/global-search.service';
import { ProjectService } from '../../../../shared/services/project.service';
import { ProjectComponent } from './project.component';
import { ICreditProjectTransmitStatus } from '../../../../shared/model/credit-project-transmit-status-model';

// tslint:disable-next-line:no-big-function
describe('ProjectComponent', () => {
  let component: ProjectComponent;
  let fixture: ComponentFixture<ProjectComponent>;
  const originReset = TestBed.resetTestingModule;
  let globalSearchService: GlobalSearchService;
  let officeSelectorService: OfficeSelectorService;
  let traneSalesBusinessDataService: TraneSalesBusinessDataService;
  let projectsMockData: SearchProjectMock;
  let apiErrorService: ApiErrorService;
  let loaderService: LoaderService;
  let salesOrderService: SalesOrderService;
  let commonService: CommonServiceService;
  let testData: OrderLineMock;
  let toasterService: ToasterService;
  let projectService: ProjectService;
  let appConstants: AppConstants;
  let headerService: JobHeaderService;

  const transmitted = 'Transmitted';
  const unTransmitted = 'UnTransmitted';
  const shippingHistory = 'Shipping History';

  const oktaRoutingConfig = Object.assign({
    onAuthRequired: ({ oktaRouter }) => {
      oktaRouter.navigate(['']);
    },
  }, OktaConfig.oidc);
  const salesOfficeDetail = {
    id: 1117,
  };
  const officeSelected = {
    salesOfficeName: 'Sioux Falls',
    drAddressId: 96,
  };
  const event = {
    preventDefault: () => { return; },
    stopPropagation: () => { return; },
  } as Event;

  const creditProjectTransmitStatus = {
    isTransmitted: false,
    isCopiedDown: true,
    isRemnant: false
  } as ICreditProjectTransmitStatus;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ProjectComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpClient, ApiErrorService, LoaderService, GlobalSearchService, OfficeSelectorService, SalesOrderService, ToasterService,
        TraneSalesBusinessDataService, AppConstants, OktaAuthService, SearchProjectMock, OrderLineMock, CommonServiceService,
        {
          provide: 'environment',
          useValue: environment,
        },
        { provide: OKTA_CONFIG, useValue: oktaRoutingConfig },
        {
          provide: ActivatedRoute, useValue: {
            snapshot: {
              params: { drAddressId: '121' },
            },
          },
        },
        {
          provide: Router, useClass: class {
            navigate = jasmine.createSpy('navigate');
          },
        },
        { provide: globalSearchService, useClass: SearchProjectMock }, JobHeaderService,
        {
          provide: NotificationService, useValue: {
            show(): NotificationSettings {
              return {
                content: '.',
                animation: { type: 'fade', duration: 100 },
                position: { horizontal: 'center', vertical: 'top' },
                type: { style: 'success', icon: true },
                height: 50,
                closable: false,
              };
            },
          },
        }
      ],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectComponent);
    component = fixture.componentInstance;
    const injector = getTestBed();
    globalSearchService = injector.inject(GlobalSearchService);
    officeSelectorService = injector.inject(OfficeSelectorService);
    traneSalesBusinessDataService = injector.inject(TraneSalesBusinessDataService);
    projectsMockData = injector.inject(SearchProjectMock);
    apiErrorService = fixture.componentRef.injector.get(ApiErrorService);
    loaderService = injector.inject(LoaderService);
    salesOrderService = injector.inject(SalesOrderService);
    commonService = injector.inject(CommonServiceService);
    testData = injector.inject(OrderLineMock);
    toasterService = injector.inject(ToasterService);
    projectService = injector.inject(ProjectService);
    appConstants = injector.inject(AppConstants);
    headerService = injector.inject(JobHeaderService);
    fixture.detectChanges();
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('projectExpand should equal to true when expandProjectContent method called', () => {
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.projectExpand = [];
    component.isSalesOrderExpanded = new Array();
    component.expandProjectContent(0);
    expect(component.isSalesOrderExpanded[0]).toEqual([]);
    expect(component.projectExpand).toEqual([true, false]);
  });

  it('projectExpand should equal to false when expandProjectContent method called', () => {
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.projectExpand = [];
    component.isSalesOrderExpanded = new Array();
    component.expandProjectContent(1);
    expect(component.isSalesOrderExpanded[1]).toEqual([]);
    expect(component.projectExpand).toEqual([false, true]);
  });

  it('should call fetchProjectDetails method when tabname and search having value and displayProject is true on ngOnInit()', () => {
    const fetchProjectsSpy = spyOn(component, 'fetchProjectDetails');
    globalSearchService.TabName.next('Projects');
    globalSearchService.searchValue.next('1437419');
    component.ngOnInit();
    expect(component.searchVal).toBe('1437419');
    expect(component.tabName).toBe('Projects');
    expect(fetchProjectsSpy).toHaveBeenCalled();
  });

  it('should fetch the selected drAddressId value when displayMode is Untransmitted when fetchSalesOfficeList() triggered', () => {
    spyOn(officeSelectorService, 'getSelectedOffice').and.returnValue(of(officeSelected));
    component.fetchSalesOfficeList();
    expect(component.projectShippingHistoryDetails).toEqual([]);
    expect(component.projectShippingHistoryDetailsWithoutHighlighting).toEqual([]);
    expect(component.drAddressId).toEqual(officeSelected.drAddressId);
  });

  it('should get the drAddressId as list value  when displayMode is History on calling fetchSalesOfficeList()', () => {
    const salesOfficeList = [101, 122];
    spyOn(officeSelectorService, 'getOfficeSelectorList').and.returnValue(of(salesOfficeList));
    component.fetchSalesOfficeList();
    expect(component.salesOrderList.length).toEqual(salesOfficeList.length);
  });

  it('should not call fetchProjectDetails method when search value is empty', () => {
    const fetchProjectsSpy = spyOn(component, 'fetchProjectDetails');
    globalSearchService.TabName.next('Projects');
    globalSearchService.searchValue.next('');
    component.ngOnInit();
    expect(component.projectShippingHistoryDetails).toEqual([]);
    expect(fetchProjectsSpy).not.toHaveBeenCalled();
  });

  it(`should call getOrderList, setStatusIconColumnWidth and set projectDetails and projectDetailsWithoutHighlighting if displayMode is not Shipping History
  on calling fetchProjectDetails()`, () => {
    component.projectDetails = [];
    component.projectDetailsWithoutHighlighting = [];
    spyOn(component, 'setJobContactPersonName');
    spyOn(component, 'highlightSearchText');
    spyOn(component, 'loadExpandedSalesOrder');
    const spySetStatusIconColumnWidth = spyOn(component, 'setStatusIconColumnWidth');
    spyOn(globalSearchService, 'getOrderList').and.returnValue(of(projectsMockData.projectDetailsData));
    component.fetchProjectDetails();
    expect(component.totalItemCount).toBe(projectsMockData.projectDetailsData.totalItemCount);
    expect(component.projectDetails).toEqual(projectsMockData.projectDetailsData.pagingItems);
    expect(component.projectDetailsWithoutHighlighting).toEqual(projectsMockData.projectDetailsData.pagingItems);
    expect(spySetStatusIconColumnWidth).toHaveBeenCalled();
  });

  it('should call getShippingHistory and set projectShippingHistoryDetails and projectShippingHistoryDetailsWithoutHighlighting if displayMode is Shipping History on calling fetchProjectDetails()', () => {
    component.displayMode = shippingHistory;
    component.projectShippingHistoryDetails = [];
    component.projectShippingHistoryDetailsWithoutHighlighting = [];
    spyOn(component, 'highlightSearchText');
    spyOn(globalSearchService, 'getShippingHistory').and.returnValue(of(projectsMockData.shippingHistoryData));
    component.fetchProjectDetails();
    expect(component.totalItemCount).toBe(projectsMockData.shippingHistoryData.totalItemCount);
    expect(component.projectShippingHistoryDetails).toEqual(projectsMockData.shippingHistoryData.pagingItems);
    expect(component.projectShippingHistoryDetailsWithoutHighlighting).toEqual(projectsMockData.shippingHistoryData.pagingItems);
  });

  it(`should set total item count if skip is zero on calling fetchProjectDetails()`, () => {
    component.displayMode = shippingHistory;
    component.projectShippingHistoryDetails = [];
    component.projectShippingHistoryDetailsWithoutHighlighting = [];
    component.skip = 0;
    component.totalItemCount = 150;
    spyOn(component, 'highlightSearchText');
    spyOn(globalSearchService, 'getShippingHistory').and.returnValue(of(projectsMockData.shippingHistoryData));
    component.fetchProjectDetails();
    expect(component.totalItemCount).toBe(projectsMockData.shippingHistoryData.totalItemCount);
  });

  it(`should not set total item count if skip is not zero on calling fetchProjectDetails()`, () => {
    component.displayMode = shippingHistory;
    component.projectShippingHistoryDetails = [];
    component.projectShippingHistoryDetailsWithoutHighlighting = [];
    component.skip = 50;
    component.totalItemCount = 150;
    spyOn(component, 'highlightSearchText');
    spyOn(globalSearchService, 'getShippingHistory').and.returnValue(of(projectsMockData.shippingHistoryData));
    component.fetchProjectDetails();
    expect(component.totalItemCount).toBe(150);
  });

  it(`should not call highlightSearchText method when getShippingHistory service call returns null
    on calling fetchProjectDetails()`, () => {
    component.displayMode = shippingHistory;
    const spyHighlightSearchText = spyOn(component, 'highlightSearchText');
    spyOn(globalSearchService, 'getShippingHistory').and.returnValue(of(null));
    component.fetchProjectDetails();
    expect(spyHighlightSearchText).not.toHaveBeenCalled();
    expect(component.projectShippingHistoryDetails).toBeUndefined();
  });

  it('should show error message when getShippingHistory service call returns an error on calling fetchProjectDetails()', () => {
    component.displayMode = shippingHistory;
    spyOn(globalSearchService, 'getShippingHistory').and.returnValue(throwError({
      error: 'error',
    }));
    const apiSpy = spyOn(apiErrorService, 'show');
    const spyLoader = spyOn(loaderService, 'hide');
    component.fetchProjectDetails();
    expect(apiSpy).toHaveBeenCalled();
    expect(spyLoader).toHaveBeenCalled();
  });

  it('should not call setJobContactPersonName method when getOrderList service call returns null', () => {
    const jobContactSpy = spyOn(component, 'setJobContactPersonName');
    spyOn(globalSearchService, 'getOrderList').and.returnValue(of(null));
    component.fetchSalesOfficeList();
    component.fetchProjectDetails();
    expect(jobContactSpy).not.toHaveBeenCalled();
    expect(component.projectDetails).toBeUndefined();
  });

  it('should show error message when getOrderList service call returns an error', () => {
    spyOn(globalSearchService, 'getOrderList').and.returnValue(throwError({
      error: 'error',
    }));
    const apiSpy = spyOn(apiErrorService, 'show');
    const spyLoader = spyOn(loaderService, 'hide');
    component.fetchProjectDetails();
    expect(apiSpy).toHaveBeenCalled();
    expect(spyLoader).toHaveBeenCalled();
  });

  it('should set job contact person name when first name and last name having values', () => {
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.setJobContactPersonName();
    expect(component.projectDetails[0].jobContactPersonName).toBe('Burns, Haley');
  });

  it('should set job contact person name when first name having value and last name is empty', () => {
    projectsMockData.projectDetailsData.pagingItems[0].jobContactPersonLastName = '';
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.setJobContactPersonName();
    expect(component.projectDetails[0].jobContactPersonName).toBe('Haley');
  });

  it('should set job contact person name when first name having empty and last name having value', () => {
    projectsMockData.projectDetailsData.pagingItems[0].jobContactPersonFirstName = '';
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.setJobContactPersonName();
    expect(component.projectDetails[0].jobContactPersonName).toBe('Burns');
  });

  it('should call loadService hide method when ngAfterViewInit is called', () => {
    const spyLoader = spyOn(loaderService, 'hide');
    component.ngAfterViewInit();
    expect(spyLoader).toHaveBeenCalled();
  });

  it('should navigate to view credit project page on calling navigateToCreditProjectPage method for transmitted project when IsCopiedDownCreditJob is false', () => {
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    component.displayMode = DisplayModeEnum.Transmitted;
    component.navigateToCreditProjectPage(projectsMockData.projectDetailsData.pagingItems[0], event);
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31777/projects/CreditJobs/2103776/credit-project-details?navFrom=ProjectLanding&projectType=Transmitted',
      '101_2103776_R529934_Transmitted');
  });

  it('should navigate to edit credit project page on calling navigateToCreditProjectPage method for transmitted project when isCopiedDownCreditJob is true and enableCopyDown is true', () => {
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    component.enableCopyDown = true;
    component.displayMode = DisplayModeEnum.Transmitted;
    projectsMockData.projectDetailsData.pagingItems[0].isCopiedDownCreditJob = true;
    component.navigateToCreditProjectPage(projectsMockData.projectDetailsData.pagingItems[0], event);
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31777/projects/CreditProject/11634/Edit?navFrom=ProjectLanding&projectType=Untransmitted',
      '101_2103776_R529934_Transmitted');
  });

  it('should navigate to view credit project page on calling navigateToCreditProjectPage method for transmitted project when isCopiedDownCreditJob is true and enableCopyDown is false', () => {
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    component.enableCopyDown = false;
    component.displayMode = DisplayModeEnum.Transmitted;
    projectsMockData.projectDetailsData.pagingItems[0].isCopiedDownCreditJob = true;
    component.navigateToCreditProjectPage(projectsMockData.projectDetailsData.pagingItems[0], event);
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31777/projects/CreditJobs/2103776/credit-project-details?navFrom=ProjectLanding&projectType=Transmitted',
      '101_2103776_R529934_Transmitted');
  });

  it('should navigate to credit project page on calling navigateToCreditProjectPage method fot untransmitted project', () => {
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.displayMode = DisplayModeEnum.Untransmitted;
    component.navigateToCreditProjectPage(projectsMockData.projectDetailsData.pagingItems[0], event);
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31776/projects/CreditProject/2103776/Edit?navFrom=ProjectLanding&projectType=Untransmitted', '101_2103776_R529934_Untransmitted');
  });

  it('should highlight the matching search text for projectDetails on calling highlightSearchText() method', () => {
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.searchVal = 'Global';
    component.highlightSearchText();
    expect(component.projectDetails[0].jobName).toBe('<em>Global</em> Enterprises CH install');
  });

  it('should highlight the matching search text for shippingHistory on calling highlightSearchText() method', () => {
    component.displayMode = shippingHistory;
    component.projectShippingHistoryDetails = projectsMockData.shippingHistoryData.pagingItems;
    component.searchVal = '121';
    component.highlightSearchText();
    expect(component.projectShippingHistoryDetails[0].orderName).toBe(' <em>121</em>53F');
  });

  it('should navigate to sales orders page on calling navigateToSalesOrderPage method for transmitted project when IsCopiedDownCreditJob is false', () => {
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    component.displayMode = DisplayModeEnum.Transmitted;
    component.salesOrderUrl = '/jobs-list/101/31777/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=Transmitted';
    const spyGenerateSalesOrderUrl = spyOn(component, 'generateSalesOrderUrl');
    component.navigateToSalesOrderPage(projectsMockData.projectDetailsData.pagingItems[0],
      projectsMockData.projectDetailsData.pagingItems[0], 1, event);
    expect(spyGenerateSalesOrderUrl).toHaveBeenCalledWith(101, 31777, 2103776, 'Transmitted');
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31777/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=Transmitted',
      '101_2103776_Doug Stephens_Transmitted');
  });

  it('should navigate to sales orders page on calling navigateToSalesOrderPage method for transmitted project when isCopiedDownCreditJob is true and enableCopyDown is true', () => {
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    component.displayMode = DisplayModeEnum.Transmitted;
    component.enableCopyDown = true;
    projectsMockData.projectDetailsData.pagingItems[0].isCopiedDownCreditJob = true;
    component.salesOrderUrl = '/jobs-list/101/31777/projects/CreditJobs/11634/SalesOrders?navFrom=ProjectLanding&projectType=Untransmitted';
    const spyGenerateSalesOrderUrl = spyOn(component, 'generateSalesOrderUrl');
    component.navigateToSalesOrderPage(projectsMockData.projectDetailsData.pagingItems[0],
      projectsMockData.projectDetailsData.pagingItems[0], 1, event);
    expect(spyGenerateSalesOrderUrl).toHaveBeenCalledWith(101, 31777, '11634', 'Untransmitted');
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31777/projects/CreditJobs/11634/SalesOrders?navFrom=ProjectLanding&projectType=Untransmitted',
      '101_2103776_Doug Stephens_TransmittedCopiedDown');
  });

  it(`should navigate to sales orders page on calling navigateToSalesOrderPage method for transmitted project when isCopiedDownCreditJob is true and
  enableCopyDown is false`, () => {
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    component.displayMode = DisplayModeEnum.Transmitted;
    component.enableCopyDown = false;
    projectsMockData.projectDetailsData.pagingItems[0].isCopiedDownCreditJob = true;
    component.salesOrderUrl = '/jobs-list/101/31777/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=Transmitted';
    const spyGenerateSalesOrderUrl = spyOn(component, 'generateSalesOrderUrl');
    component.navigateToSalesOrderPage(projectsMockData.projectDetailsData.pagingItems[0],
      projectsMockData.projectDetailsData.pagingItems[0], 1, event);
    expect(spyGenerateSalesOrderUrl).toHaveBeenCalledWith(101, 31777, 2103776, 'Transmitted');
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31777/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=Transmitted',
      '101_2103776_Doug Stephens_Transmitted');
  });

  it(`should navigate to sales orders page with job id on calling navigateToSalesOrderPage
      method when displayMode is Untransmitted`, () => {
    component.displayMode = DisplayModeEnum.Untransmitted;
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    const spyGenerateSalesOrderUrl = spyOn(component, 'generateSalesOrderUrl');
    component.salesOrderUrl = '/jobs-list/101/31776/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=Untransmitted';
    component.navigateToSalesOrderPage(projectsMockData.projectDetailsData.pagingItems[0],
      projectsMockData.projectDetailsData.pagingItems[0], 1, event);
    expect(spyGenerateSalesOrderUrl).toHaveBeenCalledWith(101, 31776, 2103776, 'Untransmitted');
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31776/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=Untransmitted',
      '101_2103776_Doug Stephens_Untransmitted');
  });

  it(`should navigate to sales orders page on calling navigateToSalesOrderPage
      method when displayMode is History`, () => {
    component.displayMode = 'History';
    const spyWindow = spyOn(window, 'open');
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.drAddressId = 96;
    component.salesOrderUrl = '/jobs-list/101/31776/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=History';
    const spyGenerateSalesOrderUrl = spyOn(component, 'generateSalesOrderUrl');
    component.navigateToSalesOrderPage(projectsMockData.projectDetailsData.pagingItems[0],
      projectsMockData.projectDetailsData.pagingItems[0], 1, event);
    expect(spyGenerateSalesOrderUrl).toHaveBeenCalledWith(101, 31776, 2103776, 'History');
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyWindow).toHaveBeenCalledWith('/jobs-list/101/31776/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=History',
      '101_2103776_Doug Stephens_History');
  });

  it(`should get salesOrderUrl on calling generateSalesOrderUrl method`, () => {
    component.generateSalesOrderUrl(101, 31776, 2103776, 'Untransmitted');
    expect(component.salesOrderUrl).toBe('/jobs-list/101/31776/projects/CreditJobs/2103776/SalesOrders?navFrom=ProjectLanding&projectType=Untransmitted');
  });

  it(`should call fetchProjectDetails method when displayMode is not shippingHistory and projectDetails length is less than
  totalItemCount`, () => {
    component.displayMode = unTransmitted;
    component.skip = 0;
    component.take = 100;
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.totalItemCount = 150;
    const projectDetailsSpy = spyOn(component, 'fetchProjectDetails');
    component.loadMore();
    expect(component.skip).toBe(100);
    expect(projectDetailsSpy).toHaveBeenCalled();
  });

  it('should not call fetchProjectDetails method when displayMode is not shippingHistory and projectDetails length is equal to totalItemCount', () => {
    component.displayMode = unTransmitted;
    component.skip = 0;
    component.take = 100;
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    const projectDetailsSpy = spyOn(component, 'fetchProjectDetails');
    component.totalItemCount = 1;
    component.loadMore();
    expect(component.skip).toBe(0);
    expect(projectDetailsSpy).not.toHaveBeenCalled();
  });

  it('should call fetchProjectDetails method when displayMode is shippingHistory and projectShippingHistoryDetails length is less than totalItemCount', () => {
    component.displayMode = shippingHistory;
    component.skip = 0;
    component.take = 100;
    component.projectShippingHistoryDetails = projectsMockData.shippingHistorySearchData.pagingItems;
    component.totalItemCount = 150;
    const projectDetailsSpy = spyOn(component, 'fetchProjectDetails');
    component.loadMore();
    expect(component.skip).toBe(100);
    expect(projectDetailsSpy).toHaveBeenCalled();
  });

  it('should not call fetchProjectDetails method when displayMode is shippingHistory and projectShippingHistoryDetails length is equal to totalItemCount', () => {
    component.displayMode = shippingHistory;
    component.skip = 0;
    component.take = 100;
    component.projectShippingHistoryDetails = projectsMockData.shippingHistorySearchData.pagingItems;
    const projectDetailsSpy = spyOn(component, 'fetchProjectDetails');
    component.totalItemCount = 1;
    component.loadMore();
    expect(component.skip).toBe(0);
    expect(projectDetailsSpy).not.toHaveBeenCalled();
  });

  it(`should set data orderLinesResponse when calling loadOrderLinesDetails method and
    set setFirstPlannedShipmentOrderLine$ to true`, () => {
    const salesOrderDetails = projectsMockData.projectDetailsData.pagingItems[0].salesOrdersList[0];
    const setFirstPlannedShipmentOrderLineSpy = spyOn(salesOrderService.setFirstPlannedShipmentOrderLine$, 'next');
    spyOn(salesOrderService, 'getOrderLinesBySalesOrderId').and.returnValue(of(testData.orderLineSummaries));
    component.orderLinesResponse = testData.orderLineSummaries;
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.isSalesOrderExpanded = [[]];
    component.loadOrderLinesDetails(salesOrderDetails, 1748047, 0, 0);
    salesOrderDetails.plannedShipmentDetails.forEach((element) => {
      expect(element.orderLineSummaries).toEqual(testData.orderLineSummaries);
      expect(element.plannedShipmentNbr).toEqual(testData.orderLineSummaries[0].plannedShipmentNbr);
    });
    expect(component.isSalesOrderExpanded[0][1]).toEqual(false);
    expect(component.shippingInstrArray).toEqual([]);
    expect(setFirstPlannedShipmentOrderLineSpy).toHaveBeenCalledWith(true);
  });

  it('should expand all the project details when expandAllPSgrid method called', () => {
    component.isExpandAll = false;
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.expandAllPSgrid();
    expect(component.isExpandAll).toBe(true);
    expect(component.projectExpand).toEqual([true, true]);
  });

  it('should not expand all the project details when expandAllPSgrid method called', () => {
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.projectDetails.length = 50;
    component.expandAllPSgrid();
    expect(component.isExpandAll).toBe(false);
  });

  it('should load expanded sales order on fetching more records', () => {
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.projectDetails.length = 100;
    component.existingProjArray = 50;
    component.isSalesOrderExpanded = new Array(50);
    component.isSalesOrderExpanded.length = 50;
    component.loadExpandedSalesOrder();
    expect(component.isSalesOrderExpanded.length).toBe(100);
  });

  it('should load expanded sales order on fetching more records', () => {
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.isSalesOrderExpanded = null;
    component.loadExpandedSalesOrder();
    expect(component.isSalesOrderExpanded.length).toBe(2);
  });

  it('should set the default toggle value as Transmitted', () => {
    component.displayMode = '';
    component.infoData = '';
    component.toggleData = [
      {
        title: 'Transmitted',
        infoText: 'transmittedInfoData',
      },
    ];
    component.setToggleDefault();
    expect(component.displayMode).toEqual('Transmitted');
    expect(component.infoData).toEqual('transmittedInfoData');
  });

  it('should set the selected toggle value to be Untransmitted if untransmitted toggle is clicked', () => {
    component.displayMode = '';
    component.infoData = '';
    const selectedToggle = {
      title: 'Untransmitted',
      infoText: 'untransmittedInfoData',
    };
    const tabEvent = {
      prevented: false,
      index: 1,
      title: 'Untransmitted',
    };
    spyOn(apiErrorService, 'hide');
    component.toggleData = [selectedToggle];
    component.onTabSelect(tabEvent);
    expect(component.displayMode).toEqual(tabEvent.title);
    expect(component.infoData).toEqual(selectedToggle.infoText);
    expect(apiErrorService.hide).toHaveBeenCalled();
  });

  it('should event preventDefault and stopPropagation to have been called on exportToExcel method triggered', () => {
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    spyOn(projectService, 'exportToExcel').and.returnValue(of(null));
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    component.exportToExcel(event, projectsMockData.projectDetailsData.pagingItems[0]);
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(spyToasterService).toHaveBeenCalledWith('success', appConstants.EXPORT_TO_EXCEL_SUCCESS_TOASTER);
  });

  it('should show success toaster message  when exportToExcel method triggered', () => {
    spyOn(projectService, 'exportToExcel').and.returnValue(of(null));
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    component.exportToExcel(event, projectsMockData.projectDetailsData.pagingItems[0]);
    expect(spyToasterService).toHaveBeenCalledWith('success', appConstants.EXPORT_TO_EXCEL_SUCCESS_TOASTER);
  });

  it('should show a toaster error message on exportToExcel failure while exporting to file', () => {
    spyOn(projectService, 'exportToExcel').and.returnValue(throwError({
      error: {
        messages: 'Server Error',
      },
    }));
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    component.exportToExcel(event, projectsMockData.projectDetailsData.pagingItems[0]);
    expect(spyToasterService).toHaveBeenCalledWith('error', appConstants.EXPORT_TO_EXCEL_ERROR_TOASTER);
  });

  it('should fetch project details timer subscription when delete untransmit is successful', fakeAsync(() => {
    const spy = spyOn(component, 'fetchProjectDetails');
    tick(15000);
    component.isDeletedRecord = true;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.ngOnInit();
      expect(component.isDeletedRecord).toBe(false);
      expect(spy).toHaveBeenCalled();
    });
  }));

  it('should return false if enableRebalancing is true and isBalanced is true, data is passed as parameter, display mode is transmitted when canShowDateData is called', () => {
    component.enableRebalancing = true;
    component.displayMode = transmitted;
    const result = component.canShowDateData(true, 'data');
    expect(result).toBe(false);
  });

  it('should return true if enableRebalancing is true and isBalanced is false, data is passed as parameter, display mode is transmitted when canShowDateData is called', () => {
    component.enableRebalancing = true;
    component.displayMode = transmitted;
    const result = component.canShowDateData(false, 'data');
    expect(result).toBe(true);
  });

  it('should return false if enableRebalancing is true and isBalanced is true, not data is passed as parameter, display mode is transmitted when canShowDateData is called', () => {
    component.enableRebalancing = true;
    component.displayMode = transmitted;
    const result = component.canShowDateData(true, 'div');
    expect(result).toBe(true);
  });

  it('should return undefined if enableRebalancing is false and isBalanced is true, not data is passed as parameter, display mode is not transmitted when canShowDateData is called', () => {
    component.enableRebalancing = false;
    component.displayMode = unTransmitted;
    const result = component.canShowDateData(true, 'div');
    expect(result).toBe(undefined);
  });

  it('should navigate to price summary page when navigateToPriceSummary is called', () => {
    const spyWindow = spyOn(window, 'open');
    const jobId = projectsMockData.projectDetailsData.pagingItems[0].watcomJobId;
    const drAddressId = projectsMockData.projectDetailsData.pagingItems[0].originatingDrAddress;
    const priceSummaryUrl = `jobs-list/${jobId}/${drAddressId}/Rebalancing/PriceSummary`;
    component.navigateToPriceSummary(projectsMockData.projectDetailsData.pagingItems[0]);
    expect(spyWindow).toHaveBeenCalledWith(priceSummaryUrl, jobId + '_' + drAddressId);
  });

  it('should return true if column name is Date, isIcon is true are passed as parameter and enableRebalancing is true, display mode is transmitted when canShowColumnHeader is called', () => {
    component.enableRebalancing = true;
    component.displayMode = transmitted;
    const result = component.canShowColumnHeader('Date', true);
    expect(result).toBe(true);
  });

  it('should return false if column name is Date, isIcon is true are passed as parameter and enableRebalancing is false, display mode is not transmitted when canShowColumnHeader is called', () => {
    component.enableRebalancing = false;
    component.displayMode = unTransmitted;
    const result = component.canShowColumnHeader('Date', true);
    expect(result).toBe(false);
  });

  it('should return false if column name is Date, isIcon is false are passed as parameter and enableRebalancing is false, display mode is not transmitted when canShowColumnHeader is called', () => {
    component.enableRebalancing = false;
    component.displayMode = unTransmitted;
    const result = component.canShowColumnHeader('Date', false);
    expect(result).toBe(false);
  });

  it('should return true if column name is Date, isIcon is false are passed as parameter and enableRebalancing is true, display mode is transmitted when canShowColumnHeader is called', () => {
    component.enableRebalancing = true;
    component.displayMode = transmitted;
    const result = component.canShowColumnHeader('Date', false);
    expect(result).toBe(true);
  });

  it('should return true if column name is not Date, isIcon is false are passed as parameter when canShowColumnHeader is called', () => {
    const result = component.canShowColumnHeader('jobName', false);
    expect(result).toBe(true);
  });

  it('should not expand sales order grid when report icon click when onSalesReportIconClick method called ', () => {
    spyOn(event, 'preventDefault');
    spyOn(event, 'stopPropagation');
    component.onSalesReportIconClick(event);
    expect(event.preventDefault).toHaveBeenCalled();
    expect(event.stopPropagation).toHaveBeenCalled();
  });

  it('should return className parameter string contains projectNbr, display mode is transmitted, enableRebalancing is true when columnHeaderClass is called', () => {
    component.displayMode = transmitted;
    component.enableRebalancing = true;
    const className = 'col-1 px-0 projectNbr';
    const result = component.columnHeaderClass('projectNbr');
    expect(result).toBe(className);
  });

  it('should return className parameter string contains projectNbr, display mode is not transmitted, enableRebalancing is false when columnHeaderClass is called', () => {
    component.displayMode = unTransmitted;
    component.enableRebalancing = false;
    const className = 'col-2 projectNbr';
    const result = component.columnHeaderClass('projectNbr');
    expect(result).toBe(className);
  });

  it('should return className parameter string does not contains projectNbr, display mode is transmitted, enableRebalancing is true when columnHeaderClass is called', () => {
    component.displayMode = transmitted;
    component.enableRebalancing = true;
    const result = component.columnHeaderClass('CustomerName');
    expect(result).toBe('CustomerName');
  });

  it('should return passed parameter if parameter string does not contains projectNbr, display mode is not transmitted, enableRebalancing is false when columnHeaderClass is called', () => {
    component.displayMode = unTransmitted;
    component.enableRebalancing = false;
    const result = component.columnHeaderClass('CustomerName');
    expect(result).toBe('CustomerName');
  });

  it('should return className if ProjectNumber is passed as parameter, display mode is transmitted, enableRebalancing is true when columnDataClass is called', () => {
    component.displayMode = transmitted;
    component.enableRebalancing = true;
    const className = 'col-1 px-0';
    const result = component.columnDataClass('ProjectNumber');
    expect(result).toBe(className);
  });

  it('should return className if ProjectNumber is passed as parameter, display mode is not transmitted, enableRebalancing is true when columnDataClass is called', () => {
    component.displayMode = unTransmitted;
    component.enableRebalancing = true;
    const className = 'col-2 px-3';
    const result = component.columnDataClass('ProjectNumber');
    expect(result).toBe(className);
  });

  it('should return className if ProjectNumber is passed as parameter, display mode is not transmitted, enableRebalancing is false when columnDataClass is called', () => {
    component.displayMode = unTransmitted;
    component.enableRebalancing = false;
    const className = 'col-2';
    const result = component.columnDataClass('ProjectNumber');
    expect(result).toBe(className);
  });

  it('should return className if CustomerName is passed as parameter, display mode is transmitted, enableRebalancing is true when columnDataClass is called', () => {
    component.displayMode = transmitted;
    const className = 'col-2';
    component.enableRebalancing = true;
    const result = component.columnDataClass('CustomerName');
    expect(result).toBe(className);
  });

  it('should return className if CustomerName is passed as parameter, display mode is not transmitted, enableRebalancing is false when columnDataClass is called', () => {
    const className = 'col-3';
    component.displayMode = unTransmitted;
    component.enableRebalancing = false;
    const result = component.columnDataClass('CustomerName');
    expect(result).toBe(className);
  });

  it('should return className of pl-2 if Excel is passed as parameter, display mode is transmitted, enableRebalancing is true when columnDataClass is called', () => {
    component.enableRebalancing = true;
    component.displayMode = transmitted;
    const className = 'pl-2';
    const result = component.columnDataClass('Excel');
    expect(result).toBe(className);
  });

  it('should return undefined if Excel is passed as parameter, display mode is not transmitted, enableRebalancing is true when columnDataClass is called', () => {
    component.enableRebalancing = false;
    component.displayMode = unTransmitted;
    const result = component.columnDataClass('Excel');
    expect(result).toBe(undefined);
  });

  it('should return true if display mode is transmitted, enableRebalancing is true when canDisplayData is called', () => {
    component.enableRebalancing = true;
    component.displayMode = transmitted;
    const result = component.canDisplayData();
    expect(result).toBe(true);
  });

  it('should return false if display mode is not transmitted, enableRebalancing is false when canDisplayData is called', () => {
    component.enableRebalancing = false;
    component.displayMode = unTransmitted;
    const result = component.canDisplayData();
    expect(result).toBe(false);
  });

  it('should return true if display mode is not shipping history, projectDetails is null when checkNoRecords() is called', () => {
    component.displayMode = unTransmitted;
    component.projectDetails = [];
    const result = component.checkNoRecords();
    expect(result).toBe(true);
  });

  it(`should return true if display mode is shipping history, projectShippingHistoryDetails is null on calling checkNoRecords()`, () => {
    component.displayMode = shippingHistory;
    component.projectShippingHistoryDetails = [];
    const result = component.checkNoRecords();
    expect(result).toBe(true);
  });

  it('should return false if display mode is not shipping history, projectDetails is not null when checkNoRecords() is called', () => {
    component.displayMode = unTransmitted;
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    const result = component.checkNoRecords();
    expect(result).toBe(false);
  });

  it(`should return false if display mode is shipping history, projectShippingHistoryDetails is not null
  on calling checkNoRecords()`, () => {
    component.displayMode = shippingHistory;
    component.projectShippingHistoryDetails = projectsMockData.shippingHistoryData.pagingItems;
    const result = component.checkNoRecords();
    expect(result).toBe(false);
  });

  describe('downloadReports', () => {
    it(`should download vo file and not call downloadShippingDetails method on calling downloadReports method`, () => {
      spyOn(globalSearchService, 'downloadShippingHistoryReports').and.returnValue
        (of({ file: new Blob() }));
      const spyDownloadShippingDetails = spyOn(component, 'downloadShippingDetails');
      component.downloadReports(projectsMockData.shippingHistoryData.pagingItems[0], 2);
      expect(globalSearchService.downloadShippingHistoryReports).toHaveBeenCalled();
      expect(spyDownloadShippingDetails).not.toHaveBeenCalled();
    });

    it(`should generate pdf file for VO reports on calling download reports`, () => {
      spyOn(globalSearchService, 'downloadShippingHistoryReports').and.returnValue(
        of({ file: new Blob(), filename: 'L10E02595.pdf' })
      );
      const pagingItems = projectsMockData.shippingHistoryData.pagingItems[0];
      component.downloadReports(pagingItems, 5);
      expect(component.downloadFileName).toEqual('L10E02595.pdf');
      expect(component.selectedIndex).toEqual(5);
      expect(component.progress).toEqual(false);
    });

    it('should show a error toaster message on calling downloadReports method', () => {
      const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
      spyOn(globalSearchService, 'downloadShippingHistoryReports').and.
        returnValue(Observable.throwError({ error: { messages: 'Server Error' } }));
      component.downloadReports(projectsMockData.shippingHistoryData.pagingItems[0], 5);
      expect(spyToasterService).toHaveBeenCalledWith('error', appConstants.DOWNLOAD_ERROR_MESSAGE);
      expect(component.progress).toEqual(false);
    });

    it('should call downloadShippingHistoryReports given orderType is VO', () => {
      const spy = spyOn(globalSearchService, 'downloadShippingHistoryReports').and.returnValue
        (of({ file: new Blob() }));
      const spyDownloadShippingDetails = spyOn(component, 'downloadShippingDetails');
      const item = {
        orderType: 'VO',
        designSpecialIndicator: 'N',
        buMfgLocId: 4,
        buMfgLocation: 'LAX LAX La Crosse WI',
        serialNumber: 'L10E02595',
        historicalStatus: null,
        isShipped: false,
        orderStatus: null,
        filePath: 'ShippingHistory/VO/VDrive/trane31d/MCN/F000/25/64/FILE0000.IMG',
        orderName: ' 12153F',
        orderBillLetter: 'A',
        orderRevision: 1,
        jobName: 'Hello Test',
        shipDate: '1-23-2021',
        shipTo: '289',
        modelNum: '289',
        fileName: 'IMG.png',
        plantName: 'SO',
        orderId: 4327,
        modelNumber: ''
      };
      component.downloadReports(item, 0);
      expect(globalSearchService.downloadShippingHistoryReports)
        .toHaveBeenCalledWith(item.filePath, item.orderName, item.serialNumber, item.orderType);
      expect(spyDownloadShippingDetails).not.toHaveBeenCalled();
    });
    it('should call downloadShippingHistoryReports given orderType is SIL', () => {
      const spy = spyOn(globalSearchService, 'downloadShippingHistoryReports').and.returnValue
        (of({ file: new Blob() }));
      const spyDownloadShippingDetails = spyOn(component, 'downloadShippingDetails');
      const item = {
        orderType: 'SIL',
        designSpecialIndicator: 'N',
        buMfgLocId: 4,
        buMfgLocation: 'LAX LAX La Crosse WI',
        serialNumber: 'L10E02595',
        historicalStatus: null,
        isShipped: false,
        orderStatus: null,
        filePath: 'ShippingHistory/VO/VDrive/trane31d/MCN/F000/25/64/FILE0000.IMG',
        orderName: ' 12153F',
        orderBillLetter: 'A',
        orderRevision: 1,
        jobName: 'Hello Test',
        shipDate: '1-23-2021',
        shipTo: '289',
        modelNum: '289',
        fileName: 'IMG.png',
        plantName: 'SO',
        orderId: 4327,
        modelNumber: ''
      };
      component.downloadReports(item, 0);
      expect(globalSearchService.downloadShippingHistoryReports)
        .toHaveBeenCalledWith(item.filePath, item.orderName, item.serialNumber, item.orderType);
      expect(spyDownloadShippingDetails).not.toHaveBeenCalled();
    });
    it('should call downloadShippingDetails given orderType is not VO nor SIL', () => {
      const spy = spyOn(globalSearchService, 'downloadShippingHistoryReports').and.returnValue
        (of({ file: new Blob() }));
      const spyDownloadShippingDetails = spyOn(component, 'downloadShippingDetails');
      const item = {
        orderType: 'BRETT',
        designSpecialIndicator: 'N',
        buMfgLocId: 4,
        buMfgLocation: 'LAX LAX La Crosse WI',
        serialNumber: 'L10E02595',
        historicalStatus: null,
        isShipped: false,
        orderStatus: null,
        filePath: 'ShippingHistory/VO/VDrive/trane31d/MCN/F000/25/64/FILE0000.IMG',
        orderName: ' 12153F',
        orderBillLetter: 'A',
        orderRevision: 1,
        jobName: 'Hello Test',
        shipDate: '1-23-2021',
        shipTo: '289',
        modelNum: '289',
        fileName: 'IMG.png',
        plantName: 'SO',
        orderId: 4327,
        modelNumber: ''
      };
      component.downloadReports(item, 0);
      expect(globalSearchService.downloadShippingHistoryReports).not.toHaveBeenCalled();
      expect(spyDownloadShippingDetails).toHaveBeenCalled();
    });
  });

  it(`should call downloadShippingDetails method on calling downloadReports method`, () => {
    const spyDownloadShippingDetails = spyOn(component, 'downloadShippingDetails');
    component.downloadReports(projectsMockData.shippingHistoryData.pagingItems[1], 5);
    expect(spyDownloadShippingDetails).toHaveBeenCalled();
  });

  it(`should call success toaster on calling downloadShippingDetails method`, () => {
    spyOn(toasterService, 'setToaster');
    spyOn(globalSearchService, 'downloadFile').and.returnValue
      (of({ file: new Blob() }));
    const payload = {
      orderId: 4327,
      serialNumber: 'N04L18621',
      orderName: 'S00034MM',
      orderBillLetter: 'A',
      orderRevision: 1,
      sourceType: 'Current'
    };
    component.downloadShippingDetails({
      orderId: 4327, serialNumber: 'N04L18621', orderName: 'S00034MM', orderBillLetter: 'A', orderRevision: 1
    } as IProjectShippingHistoryPagingItems);
    expect(globalSearchService.downloadFile).toHaveBeenCalledWith(component.downloadFilePayload);
    expect(toasterService.setToaster).toHaveBeenCalledWith('success', appConstants.SHIPPING_HISTORY_DOWNLOAD_REQUEST);
    expect(component.downloadFilePayload).toEqual(payload);
  });

  it(`should download excel file with MfgOrder as filename on calling downloadShippingDetails method`, () => {
    spyOn(toasterService, 'setToaster');
    spyOn(globalSearchService, 'downloadFile').and.returnValue
      (of({ file: new Blob() }));
    const payload = {
      orderId: 4327,
      serialNumber: null,
      orderName: 'S00034MM',
      orderBillLetter: 'A',
      orderRevision: 1,
      sourceType: 'Current'
    };
    component.downloadShippingDetails({
      orderId: 4327, serialNumber: null, orderName: 'S00034MM', orderBillLetter: 'A', orderRevision: 1
    } as IProjectShippingHistoryPagingItems);
    expect(toasterService.setToaster).toHaveBeenCalledWith('success', appConstants.SHIPPING_HISTORY_DOWNLOAD_REQUEST);
    expect(globalSearchService.downloadFile).toHaveBeenCalledWith(component.downloadFilePayload);
    expect(component.downloadFilePayload).toEqual(payload);
  });

  it('should show a error toaster message on calling downloadShippingDetails method', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    spyOn(globalSearchService, 'downloadFile').and.returnValue(Observable.throwError({ error: { messages: 'Server Error' } }));
    component.downloadShippingDetails({} as IProjectShippingHistoryPagingItems);
    expect(spyToasterService).toHaveBeenCalledWith('error', appConstants.DOWNLOAD_ERROR_MESSAGE);
    expect(component.progress).toEqual(false);
  });


  describe('showDownloadLink', () => {
    it('should return true given VO or SIL and filepath exists', () => {
      const scenarios: IProjectShippingHistoryPagingItems[] = [
        {
          orderType: 'VO',
          filePath: 'not blank'
        } as IProjectShippingHistoryPagingItems,
        {
          orderType: 'SIL',
          filePath: 'shippinghistory/bleh/FILE.PDF'
        } as IProjectShippingHistoryPagingItems,
      ];

      scenarios.forEach(model => {
        expect(component.showDownloadLink(model)).toBeTruthy();
      });
    });

    it('should return true given not VO nor SIL', () => {
      const scenarios: IProjectShippingHistoryPagingItems[] = [
        {
          orderType: 'NOT VO'
        } as IProjectShippingHistoryPagingItems,
        {
          orderType: 'NOT SIL'
        } as IProjectShippingHistoryPagingItems,
      ];

      scenarios.forEach(model => {
        expect(component.showDownloadLink(model)).toBeTruthy();
      });
    });

    it(`should return false given VO or SIL and filepath doesn't exist`, () => {
      const scenarios: IProjectShippingHistoryPagingItems[] = [
        {
          orderType: 'VO',
          filePath: ''
        } as IProjectShippingHistoryPagingItems,
        {
          orderType: 'SIL',
          filePath: ''
        } as IProjectShippingHistoryPagingItems,
        {
          orderType: 'VO',
          filePath: undefined
        } as IProjectShippingHistoryPagingItems,
        {
          orderType: 'VO',
          filePath: null
        } as IProjectShippingHistoryPagingItems,
      ];

      scenarios.forEach(model => {
        expect(component.showDownloadLink(model)).toBeFalsy();
      });
    });
  });

  it(`should not set orderLineSummaries on calling loadOrderLinesDetails method when orderLinesResponse
    is null`, () => {
    const salesOrderDetails = projectsMockData.projectDetailsData.pagingItems[0].salesOrdersList[0];
    spyOn(salesOrderService, 'getOrderLinesBySalesOrderId').and.returnValue(of(null));
    component.projectDetails = projectsMockData.projectDetailsData.pagingItems;
    component.isSalesOrderExpanded = [[]];
    component.loadOrderLinesDetails(salesOrderDetails, 1748047, 0, 0);
    salesOrderDetails.plannedShipmentDetails.forEach((element) => {
      expect(element.orderLineSummaries).toBe(undefined);
    });
  });

  it('should set displayMode and copiedDown values to localStorage when navigateToSalesOrderPage() is called', () => {
    component.drAddressId = 96;
    component.displayMode = DisplayModeEnum.Untransmitted;
    const creditJobId = projectsMockData.projectDetailsData.pagingItems[0].creditJobId;
    component.navigateToSalesOrderPage(projectsMockData.projectDetailsData.pagingItems[0],
      projectsMockData.projectDetailsData.pagingItems[0], 1, event);
    expect(localStorage.getItem(`displayMode-${creditJobId}`) === 'Untransmitted');
    expect(localStorage.getItem(`copiedDown-${creditJobId}`) === null);
  });

  it('should call unsubscribe on searchSubscription on calling ngOnDestroy', () => {
    component.searchSubscription = new Subscription();
    spyOn(component.searchSubscription, 'unsubscribe');
    component.ngOnDestroy();
    expect(component.searchSubscription.unsubscribe).toHaveBeenCalled();
  });


  it('should return ILockUser response on calling getLockedUserDetail', () => {
    const lockUserId = 'cccsss';
    const lockUserName = 'Test';
    const lockUserDetail = component.getLockedUserDetail(lockUserId, lockUserName);
    expect(lockUserDetail).toEqual({ userId: lockUserId, displayName: lockUserName } as ILockUser);
  });

  it('should return legacy job number without parenthesis added when display mode is not untransmitted', () => {
    component.displayMode = 'Transmitted';
    const legacyNumber = 'F11850';
    const formattedLegacyNumber = component.getFormattedLegacyNumber(legacyNumber);
    expect(formattedLegacyNumber).toBe(legacyNumber);
  });

  it('should return legacy job number with parenthesis added when display mode is not transmitted', () => {
    component.displayMode = 'Untransmitted';
    const legacyNumber = 'F11850';
    const formattedLegacyNumber = component.getFormattedLegacyNumber(legacyNumber);
    expect(formattedLegacyNumber).toBe('(F11850)');
  });

  it('should append transmittedStatusColumn on projectHeaderColumns on calling buildProjectHeaderColumns' +
    'when projectType is transmitted', () => {
      const projectType = 'Transmitted';
      component.buildProjectHeaderColumns(projectType);
      expect(component.projectHeaderColumns.length).toBe(7);
      expect(component.projectHeaderColumns[0]).toBe(component.transmittedStatusColumn);
    });

  it('should append untransmittedStatusColumn on projectHeaderColumns on calling buildProjectHeaderColumns' +
    'when projectType is untransmitted', () => {
      const projectType = 'Untransmitted';
      component.buildProjectHeaderColumns(projectType);
      expect(component.projectHeaderColumns.length).toBe(7);
      expect(component.projectHeaderColumns[0]).toBe(component.untransmittedStatusColumn);
    });

  it('should find the maximum offset width from the statusElements and set for the header element', fakeAsync(() => {
    const headerElement = document.createElement('div');
    headerElement.setAttribute('class', 'transmitted');
    document.body.appendChild(headerElement);
    const header: HTMLElement = document.querySelector('.transmitted');
    header.style.width = '10px';
    const item1: HTMLElement = { style: { width: '10' }, offsetWidth: 10 } as HTMLElement;
    const item2: HTMLElement = { style: { width: '30' }, offsetWidth: 30 } as HTMLElement;
    spyOn(document, 'querySelectorAll').and.returnValue([item1, item2]);
    component.setStatusIconColumnWidth();
    tick();
    expect(header.style.width).toEqual('30px');
  }));

  it('should call navigateCreditProject when displayMode is not transmitted on calling checkAndNavigateCreditProject', () => {
    const spyNavigateCreditProject = spyOn(component, 'navigateCreditProject');
    component.displayMode = DisplayModeEnum.Untransmitted;
    component.checkAndNavigateCreditProject(projectsMockData.projectDetailsData.pagingItems[0],
      event, projectsMockData.projectDetailsData.pagingItems[0], 1);
    expect(spyNavigateCreditProject).toHaveBeenCalledWith(projectsMockData.projectDetailsData.pagingItems[0],
      event, projectsMockData.projectDetailsData.pagingItems[0], 1);
  });

  it('should get credit project transmit status and call navigateCreditProject when displayMode is transmitted on calling checkAndNavigateCreditProject', () => {
    const dataItemProjectDetails = {
      originatingDrAddress: 30,
      creditJobId: 12345
    } as IProjectPagingItems;
    const spyNavigateCreditProject = spyOn(component, 'navigateCreditProject');
    const spyGetCreditProjectTransmitStatus = spyOn(projectService, 'getCreditProjectTransmitStatus')
    .and.returnValue(of(creditProjectTransmitStatus));
    component.displayMode = DisplayModeEnum.Transmitted;
    component.checkAndNavigateCreditProject(dataItemProjectDetails, event, projectsMockData.projectDetailsData.pagingItems[0], 1);
    expect(dataItemProjectDetails.isCopiedDownCreditJob).toEqual(creditProjectTransmitStatus.isCopiedDown);
    expect(spyGetCreditProjectTransmitStatus).toHaveBeenCalledWith(dataItemProjectDetails.originatingDrAddress,
      dataItemProjectDetails.creditJobId);
    expect(spyNavigateCreditProject).toHaveBeenCalledWith(dataItemProjectDetails, event,
      projectsMockData.projectDetailsData.pagingItems[0], 1);
  });

  it('should call navigateToCreditProjectPage when credit project number is clicked on calling navigateCreditProject', () => {
    const spyNavigateToCreditProjectPage = spyOn(component, 'navigateToCreditProjectPage');
    component.navigateCreditProject(projectsMockData.projectDetailsData.pagingItems[0], event);
    expect(spyNavigateToCreditProjectPage).toHaveBeenCalledWith(projectsMockData.projectDetailsData.pagingItems[0], event);
  });

  it('should call navigateToSalesOrderPage when sales order number is clicked on calling navigateCreditProject', () => {
    const spyNavigateToSalesOrderPage = spyOn(component, 'navigateToSalesOrderPage');
    component.navigateCreditProject(projectsMockData.projectDetailsData.pagingItems[0],
      event, projectsMockData.projectDetailsData.pagingItems[0], 1);
    expect(spyNavigateToSalesOrderPage).toHaveBeenCalledWith(projectsMockData.projectDetailsData.pagingItems[0],
      projectsMockData.projectDetailsData.pagingItems[0], 1, event);
  });
});
