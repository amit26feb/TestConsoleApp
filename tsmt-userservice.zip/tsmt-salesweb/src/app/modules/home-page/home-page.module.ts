import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ExcelModule, GridModule } from '@progress/kendo-angular-grid';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { SalesWebOrdersModule } from '@tsmt/salesweb-ordersmodule';
import { SalesWebWorkpackageModule } from '@tsmt/salesweb-workpackagemodule';
import { SharedCoreSaleswebModule } from '@tsmt/shared-core-salesweb';
import { LoginComponent } from '../../login/login.component';
import { SharedModule } from '../../shared/modules/shared/shared.module';
import { UserInfoResolver } from '../../user-info-resolver.service';
import { HomeDashboardComponent } from './home-dashboard/home-dashboard.component';
import { HomePageListRoutingModule } from './home-page-list/home-page-list-routing.module';
import { HomePageListComponent } from './home-page-list/home-page-list.component';

@NgModule({
  declarations: [HomePageListComponent, LoginComponent, HomeDashboardComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    DropDownsModule,
    ExcelModule,
    GridModule,
    TooltipModule,
    HomePageListRoutingModule,
    LayoutModule,
    SharedModule,
    SalesWebOrdersModule,
    SalesWebWorkpackageModule,
    SharedCoreSaleswebModule,
  ],
  providers: [UserInfoResolver],
})
export class HomePageModule { }
