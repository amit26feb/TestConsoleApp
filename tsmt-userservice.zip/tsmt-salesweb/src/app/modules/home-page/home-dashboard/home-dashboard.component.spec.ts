import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { OktaAuthService, OKTA_CONFIG } from '@okta/okta-angular';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { UserInfoService, OfficeSelectorService } from '@tsmt/shared-core-salesweb';
import { of, BehaviorSubject } from 'rxjs';
import { HomeDashboardComponent, ITileInfoWithOrder } from './home-dashboard.component';
import { TileService, TileTypes } from '../../../shared/services/tile.service';
import { UserService } from '../../../modules/jobs-list-master/services/user.service';
import OktaConfig from '../../../.okta.config';
import { AppConstants } from '../../../shared/constants/constants';

describe('HomeDashboardComponent', () => {
  let component: HomeDashboardComponent;
  let fixture: ComponentFixture<HomeDashboardComponent>;
  let userInfoService: UserInfoService;
  let userService: UserService;
  let tileService: TileService;
  let officeSelectorService: OfficeSelectorService;

  const someRole = ['some-AD-role'];

  // ** support for Office Selector Service
  const oktaRoutingConfig = Object.assign({
    onAuthRequired: ({ oktaAuth, octaRouter }) => {
      octaRouter.navigate(['']);
    },
  }, OktaConfig.oidc);

  const testDrAddressId = 121;
  const officeSelected = {
    salesOfficeName: 'Billings',
    drAddressId: 121,
  };

  class RouterMock {
    url = '/dummy';
    events = new BehaviorSubject<NavigationEnd>(null);
    navigate() { }
  }
  // ** support for Office Selector Service (end)

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [HomeDashboardComponent],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        UserInfoService,
        TileService,
        UserService,
        OfficeSelectorService,
        AppConstants,
        // ** support for Office Selector Service
        OktaAuthService,
        {
          provide: 'environment', useValue: {
            apiUrl: 'http://test',
            oktaIssuer: 'https://test.okta.com/oauth2/test',
            oktaClientId: 'test'
          }
        },
        {
          provide: Router,
          useClass: RouterMock,
        },
        {
          provide: OKTA_CONFIG,
          useValue: oktaRoutingConfig
        },
        {
          provide: ActivatedRoute,
          useValue: {
            children: [{
              snapshot: { params: { jobId: 1234, drAddressId: testDrAddressId } },
            }],
            snapshot: {
              data: { userInfo: { samAccountName: 'ccfbsb' } },
              params: { drAddressId: testDrAddressId },
            },
          },
        },
        // support for Office Selector Service (end)
      ],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA,
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeDashboardComponent);
    component = fixture.componentInstance;
    userInfoService = TestBed.inject(UserInfoService);
    userService = TestBed.inject(UserService);
    tileService = TestBed.inject(TileService);
    officeSelectorService = TestBed.inject(OfficeSelectorService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return empty array on call to getUserTiles with null user roles', () => {
    spyOn(userService, 'getDashboardPreferences').and
      .returnValue(of({ tiles: [{ name: TileTypes.CreditApprovalBacklog, isVisible: true }] }));
    spyOn(userInfoService, 'getUserRoles').and.returnValue(null);
    spyOn(tileService, 'userCanSeeTile');
    spyOn(tileService, 'getUserAccessibleTiles').and.returnValue([]);
    component.ngOnInit();

    const result = component.getUserTiles();

    expect(result).toEqual([]);
  });

  it('should include tiles on call to getUserTiles with no user preferences', () => {
    spyOn(userService, 'getDashboardPreferences').and.returnValue(of(null));
    spyOn(userInfoService, 'getUserRoles').and.returnValue(someRole);
    spyOn(tileService, 'getUserAccessibleTiles').and
      .returnValue([{ type: TileTypes.CreditApprovalBacklog }, { type: TileTypes.CreditMetrics }]);
    component.ngOnInit();

    const result = component.getUserTiles();

    expect(result).toEqual([
      { type: TileTypes.CreditApprovalBacklog, order: 0 },
      { type: TileTypes.CreditMetrics, order: 0 }] as ITileInfoWithOrder[]);
  });

  it('should not include tiles on call to getUserTiles when not visible in preferences', () => {
    spyOn(userService, 'getDashboardPreferences').and
      .returnValue(of({ tiles: [{ name: TileTypes.CreditApprovalBacklog, isVisible: false }] }));
    spyOn(userInfoService, 'getUserRoles').and.returnValue(someRole);
    spyOn(tileService, 'getUserAccessibleTiles').and
      .returnValue([{ type: TileTypes.CreditApprovalBacklog }, { type: TileTypes.CreditMetrics }]);
    component.ngOnInit();

    const result = component.getUserTiles();

    expect(result).toEqual([{ type: TileTypes.CreditMetrics, order: 0 }] as ITileInfoWithOrder[]);
  });

  it('should set drAddressId to selected office id on initialization', fakeAsync(() => {

    spyOn(officeSelectorService, 'getSelectedOffice').and.returnValue(of(officeSelected));
    component.ngOnInit();

    tick();

    expect(testDrAddressId).toEqual(component.drAddressId);

  }));

  it('should add order information from preferences on call to getUserTiles', () => {
    spyOn(userService, 'getDashboardPreferences').and
      .returnValue(of({ tiles: [{ name: TileTypes.CreditApprovalBacklog, isVisible: true, sequence: 2 }] }));
    spyOn(userInfoService, 'getUserRoles').and.returnValue(someRole);
    spyOn(tileService, 'getUserAccessibleTiles').and
      .returnValue([{ type: TileTypes.CreditApprovalBacklog }, { type: TileTypes.CreditMetrics }]);
    component.ngOnInit();

    const result = component.getUserTiles();

    expect(result).toEqual([
      { type: TileTypes.CreditApprovalBacklog, order: 2 },
      { type: TileTypes.CreditMetrics, order: 0 }] as ITileInfoWithOrder[]);
  });
});
