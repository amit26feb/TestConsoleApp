import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subscription } from 'rxjs';

import { OfficeSelectorService, UserInfoService } from '@tsmt/shared-core-salesweb';
import { UserService } from '../../../modules/jobs-list-master/services/user.service';
import { IDashboardPreference } from '../../../shared/model/dashboard-preferences';
import { ITileInfo, TileService, TileTypes } from '../../../shared/services/tile.service';

export interface ITileInfoWithOrder extends ITileInfo {
  order: number;
}

@Component({
  selector: 'app-home',
  templateUrl: './home-dashboard.component.html',
  styleUrls: ['./home-dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None,
})

export class HomeDashboardComponent implements OnDestroy, OnInit {
  private userRoles: string[];
  private userPreferences: IDashboardPreference;
  private subscriptions: Subscription[] = [];

  public TileType = TileTypes;
  public drAddressId: number;

  constructor(
    private userInfoService: UserInfoService,
    private tileService: TileService,
    private userService: UserService,
    private officeSelectorService: OfficeSelectorService) {
  }

  ngOnInit(): void {
    this.userRoles = this.userInfoService.getUserRoles() ?? [];

    this.subscriptions.push(this.userService.getDashboardPreferences().subscribe(prefs => {
      this.userPreferences = prefs ?? { tiles: [] };
    }));

    this.subscriptions.push(this.officeSelectorService.getSelectedOffice().subscribe(
      selectedOffice => {
        this.drAddressId = selectedOffice.drAddressId;
      }
    ));
  }

  ngOnDestroy(): void {
    while (this.subscriptions.length > 0) {
      const subscription = this.subscriptions.shift();
      subscription.unsubscribe();
    }
  }

  public getUserTiles(): ITileInfoWithOrder[] {
    if (this.userRoles) {
      return this.tileService.getUserAccessibleTiles(this.userRoles).filter((tile) => {
        // filter out hidden tiles
        const tilePref = this.userPreferences.tiles?.find(t => t.name === tile.type);
        return tilePref ? tilePref.isVisible : true;
      }).map((tile) => {
        // add saved order from preference
        const tilePref = this.userPreferences.tiles.find(t => t.name === tile.type);
        (tile as ITileInfoWithOrder).order = tilePref ? tilePref.sequence : 0;
        return tile as ITileInfoWithOrder;
      });
    } else {
      return [];
    }
  }
}
