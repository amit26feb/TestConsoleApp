export enum HomePageTitlesEnum {
  Jobs = 'Jobs',
  Projects = 'Projects',
  WorkPackages = 'Work Packages',
  Home = 'Home',
}
