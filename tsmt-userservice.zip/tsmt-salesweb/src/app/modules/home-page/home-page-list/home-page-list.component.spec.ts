import { ApiErrorService } from './../../../shared/services/apierror.service';
import { HomePageTitlesEnum } from './../models/home-page-title.model';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { OKTA_CONFIG, OktaAuthService } from '@okta/okta-angular';
import { WorkPackageSearchService } from '@tsmt/salesweb-workpackagemodule';
import { OfficeSelectorService, CommonService as CommonServiceService } from '@tsmt/shared-core-salesweb';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { BehaviorSubject, Observable, Subject, Subscription } from 'rxjs';
import OktaConfig from '../../../.okta.config';
import { AppConstants } from '../../../shared/constants/constants';
import { IOfficeSelectorModel } from '../../../shared/model/office-selector-model';
import { GlobalFilterService } from '../../../shared/services/global-filter.service';
import { GlobalSearchService } from '../../../shared/services/global-search.service';
import { FilterServiceMock } from '../../../shared/test-mocks/filterservice-mock';
import { WorkPackageModule } from '../../work-package/work-package.module';
import { JobHeaderService } from '.././../../shared/services/job-header.service';
import { HomePageListRoutingModule } from './home-page-list-routing.module';
import { HomePageListComponent } from './home-page-list.component';
import { LoaderService } from '@tsmt/shared-core';
import { JobsService } from '@tsmt/salesweb-jobsmodule';
const homepageList = '/home-page-list';
class RouterMock {
  url = homepageList;
  events = new BehaviorSubject<NavigationEnd>(null);
  navigate(value) {
  }
}

const officeSelected = {
  salesOfficeName: 'Billings',
  drAddressId: 121,
  country: 'USA',
  crmIntegrationInd: 'Y',
};

describe('HomePageListComponent', () => {
  let component: HomePageListComponent;
  let fixture: ComponentFixture<HomePageListComponent>;
  let route: ActivatedRoute;
  let router: Router;
  let commonService: CommonServiceService;
  let globalFilterService: GlobalFilterService;
  let globalSearchService: GlobalSearchService;
  let workPackageSearchService: WorkPackageSearchService;
  let officeSelectorService: OfficeSelectorService;
  let injector: TestBed;
  let apiErrorService: ApiErrorService;
  let jobsService: JobsService;
  const testDrAddressId = 121;
  const projects = 'Projects';
  const workPackages = 'Work Packages';

  const oktaRoutingConfig = Object.assign({
    onAuthRequired: ({ oktaAuth, octaRouter }) => {
      // Redirect the user to your custom login page
      octaRouter.navigate(['']);
    },
  }, OktaConfig.oidc);

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [HomePageListComponent],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        HomePageListRoutingModule,
        WorkPackageModule,
        HttpClientTestingModule,
        TranslateModule.forRoot(),
      ],
      providers: [
        AppConstants, OktaAuthService, GlobalSearchService, CommonServiceService,
        { provide: OKTA_CONFIG, useValue: oktaRoutingConfig },
        { provide: GlobalFilterService, useClass: FilterServiceMock },
        {
          provide: ActivatedRoute, useValue: {
            children: [{
              snapshot: { params: { jobId: 1234, drAddressId: 2345 } },
            }],
            snapshot: {
              data: { userInfo: { samAccountName: 'ccfbsb', given_name: 'testName' } },
              params: { drAddressId: testDrAddressId },
            },
          },
        },
        ApiErrorService,
        JobsService,
        LoaderService,
        {
          provide: Router, useClass: RouterMock,
        }, JobHeaderService, OfficeSelectorService, WorkPackageSearchService], schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(HomePageListComponent);
    component = fixture.componentInstance;
    route = injector.inject(ActivatedRoute);
    router = injector.inject(Router);
    commonService = injector.inject(CommonServiceService);
    globalFilterService = injector.inject(GlobalFilterService);
    globalSearchService = injector.inject(GlobalSearchService);
    officeSelectorService = TestBed.inject(OfficeSelectorService);
    workPackageSearchService = TestBed.inject(WorkPackageSearchService);
    apiErrorService = TestBed.inject(ApiErrorService);
    jobsService = TestBed.inject(JobsService);
  });

  afterEach(() => {
    component?.ngOnDestroy();
  });

  it('should set default sales office and set default tab to work packages', () => {
    const salesOfficeList: IOfficeSelectorModel[] = [
      {
        salesOfficeName: 'test1', drAddressId: 121, country: 'USA', crmIntegrationInd: 'Y', homeDrAddressId: 101,
        groupName: 'CTXDBSELECTOR', createJobInd: 'A',
      },
      {
        salesOfficeName: 'test2', drAddressId: 122, country: 'USA', crmIntegrationInd: 'Y', homeDrAddressId: 101,
        groupName: 'CTXDBSELECTOR', createJobInd: 'A',
      }] as IOfficeSelectorModel[];
    spyOn(router, 'navigate').and.callThrough();
    route.snapshot.params = Observable.of({ drAddressId: undefined });
    spyOn(component, 'clearSearchText');
    spyOn(officeSelectorService, 'getSelectedOffice').and.returnValue(Observable.of(officeSelected));
    spyOn(officeSelectorService, 'getOfficeSelectorList').and.returnValue(Observable.of(salesOfficeList));
    component.ngOnInit();
    const url = router.url.split('/');
    expect(url.length).toBeLessThan(4);
    expect(component.hideTabs).toBe(false);
    expect(component.salesOfficeName).toBe('Billings');
    expect(component.clearSearchText).toHaveBeenCalled();
  });

  it('should set default sales office to first when there homeDrAddressId to 0, get title and add subscription', () => {
    const salesOffices: IOfficeSelectorModel[] = [
      {
        salesOfficeName: 'test1', drAddressId: 121, country: 'USA', crmIntegrationInd: 'Y', homeDrAddressId: 0,
        groupName: 'CTXDBSELECTOR', createJobInd: 'A',
      },
      {
        salesOfficeName: 'test2', drAddressId: 122, country: 'USA', crmIntegrationInd: 'Y', homeDrAddressId: 0,
        groupName: 'CTXDBSELECTOR', createJobInd: 'A',
      }] as IOfficeSelectorModel[];
    spyOn(router, 'navigate').and.callThrough();
    spyOn(globalFilterService, 'getSelectedOffice').and.returnValue(Observable.of(officeSelected));
    spyOn(globalFilterService, 'getOfficeSelectorList').and.returnValue(Observable.of(salesOffices));
    spyOn(officeSelectorService, 'getSelectedOffice').and.returnValue(Observable.of(officeSelected));
    spyOn(officeSelectorService, 'getOfficeSelectorList').and.returnValue(Observable.of(salesOffices));
    spyOn(component, 'getTitle').and.returnValue(workPackages);
    component.selectedMenu = [{ title: workPackages, status: true, url: 'work-packages' }];
    component.ngOnInit();
    expect(component.selectedTab).toBe(workPackages);
    expect(component.isLoadTsmtOfficeSelector).toBe(true);
    expect(component.subscriptions.length).toBe(2);
  });

  it('should get title on calling getTitle method', () => {
    const title = component.getTitle();
    expect(component.currentUrl).toBe('home-page-list');
    expect(title).toEqual('Work Packages');
  });

  it('should route to projects on calling #(onTabSelect) function with projects tab', () => {
    spyOn(router, 'navigate').and.callThrough();
    component.drAddressId = 121;
    component.onTabSelect({ title: projects });
    expect(router.navigate).toHaveBeenCalledWith(['projects/121']);
    expect(component.selectedTab).toEqual(projects);
    expect(component.searchValue).toEqual('');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call hide on loaderService when router event is emitted', fakeAsync(() => {
    spyOn(LoaderService.prototype, 'hide');
    TestBed.compileComponents();
    const event = new NavigationEnd(42, '/', '/');
    (router.events as unknown as Subject<NavigationEnd>).next(event);
    tick();
    expect(LoaderService.prototype.hide).toHaveBeenCalled();
  }));

  it('should set search value and show icon on calling onKey with data', () => {
    const data = { target: { value: 'test' } };
    component.onKey(data);
    expect(component.searchValue).toBe('test');
    expect(component.showIcon).toBe(true);
  });

  it('should set search value to empty and hide icon on calling onKey with data empty', () => {
    const data = { target: { value: '' } };
    component.onKey(data);
    expect(component.searchValue).toBe('');
    expect(component.showIcon).toBe(false);
  });

  it('should set currentToggleSelected to Transmitted on calling onTabSelect', () => {
    component.drAddressId = 122;
    component.hideTabs = false;
    spyOn(LoaderService.prototype, 'show');
    spyOn(apiErrorService, 'hide');
    component.onTabSelect({ title: HomePageTitlesEnum.Projects });
    expect(LoaderService.prototype.show).toHaveBeenCalled();
    expect(apiErrorService.hide).toHaveBeenCalled();
    expect(component.currentToggleSelected).toEqual('Transmitted');
  });

  it('should clear search value and call searchValue next on calling clearSearchText', () => {
    component.searchValue = 'test';
    component.alreadySearchedValue = 'test';
    component.selectedTab = projects;
    component.drAddressId = 101;
    spyOn(globalSearchService.searchValue, 'next');
    component.clearSearchText();
    expect(component.searchValue).toBe('');
    expect(component.showIcon).toBe(false);
    expect(component.alreadySearchedValue).toBe(null);
    expect(globalSearchService.searchValue.next).toHaveBeenCalledWith('');
  });

  it('should clear search value & call workPackageSearchService if selectedTab is work packages applied on calling clearSearchText', () => {
    component.searchValue = 'test';
    component.alreadySearchedValue = 'test';
    component.selectedTab = workPackages;
    component.drAddressId = 101;
    spyOn(workPackageSearchService, 'searchList');
    component.clearSearchText();
    expect(component.searchValue).toBe('');
    expect(component.showIcon).toBe(false);
    expect(component.alreadySearchedValue).toBe(null);
    expect(workPackageSearchService.searchList).toHaveBeenCalledWith(101, '', workPackages);
  });

  it(`should set currentToggleSelected to Transmitted when selectedTab is projects and
  currentToggleSelected is undefined on calling setPageDefaults`, () => {
    component.currentToggleSelected = undefined;
    component.selectedTab = HomePageTitlesEnum.Projects;
    component.setPageDefaults();
    expect(component.currentToggleSelected).toEqual('Projects');
  });

  it(`should set isLoadTsmtOfficeSelector to false when selectedTab is projects and
  currentToggleSelected is Transmitted on calling setPageDefaults`, () => {
    component.currentToggleSelected = 'Transmitted';
    component.selectedTab = HomePageTitlesEnum.Projects;
    spyOn(component, 'clearSearchText');
    component.setPageDefaults();
    expect(component.isLoadTsmtOfficeSelector).toBe(false);
    expect(component.clearSearchText).toHaveBeenCalled();
  });

  it('should clear search value and not call default search on calling clearSearchText', () => {
    spyOn(globalSearchService, 'searchList');
    component.clearSearchText();
    expect(component.searchValue).toBe('');
    expect(component.showIcon).toBe(false);
    expect(globalSearchService.searchList).not.toHaveBeenCalled();
  });

  it('should trigger global search if it has value and not searched before on calling searchRecords', () => {
    component.searchValue = 'test';
    component.alreadySearchedValue = '1674';
    spyOn(globalSearchService, 'searchList');
    component.searchRecords('test');
    expect(globalSearchService.searchList).toHaveBeenCalled();
    expect(component.alreadySearchedValue).toBe('test');
  });

  it('should trigger workPackageSearchService if it has value and not searched before on calling searchRecords', () => {
    component.searchValue = 'test';
    component.drAddressId = 101;
    component.alreadySearchedValue = '1674';
    component.selectedTab = workPackages;
    spyOn(workPackageSearchService, 'searchList');
    component.searchRecords('test');
    expect(workPackageSearchService.searchList).toHaveBeenCalledWith(101, 'test', workPackages);
    expect(component.alreadySearchedValue).toBe('test');
  });

  it('should not trigger global search if its already searched with same value on calling searchRecords', () => {
    component.searchValue = 'test';
    component.alreadySearchedValue = 'test';
    spyOn(globalSearchService, 'searchList');
    component.searchRecords('test');
    expect(globalSearchService.searchList).not.toHaveBeenCalled();
  });

  it('should show error if clicked n search button without value on calling searchRecords', () => {
    component.searchValue = '';
    spyOn(globalSearchService, 'searchList');
    component.searchRecords('');
    expect(component.error).toBe(true);
    expect(component.errorText).toBe('Enter a Key Word');
  });

  it('should trigger global search on ngAfterViewInit if it has alreadySearchedValue value and activeToggle value', () => {
    component.alreadySearchedValue = 'abc';
    component.selectedTab = projects;
    commonService.activeToggleState = new BehaviorSubject('History');
    spyOn(globalSearchService, 'searchList');
    component.searchRecords('test');
    component.ngAfterViewInit();
    expect(globalSearchService.searchList).toHaveBeenCalled();
  });

  it('should set currentToggleSelected to Transmitted on calling ngAfterViewInit', () => {
    component.currentToggleSelected = '';
    commonService.activeToggleState = new BehaviorSubject(null);
    component.ngAfterViewInit();
    expect(component.currentToggleSelected).toEqual('Transmitted');
  });

  it('should not trigger global search on ngAfterInit if alreadySearchedValue has null value', () => {
    commonService.activeToggleState = new BehaviorSubject('History');
    component.alreadySearchedValue = '';
    spyOn(globalSearchService, 'searchList');
    component.searchRecords('');
    component.ngAfterViewInit();
    expect(globalSearchService.searchList).not.toHaveBeenCalled();
  });

  it('should set currentToggleSelected with selectedTab value when ngAfterInit called', () => {
    commonService.activeToggleState = new BehaviorSubject('');
    component.selectedTab = workPackages;
    component.ngAfterViewInit();
    expect(component.currentToggleSelected).toEqual(component.selectedTab);
  });

  it('should call unsubscribe on routerEventSubscription and other events on subscriptions on calling ngOnDestroy', () => {
    component.routerEventSubscription = new Subscription();
    spyOn(component.routerEventSubscription, 'unsubscribe');
    component.ngOnDestroy();
    expect(component.routerEventSubscription.unsubscribe).toHaveBeenCalled();
    expect(component.subscriptions.length).toEqual(0);
  });

  it('should default showSearch to true', () => {
    expect(component.showSearch).toBe(true);
  });

  it('should set showSearch to true if selected tab is not Home', () => {
    component.drAddressId = 1;
    component.hideTabs = false;
    component.showSearch = false;

    component.onTabSelect({ title: HomePageTitlesEnum.Jobs });
    expect(component.showSearch).toBe(true);

    component.showSearch = false;
    component.onTabSelect({ title: HomePageTitlesEnum.Projects });
    expect(component.showSearch).toBe(true);

    component.showSearch = false;
    component.onTabSelect({ title: HomePageTitlesEnum.WorkPackages });
    expect(component.showSearch).toBe(true);
  });

  it('should change showSearch to false if selected tab is Home', () => {
    component.drAddressId = 1;
    component.hideTabs = false;
    component.showSearch = true;

    component.onTabSelect({ title: HomePageTitlesEnum.Home });
    expect(component.showSearch).toBe(false);
  });
});
