import { AfterViewInit, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { JobsService } from '@tsmt/salesweb-jobsmodule';
import { WorkPackageSearchService } from '@tsmt/salesweb-workpackagemodule';
import { LoaderService } from '@tsmt/shared-core';
import { IOfficeSelector, OfficeSelectorService, CommonService as CommonServiceService } from '@tsmt/shared-core-salesweb';
import { Subscription } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ApiErrorService } from './../../../shared/services/apierror.service';
import { GlobalSearchService } from './../../../shared/services/global-search.service';
import { JobHeaderService } from './../../../shared/services/job-header.service';
import { HomePageTitlesEnum } from './../models/home-page-title.model';
@Component({
  selector: 'app-home-page-list',
  templateUrl: './home-page-list.component.html',
  styleUrls: ['./home-page-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [LoaderService],
})

export class HomePageListComponent implements OnInit, AfterViewInit, OnDestroy {
  public disable = false;
  public showIcon = false;
  public error: boolean;
  public errorText: string;
  public selectedTab = '';
  public drAddressId: number;
  public salesOfficeName: string;
  public currentUrl: string;
  public selectedMenu: any;
  public searchValue: string;
  public searchStatus: boolean;
  public alreadySearchedValue: any;
  public currentToggleSelected: string;
  public routerEventSubscription: Subscription;
  public activeToggleSubscription: Subscription;
  public subscriptions: Subscription[] = [];
  ShippingHistoryDisplayMode: string;
  alertMessage: string;
  public tabMenus = [
    { title: HomePageTitlesEnum.Home, status: true, url: 'home' },
    { title: HomePageTitlesEnum.Jobs, status: true, url: 'jobs-list' },
    { title: HomePageTitlesEnum.Projects, status: true, url: 'projects' },
    { title: HomePageTitlesEnum.WorkPackages, status: true, url: 'home-page-list' },
  ];
  public hideTabs = false;
  public isLoadTsmtOfficeSelector = true;
  public showSearch = true;
  constructor(
    private route: ActivatedRoute,
    private jobHeaderService: JobHeaderService,
    private router: Router,
    private titleService: Title,
    private globalSearchService: GlobalSearchService,
    private translateService: TranslateService,
    private commonService: CommonServiceService,
    private officeSelectorService: OfficeSelectorService,
    private workPackageSearchService: WorkPackageSearchService,
    private apiErrorService: ApiErrorService,
    private appConstants: AppConstants,
    private loaderService: LoaderService,
    private jobsService: JobsService) {
    this.translateService.setDefaultLang(this.appConstants.TRANSLATION_LANGUAGE);
    this.ShippingHistoryDisplayMode = this.appConstants.ShippingHistoryDisplayMode;
    const user = this.route.snapshot.data['userInfo'];
    if (user) {
      this.jobHeaderService.setUserId(user['samAccountName']);
      this.jobHeaderService.setUserName(user['given_name'] + ' (' + user['samAccountName'] + ')');
      this.jobHeaderService.setFullName(user['name']);
    }
    this.routerEventSubscription = this.router.events.filter(event => event instanceof NavigationEnd).subscribe(event => {
      this.selectedTab = this.getTitle();
      this.setPageDefaults();
      this.loaderService.hide();
    });
  }

  ngOnInit() {
    this.translateService.use(this.appConstants.TRANSLATION_LANGUAGE);

    if (typeof this.router.url === 'string') {
      this.hideTabs = (this.router.url.includes('exit')) ?
        true : (this.router.url.split('/').length > 4);
    }
    // update title on office selector change
    this.subscriptions.push(this.officeSelectorService.getSelectedOffice().subscribe(
      selectedOffice => this.updateTitleAndClearSearch(selectedOffice)));
    this.subscriptions.push(this.jobsService.searchClear.subscribe(() => {
      this.clearSearchText();
    }));
    this.alertMessage = `<ol>
    <li>Searches large unitary and applied systems equipment, DOES NOT include light commercial unitary (gen. <25T)</li>
    <li>Serial Number search also returns Sales Order number such as "A1A123", which is expanded to
        "A1-A123" for system to search archival scanned documents</li>
    <li>Partial character search is highly recommended, start with full Serial Number string and then try
        number groupings</li>
    <li>Not all units are in this historical location - record availability for serial numbers pre-1994 depends on product, and records for serial numbers J96-J98 are generally not available</li>
</ol>`;
  }

  ngAfterViewInit() {
    /* getting current selected toggle information from project screen*/
    this.activeToggleSubscription = this.commonService.activeToggleState.subscribe((activeToggle: string) => {
      if (activeToggle && this.selectedTab === HomePageTitlesEnum.Projects) {
        // Added isLoadTsmtOfficeSelector is false when selected tab is project to display app office selector component
        this.isLoadTsmtOfficeSelector = activeToggle === 'Untransmitted';
        this.currentToggleSelected = activeToggle;
        if (this.alreadySearchedValue !== '' && this.currentToggleSelected) {
          // get records with search filter
          this.globalSearchService.searchList(this.searchValue, this.selectedTab, this.drAddressId, this.currentToggleSelected);
        }
      } else if (this.selectedTab === (HomePageTitlesEnum.WorkPackages || HomePageTitlesEnum.Jobs)) {
        // Added isLoadTsmtOfficeSelector is true when selected tab is Work Packages to display TSMT office selector component
        this.isLoadTsmtOfficeSelector = true;
        this.currentToggleSelected = this.selectedTab;
      } else {
        this.currentToggleSelected = 'Transmitted';
      }
    });
    this.loaderService.hide();
  }

  ngOnDestroy(): void {
    this.routerEventSubscription?.unsubscribe();
    this.activeToggleSubscription?.unsubscribe();
    while (this.subscriptions.length > 0) {
      const subscription = this.subscriptions.shift();
      subscription.unsubscribe();
    }
  }

  getTitle() {
    const urlArray = this.router.url.split('/');
    if (!urlArray.includes('work-packages')) {
      this.currentUrl = urlArray[1];
      this.drAddressId = +urlArray.pop();
      this.selectedMenu = this.tabMenus.filter((menu) => this.currentUrl === menu.url);
      // by default projects tab will be Selected but on refresh current tab
      return this.selectedMenu.length > 0 ? this.selectedMenu[0].title : this.tabMenus[1].title;
    } else {
      this.drAddressId = this.route.snapshot.params['drAddressId'];
      this.selectedMenu = { title: HomePageTitlesEnum.WorkPackages, status: true, url: 'work-packages' };
      return HomePageTitlesEnum.WorkPackages;
    }
  }

  onTabSelect(event: any) {
    if (this.selectedTab !== event.title && this.drAddressId && !this.hideTabs) {
      this.loaderService.show();
      this.apiErrorService.hide();
      this.selectedTab = event.title;
      this.searchValue = '';
      this.currentToggleSelected = 'Transmitted';
      const item = this.tabMenus.filter((tab: any) => tab.title === event.title)[0];
      const routeToHomePageUrl = `${item.url}/${this.drAddressId}`;
      event.title === HomePageTitlesEnum.WorkPackages ?
        this.router.navigate([routeToHomePageUrl + '/work-packages']) : this.router.navigate([routeToHomePageUrl]);
      this.showSearch = event.title !== HomePageTitlesEnum.Home;
    }
  }

  // set default properties on page load like title , isLoadTsmtOfficeSelector and currentToggleSelected
  setPageDefaults(): void {
    this.error = false;
    this.alreadySearchedValue = '';
    this.isLoadTsmtOfficeSelector = true;
    this.titleService.setTitle(this.selectedTab + '-' + this.salesOfficeName);
    this.currentToggleSelected = this.currentToggleSelected ?? this.selectedTab;
    if (this.selectedTab === HomePageTitlesEnum.Projects) {
      this.currentToggleSelected = this.currentToggleSelected ?? 'Transmitted';
      this.isLoadTsmtOfficeSelector = this.currentToggleSelected === 'Untransmitted';
    }
    this.clearSearchText();
  }

  onKey(data: any) {
    this.searchValue = data.target.value;
    if (this.searchValue !== '') {
      this.error = false;
      this.showIcon = true;
    } else {
      this.showIcon = false;
      this.clearSearchText();
    }
  }

  public clearSearchText() {
    this.showIcon = false;
    this.searchValue = '';
    // get records with no search filter
    if (this.alreadySearchedValue) {
      // Added condition to call work package search service to load the grid data
      if (this.selectedTab === HomePageTitlesEnum.WorkPackages) {
        this.workPackageSearchService.searchList(this.drAddressId, this.searchValue, this.selectedTab);
      } else if (this.selectedTab === HomePageTitlesEnum.Projects) {
        this.globalSearchService.searchValue.next('');
      } else {
        this.globalSearchService.searchList(this.searchValue, this.selectedTab, this.drAddressId);
      }
      this.alreadySearchedValue = null;
    }
  }

  public searchRecords(searchText: string) {
    if (this.searchValue !== '') {
      if (this.alreadySearchedValue !== searchText) {
        // get records with search filter
        // Added condition for calling work package search service to load the grid data
        if (this.selectedTab === HomePageTitlesEnum.WorkPackages) {
          this.workPackageSearchService.searchList(this.drAddressId, this.searchValue, this.selectedTab);
        } else {
          this.globalSearchService.searchList(this.searchValue, this.selectedTab, this.drAddressId, this.currentToggleSelected);
        }
        this.alreadySearchedValue = searchText;
        localStorage.setItem('setSearchText', searchText);
      }
    } else {
      this.error = true;
      this.errorText = 'Enter a Key Word';
    }
  }


  /**
   * Update title and clear search text
   * @param val as IOfficeSelector
   */
  private updateTitleAndClearSearch(val: IOfficeSelector): void {
    this.salesOfficeName = val.salesOfficeName;
    this.drAddressId = val.drAddressId;
    const title = this.getTitle();
    if (this.selectedMenu.length > 0) {
      this.selectedTab = title;
    }
    this.titleService.setTitle(this.selectedTab + '-' + this.salesOfficeName);
    // clear search value
    this.clearSearchText();
  }

}
