import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OktaAuthGuard } from '@okta/okta-angular';
import { ExitComponent } from '@tsmt/shared-core-salesweb';

import { HomePageListComponent } from './home-page-list.component';
import { UserInfoResolver } from './../../../user-info-resolver.service';

// route guard
import { TSMTMenuGuard } from './../../../auth/menu-guard.service';
import { HomeDashboardComponent } from '../home-dashboard/home-dashboard.component';

const HomePageListRoutes: Routes = [
  {
    path: '',
    component: HomePageListComponent,
    resolve: {
      userInfo: UserInfoResolver,
    },
    children: [
      {
        path: 'home/:drAddressId',
        resolve: {
          userInfo: UserInfoResolver,
        },
        pathMatch: 'full',
        canActivate: [OktaAuthGuard, TSMTMenuGuard],
        component: HomeDashboardComponent,
      },
      {
        path: 'jobs-list/:drAddressId',
        resolve: {
          userInfo: UserInfoResolver,
        },
        pathMatch: 'full',
        canActivate: [OktaAuthGuard, TSMTMenuGuard],
        loadChildren: () => import('../../jobs-list-master/jobs-list-master.module').then((m) => m.JobsListMasterModule)
        , data: { Ctitle: 'Sales Tools', headerData: '', routeName: 'jobs-list' },
      },
      {
        path: 'projects/:drAddressId',
        resolve: {
          userInfo: UserInfoResolver,
        },
        loadChildren: () => import('../../orders/orders.module').then((project) => project.OrdersModule),
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'projects' },
      },
      {
        path: 'work-packages',
        loadChildren: () => import('../../work-package/work-package.module').then((work) => work.WorkPackageModule),
      },
      {
        path: ':jobId/work-packages',
        loadChildren: () => import('../../work-package/work-package.module').then((work) => work.WorkPackageModule),
      },
      {
        path: ':isLockedBySomeoneElse/:item/exit',
        component: ExitComponent,
        pathMatch: 'full',
      },
    ],
  },
  {
    path: 'jobs-list',
    resolve: {
      userInfo: UserInfoResolver,
    },
    pathMatch: 'prefix',
    canActivate: [OktaAuthGuard, TSMTMenuGuard],
    loadChildren: () => import('../../jobs-list-master/jobs-list-master.module').then((m) => m.JobsListMasterModule)
    , data: { Ctitle: 'Sales Tools', headerData: '', routeName: 'jobs-list' },
  },
  {
    path: 'projects',
    resolve: {
      userInfo: UserInfoResolver,
    },
    loadChildren: () => import('../../orders/orders.module').then((project) => project.OrdersModule),
    canActivate: [TSMTMenuGuard],
    pathMatch: 'prefix',
    data: { routeName: 'projects' },
  }

];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(HomePageListRoutes),
  ],
  exports: [RouterModule],
})
export class HomePageListRoutingModule { }
