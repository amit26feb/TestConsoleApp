import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { JobDetailsEditComponent } from '@tsmt/salesweb-jobsdetailsmodule';
import { JobLockService as SharedJobLockService } from '@tsmt/shared-core-salesweb';
import { JobLockService as LockService } from '@tsmt/shared-acquisition-dataservices';
import { ApiErrorService } from './../../shared/services/apierror.service';
import { JobHeaderService } from './../../shared/services/job-header.service';
import { CoordinateComponent } from './coordinate/coordinate.component';
import { IJobLockModel } from './models/job-lock-model';
import { ExitJobService } from './services/exit-job.service';
import { JobLockService } from './services/job-lock.service';
import { JobsServicesService } from './services/jobs-services.service';
import { ICommonTitle } from './../../shared/model/common-title';

@Component({
  selector: 'app-jobs-list-master',
  templateUrl: './jobs-list-master.component.html',
})
export class JobsListMasterComponent implements OnInit {
  public pageHeader: string;
  public listItems = [];
  public jobId: number;
  public drAddressId: number;
  public hideJobTitle: boolean;
  public jobLockUserId: string;
  public jobName: string = null;
  public initialLockInfo: IJobLockModel = null;
  public showLoader = true;
  public jobExited: boolean;
  public showOfficeSelection = false;
  public showCoordinateInfo = false;
  // variable to store the  active component in the current route.
  public currentRouteCompRef: any;
  public commonTitle: ICommonTitle;

  constructor(
    private route: ActivatedRoute, private jobHeaderService: JobHeaderService,
    private jobService: JobsServicesService, private titleService: Title,
    private apiErrorService: ApiErrorService, private exitJobService: ExitJobService,
    private jobLockService: JobLockService,
    private sharedJobLockService: SharedJobLockService,
    private lockService: LockService,
    private translateService: TranslateService) {
    this.translateService.setDefaultLang('en');
    const user = this.route.snapshot.data['userInfo'];
    if (user) {
      this.jobHeaderService.setUserId(user['samAccountName']);
      this.jobHeaderService.setUserName(user['given_name'] + ' (' + user['samAccountName'] + ')');
      this.jobHeaderService.setFullName(user['family_name'] + ', ' + user['given_name']);
    }
  }

  ngOnInit() {
    this.translateService.use('en');
    this.pageHeader = 'Jobs List';
    this.jobId = +this.route.children[0].snapshot.params['jobId'];
    this.drAddressId = +this.route.children[0].snapshot.params['drAddressId'];
    // prevent making api call for pages that do not have jobId and drAddressId in the url
    if (!isNaN(this.jobId) && !isNaN(this.drAddressId)) {
      this.fetchJobHeaderDetails();
    } else {
      this.showLoader = false;
    }
  }



  handleExitJobAttempt() {
    // prevent the call to closeAndExitJob if the request is JobDetailsEditComponent because
    // it is being handled at the component level itself
    if (!(this.currentRouteCompRef instanceof JobDetailsEditComponent)
      && !(this.currentRouteCompRef instanceof CoordinateComponent)) {
      this.showLoader = true;
      this.exitJobService.CloseAndExitJob(this.jobId, this.drAddressId, this.jobLockUserId);
      this.jobExited = true;
    } else {
      this.jobExited = false;
    }
    try {
      // If the component loaded in the current route doesn't have a method
      // handleExitJobAttempt script might throw the error to handle such
      // situations try is used here. It is onto the respective components
      // to have a handler or not.
      this.jobExited = this.currentRouteCompRef.handleExitJobAttempt();
    } catch (e) {
    }
  }

  handleJobLockChange(readOnly: boolean, userId: string, nameFirst: string, nameLast: string) {
    // We need to keep track of the locking user, since we care about this when they attempt to exit the job.
    this.jobLockUserId = userId;

    this.jobLockService.setLockInfo({ jobLockUserId: this.jobLockUserId, readOnly, userId, nameFirst, nameLast });
    // Passing data into library level to access these across the libraries.
    this.sharedJobLockService.setLockInfo({ jobLockUserId: this.jobLockUserId, readOnly, userId, nameFirst, nameLast });
  }

  onActivate(e) {
    this.currentRouteCompRef = e;
    if (this.currentRouteCompRef instanceof CoordinateComponent) {
      this.showCoordinateInfo = true;
    } else {
      this.showCoordinateInfo = false;
    }
    this.showOfficeSelection = true;
    if (this.jobExited) {
      this.showLoader = false;
    }
    this.updateLockInfoAndTitle();
  }

  updateLockInfoAndTitle(): void {
    if (!isNaN(this.jobId) && !isNaN(this.drAddressId)) {
      this.lockService.jobLockedUserDetails(this.drAddressId, this.jobId).subscribe((userInfo) => {
        this.initialLockInfo = { userId: userInfo.userId, nameFirst: userInfo.firstName, nameLast: userInfo.lastName };
        this.commonTitle = this.getCommonTitle();
        const lockInfo = {
          jobLockUserId: userInfo.userId, readOnly: false,
          userId: userInfo.userId, nameFirst: userInfo.firstName, nameLast: userInfo.lastName
        };
        // pass the updated lock info to sharedJobLockService and jobLockService(this will be removed in future)
        this.jobLockService.setLockInfo(lockInfo);
        this.sharedJobLockService.setLockInfo(lockInfo);
      });
    }
  }

  // get the title information
  getCommonTitle(): ICommonTitle {
    return {
      jobId: this.jobId,
      drAddressId: this.drAddressId,
      nameToDisplay: this.jobName,
      currentUserId: this.jobHeaderService.getUserId(),
      lockedUserId: this.initialLockInfo.userId,
      item: 'Job',
      routeName: 'jobs-list',
      exitComponentName: 'exit',
      isOfficeSelectorLabel: true,
      showExitButton: true,
    };
  }

  onDeActivate(e) {
    this.apiErrorService.hide();
  }



  public fetchJobHeaderDetails(): void {
    // fetch job details
    this.jobService.fetchJobDetails(this.jobId, this.drAddressId).subscribe((data) => {

      // job successfully found
      if (data && data.jobGeneral) {

        // Grab the data that the child job-title component cares about.
        this.initialLockInfo = { userId: data.userId, nameFirst: data.nameFirst, nameLast: data.nameLast };

        // Also need to stay aware of the locking user, since we care about this when they attempt to exit the job.
        this.jobLockUserId = data.userId;

        // set page/tab title
        this.jobName = data.jobGeneral.jobName;

        this.titleService.setTitle(this.jobName);

        this.showLoader = false;

        this.updateLockInfoAndTitle();
      }
    }, (err) => {
      this.apiErrorService.show(err.error.Message);
    });
  }


}
