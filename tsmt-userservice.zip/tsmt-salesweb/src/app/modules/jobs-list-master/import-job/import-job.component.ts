import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { UploadComponent } from '@progress/kendo-angular-upload';
import { AppConstants } from '../../../shared/constants/constants';
import { ApiErrorService } from '../../../shared/services/apierror.service';
import { GlobalFilterService } from '../../../shared/services/global-filter.service';
import { JobHeaderService } from '../../../shared/services/job-header.service';
import { ToasterService } from '@tsmt/shared-core';
import { shouldShowErrorsMaster } from '../../../shared/validators/should-show-errors-validators';
import { TraneSalesBusinessDataService } from '../services/trane-sales-business-data.service';
import { LoaderService } from './../../../shared/services/loader.service';
import { CreateJobComponent } from '../create/non-crm-job/non-crm-job.component';
import { JobsServicesService } from './../services/jobs-services.service';

@Component({
  selector: 'app-import-job',
  templateUrl: './import-job.component.html',
  styleUrls: ['./import-job.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ImportJobComponent extends CreateJobComponent implements OnInit, OnDestroy {
  importJobForm: FormGroup;
  uploadSaveUrl = '';
  uploadRemoveUrl = '';
  importLocationList: any[];
  submitted = false;
  locationOfficeValue: any;
  salesOfficeValue: any;
  selectedImportLocation: any;
  @Input() isJobLockedByUser: boolean;
  @ViewChild('kendoUpload') kendoUpload: UploadComponent;
  @ViewChild('importJobName') importJobName: ElementRef;
  @ViewChild('importJobHtmlForm') importJobHtmlForm: HTMLFormElement;

  constructor(public router: Router, public route: ActivatedRoute,
    public jobListService: JobsServicesService, public loaderService: LoaderService,
    public filterService: GlobalFilterService, public domainService: TraneSalesBusinessDataService,
    public jobHeaderService: JobHeaderService, public apiErrorService: ApiErrorService, public titleService: Title,
    private toasterService: ToasterService, private appConstants: AppConstants) {
    super(router, route, jobListService, loaderService, filterService,
      domainService, jobHeaderService, apiErrorService, titleService);
  }

  ngOnInit() {
    this.importJobForm = new FormGroup({
      Files: new FormControl(),
      destinationDrAddressId: new FormControl('', Validators.required),
      jobName: new FormControl('', [
        Validators.required,
      ]),
      salesOfficeId: new FormControl('', Validators.required),
      locationOfficeId: new FormControl('', Validators.required),
      commissionCode: new FormControl('', Validators.required),
      jobContact: new FormControl('', Validators.required),
    });
    super.ngOnInit();
    this.titleService.setTitle('Import Job');
  }

  onSubmit() {
    this.submitted = true;
    let isFormValid = true;
    if (!this.importJobForm.controls['Files'].value) {
      this.toasterService.setToaster('warning', 'Please select a file to import');
      isFormValid = false;
    }
    if (this.importJobForm.invalid) {
      for (const key in this.importJobForm.controls) {
        if (this.importJobForm.controls.hasOwnProperty(key)) {
          this.importJobForm.controls[key].markAsTouched();
        }
      }
      isFormValid = false;
    }
    if (isFormValid) {
      const formData = new FormData(this.importJobHtmlForm.nativeElement);
      formData.append('Files', this.importJobForm.controls['Files'].value);
      formData.append('Action', 'Import');
      this.jobListService.importJob(formData).subscribe((res) => {
        this.toasterService.setToaster('success',
          'Your import request has been accepted. You will receive a notification shortly on the request status');
        this.submitted = false;
      });
    }
  }

  onSelectEvent(e) {
    if (e.files.length > 1) {
      this.toasterService.setToaster('warning', this.appConstants.JOB_DETAILS_DOCUMENTS_MULTIPLE_FILE_UPLOAD_MESSAGE);
      e.preventDefault();
      // when drop or select executable file we checked below condition from array and so toaster message
    } else if (this.appConstants.IMPORT_JOB_DOCUMENTS_VALID_FILE_LIST.filter((x) => x !== e.files[0].extension).length > 0) {
      this.toasterService.setToaster('warning', this.appConstants.IMPORT_JOB_DOCUMENTS_FORBIDDEN_MESSAGE);
      e.preventDefault();
      // when select or drop valid file we upload in kendo files list
    } else {
      // when select or drop more than one valid single file we remove existing file from kendo files list
      if (this.kendoUpload.fileList.count > 0) {
        this.kendoUpload.clearFiles();
      }
      // after file select we set focus to job name control
      this.importJobName.nativeElement.focus();
      let jobName = e.files[0].name;
      if (jobName.indexOf('.') !== -1) {
        // extract the string from beginning to the last occurence of .
        // eg fileName = test.json, so display should strip of .json
        jobName = jobName.substring(0, jobName.lastIndexOf('.'));
      } else {
        jobName = '';
      }
      this.importJobForm.controls['jobName'].setValue(jobName);
      this.importJobForm.controls['Files'].setValue(e.files[0].rawFile);
      this.jobHeaderService.setImportJobOpenStatus(true);
    }
  }

  shouldShowErrors(controlName: string): boolean {
    return shouldShowErrorsMaster(this.importJobForm, controlName, this.submitted);
  }


  onCancel() {
    this.submitted = false;
    this.importJobForm.reset();
    super.ngOnInit();
    this.importJobForm.controls['destinationDrAddressId'].setValue(this.officeSelectorValue);
    this.kendoUpload.clearFiles();
    this.titleService.setTitle('Import Job');
  }

  errorEventHandler(e) {
    this.apiErrorService.show(e.response.message);
    this.toasterService.setToaster('error', this.appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_ERROR_MESSAGE);
  }

  successEventHandler(e) {
    if (e.response.status === 200) {
      this.toasterService.setToaster('success', this.appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_SUCCESS_MESSAGE);
      // after uploaded files we clear files
      this.kendoUpload.clearFiles();
    }
  }

  ngOnDestroy() {
    this.jobHeaderService.setImportJobOpenStatus(false);
  }

  removeEventHandler(e) {
    this.jobHeaderService.setImportJobOpenStatus(false);
    this.importJobForm.controls['jobName'].setValue('');
    this.importJobForm.controls['Files'].setValue(null);
  }

  emptySpaceLengthCheck(event: any) {
    // reset the jobName feild if it contains only white space
    if (event.target.value.trim().length === 0) {
      this.importJobForm.controls['jobName'].reset();
    }
  }
}
