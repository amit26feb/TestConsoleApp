import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { UploadModule } from '@progress/kendo-angular-upload';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ApiErrorService } from '../../../shared/services/apierror.service';
import { GlobalFilterService } from '../../../shared/services/global-filter.service';
import { JobHeaderService } from '../../../shared/services/job-header.service';
import { ToasterService } from '@tsmt/shared-core';
import { ApiErrorServiceMock } from '../../../shared/test-mocks/apierrorservice-mock';
import { FilterServiceMock } from '../../../shared/test-mocks/filterservice-mock';
import { ToasterMock } from '../../../shared/test-mocks/toasterservice-mock';
import { TraneSalesBusinessDataServiceMock } from '../../../shared/test-mocks/tranesalesbusinessdata-mock';
import { TraneSalesBusinessDataService } from '../services/trane-sales-business-data.service';
import { LoaderService } from './../../../shared/services/loader.service';
import { JobListServiceMock } from './../../../shared/test-mocks/jobService-mock';
import { LoaderServiceMock } from './../../../shared/test-mocks/loaderService-mock';
import { RouterMock } from './../../../shared/test-mocks/routerMock';
import { JobsServicesService } from './../services/jobs-services.service';
import { ImportJobComponent } from './import-job.component';

// tslint:disable-next-line:no-big-function
describe('ImportJobComponent', () => {
  let component: ImportJobComponent;
  let fixture: ComponentFixture<ImportJobComponent>;
  let injector: TestBed;
  let apiErrorService: ApiErrorService;
  let toasterService: ToasterService;
  let appConstants: AppConstants;
  let fService: GlobalFilterService;
  let jobHeaderService: JobHeaderService;
  let titleService: Title;
  let jobService: JobsServicesService;
  const originReset = TestBed.resetTestingModule;
  const Testroutes: Routes = [
    {
      path: '**',
      component: ImportJobComponent,
    }];


  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, HttpClientTestingModule, RouterTestingModule.withRoutes(Testroutes),
        UploadModule],
      declarations: [ImportJobComponent],
      providers: [
        { provide: JobsServicesService, useClass: JobListServiceMock },
        { provide: TraneSalesBusinessDataService, useClass: TraneSalesBusinessDataServiceMock },
        { provide: GlobalFilterService, useClass: FilterServiceMock },
        { provide: LoaderService, useClass: LoaderServiceMock },
        { provide: ApiErrorService, useClass: ApiErrorServiceMock },
        { provide: ToasterService, useClass: ToasterMock },
        { provide: Router, useClass: RouterMock },
        {
          provide: ActivatedRoute, useValue: {
            snapshot: { params: { jobId: 12, drAddressId: 121 } },
            fragment: Observable.of('test'),
          },
        },
        {
          provide: AppConstants, useValue: { API_BASE_URL_JOB: '' },
        },
        {
          provide: ActivatedRoute, useValue: {
            snapshot: { params: { jobId: 12, drAddressId: 121 } },
            fragment: Observable.of('test'),
          },
        },
        Title,
        AppConstants,
        JobHeaderService,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
    injector = getTestBed();
    fixture = TestBed.createComponent(ImportJobComponent);
    component = fixture.componentInstance;
    toasterService = injector.inject(ToasterService);
    apiErrorService = injector.inject(ApiErrorService);
    titleService = injector.inject(Title);
    appConstants = injector.inject(AppConstants);
    fService = injector.inject(GlobalFilterService);
    jobHeaderService = injector.inject(JobHeaderService);
    jobService = injector.inject(JobsServicesService);
    component.importJobForm = new FormGroup({
      kendoUploadControl: new FormControl(),
      Files: new FormControl('', Validators.required),
      importLocation: new FormControl('', Validators.required),
      jobName: new FormControl('', Validators.required),
      salesOffice: new FormControl('', Validators.required),
      locationOffice: new FormControl('', Validators.required),
      commissionCode: new FormControl('', Validators.required),
      jobContact: new FormControl('', Validators.required),
      currency: new FormControl('', Validators.required),
      status: new FormControl(),
      bidDate: new FormControl(new Date()),
    });
    fixture.detectChanges();
  }));


  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should set the officeSelectorName and document title on calling ngOnInit`, () => {
    spyOn(titleService, 'setTitle');
    const spyOfficeSelectorList = spyOn(fService, 'getOfficeSelectorList').and.returnValue(Observable.of([{
      salesOfficeName: 'Billings',
      drAddressId: 121,
      country: 'USA',
      crmIntegrationInd: 'Y',
    }]));
    component.ngOnInit();
    expect(component.officeSelectorName).toBe('Billings');
    expect(spyOfficeSelectorList).toHaveBeenCalled();
    expect(titleService.setTitle).toHaveBeenCalledWith('Import Job');
  });

  it('should throw error message when click on upload button from errorEventHandler', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const spyApiError = spyOn(apiErrorService, 'show');
    const event = { response: { message: '404 error' } };
    component.errorEventHandler(event);
    expect(spyApiError).toHaveBeenCalledWith(event.response.message);
    expect(spyToasterService).toHaveBeenCalledWith('error', appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_ERROR_MESSAGE);
  });

  it('should throw success toaster message when click on upload button from successEventHandler', () => {
    // if file successfully uploaded and return response status 200 we show success toaster message
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const event = { response: { status: 200 } };
    component.successEventHandler(event);
    expect(spyToasterService).toHaveBeenCalledWith('success', appConstants.JOB_DETAILS_DOCUMENTS_UPLOAD_SUCCESS_MESSAGE);
    // check else condition in successEventHandler
    const event1 = { response: { status: 204 } };
    component.successEventHandler(event1);
    expect(event1.response.status).toBe(204);
  });

  it('should show toaster message when dropped multiple files on onSelectEvent', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const event = {
      prevented: false, files: [{
        extension: '.pdf', name: 'index.pdf',
        rawFile: File, size: 1175, uid: 'fd81da66-7142-4f56-bf3d-02a918b5bd30',
      }, {
        extension: '.doc', name: 'test2.doc',
        rawFile: File, size: 1179, uid: 'f7efc3b9-9ae1-4e6c-845b-3e3b2aa4bb17',
      }], preventDefault: () => false,
    };
    component.onSelectEvent(event);
    expect(spyToasterService).toHaveBeenCalledWith('warning', appConstants.JOB_DETAILS_DOCUMENTS_MULTIPLE_FILE_UPLOAD_MESSAGE);
  });

  it('should show toaster message when select other than .json on onSelectEvent', () => {
    const spyToasterService = spyOn(toasterService, 'setToaster').and.callThrough();
    const event = {
      prevented: false, files: [{
        extension: '.pdf', name: 'index1.pdf',
        rawFile: File, size: 1185, uid: 'fd81da66-7142-4f56-bf3d-02a918b5bd67',
      }], preventDefault: () => false,
    };
    component.onSelectEvent(event);
    expect(spyToasterService).toHaveBeenCalledWith('warning', appConstants.IMPORT_JOB_DOCUMENTS_FORBIDDEN_MESSAGE);
  });

  it('should set focus on jobname field on onSelectEvent', () => {
    jobHeaderService.setImportJobOpenStatus(true);
    const spyFocus = spyOn(component.importJobName.nativeElement, 'focus').and.callThrough();
    const event = {
      prevented: false, files: [{
        extension: '.json', name: 'example.json',
        rawFile: File, size: 1195,
      }],
    };
    component.onSelectEvent(event);
    expect(spyFocus).toHaveBeenCalled();
    expect(jobHeaderService.getImportJobOpenStatus()).toBe(true);
    expect(component.importJobForm.controls['jobName'].value).toBe('example');
  });

  it('should set assign name to  jobname field on onSelectEvent', () => {
    const event = {
      prevented: false, files: [{
        extension: '.json', name: '1234_example.json',
        rawFile: File, size: 1195,
      }],
    };
    component.onSelectEvent(event);
    expect(component.importJobForm.controls['jobName'].value).toBe('1234_example');
  });

  it('should extract and assign name(when it has spaces) to  jobname field on onSelectEvent', () => {
    const event1 = {
      prevented: false, files: [{
        extension: '.json', name: 'i have space in_my filename.json',
        rawFile: File, size: 1195,
      }],
    };
    component.onSelectEvent(event1);
    expect(component.importJobForm.controls['jobName'].value).toBe('i have space in_my filename');
  });

  it('should extract and assign name(when it has .) to  jobname field on onSelectEvent', () => {
    const event2 = {
      prevented: false, files: [{
        extension: '.json', name: '1234_im.testing_for.in_file.name.json',
        rawFile: File, size: 2000,
      }],
    };
    component.onSelectEvent(event2);
    expect(component.importJobForm.controls['jobName'].value).toBe('1234_im.testing_for.in_file.name');
  });


  it('should call toaster service when file is null onSelectEvent', () => {
    const spy = spyOn(toasterService, 'setToaster');
    component.ngOnInit();
    component.onSubmit();
    expect(spy).toHaveBeenCalledWith('warning', 'Please select a file to import');
  });

  it('should call toaster service when importJobForm is valid on calling onSelectEvent', () => {
    const spy = spyOn(toasterService, 'setToaster').and.callThrough();
    component.ngOnInit();
    component.importJobForm.patchValue({
      Files: 'tee',
      destinationDrAddressId: '78',
      jobName: 'test',
      salesOfficeId: '925',
      locationOfficeId: '78',
      commissionCode: 'F31',
      jobContact: 'Berry, Zach',
    });
    component.onSubmit();
    const toasterMessage = 'Your import request has been accepted. You will receive a notification shortly on the request status';
    expect(spy).toHaveBeenCalledWith('success', toasterMessage);
  });

  it('should  call importjob service when importJobForm is valid on calling onSelectEvent', () => {
    const spy = spyOn(jobService, 'importJob').and.callThrough();
    component.ngOnInit();
    component.importJobForm.patchValue({
      Files: 'tee',
      destinationDrAddressId: 'hh',
      jobName: 'test',
      salesOfficeId: 'test',
      locationOfficeId: 'test',
      commissionCode: 'test',
      jobContact: 'test',
    });
    component.onSubmit();
    expect(spy).toHaveBeenCalled();
  });

  it('should  not call importjob service when importJobForm is invalid on calling onSelectEvent', () => {
    const spy = spyOn(jobService, 'importJob');
    component.ngOnInit();
    component.importJobForm.patchValue({
      Files: 'tee',
      destinationDrAddressId: 'hh',
      jobName: null,
      salesOfficeId: 'test',
      locationOfficeId: 'test',
      commissionCode: 'test',
      jobContact: 'test',
    });
    component.onSubmit();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should call form reset on calling on onCancel', () => {
    component.ngOnInit();
    const spy = spyOn(component.importJobForm, 'reset');
    component.onCancel();
    expect(spy).toHaveBeenCalled();
  });

  it('should set false to importJobPageOpenStatus flag in setImportJobOpenStatus service method on ngOnDestroy', () => {
    jobHeaderService.setImportJobOpenStatus(false);
    component.ngOnDestroy();
    expect(jobHeaderService.getImportJobOpenStatus()).toBe(false);
  });

  it('should set false to importJobPageOpenStatus flag in setImportJobOpenStatus service method on removeEventHandler', () => {
    jobHeaderService.setImportJobOpenStatus(false);
    component.importJobForm.controls['jobName'].setValue('test');
    const event = {};
    component.removeEventHandler(event);
    expect(jobHeaderService.getImportJobOpenStatus()).toBe(false);
    expect(component.importJobForm.controls['jobName'].value).toBe('');
    expect(component.importJobForm.controls['Files'].value).toBe(null);
  });

  it('should return true when the control is invalid and touched on calling shouldShowErrors', () => {
    component.ngOnInit();
    component.importJobForm.controls['salesOfficeId'].setValue('');
    component.importJobForm.controls['salesOfficeId'].markAsTouched();
    expect(component.shouldShowErrors('salesOfficeId')).toBe(true);
  });

  it('should check job name empty on emptySpaceLengthCheck ', () => {
    const event = { target: { value: ' ' } };
    component.emptySpaceLengthCheck(event);
    expect(component.importJobForm.controls['jobName'].value).toBeNull();

    const eventWithValue = { target: { value: 'Test' } };
    component.importJobForm = new FormGroup({
      jobName: new FormControl('Test'),
    });
    component.emptySpaceLengthCheck(eventWithValue);
    expect(component.importJobForm.controls['jobName'].value).toBe('Test');
  });
});
