import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { InputsModule } from '@progress/kendo-angular-inputs';

import { configureTestSuite } from 'ng-bullet';
import { of, throwError } from 'rxjs';

import { PriceComponent } from './price.component';

import { AppConstants } from '../../../shared/constants/constants';
import { JobHeaderService } from '../../../shared/services/job-header.service';
import { JobLockService } from '@tsmt/shared-core-salesweb';


// tslint:disable-next-line:no-big-function
describe('PriceComponent', () => {
  let component: PriceComponent;
  let fixture: ComponentFixture<PriceComponent>;
  let injector: TestBed;
  let jobHeaderService: JobHeaderService;
  let jobLockService: JobLockService;

  const originReset = TestBed.resetTestingModule;
  const TestRoutes: Routes = [
    {
      path: '**',
      component: PriceComponent,
    }];
  const testJobId = 1234;
  const testDrAddressId = 122;
  const testUserId = 'xxabc';

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [
        PriceComponent,
      ],
      imports: [
        RouterTestingModule.withRoutes(TestRoutes),
        HttpClientTestingModule,
        InputsModule,
      ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              params: { jobId: testJobId, drAddressId: testDrAddressId },
              // temporary for libary build-out
              queryParamMap: {
                get: () => 'false',
              },
            },
          },
        },
        JobHeaderService,
        JobLockService,
        AppConstants,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
    injector = getTestBed();
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(PriceComponent);
    fixture.detectChanges();

    component = fixture.componentInstance;
    component.drAddressId = 122;
    jobHeaderService = injector.inject(JobHeaderService);
    jobLockService = injector.inject(JobLockService);
    jobHeaderService.setUserId(testUserId);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create Component', () => {
    expect(component).toBeTruthy();
  });

  it('should call getlockinfo and identify as locked on calling ngOnInit', () => {
    const spyUserId = spyOn(jobHeaderService, 'getUserId').and.returnValue(testUserId);
    const spyLock = spyOn(jobLockService, 'getLockInfo').and.returnValue(of({ jobLockUserId: testUserId }));

    component.ngOnInit();

    expect(spyLock).toHaveBeenCalled();
    expect(spyUserId).toHaveBeenCalled();
    expect(component.isJobLocked).toEqual(true);
  });

  it('should not set as locked, when not locked', () => {
    spyOn(jobHeaderService, 'getUserId').and.returnValue('');
    spyOn(jobLockService, 'getLockInfo').and.returnValue(of({ jobLockUserId: testUserId }));

    component.ngOnInit();

    expect(component.isJobLocked).toEqual(false);
  });

  it('should set userId on Init', () => {
    spyOn(jobHeaderService, 'getUserId').and.returnValue('appa');

    component.ngOnInit();

    expect(component.userId).toEqual('appa');
  });

  it('should set isJobExited to true and return true on calling handleExitJobAttempt', () => {
    component.isJobExited = false;
    const handleExit = component.handleExitJobAttempt();
    expect(handleExit).toBe(true);
    expect(component.isJobExited).toBe(true);
  });

});
