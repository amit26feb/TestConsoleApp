import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppConstants } from '../../../shared/constants/constants';
import { JobHeaderService } from '../../../shared/services/job-header.service';
import { JobLockService } from '@tsmt/shared-core-salesweb';

@Component({
  selector: 'app-price',
  templateUrl: './price.component.html',
  styleUrls: ['./price.component.scss'],
})

export class PriceComponent implements OnInit {
  public drAddressId: number;
  public jobId: number;
  public userId: string;

  public isJobLocked: boolean;

  public isJobExited = false;

  constructor(
    public appConstants: AppConstants,
    private jobHeaderService: JobHeaderService,
    private route: ActivatedRoute,
    private jobLockService: JobLockService,
  ) { }

  ngOnInit() {
    this.jobId = +this.route.snapshot.params['jobId'];
    this.drAddressId = +this.route.snapshot.params['drAddressId'];

    this.userId = this.jobHeaderService.getUserId();

    this.jobHeaderService.setJob(this.jobId, this.drAddressId);

    this.jobLockService.getLockInfo().subscribe((lockInfo) => {
      this.isJobLocked = this.userId === lockInfo.jobLockUserId;
    });
  }

  // function which will be called by parent compnent(joblist master component) when exit job is clicked.
  handleExitJobAttempt(): boolean {
    this.isJobExited = true;
    return true;
  }

}
