import { IJobLockModel } from './models/job-lock-model';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { JobDetailsEditComponent } from '@tsmt/salesweb-jobsdetailsmodule';
import { JobLockService as SharedJobLockService } from '@tsmt/shared-core-salesweb';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { AppConstants } from './../../shared/constants/constants';
import { ApiErrorService } from './../../shared/services/apierror.service';
import { GlobalFilterService } from './../../shared/services/global-filter.service';
import { JobHeaderService } from './../../shared/services/job-header.service';
import { JobListServiceMock } from './../../shared/test-mocks/jobService-mock';
import { RouterMock } from './../../shared/test-mocks/routerMock';
import { CoordinateComponent } from './coordinate/coordinate.component';
import { JobsListMasterComponent } from './jobs-list-master.component';
import { ExitJobService } from './services/exit-job.service';
import { JobLockService } from './services/job-lock.service';
import { JobsServicesService } from './services/jobs-services.service';
import { JobLockService as LockService } from '@tsmt/shared-acquisition-dataservices';

const spyLockService = jasmine.createSpyObj('LockService', ['jobLockedUserDetails']);

const testBedConfig = {
  imports: [ReactiveFormsModule, GridModule, TranslateModule.forRoot(),
    BrowserAnimationsModule, DropDownsModule, DatePickerModule],
  declarations: [JobsListMasterComponent, CoordinateComponent],
  providers: [
    {
      provide: ActivatedRoute, useValue: {
        children: [{
          snapshot: { params: { jobId: 1234, drAddressId: 2345 } },
        }],
        snapshot: {
          data: { userInfo: { samAccountName: 'ccfbsb', given_name: 'testName' } },
        },
      },
    },
    {
      provide: JobsServicesService, useClass: JobListServiceMock,
    }, {
      provide: Router, useClass: RouterMock,
    }, HttpClient, HttpHandler, AppConstants, GlobalFilterService, JobHeaderService, FormBuilder,
    ApiErrorService, ExitJobService, JobLockService, {
      provide: LockService, useValue: spyLockService,
    },
  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
};

describe('JobsListMasterComponent', () => {
  let component: JobsListMasterComponent;
  let fixture: ComponentFixture<JobsListMasterComponent>;
  let injector: TestBed;
  let route: ActivatedRoute;
  let headerService: JobHeaderService;
  let exitJob: ExitJobService;
  let lockService: JobLockService;
  let apiError: ApiErrorService;
  let jobService: JobsServicesService;
  let formBuilder: FormBuilder;
  let sharedJobLockService: SharedJobLockService;

  const originReset = TestBed.resetTestingModule;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, GridModule, TranslateModule.forRoot(),
        BrowserAnimationsModule, DropDownsModule, DatePickerModule],
      declarations: [JobsListMasterComponent],
      providers: [
        {
          provide: ActivatedRoute, useValue: {
            children: [{
              snapshot: { params: { jobId: 1234, drAddressId: 2345 } },
            }],
            snapshot: {
              data: { userInfo: { samAccountName: 'ccfbsb', given_name: 'testName' } },
            },
          },
        },
        {
          provide: JobsServicesService, useClass: JobListServiceMock,
        },
        {
          provide: LockService, useValue: spyLockService,
        },
        {
          provide: Router, useClass: RouterMock,
        }, HttpClient, HttpHandler, AppConstants, GlobalFilterService, JobHeaderService, FormBuilder,
        ApiErrorService, ExitJobService, JobLockService],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
  });

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(JobsListMasterComponent);
    component = fixture.componentInstance;
    route = injector.inject(ActivatedRoute);
    exitJob = injector.inject(ExitJobService);
    lockService = injector.inject(JobLockService);
    headerService = injector.inject(JobHeaderService);
    apiError = injector.inject(ApiErrorService);
    jobService = injector.inject(JobsServicesService);
    formBuilder = injector.inject(FormBuilder);
    sharedJobLockService = injector.inject(SharedJobLockService);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should call the fetchJobHeaderDetails on ngOninit', () => {
    expect(headerService.getUserId()).toBe('ccfbsb');
    const spy = spyOn(component, 'fetchJobHeaderDetails');
    component.ngOnInit();
    expect(component.pageHeader).toEqual('Jobs List');
    expect(spy).toHaveBeenCalled();
  });

  it('should call CloseAndExitJob on calling handleExitJobAttempt', () => {
    const spy = spyOn(exitJob, 'CloseAndExitJob');
    component.handleExitJobAttempt();
    expect(spy).toHaveBeenCalled();
    expect(component.showLoader).toBe(true);
  });

  it('should not set showLoader to false when jobExited is false on calling onActivate', () => {
    component.jobExited = false;
    component.showLoader = true;
    spyOn(component, 'fetchJobHeaderDetails');
    component.onActivate({});
    expect(component.showLoader).toBe(true);
  });

  it('should not set initialLockInfo when api returns null on calling fetchJobHeaderDetails', () => {
    spyOn(jobService, 'fetchJobDetails').and.returnValue(Observable.of(null));
    component.fetchJobHeaderDetails();
    expect(component.initialLockInfo).toBe(null);
  });

  it('should call updateLockInfoAndTitle on calling fetchJobHeaderDetails', () => {
    spyOn(component, 'updateLockInfoAndTitle');
    component.fetchJobHeaderDetails();
    expect(component.updateLockInfoAndTitle).toHaveBeenCalled();
  });

  it(`should not call CloseAndExitJob on calling handleExitJobAttempt when currentRouteCompRef
  is instance of JobDetailsEditComponent`, () => {
    component.currentRouteCompRef = new JobDetailsEditComponent(route, null, null, formBuilder, null, null, null,
      null, null, null, null, null, null, null, null, null, null, null, null, null);
    const spy = spyOn(exitJob, 'CloseAndExitJob');
    component.handleExitJobAttempt();
    expect(spy).not.toHaveBeenCalled();
    expect(component.showLoader).toBe(true);
  });

  it(`should not call CloseAndExitJob on calling handleExitJobAttempt when currentRouteCompRef
  is instance of CoordinateComponent`, () => {
    component.currentRouteCompRef = new CoordinateComponent(null, null, null, null, null, null, null, null, null, null, null);
    const spy = spyOn(exitJob, 'CloseAndExitJob');
    component.handleExitJobAttempt();
    expect(spy).not.toHaveBeenCalled();
    expect(component.showLoader).toBe(true);
  });

  it('should emit setLockInfo event on calling handleJobLockChange', () => {
    const spy = spyOn(lockService, 'setLockInfo');
    component.handleJobLockChange(false, 'ccfbcb', 'TestCase', 'Developer');
    expect(component.jobLockUserId).toBe('ccfbcb');
    expect(spy).toHaveBeenCalledWith({
      jobLockUserId: 'ccfbcb', readOnly: false,
      userId: 'ccfbcb', nameFirst: 'TestCase', nameLast: 'Developer',
    });
  });

  it('should set showLoader to false on calling onActivate', () => {
    component.jobExited = true;
    component.onActivate({});
    expect(component.showLoader).toBe(false);
  });

  it('should call the hide method in apiErrorService on calling onDeActivate', () => {
    const spy = spyOn(apiError, 'hide');
    component.onDeActivate({});
    expect(spy).toHaveBeenCalled();
  });

  it('should assign the initialLockInfo and jobLockUserId on calling updateLockInfoAndTitle', () => {
    const spySetLockInfo = spyOn(SharedJobLockService.prototype, 'setLockInfo');
    spyLockService.jobLockedUserDetails.and
      .returnValue(Observable.of({ userId: 'xxabc', firstName: 'first', lastName: 'last' }));
    component.jobId = 123;
    component.drAddressId = 122;
    component.updateLockInfoAndTitle();
    expect(component.initialLockInfo).toEqual({ userId: 'xxabc', nameFirst: 'first', nameLast: 'last' });
    expect(spySetLockInfo).toHaveBeenCalledWith({
      jobLockUserId: 'xxabc', readOnly: false,
      userId: 'xxabc', nameFirst: 'first', nameLast: 'last'
    });
  });

  it('should call the ApiErrorService to show error message when service returns error', () => {
    const spyError = spyOn(apiError, 'show');
    spyOn(jobService, 'fetchJobDetails').and.returnValue(Observable.throwError({ error: { Message: 'Service Error' } }));
    component.fetchJobHeaderDetails();
    expect(spyError).toHaveBeenCalledWith('Service Error');
  });

  it(`should set the showCoordinateInfo to true when the CoordinateComponent is loaded into router outlet`, () => {
    const coordinateComponent = new CoordinateComponent(null, null, null, null, null, null, null, null, null, null, null);
    component.onActivate(coordinateComponent);
    expect(component.showCoordinateInfo).toBe(true);
  });

  it(`should set the showCoordinateInfo to false when the components other than
      CoordinateComponent is loaded into router outlet`, () => {
    const testComponent = {};
    component.onActivate(testComponent);
    expect(component.showCoordinateInfo).toBe(false);
    expect(component.showOfficeSelection).toBe(true);
  });

  it(`should call setLockInfo  on SharedJobLockService  from shared-salesweb  on calling handleJobLockChange`, () => {
    const spySharedSaleWeb = spyOn(sharedJobLockService, 'setLockInfo');
    component.handleJobLockChange(false, 'ccfbcb', 'TestCase', 'Developer');
    expect(component.jobLockUserId).toBe('ccfbcb');
    expect(spySharedSaleWeb).toHaveBeenCalledWith({
      jobLockUserId: 'ccfbcb', readOnly: false,
      userId: 'ccfbcb', nameFirst: 'TestCase', nameLast: 'Developer',
    });
  });

  it(`should return commonTitle on calling getCommonTitle `, () => {
    component.jobId = 12;
    component.drAddressId = 123;
    component.jobName = 'title';
    component.initialLockInfo = {
      userId: 'ccfbsb',
    } as IJobLockModel;
    spyOn(JobHeaderService.prototype, 'getUserId').and.returnValue('ccfbsb');
    const commonTitle = {
      jobId: component.jobId,
      drAddressId: component.drAddressId,
      nameToDisplay: component.jobName,
      currentUserId: 'ccfbsb',
      lockedUserId: component.initialLockInfo.userId,
      item: 'Job',
      routeName: 'jobs-list',
      exitComponentName: 'exit',
      isOfficeSelectorLabel: true,
      showExitButton: true,
    };
    expect(component.getCommonTitle()).toEqual(commonTitle);
  });
});


describe('JobsListMasterComponent', () => {
  const originReset = TestBed.resetTestingModule;
  let fixture: ComponentFixture<JobsListMasterComponent>;
  let headerService: JobHeaderService;
  testBedConfig.providers[0]['useValue']['snapshot']['data']['userInfo'] = null;


  configureTestSuite(() => {
    TestBed.configureTestingModule(testBedConfig);
  });

  it(`should not set the the userId to jobHeaderService when activatedRoute doesnt have the userinfo when
  component instance is created`, () => {
    headerService = getTestBed().inject(JobHeaderService);
    spyOn(headerService, 'setUserId');
    fixture = TestBed.createComponent(JobsListMasterComponent);
    expect(headerService.setUserId).not.toHaveBeenCalled();
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

});

describe('JobsListMasterComponent', () => {
  const originReset = TestBed.resetTestingModule;
  let fixture: ComponentFixture<JobsListMasterComponent>;
  let component: JobsListMasterComponent;
  testBedConfig.providers[0]['useValue']['children'][0]['snapshot']['params']['jobId'] = '1234aa';
  testBedConfig.providers[0]['useValue']['children'][0]['snapshot']['params']['jobId'] = 'aaa';


  configureTestSuite(() => {
    TestBed.configureTestingModule(testBedConfig);
  });

  it(`should set the showLoader to false on calling ngOninit`, () => {
    fixture = TestBed.createComponent(JobsListMasterComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    expect(component.showLoader).toBe(false);
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });


});
