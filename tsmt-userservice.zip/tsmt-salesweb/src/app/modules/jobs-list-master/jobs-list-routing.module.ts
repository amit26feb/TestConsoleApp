import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OktaAuthGuard } from '@okta/okta-angular';
// components
import { DocumentPackageInfoComponent, DocumentPackagesUploadComponent, PackagesListComponent } from '@tsmt/salesweb-docgenmodule';
import { JobsListComponent } from '@tsmt/salesweb-jobsmodule';
import { TSMTMenuGuard } from '../../auth/menu-guard.service';
import { UserInfoResolver } from '../../user-info-resolver.service';
import { HomePageListComponent } from '../home-page/home-page-list/home-page-list.component';
import { CoordinateComponent } from './coordinate/coordinate.component';
import { CreateJobHomeComponent } from './create/create-job-home.component';
import { ExitJobMessageComponent } from './exit-job-message/exit-job-message.component';
import { ImportJobComponent } from './import-job/import-job.component';
import { JobsListMasterComponent } from './jobs-list-master.component';
import { PriceComponent } from './price/price.component';

const JobsListMasterRoutes: Routes = [
  {
    path: '',
    component: JobsListMasterComponent,
    children: [
      {
        path: '',
        component: JobsListComponent,
        pathMatch: 'full',
      },
      {
        path: ':drAddressId',
        component: JobsListComponent,
      },
      {
        path: ':jobId/:drAddressId/details',
        loadChildren: () => import('@tsmt/salesweb-jobsdetailsmodule').then((module) => module.SalesWebJobsDetailsModule),
        resolve: {
          userInfo: UserInfoResolver,
        },
        pathMatch: 'full',
        canActivate: [OktaAuthGuard, TSMTMenuGuard],
        data: { routeName: 'details', subMenuRoute: 'details' },
      },
      {
        path: ':jobId/:drAddressId/bids',
        loadChildren: () => import('@tsmt/salesweb-bidsmodule').then((module) => module.SalesWebBidsModule),
        resolve: {
          userInfo: UserInfoResolver,
        },
        pathMatch: 'full',
        canActivate: [OktaAuthGuard, TSMTMenuGuard],
        data: { routeName: 'bids' },
      },
      {
        path: ':jobId/:drAddressId/configure',
        loadChildren: () => import('@tsmt/salesweb-selectionmodule').then((module) => module.SalesWebSelectionModule),
        resolve: {
          userInfo: UserInfoResolver,
        },
        pathMatch: 'full',
        canActivate: [OktaAuthGuard, TSMTMenuGuard],
        data: { routeName: 'configure' },
      },
      {
        path: ':isLockedBySomeoneElse/exit',
        component: ExitJobMessageComponent,
        pathMatch: 'full',
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'exitjob' },
      },
      {
        path: ':jobId/:drAddressId/packagesList',
        component: PackagesListComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'packagelist', subMenuRoute: 'packagesList' },
      },
      {
        path: ':jobId/:drAddressId/docPackageInfo',
        component: DocumentPackageInfoComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'docpackage', subMenuRoute: 'packagesList' },
      },
      {
        path: ':jobId/:drAddressId/coordinate',
        component: CoordinateComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'coordinate' },
      },
      {
        path: ':jobId/:drAddressId/price-component',
        component: PriceComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'price' },
      },
      {
        path: ':jobId/:drAddressId/price',
        component: PriceComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'pricelib' },
      },
      {
        path: ':drAddressId/importjob',
        component: ImportJobComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'importjob' },
      },
      {
        path: ':drAddressId/uploaddocumentpackages',
        component: DocumentPackagesUploadComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'uploaddocumentpackages' },
      },
    ],
  },
  {
    path: '',
    component: JobsListMasterComponent,
    children: [
      {
        path: ':drAddressId/create',
        component: CreateJobHomeComponent,
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'create' },
      },
    ],
  },
  {
    path: ':drAddressId',
    component: HomePageListComponent,
    children: [
      {
        path: 'projects',
        loadChildren: () => import('../orders/orders.module').then((project) => project.OrdersModule),
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'projects' },
      },
      {
        path: ':jobId/projects',
        loadChildren: () => import('../orders/orders.module').then((project) => project.OrdersModule),
        canActivate: [TSMTMenuGuard],
        data: { routeName: 'projects' },
      },
    ],
  },
  {
    path: ':jobId/:drAddressId/Rebalancing',
    loadChildren: () => import('@tsmt/salesweb-rebalancing').then((module) => module.SaleswebRebalancingModule),
    canActivate: [TSMTMenuGuard],
    data: { routeName: 'Rebalancing' },
  },
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(JobsListMasterRoutes),
  ],
  exports: [RouterModule],
  declarations: [],
})
export class JobsListRoutingModule { }
