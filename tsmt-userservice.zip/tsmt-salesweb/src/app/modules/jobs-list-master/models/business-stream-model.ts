export interface IBusinessStream {
    businessStreamId: number;
    businessStreamName: string;
    businessStreamSequenceNumber: number;
}
