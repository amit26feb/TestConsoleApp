export interface IUserModel {
  userId: string;
  firstName: string;
  lastName: string;
}

// stores user preferences
// kind of a duplicate of a obj in shared core
export interface IGridState {
  gridPreferenceId: string;
  userId: string;
  applicationId: string;
  route: string;
  gridName: string;
  gridPreferenceName: string;
  gridPreferenceSetting: string;
  isPublic: boolean;
  isDefault: boolean;
}


// Active directory model
export interface IActiveDirectory {
  businessPhones: string[];
  displayName: string;
  givenName: string;
  jobTitle: string;
  mail: string;
  mobilePhone: string;
  officeLocation: string;
  surname: string;
  userPrincipalName: string;
  onPremisesSamAccountName: string;
}

export interface IFilterConditions {
  field: string;
  value: string;
}

export interface IUserDetails {
  firstName: string;
  lastName: string;
  phoneNumber: string;
  salesOfficeName: string;
  emailAddress: string;
}
