export interface IClarificationsExceptions {
    productFamilyId: number;
    clarificationDetails: string[];
}


export interface IClarificatonItem {
    Item: string;
}
