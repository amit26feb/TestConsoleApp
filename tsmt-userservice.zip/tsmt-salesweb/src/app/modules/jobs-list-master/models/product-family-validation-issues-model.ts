export class ProductFamilyValidationIssuesModel  {
    constructor(
            public productFamilyCode: string,
            public tag: string,
            public qty: number,
            public hasUnpopulatedSubmittalRequiredFields: boolean,
            public isProductObsolete: boolean,
            public hasAnObsoleteSelectedOption: boolean) {}
    }
