export interface SharePointDocumentDetail {
    fileLocation: string;
    uniqueId: string;
}
