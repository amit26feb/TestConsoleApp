export interface IDocumentPreferredView {
    drAddressId: number;
    jobId: number;
    preferredView: string;
}
