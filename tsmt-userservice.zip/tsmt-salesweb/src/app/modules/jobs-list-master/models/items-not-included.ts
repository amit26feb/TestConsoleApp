export interface IItemsNotIncluded {
    productFamilyId: number;
    itemsNotIncludedDetails: string[];
}
