export interface IWorkPackage {
    workPackageId: number;
    workPackageName: string;
    workPackageVersion: number;
}
