import { JobRoleAsnView } from '@tsmt/salesweb-jobsdetailsmodule/lib/models/job-details-edit.model';
import { ISelectOption } from '@tsmt/shared-core/lib/models/select-item';

export interface IClassification {
    jobClassId: number;
    description: string;
    codes: IClassificationsCode[];
}

export interface IClassificationsCode {
    jobCodeId: number;
    description: string;
    jobCode?: string;
}

export interface IEarthwiseSystem {
    systemTypeId: number;
    description: string;
    toolTip: string;
}

export interface IProgram {
    programCode: string;
    programDescription: string;
}

export interface IRevenueStream {
    revenueStreamFieldValue: string;
    description: string;
}

export interface ISite {
    siteName: string;
    streetAddress1: string;
    streetAddress3: string;
    streetAddress4: string;
    streetAddress2: string;
    address: string;
    phoneNumber: string;
    companyName: string;
    crmSiteId: string;
}

export interface IContact {
    contactId: number;
    lastName: string;
    firstName: string;
    accountNumber: string;
    companyName: string;
    salesOfficeName: string;
    phoneNumber: string;
    emailAddress: string;
    address: string;
    streetAddress1: string;
    streetAddress2: string;
    crmContactId?: string;
    isPrimary?: boolean;
    crmCompanyId: string;
    salesCustId: number;
    custAcctNbr: string;
}

export enum GridType {
    CONTACT = 'Contact',
    COMPANY = 'Company',
    SITE = 'Site',
}

export interface ISearchContactListModel {
    pageNumber: number;
    pageSize: number;
    totalItemCount: number;
    pageCount: number;
    contacts: IContact[];
}

export interface ISearchSiteListModel {
    pageNumber: number;
    pageSize: number;
    totalItemCount: number;
    pageCount: number;
    sites: ISite[];
}

export interface ICurrencyListModel {
    name: string;
    code: string;
}

export interface ISaveCrmModel {
    opportunityName: string;
    status: string;
    businessUnit: string;
    company: string;
    office: string;
    commCode: string;
    salesOfficeId: number;
    location: string;
    salesProcess: string;
    parentIndustryVerticalMarket: string;
    totalBooking: number;
    currency: string;
    overallConf: number;
    bookingDate: Date;
    revenueStream: string;
    totalControls: number;
    controlsConf: number;
    bidDate: Date;
    boDOnEquipment: string;
    boDOnControls: string;
    extensibleAttributes: IExtensibleAttributeModel;
    priorCode: ISystemModel[];
    programCode: IProgramModel[];
    site: ISaveCrmSiteModel[];
    contact: ISaveCrmContactModel[];
    jobContact: string;
    foe2CreatedOrdersInd: string;
    cplpafLocked: number;
    checkedIn: string;
    locationOfficeId: number;
    verticalMarketJobCodeId: number;
    classifications: ISelectOption[];
    jobRoleAsnViews: JobRoleAsnView[];
}

export interface ISaveCrmSiteModel {
    siteId: string;
    primaryFlag: string;
}

export interface ISaveCrmContactModel {
    contactId: string;
    primaryFlag: string;
}

export interface IAttributeModel {
    name: string;
    value: string;
}

export interface IExtensibleAttributeModel {
    attribute: IAttributeModel[];
}

export interface ISystemModel {
    system: string;
}

export interface IProgramModel {
    program: string;
}
