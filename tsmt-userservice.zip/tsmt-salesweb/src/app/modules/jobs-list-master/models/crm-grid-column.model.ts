export class CrmGridColumn {
   constructor(
      public field: string,
      public title: string,
      public filter = false) { }
}

export enum CompanyGridColumnEnum {
   companyName = 'Company Name',
   companyID = 'Company ID',
   address = 'Address',
   phone = 'Phone',
}

export enum ContactGridColumnEnum {
   lastName = 'Last Name',
   firstName = 'First Name',
   accountNumber = 'Account Number',
   companyName = 'Company Name',
   office = 'Office',
   phone = 'Phone',
   email = 'Email',
   address = 'Address',
}

export enum SiteGridColumnEnum {
   siteName = 'Site Name',
   companyName = 'Company Name',
   address = 'Address',
   phone = 'Phone',
}
