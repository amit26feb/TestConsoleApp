import { ProductFamilyValidationIssuesModel } from './product-family-validation-issues-model';

export class DocumentValidationModel {
constructor(
        public hasAnySelectionsOnTheSelectedBid: boolean,
        public hasAnyValidSelectionsOnTheSelectedBid: boolean,
        public hasAnyVariationsOnTheSelectedBid: boolean,
        public productFamilyValidationIssues: ProductFamilyValidationIssuesModel[]) {}
}
