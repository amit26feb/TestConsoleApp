export class ProductAttachment {
    mechSpec: boolean;
    dimensionalDrawings: boolean;
    fanCurves: boolean;
    wgtClrAndRigDgmlDrawings: boolean;
    accessory: boolean;
    fieldWiring: boolean;
    controlsWiringDiagrams: boolean;
}
