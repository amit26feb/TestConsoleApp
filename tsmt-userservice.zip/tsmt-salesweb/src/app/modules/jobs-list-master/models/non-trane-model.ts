export interface INonTraneModel {
    variationId: number;
    variationType: string;
    jobId: number;
    prodCode: number;
    description: string;
    providerName: string;
    equipmentName: string;
    costCategory: string;
    qty: number;
    cost: number;
    markup: number;
    sellingPrice: number;
    proposalCode: number;
    salesOrderId: number;
    pendingOrderInd: string;
    totalCount: number;
    vendorName: string;
    vendorId: number;
    productId: number;
    vendorLeadTimeDays: number;
    status: string;
    tagDetails: ITagData[];
    strategicProvider: string;
}

export interface ITagData {
    tag: string;
    tagSequenceNbr: number;
    referenceUnitId: number;
}

export enum variationTypeEnum {
    M = 'VMAT',
    L = 'VLBR',
    F = 'VFAC',
}

export enum payloadMapper {
    variationId = 'variation_id',
    variationType = 'variation_type',
    prodCode = 'prod_code',
    description = 'short_desc',
    providerName = 'provider_name',
    equipmentName = 'equipment_name',
    qty = 'matl_qty',
    cost = 'matl_extended_cost',
    markup = 'matl_markup_multiplier',
    sellingPrice = 'net_price',
    proposalCode = 'proposal_code',
    salesOrderId = 'sales_order_id',
    pendingOrderInd = 'pending_order_id',
    totalCount = 'total_count',
    vendorName = 'vendor_name',
    vendorId = 'vendor_id',
    productId = 'product_id',
    vendorLeadTimeDays = 'vendor_lead_time_days',
    status = 'status',
    tagDetails = '',
    strategicProvider = 'strategic_provider',
    costCategory = 'cost_category',
}

export interface IEditNonTranePatch {
    op: string;
    path: string;
    value?: ITagPatch[] | IVariationPatch[];
}

export interface ITagPatch {
    tag_sequence_nbr?: number;
    tag?: string;
    variation_id?: number;
}

export interface IVariationPatch {
    variation_id: number;
    net_price: number;
    prod_code: string;
    short_desc: string;
    provider_name: string;
    equipment_name: string;
    matl_extended_cost: number;
    matl_qty: number;
    matl_markup_multiplier: number;
    proposal_code: string;
    sales_ord_id: number;
    vendor_name: string;
    vendor_id: number;
    product_id: number;
    vendor_lead_time_days: number;
    strategic_provider: string;
    cost_category: string;
}
export interface INonTraneListModel {
    pageNumber: number;
    pageSize: number;
    totalItemCount: number;
    pageCount: number;
    nonTraneItems: INonTraneModel[];
}
