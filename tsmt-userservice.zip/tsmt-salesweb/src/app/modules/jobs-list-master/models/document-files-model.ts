export interface IDocumentDetails {
    documentCount: number;
    documentKey: string;
    documentName: string;
    documentSource: string;
    documentUpdateStatus: string;
    documentVersion: string;
    drAddressId: number;
    fileTypeName: string;
    folderId: string;
    jobDocumentId: number;
    jobDocumentTypeId: string;
    jobId: number;
    notes: string;
    totalCount: number;
    uploadedBy: string;
    uploadedDate: string;
    filterUploadedDate?: number;
    uploadedUserId: string;
    documentPackageId: number;
    documentStorage: string;
    status: string;
    docTypeId: number;
}

export interface IDocumentDetailsList {
    documentList: IDocumentDetails[];
    pageCount: number;
    pageNumber: number;
    pageSize: number;
    totalItemCount: number;
}
