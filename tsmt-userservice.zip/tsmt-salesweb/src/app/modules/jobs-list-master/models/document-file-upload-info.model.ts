export interface DocumentFileUploadInfo {
    folderSource: string;
    docTypeId: number;
    parentFolderName: string;
    folderTypeId: number;
    parentFolderId: number;
}
