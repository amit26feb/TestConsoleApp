export interface IDocumentPackageProdFamilyErrors {
    prodFamilyId: number;
    prodFamilyCode: string;
    errors: string[];
}
