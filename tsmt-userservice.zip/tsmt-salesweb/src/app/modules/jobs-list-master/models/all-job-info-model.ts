export interface IAllJobInfoModel {
    selectionList: ISelection[];
    referenceUnitList: IReferenceUnit[];
    bidAlternateList: IBidAlternate[];
}

export interface IBidAlternate {
    currentBidInd: string;
    bidAlternateXrefList: IBidAlternateXref[];
}

export interface IBidAlternateXref {
    selectionId: number;
}

export interface IReferenceUnit {
    referenceUnitId: number;
    tagSequenceNbr: number;
    tag: string;
}

export interface ISelection {
    selectionId: number;
    salesmanDescr: string;
    unitQty: number;
    prodFamilyId: number;
    sequenceNbr: number;
    selectedModuleList: ISelectedModule[];
    selectionXrefList: ISelectionXRef[];
}

export interface ISelectionXRef {
    referenceUnitId: number;
}

export interface ISelectedModule {
    prodModuleId: number;
    moduleSequence: number;
    selectedItemList: ISelectedItem[];
}

export interface ISelectedItem {
    vpcId: number;
    siId: number;
}

