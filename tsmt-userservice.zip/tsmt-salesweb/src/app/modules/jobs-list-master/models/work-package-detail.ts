export interface IWorkPackageDetail {
    workPackageName: string;
    salesCustomerDetail: ISalesCustomerDetail;
}

export interface ISalesCustomerDetail {
    customerName: string;
}
