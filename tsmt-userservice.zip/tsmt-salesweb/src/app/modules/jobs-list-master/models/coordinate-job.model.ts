import { IJobNotesModel } from '../modal/job-details-edit.model';

export interface ICoordinateJob {
    jobCoordinationGeneralInfo: IJobCoordinationForm;
    jobNotes: IJobNotesModel;
    coordinationData: ICoordinationData;
    submissionNotes: ISubmissionNotes;
}
export interface ICoordinationData {
    submissionNotes: ISubmissionNotes;
    coordinationData: ICoordinationData;
}
export interface ICoordinationData {
    billOfMaterials: IBillOfMaterials;
    documents: IDocuments[];
}
export interface IDocuments {
    documentKey: string;
}
export interface IBillOfMaterials {
    bidAlternateId: number;
    productFamilyId: number;
    shipQuarter: number;
    shipYear: number;
    competitor: string;
    specifiedUser: string;
}
export interface ICoordinateBidData {
    bidDataForCoordination: IBid[];
}

export interface IJobCoordinationForm {
    requestedDate: string;
    quickTurnaroundIndicator: string;
    icsJobIndicator: string;
    jobContact: string;
    commissionCode: string;
    crmOpportunityId: string;
    pricingSpaNumber: number;
}

export interface ICommissionCode {
    name: string;
    commCode: string;
    commCodeDisplay: string;
    salesOfficeId: number;
}
export interface IJobContact {
    userId: string;
    userName: string;
}

export interface ISubmissionNotes {
    noteLine: any;
}

export interface IBid {
    bidAlternateId: number;
    bidName: string;
    isCurrentBid: boolean;
    isBidInCoordinationJob?: boolean;
    discountIndicator?: string;
    discountIndicatorClass?: string;
    isValid?: boolean;
    isSubmitted: boolean;
    isDisabled: boolean;
}

export interface IBidSelections {
    bidAlternateId: number;
    bidName: string;
    selections: ISelection[];
}

export interface ISelection {
    selectionIds: number[];
    selectionId: number;
    description: string;
    bidAlternateId: number;
    bidName: string;
    coordinationJobShipQuarter: number;
    coordinationJobShipYear: number;
    coordinationJobCompetitor: string;
    coordinationJobSpecifiedUser: string;
    priceControlId: number;
    prodFamilyId: number;
    isSelectionPriceComplete: boolean;
    oldShipYear: number;
    selectionErrors: string[];
    isValidShippingLeadTime?: boolean;
    isNewlyAdded?: boolean;
    bidNameAndId: string;
    selectionSource: string;
    doesSeparatelyBiddableSelectionsExist: boolean;
    displayShipQuarterError: boolean;
    displayShipYearError: boolean;
    displayPastTimeError: boolean;
}

export interface IDraftSelection {
    jobId: number;
    bidAlternateId: number;
    productFamilyId: number;
    shipQuarter: number;
    shipYear: number;
    competitor: string;
    specifiedUser: string;
    selectionIds: number[];
    description: string;
    selectionSource: string;
    doesSeparatelyBiddableSelectionsExist: boolean;
}

export interface ICoordinateRequest {
    submittedOn: string;
    coordinationStatus: string;
    pricingSPANumber: number;
    assignedTo: string;
    coordinator: string;
    bids: string[];
    coordinationJobData: any;
    coordinationId: number;
    drAddressId: number;
    jobId: number;
}

export interface ICoordinatedata {
    coordinatedJobGeneralInfo: ICoordinatedJobGeneralInfo;
    discountConfirmationDetails: IDiscountConfirmationDetails[];
}
export interface ICoordinatedJobGeneralInfo {
    assignedTo: string;
    coordinator: string;
    coordinationStatus: string;
    submittedOn: string;
}

export interface IDiscountConfirmationDetails {
    bidAlternateId: number;
    isDiscountConfirmed: boolean;
}

export interface ICoordinateDocument {
    documentKey: string;
    jobDocumentId: number;
    uploadedDate: Date;
    notes: string;
    documentName: string;
    uploadedUserId: string;
    documentUpdateStatus: string;
}
