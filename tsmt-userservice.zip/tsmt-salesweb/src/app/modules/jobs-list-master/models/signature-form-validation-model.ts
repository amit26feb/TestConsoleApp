import { SignatureForm } from './signature-form-model';

export interface SignatureFormValidationInfo {
    signatureFormValues: SignatureForm;
    validationFlag: boolean;
}
