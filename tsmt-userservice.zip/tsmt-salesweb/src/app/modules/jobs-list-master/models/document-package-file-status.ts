import { IDocumentPackageProdFamilyErrors } from './document-package-prod-family-errors';

export interface IDocumentPackageFileStatus {
    status: string;
    workStatus: string;
    generatedDate: string;
    percentComplete: number;
    productFamilyGenerationErrorDetails: IDocumentPackageProdFamilyErrors[];
}
