export interface DocumentModel {
    documentCount: number;
    documentKey: string;
    documentName: string;
    documentStorage: string;
    documentSource: string;
    documentUpdateStatus: string;
    documentVersion: string;
    drAddressId: number;
    jobDocumentId: number;
    jobId: number;
    notes: string;
    uploadedBy: string;
    uploadedDate: Date;
    uploadedUserId: string;
    documentPackageId: number;
}

export interface DocumentVersionHistoryModel {
    fileName: string;
    fileList: DocumentModel[];
}

export interface IDeleteDocumentModel {
    documentKey: string;
    documentName: string;
    documentVersion: string;
    jobDocumentTypeId: number;
    folderId: number;
    parentFolderId: number;
}
