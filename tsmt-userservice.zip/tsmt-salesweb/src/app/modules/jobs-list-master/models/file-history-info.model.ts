export interface FileHistoryInfo {
    documentKey: string;
    documentTypeId: number;
    documentStorage: string;
    status: string;
    documentName: string;
    folderId: number;
}
