export interface IJobLockModel {
    userId: string;
    nameFirst: string;
    nameLast: string;
}
