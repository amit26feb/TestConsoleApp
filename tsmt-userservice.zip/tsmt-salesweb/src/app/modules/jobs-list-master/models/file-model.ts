export interface IFileModel {
    file: Blob;
    name: string;
}
