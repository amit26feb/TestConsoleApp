export interface SignatureForm {
    selectSender: string;
    sender: string;
    title: string;
    cellPhoneNumber: string;
    faxNumber: string;
    serviceContactPhoneNumber: string;
    emailAddress: string;
    officeName: string;
    officePhoneNumber: string;
    addressLine1: string;
    addressLine2: string;
    zipCode: string;
    city: string;
    state: string;
    county: string;
    country: string;
    blockOption: string;
    selectCustomSender: string;
}
