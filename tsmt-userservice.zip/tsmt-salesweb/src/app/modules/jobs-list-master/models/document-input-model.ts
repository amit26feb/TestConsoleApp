export interface IDocumentInput {
    documentInputId: number;
    documentInputName: string;
}
