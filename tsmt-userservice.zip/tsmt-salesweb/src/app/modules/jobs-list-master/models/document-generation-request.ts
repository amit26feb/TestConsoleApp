
export interface IDocumentGenerationRequest {
    job: IJob;
    sender: ISender;
    callerTimeZone: string;
}

export interface ISender {
    name: string;
    address: string;
    phone: string;
    cell: string;
    fax: string;
    company: ICompany;
}

export interface ICompany {
    name: string;
    shortName: string;
}

export interface IJob {
    id: number;
    name: string;
    address: string;
    bidDate: string;
    products: IProductSelection[];
}

export interface IProductSelection {
    id: number;
    units: IUnit[];
}

export interface IUnit {
    tags: string[];
    quantity: number;
    salesDescription: string;
    modelNumber: string;
    modules: IModule[];
}

export interface IModule {
    moduleId: number;
    settings: ISetting[];
}

export interface ISetting {
    vpcId: number;
    selectedId: number;
}
