import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-create',
    template: `<app-non-crm-job *ngIf = "queryParam === 'NONCRM'"></app-non-crm-job>
    <app-crm-job *ngIf = "queryParam === 'CRM'"></app-crm-job>`,
})
export class CreateJobHomeComponent implements OnInit {
    public queryParam: string;
    constructor(private route: ActivatedRoute) { }
    ngOnInit() {
        this.route.queryParams.subscribe((params) => {
            this.queryParam = params['jobType'];
        });
    }
}
