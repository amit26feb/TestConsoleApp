import { PayloadModel } from '@tsmt/salesweb-jobsmodule/lib/models/job-summary-selection.model';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormArray, FormBuilder, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { GroupCheckboxViewComponent, GroupSelectViewComponent, ToasterService } from '@tsmt/shared-core';
import { RouterMock } from '@tsmt/shared-core-salesweb';
import { ApiErrorService } from '../../../../shared/services/apierror.service';
import { ICheckboxItem } from '@tsmt/shared-core/lib/models/checkbox-item';
import { Observable, of } from 'rxjs';
import { TraneSalesBusinessDataServiceMock } from '../../../../shared/test-mocks/tranesalesbusinessdata-mock';
import { ISearchCustomerListModel, ISearchCustomerModel } from '../../modal/job-details-edit.model';
import { SalesCustomerService } from '../../services/sales-customer.service';
import { JobHeaderService } from '../../../../shared/services/job-header.service';
import { SitesService } from '../../services/sites.service';
import { TraneSalesBusinessDataService } from '../../services/trane-sales-business-data.service';
import { GlobalFilterService } from '../../../../shared/services/global-filter.service';
import { AppConstants } from './../../../../shared/constants/constants';
import { GridType, IContact, ISearchContactListModel, ISearchSiteListModel, ISite, ISaveCrmModel } from './../../models/create-crm.model';
import { CrmJobComponent } from './crm-job.component';
import { CreateCrmService } from '../../services/create-crm.service';
import { GeneralComponent } from './general/general.component';
import { ApiErrorServiceMock } from '../../../../shared/test-mocks/apierrorservice-mock';
import { FilterServiceMock } from '../../../../shared/test-mocks/filterservice-mock';
import { PopupService } from '@progress/kendo-angular-popup';
import { NotificationService } from '@progress/kendo-angular-notification';
import { LoaderService } from '../../../../shared/services/loader.service';
import { LoaderServiceMock } from '../../../../shared/test-mocks/loaderService-mock';
import { ISelectOption } from '@tsmt/shared-core/lib/models/select-item';

describe('CrmJobComponent', () => {
  let component: CrmJobComponent;
  let fixture: ComponentFixture<CrmJobComponent>;
  let traneSalesBusinessDataService: TraneSalesBusinessDataService;
  let injector: TestBed;
  let apiErrorService: ApiErrorService;
  let salesCustomerService: SalesCustomerService;
  let sitesService: SitesService;
  let createCrmService: CreateCrmService;
  let toasterService: ToasterService;
  let jobHeaderService: JobHeaderService;
  let globalfilerService: GlobalFilterService;
  let loaderService: LoaderService;
  const testSearchCustomer: ISearchCustomerListModel = {
    pageNumber: 1,
    pageSize: 15,
    totalItemCount: 32,
    pageCount: 3,
    customerList: [{
      salesCustId: 70,
      firstName: 'JPK ',
      lastName: 'Associates',
      customerName: 'ALL BIDDERS',
      streetAddress1: 'No Where',
      streetAddress2: null,
      state: 'WI',
      zipCode: '54501',
      nonUsPostalCode: null,
      city: 'Lax',
      custAcctNbr: null,
      jobRoleTypeId: 2,
      commCode: 'M24',
      address: 'No Where  Lax WI  ',
      totalCount: 32,
      region: 'International',
      phoneNumber: '(303) 039-2929',
      faxNumber: '(438) 948-3904',
      contactPhoneNumber: '6087871000',
      contactFaxNumber: '4380',
      contactPhoneExtension: '2971',
      crmCompanyId: null,
    }],
  };
  let formBuilder: FormBuilder;
  let spyClassification;

  const emptySearchEvent = { searchText: '' };
  const searchEvent = { searchText: 'test' };
  const searchEventEmptyResult = { searchText: 'testtt' };
  const payload: PayloadModel = {
    skip: 0,
    take: 10,
    sort: null,
    filters: [{
      ColumnFilters: [{ field: 'name', operator: 'contains', value: 'def' }],
      logic: 'or'
    }]
  };
  const searchAndFilter = {
    searchText: 'abc', skip: 0, take: 10, payload
  };
  const testItems: ICheckboxItem[] = [{
    displayValue: 'General VRF System',
    checked: false,
    value: '1',
  },
  {
    displayValue: 'COVID Response',
    checked: false,
    value: '2',
  }];

  const sites: ISite[] = [{
    siteName: 'testSite',
    streetAddress1: 'test address1',
    streetAddress3: null,
    streetAddress4: 'test address3',
    streetAddress2: 'test address4',
    address: null,
    companyName: 'test company',
    phoneNumber: '123456',
    crmSiteId: '4655'
  }];

  const siteSearchResult = {
    pageCount: 1,
    pageSize: 15,
    pageNumber: 1,
    sites,
  } as ISearchSiteListModel;

  const contacts: IContact[] = [{
    contactId: 1,
    lastName: 'Harison',
    firstName: 'Peter',
    accountNumber: '',
    companyName: 'Peter Air Condisitoning & Sheet Metal',
    salesOfficeName: 'LEXINGTON-K',
    phoneNumber: '(999) 999-999',
    emailAddress: '',
    streetAddress1: '110 Circle Road',
    streetAddress2: 'Bentonville, AR, 72123, USA',
    address: '110 Circle Road, Bentonville, AR, 72123, USA',
    salesCustId: 678,
    custAcctNbr: '567',
    crmCompanyId: '788'
  },
  {
    contactId: 2,
    lastName: 'John',
    firstName: 'Goodman',
    accountNumber: '',
    companyName: 'Goodman Steel Inc',
    salesOfficeName: 'LEXINGTON-KY',
    phoneNumber: '(999) 999-9999',
    emailAddress: '',
    streetAddress1: '1101 Circle Road',
    streetAddress2: ' Bentonville, AR, 72123, USA',
    address: '1101 Circle Road, Bentonville, AR, 72123, USA',
    salesCustId: 789,
    custAcctNbr: '123',
    crmCompanyId: '6786'
  }];

  const testSearchContact: ISearchContactListModel = {
    pageNumber: 1,
    pageSize: 15,
    totalItemCount: 32,
    pageCount: 3,
    contacts,
  };

  const contact = {
    contactId: 2,
    lastName: 'John',
    firstName: 'Goodman',
    accountNumber: '',
    companyName: 'Goodman Steel Inc',
    salesOfficeName: 'LEXINGTON-KY',
    phoneNumber: '(999) 999-9999',
    emailAddress: '',
    streetAddress1: '1101 Circle Road',
    streetAddress2: ' Bentonville, AR, 72123, USA',
    address: '1101 Circle Road, Bentonville, AR, 72123, USA',
    salesCustId: 567,
    custAcctNbr: '567',
    crmCompanyId: '788'
  };

  const companyMock = {
    salesCustId: 34,
    firstName: 'ALL',
    lastName: 'Associates',
    customerName: 'Upchurch Plumbing And Heating',
    streetAddress1: 'Industrial park',
    streetAddress2: null,
    state: 'WI',
    zipCode: '54501',
    custAcctNbr: '10',
    contactPhoneNumber: '2222',
    contactFaxNumber: '5555',
    contactPhoneExtension: '2223',
  } as unknown as ISearchCustomerModel;

  const generalSectionData = [{
    jobClassId: 38,
    description: 'VerticalMarket',
    codes: [
      {
        jobCodeId: 1,
        description: 'service',
      },
    ],
  },
  {
    jobClassId: 108,
    description: 'Bod on Equipments',
    codes: [
      {
        jobCodeId: 1,
        description: 'BOD on major prod',
      },
    ],
  },
  {
    jobClassId: 109,
    description: 'Bod on Controls',
    codes: [
      {
        jobCodeId: 1,
        description: 'Expansion of trane',
      },
    ],
  },
  {
    jobClassId: 1,
    description: 'test classification',
    codes: [
      {
        jobCodeId: 1,
        description: 'testdescription',
      },
    ],
  },
  {
    jobClassId: 7,
    description: 'Vertical Market',
    codes: [
      {
        jobCodeId: 1,
        description: 'Service',
      },
    ],
  }];
  const errorText = 'Please enter all the required fields';
  const mockSaveCrmPayload = {
    opportunityName: 'Test Opp',
    status: 'O',
    businessUnit: 'TCS',
    company: 'NX',
    office: 'App',
    commCode: 'CC',
    salesOfficeId: 56,
    location: 'locationTest',
    salesProcess: 'SP',
    parentIndustryVerticalMarket: 'VM',
    totalBooking: 67,
    currency: 'USD',
    overallConf: 56,
    bookingDate: new Date(),
    revenueStream: 'testRevenue',
    totalControls: 67,
    controlsConf: 56,
    bidDate: new Date(),
    boDOnEquipment: 'B4',
    boDOnControls: 't5',
    extensibleAttributes: {
      attribute: [{
        name: '',
        value: ''
      }]
    },
    priorCode: [],
    programCode: [],
    site: [],
    contact: [],
    jobContact: null,
    foe2CreatedOrdersInd: 'Y',
    cplpafLocked: 0,
    checkedIn: 'Y',
    locationOfficeId: 1233,
    verticalMarketJobCodeId: 4567,
    jobRoleAsnViews: null,
    classifications: []
  };

  const assignedData = [{
    crmContactId: '743463',
    isPrimary: true
  },
  {
    crmContactId: '12345',
    isPrimary: false
  }] as unknown as IContact[];

  const createFormMock = {
    opportunityName: { value: 'testOpp' },
    salesOffice: { value: 56 },
    locationOffice: { value: 56 },
    salesPerson: { value: 'testControl' },
    jobContact: { value: 'contact' },
    status: { value: 'P' },
    revenueStreamType: { value: 'Service' },
    revenueStream: { value: 'testRevenueStream' },
    verticalMarket: { value: 'testVerticalMarket' },
    bodOnEquipment: { value: 'BodEquip' },
    bodOnControls: { value: 'BodControl' },
    bookingDollar: { value: 45 },
    controlDollar: { value: 56 },
    controlsPercentage: { value: 10 },
    bookingDate: { value: new Date('03/05/2019') },
    bidDate: { value: new Date('03/05/2019') },
    confidencePercentage: { value: 76 },
    currency: { value: 'USD' },
    businessUnit: { value: 'TCS' },
  };
  const checkBoxMock = [{
    displayValue: 'General VRF System',
    checked: false,
    value: '1',
  },
  {
    displayValue: 'COVID Response',
    checked: true,
    value: '2',
  }];

  const verticalMarketMock = [{
    jobCodeId: 1,
    description: 'BOD on major prod',
    jobCode: 'testVerticalMarket'
  }];
  const transitionalJobMock = { value: '76', description: 'Transitional Job', selected: true };
  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [CrmJobComponent, GroupCheckboxViewComponent, GeneralComponent, GroupSelectViewComponent],
      providers: [{ provide: TraneSalesBusinessDataService, useClass: TraneSalesBusinessDataServiceMock },
        AppConstants, SalesCustomerService, FormBuilder, SitesService, CreateCrmService,
        ToasterService, JobHeaderService, PopupService, NotificationService,
      { provide: LoaderService, useClass: LoaderServiceMock },
      { provide: GlobalFilterService, useClass: FilterServiceMock },
      { provide: Router, useClass: RouterMock },
      { provide: ApiErrorService, useClass: ApiErrorServiceMock },
      {
        provide: ActivatedRoute, useValue: {
          snapshot: { params: { jobId: 12, drAddressId: 121 } },
          fragment: Observable.of('test'),
        },
      },
      ],
    });
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(CrmJobComponent);
    component = fixture.componentInstance;
    traneSalesBusinessDataService = injector.inject(TraneSalesBusinessDataService);
    apiErrorService = injector.inject(ApiErrorService);
    sitesService = injector.inject(SitesService);
    salesCustomerService = injector.inject(SalesCustomerService);
    formBuilder = injector.inject(FormBuilder);
    createCrmService = injector.inject(CreateCrmService);
    toasterService = injector.inject(ToasterService);
    jobHeaderService = injector.inject(JobHeaderService);
    globalfilerService = injector.inject(GlobalFilterService);
    loaderService = injector.inject(LoaderService);
    spyClassification = spyOn(traneSalesBusinessDataService, 'getClassifications').and.returnValue(of(generalSectionData));
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.checkBoxComponent = {
        groupCheckboxForm: formBuilder.group({
          groupCheckboxOptions: new FormArray(testItems.map((item) => new FormControl(item.checked))),
        })
      } as GroupCheckboxViewComponent;
      component.generalComponent = {
        createJobForm: { valid: true, controls: createFormMock, markAllAsTouched: () => { } },
        selectedLocationOfficeCode: 'testLocationCode',
        selectedSalesOfficeCode: 'testCode',
        verticalMarketOptions: verticalMarketMock
      } as unknown as GeneralComponent;
      component.assignedCompanyGridData = [companyMock];
      component.assignedContactGridData = [contact];
      component.earthwiseSystems = testItems;
      component.programs = testItems;
      component.saveCrmPayload = mockSaveCrmPayload;
      component.showEarthwiseSystems = true;
      component.classification = {
        groupSelectForm: formBuilder.group({
          value: new FormControl({ groupSelectFormControls: new Array(1) })
        })
      } as unknown as GroupSelectViewComponent;
    });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call buildClassification, buildEarthwiseSystems, buildPrograms and buildCompany on calling ngOnInit', () => {
    const spyBuildClassification = spyOn(component, 'buildClassification');
    const spyBuildEarthwiseSystems = spyOn(component, 'buildEarthwiseSystems');
    const spyBuildPrograms = spyOn(component, 'buildPrograms');
    component.ngOnInit();
    expect(spyBuildClassification).toHaveBeenCalled();
    expect(spyBuildEarthwiseSystems).toHaveBeenCalled();
    expect(spyBuildPrograms).toHaveBeenCalled();
  });

  it('should assign classification from getClassifications on calling buildClassification', () => {
    component.buildClassification();
    expect(traneSalesBusinessDataService.getClassifications).toHaveBeenCalled();
    expect(component.classifications.length).toBe(1);
    expect(component.classifications[0].displayName).toBe('test classification');
    expect(component.classifications[0].options[0].description).toBe('testdescription');
    expect(component.classifications[0].options[1].description).toBe('None');
    expect(component.generalSectionData[0].description).toBe('VerticalMarket');
  });

  it('should show api error message when getClassifications throws error on calling buildClassification', () => {
    spyClassification.and.
      returnValue(Observable.throwError({ error: { messages: 'Error' } }));
    const spyApiErrorService = spyOn(apiErrorService, 'show');
    component.buildClassification();
    expect(traneSalesBusinessDataService.getClassifications).toHaveBeenCalled();
    expect(spyApiErrorService).toHaveBeenCalledWith('Error');
  });

  it(`should populate Earthwise system options and check 'No System' option on calling buildEarthwiseSystems`, () => {
    const earthwiseSpy = spyOn(traneSalesBusinessDataService, 'getEarthwiseSystems').and.callThrough();
    component.buildEarthwiseSystems();
    expect(earthwiseSpy).toHaveBeenCalled();
    expect(component.earthwiseSystems[0].value).toBe('1');
    expect(component.earthwiseSystems[0].displayValue).toBe('No System');
    expect(component.earthwiseSystems[0].checked).toBe(true);
  });

  it('should show api error message when buildEarthwiseSystems throws error', () => {
    const spy = spyOn(traneSalesBusinessDataService, 'getEarthwiseSystems').and.
      returnValue(Observable.throwError({ error: { messages: 'Error' } }));
    const spyApiErrorService = spyOn(apiErrorService, 'show');
    component.buildEarthwiseSystems();
    expect(spy).toHaveBeenCalled();
    expect(spyApiErrorService).toHaveBeenCalledWith('Error');
  });

  it('should set value for companyGridData and call searchTextHighlight on calling buildCompany', () => {
    spyOn(salesCustomerService, 'getSearchCustomers').and.returnValue(
      Observable.of(testSearchCustomer),
    );
    const spySearchTextHighlight = spyOn(component, 'searchTextHighlight');
    component.buildCompany(searchEvent);
    expect(component.companyGridData.data).toBe(testSearchCustomer.customerList);
    expect(spySearchTextHighlight).toHaveBeenCalledTimes(testSearchCustomer.customerList.length);
    expect(component.companyGridPageSize).toBe(15);
  });

  it(`should verify all checkbox are unchecked when no system checkbox is selected and set same the value
  for checked in earthwiseSystems on calling checkEarthwiseNoSystem`, () => {
    component.showEarthwiseSystems = true;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      const checkboxItem = { displayValue: 'No System', value: '1', checked: false, helpMessage: null };
      component.earthwiseSystems = [checkboxItem];
      const controls = ((component.checkBoxComponent.groupCheckboxForm.controls['groupCheckboxOptions']) as FormArray).controls;
      component.checkEarthwiseNoSystem(checkboxItem);
      expect(controls[0].value).toBe(true);
      expect(component.earthwiseSystems[0].checked).toBe(true);
    });
  });

  it(`should verify no system checkbox is unchecked when other checkbox is selected and set the value
  for checked in earthwiseSystems on calling checkEarthwiseNoSystem`, () => {
    component.showEarthwiseSystems = true;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      const checkboxItem = [{
        displayValue: 'Build',
        value: '1',
        checked: false,
        helpMessage: null
      },
      {
        displayValue: 'Build Design',
        value: '2',
        checked: false,
        helpMessage: null
      }];
      component.earthwiseSystems = checkboxItem;
      const controls = ((component.checkBoxComponent.groupCheckboxForm.controls['groupCheckboxOptions']) as FormArray).controls;
      component.checkEarthwiseNoSystem(checkboxItem[1]);
      expect(controls[0].value).toBe(false);
      expect(component.earthwiseSystems[0].checked).toBe(false);
      expect(component.earthwiseSystems[1].checked).toBe(true);
    });
  });

  it('should assign programs value and call loaderService to hide loader on calling buildPrograms', () => {
    const spyLoaderService = spyOn(loaderService, 'hide').and.callFake(() => { });
    const programSpy = spyOn(traneSalesBusinessDataService, 'getPrograms').and.callThrough();
    component.buildPrograms();
    expect(programSpy).toHaveBeenCalled();
    expect(component.programs[0].value).toBe('CLTC');
    expect(component.programs[0].displayValue).toBe('Critical to Close');
    expect(spyLoaderService).toHaveBeenCalled();
  });

  it('should show api error message and call loaderService to hide loader when buildPrograms throws error', () => {
    const spyLoaderService = spyOn(loaderService, 'hide').and.callFake(() => { });
    const spy = spyOn(traneSalesBusinessDataService, 'getPrograms').and.
      returnValue(Observable.throwError({ error: { messages: 'Error' } }));
    const spyApiErrorService = spyOn(apiErrorService, 'show');
    component.buildPrograms();
    expect(spy).toHaveBeenCalled();
    expect(spyApiErrorService).toHaveBeenCalledWith('Error');
    expect(spyLoaderService).toHaveBeenCalled();
  });

  it('should set assignedContactGridData values and set as primary if assignedContactGridData length is one on calling assignData', () => {
    const dataItem = { contactId: 5 };
    component.contactGridPageSize = 15;
    const event = { rowIndex: 1, data: dataItem, type: GridType.CONTACT };
    component.assignedContactGridData = [];
    component.contactData = contacts;
    component.assignData(event);
    expect(component.assignedContactGridData).toEqual([contacts[1]]);
    expect(component.assignedContactGridData[0].isPrimary).toEqual(true);
  });

  it('should set dialogOpened as true on calling assignData when user tries to assign duplicate contact', () => {
    const dataItem = { contactId: '1' };
    const event = { rowIndex: 1, data: dataItem, type: GridType.CONTACT };
    component.assignedContactGridData = [contacts[0]];
    component.contactGridData = { data: contacts, total: 2 };
    component.assignData(event);
    expect(component.dialogOpened).toBe(true);
    expect(component.dialogAction).toEqual(['OK']);
    expect(component.dialogType).toBe('info');
    expect(component.warningMessage).toBe('The selected contact has been already added');
  });

  it('should set assignedSiteGridData values on calling assignData', () => {
    const dataItem = {};
    const event = { rowIndex: 1, data: dataItem, type: GridType.SITE };
    component.assignedSiteGridData = [];
    component.siteGridData = { data: sites, total: 2 };
    component.assignData(event);
    expect(component.assignedSiteGridData).toEqual([sites[1]]);
  });

  it('should set dialogOpened as true on calling assignData when user tries to assign more than one site', () => {
    const dataItem = {};
    component.siteGridPageSize = 15;
    const event = { rowIndex: 1, data: dataItem, type: GridType.SITE };
    component.assignedSiteGridData = [sites[0]];
    component.assignData(event);
    expect(component.dialogOpened).toBe(true);
    expect(component.dialogAction).toEqual(['no', 'yes']);
    expect(component.dialogType).toBe('confirm');
    expect(component.warningMessage).toBe('The site has been already selected.Do you want to replace the selected site?');
  });

  it('should set assignedCompanyGridData values on calling assignData', () => {
    const dataItem = {};
    component.companyGridPageSize = 15;
    const event = { rowIndex: 0, data: dataItem, type: GridType.COMPANY };
    component.assignedCompanyGridData = [];
    component.companyData = testSearchCustomer.customerList;
    component.assignData(event);
    expect(component.assignedCompanyGridData).toEqual([testSearchCustomer.customerList[0]]);
  });

  it('should set dialogOpened as true on calling assignData when user tries to assign more than one company', () => {
    const dataItem = {};
    const event = { rowIndex: 1, data: dataItem, type: GridType.COMPANY };
    component.assignedCompanyGridData = [testSearchCustomer.customerList[0]];
    component.assignData(event);
    expect(component.dialogOpened).toBe(true);
    expect(component.dialogAction).toEqual(['no', 'yes']);
    expect(component.dialogType).toBe('confirm');
    expect(component.warningMessage).toBe('The company has been already selected.Do you want to replace the selected company?');
  });

  it('should remove contact from assignedContactGridData on calling removeContact', () => {
    component.assignedContactGridData = [contacts[0]];
    const rowIndex = 1;
    component.removeContact(rowIndex);
    expect(component.assignedContactGridData).toEqual([]);
  });

  it(`should remove the existing company details and assign new company details to assignedCompanyGridData
  on calling deleteAndAssignData`, () => {
    component.type = GridType.COMPANY;
    component.rowIndex = 30;
    component.companyGridPageSize = 15;
    component.companyGridData = { data: testSearchCustomer.customerList, total: 2 };
    component.assignedCompanyGridData = [companyMock];
    component.deleteAndAssignData();
    expect(component.assignedCompanyGridData).toEqual([testSearchCustomer.customerList[0]]);
    expect(component.dialogOpened).toBe(false);
  });

  it('should delete and assign new site when user clicks yes on a confirm dialog', () => {
    component.type = GridType.SITE;
    component.rowIndex = 1;
    component.siteGridData = { data: sites, total: 2 };
    component.assignedSiteGridData = [sites[0]];
    component.deleteAndAssignData();
    expect(component.assignedSiteGridData).toEqual([sites[1]]);
    expect(component.dialogOpened).toBe(false);
  });

  it(`should set value for siteGridData and call searchTextHighlight on calling fetchSites`, () => {
    const event = { searchText: 'test', skip: 1, take: 15 };
    component.assignedCompanyGridData = testSearchCustomer.customerList;
    spyOn(sitesService, 'getCrmSites').and.returnValue(
      Observable.of(siteSearchResult));
    const spySearchTextHighlight = spyOn(component, 'searchTextHighlight');
    const concatAddress = 'test address1, test address4, test address3';
    component.fetchSites(event);
    expect(component.siteGridData.data[0].address).toBe(concatAddress);
    expect(component.siteGridData.data[0].siteName).toBe('testSite');
    expect(spySearchTextHighlight).toHaveBeenCalled();
    expect(component.siteGridPageSize).toBe(15);
  });

  it('should set value for contactGridData and call searchTextHighlight on calling fetchContacts', () => {
    spyOn(salesCustomerService, 'getSearchContacts').and.returnValue(
      Observable.of(testSearchContact),
    );
    const spySearchTextHighlight = spyOn(component, 'searchTextHighlight');
    component.fetchContacts(searchEvent);
    expect(component.contactGridData.data).toBe(testSearchContact.contacts);
    expect(spySearchTextHighlight).toHaveBeenCalled();
    expect(component.contactGridPageSize).toBe(15);
  });

  it('should highlight grid data based on user serach input value on searchTextHighlight', () => {
    component.searchTextHighlight(contact, 'Good');
    expect(contact.firstName).toBe('<em>Good</em>man');
  });

  it('should set contactGridData to be empty if searchText was null/empty on calling fetchContacts', () => {
    component.fetchContacts(emptySearchEvent);
    expect(component.contactGridData.data).toEqual([]);
  });

  it('should set contactGridData to be empty if getSearchContacts returns null on calling fetchContacts', () => {
    spyOn(salesCustomerService, 'getSearchContacts').and.returnValue(
      Observable.of(null),
    );
    component.fetchContacts(searchEventEmptyResult);
    expect(component.contactGridData.data).toEqual([]);
  });

  it('should set siteGridData to be empty if searchText was null/empty on calling fetchSites', () => {
    const event = { searchText: '' };
    component.assignedCompanyGridData = testSearchCustomer.customerList;
    component.assignedCompanyGridData[0].crmCompanyId = '6789';
    component.fetchSites(event);
    expect(component.siteGridData.data).toEqual([]);
  });

  it('should set companyGridData to be empty if searchText was null/empty on calling buildCompany', () => {
    component.buildCompany(emptySearchEvent);
    expect(component.companyGridData.data).toEqual([]);
  });

  it('should set companyGridData if searchText and filtertext was not null/empty on calling buildCompany', () => {
    component.companyGridData = component.emptyGridData;
    spyOn(salesCustomerService, 'getSearchCustomers').and.returnValue(Observable.of({
      customerList: [
        {
          customerName: 'abcasssdef',
          phoneNumber: '123-456',
          companyId: 123
        },
        {
          customerName: 'abcass',
          phoneNumber: '123-456',
          companyId: 123
        }],
      totalItemCount: 20
    }));
    component.buildCompany(searchAndFilter);
    expect(component.companyGridData.data.length).toEqual(2);
    expect(component.companyGridData.total).toEqual(20);
    expect(component.showGridLoader).toBe(false);
  });

  it('should set companyGridData to be empty if getSearchCustomers is returns null on calling buildCompany', () => {
    spyOn(salesCustomerService, 'getSearchCustomers').and.returnValue(
      Observable.of(null),
    );
    component.buildCompany(searchEventEmptyResult);
    expect(component.companyGridData.data).toEqual([]);
    expect(component.companyGridPageSize).toBe(0);
  });

  it('should be set to empty if getSearchCustomers returns error on calling buildCompany', () => {
    component.companyGridData = { data: [{ crmCompanyId: 123 }], total: 10 };
    spyOn(salesCustomerService, 'getSearchCustomers').and.returnValue(Observable.throwError({ error: 'error' }));
    component.buildCompany(searchEventEmptyResult);
    expect(component.companyGridData.data).toEqual([]);
    expect(component.companyGridPageSize).toBe(0);
  });

  it(`should show apiErrorService when getCrmSites throws error on calling fetchSites`, () => {
    const event = { searchText: 'test' };
    component.assignedCompanyGridData = testSearchCustomer.customerList;
    component.assignedCompanyGridData[0].crmCompanyId = '46758';
    spyOn(sitesService, 'getCrmSites').and.returnValue(Observable.throwError({ error: { messages: 'Error' } }));
    const spyApiErrorService = spyOn(apiErrorService, 'show');
    component.fetchSites(event);
    expect(spyApiErrorService).toHaveBeenCalledWith('Error');
  });

  it(`should close window when calling onCancel`, () => {
    const spy = spyOn(window, 'close');
    component.onCancel();
    expect(spy).toHaveBeenCalled();
  });

  it(`should call loaderService to show loader and createCrmJob on calling onSave`, () => {
    const spyCreateCrmJob = spyOn(component, 'createCrmJob').and.callFake(() => { });
    const spyPayload = spyOn(component, 'setPayload');
    const spyLoaderService = spyOn(loaderService, 'show').and.callFake(() => { });
    const spySetClassifications = spyOn(component, 'setClassifications').and.callFake(() => { });
    component.showClassification = true;
    component.generalComponent = {
      createJobForm: { valid: true, controls: createFormMock, markAllAsTouched: () => { } },
      selectedLocationOfficeCode: 'testLocationCode',
      selectedSalesOfficeCode: 'testCode',
      verticalMarketOptions: verticalMarketMock
    } as unknown as GeneralComponent;
    component.isEarthwiseChecked = true;
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.earthwiseSystems = testItems;
    component.programs = testItems;
    component.onSave();
    expect(spyCreateCrmJob).toHaveBeenCalled();
    expect(spyLoaderService).toHaveBeenCalled();
    expect(spyPayload).toHaveBeenCalled();
    expect(spySetClassifications).toHaveBeenCalled();
  });

  it(`should call setToaster if assignedCompanyGridData is empty and not call loaderService to show loader on calling onSave`, () => {
    const markAllAsTouchedSpy = spyOn(component.generalComponent.createJobForm, 'markAllAsTouched');
    component.assignedCompanyGridData = [];
    component.assignedContactGridData[0] = contact[0];
    component.isEarthwiseChecked = true;
    component.showClassification = true;
    const spyCreateCrmJob = spyOn(createCrmService, 'createCrmJob');
    const spyToasterService = spyOn(toasterService, 'setToaster');
    const spyLoaderService = spyOn(loaderService, 'show').and.callFake(() => { });
    component.onSave();
    expect(markAllAsTouchedSpy).toHaveBeenCalled();
    expect(spyCreateCrmJob).not.toHaveBeenCalled();
    expect(spyToasterService).toHaveBeenCalledWith('error', errorText);
    expect(spyLoaderService).not.toHaveBeenCalled();
  });

  it(`should call setToaster if assignedContactGridData is empty on calling onSave`, () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [];
    component.isEarthwiseChecked = true;
    component.generalComponent = {
      createJobForm: { valid: false, controls: createFormMock, markAllAsTouched: () => { } },
    } as unknown as GeneralComponent;
    const spyCreateCrmJob = spyOn(createCrmService, 'createCrmJob');
    const spyToasterService = spyOn(toasterService, 'setToaster');
    component.onSave();
    expect(spyCreateCrmJob).not.toHaveBeenCalled();
    expect(spyToasterService).toHaveBeenCalledWith('error', errorText);
  });

  it(`should call setToaster if isEarthwiseChecked is false on calling onSave`, () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.earthwiseSystems = testItems;
    component.generalComponent = {
      createJobForm: { valid: true, controls: createFormMock, markAllAsTouched: () => { } },
    } as unknown as GeneralComponent;
    component.isEarthwiseChecked = false;
    const spyCreateCrmJob = spyOn(createCrmService, 'createCrmJob');
    const spyToasterService = spyOn(toasterService, 'setToaster');
    component.onSave();
    expect(spyCreateCrmJob).not.toHaveBeenCalled();
    expect(spyToasterService).toHaveBeenCalledWith('error', errorText);
  });

  it(`should call setToaster if createJobForm is invalid on calling onSave`, () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.generalComponent = {
      createJobForm: { valid: false, controls: createFormMock, markAllAsTouched: () => { } },
      selectedLocationOfficeCode: 'testLocationCode',
      selectedSalesOfficeCode: 'testCode'
    } as unknown as GeneralComponent;
    const spyCreateCrmJob = spyOn(createCrmService, 'createCrmJob');
    const spyToasterService = spyOn(toasterService, 'setToaster');
    component.onSave();
    expect(spyCreateCrmJob).not.toHaveBeenCalled();
    expect(spyToasterService).toHaveBeenCalledWith('error', errorText);
  });

  it(`should call show apiErrorService, if service throws error and call loaderService to hide loader on calling createCrmJob`, () => {
    spyOn(createCrmService, 'createCrmJob').and.
      returnValue(Observable.throwError({ error: { messages: 'Error' } }));
    const spyApiErrorService = spyOn(apiErrorService, 'show');
    const spyLoaderService = spyOn(loaderService, 'hide').and.callFake(() => { });
    component.showClassification = true;
    component.createCrmJob();
    expect(spyApiErrorService).toHaveBeenCalled();
    expect(spyLoaderService).toHaveBeenCalled();
  });

  it(`should navigate to configure, if jobId return from service is greater than 0 and
  call loaderService to hide loader on calling createCrmJob`, () => {
    const jobId = 123;
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    spyOn(createCrmService, 'createCrmJob').and.returnValue(of(jobId));
    const spyRouterNavigate = spyOn(component.router, 'navigate');
    const spyLoaderService = spyOn(loaderService, 'hide').and.callFake(() => { });
    component.createCrmJob();
    expect(spyRouterNavigate).toHaveBeenCalled();
    expect(spyLoaderService).toHaveBeenCalled();
  });

  it(`should not navigate to configure, if jobId return from service is 0 on calling createCrmJob`, () => {
    const jobId = 0;
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    spyOn(createCrmService, 'createCrmJob').and.returnValue(of(jobId));
    const spyRouterNavigate = spyOn(component.router, 'navigate');
    component.createCrmJob();
    expect(spyRouterNavigate).not.toHaveBeenCalled();
  });

  it(`should set earthwiseSystems value to priorCode in saveCrmPayload which has checked value as true on calling onSave`, () => {
    component.companyGridPageSize = 10;
    component.companyData = [companyMock];
    spyOn(component, 'createCrmJob').and.callFake(() => { });
    component.generalComponent = {
      createJobForm: { valid: true, controls: createFormMock, markAllAsTouched: () => { } },
      selectedLocationOfficeCode: 'testLocationCode',
      selectedSalesOfficeCode: 'testCode',
      verticalMarketOptions: verticalMarketMock
    } as unknown as GeneralComponent;
    component.checkBoxComponent = {
      groupCheckboxForm: formBuilder.group({
        groupCheckboxOptions: new FormArray(checkBoxMock.map((item) => new FormControl(item.checked))),
      })
    } as GroupCheckboxViewComponent;
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.earthwiseSystems = checkBoxMock;
    component.programs = checkBoxMock;
    component.onSave();
    expect(component.saveCrmPayload.priorCode[0].system).toEqual(checkBoxMock[1].value);
  });

  it('should set jobRoleAsn property for saveCrmPayload on payload', () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.saveCrmPayload = {} as ISaveCrmModel;
    component.setPayload();
    const testJobRoleAsnViews = component.saveCrmPayload.jobRoleAsnViews[1];
    expect(testJobRoleAsnViews.jobRoleAsnId).toEqual(0);
    expect(testJobRoleAsnViews.jobId).toEqual(0);
    expect(testJobRoleAsnViews.jobRoleTypeId).toEqual(0);
    expect(testJobRoleAsnViews.salesCustomerName).toEqual('Upchurch Plumbing And Heating');
    expect(testJobRoleAsnViews.salesCustId).toEqual(34);
    expect(testJobRoleAsnViews.hostUpdateInd).toEqual(null);
    expect(testJobRoleAsnViews.bidderInd).toEqual(null);
    expect(testJobRoleAsnViews.winningBidderInd).toEqual(null);
    expect(testJobRoleAsnViews.name).toEqual('ALL Associates');
    expect(testJobRoleAsnViews.phoneNbr).toEqual('2222');
    expect(testJobRoleAsnViews.faxNbr).toEqual('5555');
    expect(testJobRoleAsnViews.phoneExtension).toEqual('2223');
    expect(testJobRoleAsnViews.isJobRoleSelected).toEqual(false);
    expect(testJobRoleAsnViews.jobRoleContactId).toEqual(0);
  });

  it('should set jobRoleAsn name to firstName if lastName is null on calling setPayload', () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.assignedContactGridData[0].firstName = 'Goodman';
    component.assignedCompanyGridData[0].firstName = 'ALL';
    component.assignedCompanyGridData[0].lastName = null;
    component.assignedContactGridData[0].lastName = null;
    component.saveCrmPayload = {} as ISaveCrmModel;
    component.setPayload();
    expect(component.saveCrmPayload.jobRoleAsnViews[0].name).toEqual('Goodman');
    expect(component.saveCrmPayload.jobRoleAsnViews[1].name).toEqual('ALL');
  });

  it('should set jobRoleAsn name to lastName if firstName is null on calling setPayload', () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.assignedContactGridData[0].firstName = null;
    component.assignedCompanyGridData[0].firstName = null;
    component.assignedCompanyGridData[0].lastName = 'Associates';
    component.assignedContactGridData[0].lastName = 'John';
    component.saveCrmPayload = {} as ISaveCrmModel;
    component.setPayload();
    expect(component.saveCrmPayload.jobRoleAsnViews[0].name).toEqual('John');
    expect(component.saveCrmPayload.jobRoleAsnViews[1].name).toEqual('Associates');
  });

  it(`should set jobRoleAsn name to null if assignedCompanyGridData and assignedContactGridData,
   firstName and lastName is null on calling setPayload`, () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.assignedContactGridData[0].firstName = null;
    component.assignedContactGridData[0].lastName = null;
    component.assignedCompanyGridData[0].firstName = null;
    component.assignedCompanyGridData[0].lastName = null;
    component.saveCrmPayload = {} as ISaveCrmModel;
    component.setPayload();
    expect(component.saveCrmPayload.jobRoleAsnViews[0].name).toEqual(null);
    expect(component.saveCrmPayload.jobRoleAsnViews[1].name).toEqual(null);
  });

  it(`should set jobRoleAsn name to null if assignedCompanyGridData,
  firstName and lastName is null on calling setPayload`, () => {
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [{
      contactId: 2,
      lastName: 'John',
      firstName: 'Goodman',
      accountNumber: '',
      phoneNumber: '999-9999',
      emailAddress: '',
      salesCustId: 567,
      custAcctNbr: '567',
      crmCompanyId: '788'
    }] as unknown as IContact[];
    component.assignedCompanyGridData[0].firstName = null;
    component.assignedCompanyGridData[0].lastName = null;
    component.saveCrmPayload = {} as ISaveCrmModel;
    component.setPayload();
    expect(component.saveCrmPayload.jobRoleAsnViews[0].name).toEqual('Goodman John');
    expect(component.saveCrmPayload.jobRoleAsnViews[1].name).toEqual(null);
  });

  it(`should set programs value to programCode in saveCrmPayload which has checked value as true on calling onSave`, () => {
    component.companyData = [companyMock];
    component.showPrograms = true;
    const spyCreateCrmJob = spyOn(component, 'createCrmJob');
    component.generalComponent = {
      createJobForm: { valid: true, controls: createFormMock, markAllAsTouched: () => { } },
      selectedLocationOfficeCode: 'testLocationCode',
      selectedSalesOfficeCode: 'testCode',
      verticalMarketOptions: verticalMarketMock,
    } as unknown as GeneralComponent;
    component.programs = checkBoxMock;
    component.earthwiseSystems = checkBoxMock;
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = [contact];
    component.onSave();
    expect(spyCreateCrmJob).toHaveBeenCalled();
    expect(component.saveCrmPayload.programCode[0].program).toEqual(checkBoxMock[1].value);
  });

  it(`should set assignedContactGridData value to contact in saveCrmPayload, primaryFlag as Y
  which has isPrimary value as true and set VerticalMarketJobCodeId on calling onSave`, () => {
    component.companyData = [companyMock];
    const spyCreateCrmJob = spyOn(component, 'createCrmJob').and.callFake(() => { });
    component.generalComponent = {
      createJobForm: { valid: true, controls: createFormMock, markAllAsTouched: () => { } },
      selectedLocationOfficeCode: 'testLocationCode',
      selectedSalesOfficeCode: 'testCode',
      verticalMarketOptions: verticalMarketMock
    } as unknown as GeneralComponent;
    component.isEarthwiseChecked = true;
    component.assignedCompanyGridData = [companyMock];
    component.assignedContactGridData = assignedData;
    component.earthwiseSystems = testItems;
    component.programs = testItems;
    component.onSave();
    expect(spyCreateCrmJob).toHaveBeenCalled();
    expect(component.saveCrmPayload.contact[0].contactId)
      .toEqual(assignedData[0].crmContactId);
    expect(component.saveCrmPayload.contact[0].primaryFlag).toEqual('Y');
    expect(component.saveCrmPayload.contact[1].contactId)
      .toEqual(assignedData[1].crmContactId);
    expect(component.saveCrmPayload.contact[1].primaryFlag).toEqual('N');
    expect(component.saveCrmPayload.verticalMarketJobCodeId).toEqual(1);
  });

  it(`should call checkSystem on calling checkProgramNoSystem`, () => {
    const spyCheckSystem = spyOn(component, 'checkSystem').and.callFake(() => { });
    component.checkProgramNoSystem(testItems[0]);
    expect(spyCheckSystem).toHaveBeenCalledWith(component.programs, testItems[0]);
  });

  it(`should set isEarthwiseChecked to false, if checked in earthwiseSystems has no true on calling checkEarthwiseSystemChecked`, () => {
    component.isEarthwiseChecked = false;
    component.earthwiseSystems = testItems;
    component.checkEarthwiseSystemChecked();
    expect(component.isEarthwiseChecked).toBe(false);
  });

  it(`should set isEarthwiseChecked to true, if checked in earthwiseSystems has true on calling checkEarthwiseSystemChecked`, () => {
    component.isEarthwiseChecked = false;
    component.earthwiseSystems = testItems;
    component.earthwiseSystems[0].checked = true;
    component.checkEarthwiseSystemChecked();
    expect(component.isEarthwiseChecked).toBe(true);
  });

  it(`should return classification selected data along with transitional job on calling setClassifications()`, () => {
    component.classification.groupSelectForm.value.groupSelectFormControls = ['2'];
    const classificationMock: ISelectOption[] = [
      { value: '2', description: 'Mech / Sheetmetal-more than 30% des/bld', selected: true },
      transitionalJobMock
    ];
    component.classifications = [{ displayName: 'Purchaser Class', options: Array(3), selectedValue: '' }];
    component.classifications[0].options = [
      { value: '1', description: 'Mech / Sheetmetal-less than 30% des/bld', selected: false },
      { value: '2', description: 'Mech / Sheetmetal-more than 30% des/bld', selected: false },
      { value: '3', description: 'Controls Contractor', selected: false }
    ];
    const selectedClassifications = component.setClassifications();
    expect(selectedClassifications).toEqual(classificationMock);
  });

  it(`should return transitional job data if no classification is selected on calling setClassifications()`, () => {
    component.classification.groupSelectForm.value.groupSelectFormControls = [null];
    const selectedClassifications = component.setClassifications();
    expect(selectedClassifications).toEqual([transitionalJobMock]);
  });

});
