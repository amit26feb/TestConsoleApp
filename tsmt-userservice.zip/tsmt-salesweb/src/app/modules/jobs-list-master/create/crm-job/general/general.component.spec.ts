import { ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import * as moment from 'moment';
import { of } from 'rxjs';
import { Observable } from 'rxjs';
import { IOfficeSelectorModel } from '../../../../../shared/model/office-selector-model';
import { ApiErrorService } from '../../../../../shared/services/apierror.service';
import { GlobalFilterService } from '../../../../../shared/services/global-filter.service';
import { JobHeaderService } from '../../../../../shared/services/job-header.service';
import { ApiErrorServiceMock } from '../../../../../shared/test-mocks/apierrorservice-mock';
import { FilterServiceMock } from '../../../../../shared/test-mocks/filterservice-mock';
import { TraneSalesBusinessDataServiceMock } from '../../../../../shared/test-mocks/tranesalesbusinessdata-mock';
import { ISalesOfficeList } from '../../../modal/job-details-edit.model';
import { ICurrencyListModel } from '../../../models/create-crm.model';
import { TraneSalesBusinessDataService } from '../../../services/trane-sales-business-data.service';
import { AppConstants } from './../../../../../shared/constants/constants';
import { GeneralComponent } from './general.component';

describe('GeneralComponent', () => {
  let component: GeneralComponent;
  let fixture: ComponentFixture<GeneralComponent>;
  let traneSalesBusinessDataService: TraneSalesBusinessDataService;
  let injector: TestBed;
  let globalfilerService: GlobalFilterService;
  let apiErrorService: ApiErrorService;
  let jobHeaderService: JobHeaderService;
  let appConstants: AppConstants;
  const serverErrorMessage = 'server error';
  const name = 'user, test';
  const testSalesOfficeList = [{
    salesOfficeId: 447,
    salesOfficeName: 'ALGERIA',
    salesDistrict: '144',
    salesOfficeIdParent: '357',
    country: 'USA',
    salesOfficeCode: 'testCode'
  }] as ISalesOfficeList[];

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [GeneralComponent],
      providers: [JobHeaderService,
        { provide: GlobalFilterService, useClass: FilterServiceMock },
        { provide: TraneSalesBusinessDataService, useClass: TraneSalesBusinessDataServiceMock },
        { provide: ApiErrorService, useClass: ApiErrorServiceMock },
        {
          provide: ActivatedRoute, useValue: {
            snapshot: { params: { jobId: 12, drAddressId: 121 } },
            fragment: Observable.of('test'),
          },
        }, AppConstants,
      ],
    }),
      injector = getTestBed();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneralComponent);
    component = fixture.componentInstance;
    component.generalSectionData = [{
      jobClassId: 38,
      description: 'Vertical Market',
      codes: [
        {
          jobCodeId: 1,
          description: 'service',
        },
      ],
    },
    {
      jobClassId: 108,
      description: 'Bod on Equipments',
      codes: [
        {
          jobCodeId: 1,
          description: 'BOD on major prod',
        },
      ],
    },
    {
      jobClassId: 109,
      description: 'Bod on Controls',
      codes: [
        {
          jobCodeId: 1,
          description: 'Expansion of trane',
        },
      ],
    }];
    traneSalesBusinessDataService = injector.inject(TraneSalesBusinessDataService);
    apiErrorService = injector.inject(ApiErrorService);
    jobHeaderService = injector.inject(JobHeaderService);
    globalfilerService = injector.inject(GlobalFilterService);
    appConstants = injector.inject(AppConstants);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should call fetchOfficeSelectorList and getRevenueStream on calling ngOnInit`, () => {
    const spyGetOfficeSelectorList = spyOn(component, 'fetchOfficeSelectorList').and.callThrough();
    const revenueStreamSpy = spyOn(traneSalesBusinessDataService, 'getRevenueStream').and.callThrough();
    component.ngOnInit();
    expect(spyGetOfficeSelectorList).toHaveBeenCalled();
    expect(revenueStreamSpy).toHaveBeenCalled();
  });

  it(`should set officeSelectorName value and call fetchSalesOffice on calling fetchOfficeSelectorList`, () => {
    const testSalesOffice = [{
      salesOfficeName: 'Billings',
      drAddressId: 121,
      country: 'USA',
      crmIntegrationInd: 'Y',
      homeDrAddressId: 0,
      buInd: 'Y',
    }] as IOfficeSelectorModel[];
    component.officeSelectorValue = 121;
    spyOn(globalfilerService, 'getOfficeSelectorList')
      .and.returnValue(Observable.of(testSalesOffice));
    const spyGetSalesOffice = spyOn(component, 'fetchSalesOffice');
    component.fetchOfficeSelectorList();
    expect(component.officeSelectorName).toBe(testSalesOffice[0].salesOfficeName);
    expect(spyGetSalesOffice).toHaveBeenCalled();
  });

  it(`should set value to salesOfficeList, selectedLocationOfficeCode, selectedSalesOfficeCode and call fetchCommissionCodesList, fetchJobContactList, setCurrencyList on calling fetchSalesOffice`, () => {
    const getSalesOfficeMock = [{
      salesOfficeId: 925,
      salesOfficeName: '2 J Supply',
      salesDistrict: '844',
      salesOfficeIdParent: null,
      country: 'USA',
      salesOfficeCode: 'testCode'
    }] as ISalesOfficeList[];
    component.officeSelectorName = '2 J Supply';
    spyOn(traneSalesBusinessDataService, 'getSalesOffices').and.returnValue(of(getSalesOfficeMock));
    const spyGetCommissionCodesList = spyOn(component, 'fetchCommissionCodesList');
    const spyGetJobContactList = spyOn(component, 'fetchJobContactList');
    const spySetCurrencyList = spyOn(component, 'setCurrencyList');
    component.fetchSalesOffice();
    expect(component.salesOfficeList).toEqual(getSalesOfficeMock);
    expect(spyGetCommissionCodesList).toHaveBeenCalled();
    expect(spyGetJobContactList).toHaveBeenCalled();
    expect(spySetCurrencyList).toHaveBeenCalled();
    expect(component.selectedSalesOfficeCode).toEqual(getSalesOfficeMock[0].salesOfficeCode);
    expect(component.selectedLocationOfficeCode)
      .toEqual(getSalesOfficeMock[0].salesOfficeCode);
  });

  it(`should call error service when getSalesOffices throws error on calling fetchSalesOffice`, () => {
    spyOn(traneSalesBusinessDataService, 'getSalesOffices')
      .and.returnValue(Observable.throwError({ error: { Message: serverErrorMessage } }));
    const spyApiErrorService = spyOn(apiErrorService, 'show').and.callThrough();
    component.fetchSalesOffice();
    expect(spyApiErrorService).toHaveBeenCalledWith(serverErrorMessage);
  });

  it(`should not call fetchCommissionCodesList and salesOfficeList to be undefined
   if service returns null on calling fetchSalesOffice`, () => {
    spyOn(traneSalesBusinessDataService, 'getSalesOffices').and.returnValue(Observable.of(null));
    const spyGetCommissionCodesList = spyOn(component, 'fetchCommissionCodesList').and.callThrough();
    component.fetchSalesOffice();
    expect(component.salesOfficeList).toBeUndefined();
    expect(spyGetCommissionCodesList).not.toHaveBeenCalled();
  });

  it(`should not call fetchCommissionCodesList if service response
  does not match with officeSelectorName on calling fetchSalesOffice`, () => {
    const getSalesOfficeMock = [{
      salesOfficeId: 925,
      salesOfficeName: 'Supply',
      salesDistrict: '844',
      salesOfficeIdParent: null,
      country: 'USA',
    }] as ISalesOfficeList[];
    component.officeSelectorName = 'testOfficeSelectorName';
    spyOn(traneSalesBusinessDataService, 'getSalesOffices').and.returnValue(of(getSalesOfficeMock));
    const spyGetCommissionCodesList = spyOn(component, 'fetchCommissionCodesList').and.callThrough();
    component.fetchSalesOffice();
    expect(spyGetCommissionCodesList).not.toHaveBeenCalled();
  });

  it(`should set salesOfficeSelectedValue, selectedSalesOfficeCode and call fetchCommissionCodesList, setCurrencyList and fetchJobContactList on calling selectChangeHandler`, () => {
    const selectedVal = 447;
    component.salesOfficeList = testSalesOfficeList;
    const spyGetCommissionCodesList = spyOn(component, 'fetchCommissionCodesList').and.callThrough();
    const spyGetJobContactList = spyOn(component, 'fetchJobContactList').and.callThrough();
    const spySetCurrencyList = spyOn(component, 'setCurrencyList').and.callThrough();
    component.selectChangeHandler(selectedVal);
    expect(component.salesOfficeSelectedValue[0].salesOfficeId).toBe(447);
    expect(spyGetCommissionCodesList).toHaveBeenCalledWith(447);
    expect(spyGetJobContactList).toHaveBeenCalledWith(447);
    expect(spySetCurrencyList).toHaveBeenCalledWith(testSalesOfficeList[0].country);
    expect(component.selectedSalesOfficeCode).toEqual(testSalesOfficeList[0].salesOfficeCode);
  });

  it(`should not call the service on calling selectChangeHandler if salesOfficeList doesnot have the selectedVal`, () => {
    const selectedVal = 4470;
    component.salesOfficeList = testSalesOfficeList;
    const spyGetCommissionCodesList = spyOn(component, 'fetchCommissionCodesList');
    component.selectChangeHandler(selectedVal);
    expect(spyGetCommissionCodesList).not.toHaveBeenCalled();
  });

  it(`should call error service when getCommissionCodes throws error on calling fetchCommissionCodesList`, () => {
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(traneSalesBusinessDataService, 'getCommissionCodes')
      .and.returnValue(Observable.throwError({ error: { Message: serverErrorMessage } }));
    const salesOfficeId = 112;
    component.fetchCommissionCodesList(salesOfficeId);
    expect(apiErrorService.show).toHaveBeenCalledWith(serverErrorMessage);
  });

  it(`should assign response from the server to jobContactList on calling fetchJobContactList`, () => {
    const testUserId = 'lamsp';
    component.checkUser = false;
    spyOn(jobHeaderService, 'getUserId').and.returnValue(testUserId);
    spyOn(traneSalesBusinessDataService, 'getJobContacts')
      .and.returnValue(Observable.of([{ userId: testUserId, userName: name }]));
    component.fetchJobContactList(23);
    expect(component.jobContactList[0].userId).toBe(testUserId);
    expect(component.checkUser).toBe(true);
  });

  it(`should call error service when getJobContacts throws error on calling fetchJobContactList`, () => {
    spyOn(traneSalesBusinessDataService, 'getJobContacts')
      .and.returnValue(Observable.throwError({ error: { Message: serverErrorMessage } }));
    spyOn(apiErrorService, 'show').and.callThrough();
    component.fetchJobContactList(0);
    expect(apiErrorService.show).toHaveBeenCalledWith(serverErrorMessage);
  });

  it(`should assign current user details to the job contact list on calling fetchJobContactList when server returns null`, () => {
    const testUserId = 'lamsp';
    component.checkUser = false;
    spyOn(jobHeaderService, 'getUserId').and.returnValue(testUserId);
    spyOn(jobHeaderService, 'getFullName').and.returnValue(name);
    spyOn(traneSalesBusinessDataService, 'getJobContacts').and.returnValue(Observable.of(null));
    component.fetchJobContactList(23);
    expect(component.jobContactList.length).toBe(1);
    expect(component.jobContactList[0].userId).toBe(testUserId);
    expect(component.jobContactList[0].userName).toBe(name);
  });

  it('should set verticalMarketOptions,bodOnEquipmentsOptions,bodOnControlsOptions,revenueStreamTypeOptions on calling ngOninit', () => {
    component.ngOnInit();
    expect(component.verticalMarketOptions[0].description).toBe('service');
    expect(component.bodOnEquipmentsOptions[0].description).toBe('BOD on major prod');
    expect(component.bodOnControlsOptions[0].description).toBe('Expansion of trane');
    expect(component.revenueStreamTypeOptions[0].type).toBe('Contracting');
  });

  it('should set bookingDollar and controlDollar as empty when the value is zero on calling validateFormControls', () => {
    component.createJobForm.controls['bookingDollar'].setValue(0);
    component.createJobForm.controls['controlDollar'].setValue(0);
    component.validateFormControls('bookingDollar', 0);
    expect(component.createJobForm.controls['bookingDollar'].value).toBe('');
    component.validateFormControls('controlDollar', 0);
    expect(component.createJobForm.controls['controlDollar'].value).toBe('');
  });

  it('should set value for revenue stream based on selected revenue stream field value', () => {
    // Unit test for checking revenue stream when revenue stream type is contracting
    component.ngOnInit();
    component.revenueStreamResponse = [
      {
        revenueStreamFieldValue: 'CSNG',
        description: 'Contracting - CS No Guarantee',
      },
      {
        revenueStreamFieldValue: 'APNC',
        description: 'System - Applied no Control',
      },
      {
        revenueStreamFieldValue: 'SESH',
        description: 'Service - Controls Scheduled',
      }];
    component.filterRevenueStream(component.revenueStreamTypeOptions[0].fieldValue);
    expect(component.filteredRevenue[0].description).toBe('Contracting - CS No Guarantee');

    // Unit test for checking revenue stream when revenue stream type is systems
    component.filterRevenueStream(component.revenueStreamTypeOptions[1].fieldValue);
    expect(component.filteredRevenue[0].description).toBe('System - Applied no Control');

    // Unit test for checking revenue stream when revenue stream type is service
    component.filterRevenueStream(component.revenueStreamTypeOptions[2].fieldValue);
    expect(component.filteredRevenue[0].description).toBe('Service - Controls Scheduled');
  });

  it(`should set selectedValue to COMMSALE and currencyList which has currency name as
  USD if country is USA on calling setCurrencyList`, () => {
    const currencyListMock = [{
      name: '$USD',
      code: 'COMMSALE'
    }] as ICurrencyListModel[];
    component.setCurrencyList('USA');
    expect(component.currencyList).toEqual(currencyListMock);
    expect(component.selectedCurrencyCode).toEqual(currencyListMock[0].code);
  });

  it(`should set selectedValue to CANADA and currencyList if currency is CAN on calling setCurrencyList`, () => {
    const currencyListMock = [{
      name: '$CAD',
      code: 'CANADA'
    },
    {
      name: '$USD',
      code: 'COMMSALE'
    }] as ICurrencyListModel[];
    component.setCurrencyList('CAN');
    expect(component.currencyList).toEqual(currencyListMock);
    expect(component.selectedCurrencyCode).toEqual(currencyListMock[0].code);
  });

  it(`should return false if field is valid on calling isControlInvalid`, () => {
    const fieldName = 'opportunityName';
    component.createJobForm.get(fieldName).setErrors({ required: true });
    component.createJobForm.patchValue({ opportunityName: 'testOppy' });
    component.createJobForm.get(fieldName).markAsDirty();
    component.createJobForm.get(fieldName).markAsTouched();
    const isInvalid = component.isControlInvalid(fieldName);
    expect(isInvalid).toBe(false);
  });

  it(`should return true if field is inValid on calling isControlInvalid`, () => {
    const fieldName = 'opportunityName';
    component.createJobForm.patchValue({ opportunityName: null });
    component.createJobForm.get(fieldName).setErrors({ required: true });
    component.createJobForm.get(fieldName).markAsTouched();
    const isInvalid = component.isControlInvalid(fieldName);
    expect(isInvalid).toBe(true);
  });

  it(`should get salesOfficeSelectedValue and call fetchCommissionCodesList, setCurrencyList and fetchJobContactList on calling selectChangeHandler`, () => {
    const selectedVal = 447;
    component.salesOfficeList = testSalesOfficeList;
    const spyGetCommissionCodesList = spyOn(component, 'fetchCommissionCodesList').and.callThrough();
    const spyGetJobContactList = spyOn(component, 'fetchJobContactList').and.callThrough();
    const spySetCurrencyList = spyOn(component, 'setCurrencyList').and.callThrough();
    component.selectChangeHandler(selectedVal);
    expect(component.salesOfficeSelectedValue[0].salesOfficeId).toBe(447);
    expect(spyGetCommissionCodesList).toHaveBeenCalledWith(447);
    expect(spyGetJobContactList).toHaveBeenCalledWith(447);
    expect(spySetCurrencyList).toHaveBeenCalledWith(testSalesOfficeList[0].country);
    expect(component.selectedSalesOfficeCode).toEqual(testSalesOfficeList[0].salesOfficeCode);
  });

  it(`should set salesOfficeCode to selectedLocationOfficeCode for the selected salesOfficeId on calling onLocationChange`, () => {
    const selectedVal = 447;
    component.salesOfficeList = testSalesOfficeList;
    component.onLocationChange(selectedVal);
    expect(component.selectedLocationOfficeCode)
      .toEqual(testSalesOfficeList[0].salesOfficeCode);
  });

  it(`should set null to selectedLocationOfficeCode if selected salesOfficeId doesnot
   exist in salesOfficeList  on calling onLocationChange`, () => {
    const selectedVal = 7;
    component.salesOfficeList = testSalesOfficeList;
    component.onLocationChange(selectedVal);
    expect(component.selectedLocationOfficeCode).toBe(null);
  });

  it(`should return true if user selecting past date on calling isBeforeCurrentDate`, () => {
    expect(component.isBeforeCurrentDate(new Date('05/01/2020'))).toBe(true);
  });

  // it(`should return false if user selecting date greater than or equal to current date on calling isBeforeCurrentDate`, () => {
  //   expect(component.isBeforeCurrentDate(new Date())).toBe(false);
  // });
});
