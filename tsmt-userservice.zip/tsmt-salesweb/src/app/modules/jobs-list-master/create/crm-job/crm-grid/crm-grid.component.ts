import { GridFilterService } from './../../../services/grid-filter.service';
import { Component, EventEmitter, Input, OnInit, Output, OnChanges, SimpleChanges } from '@angular/core';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
import { State, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { PayloadModel } from '@tsmt/salesweb-jobsmodule/lib/models/job-summary-selection.model';
import { GridType } from './../../../models/create-crm.model';

export interface IFilterPayload {
  columnFilters: IFilter[];
  logic: string;
}
export interface IFilter {
  field: string;
  value: string;
  operator: string;
}


@Component({
  selector: 'app-crm-grid',
  templateUrl: './crm-grid.component.html',
  styleUrls: ['./crm-grid.component.scss'],
})
export class CrmGridComponent implements OnInit, OnChanges {

  @Input() public gridColumn: any[];
  @Input() public gridData: any[];
  @Input() public activeGrid: string;
  @Output() buildCompany: EventEmitter<any> = new EventEmitter();
  @Output() fetchSites: EventEmitter<any> = new EventEmitter();
  @Output() assignData: EventEmitter<any> = new EventEmitter();
  @Output() fetchContacts: EventEmitter<any> = new EventEmitter();
  @Output() removeContact: EventEmitter<any> = new EventEmitter();
  public payload: PayloadModel = {
    skip: 0,
    take: 50,
    sort: null,
    filters: [
      {
        ColumnFilters: [],
        logic: 'and',
      },
    ],
  };

  constructor(private gridFilterService: GridFilterService) { }
  public state: State = {
    // pagechange skip and take
    skip: 0,
    take: 15,
    sort: [],
    filter: {
      logic: 'and',
      filters: [],
    },
  };
  public buttonCount = 9;
  public type: 'numeric' | 'input' = 'numeric';
  public defaultPageSize = 15;
  public pageSizes = [15, 50, 75, 100, 150, 200];
  public previousNext = true;
  public searchValue: string;
  public isMasterGridActive: boolean;
  public isFilterable: boolean;
  @Input() public loading = false;
  @Input() public pageSize = this.defaultPageSize;

  ngOnInit(): void {
    this.isMasterGridActive = (this.activeGrid === GridType.CONTACT || this.activeGrid === GridType.SITE ||
      this.activeGrid === GridType.COMPANY);
    this.isFilterable = this.gridColumn?.some((col) => col.filter === true);
  }

  searchGrid(searchText: string): void {
    this.loading = true;
    const payload = this.buildFilterPayload();
    const searchEvent = { searchText, skip: this.state.skip, take: this.state.take, payload };
    if (this.activeGrid === GridType.SITE) {
      this.fetchSites.emit(searchEvent);
    } else if (this.activeGrid === GridType.CONTACT) {
      this.fetchContacts.emit(searchEvent);
    } else {
      this.buildCompany.emit(searchEvent);
    }
  }

  // function called when there is a filter is applied
  public filterChange(filter: CompositeFilterDescriptor): void {
    this.state.skip = 0;
    this.state.filter = filter;
    this.onApplyFilter();
  }

  ngOnChanges(change: SimpleChanges): void {
    if (change.gridData?.currentValue) {
      this.loading = false;
    }
  }

  onAssigning(index: number, dataItem: any): void {
    this.assignData.emit({ rowIndex: index, data: dataItem, type: this.activeGrid });
  }

  // create the filter payload from filter object
  buildFilterPayload(): PayloadModel {
    let colFilters = this.gridFilterService.modifyFilterObj(JSON.parse(JSON.stringify(this.state.filter.filters)));
    colFilters = this.formatPhoneNumber(colFilters);
    return this.payload = {
      skip: this.state.skip,
      take: this.state.take,
      sort: null,
      filters: colFilters,
    };
  }

  /**
   * function to format phone number from
   * (XXX) XXX-XXX to -XXX/XXX-XXX
   */
  formatPhoneNumber(filterObj: IFilterPayload[]): IFilterPayload[] {
    if (filterObj.length) {
      filterObj.forEach((obj) => {
        obj.columnFilters.forEach((element) => {
          if (element.field === 'phoneNumber' && element.value) {
            element.value = element.value.replace('(', '-').replace(')', '/').replace(/\s/g, '');
          }
        });
      });
    }
    return filterObj;
  }

  onApplyFilter(): void {
    this.loading = true;
    this.payload = this.buildFilterPayload();
    const searchEvent = { searchText: this.searchValue, skip: this.state.skip, take: this.state.take, payload: this.payload };
    this.buildCompany.emit(searchEvent);
  }

  primaryContact(index: number) {
    this.gridData.forEach((data) => {
      data.isPrimary = false;
    });
    this.gridData[index].isPrimary = true;
  }

  removeContacts(rowIndex: number): void {
    this.removeContact.emit(rowIndex);
  }

  clearSearch(): void {
    this.searchValue = '';
    this.state.skip = 0;
    this.state.take = this.defaultPageSize;
    this.searchGrid(this.searchValue);
  }

  onPageChange(event: PageChangeEvent): void {
    this.state.skip = event.skip;
    this.state.take = event.take;
    this.searchGrid(this.searchValue);
  }
}
