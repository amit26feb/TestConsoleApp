import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { ApiErrorService } from '../../../../../shared/services/apierror.service';
import { GlobalFilterService } from '../../../../../shared/services/global-filter.service';
import { JobHeaderService } from '../../../../../shared/services/job-header.service';
import { ICommCodeList, IJobContactModel, ISalesOfficeList } from '../../../modal/job-details-edit.model';
import { IOfficeSelectorModel } from '../../../modal/office-selector-model';
import { IClassification, IClassificationsCode, IRevenueStream, ICurrencyListModel } from '../../../models/create-crm.model';
import { TraneSalesBusinessDataService } from '../../../services/trane-sales-business-data.service';
import { AppConstants } from './../../../../../shared/constants/constants';

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss'],
})
export class GeneralComponent implements OnInit {
  createJobForm: FormGroup = new FormGroup({
    opportunityName: new FormControl('', Validators.required),
    salesOffice: new FormControl('', Validators.required),
    locationOffice: new FormControl('', Validators.required),
    salesPerson: new FormControl('', Validators.required),
    jobContact: new FormControl('', Validators.required),
    status: new FormControl('0', Validators.required),
    revenueStreamType: new FormControl('', Validators.required),
    revenueStream: new FormControl('', Validators.required),
    verticalMarket: new FormControl('', Validators.required),
    bodOnEquipment: new FormControl('', Validators.required),
    bodOnControls: new FormControl('', Validators.required),
    bookingDollar: new FormControl('', Validators.required),
    controlDollar: new FormControl('', { updateOn: 'change' }),
    controlsPercentage: new FormControl('', { updateOn: 'change' }),
    bookingDate: new FormControl('', Validators.required),
    bidDate: new FormControl(''),
    confidencePercentage: new FormControl('', Validators.required),
    currency: new FormControl('', Validators.required),
    businessUnit: new FormControl('TCS', Validators.required),
  });
  public currencyList: ICurrencyListModel[];
  public salesOfficeList: ISalesOfficeList[];
  public commissionCodeList: ICommCodeList[];
  public jobContactList: IJobContactModel[];
  public officeSelectorValue: number;
  public officeSelectorName: string;
  public salesOfficeSelectedValue: ISalesOfficeList[];
  public locationOfficeValue: number;
  public salesOfficeValue: number;
  public checkUser: boolean;
  public verticalMarketOptions: IClassificationsCode[];
  public bodOnEquipmentsOptions: IClassificationsCode[];
  public bodOnControlsOptions: IClassificationsCode[];
  public revenueStreamTypeOptions;
  public revenueStreamResponse;
  public filteredRevenue: IRevenueStream[];
  public selectedCurrencyCode: string;
  public readonly CURRENCY_FORMAT_OPTIONS = {
    currency: 'USD',
    currencyDisplay: 'symbol',
    style: 'currency',
  };
  public readonly CURRENCY_FORMAT_OPTIONS_CONTROLDOLLAR = {
    currency: 'USD',
    currencyDisplay: 'symbol',
    style: 'currency',
    minimumFractionDigits: 0
  };
  @Input() generalSectionData: IClassification[] = [];
  public selectedSalesOfficeCode: string;
  public selectedLocationOfficeCode: string;
  constructor(
    private traneSalesBusinessDataService: TraneSalesBusinessDataService,
    private apiErrorService: ApiErrorService,
    private jobHeaderService: JobHeaderService,
    private filterService: GlobalFilterService,
    private route: ActivatedRoute,
    private constants: AppConstants) { }

  ngOnInit(): void {
    this.officeSelectorValue = +this.route.snapshot.params['drAddressId'];
    this.fetchOfficeSelectorList();

    // Filtering options for vertical market which has class code id as 38
    this.verticalMarketOptions = this.generalSectionData.filter((data: IClassification) =>
      data.jobClassId === this.constants.VERTICAL_MARKET_CLASS_CODE)[0].codes;
    // Filtering options for BOD on equipments which has class code id as 108
    this.bodOnEquipmentsOptions = this.generalSectionData.filter((data: IClassification) =>
      data.jobClassId === this.constants.BOD_ON_EQUIPMENTS_CLASS_CODE)[0].codes;
    // Filtering options for BOD on controls which has class code id as 109
    this.bodOnControlsOptions = this.generalSectionData.filter((data: IClassification) =>
      data.jobClassId === this.constants.BOD_ON_CONTROLS_CLASS_CODE)[0].codes;
    this.revenueStreamTypeOptions = this.constants.REVENUE_DROP_DOWN;
    this.traneSalesBusinessDataService.getRevenueStream().subscribe((response: IRevenueStream[]) => {
      this.revenueStreamResponse = response;
    });
  }

  // get the office selector list from the filter service
  public fetchOfficeSelectorList(): void {
    this.filterService.getOfficeSelectorList().subscribe((response: IOfficeSelectorModel[]) => {
      // filter the officeSeletor Name based on the list from service and drAddressId in the route path
      this.officeSelectorName = response.filter((officeSelector) =>
        officeSelector.drAddressId === this.officeSelectorValue)[0].salesOfficeName;
      this.fetchSalesOffice();
    });
  }

  /**
   *  Disable the date which is before the current date
   */
  isBeforeCurrentDate = (date: Date): boolean => {
    return moment(date).isBefore(moment(new Date()));
  }

  public fetchSalesOffice(): void {
    this.traneSalesBusinessDataService.getSalesOffices().subscribe((response: ISalesOfficeList[]) => {
      if (response != null) {
        this.salesOfficeList = response;
        // set default sales office for sales office and location office dropdown
        const filterDefaultOffice: ISalesOfficeList[] = this.salesOfficeList.filter((salesOffice) =>
          salesOffice.salesOfficeName === this.officeSelectorName);
        const filterSalesOfficeId = filterDefaultOffice.length > 0 ? filterDefaultOffice[0].salesOfficeId : null;
        // assign filtered sales office id for salesOfficeValue and locationOfficeValue
        this.locationOfficeValue = filterSalesOfficeId;
        this.salesOfficeValue = filterSalesOfficeId;
        if (filterDefaultOffice.length > 0) {
          this.setCurrencyList(filterDefaultOffice[0].country);
          this.fetchCommissionCodesList(filterSalesOfficeId);
          this.fetchJobContactList(filterSalesOfficeId);
          this.selectedSalesOfficeCode = filterDefaultOffice[0].salesOfficeCode;
          this.selectedLocationOfficeCode = filterDefaultOffice[0].salesOfficeCode;
        }
      }
    },
      (err: HttpErrorResponse) => {
        this.apiErrorService.show(err.error.Message);
      });
  }

  onLocationChange(selectedLocationOfficeValue: number): void {
    const filterDefaultOffice = this.salesOfficeList.filter((salesOffice) =>
      salesOffice.salesOfficeId === Number(selectedLocationOfficeValue));
    this.selectedLocationOfficeCode = filterDefaultOffice.length > 0 ?
      filterDefaultOffice[0]?.salesOfficeCode : null;
  }

  selectChangeHandler(selectedSalesOfficeValue: number): void {
    // filter selected office details from salesOfficeList based on salesOfficeId
    this.salesOfficeSelectedValue = this.salesOfficeList.filter((salesOffice) =>
      salesOffice.salesOfficeId === Number(selectedSalesOfficeValue));
    this.commissionCodeList = this.jobContactList = [];
    if (this.salesOfficeSelectedValue.length !== 0) {
      this.fetchCommissionCodesList(this.salesOfficeSelectedValue[0].salesOfficeId);
      this.fetchJobContactList(this.salesOfficeSelectedValue[0].salesOfficeId);
      this.setCurrencyList(this.salesOfficeSelectedValue[0].country);
      this.selectedSalesOfficeCode = this.salesOfficeSelectedValue[0].salesOfficeCode;
    }
  }

  public fetchCommissionCodesList(salesOfficeId: number): void {
    this.traneSalesBusinessDataService.getCommissionCodes(salesOfficeId).subscribe((response: ICommCodeList[]) => {
      this.commissionCodeList = response;
    },
      (err: HttpErrorResponse) => {
        this.apiErrorService.show(err.error.Message);
      });
  }
  public fetchJobContactList(salesOfficeId: number): void {
    this.jobContactList = [];
    this.traneSalesBusinessDataService.getJobContacts(salesOfficeId).subscribe((response: IJobContactModel[]) => {
      if (response != null) {
        this.jobContactList = response;
        for (const jobContact of this.jobContactList) {
          if (jobContact['userId'] === this.jobHeaderService.getUserId()) {
            this.checkUser = true;
          }
        }
      }
      if (!this.checkUser) {
        const currentUserDetails: IJobContactModel = { userId: '', userName: '' };
        currentUserDetails['userId'] = this.jobHeaderService.getUserId();
        currentUserDetails['userName'] = this.jobHeaderService.getFullName();
        // add current user name in the job contact drop down
        this.jobContactList.unshift(currentUserDetails);
        this.checkUser = false;
      }
    },
      (err: HttpErrorResponse) => {
        this.apiErrorService.show(err.error.Message);
      });
  }

  validateFormControls(controlName: string, value: number): void {
    if ((controlName === 'bookingDollar' || controlName === 'controlDollar') && value === 0) {
      this.createJobForm.controls[controlName].setValue('');
    }
  }

  filterRevenueStream(selectedRevenueStream: string): void {
    if (selectedRevenueStream === this.revenueStreamTypeOptions[0].fieldValue) {
      this.filteredRevenue = this.revenueStreamResponse.filter((value) =>
        value.description.startsWith(this.revenueStreamTypeOptions[0].type) ||
        value.description.startsWith('IRIR'));
    } else if (selectedRevenueStream === this.revenueStreamTypeOptions[1].fieldValue) {
      this.filteredRevenue = this.revenueStreamResponse.filter((value) =>
        value.description.startsWith(this.revenueStreamTypeOptions[1].type));
    } else if (selectedRevenueStream === this.revenueStreamTypeOptions[2].fieldValue) {
      this.filteredRevenue = this.revenueStreamResponse.filter((value) =>
        value.description.startsWith(this.revenueStreamTypeOptions[2].type));
    }
  }

  // Required fields validation
  isControlInvalid(field: string): boolean {
    const control = this.createJobForm.get(field);
    return control.invalid && (control.dirty || control.touched);
  }

  /**
   * Function to set currency list and selected value for currency drop down based on country
   */
  public setCurrencyList(country: string): void {
    const currencyDropDownList = [{
      name: '$CAD',
      code: 'CANADA'
    }, {
      name: '$USD',
      code: 'COMMSALE'
    }] as ICurrencyListModel[];
    if (country === 'USA') {
      this.currencyList = [currencyDropDownList[1]];
      this.selectedCurrencyCode = currencyDropDownList[1].code;
    } else if (country === 'CAN') {
      this.currencyList = currencyDropDownList;
      this.selectedCurrencyCode = currencyDropDownList[0].code;
    }
  }
}
