import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { GroupCheckboxViewComponent, GroupSelectViewComponent, ToasterService } from '@tsmt/shared-core';
import { ApiErrorService } from '../../../../shared/services/apierror.service';
import { ICheckboxItem } from '@tsmt/shared-core/lib/models/checkbox-item';
import { ISelectItem, ISelectOption } from '@tsmt/shared-core/lib/models/select-item';
import { ISearchCustomerListModel, ISearchCustomerModel } from '../../modal/job-details-edit.model';
import { IClassification, IContact, IEarthwiseSystem, IProgram, ISaveCrmModel, ISearchSiteListModel, ISite } from '../../models/create-crm.model';
import { CompanyGridColumnEnum, ContactGridColumnEnum, CrmGridColumn, SiteGridColumnEnum } from '../../models/crm-grid-column.model';
import { CreateCrmService } from '../../services/create-crm.service';
import { SalesCustomerService } from '../../services/sales-customer.service';
import { SitesService } from '../../services/sites.service';
import { TraneSalesBusinessDataService } from '../../services/trane-sales-business-data.service';
import { AppConstants } from './../../../../shared/constants/constants';
import { GridType, ISearchContactListModel } from './../../models/create-crm.model';
import { GeneralComponent } from './general/general.component';
import { LoaderService } from '../../../../shared/services/loader.service';
import { JobRoleAsnView } from '@tsmt/salesweb-jobsdetailsmodule/lib/models/job-details-edit.model';
import { PayloadModel } from '@tsmt/salesweb-jobsmodule/lib/models/job-summary-selection.model';

@Component({
  selector: 'app-crm-job',
  templateUrl: './crm-job.component.html',
  styleUrls: ['./crm-job.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CrmJobComponent implements OnInit {

  constructor(
    private traneSalesBusinessDataService: TraneSalesBusinessDataService,
    private apiErrorService: ApiErrorService, public constants: AppConstants,
    private salesCustomerService: SalesCustomerService, private route: ActivatedRoute,
    private sitesService: SitesService, private createCrmService: CreateCrmService,
    public router: Router, private toasterService: ToasterService, public loaderService: LoaderService) { }

  public companyGridColumn: CrmGridColumn[] = [
    new CrmGridColumn('customerName', CompanyGridColumnEnum.companyName, true),
    new CrmGridColumn('crmCompanyId', CompanyGridColumnEnum.companyID, true),
    new CrmGridColumn('address', CompanyGridColumnEnum.address, true),
    new CrmGridColumn('phoneNumber', CompanyGridColumnEnum.phone, true)];
  public selectedCompanyGridColumn: CrmGridColumn[] = [
    new CrmGridColumn('customerName', CompanyGridColumnEnum.companyName),
    new CrmGridColumn('crmCompanyId', CompanyGridColumnEnum.companyID),
    new CrmGridColumn('address', CompanyGridColumnEnum.address),
    new CrmGridColumn('phoneNumber', CompanyGridColumnEnum.phone)];
  public companyGridData: GridDataResult;
  public contactGridColumn: CrmGridColumn[] = [
    new CrmGridColumn('lastName', ContactGridColumnEnum.lastName),
    new CrmGridColumn('firstName', ContactGridColumnEnum.firstName),
    new CrmGridColumn('custAcctNbr', ContactGridColumnEnum.accountNumber),
    new CrmGridColumn('companyName', ContactGridColumnEnum.companyName),
    new CrmGridColumn('salesOfficeName', ContactGridColumnEnum.office),
    new CrmGridColumn('phoneNumber', ContactGridColumnEnum.phone),
    new CrmGridColumn('emailAddress', ContactGridColumnEnum.email),
    new CrmGridColumn('address', ContactGridColumnEnum.address)];
  public siteGridColumn: CrmGridColumn[] = [
    new CrmGridColumn('siteName', SiteGridColumnEnum.siteName),
    new CrmGridColumn('companyName', SiteGridColumnEnum.companyName),
    new CrmGridColumn('address', SiteGridColumnEnum.address),
    new CrmGridColumn('phoneNumber', SiteGridColumnEnum.phone)];
  public contactGridData: GridDataResult;
  public siteGridData: GridDataResult;
  public companyData: ISearchCustomerModel[];
  public contactData: IContact[];
  public assignedContactGridData: IContact[] = [];
  public assignedSiteGridData: ISite[] = [];
  public assignedCompanyGridData: ISearchCustomerModel[] = [];
  public isNullCustomerAccountNumberRequired = 'true';
  public classifications: ISelectItem[];
  public showClassification: boolean;
  public showEarthwiseSystems: boolean;
  public earthwiseSystems: ICheckboxItem[] = [];
  public drAddressId: number;
  @ViewChild('checkBoxComponent') checkBoxComponent: GroupCheckboxViewComponent;
  @ViewChild(GeneralComponent) generalComponent: GeneralComponent;
  public generalSectionData = [];
  public showPrograms: boolean;
  public programs: ICheckboxItem[] = [];
  public warningMessage: string;
  public dialogOpened = false;
  public dialogAction = [];
  public dialogType: string;
  public isCompany = false;
  public rowIndex: number;
  public type: string;
  public siteGridPageSize = 15;
  public companyGridPageSize = 15;
  public contactGridPageSize = 15;
  public emptyGridData = {
    data: [],
    total: 0,
  };
  public isEarthwiseChecked: boolean;
  public saveCrmPayload: ISaveCrmModel;
  public jobRoleAsn: JobRoleAsnView;
  public showGridLoader = false;
  @ViewChild('classification') classification: GroupSelectViewComponent;

  ngOnInit(): void {
    this.drAddressId = +this.route.snapshot.params['drAddressId'];
    this.buildClassification();
    this.buildEarthwiseSystems();
    this.buildPrograms();
  }

  buildClassification(): void {
    this.traneSalesBusinessDataService.getClassifications().subscribe((res: IClassification[]) => {
      this.showClassification = true;
      const data = res.filter((classification: IClassification) => !this.constants.CRM_CLASSIFICATION_EXCLUDED_CLASSCODES
        .includes(classification.jobClassId));
      this.generalSectionData = res.filter((classification: IClassification) => this.constants.CRM_CLASSIFICATION_EXCLUDED_CLASSCODES
        .includes(classification.jobClassId));
      this.classifications = data.map((item) => {
        return {
          displayName: item.description,
          options: this.buildOption(item),
          selectedValue: '',
        };
      }) as ISelectItem[];
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  buildOption(item: IClassification): ISelectOption[] {
    const codes = item.codes.map((res) => {
      return {
        value: res.jobCodeId,
        description: res.description,
        selected: false,
      } as unknown as ISelectOption;
    });
    codes.push({
      value: '',
      description: 'None',
      selected: true,
    } as ISelectOption);
    return codes;
  }

  buildEarthwiseSystems(): void {
    this.traneSalesBusinessDataService.getEarthwiseSystems().subscribe((data: IEarthwiseSystem[]) => {
      if (data) {
        this.showEarthwiseSystems = true;
        this.earthwiseSystems = data.map((item) => {
          return {
            displayValue: item.description,
            value: item.systemTypeId.toString(),

            // By default 'No System' (system type id - 1) should be checked
            checked: item.systemTypeId === 1,
            helpMessage: item.toolTip,
          };
        }) as ICheckboxItem[];
      }
    }, (err) => {
      this.apiErrorService.show(err.error.messages);
    });
  }

  // Build company grid data
  buildCompany(event: { searchText: string; skip?: number; take?: number; payload?: PayloadModel }): void {
    this.showGridLoader = true;
    this.companyGridData = this.emptyGridData;
    event.searchText = event.searchText ?? '';
    const payload = {
      skip: event.skip,
      take: event.take,
      sort: event.payload?.sort,
      filters: event.payload?.filters
    };
    this.salesCustomerService.getSearchCustomers(event.skip, event.take, event.searchText,
      this.drAddressId, payload).subscribe((res: ISearchCustomerListModel) => {
        if (res != null) {
          this.companyData = JSON.parse(JSON.stringify(res.customerList));
          this.companyGridData = { data: res.customerList, total: res.totalItemCount };
          if (event.searchText) {
            this.companyGridData.data.forEach((company) => this.searchTextHighlight(company, event.searchText));
          }
          this.companyGridPageSize = res.pageSize;
        } else {
          this.companyGridData = this.emptyGridData;
          this.companyGridPageSize = 0;
        }
        this.showGridLoader = false;
      }, () => {
        this.showGridLoader = false;
        this.contactGridData = this.emptyGridData;
        this.companyGridPageSize = 0;
      });
  }

  checkEarthwiseNoSystem(checkboxItem: ICheckboxItem): void {
    const controls = ((this.checkBoxComponent.groupCheckboxForm.controls['groupCheckboxOptions']) as FormArray).controls;
    if (checkboxItem.value === '1') {
      controls.forEach((control) => {
        control.setValue(false);
      });
      controls[0].setValue(true);
      this.earthwiseSystems.forEach((item) => {
        item.checked = false;
      });
      this.earthwiseSystems[0].checked = true;
    } else {
      controls[0].setValue(false);
      this.earthwiseSystems[0].checked = false;
      this.checkSystem(this.earthwiseSystems, checkboxItem);
    }
  }

  checkProgramNoSystem(checkboxItem: ICheckboxItem): void {
    this.checkSystem(this.programs, checkboxItem);
  }

  checkSystem(checkedItems: ICheckboxItem[], checkboxItem: ICheckboxItem): void {
    checkedItems.forEach((item) => {
      if (item.value === checkboxItem.value) {
        item.checked = !checkboxItem.checked;
      }
    });
  }

  buildPrograms(): void {
    this.traneSalesBusinessDataService.getPrograms().subscribe((data: IProgram[]) => {
      if (data) {
        this.showPrograms = true;
        this.programs = data.map((item) => {
          return {
            displayValue: item.programDescription,
            value: item.programCode,
            checked: false,
          };
        }) as ICheckboxItem[];
      }
      this.loaderService.hide();
    }, (err: HttpErrorResponse) => {
      this.loaderService.hide();
      this.apiErrorService.show(err.error.messages);
    });
  }

  fetchSites(event: { searchText: string; skip?: number; take?: number; }): void {
    if (event.searchText) {
      this.sitesService.getCrmSites(this.drAddressId, event.skip, event.take,
        event.searchText, this.assignedCompanyGridData[0].crmCompanyId).subscribe((response: ISearchSiteListModel) => {
          response.sites.forEach((site) => {
            this.siteGridPageSize = response.pageSize;
            site.address = [site.streetAddress1, site.streetAddress2, site.streetAddress3, site.streetAddress4]
              .filter(Boolean).join(', ');
            this.searchTextHighlight(site, event.searchText);
          });
          this.siteGridData = { data: response.sites, total: response.totalItemCount };
        }, (err: HttpErrorResponse) => {
          this.apiErrorService.show(err.error.messages);
        });
    } else {
      this.siteGridData = this.emptyGridData;
    }
  }

  fetchContacts(event: { searchText: string; skip?: number; take?: number; }): void {
    this.contactGridData = this.emptyGridData;
    if (event.searchText) {
      this.salesCustomerService.getSearchContacts(event.skip, event.take, event.searchText,
        this.drAddressId).subscribe((res: ISearchContactListModel) => {
          if (res != null) {
            this.contactGridPageSize = res.pageSize;
            this.contactData = JSON.parse(JSON.stringify(res.contacts));
            res.contacts.forEach((contact) => {
              this.searchTextHighlight(contact, event.searchText);
            });
            this.contactGridData = { data: res.contacts, total: res.totalItemCount };
          }
        });
    }
  }

  public searchTextHighlight(gridData: ISearchCustomerModel | ISite | IContact, searchText: string): void {
    for (const key in gridData) {
      if (gridData.hasOwnProperty(key)) {
        gridData[key] = gridData[key] !== null ? gridData[key].toString() : '';
        const jobText = gridData[key].toLowerCase();
        let index = jobText.indexOf(searchText.toLowerCase(), 0);
        while (index !== -1) {
          gridData[key] = gridData[key].slice(0, index) + '<em>' + gridData[key].slice(index, index + searchText.length) +
            '</em>' + gridData[key].slice(index + searchText.length);
          index = gridData[key].indexOf(searchText, index + 9);
        }
      }
    }
  }

  /**called when user try to assign company/site/contact
   * @returns void
   * @param rowIndex {number}- row index of the data which user tries to assign
   * @param data - ISearchCustomerModel / ISite / IContact based on the active grid
   * @param type {string} - takes value as company / site / contact based on grid
   */
  assignData(event: { rowIndex: number; data: any; type: string; }): void {
    this.rowIndex = event.rowIndex;
    this.type = event.type;
    this.dialogAction = ['no', 'yes'];
    this.dialogType = 'confirm';
    switch (event.type) {
      case GridType.CONTACT: {
        if (!this.assignedContactGridData.some((el) => el.contactId.toString() === event.data.contactId)) {
          this.assignedContactGridData.push(this.contactData[event.rowIndex % this.contactGridPageSize]);
        } else {
          this.dialogOpened = true;
          this.dialogAction = ['OK'];
          this.dialogType = 'info';
          this.warningMessage = 'The selected contact has been already added';
        }
        if (this.assignedContactGridData.length === 1) {
          this.assignedContactGridData[0].isPrimary = true;
        }
        break;
      }
      case GridType.SITE: {
        if (this.assignedSiteGridData.length === 0) {
          this.assignedSiteGridData.push(this.siteGridData.data[event.rowIndex % this.companyGridPageSize]);
        } else {
          this.dialogOpened = true;
          this.warningMessage = 'The site has been already selected.Do you want to replace the selected site?';
        }
        break;
      } case GridType.COMPANY: {
        this.isCompany = true;
        if (this.assignedCompanyGridData.length === 0) {
          this.assignedCompanyGridData.push(this.companyData[event.rowIndex % this.companyGridPageSize]);
        } else {
          this.dialogOpened = true;
          this.warningMessage = 'The company has been already selected.Do you want to replace the selected company?';
        }
        break;
      }
    }
  }

  removeContact(rowIndex: number): void {
    this.assignedContactGridData = this.assignedContactGridData.filter((val) => val.contactId !== rowIndex);
  }

  deleteAndAssignData(): void {
    if (this.type === GridType.COMPANY) {
      this.assignedCompanyGridData = [];
      this.assignedCompanyGridData.push(this.companyGridData.data[this.rowIndex % this.companyGridPageSize]);
    } else if (this.type === GridType.SITE) {
      this.assignedSiteGridData = [];
      this.assignedSiteGridData.push(this.siteGridData.data[this.rowIndex % this.siteGridPageSize]);
    }
    this.dialogOpened = false;
  }

  onCancel(): void {
    window.close();
  }

  onSave(): void {
    this.checkEarthwiseSystemChecked();
    this.generalComponent.createJobForm.markAllAsTouched();
    if (this.generalComponent.createJobForm.valid && this.assignedContactGridData.length > 0 && this.assignedCompanyGridData.length > 0
      && this.isEarthwiseChecked) {
      this.loaderService.show();
      this.saveCrmPayload = {
        opportunityName: this.generalComponent.createJobForm.controls['opportunityName'].value,
        status: this.generalComponent.createJobForm.controls['status'].value,
        businessUnit: this.generalComponent.createJobForm.controls['businessUnit'].value,
        company: this.assignedCompanyGridData[0].crmCompanyId,
        office: this.generalComponent.selectedSalesOfficeCode,
        commCode: this.generalComponent.createJobForm.controls['salesPerson'].value,
        salesOfficeId: this.generalComponent.createJobForm.controls['salesOffice'].value,
        location: this.generalComponent.selectedLocationOfficeCode,
        salesProcess: this.generalComponent.createJobForm.controls['revenueStreamType'].value,
        parentIndustryVerticalMarket: this.generalComponent.createJobForm.controls['verticalMarket'].value,
        totalBooking: this.generalComponent.createJobForm.controls['bookingDollar'].value,
        currency: this.generalComponent.createJobForm.controls['currency'].value === 'COMMSALE' ? 'USD' : 'CAD',
        overallConf: this.generalComponent.createJobForm.controls['confidencePercentage'].value,
        bookingDate: this.generalComponent.createJobForm.controls['bookingDate'].value,
        revenueStream: this.generalComponent.createJobForm.controls['revenueStream'].value,
        totalControls: this.generalComponent.createJobForm.controls['controlDollar'].value,
        controlsConf: this.generalComponent.createJobForm.controls['controlsPercentage'].value,
        bidDate: this.generalComponent.createJobForm.controls['bidDate'].value,
        boDOnEquipment: this.generalComponent.createJobForm.controls['bodOnEquipment'].value,
        boDOnControls: this.generalComponent.createJobForm.controls['bodOnControls'].value,
        extensibleAttributes: {
          attribute: [{
            name: '',
            value: ''
          }]
        },
        priorCode: [],
        programCode: [],
        site: [],
        contact: [],
        jobContact: this.generalComponent.createJobForm.controls['jobContact'].value,
        foe2CreatedOrdersInd: 'Y',
        cplpafLocked: 0,
        checkedIn: 'Y',
        locationOfficeId: this.generalComponent.createJobForm.controls['locationOffice'].value,
        verticalMarketJobCodeId: 0,
        jobRoleAsnViews: null,
        classifications: this.setClassifications()
      };
      this.earthwiseSystems.forEach((item) => {
        if (item.checked) {
          this.saveCrmPayload.priorCode.push({ system: item.value });
        }
      });
      this.programs.forEach((item) => {
        if (item.checked) {
          this.saveCrmPayload.programCode.push({ program: item.value });
        }
      });
      this.setPayload();
      const selectedVerticalMarket = this.generalComponent.verticalMarketOptions.find((x) =>
        x.jobCode === this.saveCrmPayload.parentIndustryVerticalMarket);
      this.saveCrmPayload.verticalMarketJobCodeId = selectedVerticalMarket ? selectedVerticalMarket.jobCodeId : 0;
      this.saveCrmPayload.contact = this.assignedContactGridData.map((item) => {
        return {
          contactId: item.crmContactId,
          primaryFlag: item.isPrimary ? 'Y' : 'N'
        };
      });
      this.createCrmJob();
    } else {
      this.toasterService.setToaster('error', 'Please enter all the required fields');
    }
  }

  createCrmJob(): void {
    this.createCrmService.createCrmJob(this.drAddressId, this.saveCrmPayload).subscribe((jobId: number) => {
      if (jobId > 0) {
        this.loaderService.hide();
        this.router.navigate(['jobs-list', jobId, this.drAddressId, 'configure']);
      }
    }, (err) => {
      this.loaderService.hide();
      window.scrollTo(0, 0);
      this.apiErrorService.show(err.error.messages);
    });
  }

  checkEarthwiseSystemChecked(): void {
    this.earthwiseSystems.forEach((item) => {
      if (item.checked) {
        this.isEarthwiseChecked = true;
      }
    });
  }

  /**  To set the selected classification section data for save
   * @returns ISelectOption
   */
  setClassifications(): ISelectOption[] {
    const selectedClassifications = [];
    const selectedValues = this.classification.groupSelectForm.value.groupSelectFormControls;
    for (let i = 0; i < selectedValues.length; i++) {
      if (selectedValues[i] != null) {
        const option = this.classifications[i].options;
        for (const element of option) {
          if (selectedValues[i].toString() === element.value.toString()) {
            element.selected = true;
            selectedClassifications.push(element);
          }
        }
      }
    }
    // On job creation should pre-populate 'Transitional Job' class value to 'Yes'(Job code for 'Yes' is 76)
    selectedClassifications.push({
      value: this.constants.DEFAULT_CLASSIFICATION_TRANSITIONAL_JOB_CODE_ID,
      description: this.constants.DEFAULT_CLASSIFICATION_TRANSITIONAL_DESCRIPTION,
      selected: true
    });
    return selectedClassifications;
  }

  setPayload(): void {
    let jobRoleAsnName = null;
    const companyData = this.assignedCompanyGridData[0];
    this.saveCrmPayload.jobRoleAsnViews = this.assignedContactGridData.map((item) => {
      jobRoleAsnName = null;
      if (item.firstName != null && item.lastName != null) {
        jobRoleAsnName = item.firstName + ' ' + item.lastName;
      } else if (item.firstName != null) {
        jobRoleAsnName = item.firstName;
      } else if (item.lastName != null) {
        jobRoleAsnName = item.lastName;
      }
      return {
        jobRoleAsnId: 0,
        jobId: 0,
        jobRoleTypeId: 0,
        custAcctNbr: item.custAcctNbr,
        salesCustomerName: item.companyName,
        salesCustId: item.salesCustId,
        hostUpdateInd: null,
        insertDate: new Date(),
        bidderInd: null,
        winningBidderInd: null,
        name: jobRoleAsnName,
        phoneNbr: item.phoneNumber,
        faxNbr: null,
        phoneExtension: null,
        isJobRoleSelected: false,
        jobRoleContactId: 0,
      };
    });
    jobRoleAsnName = null;
    if (companyData.firstName != null && companyData.lastName != null) {
      jobRoleAsnName = companyData.firstName + ' ' + companyData.lastName;
    } else if (companyData.firstName != null) {
      jobRoleAsnName = companyData.firstName;
    } else if (companyData.lastName != null) {
      jobRoleAsnName = companyData.lastName;
    }
    this.saveCrmPayload.jobRoleAsnViews.push({
      jobRoleAsnId: 0,
      jobId: 0,
      jobRoleTypeId: 0,
      custAcctNbr: companyData.custAcctNbr,
      salesCustomerName: companyData.customerName,
      salesCustId: companyData.salesCustId,
      hostUpdateInd: null,
      insertDate: new Date(),
      bidderInd: null,
      winningBidderInd: null,
      name: jobRoleAsnName,
      phoneNbr: companyData.contactPhoneNumber,
      faxNbr: companyData.contactFaxNumber,
      phoneExtension: companyData.contactPhoneExtension,
      isJobRoleSelected: false,
      jobRoleContactId: 0,
    });
  }
}
