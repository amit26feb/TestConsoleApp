import { GridFilterService } from './../../../services/grid-filter.service';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
import { GridType } from './../../../models/create-crm.model';

import { CrmGridComponent, IFilterPayload } from './crm-grid.component';

describe('CrmGridComponent', () => {
  let component: CrmGridComponent;
  let fixture: ComponentFixture<CrmGridComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [CrmGridComponent],
      providers: [GridFilterService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrmGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set isMasterGridActive and isFilterable on calling ngOninit', () => {
    component.activeGrid = GridType.CONTACT;
    component.gridColumn = [{
      filter: true,
    }];
    component.ngOnInit();
    expect(component.isMasterGridActive).toBe(true);
    expect(component.isFilterable).toBe(true);
  });

  it('should emit fetchSites to bind site data in grid on calling searchGrid when active grid is site', () => {
    const spySite = spyOn(component.fetchSites, 'emit');
    component.activeGrid = GridType.SITE;
    component.searchGrid('searchtext');
    expect(component.loading).toBe(true);
    expect(spySite).toHaveBeenCalledWith({
      searchText: 'searchtext', skip: 0, take: 15,
      payload: { skip: 0, take: 15, sort: null, filters: [] }
    });
  });

  it('should emit buildCompany to bind company data in grid on calling searchGrid when active grid is company', () => {
    const spyCompany = spyOn(component.buildCompany, 'emit');
    component.activeGrid = GridType.COMPANY;
    component.searchGrid('searchtext');
    expect(spyCompany).toHaveBeenCalledWith({
      searchText: 'searchtext', skip: 0, take: 15,
      payload: { skip: 0, take: 15, sort: null, filters: [] }
    });
  });

  it('should emit fetchContacts to bind company data in grid on calling searchGrid when active grid is contact', () => {
    const spyContact = spyOn(component.fetchContacts, 'emit');
    component.activeGrid = GridType.CONTACT;
    component.searchGrid('searchtext');
    expect(spyContact).toHaveBeenCalledWith({
      searchText: 'searchtext', skip: 0, take: 15,
      payload: { skip: 0, take: 15, sort: null, filters: [] }
    });
  });

  it('should emit assignData method on calling onAssigning', () => {
    const spyAssignData = spyOn(component.assignData, 'emit');
    component.activeGrid = GridType.SITE;
    const dataItem = {};
    const rowIndex = 1;
    component.onAssigning(rowIndex, dataItem);
    expect(spyAssignData).toHaveBeenCalledWith({ rowIndex: 1, data: dataItem, type: 'Site' });
  });

  it('should emit removeContact method on calling removeContacts', () => {
    const spyRemoveContact = spyOn(component.removeContact, 'emit');
    const rowIndex = 1;
    component.removeContacts(rowIndex);
    expect(spyRemoveContact).toHaveBeenCalledWith(rowIndex);
  });

  it('should set searchText as empty on calling clearSearch', () => {
    const spy = spyOn(component, 'searchGrid');
    component.clearSearch();
    expect(component.searchValue).toBe('');
    expect(spy).toHaveBeenCalledWith('');
    expect(component.state.skip).toBe(0);
    expect(component.state.take).toBe(15);
  });

  it('should set skip and take value on calling onPageChange', () => {
    const spy = spyOn(component, 'searchGrid');
    component.searchValue = 'test';
    const event: PageChangeEvent = { skip: 15, take: 30 };
    component.onPageChange(event);
    expect(spy).toHaveBeenCalledWith('test');
    expect(component.state.skip).toBe(15);
    expect(component.state.take).toBe(30);
  });

  it('should set isPrimary to true for the given row index on calling  primaryContact', () => {
    const rowIndex = 0;
    component.gridData = [
      {
        contactId: 4536,
        isPrimary: false
      },
      {
        contactId: 1234,
        isPrimary: true
      }
    ];
    component.primaryContact(rowIndex);
    expect(component.gridData[rowIndex].isPrimary).toEqual(true);
    expect(component.gridData[1].isPrimary).toEqual(false);
  });

  it('should set skip to  0 and call onApplyFilter on calling filterChange', () => {
    component.state.skip = 10;
    spyOn(component, 'onApplyFilter');
    component.filterChange({ filters: [], logic: 'or' });
    expect(component.state.skip).toEqual(0);
    expect(component.onApplyFilter).toHaveBeenCalled();
  });

  it('should set loading to false when ngOnchanges has gridData currentValue', () => {
    component.loading = true;
    component.ngOnChanges({ gridData: { currentValue: [], previousValue: [], isFirstChange: null, firstChange: null } });
    expect(component.loading).toBe(false);
  });

  it('should return payload on calling buildFilterPayload', () => {
    const nameFilter = { field: 'name', operator: 'contains', value: 'test' };
    component.state = {
      skip: 10,
      take: 15,
      sort: [],
      filter: { filters: [nameFilter], logic: 'and' }
    };
    const payload = component.buildFilterPayload();
    expect(payload.skip).toEqual(component.state.skip);
    expect(payload.take).toEqual(component.state.take);
    expect(payload.filters.length).toEqual(1);
  });

  it('should set loading to true and called buildCompany on calling on onApplyFilter', () => {
    component.loading = false;
    component.searchValue = 'test';
    component.state = {
      skip: 10,
      take: 10,
      filter: { filters: [], logic: 'or' }
    };
    component.payload = {
      skip: 10,
      take: 10,
      sort: null,
      filters: []
    };
    spyOn(component.buildCompany, 'emit');
    component.onApplyFilter();
    const searchEvent = {
      searchText: component.searchValue, skip: component.state.skip,
      take: component.state.take, payload: component.payload
    };
    expect(component.loading).toBe(true);
    expect(component.buildCompany.emit).toHaveBeenCalledWith(searchEvent);
  });

  it('should format phoneNumber on calling formatPhoneNumber', () => {
    const phoneFilter: IFilterPayload[] =
      [{ columnFilters: [{ field: 'phoneNumber', value: ' (234) 123  -345', operator: 'contains' }], logic: 'and' }];
    component.formatPhoneNumber(phoneFilter);
    const formattedPhoneNumber = phoneFilter[0].columnFilters[0]['value'];
    expect(formattedPhoneNumber).toEqual('-234/123-345');
  });

  it('should format phoneNumber(remove spaces) on calling formatPhoneNumber', () => {
    const phoneFilterWithSpaces: IFilterPayload[] =
      [{ columnFilters: [{ field: 'phoneNumber', value: ' 234 123  -345', operator: 'contains' }], logic: 'and' }];
    component.formatPhoneNumber(phoneFilterWithSpaces);
    const formattedPhoneNumber = phoneFilterWithSpaces[0].columnFilters[0]['value'];
    expect(formattedPhoneNumber).toEqual('234123-345');
  });

  it('should not format phoneNumber on calling formatPhoneNumber', () => {
    const phoneFilterWithSpaces: IFilterPayload[] =
      [{ columnFilters: [{ field: 'phoneNumber', value: null, operator: 'contains' }], logic: 'and' }];
    component.formatPhoneNumber(phoneFilterWithSpaces);
    const formattedPhoneNumber = phoneFilterWithSpaces[0].columnFilters[0]['value'];
    expect(formattedPhoneNumber).toBeNull();
  });

});
