import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { ApiErrorService } from '../../../../shared/services/apierror.service';
import { GlobalFilterService } from '../../../../shared/services/global-filter.service';
import { JobHeaderService } from '../../../../shared/services/job-header.service';
import { LoaderService } from '../../../../shared/services/loader.service';
import { JobsServicesService } from '../../services/jobs-services.service';
import { TraneSalesBusinessDataService } from '../../services/trane-sales-business-data.service';

@Component({
  selector: 'app-non-crm-job',
  templateUrl: './non-crm-job.component.html',
  styleUrls: ['./non-crm-job.component.scss'],
})
export class CreateJobComponent implements OnInit {
  submitted = false;
  dialogOpened = false;
  createJobForm: FormGroup;
  public salesOfficeList: any[];
  public commissionCodeList: any[];
  public jobContactList: any[];
  public countryList: any[];
  public officeSelectorList = [];
  createParam: any;
  checkUser: boolean;
  public userlist: any = { userId: '', userName: '' };
  salesOfficeSelectedValue: any;
  public officeSelected: string;
  selectedValue: string;
  public officeSelectorName: string;
  officeSelectorValue: number;
  locationOfficeValue: any;
  salesOfficeValue: any;
  @Output() close: EventEmitter<any> = new EventEmitter();

  constructor(public router: Router, public route: ActivatedRoute,
    public jobListService: JobsServicesService, public loaderService: LoaderService,
    public filterService: GlobalFilterService, public domainService: TraneSalesBusinessDataService,
    public jobHeaderService: JobHeaderService, public apiErrorService: ApiErrorService, public titleService: Title) { }

  ngOnInit() {
    this.titleService.setTitle('Create New Job');
    this.createJobForm = new FormGroup({
      jobName: new FormControl('', [
        Validators.required,
      ]),
      salesOffice: new FormControl('', Validators.required),
      locationOffice: new FormControl('', Validators.required),
      commissionCode: new FormControl('', Validators.required),
      jobContact: new FormControl('', Validators.required),
      currency: new FormControl('', Validators.required),
      status: new FormControl(),
      bidDate: new FormControl(new Date(moment().add(30, 'days').toString())),
    });

    this.getSalesOffice();
    this.officeSelectorValue = +this.route.snapshot.params['drAddressId'];
    // get the office selector list from the filter service
    this.filterService.getOfficeSelectorList().subscribe((data) => {
      // filter the officeSeletor Name based on the list from service and drAddressId in the route path
      this.officeSelectorList = data;
      this.officeSelectorName = data.filter((officeSelector) =>
        officeSelector.drAddressId === this.officeSelectorValue)[0].salesOfficeName;

    });
  }

  public getSalesOffice(): void {
    this.domainService.getSalesOffices().subscribe((data) => {
      this.salesOfficeList = data;
      // set default sales office for sales office and location office dropdown
      const filterDefaultOffice = this.salesOfficeList.filter((x) => x.salesOfficeName === this.officeSelectorName);
      const filterSalesOfficeId = filterDefaultOffice.length > 0 ? filterDefaultOffice[0].salesOfficeId : '';
      const filterSalesOfficeCountry = filterDefaultOffice.length > 0 ? filterDefaultOffice[0].country : '';
      // assign filtered sales office id for salesOfficeValue and locationOfficeValue
      this.locationOfficeValue = filterSalesOfficeId;
      this.salesOfficeValue = filterSalesOfficeId;
      if (this.salesOfficeList.length > 0) {
        this.getCommissionCodesList(filterSalesOfficeId);
        this.getJobContactList(filterSalesOfficeId);
        this.getJCurrencyList(filterSalesOfficeCountry);
        this.loaderService.hide();
      }
    },
      (err) => {
        this.loaderService.hide();
        this.apiErrorService.show(err.error.Message);
      });
  }

  selectChangeHandler($event, selectedSalesOfficeValue) {
    // filter selected office details from salesOfficeList based on salesOfficeId
    this.salesOfficeSelectedValue = this.salesOfficeList.filter((x) => x.salesOfficeId === Number(selectedSalesOfficeValue));
    this.commissionCodeList = this.jobContactList = [];
    if (this.salesOfficeSelectedValue.length !== 0) {
      this.getCommissionCodesList(this.salesOfficeSelectedValue[0].salesOfficeId);
      this.getJobContactList(this.salesOfficeSelectedValue[0].salesOfficeId);
      this.getJCurrencyList(this.salesOfficeSelectedValue[0].country);
    }
  }

  public getCommissionCodesList(salesOfficeId): void {
    this.domainService.getCommissionCodes(salesOfficeId).subscribe((data) => {
      this.commissionCodeList = data;
    },
      (err) => {
        this.loaderService.hide();
        this.apiErrorService.show(err.error.Message);
      });
  }
  public getJobContactList(salesOfficeId): void {
    this.jobContactList = [];
    this.domainService.getJobContacts(salesOfficeId).subscribe((data) => {
      if (data != null) {
        this.jobContactList = data;
        for (const val of data) {
          if (val['userId'] === this.jobHeaderService.getUserId()) {
            this.checkUser = true;
          }
        }
      }
      if (!this.checkUser) {
        this.userlist['userId'] = this.jobHeaderService.getUserId();
        this.userlist['userName'] = this.jobHeaderService.getFullName();
        this.jobContactList.unshift(this.userlist);
        this.checkUser = false;
      }
    },
      (err) => {
        this.loaderService.hide();
        this.apiErrorService.show(err.error.Message);
      });
  }

  public getJCurrencyList(country): void {
    if (country === 'USA') {
      this.countryList = [{ name: '$USD', code: 'COMMSALE' }];
      this.selectedValue = 'COMMSALE';
    } else if (country === 'CAN') {
      this.countryList = [{ name: '$CAD', code: 'CANADA' }, { name: '$USD', code: 'COMMSALE' }];
      this.selectedValue = 'CANADA';
    }
  }

  onSave() {
    this.submitted = true;
    for (const key in this.createJobForm.controls) {
      if (this.createJobForm.controls.hasOwnProperty(key)) {
        this.createJobForm.controls[key].markAsTouched();
      }
    }

    this.salesOfficeSelectedValue = this.createJobForm.value.salesOffice;
    if (this.createJobForm.valid) {
      this.loaderService.show();
      this.createParam = {
        jobId: 0,
        drAddressId: this.officeSelectorValue,
        jobName: this.createJobForm.value.jobName,
        locationOffice: parseInt(this.createJobForm.value.locationOffice, 10),
        dateCreated: null,
        commCode: this.createJobForm.value.commissionCode,
        custChannelId: this.selectedValue,
        status: 'P',
        checkedIn: 'Y',
        lastUpdate: null,
        cplpafLocked: 0,
        salesOfficeId: this.salesOfficeSelectedValue,
        cjWho: null,
        hqtrJobId: null,
        watcomJobId: null,
        province: null,
        nonUsPostalCode: null,
        priceAuthId: null,
        cjDate: null,
        cjTime: null,
        bidDate: this.createJobForm.value.bidDate == null ? new Date(moment().add(30, 'days').toString())
          : this.createJobForm.value.bidDate,
        city: null,
        county: null,
        distanceToJob: null,
        lostToCompetitor: null,
        pricingSpaNbr: null,
        readOnlyPassword: null,
        readWritePassword: null,
        streetAddress1: null,
        streetAddress2: null,
        state: null,
        zipCode: null,
        zipPlus: null,
        userId: 'lamsp',
        jobSource: null,
        originatingDrAddress: null,
        country: this.selectedValue === 'COMMSALE' ? 'USA' : 'CAN',
        cjSubmitDate: null,
        domesticInternationlInd: this.selectedValue === 'COMMSALE' ? 'D' : 'I',
        standaloneInd: null,
        jobPath: null,
        statusChangeDate: null,
        hostUserId: null,
        priceProtectionPeriod: null,
        insertDate: new Date(),
        jobContact: this.createJobForm.value.jobContact,
        foe2CreatedOrdersInd: 'Y',
        tcsJobInd: null,
        coordinatedYesNoInd: null,
        crmOppurtunityId: null,
        includeCjperfInd: null,
        jobNameAddOn: null,
        crmSalesRepId: null,
        pendingOrderInd: null,
        totalCommittedDollarsLocal: null,
        totalReleasedDollarsLocal: null,
        totalCommittedDollarsHost: null,
        totalReleasedDollarsHost: null,
        totalShippedDollarsHost: null,
        archiveDeleteInd: null,
        archiveDeleteUserId: null,
        archiveDeleteDate: null,
        lastShippingInstructionId: null,
        crmOppurtunityLinkId: null,
        refreshOrdersRequiredDate: null,
        estimatedRevenue: null,
        falloutReason: null,
        crmPrimaryJobInd: null,
        dateCosted: null,
        tcpnNbr: null,
        tcpnContractNbr: null,
        crmTcJobSeqNbr: null,
        sellingPrice: '',
        nameFirst: '',
        nameLast: '',
        userName: '',
        CrmOpportunityId: null,
      };
      this.jobListService.CreateJob(this.createParam).subscribe((data) => {
        this.loaderService.hide();
        this.router.navigate(['jobs-list', data, this.officeSelectorValue, 'details']);
      }, (err) => {
        this.loaderService.hide();
        this.apiErrorService.show(err.error.messages);
      });
    }
  }

  onCancel() {
    window.close();
  }
  closeDialog() {
    this.dialogOpened = false;
  }

  public dialogAction(status) {
    if (status === 'yes') {
      this.close.emit(true);
    } else if (status === 'no') {
      this.dialogOpened = false;
    }
  }

  emptySpaceLengthCheck(event) {
    if (event.target.value.trim().length === 0) {
      this.createJobForm.controls['jobName'].reset();
    }
  }
}
