import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, getTestBed, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { SharedModule } from '../../../../shared/modules/shared/shared.module';
import { ApiErrorService } from '../../../../shared/services/apierror.service';
import { CommonService as CommonServiceService } from '@tsmt/shared-core-salesweb';
import { GlobalFilterService } from '../../../../shared/services/global-filter.service';
import { JobHeaderService } from '../../../../shared/services/job-header.service';
import { LoaderService } from '../../../../shared/services/loader.service';
import { ApiErrorServiceMock } from '../../../../shared/test-mocks/apierrorservice-mock';
import { CommonServiceMock } from '../../../../shared/test-mocks/commonservice-mock';
import { FilterServiceMock } from '../../../../shared/test-mocks/filterservice-mock';
import { JobListServiceMock } from '../../../../shared/test-mocks/jobService-mock';
import { LoaderServiceMock } from '../../../../shared/test-mocks/loaderService-mock';
import { RouterMock } from '../../../../shared/test-mocks/routerMock';
import { TraneSalesBusinessDataServiceMock } from '../../../../shared/test-mocks/tranesalesbusinessdata-mock';
import { JobsServicesService } from '../../services/jobs-services.service';
import { TraneSalesBusinessDataService } from '../../services/trane-sales-business-data.service';
import { CreateJobComponent } from './non-crm-job.component';


// tslint:disable-next-line:no-big-function
describe('CreateJobComponent', () => {
  let component: CreateJobComponent;
  let fixture: ComponentFixture<CreateJobComponent>;
  let service: JobsServicesService;
  let fService: GlobalFilterService;
  let domainService: TraneSalesBusinessDataService;
  let injector: TestBed;
  let headerService: JobHeaderService;
  let apiErrorService: ApiErrorService;
  const originReset = TestBed.resetTestingModule;
  const serverErrorMessage = 'server error';
  const name = 'Christianson, Jaimie';

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [SharedModule, ReactiveFormsModule, GridModule,
        BrowserAnimationsModule, DropDownsModule, DatePickerModule],
      declarations: [CreateJobComponent],
      providers: [
        { provide: CommonServiceService, useClass: CommonServiceMock },
        { provide: JobsServicesService, useClass: JobListServiceMock },
        { provide: TraneSalesBusinessDataService, useClass: TraneSalesBusinessDataServiceMock },
        { provide: GlobalFilterService, useClass: FilterServiceMock },
        { provide: LoaderService, useClass: LoaderServiceMock },
        { provide: ApiErrorService, useClass: ApiErrorServiceMock },
        { provide: Router, useClass: RouterMock },
        {
          provide: ActivatedRoute, useValue: {
            snapshot: { params: { jobId: 12, drAddressId: 121 } },
            fragment: Observable.of('test'),
          },
        },
        JobHeaderService,

      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
    injector = getTestBed();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateJobComponent);
    component = fixture.componentInstance;
    service = injector.inject(JobsServicesService);
    fService = injector.inject(GlobalFilterService);
    headerService = injector.inject(JobHeaderService);
    domainService = injector.inject(TraneSalesBusinessDataService);
    apiErrorService = injector.inject(ApiErrorService);
    component.createJobForm = new FormGroup({
      jobName: new FormControl('', Validators.required),
      salesOffice: new FormControl('', Validators.required),
      locationOffice: new FormControl('', Validators.required),
      commissionCode: new FormControl('', Validators.required),
      jobContact: new FormControl('', Validators.required),
      currency: new FormControl('', Validators.required),
      status: new FormControl(),
      bidDate: new FormControl(new Date()),
    });
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create Component', () => {
    expect(component).toBeTruthy();
  });
  it(`should set dialogOpened to true if formupdated is equal
      to true on call of oncancel()`, () => {
    const spy = spyOn(window, 'close');
    component.onCancel();
    expect(spy).toHaveBeenCalled();
  });
  it(`should set dialogOpened to false  on call of closeDialog()`, () => {
    component.closeDialog();
    expect(component.dialogOpened).toBeFalsy();
  });
  it(`should set dialogOpened to false and emitter is called if status is equal
      to yes on call of dialogAction()`, () => {
    component.dialogAction('yes');
    expect(component.dialogOpened).toBeFalsy();
    expect(component.close.emit).toBeDefined();
    component.dialogAction('no');
    expect(component.dialogOpened).toBeFalsy();
    component.dialogAction('');
    expect(component.dialogOpened).toBeFalsy();
  });

  it(`should assign response from the server to commissionCodeList on calling getSalesOffice or throw error`, () => {
    const spy = spyOn(domainService, 'getSalesOffices').and.returnValue(Observable.of([1, 2]));
    spyOn(component, 'getCommissionCodesList');
    spyOn(component, 'getJobContactList');
    spyOn(component, 'getJCurrencyList');
    component.getSalesOffice();
    expect(component.salesOfficeList).toEqual([1, 2]);
    expect(component.getCommissionCodesList).toHaveBeenCalled();
    expect(component.getJobContactList).toHaveBeenCalled();
    expect(component.getJCurrencyList).toHaveBeenCalled();

    expect(spy).toHaveBeenCalled();
    spyOn(apiErrorService, 'show').and.callThrough();
    spy.and.returnValue(Observable.throwError({ error: { Message: serverErrorMessage } }));
    component.getSalesOffice();
    expect(apiErrorService.show).toHaveBeenCalledWith(serverErrorMessage);
  });

  it(`should not call getCommissionCodesList when service returns empty list on calling getSalesOffice`, () => {
    spyOn(domainService, 'getSalesOffices').and.returnValue(Observable.of([]));
    spyOn(component, 'getCommissionCodesList');
    component.getSalesOffice();
    expect(component.getCommissionCodesList).not.toHaveBeenCalled();
  });


  it(`should set the officeSelectorName on calling ngOnInit`, () => {
    const spyOfficeSelectorList = spyOn(fService, 'getOfficeSelectorList').and.returnValue(Observable.of([{
      salesOfficeName: 'Billings',
      drAddressId: 121,
      country: 'USA',
      crmIntegrationInd: 'Y',
    }]));
    component.ngOnInit();
    expect(component.officeSelectorName).toBe('Billings');
    expect(spyOfficeSelectorList).toHaveBeenCalled();
  });

  it(`should assign response from the server to jobContactList  on calling getJobContactList or throw error`, () => {
    component.userlist = [{ userId: 'lamsp', userName: name }];
    spyOn(headerService, 'getUserId').and.returnValue('lamsp');
    spyOn(headerService, 'getUserName').and.returnValue(name);
    const spy = spyOn(domainService, 'getJobContacts').and.returnValue(Observable.of(component.userlist));
    component.getJobContactList('23');
    expect(component.checkUser).toBeTruthy();
    expect(component.jobContactList).toEqual(component.userlist);

    spyOn(apiErrorService, 'show').and.callThrough();
    spy.and.returnValue(Observable.throwError({ error: { Message: serverErrorMessage } }));
    component.getJobContactList('23');
    expect(apiErrorService.show).toHaveBeenCalledWith(serverErrorMessage);
  });

  it(`should not assign response from the server to jobContactList  on calling getJobContactList when server returns null`, () => {
    spyOn(domainService, 'getJobContacts').and.returnValue(Observable.of(null));
    component.getJobContactList('23');
    expect(component.jobContactList[0].userId).toBeUndefined();
  });

  it(`should create a new job or throw error on calling onSave`, () => {
    component.createJobForm = new FormGroup({
      jobName: new FormControl('chaitu '),
      salesOffice: new FormControl('34'),
    });
    component.onSave();
    expect(component.createJobForm.valid).toBeTruthy();

    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(service, 'CreateJob').and.returnValue(Observable.throwError({ error: { messages: serverErrorMessage } }));
    component.onSave();
    expect(apiErrorService.show).toHaveBeenCalledWith(serverErrorMessage);

    component.createJobForm.controls['jobName'].setErrors({ key: 'required' });
    component.onSave();
    expect(component.createJobForm.valid).toBeFalsy();
  });

  it('should set getJCurrencyList countryList & selectedValue on currency Change()', () => {
    component.getJCurrencyList('USA');
    expect(component.countryList).toEqual([{ name: '$USD', code: 'COMMSALE' }]);
    expect(component.selectedValue).toEqual('COMMSALE');
    component.getJCurrencyList('CAN');
    expect(component.countryList).toEqual([{ name: '$CAD', code: 'CANADA' }, { name: '$USD', code: 'COMMSALE' }]);
    expect(component.selectedValue).toEqual('CANADA');
    component.getJCurrencyList('EUR');
    expect(component.selectedValue).toEqual('CANADA');
  });
  it('should set getJobContactList Current User Details()', () => {
    if (component.checkUser === false) {
      const dummyData = [
        { joB_ID: 925, dR_ADDRESS_ID: 10, joB_NAME: null, locatioN_OFFICE: 1 }];
      component.userlist = [{ userId: 'lamsp', userName: name }];
      expect(component.jobContactList).toEqual(dummyData);
      expect(component.userlist['useR_ID']).toEqual('lamsp');
      expect(component.userlist['useR_NAME']).toEqual(name);
    }
  });


  it(`on Selecting Challenge Handler`, () => {
    const selectedVal = '447';
    component.salesOfficeList = [{
      salesOfficeId: 447, salesOfficeName: 'ALGERIA',
      salesDistrict: 144, salesOfficeIdParent: 357, country: 'USA',
    }];
    const comSpy = spyOn(component, 'getCommissionCodesList');
    const jobSpy = spyOn(component, 'getJobContactList');
    const curSpy = spyOn(component, 'getJCurrencyList');
    component.selectChangeHandler(null, selectedVal);
    expect(component.salesOfficeSelectedValue[0].salesOfficeId).toBe(447);
    expect(comSpy).toHaveBeenCalledWith(447);
    expect(jobSpy).toHaveBeenCalledWith(447);
    expect(curSpy).toHaveBeenCalledWith('USA');
  });

  it(`should not call the service on calling selectChangeHandler when salesOfficeList doesnt have the selectedVal`, () => {
    const selectedVal = '4470';
    const comSpy = spyOn(component, 'getCommissionCodesList');
    component.salesOfficeList = [{
      salesOfficeId: 447, salesOfficeName: 'ALGERIA',
      salesDistrict: 144, salesOfficeIdParent: 357, country: 'USA',
    }];
    component.selectChangeHandler(null, selectedVal);
    expect(comSpy).not.toHaveBeenCalled();
  });

  it('should check job name empty on emptySpaceLengthCheck ', () => {
    const event = { target: { value: '' } };
    component.emptySpaceLengthCheck(event);
    expect(component.createJobForm.controls['jobName'].value).toBeNull();
    const event1 = { target: { value: 'TestJob' } };
    component.emptySpaceLengthCheck(event1);
    expect(component.createJobForm.controls['jobName'].value).toBeNull();
  });

  it(`should call error service when getCommissionCodes errors in commissionCodeList`, () => {
    spyOn(apiErrorService, 'show').and.callThrough();
    spyOn(domainService, 'getCommissionCodes').and.returnValue(Observable.throwError({ error: { Message: serverErrorMessage } }));
    const salesOfficeId = 112;
    component.getCommissionCodesList(salesOfficeId);
    expect(apiErrorService.show).toHaveBeenCalledWith(serverErrorMessage);
  });
});
