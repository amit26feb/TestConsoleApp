import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { ApiErrorService } from '../../../shared/services/apierror.service';
import { of } from 'rxjs';
import { SalesCustomerService } from '../services/sales-customer.service';
import { TraneSalesBusinessDataService } from '../services/trane-sales-business-data.service';
import { AppConstants } from './../../../shared/constants/constants';
import { TraneSalesBusinessDataServiceMock } from './../../../shared/test-mocks/tranesalesbusinessdata-mock';
import { SitesService } from './../services/sites.service';
import { CreateJobHomeComponent } from './create-job-home.component';
import { CrmJobComponent } from './crm-job/crm-job.component';
import { CreateJobComponent } from './non-crm-job/non-crm-job.component';
import { ToasterService } from '@tsmt/shared-core';
import { ApiErrorServiceMock } from './../../../shared/test-mocks/apierrorservice-mock';
import { LoaderService } from '../../../shared/services/loader.service';
import { LoaderServiceMock } from '../../../shared/test-mocks/loaderService-mock';

describe('CreateJobHomeComponent', () => {
  let component: CreateJobHomeComponent;
  let fixture: ComponentFixture<CreateJobHomeComponent>;
  let routerTest: Router;
  let route: ActivatedRoute;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      declarations: [CreateJobHomeComponent, CreateJobComponent, CrmJobComponent],
      providers: [
        {
          provide: ActivatedRoute, useValue: {
            snapshot: {
              params: {},
            },
            queryParams: of({ jobType: 'CRM' }),
            parent: {
              parent: {
                parent: {
                  params: of({ drAddressId: 121 }),
                },
              },
            },
          },
        },
        { provide: TraneSalesBusinessDataService, useClass: TraneSalesBusinessDataServiceMock },
        { provide: ApiErrorService, useClass: ApiErrorServiceMock },
        { provide: LoaderService, useClass: LoaderServiceMock },
        AppConstants, SalesCustomerService, SitesService, ToasterService
      ],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateJobHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    routerTest = TestBed.inject(Router);
    route = TestBed.inject(ActivatedRoute);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the value of query param to be CRM when ngOnInit is triggered', () => {
    route.queryParams = of({ jobType: 'CRM' });
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.queryParam).toBe('CRM');
  });
});
