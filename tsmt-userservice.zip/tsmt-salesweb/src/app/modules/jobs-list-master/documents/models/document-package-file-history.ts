export interface IDocumentPackageFileHistory {
    fileVersion: number;
    fileName: string;
    modifiedDate: string;
    lastModifiedByUser: string;
    lastModifiedByUserName: string;
    generatedDate: string;
    generatedByUser: string;
    generatedByUserName: string;
    status: string;
    error: string;
    notes: string;
    fileLocation: string;
    documentStorage: string;
    documentVersion: string;
}
