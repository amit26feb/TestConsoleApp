import { IDocumentPackageProdFamilyErrors } from '../../models/document-package-prod-family-errors';

export interface IDocumentPackageListItemModel {
    documentType: string;
    docPkgId: number;
    name: string;
    documentStorage: string;
    fileLocation: string;
    description: number;
    drAddressId: number;
    createdUser: string;
    createdUserFirstName: string;
    createdUserLastName: string;
    createdDate: string;
    modifiedUser: string;
    modifiedUserFirstName: string;
    modifiedUserLastName: string;
    modifiedDate: string;
    status: string;
    fileVersion: number;
    lastGeneratedFileVersion: number;
    fileGeneratedDate: string;
    fileGeneratedByUser: string;
    generatedUserFirstName: string;
    generatedUserLastName: string;
    lastUploadedFileVersion: number;
    fileUploadedDate: string;
    fileUploadedByUser: string;
    uploadedUserFirstName: string;
    uploadedUserLastName: string;
    workStatus: string;
    percentComplete: number;
    productFamilyGenerationErrorDetails: IDocumentPackageProdFamilyErrors[];
    documentVersion: string;
    fileName: string;
}
