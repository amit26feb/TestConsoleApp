export interface IGenPackageFolders {
    documentType: string;
    packagesList: IPackagesList[];
    expanded: boolean;
}
export interface IPackagesList {
    documentType: string;
    docPkgId: number;
    name: string;
    description: number;
    drAddressId: number;
    createdUser: string;
    createdUserFirstName: string;
    createdUserLastName: string;
    createdDate: string;
    modifiedUser: string;
    modifiedUserFirstName: string;
    modifiedUserLastName: string;
    modifiedDate: string;
    status: string;
    fileVersion: number;
    lastGeneratedFileVersion: number;
    fileGeneratedDate: string;
    fileGeneratedByUser: string;
    generatedUserFirstName: string;
    generatedUserLastName: string;
}

export interface IDocumentFolderList {
    folderId: number;
    folderParentId: number;
    drAddressId: number;
    jobId: number;
    folderName: string;
    folderSource: string;
    jobFolderTypeId: number;
    docTypeId?: number;
    isLegacyLdgFolder: boolean;
    isLegacyJobCenterFolder: boolean;
}
