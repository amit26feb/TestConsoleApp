export interface IMandatoryInfo {
    businessStream: number;
    documentType: number;
    docPackageName: string;
    docDescription: string;
    legalEntity: number;
    bid?: number;
    workPackage?: number;
    termsandconditions: number;
    unitOfMeasureMetric: boolean;
}
