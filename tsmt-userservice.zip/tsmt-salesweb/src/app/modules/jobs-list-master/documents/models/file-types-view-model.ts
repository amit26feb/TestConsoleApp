export interface IFileTypesDetails {
    createdBy: string;
    createdOn: string;
    jobDocumentTypeId: number;
    isAvailableForUser: boolean;
    sequenceNumber: number;
    status: string;
    typeAbstract: string;
    typeName: string;
    updatedBy: string;
    updatedOn: string;
}
