export interface ICustomSenderDetails {
    customSenderId: string;
    customSenderNickName: string;
    senderName: string;
    title: string;
    cellPhoneNumber: string;
    emailAddress: string;
    jobDrAddressId: number;
    customSenderDrAddressId: number;
    customSenderSalesOfficeId: number;
    officePhoneNumber: string;
    officeFaxNumber: string;
    createdBy: string;
    lastModifiedBy: string;
    createdDate: string;
    lastModifiedDate: string;
}
