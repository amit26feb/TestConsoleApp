export interface IMostRecentGeneratedFileHistory {
    fileVersion: number;
    fileName: string;
    totalGeneratedVersions: number;
}
