export interface ILegacyFile {
    isLegacyLdgFile: boolean;
    isLegacyJobCenterFile: boolean;
    fileName: string;
    relativeDirectoryAndFileName: string;
    fullPathToFile: string;
    lastModifiedDate: string;
    versionId: string;
    folderId: number;
}
