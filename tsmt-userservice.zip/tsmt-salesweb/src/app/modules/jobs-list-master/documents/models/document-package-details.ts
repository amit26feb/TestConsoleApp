export interface IDocumentPackageDetails {
    legalEntityLongName: string;
    legalEntityShortName: string;
    termsConditionsName: string;
    tcFileLocation: string;
    drAddressId: number;
    jobId: number;
    documentPackageId: number;
    version: number;
    documentPackageFileId: number;
    legalEntityId: number;
    termsAndConditionsId: number;
    bidAlternateId: number;
    workPackageId: number;
    fileName: string;
    fileLocation: string;
    additionalInfo: any;
    status: string;
    generatedInfo: string;
    generatedDate: string;
    generatedBy: string;
    proposalNumber: string;
    updatedOn: string;
    updatedBy: string;
}
