import { IDocumentPackageDetails } from './document-package-details';

export interface IDocumentPackageInfo {
    docPkgFileDetails: IDocumentPackageDetails;
    documentPackageId: number;
    name: string;
    description: string;
    drAddressId: number;
    salesOfficeCode: string;
    jobId: number;
    businessStreamId: number;
    documentTypeId: number;
    documentTypeName: string;
    createdOn: string;
    createdBy: string;
    updatedOn: string;
    updatedBy: string;
}
