export interface IJobDateModel {
  jobId: number;
  jobReportId: number;
  drAddressId: number;
  bidDate: string;
  submittalDateApproved: string;
  reqProjectCompletionDate: string;
  startUpDate: string;
  lastUpdate: string;
  dateCreated: string;
  crmOpportunityId: string;
}

export class IJobIndicatorsModel {
  jobReportId: number;
  jobId: number;
  drAddressId: number;
  acousticsInd: string;
  hieffInd: string;
  lowTempAirInd: string;
  nationalAcctInd: string;
  pactInd: string;
  penaltyJobInd: string;
  serviceContractInd: string;
  stackedInd: string;
  targetJobInd: string;
  adpInd: string;
  icsInd: string;
  llwtInd: string;
}

export interface IJobGeneral {
  jobId: number;
  jobReportId: string;
  drAddressId: number;
  jobName: string;
  status: string;
  crmOpportunityId: string;
  crmIntegrationInd: string;
  custChannelId: string;
  qualitySpecDescr: string;
  jobPhaseDescr: string;
  influencedById: string;
  quoteNbr: string;
  pricingSpaNbr: string;
  dodgeNbr: string;
  distanceToJob: string;
  sourceOfLead: string;
  tcpnNbr: string;
  tcpnContractNbr: string;
  falloutReason: string;
  lostToCompetitor: string;
  hqtrJobId: string;
  sellingPrice: number;
  isCplpafLocked: boolean;
}

export interface IJobAddress {
  jobId: number;
  drAddressId: number;
  domesticInternationlInd: string;
  streetAddress1: string;
  streetAddress2: string;
  city: string;
  state: string;
  zipCode: string;
  zipPlus: string;
  country: string;
  county: string;
  province: string;
  nonUsPostalCode: string;
}

export interface IJobOfficeAndPeople {
  jobId: number;
  jobReportId: string;
  drAddressId: number;
  salesOfficeId: number;
  locationOffice: number;
  commCode: string;
  takeoffCommCode: string;
  controlsCommCode: string;
  crmOppurtunityId: string;
  salesOfficeName: string;
  locationOfficeName: string;
  buMfgLocationId?: number;
}

export interface IJobDomainList {
  listType: string;
  codeValue: string;
  displayValue: string;
  activeInd: string;
  displayOrder: string;
}

export interface IJobRoleTypeList {
  roleTypeId: string;
  roleTypeName: string;
}

export interface ICompetitorList {
  competitorId: string;
  competitorName: string;
  crmCompanyId: string;
  competitorStatus: string;
}

export interface ISalesOfficeList {
  salesOfficeId: number;
  salesOfficeName: string;
  salesDistrict: string;
  salesOfficeIdParent: string;
  country: string;
  salesOfficeCode?: string;
}

export interface ICommCodeList {
  name: string;
  commCode: string;
  commCodeDisplay: string;
  salesOfficeId: string;
}

export interface IEditJobModel {
  jobId: number;
  drAddressId: number;
  userId: string;
  nameFirst: string;
  nameLast: string;
  coordinationStatus: string;
  jobGeneral: IJobGeneral;
  jobAddress: IJobAddress;
  jobNotes: IJobNotesModel;
  jobOfficeAndPeople: IJobOfficeAndPeople;
  jobDomainList: IJobDomainList[];
  jobRoleTypeList: IJobRoleTypeList[];
  competitorList: ICompetitorList[];
  salesOfficeList: ISalesOfficeList[];
  commCodeList: ICommCodeList[];
  jobDates?: IJobDateModel;
  jobIndicatorView?: IJobIndicatorsModel;
  jobFinancial: IJobEditFinancialModel;
  jobClassificationList: IClassificationModel;
}

export interface IPostalMasterModel {
  countryCode: string;
  mainCityInd: string;
  fipsCode: string;
  stateProvinceCode: string;
  city: string;
  postalCode: string;
  countyName: string;

}
export interface ICountryModel {
  countryCode: string;
  countryName: string;
}
export interface IStateModel {
  country: string;
  stateProvinceCode: string;
}
export interface ICustomerModel {
  salesCustomerID: string;
  customerName: string;
  accountNumber: string;
  city: string;
  zipCode: string;
  phoneNumber: string;
  county: string;
}

export interface IJobNotesModel {
  jobId: number;
  noteString: string;
  drAddressId: number;
}
export interface IJobEditFinancialModel {
  jobReportId: number;
  jobId: number;
  drAddressId: number;
  estEquipment: number;
  estControl: number;
  contractMargin: number;
  contractTaxes: number;
  contractTraneEquipDlrs: number;
  contractNonTraneEquipDlrs: number;
  contractSubContractDlrs: number;
  contractDirectJobExpenses: number;
}

export interface IEarthwiseSystemModel {
  sysTypeId: number;
  description: string;
  multiSelect: string;
  seqNbr: number;
  isChecked: boolean;
  toolTip: string;
}

export interface IClassificationModel {
  jobCodeId: number;
  jobId: number;
  drAddressId: number;
  jobClassId: number;
  descriptionValues: string;
  classificationDescription: string;
  jobClassificationList: IClassificationOptions[];
}
export interface IClassificationOptions {
  jobCodeId: number;
  description: string;
  selected: boolean;
}

export interface IShipToAddress {
  altDeliveryContactEmail: string;
  altDeliveryContactExtension: string;
  altDeliveryContactName: string;
  altDeliveryContactPhone: string;
  city: string;
  country: string;
  creditJobId: number;
  deliveryContactEmail: string;
  deliveryContactExtension: string;
  deliveryContactName: string;
  deliveryContactPhone: string;
  deliveryHours: number;
  fipsCode: string;
  isDomestic: boolean;
  isFinalFinisher: boolean;
  isIncludePO: boolean;
  jobId: number;
  markBillLadingText: string;
  markPackageText: string;
  nonUSPostalCode: string;
  partyName: string;
  province: string;
  shippingInstructionDescription: string;
  shippingInstructionId: number;
  shippingInstructionNote: string;
  stateCode: string;
  streetAddress1: string;
  streetAddress2: string;
  zipCode: string;
  zipPlus: string;
  poNumber: string;
  county: string;
  isUsedOnLineItem?: boolean;
  isChangeAllowed?: boolean;
}

export interface IJobContactModel {
  userId: string;
  userName: string;
}

export interface ISearchCustomerListModel {
  pageNumber: number;
  pageSize: number;
  totalItemCount: number;
  pageCount: number;
  customerList: ISearchCustomerModel[];
}

export interface ISearchCustomerModel {
  salesCustId: number;
  firstName: string;
  lastName: string;
  customerName: string;
  streetAddress1: string;
  streetAddress2: string;
  state: string;
  zipCode: string;
  nonUsPostalCode: string;
  city: string;
  custAcctNbr: string;
  jobRoleTypeId?: number;
  commCode: string;
  address: string;
  totalCount: number;
  region: string;
  phoneNumber: string;
  faxNumber: string;
  contactPhoneNumber: string;
  contactFaxNumber: string;
  contactPhoneExtension: string;
  crmCompanyId: string;
}

export interface ISalesCustomerContactView {
  assignContact: boolean;
  rowID: number;
  firstName: string;
  lastName: string;
  phoneNbr: string;
  phoneExtension: string;
  faxNbr: string;
  customerContactId: number;
  salesCustId: number;
  jobRoleContactId: number;
  jobRoleAsnId: number;
}

export interface ISalesCustomer {
  salesCustId: string;
  custChannelId: string;
  customerName: string;
  salesOfficeId: number;
  jobRoleType: string;
  commCode: string;
  accountNumber: string;
  addressLine1: string;
  addressLine2: string;
  state: string;
  zipPlus: string;
  country: string;
  phoneNumber: string;
  faxNumber: string;
  parentCustId?: number;
  zipCode: string;
  province: string;
  nonUSPostalCode: string;
  city: string;
  custCreditCatgCode: string;
  usedForOrderEntryInd: string;
  fipsCode: string;
  statusFlag: string;
  crmcompanyId: string;
  lastEcSyncChangeId?: number;
  JobId: number;
  JobRoleAsnId: number;
  salesCustomerContactView: ISalesCustomerContactView[];
  isValid: boolean;
}
