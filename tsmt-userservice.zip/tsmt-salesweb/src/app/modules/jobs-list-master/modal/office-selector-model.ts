export interface IOfficeSelectorModel {
    salesOfficeName: string;
    drAddressId: number;
    country: string;
    crmIntegrationInd: string;
    homeDrAddressId: number;
}
