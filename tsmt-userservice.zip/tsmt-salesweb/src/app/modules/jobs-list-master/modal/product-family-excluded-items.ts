export class ProductFamilyExcludedItem {
        constructor(
                public id: number,
                public productId: number,
                public Item: string) { }
}
