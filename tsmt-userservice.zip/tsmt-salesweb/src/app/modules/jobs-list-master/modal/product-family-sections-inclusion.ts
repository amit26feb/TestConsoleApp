export class ProductFamilySectionInclusion {
    constructor(
        public productFamilyId: number,
        public sections: number) {}
    }
