export class PerformanceInclusionFields {
    hasPerformanceField: boolean;
    includePerformanceDataForProposal: boolean;
    includePerformanceDataForSubmittal: boolean;
}
