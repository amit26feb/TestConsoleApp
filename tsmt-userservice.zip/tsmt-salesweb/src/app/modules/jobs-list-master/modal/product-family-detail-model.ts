import { PerformanceInclusionFields } from './performance-Inclusion-Fields';
export class ProductFamilyDetailModel {
  id: number;
  code: string;
  alias?: string;
  description: string;
  ahriCertifiable: boolean;
  performanceInclusionFields: PerformanceInclusionFields;
}
