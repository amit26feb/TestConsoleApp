export class ProductFamilyClarificationItem {
    constructor(
        public productFamilyId: number,
        public clarificationDetails: string[]) { }
}
