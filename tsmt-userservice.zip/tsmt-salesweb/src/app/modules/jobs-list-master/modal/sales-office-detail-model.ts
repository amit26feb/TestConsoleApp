export interface ISalesOfficeDetailModel {
    id: number;
    code: string;
    name: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    province: string;
    zip: string;
    zipPlus: string;
    country: string;
    phone: string;
    fax: string;
    isOracleProjectIndicator: boolean;
}
