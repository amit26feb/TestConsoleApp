export class ProductFamilyItemsNotIncluded {
        constructor(
                public productFamilyId: number,
                public itemsNotIncludedDetails: string[]) { }
}
