import { PerformanceInclusionFields } from './performance-Inclusion-Fields';
export class ProductFamily {
        constructor(
                public id: number,
                public name: string,
                public ahriCertifiable: boolean,
                public performanceInclusionFields: PerformanceInclusionFields,
        ) { }
}
