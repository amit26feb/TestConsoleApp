import { CommonModule, CurrencyPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ExcelModule, GridModule } from '@progress/kendo-angular-grid';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NotificationModule, NotificationService } from '@progress/kendo-angular-notification';
import { PopupModule } from '@progress/kendo-angular-popup';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { UploadModule } from '@progress/kendo-angular-upload';
import { SaleswebDocgenLibraryModule } from '@tsmt/salesweb-docgenmodule';
import { JobsLibraryModule } from '@tsmt/salesweb-jobsmodule';
import { SalesWebJobsDetailsLibraryModule } from '@tsmt/salesweb-jobsdetailsmodule';
import { RebalancingLibraryModule } from '@tsmt/salesweb-rebalancing';
import { SelectionLibraryModule } from '@tsmt/salesweb-selectionmodule';
import { ClassificationsFormComponent } from '../../shared/components/classifications-form/classifications-form.component';
import { EarthwiseSystemFormComponent } from '../../shared/components/earthwisesystem-form/earthwisesystem-form.component';
import { SharedModule } from '../../shared/modules/shared/shared.module';
import { LoaderService } from '../../shared/services/loader.service';
import { environment } from './../../../environments/environment';
import { BidsModuleLibraryModule } from './../../bidsmodule-library.module';
import { SharedPriceRollUpLibraryModule } from './../../shared-price-rollup-library.module';
import { ApiErrorService } from './../../shared/services/apierror.service';
import { JobSummaryService } from './../../shared/services/job-summary.service';
import { SharedCoreLibraryModule } from './../../sharedcore-library.module';
import { CoordinateComponent } from './coordinate/coordinate.component';
import { CreateJobHomeComponent } from './create/create-job-home.component';
import { CrmGridComponent } from './create/crm-job/crm-grid/crm-grid.component';
import { CrmJobComponent } from './create/crm-job/crm-job.component';
import { GeneralComponent } from './create/crm-job/general/general.component';
import { CreateJobComponent } from './create/non-crm-job/non-crm-job.component';
import { ExitJobMessageComponent } from './exit-job-message/exit-job-message.component';
import { ImportJobComponent } from './import-job/import-job.component';
import { JobsListMasterComponent } from './jobs-list-master.component';
import { JobsListRoutingModule } from './jobs-list-routing.module';
import { PriceComponent } from './price/price.component';
import { BidsService } from './services/bids.service';
import { CoordinateService } from './services/coordinate.service';
import { DocumentService } from './services/document.service';
import { ExitJobService } from './services/exit-job.service';
import { GridFilterService } from './services/grid-filter.service';
import { JobLockService } from './services/job-lock.service';
import { JobSelectionService } from './services/job-selection.service';
import { JobEditSaveService } from './services/jobeditsave.service';
import { JobsRemoteBindingService } from './services/jobs-remote-binding.service';
import { JobsServicesService } from './services/jobs-services.service';
import { SelectionService } from './services/selection.service';
import { SitesService } from './services/sites.service';
import { TraneSalesBusinessDataService } from './services/trane-sales-business-data.service';
import { UserService } from './services/user.service';

export function httpLoaderFactory(httpClient: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(httpClient, './assets/i18n/', '.json');
}

@NgModule({
  imports: [
    CommonModule,
    GridModule,
    JobsListRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    DialogsModule,
    DropDownsModule,
    InputsModule,
    TooltipModule,
    TreeViewModule,
    DatePickerModule,
    ButtonsModule,
    NotificationModule,
    SharedModule,
    LayoutModule,
    PopupModule,
    ExcelModule,
    UploadModule,
    RebalancingLibraryModule.forRoot(environment),
    SharedCoreLibraryModule.forRoot(environment),
    SharedPriceRollUpLibraryModule.forRoot(environment),
    BidsModuleLibraryModule.forRoot(environment),
    SelectionLibraryModule.forRoot(environment),
    JobsLibraryModule.forRoot(environment),
    SalesWebJobsDetailsLibraryModule.forRoot(environment),
    SaleswebDocgenLibraryModule.forRoot(environment),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient],
      },
    }),
  ],
  declarations: [JobsListMasterComponent, CreateJobComponent, EarthwiseSystemFormComponent, ClassificationsFormComponent,
    ExitJobMessageComponent, PriceComponent, CoordinateComponent,
    ImportJobComponent, CrmJobComponent, CreateJobHomeComponent, CrmGridComponent, GeneralComponent],


  providers: [
    DocumentService,
    UserService,
    ExitJobService,
    JobEditSaveService,
    JobsRemoteBindingService,
    JobsServicesService,
    LoaderService,
    NotificationService,
    TraneSalesBusinessDataService,
    BidsService,
    CurrencyPipe,
    JobLockService,
    ApiErrorService,
    GridFilterService,
    JobSelectionService,
    CoordinateService,
    SelectionService,
    JobSummaryService,
    SitesService,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
})
export class JobsListMasterModule { }
