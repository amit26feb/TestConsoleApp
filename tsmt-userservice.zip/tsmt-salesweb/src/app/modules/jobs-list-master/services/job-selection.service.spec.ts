import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { JobSelectionService } from './job-selection.service';

describe('JobSelectionService', () => {
  let jobSelectionService: JobSelectionService;
  let httpClient: HttpClient;
  const originReset = TestBed.resetTestingModule;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [JobSelectionService, AppConstants],
    });
    jobSelectionService = TestBed.inject(JobSelectionService);
    httpClient = TestBed.inject(HttpClient);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([JobSelectionService], (service: JobSelectionService) => {
    expect(service).toBeTruthy();
  }));

  it('should fetch bids cross reference list details and check error when getting bids cross reference list', () => {
    jobSelectionService.getBidsCrossReferenceData(122, 59297).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
    // check error when getting bids cross reference list
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    jobSelectionService.getBidsCrossReferenceData(122, 1).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
});
