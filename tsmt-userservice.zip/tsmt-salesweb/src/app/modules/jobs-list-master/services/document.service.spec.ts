import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { throwError, Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { DocumentDetails } from '@tsmt/shared-acquisition-dataservices';
import { IDocumentFolderList } from '../documents/models/document-package-gen-folders-model';
import { IFileTypesDetails } from '../documents/models/file-types-view-model';
import { ILegacyFile } from '../documents/models/legacy-file';
import { IMostRecentGeneratedFileHistory } from '../documents/models/most-recent-generated-file-history';
import { IWorkPackage } from '../models/work-package';
import { IBusinessStream } from '../models/business-stream-model';
import { IDocumentInput } from '../models/document-input-model';
import { DocumentService } from './document.service';
import { IWorkPackageDetail } from '../models/work-package-detail';

// tslint:disable-next-line:no-big-function
describe('DocumentService', () => {
  let injector: TestBed;
  let service: DocumentService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;
  let docUrl: string;
  let docPacUrl: string;
  let salesWebGatewayUrl: string;
  const originReset = TestBed.resetTestingModule;
  const drAddressId = 2;
  const jobId = 1;
  const docPackId = 3;
  const fileVersion = 4;
  const workPackageId = 5;
  const documentName = 'SampleTest.doc';
  const folderId = 29;
  const documentTypeId = 1;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [DocumentService, AppConstants],
      imports: [HttpClientTestingModule],
    });
    injector = getTestBed();
    service = injector.inject(DocumentService);
    httpMock = injector.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
    docUrl = 'https://devservices.trane.com/saleswebgateway/api/v1/DocumentGenerator/96/Jobs/1234/DocumentPackage/12/Generate';
    docPacUrl = 'https://devservices.trane.com/documentpackage/api/v1/';
    salesWebGatewayUrl = 'https://devservices.trane.com/saleswebgateway/api/v1/';
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('generateDocument should call documentService to request document generation', fakeAsync(() => {
    const payload = {
      jobId: 1234,
      drAddressId: 96,
      docPackId: 12,
    };
    service.requestDocumentGeneration(payload).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const req = httpMock.expectOne(docUrl);
    expect(req.request.method).toBe('POST');
    req.flush(new Blob(), { status: 200, statusText: 'OK' });
  }));

  it('should catch the error when documentService throws an error while generating the document', () => {
    const payload = {
      jobId: 1234,
      drAddressId: 96,
      docPackId: 12,
    };
    const spyPost = spyOn(httpClient, 'post').and.returnValue(Observable.of(true));
    spyPost.and.returnValue(throwError({ error: 'error' }));
    service.requestDocumentGeneration(payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should fetch the list of business streams when fetchBusinessStreams method is being called', () => {
    const res = [
      {
        businessStreamId: 1,
        businessStreamName: 'NewEquipment',
      },
    ] as IBusinessStream[];
    service.getBusinessStreams().subscribe((value) => {
      expect(value[0].businessStreamId).toBe(1);
      expect(value[0].businessStreamName).toBe('NewEquipment');
    });
    const req = httpMock.expectOne(docPacUrl + 'MasterData/BusinessStreams');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it(`should fetch the list of business stream driven document inputs
  when getDocumentInputsForBusinessStream method is being called`, () => {
    const businessStreamId = 1;
    const res = [
      {
        documentInputId: 1,
        documentInputName: 'ServiceContactPhoneNumber',
      },
    ] as IDocumentInput[];
    service.getDocumentInputsForBusinessStream(businessStreamId).subscribe((value) => {
      expect(value[0].documentInputId).toBe(1);
      expect(value[0].documentInputName).toBe('ServiceContactPhoneNumber');
    });
    const req = httpMock.expectOne(docPacUrl + 'MasterData/Groups/' + businessStreamId + '/Inputs');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it(`should fetch the list of document type driven document inputs
  when getDocumentInputsForDocumentType method is being called`, () => {
    const docTypeId = 1;
    const res = [
      {
        documentInputId: 1,
        documentInputName: 'ServiceContactPhoneNumber',
      },
    ] as IDocumentInput[];
    service.getDocumentInputsForDocumentType(docTypeId).subscribe((value) => {
      expect(value[0].documentInputId).toBe(1);
      expect(value[0].documentInputName).toBe('ServiceContactPhoneNumber');
    });
    const req = httpMock.expectOne(docPacUrl + 'MasterData/DocumentTypes/' + docTypeId + '/Inputs');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should fetch the list of document types when getAllDocumentTypes method is being called', () => {
    const res = [
      {
        documentTypeId: 1,
        documentTypeName: 'EquipmentProposal',
        description: 'EquipmentProposal',
        active: 1,
        createdOn: '2019-05-17T13:29:55.1360116+05:30',
        createdBy: '',
        updatedOn: '2019-05-17T13:29:55.1363364+05:30',
        updatedBy: '',
      },
    ];
    service.getAllDocumentTypes().subscribe((value) => {
      expect(value).toBeDefined();
    });
    const req = httpMock.expectOne(docPacUrl + 'MasterData/DocumentTypes');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should fetch the list of document types when getDocumentTypes method is being called', () => {
    const res = [
      {
        documentTypeId: 1,
        documentTypeName: 'EquipmentProposal',
        description: 'EquipmentProposal',
        active: 1,
        createdOn: '2019-05-17T13:29:55.1360116+05:30',
        createdBy: '',
        updatedOn: '2019-05-17T13:29:55.1363364+05:30',
        updatedBy: '',
      },
    ];
    service.getDocumentTypes(1).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const req = httpMock.expectOne(docPacUrl + 'MasterData/Groups/1/DocumentTypes');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should fetch the list of packages when getPackagesList method is being called', () => {
    const res = {
      documentType: {
        equipmentProposal: [
          {
            documentType: 'Equipmentproposal',
          },
        ],
      },
    };
    service.getPackagesList({ drAddressId: 123, jobId: 67 }).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const req = httpMock.expectOne(salesWebGatewayUrl + '123/Jobs/67/DocumentPackages');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should fetch the package details when getPackageDetails method is being called', () => {
    const res = {
      businessStreamId: 0,
      createdBy: 'ccfbsb',
      createdOn: '2019-08-22T12:38:31',
      description: 'sravsTest',
    };
    service.getPackageDetails(123, 67, 23).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const req = httpMock.expectOne(docPacUrl + '123/Jobs/67/DocumentPackage/23');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should fetch the list of legal entities when fetchLegalEntities method is being called', () => {
    const res = [
      {
        legalEntityId: 1,
        legalEntityName: 'Trane U.S. Inc.',
        shortName: 'Trane',
        description: 'Trane U.S. Inc.',
        active: 1,
        createdOn: '2019-05-17T13:30:47.3451054+05:30',
        createdBy: '',
        updatedOn: '2019-05-17T13:30:47.3452278+05:30',
        updatedBy: '',
      },
    ];
    service.getLegalEntities(1).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const req = httpMock.expectOne(docPacUrl + 'MasterData/DocumentTypes/1/LegalEntities');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should fetch the list of terms and conditions when fetchTermsAndConditions method is being called', () => {
    const res = [
      {
        termsAndConditionId: 1,
        termsAndConditionName: 'Supplier',
        description: 'Supplier',
        active: 1,
        createdOn: '2019-05-17T13:31:26.073024+05:30',
        createdBy: '',
        updatedOn: '2019-05-17T13:31:26.0731114+05:30',
        updatedBy: '',
      },
    ];
    service.getTermsAndConditions(1).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const req = httpMock.expectOne(docPacUrl + 'MasterData/DocumentTypes/1/TermsAndConditions');
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should return file and non-unicode filename on getDocumentFileDownload', () => {
    const downloadFile = {
      status: 200,
      file: new Blob(),
      headers: new HttpHeaders({
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="file's.docx";`,
      }),
    };
    spyOn(httpClient, 'get').and.returnValue(Observable.of(downloadFile));
    service.getDocumentFileDownload(1, 2, 3, 4).subscribe((data) => {
      expect(data.file).toBeDefined();
      expect(data.name).toBe(`file's.docx`);
    });
  });

  it('should return file and unicode filename on getDocumentFileDownload', () => {
    const nonUnicodeFilename = 'crazyfilename__________`!@#$%^&();{}=-+\'.docx';
    const unicodeEncodedFilename = 'crazyfilename_%C3%A9%C3%A8%C3%A2%C3%AE%C3%B4%C3%B1%C3%BC%C3%AF%C3%A7`!%40#$%25^&%28%29%3B%7B%7D%3D-+%27.docx';
    const expectedFilename = 'crazyfilename_éèâîôñüïç`!@#$%^&();{}=-+\'.docx';
    const downloadFile = {
      status: 200,
      file: new Blob(),
      headers: new HttpHeaders({
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="${nonUnicodeFilename}"; filename*=UTF-8''${unicodeEncodedFilename}`,
      }),
    };
    spyOn(httpClient, 'get').and.returnValue(Observable.of(downloadFile));
    service.getDocumentFileDownload(1, 2, 3, 4).subscribe((data) => {
      expect(data.file).toBeDefined();
      expect(data.name).toBe(expectedFilename);
    });
  });

  it('getDocumentFileDownload should catch the error when http throws an error', () => {
    const spyPost = spyOn(httpClient, 'get').and.returnValue(Observable.of(true));
    spyPost.and.returnValue(throwError({ error: 'errorMan' }));
    service.getDocumentFileDownload(1, 2, 3, 4).subscribe(() => {
    }, (err) => { expect(err.error).toBe('errorMan'); });
  });

  it('should return file and non-unicode filename on getMostRecentDocumentFileDownload', () => {
    const downloadFile = {
      status: 200,
      file: new Blob(),
      headers: new HttpHeaders({
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="file's.docx";`,
      }),
    };
    spyOn(httpClient, 'get').and.returnValue(Observable.of(downloadFile));
    service.getMostRecentDocumentFileDownload(1, 2, 3).subscribe((data) => {
      expect(data.file).toBeDefined();
      expect(data.name).toBe(`file's.docx`);
    });
  });

  it('should return file and unicode filename on getMostRecentDocumentFileDownload', () => {
    const nonUnicodeFilename = 'crazyfilename__________`!@#$%^&();{}=-+\'.docx';
    const unicodeEncodedFilename = 'crazyfilename_%C3%A9%C3%A8%C3%A2%C3%AE%C3%B4%C3%B1%C3%BC%C3%AF%C3%A7`!%40#$%25^&%28%29%3B%7B%7D%3D-+%27.docx';
    const expectedFilename = 'crazyfilename_éèâîôñüïç`!@#$%^&();{}=-+\'.docx';
    const downloadFile = {
      status: 200,
      file: new Blob(),
      headers: new HttpHeaders({
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="${nonUnicodeFilename}"; filename*=UTF-8''${unicodeEncodedFilename}`,
      }),
    };
    spyOn(httpClient, 'get').and.returnValue(Observable.of(downloadFile));
    service.getMostRecentDocumentFileDownload(1, 2, 3).subscribe((data) => {
      expect(data.file).toBeDefined();
      expect(data.name).toBe(expectedFilename);
    });
  });

  it('getMostRecentDocumentFileDownload should catch the error when http throws an error', () => {
    const spyPost = spyOn(httpClient, 'get').and.returnValue(Observable.of(true));
    spyPost.and.returnValue(throwError({ error: 'errorMan' }));
    service.getMostRecentDocumentFileDownload(1, 2, 3).subscribe(() => {
    }, (err) => { expect(err.error).toBe('errorMan'); });
  });

  it('getDocumentFileStatus should return the payload returned by the http call', () => {
    const response = { status: 'dun', generatedDate: 'now', workStatus: 'Generating Reports', percentComplete: 12 };

    service.getDocumentFileStatus(drAddressId, jobId, docPackId, fileVersion).subscribe((value) => {
      expect(response.status).toEqual(value.status);
      expect(response.generatedDate).toEqual(value.generatedDate);
      expect(response.workStatus).toEqual(value.workStatus);
      expect(response.percentComplete).toEqual(value.percentComplete);
    });

    const req = httpMock.expectOne(salesWebGatewayUrl +
      `${drAddressId}/Jobs/${jobId}/DocumentPackages/${docPackId}/Files/${fileVersion}/Status`);
    expect(req.request.method).toBe('GET');
    req.flush(response);
  });

  it('should get the generated files on call of getJobHistoryFiles method', () => {
    const res = [{
      documentName: 'Package 1',
      documentUpdateStatus: 'Complete',
      uploadedDate: '2018-09-10T09:44:46',
      uploadedBy: 'cczpvr',
      documentVersion: '1'
    }] as DocumentDetails[];

    service.getJobHistoryFiles(drAddressId, jobId, documentName, folderId, documentTypeId).subscribe((value) => {
      expect(value).toBe(res);
    });
    const req = httpMock.expectOne(salesWebGatewayUrl + `Document/JobDocumentHistory?drAddressId=2&jobId=1&documentName=SampleTest.doc&folderId=29&documentTypeId=1`);
    expect(req.request.method).toBe('GET');
    req.flush(res);
    // check exception scenario in service
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getJobHistoryFiles(drAddressId, jobId, documentName, folderId, documentTypeId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get the legacy files on call of getFiles method', () => {
    const res = [{
      isLegacyLdgFile: true,
      isLegacyJobCenterFile: false,
      fileName: 'rick.docx',
      relativeDirectoryAndFileName: '1/rick.docx',
      fullPathToFile: 'blah/1/rick.docx',
      lastModifiedDate: '2020-01-01',
      versionId: 'xyz'
    }] as ILegacyFile[];

    service.getLegacyFiles(drAddressId, jobId).subscribe((value) => {
      expect(value).toBe(res);
    });

    const req = httpMock.expectOne(docPacUrl + `${drAddressId}/Jobs/${jobId}/LegacyFiles`);
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should request migration of legacy files on requestMigrationOfLegacyFiles()', () => {
    service.requestMigrationOfLegacyFiles(drAddressId, jobId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should check error on migration of legacy files on requestMigrationOfLegacyFiles()', () => {
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.requestMigrationOfLegacyFiles(drAddressId, jobId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it(`should get the most recent generated file history info
    on call of getMostRecentGeneratedFile method`, () => {
    const res = {
      fileName: 'Package 1',
      fileVersion: 5,
      totalGeneratedVersions: 3,
    } as IMostRecentGeneratedFileHistory;

    service.getMostRecentGeneratedFile(drAddressId, jobId, docPackId).subscribe((value) => {
      expect(value).toBe(res);
    });

    const req = httpMock.expectOne(docPacUrl + `${drAddressId}/Jobs/${jobId}/DocumentPackages/${docPackId}/Files/MostRecentGeneratedFile`);
    expect(req.request.method).toBe('GET');
    req.flush(res);
  });

  it('should create a new document folder on call of createDocumentFolder', fakeAsync(() => {
    const createPayload = {
      folderId: 2,
      folderParentId: 1,
      drAddressId: 2,
      jobId: 1,
      folderName: 'New folder',
      folderSource: 'user',
    } as IDocumentFolderList;
    service.createDocumentFolder(createPayload).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const request = httpMock.expectOne(docPacUrl + `${drAddressId}/Jobs/${jobId}/DocumentFolder`);
    expect(request.request.method).toBe('POST');
    request.flush({});
  }));

  it(`should throw error when failed to create document folder on calling createDocumentFolder method`, () => {
    const createPayload = {
      folderId: 3,
      folderParentId: 1,
      drAddressId: 0,
      jobId: 0,
      folderName: 'New folder 2',
      folderSource: 'user',
    } as IDocumentFolderList;
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.createDocumentFolder(createPayload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get the document folders on call of getDocumentFolders method', fakeAsync(() => {
    const response = [{
      folderId: 1,
      folderParentId: null,
      drAddressId: 2,
      jobId: 1,
      folderName: 'Folder 1',
      folderSource: 'user',
    }] as IDocumentFolderList[];
    service.getDocumentFolders(drAddressId, jobId).subscribe((value) => {
      expect(value).toBe(response);
    });
    const req = httpMock.expectOne(docPacUrl + `${drAddressId}/Jobs/${jobId}/DocumentFolder`);
    expect(req.request.method).toBe('GET');
    req.flush(response);
  }));

  it('getDocumentFolders should catch the error when http throws an error', () => {
    const spyPost = spyOn(httpClient, 'get').and.returnValue(Observable.of(true));
    spyPost.and.returnValue(throwError({ error: 'errorMan' }));
    service.getDocumentFolders(drAddressId, jobId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('errorMan'); });
  });

  it('should get file type details on calling getFileTypes', () => {
    const filetypes = [
      {
        createdBy: 'laflp',
        createdOn: '2020-12-28T04:51:10',
        jobDocumentTypeId: 1,
        isAvailableForUser: true,
        sequenceNumber: 1,
        status: 'C',
        typeAbstract: null,
        typeName: 'Contract',
        updatedBy: null,
        updatedOn: '0001-01-01T00:00:00',
      },
    ] as IFileTypesDetails[];
    spyOn(httpClient, 'get').and.returnValue(Observable.of(filetypes));
    service.getFileTypes().subscribe((res: IFileTypesDetails[]) => {
      expect(res).toEqual(filetypes);
    });
  });

  it('should get work packages on calling getWorkPackages', () => {
    const res = [
      { workPackageId: 5, workPackageName: 'rick was here' }
    ] as IWorkPackage[];
    spyOn(httpClient, 'get').and.returnValue(Observable.of(res));
    service.getWorkPackages(drAddressId, jobId).subscribe((value) => {
      expect(value).toBeDefined();
    });
  });

  it('should check error on service method calling getWorkPackages', () => {
    const spy = spyOn(httpClient, 'get').and.returnValue(Observable.of(true));
    spy.and.returnValue(throwError({ error: 'errorMan' }));
    service.getWorkPackages(drAddressId, jobId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('errorMan'); });
  });

  it('should get work package on calling getWorkPackage', () => {
    const res = {
      workPackageName: 'rick was here',
      salesCustomerDetail: {
        customerName: 'rick b'
      }
    } as IWorkPackageDetail;
    spyOn(httpClient, 'get').and.returnValue(Observable.of(res));
    service.getWorkPackage(drAddressId, workPackageId).subscribe((value) => {
      expect(value).toBeDefined();
    });
  });

  it('should check error on service method calling getWorkPackage', () => {
    const spy = spyOn(httpClient, 'get').and.returnValue(Observable.of(true));
    spy.and.returnValue(throwError({ error: 'errorMan' }));
    service.getWorkPackage(drAddressId, workPackageId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('errorMan'); });
  });

  it('should update existing document folder name on calling updateDocumentFolder', () => {
    const updatePayload = {
      folderId: 2,
      folderParentId: 1,
      drAddressId: 2,
      jobId: 1,
      folderName: 'New folder',
      folderSource: 'user',
    } as IDocumentFolderList;
    service.updateDocumentFolder(updatePayload).subscribe((value) => {
      expect(value).toBeDefined();
    });
    const request = httpMock.expectOne(docPacUrl + `${drAddressId}/Jobs/${jobId}/DocumentFolder/DocumentFolderName`);
    expect(request.request.method).toBe('PUT');
  });

  it(`should throw error when failed to update existing document folder name on calling updateDocumentFolder method`, () => {
    const updatePayload = {
      folderId: 3,
      folderParentId: 1,
      drAddressId: 0,
      jobId: 0,
      folderName: 'New folder 2',
      folderSource: 'user',
    } as IDocumentFolderList;
    spyOn(httpClient, 'put').and.returnValue(Observable.throwError({ error: 'error' }));
    service.updateDocumentFolder(updatePayload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
});
