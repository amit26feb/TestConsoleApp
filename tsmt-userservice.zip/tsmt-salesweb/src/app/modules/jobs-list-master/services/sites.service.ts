import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ISearchSiteListModel } from '../models/create-crm.model';

@Injectable()
export class SitesService {

  private BASE_URL = this.appconstants.API_BASE_URL_JOB;
  private sitesControllerUrl = '/Sites/Search';
  constructor(private http: HttpClient, private appconstants: AppConstants) { }

  public getCrmSites(drAddressId: number, skip, take, searchText: string, crmCompanyId: string): Observable<ISearchSiteListModel> {
    const options = new HttpParams().set('skip', skip)
      .set('take', take)
      .set('searchText', searchText)
      .set('crmCompanyId', crmCompanyId);
    return this.http.get<ISearchSiteListModel>(this.BASE_URL + '/' + drAddressId +
      this.sitesControllerUrl, { params: options }).map((res: ISearchSiteListModel) => res)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }
}
