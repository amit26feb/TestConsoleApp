import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';
@Injectable()
export class JobLockService {
  // The job lock information that the components need to share across the module
  lockInfo$ = new ReplaySubject<{
    jobLockUserId: string, readOnly: boolean, userId: string,
    nameFirst: string, nameLast: string, jobData: any,
  }>();

  constructor() { }

  setLockInfo(lockInfo) {
    this.lockInfo$.next(lockInfo);
  }

  getLockInfo() {
    return this.lockInfo$;
  }

}
