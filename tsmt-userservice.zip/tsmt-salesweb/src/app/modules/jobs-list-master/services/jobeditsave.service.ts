import { Injectable } from '@angular/core';

// enum to assign index to each section which inturn is used as the id
// in jobEditSaveStatus.
export enum JobSaveFormType {
  GeneralForm = 0,
  AddressForm = 1,
  OfficeForm = 2,
  CustomerForm = 3,
  DocumentsForm = 4,
  ClassificationForm = 5,
  DateForm = 6,
  IndicatorForm = 7,
  FinancialForm = 8,
  CompetitorForm = 9,
  JobNotesForm = 10,
  EarthwiseForm = 11,
}


@Injectable()
export class JobEditSaveService {

  public jobEditSaveStatus = [
    {
      id: JobSaveFormType.GeneralForm,
      formObj: null,
      callback: 'updateJobData',
      valid: true,
      name: 'General',
    },
    {
      id: JobSaveFormType.AddressForm,
      formObj: null,
      callback: 'UpdateAddressData',
      valid: true,
      name: 'Address',
    },
    {
      id: JobSaveFormType.OfficeForm,
      formObj: null,
      callback: 'updateOfficeAndPeople',
      valid: true,
      name: 'Office',
    },
    {
      id: JobSaveFormType.CustomerForm,
      formObj: null,
      callback: '',
      valid: true,
      name: 'Customers',
    },
    {
      id: JobSaveFormType.DocumentsForm,
      formObj: null,
      callback: '',
      valid: true,
      name: 'Documents',
    },
    {
      id: JobSaveFormType.ClassificationForm,
      formObj: null,
      callback: 'updateClassification',
      valid: true,
      name: 'Classifications',
    },
    {
      id: JobSaveFormType.DateForm,
      formObj: null,
      callback: 'UpdateDateForm',
      valid: true,
      name: 'Dates',
    },
    {
      id: JobSaveFormType.IndicatorForm,
      formObj: null,
      callback: 'UpdateIndicatorsForm',
      valid: true,
      name: 'Indicators',
    },
    {
      id: JobSaveFormType.FinancialForm,
      formObj: null,
      callback: 'UpdateFinancialForm',
      valid: true,
      name: 'Financial',
    },
    {
      id: JobSaveFormType.JobNotesForm,
      formObj: null,
      callback: 'UpdateNotesForm',
      valid: true,
      name: 'Job Notes',
    },
    {
      id: JobSaveFormType.EarthwiseForm,
      formObj: null,
      callback: 'UpdateEarthWiseSystem',
      valid: true,
      name: 'Earthwise',
    },
  ];

  constructor() { }


}


