import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { JobEditSaveService } from './jobeditsave.service';

describe('JobEditSaveService', () => {
  const originReset = TestBed.resetTestingModule;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [JobEditSaveService],
    });
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([JobEditSaveService], (service: JobEditSaveService) => {
    expect(service).toBeTruthy();
  }));
});
