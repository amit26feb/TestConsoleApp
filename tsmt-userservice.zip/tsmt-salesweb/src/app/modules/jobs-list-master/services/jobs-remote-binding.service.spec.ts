import { Component, Injectable } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { BehaviorSubject, Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { TraneSalesBusinessDataServiceMock } from '../../../shared/test-mocks/tranesalesbusinessdata-mock';
import { IJobDomainList } from '../modal/job-details-edit.model';
import { IOfficeSelectorModel } from '../modal/office-selector-model';
import { TraneSalesBusinessDataService } from '../services/trane-sales-business-data.service';

import { HttpClient, HttpErrorResponse, HttpHandler, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, fakeAsync, getTestBed, inject, TestBed } from '@angular/core/testing';
import { SortDescriptor } from '@progress/kendo-data-query';
import { LoaderService } from '../../../shared/services/loader.service';
import { JobsRemoteBindingService } from './jobs-remote-binding.service';

describe('JobsRemoteBindingService', () => {
    let injector: TestBed;
    let dataBindingService: JobsRemoteBindingService;
    let httpClient: HttpClient;
    let traneSalesBusinessDataService: TraneSalesBusinessDataService;
    const originReset = TestBed.resetTestingModule;
    const payload = {
        skip: 0,
        take: 20,
        sort: [
            {
                sortBy: 'lastUpdate',
                sortDirection: 'Descending',
            }],
        filters: [
            {
                ColumnFilters: [
                    {
                        field: 'drAddressId',
                        operator: 'Eq',
                        value: '122',
                    },
                ],
                logic: 'and',
            },
        ],
    };
    configureTestSuite(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [JobsRemoteBindingService, HttpClient, HttpHandler, AppConstants,
                { provide: TraneSalesBusinessDataService, useClass: TraneSalesBusinessDataServiceMock }],
        });

        injector = getTestBed();
        dataBindingService = injector.inject(JobsRemoteBindingService);
        traneSalesBusinessDataService = injector.inject(TraneSalesBusinessDataService);
        httpClient = TestBed.inject(HttpClient);
    });

    afterAll(() => {
        TestBed.resetTestingModule = originReset;
        TestBed.resetTestingModule();
    });

    it('should be created', inject([JobsRemoteBindingService], (service: JobsRemoteBindingService) => {
        expect(service).toBeTruthy();
    }));

    it('should fetch the data for job list on query', () => {
        const spy = spyOn(dataBindingService, 'fetch').and.returnValue(Observable.of(true));
        dataBindingService.query(payload);
        expect(spy).toHaveBeenCalled();
    });

    it('should fetch the data for job list', () => {
        dataBindingService.drAddressId = 122;
        const mockdata = [
            {
                jobId: 23,
                drAddressId: 78,
                jobName: 'AT03302019111019514',
                custChannelId: '$USD',
                sellingPrice: '$0',
                status: 'Open',
                commCode: 'Parts Sales [A01]',
            },
            {
                jobId: 22,
                drAddressId: 78,
                jobName: 'AT0329201920549643',
                custChannelId: '$USD',
                sellingPrice: '$0',
                status: 'Open',
                commCode: 'Todd Warvel [A00]',
            },
        ];

        const spy = spyOn(httpClient, 'post').and.returnValue(Observable.of({ jobList: mockdata, totalItemCount: 122 }));
        dataBindingService.fetch(payload).subscribe((response) => {
            expect(response.data).toEqual(mockdata);
            expect(response.total).toEqual(122);
        }, (error) => { });
        spy.and.returnValue(Observable.of(null));
        dataBindingService.fetch(payload).subscribe((response) => {
            expect(response.data).toEqual([]);
            expect(response.total).toEqual(0);
        }, (error) => { });
        spy.and.returnValue(Observable.throwError({ error: 'service error' }));
        dataBindingService.fetch(payload).subscribe((response) => {
        }, (error) => {
            expect(error.data).toEqual([]);
            expect(error.total).toEqual(0);
        });
    });
    it('should return empty result on error from service', () => {
        dataBindingService.drAddressId = 122;
        spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: { status: 404 } }));
        dataBindingService.fetch(payload).subscribe((response) => {
            expect(response.data).toEqual([]);
            expect(response.total).toEqual(0);
        }, (error) => { });
    });

    it('should be able to retrieve officeSelector on after setting it', () => {
        dataBindingService.officeSelector = 12;
        expect(dataBindingService.officeSelector).toBe(12);
    });


});
