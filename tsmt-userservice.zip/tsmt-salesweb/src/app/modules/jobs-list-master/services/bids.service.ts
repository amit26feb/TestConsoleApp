import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { BidsListModel } from '../../../shared/model/bids-model';
import { ProductFamilyDetailModel } from '../modal/product-family-detail-model';
import { DocumentValidationModel } from '../models/document-validation-model';

@Injectable()
export class BidsService {
  private SALESWEBGATEWAY_URL = this.appconstants.API_BASE_URL_SALESWEBGATEWAY;
  private BIDS_URL = this.appconstants.API_BASE_URL_BIDS;
  constructor(private http: HttpClient, private appconstants: AppConstants) { }

  /**
   * Calls salesweb gateway to get all the bids for a job.
   * Includes additional information regarding credit jobs and purchase orders.
   * @param drAddressId The VPD ID for the sales office
   * @param jobId The job ID to retrieve bids for
   */
  getBidsList(drAddressId, jobId) {
    return this.http.get<BidsListModel[]>(this.SALESWEBGATEWAY_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Bids');
  }

  /**
   * Calls salesweb gateway to get product families that exist on a bid.
   * @param drAddressId The VPD ID for the sales office
   * @param jobId The job ID associated with the bid.
   * @param bidAlternateId The bid ID to get product families for
   */
  getProductFamilies(drAddressId, jobId, bidAlternateId): Observable<ProductFamilyDetailModel[]> {
    return this.http.get<ProductFamilyDetailModel[]>
      (this.SALESWEBGATEWAY_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Bids/' + bidAlternateId + '/ProductFamilies');
  }

  /**
   * Gtes document validation for the bid.
   * @param drAddressId The VPD ID for the sales office
   * @param jobId The job ID associated with the bid.
   * @param bidAlternateId The bid ID to get product families for
   */
  getDocumentValidation(drAddressId, jobId, bidAlternateId): Observable<DocumentValidationModel> {
    return this.http.get<DocumentValidationModel>(`
      ${this.SALESWEBGATEWAY_URL}/${drAddressId}/Jobs/${jobId}/Bids/${bidAlternateId}/DocumentValidation`)
        .catch((error: any) => {
          return Observable.throwError(error);
        });
  }

  /**
   * Gets a list of bids associated with a job.  Does not include supplementary credit job or purchase order information.
   * @param drAddressId The VPD ID for the sales office
   * @param jobId The job ID to retrieve bids for
   */
  getBids(drAddressId, jobId) {
    return this.http.get<BidsListModel[]>(`${this.BIDS_URL}/v2/${drAddressId}/Jobs/${jobId}/Bids`);
  }

  // update selected current bids status in database
  updateCurrentBidsStatus(drAddressId, jobId, bidAlternateId) {
    const headers = new HttpHeaders();
    return this.http.post(`${this.BIDS_URL}/v1/${drAddressId}/Jobs/${jobId}/Bids/${bidAlternateId}/Status`, { headers })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // delete selected bid in database
  deleteBid(drAddressId, jobId, bidAlternateId) {
    return this.http.delete(`${this.BIDS_URL}/v2/${drAddressId}/Jobs/${jobId}/Bids/${bidAlternateId}`)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  /**
   * Creates a bid
   * @param drAddressId The VPD ID for the sales office.
   * @param jobId The job id to create the bid for.
   * @param data The bid info.
   */
  saveBids(drAddressId, jobId, data) {
    const headers = new HttpHeaders();
    return this.http.post(`${this.BIDS_URL}/v2/${drAddressId}/Jobs/${jobId}/Bids`, data, { headers })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  editBid(drAddressId, jobId, bidAlternateId, data) {
    return this.http.put(`${this.BIDS_URL}/v2/${drAddressId}/Jobs/${jobId}/Bids/${bidAlternateId}`, data)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  getBidSelections(drAddressId, jobId) {
    return this.http.get<any[]>(`${this.BIDS_URL}/v2/${drAddressId}/Jobs/${jobId}/Selections`)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  addSelectionsForBid(drAddressId, jobId, bidAlternateId, data) {
    return this.http.post(`${this.BIDS_URL}/v1/${drAddressId}/Jobs/${jobId}/Bids/${bidAlternateId}/Selections`, data)
      .catch((error) => {
        return Observable.throwError(error);
      });
  }

  deleteBidSelections(drAddressId, jobId, bidAlternateId, payload) {
    const options = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
      body: payload,
    };

    return this.http.delete(`${this.BIDS_URL}/v1/${drAddressId}/Jobs/${jobId}/Bids/${bidAlternateId}/Selections`, options)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }
}
