import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { IBidSelections, ICoordinateBidData, ICoordinatedata, ICoordinateRequest } from '../models/coordinate-job.model';
import { ICoordinateJob } from '../models/coordinate-job.model';
import { AppConstants } from './../../../shared/constants/constants';

@Injectable({ providedIn: 'root' })
export class CoordinateService {
  private BASE_URL = this.appConstants.API_BASE_URL_SALESWEBGATEWAY;
  private BASE_URL_JOB = this.appConstants.API_BASE_URL_JOB;
  private jobCoordinationLabel = 'JobCoordination';
  markJobForSubmitSubject: Subject<any> = new Subject();
  isJobMarkedForSubmit = false;

  constructor(private http: HttpClient, private appConstants: AppConstants) { }

  fetchCoordinateBidData(drAddressId, jobId): Observable<ICoordinateBidData> {
    return this.http.get<ICoordinateBidData>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/JobCoordination');
  }

  validateShipLeadTime(drAddressId, jobId, coordinationId) {
    return this.http.get(this.BASE_URL + '/' + drAddressId + '/Jobs/'
      + jobId + '/' + this.jobCoordinationLabel + '/' + coordinationId + '/ShippingLeadTime/Validate');
  }

  fetchCoordinateJobData(drAddressId, jobId, coordinationId): Observable<ICoordinateJob> {
    return this.http.get<ICoordinateJob>(this.BASE_URL_JOB + '/' + drAddressId + '/Jobs/' + jobId + '/JobCoordinationInfo/' +
     coordinationId);
  }

  fetchBidsWithSelections(drAddressId, jobId, selectedBids): Observable<IBidSelections[]> {
    return this.http
      .post<IBidSelections[]>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/JobCoordination/BillOfMaterialDetails', selectedBids)
      .pipe(map((res) => res ? res : []));
  }

  fetchCoordinateRequest(drAddressId, jobId): Observable<ICoordinateRequest[]> {
    return this.http.get<ICoordinateRequest[]>(this.BASE_URL_JOB + '/' + drAddressId + '/Jobs/' + jobId + '/JobCoordinationHistory');
  }

  saveCoordinateJobData(data, drAddressId, jobId) {
    return this.http.put(this.BASE_URL_JOB + '/' + drAddressId + '/JobCoordination/'
      + jobId + '/JobCoordination', data);
  }

  fetchCoordinateJobGeneralData(drAddressId: number, jobId: number): Observable<ICoordinatedata> {
    return this.http.get<ICoordinatedata>(this.BASE_URL + '/' + drAddressId + '/Jobs/'
           + jobId + '/JobCoordination/' + 'SubmittedJobInfo');
  }

  validateCoordinateRequest(drAddressId, jobId, coordinationId) {
    return this.http.get(this.BASE_URL + '/' + drAddressId + '/Jobs/'
      + jobId + '/' + this.jobCoordinationLabel + '/' + coordinationId + '/Submission/Validate');
  }

  submitJobForCoordination(drAddressId, jobId, coordinationId) {
    return this.http.get(this.BASE_URL + '/' + drAddressId + '/Jobs/'
      + jobId + '/' + this.jobCoordinationLabel + '/' + coordinationId + '/Submission');
  }

  getJobMarkedForSubmit() {
    return this.markJobForSubmitSubject.asObservable();
  }

  setJobMarkedForSubmit(flag: boolean) {
    if (flag && !this.isJobMarkedForSubmit) {
      this.isJobMarkedForSubmit = flag;
      this.markJobForSubmitSubject.next();
    } else {
      this.isJobMarkedForSubmit = flag;
    }
  }
}
