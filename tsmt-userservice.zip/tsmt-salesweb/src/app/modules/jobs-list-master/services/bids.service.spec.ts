import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { BidsService } from './bids.service';

// tslint:disable-next-line:no-big-function
describe('BidsService', () => {
  let bidsService: BidsService;
  let httpClient: HttpClient;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BidsService, AppConstants],
    });
    bidsService = TestBed.inject(BidsService);
    httpClient = TestBed.inject(HttpClient);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([BidsService], (service: BidsService) => {
    expect(service).toBeTruthy();
  }));

  it('should fetch bids list details', () => {
    bidsService.getBidsList(122, 59297).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should fetch product family details', () => {
    bidsService.getProductFamilies(122, 59297, 1991).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should fetch document validation', () => {
    bidsService.getDocumentValidation(122, 59297, 1991).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should update assigned current bids status', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternativeId = 1304;
    bidsService.updateCurrentBidsStatus(drAddressId, jobId, bidAlternativeId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should check error on service method updateCurrentBidsStatus', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternativeId = 1304;
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    bidsService.updateCurrentBidsStatus(drAddressId, jobId, bidAlternativeId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
  it('should delete selected bids', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternateId = 1304;
    bidsService.deleteBid(drAddressId, jobId, bidAlternateId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });
  it('should check error on service method deleteBid', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternateId = 1304;
    spyOn(httpClient, 'delete').and.returnValue(Observable.throwError({ error: 'error' }));
    bidsService.deleteBid(drAddressId, jobId, bidAlternateId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should save create bid details on saveBids', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const payload = {
      jobId,
      bidAlternateId: 0,
      baseBidYesNo: 0,
      bidName: 'Air Bid',
      currentBidInd: 'N',
      includeInCJ: 0,
      description: 'Air Bid Desc',
    };
    bidsService.saveBids(drAddressId, jobId, payload).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should check error on service method saveBids', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const payload = {
      jobId,
      bidAlternateId: 0,
      baseBidYesNo: 0,
      bidName: 'Air Bid',
      currentBidInd: 'N',
      includeInCJ: 0,
      description: 'Air Bid Desc',
    };
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    bidsService.saveBids(drAddressId, jobId, payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should make service call and return appropriate data on editBid', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternateId = 1304;
    spyOn(httpClient, 'put').and.returnValue(Observable.of({ Message: 'Edited Successfully' }));
    bidsService.editBid(drAddressId, jobId, bidAlternateId, {}).subscribe(() => {
    }, (res) => { expect(res.Message).toBe('Edited Successfully'); });
  });

  it('should through error when service call returns error on editBid', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternateId = 1304;
    spyOn(httpClient, 'put').and.returnValue(Observable.throwError({ error: 'error' }));
    bidsService.editBid(drAddressId, jobId, bidAlternateId, {}).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get bid selection and check error when getting bid selection list from getBidSelection ', () => {
    const jobId = 122;
    const drAddressId = 59297;
    bidsService.getBidSelections(drAddressId, jobId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });

    // check error when getting bids selection list
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    bidsService.getBidSelections(122, 1).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should delete bid cross reference selected bids', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternateId = 68844;
    const removePayload = {
      removeSelectionsRequest: [{ selectionId: 1 }],
      removeSeparatelyBiddablesRequest: [],
      removeVariationsRequest: [],
    };
    bidsService.deleteBidSelections(drAddressId, jobId, bidAlternateId, removePayload).subscribe((data: any) => {
      expect(data).toBe(true);
    });
  });

  it('should check error on service method deleteBidSelections', () => {
    const jobId = 122;
    const drAddressId = 59297;
    const bidAlternateId = 0;
    const removePayload = {
      removeSelectionsRequest: [],
      removeSeparatelyBiddablesRequest: [],
      removeVariationsRequest: [],
    };
    spyOn(httpClient, 'delete').and.returnValue(Observable.throwError({ error: 'error' }));
    bidsService.deleteBidSelections(drAddressId, jobId, bidAlternateId, removePayload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should save selections on addSelectionsForBid', () => {
    const bidAlternateId = 122;
    const jobId = 77;
    const drAddressId = 59297;
    const payload = {
      selectionDetails: [{
        selectionId: 2,
        excludeSelection: true,
        separatelyBiddableViewModel: [
          {
            separatelyBiddableId: 11,
          },
        ],
        variationViewModel: [
          {
            variationId: 12,
          },
        ],
      },
      ],
      jobVariations: [
        {
          variationId: 44,
        },
      ],
    };
    bidsService.addSelectionsForBid(drAddressId, jobId, bidAlternateId, payload).subscribe((data: any) => {
      expect(data).toBe(true);
    });
  });
  it('should check error on service method addSelectionsForBid', () => {
    const bidAlternateId = 0;
    const jobId = 77;
    const drAddressId = 59297;
    const payload = {
      selectionDetails: [{
        selectionId: 2,
        excludeSelection: true,
        separatelyBiddableViewModel: [],
        variationViewModel: [],
      },
      ],
      jobVariations: [],
    };
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    bidsService.addSelectionsForBid(drAddressId, jobId, bidAlternateId, payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
});
