import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ISaveCrmModel } from '../models/create-crm.model';

@Injectable({
  providedIn: 'root'
})
export class CreateCrmService {
  private SALESWEBGATEWAY_URL = this.appconstants.API_BASE_URL_SALESWEBGATEWAY;

  constructor(private http: HttpClient, private appconstants: AppConstants) { }

  public createCrmJob(drAddressId: number, saveCrmPayload: ISaveCrmModel): Observable<number> {
    return this.http.post<number>(this.SALESWEBGATEWAY_URL + '/' + drAddressId + '/CrmJobs', saveCrmPayload)
      .map((res: number) => res)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }
}
