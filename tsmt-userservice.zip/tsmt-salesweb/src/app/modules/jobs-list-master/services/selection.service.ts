import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { SelectionlistModel } from '../../../shared/model/selectionlist-model';

@Injectable()
export class SelectionService {
  sortParameter = new BehaviorSubject<any>([{ field: 'sequenceNumber', dir: 'asc' }]);
  sortParameterValue$ = this.sortParameter.asObservable();

  sortParameterNonTrane = new BehaviorSubject<any>([{ field: 'variationType', dir: 'asc' }]);
  sortParameterNonTraneValue$ = this.sortParameterNonTrane.asObservable();

  private BASE_URL = this.appconstants.API_BASE_URL_JOB_SELECTION;

  constructor(
    private http: HttpClient,
    private appconstants: AppConstants) { }

  sortValue(sortingVal) {
    this.sortParameter.next(sortingVal);
  }

  sortValueNonTrane(sortingVal) {
    this.sortParameterNonTrane.next(sortingVal);
  }

  getSelectionListData(data, drAddressId, jobId): Observable<any> {
    return this.http.post<SelectionlistModel>(this.BASE_URL + '/' + drAddressId + '/Jobs/'
      + jobId + '/Selections/TraneItems', data)
      .map(
        (response: SelectionlistModel) => {
          if (response !== null && response.selectionList) {
            response.selectionList.map((x) => {
              x.reviseDate = x.reviseDate ? new Date(x.reviseDate) : '';
            });
          }
          return response;
        }, (error) => {
          console.error('selection.service::getSelectionListData: %o', error);
        });
  }

  getNonTraneData(data, drAddressId, jobId): Observable<any> {
    return this.http.post<any>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/NonTraneItems/Search', data);
  }
}
