import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';

@Injectable()
export class JobSelectionService {
  constructor(private http: HttpClient, private appconstants: AppConstants) { }

  // get bid cross reference data from salewebgateway api
  getBidsCrossReferenceData(drAddressId, jobId) {
    return this.http.get<any[]>(this.appconstants.API_BASE_URL_SALESWEBGATEWAY + '/'
      + drAddressId + '/Jobs/' + jobId + '/Bids/JobSelections')
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

}
