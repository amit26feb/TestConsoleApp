import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { DocumentDetails } from '@tsmt/shared-acquisition-dataservices';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ICustomSenderDetails } from '../documents/models/custom-sender-details';
import {
  IClassificationModel, ICountryModel, IEarthwiseSystemModel, IEditJobModel, IPostalMasterModel, IShipToAddress,
} from '../modal/job-details-edit.model';
import { IOfficeSelectorModel } from '../modal/office-selector-model';
import { IAllJobInfoModel } from '../models/all-job-info-model';
import { IDocumentDetails, IDocumentDetailsList } from '../models/document-files-model';
import { SharePointDocumentDetail } from '../models/share-point-document-detail-model';


@Injectable()
export class JobsServicesService {
  sortParameter = new BehaviorSubject<any>([{ field: 'joB_NAME', dir: 'asc' }]);
  summarySelectionSubject = new BehaviorSubject<number>(0);
  sortParameterValue$ = this.sortParameter.asObservable();
  private BASE_URL = this.appconstants.API_BASE_URL_JOB;
  public BUSINESSDATA_URL = this.appconstants.BUSINESSDATA_BASE_URL;
  public BUSINESSDATA_CONTEXT = '/BusinessDataService/';
  public SALESWEBGATEWAY_URL = this.appconstants.API_BASE_URL_SALESWEBGATEWAY;
  jobId: number;
  drAddressId: number;
  jobReportId: number;
  salesOfficeId: number;
  sort = [{ field: 'lastUpdate', dir: 'desc' }];
  private params: any;
  public latestJobName$ = new Subject<string>();

  constructor(private http: HttpClient, private appconstants: AppConstants) { }

  setSortConfig(sort) {
    this.sort = sort;
  }

  getSortConfig() {
    return this.sort;
  }

  setJobReportId(jobReportId) {
    this.jobReportId = jobReportId;
  }
  getJobReportId() {
    return this.jobReportId;
  }
  setSalesOfficeId(officeId) {
    this.salesOfficeId = officeId;
  }
  getSalesOfficeId() {
    return this.salesOfficeId;
  }
  // when changed job name in details page we set updated job name in latestJobName$
  public latestJobName(jobName) {
    this.latestJobName$.next(jobName);
  }

  LockAndUnLockJob(data): Observable<any> {
    const options = new HttpParams()
      .set('lockJob', data.lockJob)
      .set('App', 'SalesWeb')
      .set('allowLockOverride', data.allowLockOverride);    // override can only be true when 'Locked by another user' dialog was displayed

    return this.http.post(this.BASE_URL + '/' + data.drAddressId + '/Jobs/' + data.jobId, data, { params: options })
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }

  // SalesOffices Get OfficeSelector
  getOfficeSelector() {
    return this.http.get<IOfficeSelectorModel[]>(this.BASE_URL + '/Jobs/SalesOffices')
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // CreateJob Creates a Job
  CreateJob(data): Observable<any> {
    const headers = new HttpHeaders();
    return this.http.post(this.BASE_URL + '/' + data.drAddressId + '/Jobs', data, { headers })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }
  fetchformData(data) {
    return this.http.post<any>(this.BASE_URL + '/Job/GetEditJobListByOptions', data);
  }

  getJobAllInfo(drAddressId: number, jobId: number): Observable<IAllJobInfoModel> {
    return this.http.get<IAllJobInfoModel>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/AllInfo');
  }

  getJobUpdateData(data, key) {
    if (key === 'Classification' || key === 'Earthwise') {
      return this.http.put(this.BASE_URL + '/' + data.drAddressId + '/Jobs/' + data.jobId, data);
    } else {
      return this.http.put(this.BASE_URL + '/' + data[key].drAddressId + '/Jobs/' + data[key].jobId, data);
    }
  }

  fetchJobDetails(jobId, drAddressId): Observable<IEditJobModel> {
    return this.http.get<IEditJobModel>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId);
  }

  // CommissionCode and JobContact
  GetJobContactAndCommCode(salesOfficeId) {
    const options = new HttpParams().set('salesOfficeId', salesOfficeId);
    return this.http.post<any[]>(this.BASE_URL + '/Job/GetJobContactAndCommCode', options)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }
  getCountryCode(data) {
    const options = new HttpParams().set('search', data);
    return this.http.get<ICountryModel[]>(this.BUSINESSDATA_URL + this.BUSINESSDATA_CONTEXT + 'Countries', { params: options });
  }
  getPostalCode(data) {
    const options = new HttpParams().set('search', data);
    return this.http.get<IPostalMasterModel[]>(this.BUSINESSDATA_URL + this.BUSINESSDATA_CONTEXT + 'PostalCodes', { params: options });
  }

  loadJobNotes(data) {
    return this.http.post(this.BASE_URL + '/Jobs/InsertNotes', data);
  }

  EarthwiseSystemDetails(jobId, drAddressId): Observable<IEarthwiseSystemModel> {
    return this.http.get<IEarthwiseSystemModel>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/SystemTypes');
  }

  editClassificationDetails(drAddressId, jobId) {
    return this.http.get<IClassificationModel[]>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Classifications');
  }

  getSelectedClassifications(drAddressId, jobId) {
    return this.http.get<IClassificationModel[]>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/ClassificationsById');
  }

  assignCustomer(data, drAddressId): Observable<any> {
    const headers = new HttpHeaders();
    return this.http.post(this.BASE_URL + '/' + drAddressId + '/Jobs/' + data.jobId + '/AssignCustomer', data, { headers })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  saveCustomerContact(drAddressId, data): Observable<GridDataResult> {
    return this.http.put<GridDataResult>(this.BASE_URL + '/' + drAddressId +
      '/SalesCustomer/PutAndPostContacts', data);

  }
  // Get Role By List
  getJobRoleTypes(drAddressId: any): Observable<any[]> {
    return this.http.get<any[]>(this.BASE_URL + '/' + drAddressId + '/Jobs/RoleTypes')
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // Get Locked User details based on Job
  getJobLockedUserDetails(drAddressId, jobId) {
    return this.http.get<any[]>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/LockedUser')
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  getDocumentList(drAddressId: number, jobId: number, documentTypeId: number, folderId: number, skip: number
    , take: number): Observable<IDocumentDetailsList> {
    const options = new HttpParams().set('drAddressId', drAddressId.toString()).set('jobId', jobId.toString())
      .set('documentTypeId', documentTypeId.toString()).set('folderId', folderId.toString())
      .set('skip', skip.toString()).set('take', take.toString());
    return this.http.get<IDocumentDetailsList>(this.SALESWEBGATEWAY_URL + '/Document', { params: options })
      .map((res: IDocumentDetailsList) => res)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }

  // Get document history details based on drAddressId, jobId, documentName and folderId
  getJobDocumentHistoryDetails(drAddressId: number, jobId: number, documentName: string, folderId: number): Observable<DocumentDetails[]> {
    const options = new HttpParams().set('documentName', documentName).set('folderId', folderId.toString());
    return this.http.get<DocumentDetails[]>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/DocumentHistory', { params: options })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  deleteDocument(drAddressId, jobId, documentKey) {
    const options = new HttpParams().set('documentKey', documentKey);
    return this.http.delete(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Document', { params: options })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  /**
   * Get resourse url of the document that is moved to share point
   * @param- job id -Job id for which going to fetch shipping instruction.
   * @param- drAddressId - Against this dr address id we are going to execute the query.
   * @param- documentKey -Document Key
   * @param- documentVersion - Document version
   * @param- documentStorage - Document storage location
   */
  downloadDocument(drAddressId: number, jobId: number, documentKey: string, documentVersion: string,
    documentStorage: string): Observable<{ file: Blob }> {
    const options = new HttpParams().set('documentKey', documentKey).set('documentVersion', documentVersion)
      .set('documentStorage', documentStorage);
    const url = `${this.BASE_URL}/${drAddressId}/Jobs/${jobId}/Document/Download`;
    return this.http.get(url, { observe: 'response', responseType: 'blob', params: options })
      .map((res) => {
        return {
          file: new Blob([res.body], { type: res.headers.get('Content-Type') }),
        };

      }).catch((err) => {
        return Observable.throwError(err);
      });
  }
  transmitJob(data): Observable<any> {
    return this.http.post(this.BASE_URL + '/' + data.sourceDrAddressId + '/Jobs' + '/' + data.sourceJobId + '/Transmit', data,
      { responseType: 'text' })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }
  exportJob(data): Observable<any> {
    return this.http.post(this.SALESWEBGATEWAY_URL + '/' + data.sourceDrAddressId + '/Jobs' + '/' + data.sourceJobId + '/ExportJob/Export',
      data)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  importJob(data): Observable<any> {
    return this.http.post(this.BASE_URL + '/Jobs/ImportJob',
      data, { responseType: 'text' })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  getJobBasicInfo(jobId: number, drAddressId: number) {
    return this.http.get<any>(this.BASE_URL + '/' + drAddressId + '/jobs/' + jobId + '/BasicInfo');
  }

  /**
   * Load grid data with initial shiping instruction values.
   * @param- job id -Job id for which going to fetch shipping instruction.
   * @param- drAddressId - Against this dr address id we are going to execute the query.
   */
  getBasicShippingInstruction(jobId: number, drAddressId: number): Observable<IShipToAddress> {
    return this.http.get<IShipToAddress>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Shipments/ShipTo');
  }

  /**
   * Get the maximum shipping instruction id using by the job id.
   * @param- job id -Job id for which going to fetch shipping instruction.
   * @param- drAddressId - Against this dr address id we are going to execute the query.
   */
  getMaxShippingInstructionID(jobId: number, drAddressId: number): Observable<number> {
    return this.http.get<number>(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Shipments/ShippingInstructionId');
  }

  getFollowedJobCount(drAddressId: number): Observable<any> {
    return this.http.get<any>(this.BASE_URL + '/' + drAddressId + '/Jobs/Favorites/Count');
  }

  updateFavorite(drAddressId: number, jobId: number): Observable<object> {
    return this.http.put(this.BASE_URL + '/' + drAddressId + '/Jobs/' + jobId + '/Favorites', null);
  }

  getCustomSenderDetails(drAddressId: number): Observable<ICustomSenderDetails[]> {
    const url = this.BASE_URL + '/' + drAddressId + '/CustomSender';
    return this.http.get<ICustomSenderDetails[]>(url);
  }

  // creates a new custom sender
  createCustomSender(drAddressId: number, data) {
    const url = this.BASE_URL + '/' + drAddressId + '/CustomSender';
    return this.http.post(url, { customSender: data })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // updates existing custom sender
  updateCustomSender(drAddressId: number, data) {
    const url = this.BASE_URL + '/' + drAddressId + '/CustomSender';
    return this.http.put(url, { customSender: data })
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // deletes existing custom sender
  deleteCustomSender(drAddressId: number, customSenderId) {
    const url = this.BASE_URL + '/' + drAddressId + '/CustomSender/' + customSenderId;
    return this.http.delete(url)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  /**
   * Get country from country code.
   * @param- countryCode - Country code for which we are going to fetch country.
   */
  getCountryFromCountryCode(countryCode: string): Observable<ICountryModel> {
    const options = new HttpParams().set('countryCode', countryCode);
    return this.http.get<ICountryModel>(this.BUSINESSDATA_URL + this.BUSINESSDATA_CONTEXT + 'Country', { params: options });
  }

  /**
   * Get resourse url of the document that is moved to share point
   * @param- job id -Job id for which going to fetch shipping instruction.
   * @param- drAddressId - Against this dr address id we are going to execute the query.
   * @param- fileUploadInfo -Object that contains the details of the document.
   * @param- folderName - The folder in which that document needs to be moved.
   * @param- folderId - folder id of the document
   */
  moveDocumentToSharePoint(drAddressId: number, jobId: number, fileUploadInfo: IDocumentDetails,
    folderName: string, folderId: number): Observable<SharePointDocumentDetail> {
    const url = `${this.SALESWEBGATEWAY_URL}/Document/Move?JobId=${jobId}&DrAddressId=${drAddressId}&DocumentStorage=${fileUploadInfo.documentStorage}&JobDocumentId=${fileUploadInfo.jobDocumentId}&DocumentKey=${fileUploadInfo.documentKey}&DocumentName=${encodeURIComponent(fileUploadInfo.documentName)}&FolderName=${folderName}&folderId=${folderId}&documentPackageId=${fileUploadInfo.documentPackageId}&documentVersion=${fileUploadInfo.documentVersion}&docTypeId=${fileUploadInfo.docTypeId}`;
    return this.http.post<SharePointDocumentDetail>(url, null)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }
}
