import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, getTestBed, inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';

import { AppConstants } from '../../../shared/constants/constants';
import { SelectionService } from './selection.service';

import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';

describe('SelectionService', () => {
  const originReset = TestBed.resetTestingModule;
  let injector: TestBed;
  let selectionService: SelectionService;
  let httpMock: HttpTestingController;
  let appConstant: AppConstants;
  const drAddressId = 126;
  const jobId = 3875;
  const payload = {
    skip: 0,
    take: 20,
    sort: [
      {
        sortBy: 'sequenceNumber',
        sortDirection: 'Ascending',
      },
    ],
  };
  let selectionUrl;
  let nonTraneUrl;
  const selectionResponse = {
    pageNumber: 1,
    pageSize: 10,
    totalItemCount: 1,
    pageCount: 1,
    selectionList: [{
      isconfiguredItem: 1,
      pricedIndicator: 'P',
      description: 'Indoor Gas Heating Products',
      selectionId: 987654,
      listPrice: 5045,
      qty: 2,
      tag: 'ABC-123',
      productFamily: 'ZYXW',
      orderedIndicator: 'C',
      reviseDate: '04/10/2006 17:42:42',
    },
    {
      isconfiguredItem: 3875,
      pricedIndicator: 'NP',
      description: 'Indoor Gas Heating Products',
      selectionId: 987654,
      listPrice: 5045,
      qty: 2,
      tag: 'ABC-123',
    }],
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [SelectionService, AppConstants],
      imports: [HttpClientTestingModule],
    });

    injector = getTestBed();
    selectionService = injector.inject(SelectionService);
    httpMock = injector.inject(HttpTestingController);
    appConstant = injector.inject(AppConstants);
    selectionUrl = appConstant.API_BASE_URL_JOB_SELECTION + '/' + drAddressId + '/Jobs/'
      + jobId + '/Selections/TraneItems';
    nonTraneUrl = appConstant.API_BASE_URL_JOB_SELECTION + '/' + drAddressId + '/Jobs/'
      + jobId + '/NonTraneItems/Search';

  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([SelectionService], (service: SelectionService) => {
    expect(service).toBeTruthy();
  }));

  it('"getSelectionListData()" should return grid data with date objects', fakeAsync(() => {
    selectionService.getSelectionListData(payload, drAddressId, jobId).subscribe((data) => {
      expect(data.selectionList.length).toBeGreaterThan(0);
      expect(data.selectionList[0].reviseDate).toEqual(new Date('04/10/2006 17:42:42'));
      expect(data.selectionList[1].reviseDate).toBe('');
    });
    const req = httpMock.expectOne(selectionUrl);
    expect(req.request.method).toEqual('POST');
    req.flush(selectionResponse);
  }));

  it('"getSelectionListData()" should return null when service response is null', fakeAsync(() => {
    selectionService.getSelectionListData(payload, drAddressId, jobId).subscribe((data) => {
      expect(data).toBe(null);
    });
    const req = httpMock.expectOne(selectionUrl);
    req.flush(null);
  }));

  it('"getSelectionListData()" should throw error when service throws error', fakeAsync(() => {
    spyOn(console, 'error');
    selectionService.getSelectionListData(payload, drAddressId, jobId).subscribe((data) => {
    },
      (err) => {
        expect(console.error).toHaveBeenCalled();
      });
    const req = httpMock.expectOne(selectionUrl);
    expect(req.request.method).toEqual('POST');
    req.flush(Observable.throwError({ status: 404 }));
  }));

  it('should set the sortParameter$ on sortValue', inject([SelectionService], (service: SelectionService) => {
    service.sortValue([{ field: 'prodGroup', dir: 'down' }]);
    const subscription = service.sortParameterValue$.subscribe((res) => {
      expect(res[0].field).toBe('prodGroup');
      expect(res[0].dir).toBe('down');
    });
    subscription.unsubscribe();
  }));

  it('should set the sortParameterNonTraneValue$ on sortValueNonTrane', inject([SelectionService], (service: SelectionService) => {
    service.sortValue([{ field: 'variationType', dir: 'asc' }]);
    const subscription = service.sortParameterNonTraneValue$.subscribe((res) => {
      expect(res[0].field).toBe('variationType');
      expect(res[0].dir).toBe('asc');
    });
    subscription.unsubscribe();
  }));

  it('should return non trane grid data on calling getNonTraneData', fakeAsync(() => {
    selectionService.getNonTraneData(payload, drAddressId, jobId).subscribe((data) => {
      expect(data.selectionList.length).toBeGreaterThan(0);
    });
    const req = httpMock.expectOne(nonTraneUrl);
    expect(req.request.method).toEqual('POST');
    req.flush(selectionResponse);
  }));

});
