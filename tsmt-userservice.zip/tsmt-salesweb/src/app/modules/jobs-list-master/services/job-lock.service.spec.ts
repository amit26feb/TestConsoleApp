import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { JobLockService } from './job-lock.service';

describe('JobLockService', () => {
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [JobLockService],
    });
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([JobLockService], (service: JobLockService) => {
    expect(service).toBeTruthy();
  }));

  it('should emit the lockInfo on calling setLockInfo', inject([JobLockService], (service: JobLockService) => {
    const lockInfo = {
      jobLockUserId: 'ccfbsb', readOnly: false, userId: 'ccfb',
      nameFirst: 'TestCase', nameLast: 'Developer', jobData: { jobId: 10 },
    };
    const lock = service.getLockInfo();
    service.setLockInfo(lockInfo);
    lock.subscribe((lockVal) => { expect(lockVal).toBe(lockInfo); });
  }));
});
