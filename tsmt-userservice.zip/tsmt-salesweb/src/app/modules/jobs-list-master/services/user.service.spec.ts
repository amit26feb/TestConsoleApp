import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { IDashboardPreference } from '../../../shared/model/dashboard-preferences';
import { AppConstants } from '../../../shared/constants/constants';
import { IActiveDirectory, IGridState, IUserModel } from '../models/user-model';
import { UserService } from './user.service';

describe('UserService', () => {
  let service: UserService;
  let appConstants: AppConstants;
  let httpMock: HttpTestingController;
  const originReset = TestBed.resetTestingModule;
  const emailAddress = 'ron@trane.com';

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UserService, AppConstants],
    });
    service = TestBed.inject(UserService);
    appConstants = TestBed.inject(AppConstants);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return user models returned from http post', () => {
    const payload = ['julia', 'raja', 'anusha', 'vikram', 'troy'];
    const response = [
      { userId: 'julia', firstName: 'Julia', lastName: 'Froegel' },
      { userId: 'raja', firstName: 'Raja', lastName: 'K' },
    ] as IUserModel[];
    service.getUsers(payload).subscribe((value) => {
      expect(value).toBe(response);
    });
    const req = httpMock.expectOne(appConstants.API_BASE_URL_USER + '/Users/Search');
    expect(req.request.body).toBe(payload);
    expect(req.request.method).toBe('POST');
    req.flush(response);
  });

  it('should return user detail', () => {
    const jobContactDetails = {
      firstName: 'Ron',
      lastName: 'John',
    };
    service.getUserDetails(emailAddress).subscribe((value) => {
      expect(value.firstName).toBe(jobContactDetails.firstName);
      expect(value.lastName).toBe(jobContactDetails.lastName);
    });

    const req = httpMock.expectOne(appConstants.API_BASE_URL_USER + '/Users/UserDetail?emailId=' + emailAddress);
    expect(req.request.method).toBe('GET');
    req.flush(jobContactDetails);
  });

  it('should get grid state preferences about grid', () => {
    const userId = 'ccebpe';
    const route = 'I90';
    const gridId = 'griddle';
    const preferenceName = 'DefaultView';

    const res: IGridState = {
      gridPreferenceId: '12345',
      userId,
      applicationId: appConstants.applicationId,
      route,
      gridName: gridId,
      gridPreferenceName: preferenceName,
      gridPreferenceSetting: 'Full Rollup',
      isPublic: true,
      isDefault: true,
    };

    service.getGridStates(userId, route, gridId).subscribe((x) => {
      expect(x[0].applicationId).toEqual(appConstants.applicationId);
      expect(x[0].gridPreferenceId).toEqual('12345');
      expect(x[0].userId).toEqual(userId);
      expect(x[0].route).toEqual(route);
      expect(x[0].gridName).toEqual(gridId);
      expect(x[0].gridPreferenceName).toEqual(preferenceName);
      expect(x[0].gridPreferenceSetting).toEqual('Full Rollup');
      expect(x[0].isPublic).toBeTruthy();
      expect(x[0].isDefault).toBeTruthy();
    });

    const req = httpMock.expectOne(`${appConstants.API_BASE_URL_USER}/User/${userId}/Preferences` +
      `/GridState?appId=${appConstants.applicationId}&route=${route}&gridId=${gridId}`);
    expect(req.request.method).toBe('GET');
    req.flush([res]);
  });

  it('should create grid state to remember user preference', () => {
    const userId = 'ccebpe';

    const newGrid: IGridState = {
      gridPreferenceId: 'abcd',
      userId,
      applicationId: appConstants.applicationId,
      route: 'losey',
      gridName: 'grit',
      gridPreferenceName: 'DefaultView',
      gridPreferenceSetting: 'Mini Rollup',
      isPublic: true,
      isDefault: true,
    };

    service.createGridState(userId, newGrid).subscribe();

    const req = httpMock.expectOne(`${appConstants.API_BASE_URL_USER}/User/${userId}/Preferences/GridState`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ GridPreference: newGrid });
    req.flush({});
  });

  it('should update grid state on user preference', () => {
    const userId = 'ccebpe';

    const newGrid: IGridState = {
      gridPreferenceId: 'afoejfefo',
      userId,
      applicationId: appConstants.applicationId,
      route: 'street',
      gridName: 'name',
      gridPreferenceName: 'CatView',
      gridPreferenceSetting: 'Kitten Rollup',
      isPublic: true,
      isDefault: true,
    };

    service.updateGridState(userId, newGrid).subscribe();

    const req = httpMock.expectOne(`${appConstants.API_BASE_URL_USER}/User/${userId}/Preferences/GridState`);
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual(newGrid);
    req.flush({});
  });

  it('should get data from active directory', () => {
    const searchText = 'John';

    const activeDirectory: IActiveDirectory[] = [{
      businessPhones: [],
      displayName: 'John, david',
      givenName: 'David',
      jobTitle: 'Project Manager',
      mail: 'david.john@ir.com',
      mobilePhone: '398909019',
      officeLocation: 'La crosse',
      surname: 'John',
      userPrincipalName: null,
      onPremisesSamAccountName: 'tsmcm365',
    },
    {
      businessPhones: [],
      displayName: 'John, harpid',
      givenName: 'Harpid',
      jobTitle: 'Financial Manager',
      mail: 'harpid.john@ir.com',
      mobilePhone: '232090019',
      officeLocation: 'La crosse',
      surname: 'John',
      userPrincipalName: null,
      onPremisesSamAccountName: 'tsmml365',
    }];

    service.getUsersFromActiveDirectory(searchText).subscribe((value) => {
      expect(value[0]).toBe(activeDirectory[0]);
    });

    const req = httpMock.expectOne(appConstants.API_BASE_URL_USER + '/Users/ActiveDirectory/Search?searchText=' + searchText);
    expect(req.request.method).toBe('GET');
    req.flush(activeDirectory);
  });

  it('should get dashboard preferences on call to getDashboardPreferences', (done) => {
    const dashboardPreference: IDashboardPreference = {
      tiles: [{ name: 'asdf', isVisible: true, sequence: 1 }],
    };

    service.getDashboardPreferences().subscribe((resp) => {
      expect(resp).toBe(dashboardPreference);
      done();
    });

    const req = httpMock
      .expectOne(`${appConstants.API_BASE_URL_USER}/Applications/${appConstants.applicationId}/Preferences/Dashboard`);

    expect(req.request.method).toBe('GET');
    req.flush(dashboardPreference);
  });

  it('should set dashboard preferences on call to setDashboardPreferences', (done) => {
    const dashboardPreference: IDashboardPreference = {
      tiles: [{ name: 'asdf', isVisible: true, sequence: 1 }],
    };

    service.setDashboardPreferences(dashboardPreference).subscribe((resp) => done());

    const req = httpMock
      .expectOne(`${appConstants.API_BASE_URL_USER}/Applications/${appConstants.applicationId}/Preferences/Dashboard`);

    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toBe(dashboardPreference);
    req.flush(dashboardPreference);
  });
});
