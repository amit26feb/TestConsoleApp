import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { Router, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { ExitJobService } from './exit-job.service';

import { ApiErrorService } from '../../../shared/services/apierror.service';
import { JobHeaderService } from '../../../shared/services/job-header.service';
import { ApiErrorServiceMock } from '../../../shared/test-mocks/apierrorservice-mock';
import { JobListServiceMock } from '../../../shared/test-mocks/jobService-mock';
import { JobsServicesService } from '../services/jobs-services.service';

import { AppConstants } from '../../../shared/constants/constants';

describe('ExitJobService', () => {
  let injector: TestBed;

  let service: ExitJobService;

  let appConstant: AppConstants;
  let apiErrorService: ApiErrorService;
  let jobHeaderService: JobHeaderService;
  let jobService: JobsServicesService;
  let router: Router;
  const originReset = TestBed.resetTestingModule;
  const TestRoutes: Routes = [
    {
      path: '**',
      component: ExitJobService,
    },
  ];

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes(TestRoutes),
      ],
      providers: [
        AppConstants,
        { provide: ApiErrorService, useClass: ApiErrorServiceMock },
        ExitJobService,
        JobHeaderService,
        { provide: JobsServicesService, useClass: JobListServiceMock },
      ],
    });
  });

  beforeEach(() => {
    injector = getTestBed();

    service = injector.inject(ExitJobService);
    appConstant = injector.inject(AppConstants);
    apiErrorService = injector.inject(ApiErrorService);
    jobHeaderService = injector.inject(JobHeaderService);
    jobService = injector.inject(JobsServicesService);
    router = injector.inject(Router);

    jobHeaderService.setUserId('xxabc');
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should close tab when locked by different user', () => {
    const spy = spyOn(service, 'closeJob').and.callThrough();
    const spyHeader = spyOn(jobHeaderService, 'clearJob');
    const spyJob = spyOn(jobService, 'LockAndUnLockJob');

    service.CloseAndExitJob(123, 94, 'xxxzz');

    expect(spy).toHaveBeenCalledWith(true);
    expect(spyHeader).toHaveBeenCalledTimes(1);
    expect(spyJob).toHaveBeenCalledTimes(0);
  });

  it('should close tab when locked by current user', () => {
    const spyWindow = spyOn(window, 'close');
    const spy = spyOn(service, 'closeJob').and.callThrough();
    const spyHeader = spyOn(jobHeaderService, 'clearJob');
    const spyJob = spyOn(jobService, 'LockAndUnLockJob').and.callThrough();

    service.CloseAndExitJob(123, 94, 'xxabc');

    expect(spy).toHaveBeenCalledWith(false);
    expect(spyHeader).toHaveBeenCalledTimes(1);
    expect(spyJob).toHaveBeenCalledTimes(1);
    expect(spyWindow).toHaveBeenCalled();
  });

  it('should close tab when current user had lock stolen', () => {
    const spy = spyOn(service, 'closeJob').and.callThrough();
    const spyHeader = spyOn(jobHeaderService, 'clearJob');
    const spyJob = spyOn(jobService, 'LockAndUnLockJob').and.returnValue(Observable.throwError({ status: 409 }));

    service.CloseAndExitJob(123, 94, 'xxabc');

    expect(spy).toHaveBeenCalledWith(true);
    expect(spyHeader).toHaveBeenCalledTimes(1);
    expect(spyJob).toHaveBeenCalledTimes(1);
  });

  it('should close tab and display error when unlock call failed', () => {

    const spy = spyOn(service, 'closeJob').and.callThrough();
    const spyApi = spyOn(apiErrorService, 'show');
    const spyHeader = spyOn(jobHeaderService, 'clearJob');
    const spyJob = spyOn(jobService, 'LockAndUnLockJob').and.returnValue(Observable.throwError({
      status: 500,
      error: {
        Message: 'failure message',
      },
    }));

    service.CloseAndExitJob(123, 94, 'xxabc');

    expect(spy).toHaveBeenCalledWith(false);
    expect(spyApi).toHaveBeenCalledTimes(1);
    expect(spyApi).toHaveBeenCalledWith('failure message');
    expect(spyHeader).toHaveBeenCalledTimes(1);
    expect(spyJob).toHaveBeenCalledTimes(1);
  });
});
