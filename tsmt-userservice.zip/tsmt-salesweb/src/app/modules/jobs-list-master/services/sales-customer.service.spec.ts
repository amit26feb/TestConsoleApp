import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, inject, TestBed, tick, discardPeriodicTasks, flushMicrotasks, flush } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ISearchCustomerListModel } from '../modal/job-details-edit.model';
import { SalesCustomerServiceMock } from './../../../shared/test-mocks/sales-customer-mock';
import { IContact, ISearchContactListModel } from './../models/create-crm.model';
import { SalesCustomerService } from './sales-customer.service';

// tslint:disable-next-line:no-big-function
describe('SalesCustomerService', () => {
  let service: SalesCustomerService;
  let httpClient: HttpClient;
  let serviceMock: SalesCustomerServiceMock;
  let httpMock: HttpTestingController;
  let appConstants: AppConstants;

  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SalesCustomerService, AppConstants, HttpClient, SalesCustomerServiceMock],
    });
    service = TestBed.inject(SalesCustomerService);
    httpClient = TestBed.inject(HttpClient);
    serviceMock = TestBed.inject(SalesCustomerServiceMock);
    appConstants = TestBed.inject(AppConstants);
    httpMock = TestBed.inject(HttpTestingController);
  });


  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([SalesCustomerService], (salesCustomerService: SalesCustomerService) => {
    expect(salesCustomerService).toBeTruthy();
  }));

  it('should get the customer name list', () => {
    const search = 'nor';
    const drAddressId = 34;
    service.getCustomerName(search, drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the account number list', () => {
    const search = '123';
    const drAddressId = 34;
    service.getCustomerAccountNumber(search, drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the pnone number list', () => {
    const search = '123';
    const drAddressId = 34;
    service.getCustomerPhoneNumbers(search, drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the international zipcode list', () => {
    const search = '188';
    const drAddressId = 34;
    service.getCustomerPostalCode(search, drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the international states list', () => {
    const search = 'IL';
    const drAddressId = 34;
    service.getCustomerInternationalStateCode(search, drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should save/Edit the new/existing customer or throw error on calling CreateCustomer', () => {
    const data = {
      salesCustId: 0,
      custChannelId: 'COMMSALE',
      customerName: 'North Quincy High School',
      salesOfficeId: '925',
      jobRoleType: '114',
      commCode: 'A01',
      accountNumber: '1234567',
      addressLine1: '7615 Standish Place',
      addressLine2: '13 Hancock Street',
      state: 'PA',
      zipPlus: '1234',
      country: 'USA',
      phoneNumber: '2137418871',
      faxNumber: '2137418872',
      parentCustId: 0,
      zipCode: '18801',
      province: '',
      nonUSPostalCode: '',
      city: 'MONTROSE',
      custCreditCatgCode: '',
      usedForOrderEntryInd: '',
      fipsCode: '',
      statusFlag: 'C',
      crmCompanyId: '',
      lastEcSyncChangeId: 0,
      salesCustomerContactView: [{
        customerContactId: 212,
        salesCustId: 0,
        firstName: 'Jack',
        lastName: 'Dill',
        phoneNbr: '6456464564',
        assignContact: true,
        faxNbr: '4564564564',
        jobRoleAsnId: 0,
        jobRoleContactId: 0,
        phoneExtension: '666',
      },
      {
        customerContactId: 213,
        salesCustId: 0,
        firstName: 'Jamesh',
        lastName: 'Kane',
        phoneNbr: '4534534534',
        assignContact: true,
        faxNbr: '3534534534',
        jobRoleAsnId: 0,
        jobRoleContactId: 0,
        phoneExtension: '555',
      },
      ],
    };
    const drAddressId = 122;
    const spyPost = spyOn(httpClient, 'post').and.returnValue(Observable.of(true));
    service.createCustomer(data, drAddressId).subscribe((res: any) => {
      expect(res).toBeTruthy();
    });
    spyPost.and.returnValue(Observable.throwError({ error: 'error' }));
    service.createCustomer(data, drAddressId).subscribe((res: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyPost.and.returnValue(Observable.throwError(''));
    service.createCustomer(data, drAddressId).subscribe((res: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });

    data.salesCustId = 100;
    const spyPut = spyOn(httpClient, 'put').and.returnValue(Observable.of(true));
    service.createCustomer(data, drAddressId).subscribe((res: any) => {
      expect(res).toBeTruthy();
    });

    spyPut.and.returnValue(Observable.throwError({ error: 'error' }));
    service.createCustomer(data, drAddressId).subscribe((res: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyPut.and.returnValue(Observable.throwError(''));
    service.createCustomer(data, drAddressId).subscribe((res: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should get the search customer list on calling getSearchCustomers', fakeAsync(() => {
    const skip = 0;
    const take = 20;
    const searchText = 'A02';
    const drAddressId = 34;
    spyOn(httpClient, 'post').and.returnValue(Observable.of({ customerList: [{ phoneNumber: '1234567890', faxNumber: '0987654321' }] }));
    tick();
    service.getSearchCustomers(skip, take, searchText, drAddressId).subscribe((data: ISearchCustomerListModel) => {
      expect(data.customerList[0].phoneNumber).toBe('(123) 456-7890');
      expect(data.customerList[0].faxNumber).toBe('(098) 765-4321');
    });
  }));

  it('should get the empty list on calling getSearchCustomers', fakeAsync(() => {
    const skip = 0;
    const take = 20;
    const searchText = 'A02';
    const drAddressId = 34;
    spyOn(httpClient, 'post').and.returnValue(Observable.of({ customerList: [] }));
    service.getSearchCustomers(skip, take, searchText, drAddressId).subscribe((data: ISearchCustomerListModel) => {
      expect(data.customerList.length).toBe(0);
    });
  }));

  it('should throw error on calling getSearchCustomers', fakeAsync(() => {
    const skip = 0;
    const take = 20;
    const searchText = 'A02';
    const drAddressId = 34;
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getSearchCustomers(skip, take, searchText, drAddressId).subscribe((res: ISearchCustomerListModel) => {

    }, (err) => { expect(err.error).toBe('error'); });
  }));

  it('should get the assign customer list or throw error on calling getAssignCustomers', () => {
    const skip = 0;
    const take = 20;
    const jobId = '25150';
    const drAddressId = 34;
    const spyAssign = spyOn(httpClient, 'get').and.
      returnValue(Observable.of({ customerList: [{ phoneNbr: '1234567890', faxNbr: '0987654321' }] }));
    service.getAssignCustomers(skip, take, jobId, drAddressId).subscribe((data: any) => {
      expect(data.customerList[0].phoneNbr).toBe('(123) 456-7890');
      expect(data.customerList[0].faxNbr).toBe('(098) 765-4321');
    });

    spyAssign.and.returnValue(Observable.of([]));
    service.getAssignCustomers(skip, take, jobId, drAddressId).subscribe((data: any) => {
      expect(data.length).toBe(0);
    });

    spyAssign.and.returnValue(Observable.throwError({ error: 'error' }));
    service.getAssignCustomers(skip, take, jobId, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyAssign.and.returnValue(Observable.throwError(''));
    service.getAssignCustomers(skip, take, jobId, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should delete the assigned customer or throw error on calling unassignCustomer', () => {
    const jobId = 25150;
    const drAddressId = 34;
    const jobRoleAsnId = 2;
    const spyDelete = spyOn(httpClient, 'delete').and.returnValue(Observable.of(true));
    service.unassignCustomer(jobRoleAsnId, drAddressId, jobId).subscribe((data: any) => {
      expect(data).toBeTruthy();
    });
    spyDelete.and.returnValue(Observable.throwError({ error: 'error' }));
    service.unassignCustomer(jobRoleAsnId, drAddressId, jobId).subscribe((data: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyDelete.and.returnValue(Observable.throwError(''));
    service.unassignCustomer(jobRoleAsnId, drAddressId, jobId).subscribe((data: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should assign customer or throw error on calling assignCustomer', () => {
    const drAddressId = 34;
    const payload = {
      jobRoleAsnId: 0,
      jobId: 27201,
      jobRoleTypeId: '4',
      custAcctNbr: '9369653',
      bidderInd: '',
      faxNbr: '3076747561',
      hostUpdateInd: '',
      insertDate: '2019-01-21T07:26:02.077Z',
      name: 'Bob  Prill',
      phoneNbr: '3076744437',
      salesCustId: '191',
      salesCustomerName: 'Prill Brothers Inc.',
      winningBidderInd: '',
    };
    const spyAssign = spyOn(httpClient, 'post').and.returnValue(Observable.of(true));
    service.assignCustomer(payload, drAddressId).subscribe((data: any) => {
      expect(data).toBeTruthy();
    });

    spyAssign.and.returnValue(Observable.throwError({ error: 'error' }));
    service.assignCustomer(payload, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyAssign.and.returnValue(Observable.throwError(''));
    service.assignCustomer(payload, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should get customer and contact list or throw error on getCustomerAndContactsList', () => {
    const salesCustId = 713;
    const drAddressId = 122;
    const spyGetCustomer = spyOn(httpClient, 'get').and.
      returnValue(Observable.of({ customerList: [{ phoneNbr: '1234567890', faxNbr: '0987654321' }] }));

    service.getCustomerAndContactsList(salesCustId, drAddressId).subscribe((data: any) => {
      expect(data.customerList.length).toBe(1);
    });

    spyGetCustomer.and.returnValue(Observable.throwError({ error: 'error' }));
    service.getCustomerAndContactsList(salesCustId, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyGetCustomer.and.returnValue(Observable.throwError(''));
    service.getCustomerAndContactsList(salesCustId, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should delete user selected customer contact or throw error on calling deleteCustomerContact', () => {
    const salesCustId = 2515;
    const drAddressId = 34;
    const customerContactId = 2;
    const spyDelete = spyOn(httpClient, 'delete').and.
      returnValue(serviceMock.deleteCustomerContact(salesCustId, drAddressId, customerContactId));
    service.deleteCustomerContact(salesCustId, drAddressId, customerContactId).subscribe((data: any) => {
      expect(data).toBeTruthy();
    });
    spyDelete.and.returnValue(Observable.throwError({ error: 'error' }));
    service.deleteCustomerContact(salesCustId, drAddressId, customerContactId).subscribe((data: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyDelete.and.returnValue(Observable.throwError(''));
    service.deleteCustomerContact(salesCustId, drAddressId, customerContactId).subscribe((data: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should update the assigned customer or throw error on calling updateAssignCustomer', () => {
    const drAddressId = 34;
    const jobId = 27355;
    const payload = {
      jobRoleAsnId: 2718,
      jobId: 27355,
      jobRoleTypeId: '4',
      custAcctNbr: '9369653',
      bidderInd: 'Y',
      faxNbr: '3076747561',
      hostUpdateInd: '',
      insertDate: '2019-01-21T07:26:02.077Z',
      name: 'Bob  Prill',
      phoneNbr: '3076744437',
      salesCustId: '191',
      salesCustomerName: 'Prill Brothers Inc.',
      winningBidderInd: 'Y',
      isJobRoleSelected: false,
    };

    const spyPut = spyOn(httpClient, 'put').and.returnValue(Observable.of(true));
    service.updateAssignCustomer(payload, drAddressId, jobId).subscribe((res: any) => {
      expect(res).toBeTruthy();
    });
    spyPut.and.returnValue(Observable.throwError({ error: 'error' }));
    service.updateAssignCustomer(payload, drAddressId, jobId).subscribe((res: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyPut.and.returnValue(Observable.throwError(''));
    service.updateAssignCustomer(payload, drAddressId, jobId).subscribe((res: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should delete user selected customer or throw error on calling deleteCustomer', () => {
    const selectedCustId = 2515;
    const drAddressId = 34;
    const spyDelete = spyOn(httpClient, 'delete').and.returnValue(Observable.of(true));
    service.deleteCustomer(selectedCustId, drAddressId).subscribe((data: any) => {
      expect(data).toBeTruthy();
    });

    spyDelete.and.returnValue(Observable.throwError({ error: 'error' }));
    service.deleteCustomer(selectedCustId, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spyDelete.and.returnValue(Observable.throwError(''));
    service.deleteCustomer(selectedCustId, drAddressId).subscribe((data: any) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should get the search contacts or throw error on calling getSearchContacts', () => {
    const skip = 0;
    const take = 20;
    const searchText = 'trane';
    const drAddressId = 34;
    const contacts: IContact[] = [{
      contactId: 1,
      lastName: 'Harison',
      firstName: 'Peter',
      accountNumber: '',
      companyName: 'Peter Air Condisitoning & Sheet Metal',
      salesOfficeName: 'LEXINGTONKY',
      phoneNumber: '999-9999',
      emailAddress: '',
      streetAddress1: '110 Circle Road',
      streetAddress2: 'Bentonville, AR, 72123, USA',
      address: 'trane',
      salesCustId: 678,
      custAcctNbr: '567',
      crmCompanyId: '788'
    },
    {
      contactId: 2,
      lastName: 'John',
      firstName: 'Goodman',
      accountNumber: '',
      companyName: 'Goodman Steel Inc',
      salesOfficeName: 'LEXINGTON-KY',
      phoneNumber: '(999) 999-9999',
      emailAddress: '',
      streetAddress1: '110 Circle Road',
      streetAddress2: 'Bentonville, AR, 72123, USA',
      address: '1101 Circle Road',
      salesCustId: 678,
      custAcctNbr: '567',
      crmCompanyId: '788'
    }];
    const spySearch = spyOn(httpClient, 'get').
      and.returnValue(Observable.of({ contacts }));

    spySearch.and.returnValue(Observable.of({ contacts }));
    service.getSearchContacts(skip, take, searchText, drAddressId).subscribe((data: ISearchContactListModel) => {
      expect(data.contacts.length).toBe(2);
    });
  });

  it('should throw error on calling getSearchContacts', () => {
    const skip = 0;
    const take = 20;
    const searchText = 'trane';
    const drAddressId = 34;

    const spySearch = spyOn(httpClient, 'get').
      and.returnValue(Observable.of({ contacts: [] }));

    spySearch.and.returnValue(Observable.throwError({ error: 'error' }));
    service.getSearchContacts(skip, take, searchText, drAddressId).subscribe((res: ISearchContactListModel) => {

    }, (err) => { expect(err.error).toBe('error'); });

    spySearch.and.returnValue(Observable.throwError(''));
    service.getSearchContacts(skip, take, searchText, drAddressId).subscribe((res: ISearchContactListModel) => {

    }, (err) => { expect(err).toBe(service.errorInfo); });
  });

  it('should make a call to the url on calling getSearchCustomers', fakeAsync(() => {
    const skip = 0;
    const take = 20;
    const searchText = 'A02';
    const drAddressId = 34;
    const searchUrl = appConstants.API_BASE_URL_JOB + '/34/SalesCustomer/Items?skip=0&take=20&searchText=A02';
    service.getSearchCustomers(skip, take, searchText, drAddressId).subscribe((data: ISearchCustomerListModel) => {
    });
    tick();
    const req = httpMock.match(searchUrl);
    expect(req[0].request.method).toEqual('POST');
    req[0].flush([]);
    flush();
  }));

});
