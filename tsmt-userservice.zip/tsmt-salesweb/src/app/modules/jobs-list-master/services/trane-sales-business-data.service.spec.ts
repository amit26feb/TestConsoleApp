import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { Observable, of } from 'rxjs';
import { ISalesOfficeModel } from '../../../shared/model/sales-office-model';
import { AppConstants } from '../../../shared/constants/constants';
import { TraneSalesBusinessDataService } from './trane-sales-business-data.service';

describe('TraneSalesBusinessDataService', () => {
  let service: TraneSalesBusinessDataService;
  let httpClient: HttpClient;
  let appConstants: AppConstants;
  const originReset = TestBed.resetTestingModule;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TraneSalesBusinessDataService, AppConstants],
    });
    service = TestBed.inject(TraneSalesBusinessDataService);
    httpClient = TestBed.inject(HttpClient);
    appConstants = TestBed.inject(AppConstants);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([TraneSalesBusinessDataService], (traneSalesBusinessDataService: TraneSalesBusinessDataService) => {
    expect(traneSalesBusinessDataService).toBeTruthy();
  }));

  it('should get the sales office list', () => {
    service.getSalesOffices().subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the Commision Code list', () => {
    const salesOfficeId = 1;
    service.getCommissionCodes(salesOfficeId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the JobContact list', () => {
    const salesOfficeId = 1;
    service.getJobContacts(salesOfficeId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the domain list', () => {
    const listTypes = ['job status', 'quality spec', 'job phase', 'fall out reason', 'tcpn contract'];
    service.getDomainList(listTypes).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the Influenced By list', () => {
    service.getJobRoleTypes().subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the Competitor list', () => {
    const drAddressId = 34;
    service.getCompetitors(drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the data as per the url that is passed', () => {
    const salesOfficeId = 10;
    const url = appConstants.API_BASE_URL_JOB + '/TraneSalesBusinessData/' + salesOfficeId + '/CommissionCodes';
    service.getData(url).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
    // check getData exception scenario
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getData(url).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
  it('should get the sales office by sales office id', () => {
    const salesOfficeId = 10;
    service.getSalesOffice(salesOfficeId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });

    // check getSalesOffice exception scenario
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getSalesOffice(salesOfficeId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get the sales office by dr address id', () => {
    const drAddressId = 10;
    service.getSalesOfficeByDrAddressId(drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });

    // check getSalesOfficeByDrAddressId exception scenario
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getSalesOfficeByDrAddressId(drAddressId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get sales offices list on getAllSalesOffices', () => {
    service.getAllSalesOffices().subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should return error when http get fails when fetching on getAllSalesOffices', () => {
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getAllSalesOffices().subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get sales offices list on getAllSalesOfficesIncludingChildren', () => {
    service.getAllSalesOfficesIncludingChildren().subscribe((data: ISalesOfficeModel[]) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it(`should return error when http get fails when fetching
  on getAllSalesOfficesIncludingChildren`, () => {
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getAllSalesOfficesIncludingChildren().subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get the providers', () => {
    service.getProviders().subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get list of equipments on getEquipments', () => {
    service.getEquipments().subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('getEquipments should throw error when service throws error', () => {
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getEquipments().subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should return classification response on calling getClassifications', () => {
    const sampleClassifications = {
      jobClassId: 1,
      description: 'test classification',
      codes: [
        {
          jobCodeId: 1,
          description: 'test description',
        },
      ],
    };
    const spy = spyOn(httpClient, 'get').and.returnValue(of([sampleClassifications]));
    service.getClassifications().subscribe((value) => {
      expect(value).toEqual([sampleClassifications]);
      expect(spy).toHaveBeenCalled();
    });
  });

  it('should return error response when service throws error', () => {
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'Error occured while getting classifications' }));
    service.getClassifications().subscribe(() => {
    }, (err) => {
      expect(err.error).toBe('Error occured while getting classifications');
    });
  });

  it('should return earthwise response on calling getEarthwiseSystems', () => {
    const earthwiseSystems = [{
      systemTypeId: 1,
      description: 'test earthwise systems',
      toolTip: 'trane test',
    }];
    const spy = spyOn(httpClient, 'get').and.returnValue(of(earthwiseSystems));
    service.getEarthwiseSystems().subscribe((value) => {
      expect(value).toEqual(earthwiseSystems);
      expect(spy).toHaveBeenCalled();
    });
  });

  it('should return program response on calling getPrograms', () => {
    const programs = [{
      programCode: 'CLTC',
      programDescription: 'Critical to Close',
    }];
    const spy = spyOn(httpClient, 'get').and.returnValue(of(programs));
    service.getPrograms().subscribe((value) => {
      expect(value).toEqual(programs);
      expect(spy).toHaveBeenCalled();
    });
  });

  it('should return revenue response on calling getRevenueStream', () => {
    const revenue = [{
      revenueStreamFieldValue: 'CSNG',
      description: 'Contracting - CS No Guarantee',
    }];
    const spy = spyOn(httpClient, 'get').and.returnValue(of(revenue));
    service.getRevenueStream().subscribe((value) => {
      expect(value).toEqual(revenue);
      expect(spy).toHaveBeenCalled();
    });
  });
});

