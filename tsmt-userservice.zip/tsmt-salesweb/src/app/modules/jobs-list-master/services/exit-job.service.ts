import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { ApiErrorService } from '../../../shared/services/apierror.service';
import { JobHeaderService } from '../../../shared/services/job-header.service';
import { JobsServicesService } from './jobs-services.service';

@Injectable()
export class ExitJobService {

  constructor(
    private apiErrorService: ApiErrorService,
    private jobHeaderService: JobHeaderService,
    private jobService: JobsServicesService,
    private router: Router,
  ) { }

  CloseAndExitJob(jobId: number, drAddressId: number, jobLockUser: string) {

    const currentUserId = this.jobHeaderService.getUserId();

    if (jobLockUser === currentUserId) {

      // The current user has the job locked, so we want to unlock the job.
      this.jobService.LockAndUnLockJob({
        jobId,
        drAddressId,
        userId: currentUserId,
        lockJob: false,
      }).subscribe(() => {

        // successfully unlocked
        this.closeJob(false);

      }, (err: HttpErrorResponse) => {

        // job wasn't unlocked due to being locked by someone else
        //  this can be ignored
        if (err.status === 409) {
          this.closeJob(true);
        } else {
          // unexpected error
          this.apiErrorService.show(err.error.Message);
          this.closeJob(false);
        }
      });
    } else {

      // locked by someone else
      this.closeJob(true);
    }
  }

  closeJob(isLockedBySomeoneElse: boolean) {
    this.jobHeaderService.clearJob();
    // attempt to close the tab
    window.close();
    // route to exit page in case window close doesnt work
    // https://stackoverflow.com/questions/14373625/close-current-tab
    this.router.navigate(['jobs-list', isLockedBySomeoneElse, 'exit']);
  }
}
