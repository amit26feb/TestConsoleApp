import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ISaveCrmModel } from '../models/create-crm.model';

import { CreateCrmService } from './create-crm.service';

describe('CreateCrmService', () => {
  let service: CreateCrmService;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateCrmService, AppConstants],
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(CreateCrmService);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return jobId as response if create is success on calling createCrmJob', () => {
    const jobId = 1234;
    const saveCrmPayload = {
      opportunityName: 'test',
    } as unknown as ISaveCrmModel;
    spyOn(httpClient, 'get').and.returnValue(of(jobId));
    const response = service.createCrmJob(101, saveCrmPayload);
    response.subscribe((data) => {
      expect(data).toEqual(jobId);
    });
  });

  it('should catch the error when documentService throws an error while generating the document', () => {
    const saveCrmPayload = {
      opportunityName: null,
    } as unknown as ISaveCrmModel;
    spyOn(httpClient, 'get').and.returnValue(throwError({ error: 'error' }));
    const response = service.createCrmJob(101, saveCrmPayload);
    response.subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
});
