import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SortDescriptor } from '@progress/kendo-data-query';
import { BehaviorSubject, Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { IDocumentPackageFileHistory } from '../documents/models/document-package-file-history';
import { IDocumentPackageInfo } from '../documents/models/document-package-info';
import { IFileTypesDetails } from '../documents/models/file-types-view-model';
import { IDocumentPackageFileStatus } from '../models/document-package-file-status';
import { IDocumentFolderList } from '../../jobs-list-master/documents/models/document-package-gen-folders-model';
import { IMostRecentGeneratedFileHistory } from '../documents/models/most-recent-generated-file-history';
import { ILegacyFile } from '../documents/models/legacy-file';
import { IBusinessStream } from '../models/business-stream-model';
import { IDocumentInput } from '../models/document-input-model';
import { IWorkPackage } from '../models/work-package';
import { IWorkPackageDetail } from '../models/work-package-detail';
import { DocumentDetails } from '@tsmt/shared-acquisition-dataservices';

@Injectable({
  providedIn: 'root',
})
export class DocumentService {
  private BASE_URL = this.appconstants.API_BASE_URL_SALESWEBGATEWAY;
  private DOC_PAC_BASE_URL = this.appconstants.API_BASE_URL_DOCUMENTPACKAGE;
  private WORK_PACKAGE_BASE_URL = this.appconstants.API_BASE_URL_WORKPACKAGE;
  groupedPackagesSubject = new BehaviorSubject([]);
  skip = 0;
  take = 15;
  sortParameterValue: SortDescriptor[] = [{ field: 'lastModified', dir: 'desc' }];
  packageFormType = 'create';
  docPackageId: number;
  packageName: string;
  viewHistory = false;
  generateBtnChecked = false;
  isEnablePackage = new BehaviorSubject<boolean>(true);
  constructor(private httpClient: HttpClient, private appconstants: AppConstants) { }

  getPackagesList(data) {
    return this.httpClient.get(this.BASE_URL + '/' + data.drAddressId + '/Jobs/' + data.jobId +
      '/DocumentPackages');
  }

  getFiles(drAddressId: number, jobId: number, documentPackageId: number): Observable<IDocumentPackageFileHistory[]> {
    return this.httpClient.get<IDocumentPackageFileHistory[]>(
      `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/DocumentPackages/${documentPackageId}/Files`);
  }

  getJobHistoryFiles(drAddressId: number, jobId: number, documentName: string, folderId: number, documentTypeId: number)
    : Observable<DocumentDetails[]> {
    const options = new HttpParams().set('drAddressId', drAddressId.toString()).set('jobId', jobId.toString()).
      set('documentName', encodeURIComponent(documentName))
      .set('folderId', folderId.toString()).set('documentTypeId', documentTypeId.toString());
    return this.httpClient.get<DocumentDetails[]>(this.BASE_URL + '/Document/JobDocumentHistory', { params: options })
      .map((res: DocumentDetails[]) => res)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }

  getLegacyFiles(drAddressId: number, jobId: number): Observable<ILegacyFile[]> {
    return this.httpClient.get<ILegacyFile[]>(
      `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/LegacyFiles`);
  }

  requestMigrationOfLegacyFiles(drAddressId: number, jobId: number): Observable<void> {
    return this.httpClient.post<void>(
      `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/LegacyFiles`, '')
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }

  getMostRecentGeneratedFile(drAddressId: number, jobId: number, documentPackageId: number): Observable<IMostRecentGeneratedFileHistory> {
    return this.httpClient.get<IMostRecentGeneratedFileHistory>(
      `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/DocumentPackages/${documentPackageId}/Files/MostRecentGeneratedFile`);
  }

  getPackageDetails(drAddressId: number, jobId: number, documentPackageId: number): Observable<IDocumentPackageInfo> {
    return this.httpClient.get<IDocumentPackageInfo>(
      `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/DocumentPackage/${documentPackageId}`);
  }

  requestDocumentGeneration(data) {
    const headers = new HttpHeaders().append('Content-Type', 'application/json');
    return this.httpClient.post(this.BASE_URL + '/DocumentGenerator/' + data.drAddressId + '/Jobs/' + data.jobId + '/DocumentPackage/' +
      data.docPackId + '/Generate',
      JSON.stringify(data.callerTimeZone), { observe: 'response', responseType: 'blob', headers })
      .catch((err) => {
        return Observable.throwError(err);
      });
  }

  getBusinessStreams(): Observable<IBusinessStream[]> {
    return this.httpClient.get<IBusinessStream[]>(this.DOC_PAC_BASE_URL + '/MasterData/BusinessStreams');
  }

  getDocumentInputsForBusinessStream(docGroupId: number): Observable<IDocumentInput[]> {
    return this.httpClient.get<IDocumentInput[]>(this.DOC_PAC_BASE_URL + '/MasterData/Groups/' + docGroupId + '/Inputs');
  }

  getDocumentInputsForDocumentType(docTypeId: number): Observable<IDocumentInput[]> {
    return this.httpClient.get<IDocumentInput[]>(this.DOC_PAC_BASE_URL + '/MasterData/DocumentTypes/' + docTypeId + '/Inputs');
  }

  getAllDocumentTypes() {
    return this.httpClient.get(this.DOC_PAC_BASE_URL + '/MasterData/DocumentTypes');
  }

  getDocumentTypes(businessStreamId: number) {
    return this.httpClient.get(this.DOC_PAC_BASE_URL + '/MasterData/Groups/' + businessStreamId + '/DocumentTypes');
  }

  getLegalEntities(docTypeId: number) {
    return this.httpClient.get(this.DOC_PAC_BASE_URL + '/MasterData/DocumentTypes/' + docTypeId + '/LegalEntities');
  }

  getTermsAndConditions(docTypeId: number) {
    return this.httpClient.get(this.DOC_PAC_BASE_URL + '/MasterData/DocumentTypes/' + docTypeId + '/TermsAndConditions');
  }

  getDocumentFileDownload(drAddressId: number, jobId: number, documentPackageId: number, version: number) {
    const url = `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/DocumentPackages/${documentPackageId}/Files/${version}/Download`;
    return this.getFileDownload(url);
  }

  getMostRecentDocumentFileDownload(drAddressId: number, jobId: number, documentPackageId: number) {
    const url = `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/DocumentPackages/${documentPackageId}/Files/Download`;
    return this.getFileDownload(url);
  }

  private getFileDownload(url: string): Observable<{ file: Blob, name: string }> {
    return this.httpClient.get(url, { observe: 'response', responseType: 'blob' })
      .map((res) => {
        // We assume the filename is unicode, or the browser supports unicode (filename* exists on content-disposition header)
        // content-disposition: attachment; filename="(non-unicode filename)"; filename*="(encoding type)''(unicode filename)";
        const contentDispositionHeader = res.headers.get('Content-Disposition');

        // Read from filename* for unicode filename (browser may or may not support this, peel off encoding type like UTF-8).
        const unicodeFilenameRegex = /filename\*?=(UTF-\d['"]*)([^;\r\n"']*)['"]?;?/;
        let fileName = '';

        // Encoded unicode filename will be null or 0 length if the browser does not support unicode.
        const encodedUnicodeFilename = unicodeFilenameRegex.exec(contentDispositionHeader);
        if (encodedUnicodeFilename === null || encodedUnicodeFilename.length === 0) {
          // Non-unicode filename.
          // Read from filename (note: no *)
          const nonunicodeFilenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
          fileName = contentDispositionHeader ? nonunicodeFilenameRegex.exec(contentDispositionHeader)[1].replace(/["]/g, '') : '';
        } else {
          // Unicode filename (contains something like: éèâîôñüïç).
          // Already read from filename*.
          const escapedFileName = contentDispositionHeader ?
            unicodeFilenameRegex.exec(contentDispositionHeader)[2].replace(/["]/g, '') : '';
          fileName = unescape(decodeURIComponent(escapedFileName));
        }

        return {
          file: new Blob([res.body], { type: res.headers.get('Content-Type') }),
          name: fileName,
        };

      }).catch((err) => {
        return Observable.throwError(err);
      });
  }

  getDocumentFileStatus(drAddressId: number, jobId: number, docPackId: number, version: number): Observable<IDocumentPackageFileStatus> {
    const url = `${this.BASE_URL}/${drAddressId}/Jobs/${jobId}/DocumentPackages/${docPackId}/Files/${version}/Status`;
    return this.httpClient.get<IDocumentPackageFileStatus>(url);
  }

  // Create a new document folder
  createDocumentFolder(createPayload: IDocumentFolderList): Observable<IDocumentFolderList[]> {
    const url = `${this.DOC_PAC_BASE_URL}/${createPayload.drAddressId}/Jobs/${createPayload.jobId}/DocumentFolder`;
    return this.httpClient.post<IDocumentFolderList[]>(url, createPayload)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }

  // Update existing document folder
  updateDocumentFolder(updatePayload: IDocumentFolderList): Observable<IDocumentFolderList[]> {
    const url = `${this.DOC_PAC_BASE_URL}/${updatePayload.drAddressId}/Jobs/${updatePayload.jobId}/DocumentFolder/DocumentFolderName`;
    return this.httpClient.put<IDocumentFolderList[]>(url, updatePayload)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }

  // Get document folders based on job id
  getDocumentFolders(drAddressId: number, jobId: number): Observable<IDocumentFolderList[]> {
    const url = `${this.DOC_PAC_BASE_URL}/${drAddressId}/Jobs/${jobId}/DocumentFolder`;
    return this.httpClient.get<IDocumentFolderList[]>(url);
  }

  getFileTypes(): Observable<IFileTypesDetails[]> {
    const url = this.DOC_PAC_BASE_URL + '/MasterData/JobDocumentTypes';
    return this.httpClient.get<IFileTypesDetails[]>(url);
  }

  getWorkPackages(drAddressId: number, jobId: number): Observable<IWorkPackage[]> {
    return this.httpClient.get<IWorkPackage[]>(
      this.WORK_PACKAGE_BASE_URL + '/' + drAddressId + this.appconstants.WORK_PACKAGE_URL + '?jobId=' + jobId)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }

  getWorkPackage(drAddressId: number, workPackageId: number): Observable<IWorkPackageDetail> {
    return this.httpClient.get<IWorkPackageDetail>(
      this.WORK_PACKAGE_BASE_URL + '/' + drAddressId + this.appconstants.WORK_PACKAGE_URL + '/' + workPackageId)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error);
      });
  }
}
