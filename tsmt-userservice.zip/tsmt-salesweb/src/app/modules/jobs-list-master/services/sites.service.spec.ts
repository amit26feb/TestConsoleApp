import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ISearchSiteListModel, ISite } from '../models/create-crm.model';
import { SitesService } from './sites.service';

describe('SitesService', () => {
  let service: SitesService;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SitesService, AppConstants, HttpClient],
    });
    service = TestBed.inject(SitesService);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get the search sites on calling getCrmSites', () => {
    const skip = 0;
    const take = 20;
    const searchText = 'trane';
    const drAddressId = 34;
    const crmCompanyId = '1234';
    const siteDetails = [{
      siteName: 'Peter Air Condisitoning & Sheet Metal',
      streetAddress1: 'trane',
      streetAddress2: '',
      streetAddress3: '',
      streetAddress4: '',
    },
    {
      siteName: 'Goodman Steel Inc',
      streetAddress1: '1101 Circle Road',
      streetAddress2: '',
      streetAddress3: '',
      streetAddress4: '',
    }] as ISite[];
    const searchResult = {
      pageCount: 1,
      pageSize: 15,
      pageNumber: 1,
      sites: siteDetails,
    } as ISearchSiteListModel;
    spyOn(httpClient, 'get').
      and.returnValue(Observable.of(searchResult));

    service.getCrmSites(drAddressId, skip, take, searchText, crmCompanyId).subscribe((data: ISearchSiteListModel) => {
      expect(data.sites.length).toBe(2);
    });
  });

  it('should throw error on calling getCrmSites', () => {
    const skip = 0;
    const take = 20;
    const searchText = 'trane';
    const drAddressId = 34;
    const crmCompanyId = '6789';
    spyOn(httpClient, 'get').
      and.returnValue(Observable.throwError({ error: 'error' }));
    service.getCrmSites(drAddressId, skip, take, searchText, crmCompanyId).subscribe((res: ISearchSiteListModel) => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
});
