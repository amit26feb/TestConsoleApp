import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { getTestBed, TestBed } from '@angular/core/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { of } from 'rxjs';
import { AppConstants } from './../../../shared/constants/constants';
import { IBidSelections, ICoordinateBidData, ICoordinatedata, ICoordinateRequest } from './../models/coordinate-job.model';
import { CoordinateService } from './coordinate.service';

describe('CoordinateService', () => {
  let service: CoordinateService;
  let injector: TestBed;
  let httpClient: HttpClient;
  const originReset = TestBed.resetTestingModule;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [CoordinateService, AppConstants],
      imports: [HttpClientTestingModule],
    });
    injector = getTestBed();
    service = injector.inject(CoordinateService);
    httpClient = TestBed.inject(HttpClient);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch coordinate job info when fetchCoordinateJobData method is called', () => {
    const testCoordinateData = {
      jobCoordinationGeneralInfo: {
        requestedDate: '9/9/2200 12:00:00 AM',
        quickTurnaroundIndicator: 'Y',
        icsJobIndicator: 'N',
        jobContact: 'cceenp',
        commissionCode: 'X00',
        crmOpportunityId: '1811024',
        pricingSpaNumber: null,
      },
      jobNotes: {
        jobId: 1,
        noteString: 'Test Notes',
        drAddressId: 122,
      },
      submissionNotes: {
        jobId: 1,
        sequenceNumber: 1,
        drAddressId: 122,
        noteLine: 'Test submission notes',
      },
      coordinationData: {
        submissionNotes: {
          notesLine: 'test Notes',
        },
      },
    };

    const coordinateData = testCoordinateData;
    spyOn(httpClient, 'get').and.returnValue(of(coordinateData));
    service.fetchCoordinateJobData(1, 122, 100).subscribe((data) => {
      expect(data.jobCoordinationGeneralInfo).toEqual(coordinateData.jobCoordinationGeneralInfo);
      expect(data.jobNotes.noteString).toBe('Test Notes');
      expect(data.jobNotes.jobId).toBe(1);
      expect(data.jobNotes.drAddressId).toBe(122);
    });
  });

  it('should fetch coordinate bid info when fetchCoordinateBidData method is called', () => {
    const coordinateData: ICoordinateBidData = {
      bidDataForCoordination: [{
        bidAlternateId: 2086,
        bidName: 'Base Bid',
        isCurrentBid: true,
        isBidInCoordinationJob: true,
        isSubmitted: false,
        isDisabled: false,
      }],
    };
    spyOn(httpClient, 'get').and.returnValue(of(coordinateData));
    service.fetchCoordinateBidData(1, 122).subscribe((data) => {
      expect(data.bidDataForCoordination).toEqual(coordinateData.bidDataForCoordination);
    });
  });

  it('should fetch coordinate job general data when fetchCoordinateJobGeneralData method is called', () => {
    const coordinateData: ICoordinatedata = {
      coordinatedJobGeneralInfo: null,
      discountConfirmationDetails: [{
        bidAlternateId: 123,
        isDiscountConfirmed: true,
      }],
    };
    spyOn(httpClient, 'get').and.returnValue(of(coordinateData));
    service.fetchCoordinateJobGeneralData(1, 122).subscribe((data) => {
      expect(data).toEqual(coordinateData);
    });
  });

  it('should make http call when saveCoordinateJob method is called', () => {
    const spy = spyOn(httpClient, 'post').and.returnValue(of({}));
    const notesReqest = {
      jobCoordinationViewModel: {
        jobId: '442',
        drAddressId: '122',
        coordinationId: '46',
      },
    };
    service.saveCoordinateJobData(notesReqest, notesReqest.jobCoordinationViewModel.drAddressId,
      notesReqest.jobCoordinationViewModel.jobId).subscribe((data) => {
        expect(spy).toHaveBeenCalled();
      });
  });

  it('should fetch bids with selections when fetchBidsWithSelections method is called', () => {
    const testSelection1 = { description: 'Product A', bidName: 'Base bid' };
    const testSelection2 = { description: 'Product B', bidName: 'Base bid' };
    const testSelection3 = { description: 'Product C', bidName: 'Rebid' };
    const testBid1 = { bidAlternateId: 123, bidName: 'Base bid', selections: [testSelection1, testSelection2] };
    const testBid2 = { bidAlternateId: 456, bidName: 'Rebid', selections: [testSelection3] };
    const testBids = [testBid1, testBid2] as IBidSelections[];
    const spy = spyOn(httpClient, 'post').and.returnValue(of(testBids));
    service.fetchBidsWithSelections(1, 122, [123, 456]).subscribe((data) => {
      expect(spy).toHaveBeenCalled();
      expect(data).toEqual(testBids);
    });
  });

  it('should fetch coordinate requests data when fetchCoordinateRequest method is called', () => {
    const coordinateData: ICoordinateRequest[] = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: 'Not Submitted',
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    }];
    spyOn(httpClient, 'get').and.returnValue(of(coordinateData));
    service.fetchCoordinateRequest(101, 37499).subscribe((data) => {
      expect(data).toEqual(coordinateData);
    });
  });

  it('should fetch validation results for coordinate request when validateCoordinateRequest method is called', () => {
    const validationResponse = { shippingLeadTimeValidations: [{ prodFamilyId: 123, isValid: false }] };
    spyOn(httpClient, 'get').and.returnValue(of(validationResponse));
    service.validateCoordinateRequest(101, 37499, 123).subscribe((data) => {
      expect(data).toEqual(validationResponse);
    });
  });

  it('should emit a new value from markJobForSubmitSubject when setJobMarkedForSubmit is called with true', () => {
    service.isJobMarkedForSubmit = false;
    const spy = spyOn(service.markJobForSubmitSubject, 'next');
    service.setJobMarkedForSubmit(true);
    expect(spy).toHaveBeenCalled();
    expect(service.isJobMarkedForSubmit).toBe(true);
  });

  it('should not emit a new value from markJobForSubmitSubject when job is already marked for submit', () => {
    service.isJobMarkedForSubmit = true;
    const spy = spyOn(service.markJobForSubmitSubject, 'next');
    service.setJobMarkedForSubmit(true);
    expect(spy).not.toHaveBeenCalled();
    expect(service.isJobMarkedForSubmit).toBe(true);
  });

  it('should not emit a new value from markJobForSubmitSubject when setJobMarkedForSubmit is called with false', () => {
    service.isJobMarkedForSubmit = true;
    const spy = spyOn(service.markJobForSubmitSubject, 'next');
    service.setJobMarkedForSubmit(false);
    expect(spy).not.toHaveBeenCalled();
    expect(service.isJobMarkedForSubmit).toBe(false);
  });

  it('should fetch ship lead time validation results when validateShipLeadTime method is called', () => {
    const validationResponse = { shippingLeadTimeValidations: [{ prodFamilyId: 123, isValid: false }] };
    spyOn(httpClient, 'get').and.returnValue(of(validationResponse));
    service.validateShipLeadTime(101, 37499, 123).subscribe((data) => {
      expect(data).toEqual(validationResponse);
    });
  });

  it('should submit job for coordination when submitJobForCoordination method is called', () => {
    const response = { isJobSubmittedForCoordination: true };
    spyOn(httpClient, 'get').and.returnValue(of(response));
    service.submitJobForCoordination(101, 37499, 123).subscribe((data) => {
      expect(data).toEqual(response);
    });
  });

});
