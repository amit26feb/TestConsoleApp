import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ISalesOfficeModel } from '../../../shared/model/sales-office-model';
import { AppConstants } from '../../../shared/constants/constants';
import { IJobDomainList } from '../modal/job-details-edit.model';
import { ISalesOfficeDetailModel } from '../modal/sales-office-detail-model';
import { IClassification, IEarthwiseSystem, IProgram, IRevenueStream } from '../models/create-crm.model';

@Injectable()
export class TraneSalesBusinessDataService {

  private BASE_URL = this.appconstants.API_BASE_URL_JOB;
  public BUSINESSDATA_URL = this.appconstants.BUSINESSDATA_BASE_URL;
  public BUSINESSDATA_CONTEXT = '/BusinessDataService/';
  constructor(private http: HttpClient, private appconstants: AppConstants) { }

  // Get data method
  getData(url): Observable<any[]> {
    return this.http.get<any[]>(url)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // SalesOffices Get Sales Office
  getSalesOffices() {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/SalesOffices');
  }

  // Get sales office
  getSalesOffice(salesOfficeId: number): Observable<ISalesOfficeDetailModel> {
    return this.http.get<ISalesOfficeDetailModel>(this.BASE_URL + '/TraneSalesBusinessData/SalesOffice/' + salesOfficeId)
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // Get sales office by dr address id
  getSalesOfficeByDrAddressId(drAddressId: number): Observable<ISalesOfficeDetailModel> {
    return this.http.get<ISalesOfficeDetailModel>(this.BASE_URL + '/TraneSalesBusinessData/DrAddress/' + drAddressId + '/SalesOffice')
      .catch((error: any) => {
        return Observable.throwError(error);
      });
  }

  // CommissionCodes Get Commission Codes Details
  getCommissionCodes(salesOfficeId) {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/' + salesOfficeId + '/CommissionCodes');
  }

  // JobContacts Get Job Contact Details
  getJobContacts(salesOfficeId) {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/' + salesOfficeId + '/Contacts');
  }

  // Get Domain List
  getDomainList(listTypes: string[]) {
    const listType = 'listType';
    let options = new HttpParams().set(listType, listTypes[0]);
    for (let i = 1; i < listTypes.length; i++) {
      options = options.append(listType, listTypes[i]);
    }
    return this.http.get<IJobDomainList[]>(this.BUSINESSDATA_URL + this.BUSINESSDATA_CONTEXT + 'DomainList', { params: options });
  }

  // Get Role By List
  getJobRoleTypes() {
    return this.getData(this.BUSINESSDATA_URL + this.BUSINESSDATA_CONTEXT + 'RolesTypeList');
  }

  // Get Competitor List
  getCompetitors(drAddressId) {
    return this.getData(this.BASE_URL + '/' + drAddressId + '/TraneSalesBusinessData/Competitors');
  }

  // All Sales Office List data
  getAllSalesOffices() {
    const options = new HttpParams()
      .set('DrAddressId', '0')
      .set('ExcludeParts', 'true')
      .set('FilterCriteria', 'salesofficewithdraddressid');
    return this.http.get<any[]>(
      this.BASE_URL + '/TraneSalesBusinessData/SalesOffices', { params: options },
    ).catch((error: any) => {
      return Observable.throwError(error);
    });
  }

  // All Sales Office List including data
  getAllSalesOfficesIncludingChildren(): Observable<ISalesOfficeModel[]> {
    const options = new HttpParams()
      .set('DrAddressId', '0')
      .set('ExcludeParts', 'true')
      .set('FilterCriteria', 'salesofficewithdraddressidincludingchildren');
    return this.http.get<ISalesOfficeModel[]>(
      this.BASE_URL + '/TraneSalesBusinessData/SalesOffices', { params: options },
    ).catch((error: any) => {
      return Observable.throwError(error);
    });
  }

  // Get provider List
  getProviders() {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/Providers');
  }
  // Get Equipment List
  // Returns list of equipment details
  getEquipments() {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/Equipments');
  }

  getClassifications(): Observable<IClassification[]> {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/Classifications');
  }
  // Get Earthwise Systems
  // Returns Earthwise Systems
  getEarthwiseSystems(): Observable<IEarthwiseSystem[]> {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/SystemTypes');
  }
  // Get Programs
  // Returns Programs
  getPrograms(): Observable<IProgram[]> {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/Programs');
  }

  // Get Revenue stream list
  // Returns list of revenue stream
  getRevenueStream(): Observable<IRevenueStream[]> {
    return this.getData(this.BASE_URL + '/TraneSalesBusinessData/Revenue');
  }
}
