import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { JobListServiceMock } from './../../../shared/test-mocks/jobService-mock';

import { HttpClient } from '@angular/common/http';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { AppConstants } from '../../../shared/constants/constants';
import { ICustomSenderDetails } from '../documents/models/custom-sender-details';
import { JobsServicesService } from './jobs-services.service';
import { IDocumentDetails, IDocumentDetailsList } from '../models/document-files-model';
import { ICountryModel } from '../modal/job-details-edit.model';
import { SharePointDocumentDetail } from '../models/share-point-document-detail-model';
import { DocumentDetails } from '@tsmt/shared-acquisition-dataservices';

// tslint:disable-next-line:no-big-function
describe('JobsServicesService', () => {
  let service: JobsServicesService;
  let httpClient: HttpClient;
  let httpMock: HttpTestingController;
  let appConstants: AppConstants;
  const originReset = TestBed.resetTestingModule;
  const modifiedJobName = 'Erdman Harve de Grace Aberdeen';
  const documentStorage = 'S3';
  const folderId = 23;
  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [JobsServicesService, AppConstants],
    });
    service = TestBed.inject(JobsServicesService);
    httpClient = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
    appConstants = TestBed.inject(AppConstants);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', inject([JobsServicesService], (jobService: JobsServicesService) => {
    expect(jobService).toBeTruthy();
  }));

  it('should get the office selector list', () => {
    service.getOfficeSelector().subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });

    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getOfficeSelector().subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should lock the job or throw error ( based on response from service ) on calling LockAndUnLockJob', () => {
    const payload = {
      jobId: 1234,
      drAddressId: 122,
      userId: 'ccfbsb',
      lock: true,
    };
    service.LockAndUnLockJob(payload).subscribe((data: any) => {
      expect(data).toBeTruthy();
    });

    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.LockAndUnLockJob(payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it(`should assign customer or throw error based on the response from service
  on calling assignCustomer method`, () => {
    const payload = {
      jobRoleAsnId: 0,
      jobId: 1234,
      jobRoleTypeId: 114,
      custAcctNbr: '1234567',
      salesCustomerName: 'Dave Jones',
      salesCustId: '30100',
      hostUpdateInd: '',
      insertDate: new Date(),
      bidderInd: '',
      winningBidderInd: '',
    };
    const drAddressId = 34;
    service.assignCustomer(payload, drAddressId).subscribe((data: any) => {
      expect(data).toBeTruthy();
    });

    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.assignCustomer(payload, drAddressId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should set jobReportId on setJobReportId()', () => {
    const jobReportId = 110;
    service.setJobReportId(jobReportId);
    expect(service.jobReportId).toBe(110);
  });
  it('should return jobReportId on getJobReportId()', () => {
    service.setJobReportId(110);
    expect(service.getJobReportId()).toBe(110);
  });
  it('should create the job', () => {
    const payload = {
      jobId: 0,
      drAddressId: 122,
    };
    service.CreateJob(payload).subscribe((data: any) => {
      expect(data).toBeDefined();
    });
    // check exception scenario in service
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.CreateJob(payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
  it('should fetch form data', () => {
    const payload = {
      jobId: 0,
      drAddressId: 122,
    };
    service.fetchformData(payload).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });
  it('should get job update data', () => {
    const payload = {
      jobId: 0,
      drAddressId: 122,
    };
    service.getJobUpdateData(payload, 'Classification').subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });

    service.getJobUpdateData(payload, 'Earthwise').subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });

    const notesPayload = {
      jobNotes: {
        jobId: 1231,
        noteString: 'Test',
        drAddressId: 122,
      },
    };

    service.getJobUpdateData(notesPayload, 'jobNotes').subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should fetch job details', () => {
    service.fetchJobDetails(59297, 34).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should fetch all info', () => {
    service.getJobAllInfo(94, 1234).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should fetch job contact and commission code details', () => {
    const salesOfficeId = 110;
    service.GetJobContactAndCommCode(salesOfficeId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
    // check exception scenario in service
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.GetJobContactAndCommCode(salesOfficeId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
  it('should fetch country code details', () => {
    const payload = {
      jobId: 4552,
      drAddressId: 122,
      country: 'USA',
    };
    service.getCountryCode(payload).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });
  it('should fetch postal code details', () => {
    const payload = {
      jobId: 4552,
      drAddressId: 122,
      country: 'USA',
    };
    service.getPostalCode(payload).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });
  it('should fetch country code details', () => {
    const payload = {
      jobId: 4552,
      drAddressId: 122,
      notes: 'Test notes',
    };
    service.loadJobNotes(payload).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });
  it('should fetch earthwise system details', () => {
    service.EarthwiseSystemDetails(59297, 34).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });
  it('should edit classification details', () => {
    service.editClassificationDetails(59297, 34).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });
  it('should get selected classification details', () => {
    service.getSelectedClassifications(59297, 34).subscribe((data: any) => {
      expect(data[0]).toBe(123);
    });
  });
  it('should get save customer contacts', () => {
    const payload = {
      jobId: 4552,
      drAddressId: 122,
      jobRoleAsnId: 4356,
    };
    service.saveCustomerContact(34, payload).subscribe((data: any) => {
      expect(data[0]).toBe(1);
    });
  });

  it('should call on setSortConfig and getSortConfig', () => {
    const sort = [{ field: 'lastUpdate', dir: 'desc' }, { field: 'jobName', dir: 'asc' }];
    service.setSortConfig(sort);
    expect(service.getSortConfig()).toBe(sort);
  });

  it('should call on setSalesOfficeId and getSalesOfficeId', () => {
    service.setSalesOfficeId(1);
    expect(service.getSalesOfficeId()).toBe(1);
  });

  it('should get all job information on getJobAllInfo', () => {
    const jobId = 4552;
    const drAddressId = 122;
    service.getJobAllInfo(drAddressId, jobId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should get the job role type list on getJobRoleTypes in jobService', () => {
    const drAddressId = 122;
    service.getJobRoleTypes(drAddressId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
    // check exception scenario in service
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getJobRoleTypes(drAddressId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get the job locked user list on getJobLockedUserDetails in jobService', () => {
    const drAddressId = 122;
    const jobId = 4552;
    service.getJobLockedUserDetails(drAddressId, jobId).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
    // check exception scenario in service
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getJobLockedUserDetails(drAddressId, jobId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
  it('should get the document list on getDocumentList in jobService', () => {
    const drAddressId = 122;
    const jobId = 4552;
    const skip = 0;
    const take = 10;
    const documentTypeId = 5;
    const documentDetailsList = {
      documentList: [{
        documentKey: 'Jobs/78/27397/Upload2.txt',
        documentName: 'Upload2.txt',
        documentSource: null,
        documentVersion: 'h86MljuQOl02chH879lDRn3aEInRty5w',
        jobId: 27397,
        notes: null,
        totalCount: 11,
        uploadedDate: '2019-09-26T02:03:39',
        uploadedBy: 'Pandey, Shruti',
      }],
      totalItemCount: 1,
    } as IDocumentDetailsList;
    const spyDocument = spyOn(httpClient, 'get').and.returnValue(Observable.of(documentDetailsList));
    service.getDocumentList(drAddressId, jobId, documentTypeId, folderId, skip, take).subscribe((data: IDocumentDetailsList) => {
      expect(data.totalItemCount).toBeGreaterThan(0);
    });
    // check exception scenario in service
    spyDocument.and.returnValue(Observable.throwError({ error: 'error' }));
    service.getDocumentList(drAddressId, jobId, documentTypeId, folderId, skip, take).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should get the document history list details on getJobLockedUserDetails in jobService', () => {
    const drAddressId = 122;
    const jobId = 4552;
    const documentName = 'BidsCrossReference(1).xlsx';
    service.getJobDocumentHistoryDetails(drAddressId, jobId, documentName, folderId).subscribe((data: DocumentDetails[]) => {
      expect(data.length).toBeGreaterThan(0);
    });
    // check exception scenario in service
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.getJobDocumentHistoryDetails(drAddressId, jobId, documentName, folderId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should delete the document in job detail section', () => {
    const jobId = 78;
    const drAddressId = 27440;
    const documentKey = 'Jobs/78/27440/new 8.txt';
    service.deleteDocument(drAddressId, jobId, documentKey).subscribe((data: any) => {
      expect(data).toBe(true);
    });
  });
  it('should check error on service method deleteDocument', () => {
    const jobId = 78;
    const drAddressId = 27440;
    const documentKey = 'Jobs/new 8.txt';
    spyOn(httpClient, 'delete').and.returnValue(Observable.throwError({ error: 'error' }));
    service.deleteDocument(drAddressId, jobId, documentKey).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should download the document in job detail section', () => {
    const jobId = 78;
    const drAddressId = 27440;
    const documentKey = 'Jobs/78/27440/new 8.txt';
    const documentVersion = 'jI9eTNWgMHDdfqjYF4luqFld_qC7UfzY';
    service.downloadDocument(drAddressId, jobId, documentKey, documentVersion, documentStorage).subscribe((data: any) => {
      expect(data).toBeDefined();
    });
  });

  it('should check error on service method downloadDocument', () => {
    const jobId = 78;
    const drAddressId = 27440;
    const documentKey = 'Jobs/new 8.txt';
    const documentVersion = ' ';
    spyOn(httpClient, 'get').and.returnValue(Observable.throwError({ error: 'error' }));
    service.downloadDocument(drAddressId, jobId, documentKey, documentVersion, documentStorage).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should set modified job name on latestJobName()', () => {
    service.latestJobName(modifiedJobName);
    service.latestJobName$.subscribe((jobName) => {
      expect(jobName).toEqual(modifiedJobName);
    });
  });

  it(`should transmit a job on calling transmitJob method`, () => {
    const payload = {
      sourceJobId: 5678,
      sourceDrAddressId: 94,
      action: 'copy',
      jobName: modifiedJobName,
      jobContact: 'ccfsas',
      commissionCode: 'A01',
    };
    service.transmitJob(payload).subscribe((data: any) => {
      expect(data).toBeDefined();
    });
  });

  it(`should throw error when service failed to transmit job on calling transmitjob method`, () => {
    const payload = {
      sourceJobId: 5678,
      sourceDrAddressId: 94,
      action: 'copy',
      jobName: modifiedJobName,
      jobContact: 'ccfsas',
      commissionCode: 'A01',
    };
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.transmitJob(payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it(`should export a job after crm validation on calling exportJob method`, () => {
    const payload = {
      sourceJobId: 9847,
      sourceDrAddressId: 122,
      destinationDrAddressId: 105,
      action: 'Export',
      jobName: 'Test Job',
      jobContact: 'ccfsas',
      commissionCode: 'A01',
      crmOpportunityId: '5647',
      destinationDataBaseName: 'Alaska',
    };
    service.exportJob(payload).subscribe((data: any) => {
      expect(data).toBeDefined();
    });
  });

  it(`should throw error when service failed to export job on calling exportJob method`, () => {
    const payload = {
      sourceJobId: 9847,
      sourceDrAddressId: 122,
      destinationDrAddressId: 105,
      action: 'Export',
      jobName: 'Test Job',
      jobContact: 'ccfsas',
      commissionCode: 'A01',
      crmOpportunityId: ' ',
      destinationDataBaseName: 'Alaska',
    };
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.exportJob(payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it(`should return true on calling importJob method`, () => {
    const payload = {
      sourceJobId: 5678,
      sourceDrAddressId: 94,
      action: 'copy',
      jobName: modifiedJobName,
      jobContact: 'ccfsas',
      commissionCode: 'A01',
    };
    spyOn(httpClient, 'get').and.returnValue(Observable.of(true));

    service.importJob(payload).subscribe((data: any) => {
      expect(data).toBe(true);
    });
  });

  it(`should throw error on calling importJob method when service throws error`, () => {
    const payload = {
      sourceJobId: 5678,
      sourceDrAddressId: 94,
      action: 'copy',
      jobName: modifiedJobName,
      jobContact: 'ccfsas',
      commissionCode: 'A01',
    };
    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));

    service.importJob(payload).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });

  });

  it('should get job basic information', () => {
    service.getJobBasicInfo(59297, 34).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should return followed job on calling getFollowedJobCount', () => {
    const followedJobCount = 3;
    const drAddressId = 122;
    spyOn(httpClient, 'get').and.returnValue(Observable.of(followedJobCount));
    service.getFollowedJobCount(drAddressId).subscribe((data: any) => {
      expect(data).toBe(followedJobCount);
    });
  });

  it('should set favorite job', () => {
    service.updateFavorite(34, 59297).subscribe((data: any) => {
      expect(data).toBeDefined();
    });
  });

  it('should set favorite job when service throws error', () => {
    spyOn(httpClient, 'put').and.returnValue(Observable.throwError({ error: 'error' }));
    service.updateFavorite(34, 59297).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });

  it('should fetch shipping address for job', () => {
    service.getBasicShippingInstruction(94, 1234).subscribe((data: any) => {
      expect(data.length).toBeGreaterThan(0);
    });
  });

  it('should fetch maximum shipping instruction id used by job id', () => {
    const shippingInstructionId = 3;
    const jobId = 123;
    const drAddressId = 122;
    spyOn(httpClient, 'get').and.returnValue(Observable.of(shippingInstructionId));
    service.getMaxShippingInstructionID(jobId, drAddressId).subscribe((data: number) => {
      expect(data).toBe(shippingInstructionId);
    });
  });

  it('should get custom sender details on calling getCustomSenderDetails', () => {
    const customSender = [
      {
        customSenderId: 'object1',
        customSenderNickName: 'Jay',
        senderName: 'JayRam',
        title: 'doc12',
        cellPhoneNumber: '4537898',
        emailAddress: 'jay@irco.com',
        customSenderDrAddressId: 23,
      },
    ] as ICustomSenderDetails[];
    const drAddressId = 122;
    spyOn(httpClient, 'get').and.returnValue(Observable.of(customSender));
    service.getCustomSenderDetails(drAddressId).subscribe((res: ICustomSenderDetails[]) => {
      expect(res).toEqual(customSender);
    });
  });

  it('should create a custom sender calling createCustomSender', () => {
    const createPayload = {
      customSenderNickName: 'Jay',
      senderName: 'JayRam',
      title: 'doc12',
      cellPhoneNumber: '4537898',
      emailAddress: 'jay@irco.com',
      jobDrAddressId: 122,
      customSenderDrAddressId: 23,
      officePhoneNumber: '96786754',
      officeFaxNumber: '89877687',
      createdBy: 'ccefd',
      lastModifiedBy: 'ccefd',
    };
    const drAddressId = 122;
    service.createCustomSender(drAddressId, createPayload).subscribe();
    const req = httpMock.expectOne(`${appConstants.API_BASE_URL_JOB}/${drAddressId}/CustomSender`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ customSender: createPayload });
    req.flush({});
  });

  it('should update existing custom sender calling updateCustomSender', () => {
    const updatePayload = {
      customSenderId: 'h78h-8989j-jkj9',
      customSenderNickName: 'Nick',
      senderName: 'Nick Frost',
      title: 'doc12',
      cellPhoneNumber: '4537898',
      emailAddress: 'nick@xyz.com',
      jobDrAddressId: 122,
      customSenderDrAddressId: 23,
      officePhoneNumber: '96786754',
      officeFaxNumber: '89877687',
      lastModifiedBy: 'ccefd',
    };
    const drAddressId = 122;
    service.updateCustomSender(drAddressId, updatePayload).subscribe();
    const req = httpMock.expectOne(`${appConstants.API_BASE_URL_JOB}/${drAddressId}/CustomSender`);
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual({ customSender: updatePayload });
    req.flush({});
  });

  it('should delete existing custom sender with respect to customSenderId by calling deleteCustomSender', () => {
    const customSenderId = 'h78h-8989j-jkj9';
    const drAddressId = 122;
    service.deleteCustomSender(drAddressId, customSenderId).subscribe();
    const req = httpMock.expectOne(`${appConstants.API_BASE_URL_JOB}/${drAddressId}/CustomSender/${customSenderId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush({});
  });

  it('should fetch country on calling getCountryFromCountryCode', () => {
    service.getCountryFromCountryCode('IND').subscribe((data: ICountryModel) => {
      expect(data.countryName).toEqual('INDIA');
    });
  });

  it('should get resource url of the document in sharepoint on calling moveDocumentToSharePoint', () => {
    const sharePointDocument = {
      fileLocation: '',
      uniqueId: '',
    } as SharePointDocumentDetail;
    const drAddressId = 122;
    const folderName = 'New folder';
    const jobId = 63520;
    const fileUploadInfo = {
      documentStorage: 's3',
      jobDocumentId: 34,
      documentKey: 'job/101/63520/document.doc',
      documentName: 'document.doc',
    } as IDocumentDetails;
    spyOn(httpClient, 'get').and.returnValue(Observable.of(sharePointDocument));
    service.moveDocumentToSharePoint(drAddressId, jobId, fileUploadInfo, folderName, folderId)
      .subscribe((documentResource: SharePointDocumentDetail) => {
        expect(documentResource).toEqual(sharePointDocument);
      });
  });

  it('should throw error ( based on response from service ) on calling moveDocumentToSharePoint', () => {
    const drAddressId = 122;
    const folderName = 'New folder';
    const jobId = 2;
    const fileUploadInfo = {
      documentStorage: '',
      jobDocumentId: 34,
      documentKey: '',
      documentName: 'document.doc',
    } as IDocumentDetails;

    spyOn(httpClient, 'post').and.returnValue(Observable.throwError({ error: 'error' }));
    service.moveDocumentToSharePoint(drAddressId, jobId, fileUploadInfo, folderName, folderId).subscribe(() => {
    }, (err) => { expect(err.error).toBe('error'); });
  });
});
