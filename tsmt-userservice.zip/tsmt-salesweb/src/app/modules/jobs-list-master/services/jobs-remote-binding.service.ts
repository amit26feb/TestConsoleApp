
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { AppConstants } from '../../../shared/constants/constants';
import { IJobDomainList } from '../modal/job-details-edit.model';

@Injectable()
export class JobsRemoteBindingService extends BehaviorSubject<any> {
  public loading: boolean;
  public totalAPIData;
  sortParameter = new BehaviorSubject<any>([{ field: 'joB_NAME', dir: 'asc' }, { field: 'lasT_UPDATE', dir: 'desc' }]);
  sortParameterValue$ = this.sortParameter.asObservable();
  private BASE_URL = this.appconstants.API_BASE_URL_JOB;
  private params: any;
  public jobStatusList: IJobDomainList[] = [];
  public jobListData: any;
  public filterObj;
  public drAddressId: number;

  constructor(private http: HttpClient,
              private appconstants: AppConstants) {
    super(http);
  }

  public query(state: any): void {
    const fetch$ = this.fetch(state);
    if (fetch$) {
      fetch$.subscribe((x) => {
        super.next(x);
      }, (error) => {
        console.error(error);
      });
    }
  }

  /* making an API call to fetch the data based on the filter and sort applied
  GetByOptions  Gets JobList with paging options as per the start index, end index,
                 sort key and filter conditions (Modified)*/

  public fetch(state: any): Observable<any> {
    this.loading = true;
    if (this.drAddressId) {
      return this.http
        .post(`${this.BASE_URL}` + '/' + this.drAddressId + '/Jobs/Items', state)
        .pipe(
          tap((d) => this.totalAPIData = d),
          map((res) => {
            this.loading = false;
            if (res != null) {
              return ({
                data: res['jobList'],
                total: res['totalItemCount'],
              } as GridDataResult);
            } else {
              return ({
                data: [],
                total: 0,
              } as GridDataResult);
            }
          },
          )).catch((err: HttpErrorResponse) => {
            return (Observable.of({
              data: [],
              total: 0,
            }));
          });
    }
  }

  // This method is used to get the officeSelector object.
  get officeSelector(): number {
    return this.drAddressId;
  }
  // This method is used to set the officeSelector object.
  set officeSelector(data: number) {
    this.drAddressId = data;
  }


}
