import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IDashboardPreference } from '../../../shared/model/dashboard-preferences';
import { AppConstants } from '../../../shared/constants/constants';
import { IJobContactDetails } from '@tsmt/salesweb-ordersmodule';
import { IActiveDirectory, IGridState, IUserModel } from '../models/user-model';

@Injectable()
export class UserService {
  private BASE_URL = this.appconstants.API_BASE_URL_USER;

  constructor(private httpClient: HttpClient, private appconstants: AppConstants) { }

  // Get users by userIds
  getUsers(userIds: string[]): Observable<IUserModel[]> {
    return this.httpClient.post<IUserModel[]>(this.BASE_URL + '/Users/Search', userIds);
  }
  getUserDetails(emailAddress: string): Observable<IJobContactDetails> {
    const options = new HttpParams().set('emailId', emailAddress);
    return this.httpClient.get<IJobContactDetails>(`${this.BASE_URL}/Users/UserDetail`, { params: options });
  }

  ///// This group of service calls is in shared core in GridPreferenceService but that comes with some baggage so for now these are here

  // Gets user preference
  getGridStates(userId: string, route: string, gridId: string): Observable<[IGridState]> {
    const query = `?appId=${this.appconstants.applicationId}&route=${route}&gridId=${gridId}`;
    return this.httpClient.get<[IGridState]>(`${this.BASE_URL}/User/${userId}/Preferences/GridState${query}`);
  }

  // Create user preference
  createGridState(userId: string, gridState: IGridState): Observable<IGridState> {
    return this.httpClient.post<IGridState>(`${this.BASE_URL}/User/${userId}/Preferences/GridState`, { GridPreference: gridState });
  }

  // Update user preference
  updateGridState(userId: string, gridUpdate: IGridState): Observable<IGridState> {
    return this.httpClient.put<IGridState>(`${this.BASE_URL}/User/${userId}/Preferences/GridState`, gridUpdate);
  }

  /**
   * Get users data from active directory.
   * Returns users data as IActiveDirectory list.
   */
  getUsersFromActiveDirectory(searchText: string): Observable<IActiveDirectory[]> {
    return this.httpClient.get<IActiveDirectory[]>(`${this.BASE_URL}/Users/ActiveDirectory/Search?searchText=${searchText}`)
      .catch((error: any) => []);
  }

  getDashboardPreferences() {
    return this.httpClient.get<IDashboardPreference>(`${this.BASE_URL}/Applications/${this.appconstants.applicationId}/Preferences/Dashboard`);
  }

  setDashboardPreferences(dashboardPreference: IDashboardPreference) {
    return this.httpClient.put<IDashboardPreference>(`${this.BASE_URL}/Applications/${this.appconstants.applicationId}/Preferences/Dashboard`, dashboardPreference);
  }
}
