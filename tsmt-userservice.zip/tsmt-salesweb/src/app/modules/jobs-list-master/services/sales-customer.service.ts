import { PayloadModel } from '@tsmt/salesweb-jobsmodule/lib/models/job-summary-selection.model';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConstants } from '../../../shared/constants/constants';
import { ICustomerModel, ISearchCustomerListModel, IStateModel } from '../modal/job-details-edit.model';
import { ISearchContactListModel } from './../models/create-crm.model';
@Injectable()
export class SalesCustomerService {
  private BASE_URL = this.appconstants.API_BASE_URL_JOB;
  private params: any;
  public errorInfo = 'Server error';
  public controllerName = '/SalesCustomer/';
  constructor(private http: HttpClient, private appconstants: AppConstants) { }

  getCustomerName(data, drAddressId) {
    const options = new HttpParams().set('search', data);
    return this.http.get<ICustomerModel[]>(this.BASE_URL + '/' + drAddressId + '/SalesCustomer/Names', { params: options });
  }

  getCustomerAccountNumber(data, drAddressId) {
    const options = new HttpParams().set('search', data);
    return this.http.get<ICustomerModel[]>(this.BASE_URL + '/' + drAddressId + '/SalesCustomer/AccountNumbers', { params: options });
  }

  getCustomerPhoneNumbers(data, drAddressId) {
    const options = new HttpParams().set('search', data);
    return this.http.get<ICustomerModel[]>(this.BASE_URL + '/' + drAddressId + '/SalesCustomer/PhoneNumbers', { params: options });
  }

  getCustomerPostalCode(data, drAddressId) {
    const options = new HttpParams().set('search', data);
    return this.http.get<ICustomerModel[]>(this.BASE_URL + '/' + drAddressId + '/SalesCustomer/PostalCodes', { params: options });
  }

  getCustomerInternationalStateCode(data, drAddressId) {
    const options = new HttpParams().set('search', data);
    return this.http.get<IStateModel[]>(this.BASE_URL + '/' + drAddressId + '/SalesCustomer/States', { params: options });
  }

  createCustomer(data, drAddressId): Observable<any> {
    const headers = new HttpHeaders();
    if (data.salesCustId > 0) {
      // Update Customer with Contacts
      return this.http.put(this.BASE_URL + '/' + drAddressId + this.controllerName + data.salesCustId, data, { headers })
        .map((res: any) => res)
        .catch((error: any) => {
          return Observable.throwError(error || this.errorInfo);
        });
    } else {
      // Create Customer with Contacts
      return this.http.post(this.BASE_URL + '/' + drAddressId + '/SalesCustomer', data, { headers })
        .map((res: any) => res)
        .catch((error: any) => {
          return Observable.throwError(error || this.errorInfo);
        });
    }
  }

  getSearchCustomers(skip: number, take: number, searchValue: string, drAddressId: number,
    gridState?: PayloadModel): Observable<ISearchCustomerListModel> {
    let options = new HttpParams().set('skip', skip?.toString()).set('take', take?.toString());
    if (searchValue) {
      options = options.set('searchText', searchValue);
    }
    return this.http.post<ISearchCustomerListModel>(this.BASE_URL + '/' + drAddressId + '/SalesCustomer/Items',
      gridState,
      {
        params: options,
      })
      .map((res: any) => {
        if (res !== null && res.customerList) {
          res.customerList.map((x) => {
            x.phoneNumber = this.formatPhoneAndFaxNumber(x.phoneNumber);
            x.faxNumber = this.formatPhoneAndFaxNumber(x.faxNumber);
          });
        }
        return res;
      }, (error) => {
        console.error('sales-customer.service::getSearchCustomers: %o', error);
      })
      .catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }

  assignCustomer(data, drAddressId): Observable<any> {
    const headers = new HttpHeaders();
    return this.http.post(this.BASE_URL + '/' + drAddressId + this.controllerName + 'Job/' + data.jobId +
      '/CustomerAssignments', data, { headers })
      .map((res: any) => res)
      .catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }

  getAssignCustomers(skip, take, jobId, drAddressId): Observable<any> {
    const options = new HttpParams().set('skip', skip).set('take', take);
    return this.http.get<any>(this.BASE_URL + '/' + drAddressId + this.controllerName + 'Job/' +
      jobId + '/CustomerAssignments', { params: options })
      .map((data: any) => {
        if (data !== null && data.customerList) {
          data.customerList.map((c) => {
            c.phoneNbr = this.formatPhoneAndFaxNumber(c.phoneNbr);
            c.faxNbr = this.formatPhoneAndFaxNumber(c.faxNbr);
          });
        }
        return data;
      }).catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }

  unassignCustomer(jobRoleAsnId, drAddressId, jobId): Observable<any> {
    return this.http.delete<any>(this.BASE_URL + '/' + drAddressId + this.controllerName +
      'Job/' + jobId + '/CustomerAssignments/' + jobRoleAsnId)
      .map((res: any) => res)
      .catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }
  formatPhoneAndFaxNumber(obj) {
    return obj ? obj.replace(/[^\d]+/g, '')
      .replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3') : '';
  }

  getCustomerAndContactsList(salesCustId, drAddressId) {
    return this.http.get<any>(this.BASE_URL + '/' + drAddressId + this.controllerName + salesCustId)
      .catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }


  deleteCustomerContact(salesCustId, drAddressId, customerContactId): Observable<any> {
    return this.http.delete<any>(this.BASE_URL + '/' + drAddressId + this.controllerName + salesCustId + '/Contacts/' + customerContactId)
      .map((res: any) => res)
      .catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }

  updateAssignCustomer(data, drAddressId, jobId): Observable<any> {
    const headers = new HttpHeaders();
    return this.http.put(this.BASE_URL + '/' + drAddressId + '/SalesCustomer/Job/' + jobId +
      '/CustomerAssignments/' + data.jobRoleAsnId, data, { headers })
      .map((res: any) => res)
      .catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }

  // Service method to delete a customer from the database
  deleteCustomer(salesCustId, drAddressId): Observable<any> {
    return this.http.delete<any>(this.BASE_URL + '/' + drAddressId + this.controllerName + salesCustId)
      .map((res: any) => res)
      .catch((error: any) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }

  getSearchContacts(skip, take, searchValue, drAddressId): Observable<ISearchContactListModel> {
    const options = new HttpParams()
      .set('skip', skip)
      .set('take', take)
      .set('searchText', searchValue);
    return this.http.get<any>(this.BASE_URL + '/' + drAddressId + this.controllerName + 'Contacts/Search', { params: options })
      .map((res: ISearchContactListModel) => res)
      .catch((error: HttpErrorResponse) => {
        return Observable.throwError(error || this.errorInfo);
      });
  }
}
