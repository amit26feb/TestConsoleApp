import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, getTestBed, TestBed, tick } from '@angular/core/testing';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { of, throwError } from 'rxjs';
import { CoordinateFormComponent } from '../../../shared/components/coordinate-form/coordinate-form.component';
import { CoordinateService } from '../services/coordinate.service';
import { JobLockService } from '@tsmt/shared-core-salesweb';
import { CoordinateStatusComponent } from './../../../shared/components/coordinate-status-grid/coordinate-status.component';
import { SubmissionNotesComponent } from './../../../shared/components/submission-notes/submission-notes.component';
import { AppConstants } from './../../../shared/constants/constants';
import { ApiErrorService } from './../../../shared/services/apierror.service';
import { JobCoordinationMergeService } from './../../../shared/services/job-coordination-merge.service';
import { JobCoordinationValidationService } from './../../../shared/services/job-coordination-validation.service';
import { JobHeaderService } from './../../../shared/services/job-header.service';
import { LoaderService } from './../../../shared/services/loader.service';
import { ToasterService } from './../../../shared/services/toaster.service';
import { IBid, ICoordinateRequest, IDraftSelection, IJobCoordinationForm, ISelection } from './../models/coordinate-job.model';
import { ExitJobService } from './../services/exit-job.service';
import { JobsServicesService } from './../services/jobs-services.service';
import { CoordinateComponent } from './coordinate.component';

// tslint:disable-next-line: no-big-function
describe('CoordinateComponent', () => {
  let component: CoordinateComponent;
  let fixture: ComponentFixture<CoordinateComponent>;
  let injector: TestBed;
  let jobHeaderService: JobHeaderService;
  let jobLockService: JobLockService;
  let coordinateService: CoordinateService;
  let toasterService: ToasterService;
  let jobService: JobsServicesService;
  let jobCoordinationMergeService: JobCoordinationMergeService;
  let jobCoordinationValidationService: JobCoordinationValidationService;
  let exitJobService: ExitJobService;
  let loaderService: LoaderService;
  let testWidgetInfo;
  let testRequestedDate;
  const testJobId = 1234;
  const testDrAddressId = 122;
  const testUserId = 'xxabc';
  const documentKey = ['Jobs/78/27440/new 9.txt'];
  const lockFetchFailMessage = 'job lock fetch failed';
  const saveFailMessage = 'save failed';
  const testDate = '2020-04-01T10:46:50';
  const coordinationStatusOptions = {
    submitted: 'Submitted',
    notSubmitted: 'Not Submitted',
    pendingPricing: 'Pending Pricing',
    escalated: 'Escalated',
    escalationComplete: 'Escalation Complete',
    pricingComplete: 'Pricing Complete',
    spaIssuedDiscountActive: 'SPA Issued/Discount Active',
    releasedWithoutDiscount: 'Released w/o Discount',
    recoordinated: 'Recoordinated',
    errorInSubmission: 'Error in Submission',
  };
  const nonCrmJobDetails = {
    commissionCode: 'R22',
    crmOpportunityId: null,
    icsJobIndicator: 'N',
    jobContact: 'tssea34',
    quickTurnaroundIndicator: 'N',
    requestedDate: testDate,
    pricingSpaNumber: 2456,
  };
  const crmJobDetails = {
    commissionCode: 'R22',
    crmOpportunityId: '235674',
    icsJobIndicator: 'N',
    jobContact: 'tssea34',
    quickTurnaroundIndicator: 'N',
    requestedDate: testDate,
    pricingSpaNumber: 2456,
  };
  const testCoordinateData = {
    jobCoordinationGeneralInfo: {
      requestedDate: testDate,
      quickTurnaroundIndicator: 'Y',
      icsJobIndicator: 'N',
      jobContact: 'cceenp',
      commissionCode: 'X00',
      crmOpportunityId: '1811024',
    },
    jobNotes: {
      jobId: 1,
      noteString: 'Test Note',
      drAddressId: 122,
    },
    submissionNotes: {
      jobId: 1,
      sequenceNumber: 1,
      drAddressId: 122,
      noteLine: 'Test submission notes',
    },
    coordinationData: {
      submissionNotes: 'test Notes',
    },
  };
  const testCoordinateBidData = {
    bidDataForCoordination: [{
      bidAlternateId: 2087,
      bidName: 'Base Bid',
      isCurrentBid: true,
      isBidInCoordinationJob: true,
      isSubmitted: false,
      isDisabled: false,
    }],
  };
  const jobLockedByuser = {
    userId: 'abcdef',
    userName: 'vishveshraj, rajasekar',
    firstName: 'rajasekar',
    lastName: 'vishveshraj',
  };
  const data = [{
    assignedTo: ' ',
    bids: [],
    coordinationId: 20,
    coordinationJobData: null,
    coordinationStatus: 'Submitted',
    coordinator: ' ',
    drAddressId: 101,
    jobId: 37499,
    pricingSPANumber: null,
    submittedOn: null,
  },
  {
    assignedTo: ' ',
    bids: [],
    coordinationId: 21,
    coordinationJobData: null,
    coordinationStatus: coordinationStatusOptions.notSubmitted,
    coordinator: ' ',
    drAddressId: 101,
    jobId: 37599,
    pricingSPANumber: null,
    submittedOn: null,
  },
  ];
  const errorClass = {
    submissionException: 'submission-exception',
    dateNotSet: 'date-not-set',
    invalidSelection: 'invalid-selection',
    invalidShipLeadTime: 'lead-time-invalid',
    invalidJobContactException: 'job-contact-invalid',
    invalidSalesPersonException: 'sales-person-invalid',
  };
  const pageWidgets = {
    submissionNotes: 'submission-notes',
    coordinateForm: 'coordinate-form',
    coordinateBids: 'coordinate-bids',
    bom: 'bom',
  };
  const TestRoutes: Routes = [
    {
      path: '**',
      component: CoordinateComponent,
    }];
  const originReset = TestBed.resetTestingModule;
  const formBuilder: FormBuilder = new FormBuilder();
  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [CoordinateComponent],
      imports: [
        RouterTestingModule.withRoutes(TestRoutes),
        HttpClientTestingModule,
      ],
      providers: [
        { provide: ActivatedRoute, useValue: { snapshot: { params: { jobId: testJobId, drAddressId: testDrAddressId } } } },
        {
          provide: AppConstants, useValue: { API_BASE_URL_JOB: '' },
        },
        CoordinateService,
        { provide: FormBuilder, useValue: formBuilder },
        JobHeaderService,
        JobLockService,
        ToasterService,
        JobsServicesService,
        JobCoordinationValidationService,
        ExitJobService,
        LoaderService,
        ApiErrorService,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
  }));

  beforeEach(() => {
    injector = getTestBed();
    fixture = TestBed.createComponent(CoordinateComponent);
    component = fixture.componentInstance;
    jobHeaderService = injector.inject(JobHeaderService);
    jobLockService = injector.inject(JobLockService);
    coordinateService = injector.inject(CoordinateService);
    toasterService = injector.inject(ToasterService);
    jobService = injector.inject(JobsServicesService);
    jobCoordinationMergeService = injector.inject(JobCoordinationMergeService);
    jobCoordinationValidationService = injector.inject(JobCoordinationValidationService);
    exitJobService = injector.inject(ExitJobService);
    loaderService = injector.inject(LoaderService);
    spyOn(coordinateService, 'fetchCoordinateJobData').and.returnValue(of(testCoordinateData));
    spyOn(coordinateService, 'fetchCoordinateBidData').and.returnValue(of(testCoordinateBidData));
    spyOn(coordinateService, 'fetchCoordinateRequest').and.returnValue(of(data));
    fixture.detectChanges();
    jobHeaderService.setUserId(testUserId);
    component.drAddressId = 122;
    component.coordinationId = 123;
    testWidgetInfo = {
      name: 'Bids',
      payloadKey: 'bidsViewModel',
      payloadMethod: 'buildBidsPayload',
      data: [],
    };
    testRequestedDate = '01/01/2019';
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit job lock status on load', () => {
    const sampleData = {
      jobLockUserId: 'ccefaa',
      readOnly: false,
    };
    const spyJobLockStatus = spyOn(jobCoordinationValidationService, 'setJobLockedByMeFlag');
    const spyJobLockService = spyOn(jobLockService, 'getLockInfo').and.returnValue(of(sampleData));
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.ngOnInit();
    expect(spyJobLockService).toHaveBeenCalled();
    expect(spyJobLockStatus).toHaveBeenCalledWith(true);
    expect(component.jobLockUserId).toEqual(sampleData.jobLockUserId);
  });

  it('should set jobId and drAddressId from the route parameters when component is initialized', () => {
    spyOn(jobCoordinationMergeService, 'setJobId');
    spyOn(jobCoordinationMergeService, 'setDrAddressId');
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.ngOnInit();
    expect(component.jobId).toBe(testJobId);
    expect(component.drAddressId).toBe(testDrAddressId);
    expect(jobCoordinationMergeService.setJobId).toHaveBeenCalled();
    expect(jobCoordinationMergeService.setDrAddressId).toHaveBeenCalled();
  });

  it('should call setJob method on JobHeaderService when component is initialized', () => {
    const spy = spyOn(jobHeaderService, 'setJob').and.callThrough();
    const spyJobValidationService = spyOn(jobCoordinationValidationService, 'clearTimerForJobDetailsValidation');
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.ngOnInit();
    expect(spy).toHaveBeenCalled();
    expect(spyJobValidationService).toHaveBeenCalled();
  });

  it('should call createTimerForJobDetailsValidation on destroy', () => {
    const spyJobValidationService = spyOn(jobCoordinationValidationService, 'createTimerForJobDetailsValidation');
    component.ngOnDestroy();
    expect(spyJobValidationService).toHaveBeenCalled();
  });

  it('should fetch job coordinate data when handleCoordinateRequestSelectionChange is called', fakeAsync(() => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData').and.callThrough();
    const testCoordinateFormData = { icsJobIndicator: 'N' } as IJobCoordinationForm;
    const spy = spyOn(jobCoordinationMergeService, 'buildJobDetails').and.returnValue(testCoordinateFormData);
    const spybuildBidDetails = spyOn(jobCoordinationMergeService, 'buildBidData').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(data[0]);
    tick();
    expect(component.coordinationId).toBe(20);
    expect(spyGetCoordinateData).toHaveBeenCalled();
    expect(component.coordinateJobDataLoaded).toBe(true);
    expect(component.jobCoordinationData).toBe(testCoordinateData);
    expect(component.submissionNotes.noteLine).toBe(testCoordinateData.coordinationData.submissionNotes);
    expect(component.jobCoordinationInput).toBe(testCoordinateFormData);
    expect(component.jobNotes).toBe(testCoordinateData.jobNotes);
    expect(spy).toHaveBeenCalled();
    expect(spybuildBidDetails).toHaveBeenCalled();
  }));

  it('should emit false to setCoordinationStatusFlag() if handleCoordinateRequestSelectionChange is called with null', fakeAsync(() => {
    const spyCoordinationStatus = spyOn(jobCoordinationValidationService, 'setCoordinationStatusFlag');
    component.handleCoordinateRequestSelectionChange(null);
    tick();
    expect(spyCoordinationStatus).toHaveBeenCalledWith(false);
  }));

  it('should emit false to setCoordinationStatusFlag() if coordination status is other than Not Submitted', fakeAsync(() => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData').and.callFake(() => { });
    const spyCoordinationStatus = spyOn(jobCoordinationValidationService, 'setCoordinationStatusFlag');
    component.handleCoordinateRequestSelectionChange(data[0]);
    tick();
    expect(spyCoordinationStatus).toHaveBeenCalledWith(false);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  }));

  it('should emit true to setCoordinationStatusFlag if coordination status is Not Submitted', fakeAsync(() => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData').and.callFake(() => { });
    const spyCoordinationStatus = spyOn(jobCoordinationValidationService, 'setCoordinationStatusFlag');
    component.handleCoordinateRequestSelectionChange(data[1]);
    tick();
    expect(spyCoordinationStatus).toHaveBeenCalledWith(true);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  }));

  it('should fetch bid coordinate data when handleCoordinateRequestSelectionChange is called', fakeAsync(() => {
    const sampleJobData = {
      coordinatedJobGeneralInfo: {
        assignedTo: 'Tim',
        coordinator: 'Suzie',
        coordinationStatus: coordinationStatusOptions.notSubmitted,
        submittedOn: null,
      },
      discountConfirmationDetails: [
        {
          bidAlternateId: 123,
          isDiscountConfirmed: true,
        },
      ],
    };
    component.hasBeenPreviouslyCoordinated = true;
    const spybuildBidData = spyOn(jobCoordinationMergeService, 'buildBidData').and.callFake(() => { });
    const spyFetchCoordinateJobGeneralData = spyOn(coordinateService, 'fetchCoordinateJobGeneralData').and.returnValue(of(sampleJobData));
    component.handleCoordinateRequestSelectionChange(data[1]);
    tick();
    expect(spybuildBidData).toHaveBeenCalled();
    expect(component.coordinateBidDataLoaded).toBe(true);
    expect(component.bidData).toEqual(testCoordinateBidData.bidDataForCoordination);
    expect(spyFetchCoordinateJobGeneralData).toHaveBeenCalled();
  }));

  it('should get lock info to set read only state in ngOnInit', () => {
    const spyGetLockInfo = spyOn(jobLockService, 'getLockInfo').and.returnValue(of({ readOnly: true }));
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.ngOnInit();
    expect(spyGetLockInfo).toHaveBeenCalled();
    expect(component.isJobLockedToCurrentUser).toBe(false);
  });

  it('should display a toaster error message when showErrorMessage is called', () => {
    const spy = spyOn(toasterService, 'setToaster');
    component.showErrorMessage('test error message');
    expect(spy).toHaveBeenCalled();
  });

  it('should save submission notes when saveSubmissionNotes is called', fakeAsync(() => {
    const form: FormGroup = formBuilder.group({ notes: 'test notes 1' });
    const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(of({}));
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('abcdef');
    component.saveSubmissionNotes(form, false);
    tick();
    expect(spy).toHaveBeenCalled();
  }));

  it('should show error when save submission notes is failed', fakeAsync(() => {
    const form: FormGroup = formBuilder.group({ notes: 'test notes 2' });
    const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(throwError(saveFailMessage));
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('abcdef');
    const toasterSpy = spyOn(toasterService, 'setToaster');
    component.saveSubmissionNotes(form, false);
    tick();
    expect(spy).toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
  }));

  it('should not save submission notes if the job is locked to other user while saving', fakeAsync(() => {
    const form: FormGroup = formBuilder.group({ notes: 'test notes to check job lock' });
    const spy = spyOn(coordinateService, 'saveCoordinateJobData');
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccefaa');
    component.saveSubmissionNotes(form, false);
    tick();
    expect(spy).not.toHaveBeenCalled();
    expect(component.isReadOnly).toBe(true);
  }));

  it('should not save submission notes if the job lock is not determined', fakeAsync(() => {
    const form: FormGroup = formBuilder.group({ notes: 'test notes to check job lock check fail' });
    const spy = spyOn(coordinateService, 'saveCoordinateJobData');
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(throwError(lockFetchFailMessage));
    component.saveSubmissionNotes(form, false);
    tick();
    expect(spy).not.toHaveBeenCalled();
  }));

  it('should set the selected bids when bid selection change event is received', () => {
    const selectedBids = [{ bidAlternateId: 123 } as IBid, { bidAlternateId: 456 } as IBid];
    component.handleBidSelectionChange(selectedBids);
    expect(component.selectedBidsForCoordination).toBe(selectedBids);
    expect(component.selectedBidIds).toEqual([123, 456]);
    expect(component.selectedBidsChanged).toBe(true);
  });

  it('should set the selected bids if any when handleCoordinateRequestSelectionChange is called', fakeAsync(() => {
    const sampleBid = {
      bidAlternateId: 2087,
      bidName: 'Base Bid',
      isCurrentBid: true,
      isBidInCoordinationJob: true,
    };
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData').and.callThrough();
    const spybuildBidData = spyOn(jobCoordinationMergeService, 'buildBidData').and.returnValue(of(sampleBid));
    tick();
    component.handleCoordinateRequestSelectionChange(data[0]);
    expect(spyGetCoordinateData).toHaveBeenCalled();
    expect(spybuildBidData).toHaveBeenCalled();
    expect(component.selectedBidsForCoordination.length).toBe(1);
    expect(component.selectedBidsForCoordination[0].bidAlternateId).toBe(2087);
    expect(component.selectedBidIds.length).toBe(1);
    expect(component.selectedBidIds[0]).toBe(2087);
  }));

  it('should set coordinateRequestLoaded to true if fetchCoordinateRequest returns data', fakeAsync(() => {
    tick();
    component.getCoordinateRequest();
    expect(component.coordinateRequestLoaded).toBe(true);
  }));

  it('should save documents when saveDocuments is called', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(of({}));
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('abcdef');
    component.saveDocuments(documentKey);
    tick();
    expect(spy).toHaveBeenCalled();
  }));

  it('should show error when save documents is failed', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(throwError(saveFailMessage));
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('abcdef');
    const toasterSpy = spyOn(toasterService, 'setToaster');
    component.saveDocuments(documentKey);
    tick();
    expect(spy).toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
  }));

  it('should not save if the job is locked to other user while saving', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData');
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccefaa');
    component.saveDocuments(documentKey);
    tick();
    expect(spy).not.toHaveBeenCalled();
    expect(component.isReadOnly).toBe(true);
  }));

  it('should not save documents if the job lock is not determined', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData');
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(throwError(lockFetchFailMessage));
    component.saveDocuments(documentKey);
    tick();
    expect(spy).not.toHaveBeenCalled();
  }));

  it('should call getCoordinate method on coordinate request selection change', fakeAsync(() => {
    spyOn(component, 'getCoordinateData');
    spyOn(jobCoordinationMergeService, 'setCoordinationId');
    component.handleCoordinateRequestSelectionChange(data[0]);
    tick();
    expect(component.getCoordinateData).toHaveBeenCalled();
    expect(jobCoordinationMergeService.setCoordinationId).toHaveBeenCalled();
  }));

  it('should set shouldExpandCoordinateDetails to true on coordinate request selection change', fakeAsync(() => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(data[0]);
    tick();
    expect(spyGetCoordinateData).toHaveBeenCalled();
    expect(component.shouldExpandCoordinateDetails).toBe(true);
  }));

  it('should set shouldExpandCoordinateDetails to false on coordination status expand method', fakeAsync(() => {
    component.handleCoordinationStatusExpand();
    tick();
    expect(component.shouldExpandCoordinateDetails).toBeFalsy();
  }));

  it('should call handleCoordinateRequestSelectionChange with null on coordination status expand method', fakeAsync(() => {
    const spyHandleRequestSelectionChange = spyOn(component, 'handleCoordinateRequestSelectionChange');
    component.handleCoordinationStatusExpand();
    tick();
    expect(spyHandleRequestSelectionChange).toHaveBeenCalledWith(null);
  }));

  it('should save widget data when saveWidgetData is called', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(of({}));
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('abcdef');
    spyOn(component, 'buildWidgetPayload').and.callThrough();
    spyOn(component, testWidgetInfo.payloadMethod).and.callThrough();
    const removeWidgetSpy = spyOn(component, 'removeWidgetFromInProgress');
    const exitSpy = spyOn(component, 'checkAndHandleExit');
    component.saveWidgetData(testWidgetInfo);
    expect(component.buildWidgetPayload).toHaveBeenCalledWith(testWidgetInfo);
    expect(component[testWidgetInfo.payloadMethod]).toHaveBeenCalledWith(testWidgetInfo.data);
    tick();
    expect(spy).toHaveBeenCalled();
    expect(removeWidgetSpy).toHaveBeenCalled();
    expect(exitSpy).toHaveBeenCalled();
    expect(component.jobLockUserId).toBe(jobLockedByuser.userId);
  }));

  it('should show error when saving widget data is failed', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(throwError(saveFailMessage));
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('abcdef');
    spyOn(component, 'buildWidgetPayload').and.callThrough();
    spyOn(component, testWidgetInfo.payloadMethod).and.callThrough();
    const removeWidgetSpy = spyOn(component, 'removeWidgetFromInProgress');
    const toasterSpy = spyOn(toasterService, 'setToaster');
    const resetSpy = spyOn(component, 'resetSubmissionState');
    component.saveWidgetData(testWidgetInfo);
    expect(component.buildWidgetPayload).toHaveBeenCalledWith(testWidgetInfo);
    expect(component[testWidgetInfo.payloadMethod]).toHaveBeenCalledWith(testWidgetInfo.data);
    tick();
    expect(spy).toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
    expect(removeWidgetSpy).toHaveBeenCalled();
    expect(resetSpy).toHaveBeenCalled();
  }));

  it('should not save widget data if the job is locked to other user while saving', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData');
    const toasterSpy = spyOn(toasterService, 'setToaster');
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('ccefaa');
    const removeWidgetSpy = spyOn(component, 'removeWidgetFromInProgress');
    const resetSpy = spyOn(component, 'resetSubmissionState');
    const lockSpy = spyOn(component, 'handleJobLockException');
    component.saveWidgetData(testWidgetInfo);
    tick();
    expect(spy).not.toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
    expect(removeWidgetSpy).toHaveBeenCalled();
    expect(resetSpy).toHaveBeenCalled();
    expect(lockSpy).toHaveBeenCalled();
  }));

  it('should not save widget data if the job is not locked', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData');
    const toasterSpy = spyOn(toasterService, 'setToaster');
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of({}));
    const removeWidgetSpy = spyOn(component, 'removeWidgetFromInProgress');
    const resetSpy = spyOn(component, 'resetSubmissionState');
    const lockSpy = spyOn(component, 'handleJobLockException');
    component.saveWidgetData(testWidgetInfo);
    tick();
    expect(spy).not.toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
    expect(removeWidgetSpy).toHaveBeenCalled();
    expect(resetSpy).toHaveBeenCalled();
    expect(lockSpy).toHaveBeenCalled();
  }));

  it('should not save widget data if the job lock is not determined', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'saveCoordinateJobData');
    const toasterSpy = spyOn(toasterService, 'setToaster');
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(throwError(lockFetchFailMessage));
    const removeWidgetSpy = spyOn(component, 'removeWidgetFromInProgress');
    const resetSpy = spyOn(component, 'resetSubmissionState');
    component.saveWidgetData(testWidgetInfo);
    tick();
    expect(spy).not.toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
    expect(removeWidgetSpy).toHaveBeenCalled();
    expect(resetSpy).toHaveBeenCalled();
  }));

  it('should build and return bids payload when buildBidsPayload is called', () => {
    const testBid1: IBid = {
      bidAlternateId: 123,
      bidName: 'Test Bid 1',
      discountIndicator: 'Y',
    } as IBid;
    const testBid2: IBid = {
      bidAlternateId: 456,
      bidName: 'Test Bid 2',
    } as IBid;
    const bidsPayload = component.buildBidsPayload([testBid1, testBid2]);
    expect(bidsPayload.length).toBe(2);
    expect(bidsPayload[0].bidAlternateId).toBe(testBid1.bidAlternateId);
    expect(bidsPayload[0].bidAlternateName).toBe(testBid1.bidName);
    expect(bidsPayload[0].confirmationOfDiscountIndicator).toBe(testBid1.discountIndicator);
    expect(bidsPayload[1].bidAlternateId).toBe(testBid2.bidAlternateId);
    expect(bidsPayload[1].bidAlternateName).toBe(testBid2.bidName);
    expect(bidsPayload[1].confirmationOfDiscountIndicator).toBe('N/A');
  });

  it('should call saveWidgetData when saveBids is called', () => {
    const testBid1: IBid = {
      bidAlternateId: 123,
      bidName: 'Test Bid 1',
      discountIndicator: 'Y',
    } as IBid;
    const testBid2: IBid = {
      bidAlternateId: 456,
      bidName: 'Test Bid 2',
    } as IBid;
    spyOn(component, 'saveWidgetData').and.callThrough();
    const bidsData = [testBid1, testBid2];
    component.saveBids(bidsData);
    expect(component.saveWidgetData).toHaveBeenCalledWith({
      name: 'Bids',
      payloadKey: 'bids',
      payloadMethod: 'buildBidsPayload',
      data: bidsData,
    });
  });

  it('should call saveWidgetData when saveBillOfMaterials is called', () => {
    const billOfMaterialsData = [{
      bidAlternateId: 123,
      prodFamilyId: 2006347,
      selectionIds: [831049, 831048],
      coordinationJobShipQuarter: 1,
      coordinationJobShipYear: 2000,
      coordinationJobSpecifiedUser: 'abc',
      coordinationJobCompetitor: 'cbd',
      description: 'Product A',
      bidName: 'Fan',
      selectionId: 1,
    }];
    spyOn(component, 'saveWidgetData').and.callFake(() => { });
    component.saveBillOfMaterials(billOfMaterialsData);
    expect(component.saveWidgetData).toHaveBeenCalledWith({
      name: 'BillOfMaterials',
      payloadKey: 'billOfMaterials',
      payloadMethod: 'buildBillOfMaterialsPayload',
      data: billOfMaterialsData,
      callback: 'saveBomSuccessHandler',
    });
  });

  it('should build and return bill of materials payload when buildBillOfMaterialsPayload is called', () => {
    const billOfMaterialsData = [{
      bidAlternateId: 123,
      prodFamilyId: 2006347,
      selectionIds: [831049, 831048],
      coordinationJobShipQuarter: 1,
      coordinationJobShipYear: 2000,
      coordinationJobSpecifiedUser: 'abc',
      coordinationJobCompetitor: 'cbd',
      description: 'Product A',
      bidName: 'Fan',
      selectionId: 1,
      selectionSource: 'C',
      doesSeparatelyBiddableSelectionsExist: false,
    } as ISelection,
    {
      bidAlternateId: 123,
      prodFamilyId: 2006348,
      selectionIds: [831041, 831042],
      coordinationJobShipQuarter: 0,
      coordinationJobShipYear: 0,
      coordinationJobSpecifiedUser: 'abc',
      coordinationJobCompetitor: 'cbd',
      description: 'Product B',
      bidName: 'test',
      selectionId: 12,
      selectionSource: 'N',
      doesSeparatelyBiddableSelectionsExist: false,
    } as ISelection,
    ];
    const payload = [{
      bidAlternateId: 123,
      productFamilyId: 2006347,
      selectionIds: [831049, 831048],
      shipQuarter: 1,
      shipYear: 2000,
      specifiedUser: 'abc',
      competitor: 'cbd',
      description: 'Product A',
      jobId: component.jobId,
      selectionSource: 'C',
      doesSeparatelyBiddableSelectionsExist: false,
    } as IDraftSelection,
    {
      bidAlternateId: 123,
      productFamilyId: 2006348,
      selectionIds: [831041, 831042],
      shipQuarter: null,
      shipYear: null,
      specifiedUser: 'abc',
      competitor: 'cbd',
      description: 'Product B',
      jobId: component.jobId,
      selectionSource: 'N',
      doesSeparatelyBiddableSelectionsExist: false,
    } as IDraftSelection,
    ];
    const billOfMaterialsPayload = component.buildBillOfMaterialsPayload(billOfMaterialsData);
    expect(billOfMaterialsPayload.length).toBe(2);
    expect(billOfMaterialsPayload).toEqual(payload);
  });

  it('should call saveWidgetData when saveJobDetails is called', () => {
    const jobDetails = {};
    spyOn(component, 'saveWidgetData').and.callThrough();
    component.saveJobDetails(jobDetails, false);
    expect(component.saveWidgetData).toHaveBeenCalledWith({
      name: 'Job Details',
      payloadKey: 'jobGeneralInformation',
      payloadMethod: 'buildJobDetailsPayload',
      data: jobDetails,
      isForSubmit: false,
    });
  });

  it('should build and return job details payload when buildJobDetailsPayload is called', () => {
    component.jobCoordinationData = {
      jobCoordinationGeneralInfo: {
        quickTurnaroundIndicator: true,
        icsJobIndicator: true,
        requestedDate: testRequestedDate,
        jobContact: 'sree',
        commissionCode: 'sree',
      },
    };
    let jobDetails: any = {
      quickTurnaroundIndicator: false,
      icsJobIndicator: false,
      requestedDate: '01/01/2020',
      jobContact: 'basam',
      commissionCode: 'basam',
    };
    let payload = component.buildJobDetailsPayload(jobDetails);
    expect(payload['isQuickTurnaroundRequired']).toBe(jobDetails.quickTurnaroundIndicator);
    expect(payload['isIcsJob']).toBe(jobDetails.icsJobIndicator);
    expect(payload['requestedDate']).toBe(jobDetails.requestedDate);
    expect(payload['jobContact']).toBe(jobDetails.jobContact);
    expect(payload['commissionCode']).toBe(jobDetails.commissionCode);

    jobDetails = {
      quickTurnaroundIndicator: false,
      icsJobIndicator: false,
    };
    payload = component.buildJobDetailsPayload(jobDetails);
    expect(payload['isQuickTurnaroundRequired']).toBe(jobDetails.quickTurnaroundIndicator);
    expect(payload['isIcsJob']).toBe(jobDetails.icsJobIndicator);
    expect(payload['requestedDate']).toBe(undefined);
    expect(payload['jobContact']).toBe(undefined);
    expect(payload['commissionCode']).toBe(undefined);
  });

  it('should not add job contact and commission code to the payload if the values are same as existing', () => {
    component.jobCoordinationData = {
      jobCoordinationGeneralInfo: {
        quickTurnaroundIndicator: true,
        icsJobIndicator: true,
        requestedDate: testRequestedDate,
        jobContact: 'basam',
        commissionCode: 'basam',
      },
    };
    const jobDetails: any = {
      quickTurnaroundIndicator: false,
      icsJobIndicator: false,
      jobContact: 'basam',
      commissionCode: 'basam',
    };
    const payload = component.buildJobDetailsPayload(jobDetails);
    expect(payload['isQuickTurnaroundRequired']).toBe(jobDetails.quickTurnaroundIndicator);
    expect(payload['isIcsJob']).toBe(jobDetails.icsJobIndicator);
    expect(payload['requestedDate']).toBe(undefined);
    expect(payload['jobContact']).toBe(undefined);
    expect(payload['commissionCode']).toBe(undefined);
  });

  it('should add job contact and commission code to the payload if the submission is in progress', () => {
    component.isSubmissionInProgress = true;
    component.jobCoordinationData = {
      jobCoordinationGeneralInfo: {
        quickTurnaroundIndicator: true,
        icsJobIndicator: true,
        requestedDate: testRequestedDate,
        jobContact: 'basam',
        commissionCode: 'basam',
      },
    };
    const jobDetails: any = {
      quickTurnaroundIndicator: false,
      icsJobIndicator: false,
      jobContact: 'basam',
      commissionCode: 'basam',
    };
    const payload = component.buildJobDetailsPayload(jobDetails);
    expect(payload['jobContact']).toBe(jobDetails.jobContact);
    expect(payload['commissionCode']).toBe(jobDetails.commissionCode);
  });

  it('should call clearTimerForJobDetailsValidation when component is initialized', () => {
    const spyJobValidationService = spyOn(jobCoordinationValidationService, 'clearTimerForJobDetailsValidation');
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.ngOnInit();
    expect(spyJobValidationService).toHaveBeenCalled();
  });

  it('should call fetchCoordinateJobGeneralData after loading bids', fakeAsync(() => {
    const coordinateData = {
      coordinatedJobGeneralInfo: {
        assignedTo: 'Dot',
        coordinator: 'Drick',
        coordinationStatus: 'Submitted',
        submittedOn: 'Mon Oct 07 2019 21:12:07 GMT+0530',
      },
      discountConfirmationDetails: [],
    };
    const spy = spyOn(coordinateService, 'fetchCoordinateJobGeneralData').and.returnValue(of(coordinateData));
    const showLoaderSpy = spyOn(loaderService, 'show');
    const hideLoaderSpy = spyOn(loaderService, 'hide');
    const sortSpy = spyOn(component, 'sortBids').and.callFake(() => { });
    spyOn(jobCoordinationMergeService, 'buildBidData').and.callFake(() => { });
    component.getBidsData();
    expect(showLoaderSpy).toHaveBeenCalled();
    tick();
    expect(spy).toHaveBeenCalled();
    expect(hideLoaderSpy).toHaveBeenCalled();
    expect(sortSpy).toHaveBeenCalled();
  }));

  it('should not call fetchCoordinateJobGeneralData if job has never been coordinated', fakeAsync(() => {
    component.hasBeenPreviouslyCoordinated = false;
    const spyBuildBidData = spyOn(jobCoordinationMergeService, 'buildBidData').and.callFake(() => { });
    const spyFetchCoordinateJobGeneralData = spyOn(coordinateService, 'fetchCoordinateJobGeneralData');
    component.getBidsData();
    tick();
    expect(spyBuildBidData).toHaveBeenCalled();
    expect(spyFetchCoordinateJobGeneralData).not.toHaveBeenCalled();
  }));

  it('should show error toaster when fetching bids failed', fakeAsync(() => {
    const errorSpy = spyOn(component, 'showErrorMessage');
    const showLoaderSpy = spyOn(loaderService, 'show');
    const hideLoaderSpy = spyOn(loaderService, 'hide');
    coordinateService.fetchCoordinateBidData = jasmine.createSpy('spyCoordinateBidData')
      .and.returnValue(throwError('bids error'));
    component.getBidsData();
    expect(showLoaderSpy).toHaveBeenCalled();
    tick();
    expect(errorSpy).toHaveBeenCalled();
    expect(hideLoaderSpy).toHaveBeenCalled();
  }));

  it('should call scrollToSection method if selectedExceptionSubscription receives data', () => {
    const spyScrollToSection = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleSection = 'bom';
    const spyGetSelectedException = spyOn(jobCoordinationValidationService, 'getSelectedException')
      .and.returnValue(of(sampleSection));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyGetSelectedException).toHaveBeenCalled();
    expect(spyScrollToSection).toHaveBeenCalled();
    expect(spySetFocus).toHaveBeenCalled();
  });

  it('should remove widget from in progress when removeWidgetFromInProgress method is called', () => {
    const widget1 = {
      name: 'test widget 1',
      isForSubmit: false,
    };
    component.widgetsUnderAutoSave = [widget1];
    const widget2 = {
      name: 'test widget 2',
      isForSubmit: true,
    };
    component.jobCoordinationInput = nonCrmJobDetails;
    component.widgetsUnderSaveForSubmit = [widget2];
    component.removeWidgetFromInProgress(widget1);
    expect(component.widgetsUnderAutoSave).toEqual([]);
    component.removeWidgetFromInProgress(widget2);
    expect(component.widgetsUnderSaveForSubmit).toEqual([]);
  });

  it('should fetch and set ship lead time validations when validateShipLeadTime is called', fakeAsync(() => {
    const testValidationResults = [
      {
        productFamilyId: 120,
        selectionErrors: [],
        isValidShippingLeadTime: true,
      },
    ];
    const spy = spyOn(coordinateService, 'validateShipLeadTime').and.returnValue(of(testValidationResults));
    component.validateShipLeadTime();
    tick();
    expect(spy).toHaveBeenCalled();
    expect(component.shippingLeadTimeValidations).toEqual(testValidationResults);
  }));

  it('should validate coordinate request when status of selected request is Not Submitted', () => {
    const testRequest = {
      coordinationId: 123,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
    } as ICoordinateRequest;
    const spy = spyOn(component, 'validateCoordinateRequest').and.callFake(() => { });
    const coordinateSpy = spyOn(component, 'getCoordinateData').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(testRequest);
    expect(spy).toHaveBeenCalled();
    expect(coordinateSpy).toHaveBeenCalled();
  });

  it('should validate coordinate request when validateCoordinateRequest method is called', fakeAsync(() => {
    const spy = spyOn(coordinateService, 'validateCoordinateRequest').and.returnValue(of({}));
    const handleExceptionsSpy = spyOn(component, 'handleValidationExceptions').and.callFake(() => { });
    component.validateCoordinateRequest();
    tick();
    expect(spy).toHaveBeenCalled();
    expect(handleExceptionsSpy).toHaveBeenCalled();
  }));

  it('should reset validation results when status of selected request is other than Not Submitted', () => {
    const testRequest = {
      coordinationId: 123,
      coordinationStatus: 'Pending Pricing',
    } as ICoordinateRequest;
    const spy = spyOn(component, 'validateCoordinateRequest');
    const resetValidationsSpy = spyOn(component, 'resetValidationResults');
    const coordinateSpy = spyOn(component, 'getCoordinateData').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(testRequest);
    expect(spy).not.toHaveBeenCalled();
    expect(resetValidationsSpy).toHaveBeenCalled();
    expect(coordinateSpy).toHaveBeenCalled();
  });

  it('should clear shippingLeadTimeValidations when resetValidationResults is called', () => {
    component.shippingLeadTimeValidations = [{ prodFamilyId: 123, isValid: false }];
    component.resetValidationResults();
    expect(component.shippingLeadTimeValidations).toEqual([]);
  });

  it('should validate ship lead time for submission when BOM is saved', () => {
    const spy = spyOn(component, 'validateShipLeadTime').and.callFake(() => { });
    component.isSubmissionInProgress = false;
    component.saveBomSuccessHandler();
    expect(spy).toHaveBeenCalled();
  });

  it('should not validate ship lead time for submission when BOM is saved and submission is in progress', () => {
    component.isSubmissionInProgress = true;
    const spy = spyOn(component, 'validateShipLeadTime').and.callFake(() => { });
    component.saveBomSuccessHandler();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should call saveBomSuccessHandler after BOM data is successfully saved', fakeAsync(() => {
    const billOfMaterialsData = [{
      bidAlternateId: 123,
      prodFamilyId: 2006347,
      selectionIds: [831049, 831048],
      coordinationJobShipQuarter: 1,
      coordinationJobShipYear: 2000,
      coordinationJobSpecifiedUser: 'abc',
      coordinationJobCompetitor: 'cbd',
      description: 'Product A',
      bidName: 'Fan',
      selectionId: 1,
    }];
    testWidgetInfo = {
      name: 'BillOfMaterials',
      payloadKey: 'billOfMaterials',
      payloadMethod: 'buildBillOfMaterialsPayload',
      data: billOfMaterialsData,
      callback: 'saveBomSuccessHandler',
    };
    const spy = spyOn(coordinateService, 'saveCoordinateJobData').and.returnValue(of({}));
    const successSpy = spyOn(component, 'saveBomSuccessHandler').and.callFake(() => { });
    spyOn(jobService, 'getJobLockedUserDetails').and.returnValue(of(jobLockedByuser));
    spyOn(jobHeaderService, 'getUserId').and.returnValue('abcdef');
    spyOn(component, 'buildWidgetPayload').and.callThrough();
    spyOn(component, testWidgetInfo.payloadMethod).and.callThrough();
    component.saveWidgetData(testWidgetInfo);
    expect(component.buildWidgetPayload).toHaveBeenCalledWith(testWidgetInfo);
    expect(component[testWidgetInfo.payloadMethod]).toHaveBeenCalledWith(testWidgetInfo.data);
    tick();
    expect(successSpy).toHaveBeenCalled();
    expect(spy).toHaveBeenCalled();
  }));

  it('should set previously coordinated flag when getCoordinateRequest is called', fakeAsync(() => {
    const spy = spyOn(jobCoordinationValidationService, 'setHasBeenPreviouslyCoordinatedFlag');
    component.getCoordinateRequest();
    tick();
    expect(spy).toHaveBeenCalledWith(true);
  }));

  it('should set hasActiveCoordinationRequest to false if there are no active requests', fakeAsync(() => {
    component.getCoordinateRequest();
    expect(component.hasActiveCoordinationRequest).toBe(false);
  }));

  it('should set hasActiveCoordinationRequest to true if coordination status includes Pending Pricing', fakeAsync(() => {
    const sampleData = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    {
      assignedTo: ' ',
      bids: [],
      coordinationId: 21,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.pendingPricing,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37599,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    coordinateService.fetchCoordinateRequest = jasmine.createSpy('spyActiveRequest').and.returnValue(of(sampleData));
    component.getCoordinateRequest();
    expect(coordinateService.fetchCoordinateRequest).toHaveBeenCalled();
    expect(component.hasActiveCoordinationRequest).toBe(true);
  }));

  it('should set hasActiveCoordinationRequest to true if coordination status includes Escalated', fakeAsync(() => {
    const sampleData = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    {
      assignedTo: ' ',
      bids: [],
      coordinationId: 21,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.escalated,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37599,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    coordinateService.fetchCoordinateRequest = jasmine.createSpy('spyActiveRequest').and.returnValue(of(sampleData));
    component.getCoordinateRequest();
    expect(coordinateService.fetchCoordinateRequest).toHaveBeenCalled();
    expect(component.hasActiveCoordinationRequest).toBe(true);
  }));

  it('should set hasActiveCoordinationRequest to true if coordination status includes Escalation Complete', fakeAsync(() => {
    const sampleData = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    {
      assignedTo: ' ',
      bids: [],
      coordinationId: 21,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.escalationComplete,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37599,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    coordinateService.fetchCoordinateRequest = jasmine.createSpy('spyActiveRequest').and.returnValue(of(sampleData));
    component.getCoordinateRequest();
    expect(coordinateService.fetchCoordinateRequest).toHaveBeenCalled();
    expect(component.hasActiveCoordinationRequest).toBe(true);
  }));

  it('should save job details and submission notes when saveJobDataBeforeSubmit method is called', () => {
    component.isSubmissionInProgress = false;
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.widgetsUnderSaveForSubmit = [];
    const jobDetailsSpy = spyOn(component, 'saveJobDetails').and.callFake(() => { });
    const submissionNotesSpy = spyOn(component, 'saveSubmissionNotes').and.callFake(() => { });
    const showLoaderSpy = spyOn(loaderService, 'show');
    component.saveJobDataBeforeSubmit();
    expect(jobDetailsSpy).toHaveBeenCalled();
    expect(submissionNotesSpy).toHaveBeenCalled();
    expect(showLoaderSpy).toHaveBeenCalled();
    expect(component.isSubmissionInProgress).toBe(true);
    expect(component.widgetsUnderSaveForSubmit.includes(component.widgetNames.jobDetails));
    expect(component.widgetsUnderSaveForSubmit.includes(component.widgetNames.submissionNotes));
  });

  it('should submitJobForCoordination when checkAndHandleSubmission is called', () => {
    component.isSubmissionInProgress = true;
    const spy = spyOn(component, 'submitJobForCoordination').and.callFake(() => { });
    component.checkAndHandleSubmission();
    expect(spy).toHaveBeenCalled();
  });

  it('should not submitJobForCoordination when widget save is in progress', () => {
    const submissionNotes = component.widgetNames.submissionNotes;
    component.widgetsUnderSaveForSubmit = [submissionNotes];
    const spy = spyOn(component, 'submitJobForCoordination').and.callFake(() => { });
    component.checkAndHandleSubmission();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should submit job for coordination when submitJobForCoordination method is called', () => {
    const testResponse = { isJobSubmittedForCoordination: true };
    const spy = spyOn(coordinateService, 'submitJobForCoordination').and.returnValue(of(testResponse));
    const toasterSpy = spyOn(toasterService, 'setToaster');
    const handleExceptionSpy = spyOn(component, 'handleValidationExceptions').and.callFake(() => { });
    const loadRequestSpy = spyOn(component, 'getCoordinateRequest').and.callFake(() => { });
    const resetSubmissionStateSpy = spyOn(component, 'resetSubmissionState');
    component.submitJobForCoordination();
    expect(component.loadNotSubmittedRequest).toBe(true);
    expect(spy).toHaveBeenCalled();
    expect(handleExceptionSpy).not.toHaveBeenCalled();
    expect(resetSubmissionStateSpy).toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
    expect(loadRequestSpy).toHaveBeenCalled();
  });

  it('should handle exceptions when submission is failed', () => {
    const testResponse = { isJobSubmittedForCoordination: false };
    const spy = spyOn(coordinateService, 'submitJobForCoordination').and.returnValue(of(testResponse));
    const toasterSpy = spyOn(toasterService, 'setToaster');
    const handleExceptionSpy = spyOn(component, 'handleValidationExceptions').and.callFake(() => { });
    const resetSubmissionStateSpy = spyOn(component, 'resetSubmissionState');
    component.submitJobForCoordination();
    expect(spy).toHaveBeenCalled();
    expect(handleExceptionSpy).toHaveBeenCalled();
    expect(resetSubmissionStateSpy).toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
  });

  it('should show toaster when error occurs during submit', () => {
    const submitFailMessage = 'Submit failed';
    const spy = spyOn(coordinateService, 'submitJobForCoordination').and.returnValue(throwError(submitFailMessage));
    const toasterSpy = spyOn(toasterService, 'setToaster');
    const resetSubmissionStateSpy = spyOn(component, 'resetSubmissionState');
    component.submitJobForCoordination();
    expect(spy).toHaveBeenCalled();
    expect(resetSubmissionStateSpy).toHaveBeenCalled();
    expect(toasterSpy).toHaveBeenCalled();
  });

  it('should reset submission state when resetSubmissionState method is called', () => {
    component.isSubmissionInProgress = true;
    const spy = spyOn(coordinateService, 'setJobMarkedForSubmit');
    const hideLoaderSpy = spyOn(loaderService, 'hide');
    component.resetSubmissionState();
    expect(component.isSubmissionInProgress).toBe(false);
    expect(spy).toHaveBeenCalledWith(false);
    expect(hideLoaderSpy).toHaveBeenCalled();
  });

  it('should call handleJobLockException when validating, if job is not locked by current user', () => {
    const spy = spyOn(component, 'handleJobLockException');
    const exceptions = {
      jobCoordinationViewModel: {
        isJobLockedByLoggedInUser: false,
      },
    };
    component.handleValidationExceptions(exceptions);
    expect(spy).toHaveBeenCalled();
  });

  it('should update readonly and job lock status when handleJobLockException method is called', () => {
    component.isReadOnly = false;
    component.isJobLockedToCurrentUser = true;
    const spy = spyOn(jobCoordinationValidationService, 'setJobLockedByMeFlag');
    component.handleJobLockException();
    expect(spy).toHaveBeenCalledWith(false);
    expect(component.isReadOnly).toBe(true);
    expect(component.isJobLockedToCurrentUser).toBe(false);
  });

  it('should update active request status when validating, if there is an active job', () => {
    const spy = spyOn(jobCoordinationValidationService, 'setActiveRequestFlag');
    const exceptions = {
      jobCoordinationViewModel: {
        hasNoActiveCoordination: false,
      },
    };
    component.handleValidationExceptions(exceptions);
    expect(spy).toHaveBeenCalledWith(true);
  });

  it('should update isJobReleasedFromCojo when validating, if the job is in use in COJO', () => {
    const spy = spyOn(jobCoordinationValidationService, 'setJobReleasedFromCojo');
    const exceptions = {
      jobCoordinationViewModel: {
        hasNoActiveCoordination: false,
      },
      hasBeenPreviouslyCoordinated: true,
    };
    component.handleValidationExceptions(exceptions);
    expect(spy).toHaveBeenCalledWith(false);
  });

  it('should call validateJobDetailsForCoordination if the exceptions has earthwise', () => {
    const spy = spyOn(jobCoordinationValidationService, 'validateJobDetailsForCoordination');
    const exceptions = {
      jobCoordinationViewModel: {
        hasAnyEarthwiseSystems: false,
        hasAllDefinedClassifications: true,
      },
    };
    component.handleValidationExceptions(exceptions);
    expect(spy).toHaveBeenCalled();
  });

  it('should call validateJobDetailsForCoordination if the exceptions has classifications', () => {
    const spy = spyOn(jobCoordinationValidationService, 'validateJobDetailsForCoordination');
    const exceptions = {
      jobCoordinationViewModel: {
        hasAnyEarthwiseSystems: true,
        hasAllDefinedClassifications: false,
      },
    };
    component.handleValidationExceptions(exceptions);
    expect(spy).toHaveBeenCalled();
  });

  it('should not call submitJobForCoordination if submission is not in progress', () => {
    component.isSubmissionInProgress = false;
    const spy = spyOn(component, 'submitJobForCoordination').and.callFake(() => { });
    component.checkAndHandleSubmission();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should subscribe to submission changes on init', () => {
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.ngOnInit();
    expect(component.submissionSubscription).toBeDefined();
  });

  it('should unsubscribe from submission subscription on destroy', () => {
    const spy = spyOn(component.submissionSubscription, 'unsubscribe').and.callThrough();
    component.ngOnDestroy();
    expect(spy).toHaveBeenCalled();
    expect(component.submissionSubscription.closed).toBe(true);
  });

  it('should call saveJobDataBeforeSubmit when a new value is received in submission subscription', fakeAsync(() => {
    const spy = spyOn(component, 'saveJobDataBeforeSubmit').and.callFake(() => { });
    coordinateService.setJobMarkedForSubmit(true);
    tick();
    expect(spy).toHaveBeenCalled();
  }));

  it('should set exceptionSection to coordinate-form when selectedExceptionSubscription receives requestedDate exception', () => {
    const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'requestedDateNotValid';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScroll).toHaveBeenCalledWith(pageWidgets.coordinateForm);
    expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.coordinateForm, errorClass.submissionException);
  });

  it('should set exceptionSection to coordinate-form when selectedExceptionSubscription receives jobContact exception', () => {
    const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'jobContactNotValid';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScroll).toHaveBeenCalledWith(pageWidgets.coordinateForm);
    expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.coordinateForm, errorClass.invalidJobContactException);
  });

  it(`should set exceptionSection to coordinate-form when selectedExceptionSubscription receives salesPerson exception
  for non CRM jobs`, () => {
    const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'salesPersonNotValid';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScroll).toHaveBeenCalledWith(pageWidgets.coordinateForm);
    expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.coordinateForm, errorClass.invalidSalesPersonException);
  });

  it('should set exceptionSection to coordinate-bids when selectedExceptionSubscription receives bidsNotSelected exception', () => {
    const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'bidsNotSelected';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScroll).toHaveBeenCalledWith(pageWidgets.coordinateBids);
    expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.coordinateBids, errorClass.submissionException);
  });

  it('should set exceptionSection to submission-notes when selectedExceptionSubscription receives submissionNotesNotValid exception',
    () => {
      const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
      const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
      const sampleData = 'submissionNotesNotValid';
      spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
      component.jobCoordinationInput = nonCrmJobDetails;
      component.subscribeToSelectedException();
      expect(spyScroll).toHaveBeenCalledWith(pageWidgets.submissionNotes);
      expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.submissionNotes, errorClass.submissionException);
    });

  it('should set exceptionSection to bom when selectedExceptionSubscription receives bomDateNotSet exception', () => {
    const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'bomDateNotSet';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScroll).toHaveBeenCalledWith(pageWidgets.bom);
    expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.bom, errorClass.dateNotSet);
  });

  it('should set exceptionSection to bom when selectedExceptionSubscription receives bomDateNotValid exception', () => {
    const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'bomDateNotValid';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScroll).toHaveBeenCalledWith(pageWidgets.bom);
    expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.bom, errorClass.invalidSelection);
  });

  it('should set exceptionSection to bom when selectedExceptionSubscription receives shipLeadTimeNotValid exception', () => {
    const spyScroll = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'shipLeadTimeNotValid';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScroll).toHaveBeenCalledWith(pageWidgets.bom);
    expect(spySetFocus).toHaveBeenCalledWith(pageWidgets.bom, errorClass.invalidShipLeadTime);
  });

  it('should not call scrollToSection method if selectedExceptionSubscription does not receive data', () => {
    const spyScrollToSection = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleSection = null;
    const spyGetSelectedException = spyOn(jobCoordinationValidationService, 'getSelectedException')
      .and.returnValue(of(sampleSection));
    component.jobCoordinationInput = nonCrmJobDetails;
    component.subscribeToSelectedException();
    expect(spyGetSelectedException).toHaveBeenCalled();
    expect(spyScrollToSection).not.toHaveBeenCalled();
    expect(spySetFocus).not.toHaveBeenCalled();
  });

  it(`should not call scrollToSection and setFocusOnException on receiving salesPerson exception for CRM jobs`, () => {
    const spyScrollToSection = spyOn(component, 'scrollToSection').and.callFake(() => { });
    const spySetFocus = spyOn(component, 'setFocusOnException').and.callFake(() => { });
    const sampleData = 'salesPersonNotValid';
    spyOn(jobCoordinationValidationService, 'getSelectedException').and.returnValue(of(sampleData));
    component.jobCoordinationInput = crmJobDetails;
    component.subscribeToSelectedException();
    expect(spyScrollToSection).not.toHaveBeenCalled();
    expect(spySetFocus).not.toHaveBeenCalled();
  });

  it('should scroll to section when scrollToSection method is called', () => {
    const sampleSection = 'bom';
    const dummyElement: HTMLElement = document.createElement('div');
    spyOn(document, 'getElementById').and.returnValue(dummyElement);
    const spyScroll = spyOn(dummyElement, 'scrollIntoView').and.callThrough();
    component.scrollToSection(sampleSection);
    expect(spyScroll).toHaveBeenCalled();
  });

  it('should set focus on first exception on scroll when setFocusOnException method is called', () => {
    const sampleSection = pageWidgets.submissionNotes;
    const sampleErrorClass = errorClass.submissionException;
    const dummyParentElement = document.createElement('div');
    const dummyElement: HTMLElement = document.createElement('textarea');
    spyOn(document, 'getElementById').and.returnValue(dummyParentElement);
    spyOn(dummyParentElement, 'getElementsByClassName').and.returnValue([dummyElement]);
    const spyFocus = spyOn(dummyElement, 'focus').and.callThrough();
    component.setFocusOnException(sampleSection, sampleErrorClass);
    expect(spyFocus).toHaveBeenCalled();
  });

  it('should set disableAddDocumentsLink to true if coordination status is Not Submitted', () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = false;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(true);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it('should set disableAddDocumentsLink to true if coordination status is Pricing Complete', () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = false;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.pricingComplete,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(true);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it('should set disableAddDocumentsLink to true if coordination status is SPA Issued/Discount Active', () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = false;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.spaIssuedDiscountActive,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(true);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it('should set disableAddDocumentsLink to true if coordination status is Recoordinated', () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = false;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.recoordinated,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(true);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it(`should set disableAddDocumentsLink to true if coordination status is Released w/o Discount`, () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = true;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.releasedWithoutDiscount,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(true);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it('should set disableAddDocumentsLink to false if coordination status is Submitted', () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = true;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.submitted,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(false);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it(`should set disableAddDocumentsLink to false if coordination status is Pending Pricing`, () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = true;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.pendingPricing,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(false);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it(`should set disableAddDocumentsLink to false if coordination status is Escalated`, () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = true;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.escalated,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(false);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it(`should set disableAddDocumentsLink to false if coordination status is Escalation Complete`, () => {
    const spyGetCoordinateData = spyOn(component, 'getCoordinateData');
    component.disableAddDocumentsLink = true;
    component.isJobLockedToCurrentUser = true;
    const sampleRequest = [{
      assignedTo: ' ',
      bids: [],
      coordinationId: 20,
      coordinationJobData: null,
      coordinationStatus: coordinationStatusOptions.escalationComplete,
      coordinator: ' ',
      drAddressId: 101,
      jobId: 37499,
      pricingSPANumber: null,
      submittedOn: null,
    },
    ];
    component.handleCoordinateRequestSelectionChange(sampleRequest[0]);
    expect(component.disableAddDocumentsLink).toBe(false);
    expect(spyGetCoordinateData).toHaveBeenCalled();
  });

  it(`should set disableAddDocumentsLink to true if job is not locked to current user`, () => {
    component.isJobLockedToCurrentUser = false;
    component.disableAddDocumentsLink = false;
    component.coordinationStatus = coordinationStatusOptions.submitted;
    component.updateAddDocumentsLinkState();
    expect(component.disableAddDocumentsLink).toBe(true);
  });

  it(`should set disableAddDocumentsLink to true if status is Error In Submission`, () => {
    component.isJobLockedToCurrentUser = true;
    component.disableAddDocumentsLink = false;
    component.coordinationStatus = coordinationStatusOptions.errorInSubmission;
    component.updateAddDocumentsLinkState();
    expect(component.disableAddDocumentsLink).toBe(true);
  });

  it('should call exitJob and reset exit status, when exit is in progress and auto save is completed', () => {
    component.isExitInProgress = true;
    component.widgetsUnderAutoSave = [];
    const spy = spyOn(component, 'exitJob').and.callFake(() => { });
    component.checkAndHandleExit();
    expect(spy).toHaveBeenCalled();
    expect(component.isExitInProgress).toBe(false);
  });

  it('should not call exitJob, when exit is in progress and auto save is in progress', () => {
    component.isExitInProgress = true;
    component.widgetsUnderAutoSave = ['Submission Notes'];
    const spy = spyOn(component, 'exitJob').and.callFake(() => { });
    component.checkAndHandleExit();
    expect(spy).not.toHaveBeenCalled();
    expect(component.isExitInProgress).toBe(true);
  });

  it('should not call exitJob, when exit is not in progress and auto save is completed', () => {
    component.isExitInProgress = false;
    component.widgetsUnderAutoSave = [];
    const spy = spyOn(component, 'exitJob').and.callFake(() => { });
    component.checkAndHandleExit();
    expect(spy).not.toHaveBeenCalled();
    expect(component.isExitInProgress).toBe(false);
  });

  it('should exit the job and hide the job title when exitJob is called', () => {
    const spy = spyOn(exitJobService, 'CloseAndExitJob').and.callFake(() => { });
    const titleElement: HTMLElement = { style: { display: 'block' } } as HTMLElement;
    spyOn(document, 'querySelector').and.returnValue(titleElement);
    component.exitJob();
    expect(spy).toHaveBeenCalled();
    expect(titleElement.style.display).toBe('none');

  });

  it('should mark exit in progress and call handle exit', () => {
    component.isExitInProgress = false;
    const spy = spyOn(component, 'checkAndHandleExit').and.callFake(() => { });
    const isJobExited = component.handleExitJobAttempt();
    expect(spy).toHaveBeenCalled();
    expect(isJobExited).toBe(false);
    expect(component.isExitInProgress).toBe(true);
  });

  it('should create timer to refresh coordinate requests in grid when there is an active request', () => {
    component.hasActiveCoordinationRequest = true;
    const spy = spyOn(component, 'createTimerForCoordinateRequestsRefresh').and.callFake(() => { });
    component.updateTimerForCoordinateRequestsRefresh();
    expect(spy).toHaveBeenCalled();
  });

  it('should create timer to refresh coordinate requests in grid when there is a submitted request', () => {
    component.requests = [{ coordinationStatus: coordinationStatusOptions.submitted } as ICoordinateRequest];
    const spy = spyOn(component, 'createTimerForCoordinateRequestsRefresh').and.callFake(() => { });
    component.updateTimerForCoordinateRequestsRefresh();
    expect(spy).toHaveBeenCalled();
  });

  it('should clear timer to refresh coordinate requests in grid when there are no active or submitted requests', () => {
    component.hasActiveCoordinationRequest = false;
    component.requests = [{ coordinationStatus: coordinationStatusOptions.notSubmitted } as ICoordinateRequest];
    const spy = spyOn(component, 'clearTimerForCoordinateRequestsRefresh').and.callFake(() => { });
    component.updateTimerForCoordinateRequestsRefresh();
    expect(spy).toHaveBeenCalled();
  });

  it('should call createTimerForCoordinateRequestsRefresh when getCoordinateRequest is called', fakeAsync(() => {
    const spy = spyOn(component, 'createTimerForCoordinateRequestsRefresh').and.callFake(() => { });
    component.getCoordinateRequest();
    tick();
    expect(spy).toHaveBeenCalled();
  }));

  it('should call clearTimerForCoordinateRequestsRefresh on destroy', () => {
    const spy = spyOn(component, 'clearTimerForCoordinateRequestsRefresh').and.callFake(() => { });
    component.ngOnDestroy();
    expect(spy).toHaveBeenCalled();
  });

  it('should create timer when createTimerForCoordinateRequestsRefresh is called', () => {
    component.coordinateRequestsRefreshTimer = null;
    component.createTimerForCoordinateRequestsRefresh();
    expect(component.coordinateRequestsRefreshTimer).toBeDefined();
    component.clearTimerForCoordinateRequestsRefresh();
  });

  it('should not create timer if timer already exists, when createTimerForCoordinateRequestsRefresh is called', () => {
    component.createTimerForCoordinateRequestsRefresh();
    const timerSubscription = component.coordinateRequestsRefreshTimer;
    component.createTimerForCoordinateRequestsRefresh();
    expect(component.coordinateRequestsRefreshTimer).toBe(timerSubscription);
    component.clearTimerForCoordinateRequestsRefresh();
  });

  it('should clear the timer when clearTimerForCoordinateRequestsRefresh is called', () => {
    component.createTimerForCoordinateRequestsRefresh();
    expect(component.coordinateRequestsRefreshTimer).toBeDefined();
    const timerSubscription = component.coordinateRequestsRefreshTimer;
    component.clearTimerForCoordinateRequestsRefresh();
    expect(timerSubscription.closed).toBe(true);
    expect(component.coordinateRequestsRefreshTimer).toBe(null);
  });

  it('should call checkAndLoadNotSubmittedRequest when getCoordinateRequest is called', fakeAsync(() => {
    const loadRequestSpy = spyOn(component, 'checkAndLoadNotSubmittedRequest').and.callFake(() => { });
    component.getCoordinateRequest();
    tick();
    expect(loadRequestSpy).toHaveBeenCalled();
  }));

  it('should not fetch requests when submission is in progress', fakeAsync(() => {
    component.isSubmissionInProgress = true;
    coordinateService.fetchCoordinateRequest = jasmine.createSpy('spyFetchRequest').and.returnValue(of({}));
    component.getCoordinateRequest();
    tick();
    expect(coordinateService.fetchCoordinateRequest).not.toHaveBeenCalled();
  }));

  it('should call updatePricingSPANumber when getCoordinateRequest is called', fakeAsync(() => {
    const spaNumberSpy = spyOn(component, 'updatePricingSPANumber').and.callFake(() => { });
    component.getCoordinateRequest();
    tick();
    expect(spaNumberSpy).toHaveBeenCalled();
  }));

  it('should call handleErrorInSubmission when getCoordinateRequest is called', fakeAsync(() => {
    const errorSpy = spyOn(component, 'handleErrorInSubmission').and.callFake(() => { });
    component.getCoordinateRequest();
    tick();
    expect(errorSpy).toHaveBeenCalled();
  }));

  it('should call loadRequestIntoView when loadNotSubmittedRequest is true', () => {
    component.coordinateStatusComponent = { loadRequestIntoView: (request) => { } } as CoordinateStatusComponent;
    const spy = spyOn(component.coordinateStatusComponent, 'loadRequestIntoView').and.callFake(() => { });
    component.loadNotSubmittedRequest = true;
    const notSubmittedRequest = { coordinationId: 2, coordinationStatus: coordinationStatusOptions.notSubmitted } as ICoordinateRequest;
    component.requests = [notSubmittedRequest];
    component.checkAndLoadNotSubmittedRequest();
    expect(spy).toHaveBeenCalledWith(notSubmittedRequest);
    expect(component.loadNotSubmittedRequest).toBe(false);
  });

  it('should not call loadRequestIntoView when loadNotSubmittedRequest is false', () => {
    component.coordinateStatusComponent = { loadRequestIntoView: (request) => { } } as CoordinateStatusComponent;
    const spy = spyOn(component.coordinateStatusComponent, 'loadRequestIntoView').and.callFake(() => { });
    component.loadNotSubmittedRequest = false;
    const notSubmittedRequest = { coordinationId: 2, coordinationStatus: coordinationStatusOptions.notSubmitted } as ICoordinateRequest;
    component.requests = [notSubmittedRequest];
    component.checkAndLoadNotSubmittedRequest();
    expect(spy).not.toHaveBeenCalled();
    expect(component.loadNotSubmittedRequest).toBe(false);
  });

  it('should reset all the data load flags when resetDataLoadStatus method is called', () => {
    component.coordinateJobDataLoaded = true;
    component.coordinateBidDataLoaded = true;
    component.selectedBidsChanged = true;
    component.resetDataLoadStatus();
    expect(component.coordinateJobDataLoaded).toBe(false);
    expect(component.coordinateBidDataLoaded).toBe(false);
    expect(component.selectedBidsChanged).toBe(false);
  });

  it('should call resetDataLoadStatus when handleCoordinateRequestSelectionChange is called', () => {
    const spy = spyOn(component, 'resetDataLoadStatus');
    component.handleCoordinateRequestSelectionChange(null);
    expect(spy).toHaveBeenCalled();
  });

  it('should reset coordination id when handleCoordinateRequestSelectionChange is called with null', () => {
    component.coordinationId = 123;
    component.handleCoordinateRequestSelectionChange(null);
    expect(component.coordinationId).toBe(0);
  });

  it('should set submission notest to original notes when coordination draft notes is null', fakeAsync(() => {
    testCoordinateData.coordinationData.submissionNotes = null;
    const testCoordinateFormData = { icsJobIndicator: 'N' } as IJobCoordinationForm;
    spyOn(jobCoordinationMergeService, 'buildJobDetails').and.returnValue(testCoordinateFormData);
    spyOn(jobCoordinationMergeService, 'buildBidData').and.callFake(() => { });
    component.getCoordinateData();
    tick();
    expect(component.submissionNotes.noteLine).toBe(testCoordinateData.submissionNotes.noteLine);
    testCoordinateData.coordinationData.submissionNotes = 'test notes 3';
    component.getCoordinateData();
    tick();
    expect(component.submissionNotes.noteLine).toBe(testCoordinateData.coordinationData.submissionNotes);
  }));

  it('should hide loader after view is initialized', () => {
    const spy = spyOn(loaderService, 'hide');
    component.ngAfterViewInit();
    expect(spy).toHaveBeenCalled();
  });

  it('should show and hide loader when getCoordinateData is called', fakeAsync(() => {
    spyOn(jobCoordinationMergeService, 'buildBidData').and.callFake(() => { });
    const showSpy = spyOn(loaderService, 'show');
    const hideSpy = spyOn(loaderService, 'hide');
    component.getCoordinateData();
    expect(showSpy).toHaveBeenCalled();
    tick();
    expect(hideSpy).toHaveBeenCalled();
    showSpy.calls.reset();
    hideSpy.calls.reset();
    coordinateService.fetchCoordinateJobData = jasmine.createSpy('coordinateSpy').and.returnValue(throwError('error'));
    const errorSpy = spyOn(component, 'showErrorMessage');
    component.getCoordinateData();
    expect(showSpy).toHaveBeenCalled();
    tick();
    expect(hideSpy).toHaveBeenCalled();
    expect(errorSpy).toHaveBeenCalled();
  }));

  it('should set readonly flag to false if job locked to current user and status is not submitted', () => {
    component.isJobLockedToCurrentUser = true;
    const testRequest = {
      coordinationId: 123,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
    } as ICoordinateRequest;
    spyOn(component, 'validateCoordinateRequest').and.callFake(() => { });
    spyOn(component, 'getCoordinateData').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(testRequest);
    expect(component.isReadOnly).toBe(false);
  });

  it('should set readonly flag to true if job locked to current user and status is other than not submitted', () => {
    component.isJobLockedToCurrentUser = true;
    const testRequest = {
      coordinationId: 123,
      coordinationStatus: coordinationStatusOptions.submitted,
    } as ICoordinateRequest;
    spyOn(component, 'getCoordinateData').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(testRequest);
    expect(component.isReadOnly).toBe(true);
  });

  it('should set readonly flag to true if job is not locked to current user', () => {
    component.isJobLockedToCurrentUser = false;
    const testRequest = {
      coordinationId: 123,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
    } as ICoordinateRequest;
    spyOn(component, 'validateCoordinateRequest').and.callFake(() => { });
    spyOn(component, 'getCoordinateData').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(testRequest);
    expect(component.isReadOnly).toBe(true);
  });

  it('should update read only state on lock change', () => {
    component.isJobLockedToCurrentUser = false;
    component.isStatusNotSubmitted = true;
    component.isReadOnly = true;
    const spyGetLockInfo = spyOn(jobLockService, 'getLockInfo').and.returnValue(of({ readOnly: false }));
    const documentSpy = spyOn(component, 'updateAddDocumentsLinkState');
    component.jobDetailsComponent = { buildDataForSaving: () => { } } as CoordinateFormComponent;
    component.submissionNotesComponent = { getNotesWithDate: () => { } } as SubmissionNotesComponent;
    component.ngOnInit();
    expect(spyGetLockInfo).toHaveBeenCalled();
    expect(component.isJobLockedToCurrentUser).toBe(true);
    expect(component.isReadOnly).toBe(false);
    expect(documentSpy).toHaveBeenCalled();
  });

  it('should compare bids by name when compareBidsByName is called', () => {
    const bid1 = { bidName: 'Base' } as IBid;
    const bid2 = { bidName: 'Alt' } as IBid;
    const bid3 = { bidName: 'Rebid' } as IBid;
    let compare = component.compareBidsByName(bid1, bid2);
    expect(compare).toBe(1);
    compare = component.compareBidsByName(bid2, bid3);
    expect(compare).toBe(-1);
  });

  it('should return 0 if flags of both bids are false, when compareBidsByFlag is called', () => {
    const bid1 = { isSubmitted: false } as IBid;
    const bid2 = { isSubmitted: false } as IBid;
    const compare = component.compareBidsByFlag(bid1, bid2, 'isSubmitted');
    expect(compare).toBe(0);
  });

  it('should compare bids by name if flags of both bids are true, when compareBidsByFlag is called', () => {
    const bid1 = { isSubmitted: true, bidName: 'Base' } as IBid;
    const bid2 = { isSubmitted: true, bidName: 'Alt' } as IBid;
    const spy = spyOn(component, 'compareBidsByName').and.callThrough();
    const compare = component.compareBidsByFlag(bid1, bid2, 'isSubmitted');
    expect(compare).toBe(1);
    expect(spy).toHaveBeenCalled();
  });

  it('should return -1 if only flag of first bid is true, when compareBidsByFlag is called', () => {
    const bid1 = { isSubmitted: true } as IBid;
    const bid2 = { isSubmitted: false } as IBid;
    const compare = component.compareBidsByFlag(bid1, bid2, 'isSubmitted');
    expect(compare).toBe(-1);
  });

  it('should return 1 if only flag of second bid is true, when compareBidsByFlag is called', () => {
    const bid1 = { isSubmitted: false } as IBid;
    const bid2 = { isSubmitted: true } as IBid;
    const compare = component.compareBidsByFlag(bid1, bid2, 'isSubmitted');
    expect(compare).toBe(1);
  });

  it('should call compareBidsByFlag when compareBidsByFlags is called', () => {
    const bid1 = { isSubmitted: true, isCurrentBid: false } as IBid;
    const bid2 = { isSubmitted: false, isCurrentBid: true } as IBid;
    const flags = ['isSubmitted', 'isCurrentBid'];
    const spy = spyOn(component, 'compareBidsByFlag').and.callThrough();
    const compare = component.compareBidsByFlags(bid1, bid2, flags);
    expect(compare).toBe(-1);
    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should sort bids when sortBidsByFlags is called', () => {
    const bid1 = { isSubmitted: false } as IBid;
    const bid2 = { isSubmitted: true } as IBid;
    component.bidData = [bid1, bid2];
    const flags = ['isSubmitted'];
    const spy = spyOn(component, 'compareBidsByFlags').and.callThrough();
    const nameSpy = spyOn(component, 'compareBidsByName').and.callThrough();
    component.sortBidsByFlags(flags);
    expect(component.bidData).toEqual([bid2, bid1]);
    expect(spy).toHaveBeenCalled();
    expect(nameSpy).not.toHaveBeenCalled();
  });

  it('should sort bids by name if flags of both bids are false when sortBidsByFlags is called', () => {
    const bid1 = { isSubmitted: false, bidName: 'Base Bid' } as IBid;
    const bid2 = { isSubmitted: false, bidName: 'Alt bid' } as IBid;
    component.bidData = [bid1, bid2];
    const flags = ['isSubmitted'];
    const spy = spyOn(component, 'compareBidsByFlags').and.callThrough();
    const nameSpy = spyOn(component, 'compareBidsByName').and.callThrough();
    component.sortBidsByFlags(flags);
    expect(component.bidData).toEqual([bid2, bid1]);
    expect(spy).toHaveBeenCalled();
    expect(nameSpy).toHaveBeenCalled();
  });

  it('should call sortBidsByFlags when sortBids is called', () => {
    component.coordinationStatus = component.coordinationStatusOptions.notSubmitted;
    const selectedFlag = 'isBidInCoordinationJob';
    const submittedFlag = 'isSubmitted';
    const currentFlag = 'isCurrentBid';
    const spy = spyOn(component, 'sortBidsByFlags').and.callFake(() => { });
    component.sortBids();
    expect(spy).toHaveBeenCalledWith([selectedFlag, submittedFlag, currentFlag]);
    spy.calls.reset();
    component.coordinationStatus = component.coordinationStatusOptions.submitted;
    component.sortBids();
    expect(spy).toHaveBeenCalledWith([submittedFlag, currentFlag]);
  });

  it('should reload the selected request if there are new errors in submission', () => {
    component.submissionErrorsCount = 0;
    const selectedRequest = {
      coordinationId: 123,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
    } as ICoordinateRequest;
    const errorInSubmissionRequest = {
      coordinationId: 456,
      coordinationStatus: coordinationStatusOptions.errorInSubmission,
    } as ICoordinateRequest;
    component.coordinationId = selectedRequest.coordinationId;
    component.requests = [selectedRequest, errorInSubmissionRequest];
    const spy = spyOn(component, 'handleCoordinateRequestSelectionChange').and.callFake(() => { });
    component.handleErrorInSubmission();
    expect(spy).toHaveBeenCalledWith(selectedRequest);
    expect(component.submissionErrorsCount).toBe(1);
  });

  it('should not call handleCoordinateRequestSelectionChange if no request is selected and there are new errors in submission', () => {
    component.submissionErrorsCount = 0;
    const errorInSubmissionRequest = {
      coordinationId: 456,
      coordinationStatus: coordinationStatusOptions.errorInSubmission,
    } as ICoordinateRequest;
    component.coordinationId = 0;
    component.requests = [errorInSubmissionRequest];
    const spy = spyOn(component, 'handleCoordinateRequestSelectionChange').and.callFake(() => { });
    component.handleErrorInSubmission();
    expect(spy).not.toHaveBeenCalled();
    expect(component.submissionErrorsCount).toBe(1);
  });

  it('should not reload the selected request if there are no new errors in submission', () => {
    component.submissionErrorsCount = 1;
    const selectedRequest = {
      coordinationId: 123,
      coordinationStatus: coordinationStatusOptions.notSubmitted,
    } as ICoordinateRequest;
    const errorInSubmissionRequest = {
      coordinationId: 456,
      coordinationStatus: coordinationStatusOptions.errorInSubmission,
    } as ICoordinateRequest;
    component.coordinationId = selectedRequest.coordinationId;
    component.requests = [selectedRequest, errorInSubmissionRequest];
    const spy = spyOn(component, 'handleCoordinateRequestSelectionChange').and.callFake(() => { });
    component.handleErrorInSubmission();
    expect(spy).not.toHaveBeenCalled();
    expect(component.submissionErrorsCount).toBe(1);
  });

  it('should call updateSelectedRequest only if auto save is not in progress when checkAndHandleRquestChange is called', () => {
    component.isRequestChangeInProgress = true;
    component.widgetsUnderAutoSave = ['BOM'];
    const spy = spyOn(component, 'updateSelectedRequest').and.callFake(() => { });
    component.checkAndHandleRquestChange();
    expect(spy).not.toHaveBeenCalled();
    expect(component.isRequestChangeInProgress).toBe(true);
    component.widgetsUnderAutoSave = [];
    component.checkAndHandleRquestChange();
    expect(spy).toHaveBeenCalled();
    expect(component.isRequestChangeInProgress).toBe(false);
  });

  it('should set isRequestChangeInProgress to true if auto save is in progress', () => {
    const request = { coordinationId: 325 } as ICoordinateRequest;
    component.isRequestChangeInProgress = false;
    component.widgetsUnderAutoSave = ['Notes'];
    component.handleCoordinateRequestSelectionChange(request);
    expect(component.isRequestChangeInProgress).toBe(true);
    expect(component.newSelectedCoordinateRequest).toEqual(request);
  });

  it('should call updateSelectedRequest only when auto save is not in progress on call of handleCoordinateRequestSelectionChange', () => {
    const request = { coordinationId: 325 } as ICoordinateRequest;
    component.isRequestChangeInProgress = false;
    component.widgetsUnderAutoSave = [];
    const spy = spyOn(component, 'updateSelectedRequest').and.callFake(() => { });
    component.handleCoordinateRequestSelectionChange(request);
    expect(component.isRequestChangeInProgress).toBe(false);
    expect(spy).toHaveBeenCalledWith(request);
  });

  it('should set coordinatedJobGeneralInfo when updateSelectedRequest method is called', () => {
    const request = {
      coordinationId: 325,
      assignedTo: 'Sreeram',
      coordinator: 'ccefaa',
      submittedOn: '2020-05-08T11:08:31',
      coordinationStatus: coordinationStatusOptions.errorInSubmission,
      pricingSPANumber: 964,
    } as ICoordinateRequest;
    component.coordinatedJobGeneralInfo = null;
    spyOn(component, 'getCoordinateData').and.callFake(() => { });
    component.updateSelectedRequest(request);
    expect(component.coordinatedJobGeneralInfo.assignedTo).toEqual(request.assignedTo);
    expect(component.coordinatedJobGeneralInfo.coordinator).toEqual(request.coordinator);
    expect(component.coordinatedJobGeneralInfo.submittedOn).toEqual(request.submittedOn);
    expect(component.coordinatedJobGeneralInfo.coordinationStatus).toEqual(request.coordinationStatus);
    expect(component.pricingSpaNumber).toBe(request.pricingSPANumber);
  });

  it('should set hasBeenPreviouslyCoordinated flag when handlePreviouslyCoordinated method is called', () => {
    spyOn(component, 'createTimerForCoordinateRequestsRefresh').and.callFake(() => { });
    const notSubmittedRequest = {
      coordinationStatus: coordinationStatusOptions.notSubmitted,
    } as ICoordinateRequest;
    const errorInSubmissionRequest = {
      coordinationStatus: coordinationStatusOptions.errorInSubmission,
    } as ICoordinateRequest;
    const submittedRequest = {
      coordinationStatus: coordinationStatusOptions.submitted,
    } as ICoordinateRequest;
    component.requests = [notSubmittedRequest];
    component.handlePreviouslyCoordinated();
    expect(component.hasBeenPreviouslyCoordinated).toBe(false);
    component.requests = [errorInSubmissionRequest];
    component.handlePreviouslyCoordinated();
    expect(component.hasBeenPreviouslyCoordinated).toBe(false);
    component.requests = [notSubmittedRequest, submittedRequest];
    component.handlePreviouslyCoordinated();
    expect(component.hasBeenPreviouslyCoordinated).toBe(true);
  });

  it('should update the pricingSPANumber when updatePricingSPANumber is called', () => {
    const request1: ICoordinateRequest = {
      coordinationStatus: coordinationStatusOptions.notSubmitted,
      pricingSPANumber: 123,
    } as ICoordinateRequest;
    const request2: ICoordinateRequest = {
      coordinationStatus: coordinationStatusOptions.submitted,
      pricingSPANumber: 123,
    } as ICoordinateRequest;
    const request3: ICoordinateRequest = {
      coordinationStatus: coordinationStatusOptions.errorInSubmission,
      pricingSPANumber: 123,
    } as ICoordinateRequest;
    component.requests = [request1, request2, request3];
    component.updatePricingSPANumber();
    expect(request1.pricingSPANumber).toBe(null);
    expect(request2.pricingSPANumber).toBe(123);
    expect(request3.pricingSPANumber).toBe(null);
  });

  it('should call handleCoordinateRequestSelectionChange when details panel is expanded', () => {
    const panels = [{ expanded: true }];
    const spy = spyOn(component, 'handleCoordinateRequestSelectionChange').and.callFake(() => { });
    component.handleDetailsPanelExpand(panels);
    expect(spy).toHaveBeenCalled();
  });

});
