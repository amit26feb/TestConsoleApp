import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { timer, Subscription } from 'rxjs';
import { AppConstants } from '../../../../app/shared/constants/constants';
import { ToasterService } from '../../../../app/shared/services/toaster.service';
import { ICoordinateRequest, IJobCoordinationForm, ISubmissionNotes } from '../models/coordinate-job.model';
import { CoordinateService } from '../services/coordinate.service';
import { JobLockService } from '@tsmt/shared-core-salesweb';
import { CoordinateFormComponent } from './../../../shared/components/coordinate-form/coordinate-form.component';
import { CoordinateStatusComponent } from './../../../shared/components/coordinate-status-grid/coordinate-status.component';
import { SubmissionNotesComponent } from './../../../shared/components/submission-notes/submission-notes.component';
import { JobCoordinationMergeService } from './../../../shared/services/job-coordination-merge.service';
import { JobCoordinationValidationService } from './../../../shared/services/job-coordination-validation.service';
import { JobHeaderService } from './../../../shared/services/job-header.service';
import { LoaderService } from './../../../shared/services/loader.service';
import { IJobNotesModel } from './../modal/job-details-edit.model';
import { IBid, ICoordinatedJobGeneralInfo, IDraftSelection, ISelection } from './../models/coordinate-job.model';
import { ExitJobService } from './../services/exit-job.service';
import { JobsServicesService } from './../services/jobs-services.service';

@Component({
    selector: 'app-job-coordinate',
    templateUrl: './coordinate.component.html',
    styleUrls: ['./coordinate.component.scss'],
})
export class CoordinateComponent implements OnInit, AfterViewInit, OnDestroy {
    coordinationStatus: string;
    jobId: number;
    drAddressId: number;
    coordinationId: number;
    jobCoordinationData: any;
    jobNotes: IJobNotesModel;
    bidData: IBid[];
    coordinateJobDataLoaded: boolean;
    coordinateBidDataLoaded: boolean;
    disableJobNotes: true;
    jobLockUserId: string;
    isReadOnly: boolean;
    isJobLockedToCurrentUser = false;
    jobCoordinationInput: IJobCoordinationForm;
    submissionNotes: ISubmissionNotes;
    originalSubmissionNotes: any;
    hasBeenPreviouslyCoordinated: boolean;
    hasActiveCoordinationRequest: boolean;
    isStatusNotSubmitted: boolean;
    documents: any[];
    selectedBidsForCoordination: IBid[];
    selectedBidIds: number[];
    selectedBidsChanged = false;
    shippingLeadTimeValidations: any[] = [];
    pricingSpaNumber: number;
    coordinatedJobGeneralInfo: ICoordinatedJobGeneralInfo;
    coordinationStatusOptions = {
        notSubmitted: 'Not Submitted',
        pendingPricing: 'Pending Pricing',
        escalated: 'Escalated',
        escalationComplete: 'Escalation Complete',
        pricingComplete: 'Pricing Complete',
        spaIssuedDiscountActive: 'SPA Issued/Discount Active',
        releasedWithoutDiscount: 'Released w/o Discount',
        submitted: 'Submitted',
        recoordinated: 'Recoordinated',
        errorInSubmission: 'Error in Submission',
    };
    widgetNames = {
        jobDetails: 'Job Details',
        submissionNotes: 'Submission Notes',
    };
    public requests: ICoordinateRequest[];
    public isRequestsFetchInProgress = false;
    public lockedMessage = 'Data cannot be saved as the job is currently locked to ';
    coordinateRequestLoaded: boolean;
    shouldExpandCoordinateDetails: boolean;
    isSubmissionInProgress = false;
    isRequestChangeInProgress = false;
    newSelectedCoordinateRequest: ICoordinateRequest;
    selectedRequest: ICoordinateRequest;
    widgetsUnderSaveForSubmit = [];
    widgetsUnderAutoSave = [];
    submissionSubscription: Subscription;
    @ViewChild(CoordinateFormComponent)
    jobDetailsComponent: CoordinateFormComponent;
    @ViewChild(SubmissionNotesComponent)
    submissionNotesComponent: SubmissionNotesComponent;
    @ViewChild(CoordinateStatusComponent)
    coordinateStatusComponent: CoordinateStatusComponent;
    selectedExceptionSubscription: Subscription;
    disableAddDocumentsLink: boolean;
    submissionErrorsCount = 0;
    pageWidgets = {
        submissionNotes: 'submission-notes',
        coordinateForm: 'coordinate-form',
        coordinateData: 'coordinate-data',
        coordinateBids: 'coordinate-bids',
        bom: 'bom',
    };
    isExitInProgress = false;
    coordinateRequestsRefreshTimer: Subscription;
    loadNotSubmittedRequest = false;
    constructor(private jobHeaderService: JobHeaderService, private route: ActivatedRoute, private coordinateService: CoordinateService,
                private jobLockService: JobLockService, private toasterService: ToasterService,
                private jobService: JobsServicesService, public appConstants: AppConstants,
                private jobCoordinationMergeService: JobCoordinationMergeService,
                private jobCoordinationValidationService: JobCoordinationValidationService,
                private exitJobService: ExitJobService, public loaderService: LoaderService) { }

    ngOnInit() {
        this.jobId = +this.route.snapshot.params['jobId'];
        this.drAddressId = +this.route.snapshot.params['drAddressId'];
        this.jobCoordinationMergeService.setJobId(this.jobId);
        this.jobCoordinationMergeService.setDrAddressId(this.drAddressId);
        this.jobHeaderService.setJob(this.jobId, this.drAddressId);
        // get locked user info to set read only state
        this.jobLockService.getLockInfo().subscribe((lockInfo) => {
            this.jobLockUserId = lockInfo.jobLockUserId;
            this.isJobLockedToCurrentUser = !lockInfo.readOnly;
            this.isReadOnly = !this.isJobLockedToCurrentUser || !this.isStatusNotSubmitted;
            this.jobCoordinationValidationService.setJobLockedByMeFlag(this.isJobLockedToCurrentUser);
            this.updateAddDocumentsLinkState();
        });
        this.jobCoordinationValidationService.clearTimerForJobDetailsValidation();
        this.getCoordinateRequest();
        this.submissionSubscription = this.coordinateService.getJobMarkedForSubmit().subscribe(() => {
            this.saveJobDataBeforeSubmit();
        });
        this.subscribeToSelectedException();
    }

    ngAfterViewInit() {
        this.loaderService.hide();
    }

    ngOnDestroy() {
        this.submissionSubscription.unsubscribe();
        this.jobCoordinationValidationService.createTimerForJobDetailsValidation();
        this.clearTimerForCoordinateRequestsRefresh();
    }

    createTimerForCoordinateRequestsRefresh(): void {
        if (!this.coordinateRequestsRefreshTimer) {
            this.coordinateRequestsRefreshTimer = timer(15000, 15000).subscribe(() => {
                this.getCoordinateRequest();
            });
        }
    }

    clearTimerForCoordinateRequestsRefresh() {
        if (this.coordinateRequestsRefreshTimer) {
            this.coordinateRequestsRefreshTimer.unsubscribe();
            this.coordinateRequestsRefreshTimer = null;
        }
    }

    // get coordinate data
    getCoordinateData() {
        this.loaderService.show();
        this.coordinateService.fetchCoordinateJobData(this.drAddressId, this.jobId, this.coordinationId).subscribe((data) => {
            this.loaderService.hide();
            this.coordinateJobDataLoaded = true;
            this.jobCoordinationData = data;
            this.jobNotes = data.jobNotes;
            this.originalSubmissionNotes = data.submissionNotes === null ? '' : data.submissionNotes.noteLine;
            let notes = data.coordinationData.submissionNotes;
            if (notes === null) {
                notes = this.originalSubmissionNotes;
            }
            this.submissionNotes = { noteLine: notes };
            this.documents = data.coordinationData.documents;
            this.jobCoordinationMergeService.setCoordinateDraftData(data.coordinationData);
            this.jobCoordinationInput = this.jobCoordinationMergeService.buildJobDetails(data.jobCoordinationGeneralInfo);
            this.getBidsData();
        },
            (err) => {
                this.loaderService.hide();
                this.showErrorMessage('Unable to load request. Please try later');
            });
    }

    getBidsData() {
        this.loaderService.show();
        this.coordinateService.fetchCoordinateBidData(this.drAddressId, this.jobId).subscribe((data) => {
            this.loaderService.hide();
            this.coordinateBidDataLoaded = true;
            this.bidData = data.bidDataForCoordination;
            this.jobCoordinationMergeService.buildBidData(this.bidData);
            this.sortBids();
            this.selectedBidsForCoordination = this.bidData.filter((bid) => bid.isBidInCoordinationJob);
            this.selectedBidIds = this.selectedBidsForCoordination
                .map((bid) => bid.bidAlternateId);
            if (!this.hasBeenPreviouslyCoordinated) {
                this.jobCoordinationMergeService.assignBidDiscountConfirmation(this.bidData);
            } else {
                this.coordinateService.fetchCoordinateJobGeneralData(this.drAddressId, this.jobId).subscribe((result) => {
                    this.jobCoordinationMergeService.assignBidDiscountConfirmation(this.bidData, result);
                });
            }
        },
        (err) => {
            this.loaderService.hide();
            this.showErrorMessage('Unable to load Bids. Please try later');
        });
    }

    sortBids() {
        const inactiveStatuses = [this.coordinationStatusOptions.notSubmitted,
        this.coordinationStatusOptions.recoordinated,
        this.coordinationStatusOptions.errorInSubmission];
        const compareFlags = [];
        if (inactiveStatuses.includes(this.coordinationStatus)) {
            compareFlags.push('isBidInCoordinationJob');
        }
        compareFlags.push(...['isSubmitted', 'isCurrentBid']);
        this.sortBidsByFlags(compareFlags);
    }

    sortBidsByFlags(compareFlags: string[]) {
        this.bidData.sort((firstBid, secondBid) => {
            let compare = this.compareBidsByFlags(firstBid, secondBid, compareFlags);
            if (compare === 0) {
                compare = this.compareBidsByName(firstBid, secondBid);
            }
            return compare;
        });
    }

    compareBidsByFlags(firstBid: IBid, secondBid: IBid, compareFlags: string[]) {
        let compare = 0;
        compareFlags.forEach((compareFlag) => {
            // should compare with the current flag only if the previous flag could not determine sort order
            if (compare === 0) {
                compare = this.compareBidsByFlag(firstBid, secondBid, compareFlag);
            }
        });
        return compare;
    }

    compareBidsByFlag(firstBid: IBid, secondBid: IBid, compareFlag: string) {
        let compare = 0;
        if (firstBid[compareFlag] || secondBid[compareFlag]) {
            if (firstBid[compareFlag] && secondBid[compareFlag]) {
                compare = this.compareBidsByName(firstBid, secondBid);
            } else {
                compare = firstBid[compareFlag] ? -1 : 1;
            }
        }
        return compare;
    }

    compareBidsByName(firstBid: IBid, secondBid: IBid) {
        return firstBid.bidName < secondBid.bidName ? -1 : 1;
    }

    handleCoordinateRequestSelectionChange(request: ICoordinateRequest): void {
        if (this.isAutoSaveInProgress()) {
            this.isRequestChangeInProgress = true;
            this.newSelectedCoordinateRequest = request;
        } else {
            this.updateSelectedRequest(request);
        }
    }

    updateSelectedRequest(request: ICoordinateRequest): void {
        this.selectedRequest = request;
        this.resetDataLoadStatus();
        if (request === null) {
            this.jobCoordinationValidationService.setCoordinationStatusFlag(false);
            this.coordinationStatus = null;
            this.coordinationId = 0;
        } else {
            this.coordinationStatus = request.coordinationStatus;
            this.pricingSpaNumber = request.pricingSPANumber;
            this.coordinatedJobGeneralInfo = {
                submittedOn: request.submittedOn,
                coordinationStatus: request.coordinationStatus,
                coordinator: request.coordinator,
                assignedTo: request.assignedTo,
            };
            this.updateAddDocumentsLinkState();
            this.jobCoordinationMergeService.setCoordinationStatus(this.coordinationStatus);
            this.isStatusNotSubmitted = this.coordinationStatus === this.coordinationStatusOptions.notSubmitted;
            this.isReadOnly = !this.isJobLockedToCurrentUser || !this.isStatusNotSubmitted;
            this.jobCoordinationValidationService.setCoordinationStatusFlag(this.isStatusNotSubmitted);
            this.coordinationId = request.coordinationId;
            this.jobCoordinationMergeService.setCoordinationId(this.coordinationId);
            this.getCoordinateData();
            if (this.isStatusNotSubmitted) {
                this.validateCoordinateRequest();
            } else {
                this.resetValidationResults();
            }
            this.shouldExpandCoordinateDetails = true;
        }
    }
    resetDataLoadStatus(): void {
        this.coordinateJobDataLoaded = false;
        this.coordinateBidDataLoaded = false;
        this.selectedBidsChanged = false;
    }

    handleCoordinationStatusExpand() {
        this.shouldExpandCoordinateDetails = false;
        this.handleCoordinateRequestSelectionChange(null);
    }
    getCoordinateRequest(): void {
        if (this.isRequestsFetchInProgress || this.isSubmissionInProgress) {
            return;
        }
        this.isRequestsFetchInProgress = true;
        this.coordinateService.fetchCoordinateRequest(this.drAddressId, this.jobId).subscribe((data: ICoordinateRequest[]) => {
            if (data !== null) {
                this.coordinateRequestLoaded = true;
            }
            this.requests = data;
            this.updatePricingSPANumber();
            this.handlePreviouslyCoordinated();
            this.checkAndLoadNotSubmittedRequest();
            this.handleErrorInSubmission();
            this.isRequestsFetchInProgress = false;
        }, (err) => {
            this.toasterService.setToaster('error', 'Internal server error');
            this.isRequestsFetchInProgress = false;
        });
    }

    updatePricingSPANumber() {
        const unCoordinatedStatuses = [
            this.coordinationStatusOptions.notSubmitted,
            this.coordinationStatusOptions.errorInSubmission,
            this.coordinationStatusOptions.recoordinated,
        ];
        const [latestActiveRequest] = this.requests.filter((request) => {
            return !unCoordinatedStatuses.includes(request.coordinationStatus);
        });
        this.requests.forEach((request) => {
            if (request !== latestActiveRequest) {
                request.pricingSPANumber = null;
            }
        });
    }

    handleErrorInSubmission() {
        const [selectedRequest] = this.requests.filter((request) => request.coordinationId === this.coordinationId);
        const errorsInSubmissionCount = this.requests.filter((request) => {
            return request.coordinationStatus === this.coordinationStatusOptions.errorInSubmission;
        }).length;
        if (errorsInSubmissionCount > this.submissionErrorsCount) {
            if (selectedRequest) {
                this.handleCoordinateRequestSelectionChange(selectedRequest);
            }
            this.submissionErrorsCount = errorsInSubmissionCount;
        }
    }

    handlePreviouslyCoordinated() {
        const activeOptions = [this.coordinationStatusOptions.pendingPricing, this.coordinationStatusOptions.escalated,
        this.coordinationStatusOptions.escalationComplete];
        this.hasBeenPreviouslyCoordinated = this.requests.filter((request) => {
            const unCoordinatedStatuses = [this.coordinationStatusOptions.notSubmitted, this.coordinationStatusOptions.errorInSubmission];
            return !unCoordinatedStatuses.includes(request.coordinationStatus);
        }).length > 0;
        if (this.hasBeenPreviouslyCoordinated) {
            this.hasActiveCoordinationRequest = this.requests.some((request) => {
                return activeOptions.includes(request.coordinationStatus);
            });
            this.jobCoordinationValidationService.setActiveRequestFlag(this.hasActiveCoordinationRequest);
            this.createTimerForCoordinateRequestsRefresh();
        }
        this.jobCoordinationValidationService
            .setHasBeenPreviouslyCoordinatedFlag(this.hasBeenPreviouslyCoordinated);
    }

    checkAndLoadNotSubmittedRequest() {
        if (this.loadNotSubmittedRequest) {
            const [request] = this.requests.filter((req) => req.coordinationStatus === this.coordinationStatusOptions.notSubmitted);
            if (request) {
                this.coordinateStatusComponent.loadRequestIntoView(request);
                this.loadNotSubmittedRequest = false;
            }
        }
    }

    handleDetailsPanelExpand(panels) {
        if (panels[0].expanded) {
            this.handleCoordinateRequestSelectionChange(this.selectedRequest);
        }
    }

    updateTimerForCoordinateRequestsRefresh() {
        const hasSubmittedRequest = this.requests.some((request) => {
            return request.coordinationStatus === this.coordinationStatusOptions.submitted;
        });
        if (this.hasActiveCoordinationRequest || hasSubmittedRequest) {
            this.createTimerForCoordinateRequestsRefresh();
        } else {
            this.clearTimerForCoordinateRequestsRefresh();
        }
    }

    updateAddDocumentsLinkState() {
        const submitDocumentsDisablingOptions = [this.coordinationStatusOptions.notSubmitted, this.coordinationStatusOptions.recoordinated,
        this.coordinationStatusOptions.pricingComplete, this.coordinationStatusOptions.spaIssuedDiscountActive,
        this.coordinationStatusOptions.errorInSubmission, this.coordinationStatusOptions.releasedWithoutDiscount];
        this.disableAddDocumentsLink = submitDocumentsDisablingOptions.includes(this.coordinationStatus) || !this.isJobLockedToCurrentUser;
    }

    saveSubmissionNotes(notes, isForSubmit) {
        this.saveWidgetData({
            name: this.widgetNames.submissionNotes,
            payloadKey: 'submissionNotes',
            payloadMethod: 'buildSubmissionNotesPayload',
            data: notes,
            isForSubmit,
        });
    }

    saveDocuments(documentKeys) {
        this.saveWidgetData({
            name: 'Documents',
            payloadKey: 'documents',
            payloadMethod: 'buildDocumentsPayload',
            data: documentKeys,
        });
    }

    saveBids(bids) {
        this.saveWidgetData({
            name: 'Bids',
            payloadKey: 'bids',
            payloadMethod: 'buildBidsPayload',
            data: bids,
        });
    }

    saveBillOfMaterials(billOfMaterials) {
        this.saveWidgetData({
            name: 'BillOfMaterials',
            payloadKey: 'billOfMaterials',
            payloadMethod: 'buildBillOfMaterialsPayload',
            data: billOfMaterials,
            callback: 'saveBomSuccessHandler',
        });
    }

    saveBomSuccessHandler() {
        if (!this.isSubmissionInProgress && this.coordinationId) {
            this.validateShipLeadTime();
        }
    }

    saveJobDetails(jobDetails, isForSubmit) {
        this.saveWidgetData({
            name: this.widgetNames.jobDetails,
            payloadKey: 'jobGeneralInformation',
            payloadMethod: 'buildJobDetailsPayload',
            data: jobDetails,
            isForSubmit,
        });
    }

    saveWidgetData(widgetInfo) {
        this.addWidgetToAutoSaveList(widgetInfo);
        this.jobService.getJobLockedUserDetails(this.drAddressId, this.jobId).subscribe((res: any) => {
            if (res && res.userId) {
                this.jobLockUserId = res.userId;
                if (res.userId === this.jobHeaderService.getUserId() && this.coordinationId) {
                    const payload = this.buildWidgetPayload(widgetInfo);
                    this.coordinateService.saveCoordinateJobData(payload, this.drAddressId, this.jobId).subscribe((val) => {
                        this.removeWidgetFromInProgress(widgetInfo);
                        this.checkAndHandleExit();
                        this.checkAndHandleSubmission();
                        this.checkAndHandleRquestChange();
                        if (widgetInfo.callback) {
                            this[widgetInfo.callback]();
                        }
                    }, (error) => {
                        const message = widgetInfo.name + ': ' + this.appConstants.COORDINATE_JOB_SAVE_ERROR_MESSAGE;
                        this.showErrorMessage(message);
                        this.removeWidgetFromInProgress(widgetInfo);
                        this.resetSubmissionState();
                    });
                } else {
                    let message = this.lockedMessage;
                    message += res.lastName + ' ' + res.firstName + ' (' + res.userId + ')';
                    this.showErrorMessage(message);
                    this.handleJobLockException();
                    this.removeWidgetFromInProgress(widgetInfo);
                    this.resetSubmissionState();
                }
            } else {
                this.jobLockUserId = '';
                this.showErrorMessage('Data cannot be saved as the job is currently not locked ');
                this.handleJobLockException();
                this.removeWidgetFromInProgress(widgetInfo);
                this.resetSubmissionState();
            }
        }, (err) => {
            const message = widgetInfo.name + ': ' + this.appConstants.COORDINATE_JOB_SAVE_ERROR_MESSAGE;
            this.removeWidgetFromInProgress(widgetInfo);
            this.showErrorMessage(message);
            this.resetSubmissionState();
        });
    }

    addWidgetToAutoSaveList(widgetInfo) {
        if (!widgetInfo.isForSubmit) {
            this.widgetsUnderAutoSave.push(widgetInfo.name);
        }
    }

    removeWidgetFromInProgress(widgetInfo) {
        if (widgetInfo.isForSubmit) {
            const index = this.widgetsUnderSaveForSubmit.indexOf(widgetInfo.name);
            this.widgetsUnderSaveForSubmit.splice(index, 1);
        } else {
            const index = this.widgetsUnderAutoSave.indexOf(widgetInfo.name);
            this.widgetsUnderAutoSave.splice(index, 1);
        }
    }

    buildWidgetPayload(widgetInfo) {
        const payload = {
            jobCoordinationViewModel: {
                jobId: this.jobId,
                drAddressId: this.drAddressId,
                coordinationId: this.coordinationId,
                isForSubmit: widgetInfo.isForSubmit,
                coordinationStatus: this.coordinationStatus,
            },
        };
        payload.jobCoordinationViewModel[widgetInfo['payloadKey']] = this[widgetInfo.payloadMethod](widgetInfo.data);
        return payload;
    }

    buildBidsPayload(bids: IBid[]) {
        return bids.map((bid) => {
            return {
                bidAlternateId: bid.bidAlternateId,
                bidAlternateName: bid.bidName,
                confirmationOfDiscountIndicator: bid.discountIndicator || 'N/A',
            };
        });
    }

    buildBillOfMaterialsPayload(billOfMaterials: ISelection[]): IDraftSelection[] {
        return billOfMaterials.map((selection) => {
            return {
                bidAlternateId: selection.bidAlternateId,
                productFamilyId: selection.prodFamilyId,
                description: selection.description,
                shipQuarter: this.getShipTime(selection, 'coordinationJobShipQuarter'),
                shipYear: this.getShipTime(selection, 'coordinationJobShipYear'),
                competitor: selection.coordinationJobCompetitor,
                specifiedUser: selection.coordinationJobSpecifiedUser,
                selectionIds: selection.selectionIds,
                selectionSource: selection.selectionSource,
                doesSeparatelyBiddableSelectionsExist: selection.doesSeparatelyBiddableSelectionsExist,
                jobId: this.jobId,
            };
        });
    }

    getShipTime(selection: ISelection, field: string): number {
        return selection[field] > 0 ? selection[field] : null;
    }

    buildJobDetailsPayload(jobDetails) {
        const payload: any = {};
        this.mapProperty(jobDetails, payload, 'quickTurnaroundIndicator', 'isQuickTurnaroundRequired');
        this.mapProperty(jobDetails, payload, 'icsJobIndicator', 'isIcsJob');
        this.mapProperty(jobDetails, payload, 'requestedDate', 'requestedDate');
        if (jobDetails.jobContact !== this.jobCoordinationData.jobCoordinationGeneralInfo.jobContact
            || this.isSubmissionInProgress) {
            payload.jobContact = jobDetails.jobContact;
        }
        if (jobDetails.commissionCode !== this.jobCoordinationData.jobCoordinationGeneralInfo.commissionCode
            || this.isSubmissionInProgress) {
            payload.commissionCode = jobDetails.commissionCode;
        }
        return payload;
    }

    buildDocumentsPayload(documentKeys) {
        return documentKeys;
    }

    buildSubmissionNotesPayload(notes) {
        return notes;
    }

    mapProperty(source, target, sourceProp, targetProp) {
        if (source && source[sourceProp] !== undefined) {
            target[targetProp] = source[sourceProp];
        }
    }

    handleBidSelectionChange(selectedBids: IBid[]) {
        this.selectedBidsForCoordination = selectedBids;
        this.selectedBidIds = this.selectedBidsForCoordination.map((bid) => bid.bidAlternateId);
        this.selectedBidsChanged = true;
    }

    showErrorMessage(txt: string) {
        this.toasterService.setToaster('error', txt);
    }

    validateCoordinateRequest() {
        this.coordinateService.validateCoordinateRequest(this.drAddressId, this.jobId, this.coordinationId)
            .subscribe((res: any) => {
                this.handleValidationExceptions(res);
            });
    }

    validateShipLeadTime() {
        this.coordinateService.validateShipLeadTime(this.drAddressId, this.jobId, this.coordinationId)
            .subscribe((res: any) => {
                this.shippingLeadTimeValidations = res || [];
            });
    }

    resetValidationResults() {
        this.shippingLeadTimeValidations = [];
    }

    saveJobDataBeforeSubmit() {
        this.loaderService.show();
        this.isSubmissionInProgress = true;
        this.widgetsUnderSaveForSubmit.push(this.widgetNames.jobDetails);
        this.widgetsUnderSaveForSubmit.push(this.widgetNames.submissionNotes);
        this.saveJobDetails(this.jobDetailsComponent.buildDataForSaving(), true);
        this.saveSubmissionNotes(this.submissionNotesComponent.getNotesWithDate(), true);
    }

    checkAndHandleSubmission() {
        if (this.isSubmissionInProgress) {
            const autoSaveInProgess = this.widgetsUnderAutoSave.length !== 0;
            const saveForSubmitInProgress = this.widgetsUnderSaveForSubmit.length !== 0;
            const shouldSubmit = !autoSaveInProgess && !saveForSubmitInProgress;
            if (shouldSubmit) {
                this.submitJobForCoordination();
            }
        }
    }

    checkAndHandleRquestChange(): void {
        if (this.isRequestChangeInProgress && !this.isAutoSaveInProgress()) {
            this.updateSelectedRequest(this.newSelectedCoordinateRequest);
            this.isRequestChangeInProgress = false;
        }
    }

    isAutoSaveInProgress(): boolean {
        return this.widgetsUnderAutoSave.length !== 0;
    }

    submitJobForCoordination() {
        this.coordinateService.submitJobForCoordination(this.drAddressId, this.jobId, this.coordinationId)
            .subscribe((res: any) => {
                this.resetSubmissionState();
                if (!res.isJobSubmittedForCoordination) {
                    this.toasterService.setToaster('error', 'Job could not be submitted for coordination');
                    this.handleValidationExceptions(res);
                } else {
                    this.loadNotSubmittedRequest = true;
                    this.toasterService.setToaster('success',
                        'Job submission has been initiated. You will receive a notification on the status shortly.');
                    this.getCoordinateRequest();
                    this.createTimerForCoordinateRequestsRefresh();
                }
            }, (err) => {
                this.resetSubmissionState();
                this.toasterService.setToaster('error', 'Job could not be submitted for coordination');
            });
    }

    resetSubmissionState() {
        if (this.isSubmissionInProgress) {
            this.loaderService.hide();
            this.isSubmissionInProgress = false;
            this.coordinateService.setJobMarkedForSubmit(false);
        }
    }

    handleValidationExceptions(exceptions) {
        this.jobCoordinationValidationService.setJobReleasedFromCojo(!exceptions.hasBeenPreviouslyCoordinated);
        if (!exceptions.jobCoordinationViewModel.isJobLockedByLoggedInUser) {
            this.handleJobLockException();
        }
        if (!exceptions.jobCoordinationViewModel.hasNoActiveCoordination) {
            this.jobCoordinationValidationService.setActiveRequestFlag(true);
        }
        if (!exceptions.jobCoordinationViewModel.hasAnyEarthwiseSystems ||
            !exceptions.jobCoordinationViewModel.hasAllDefinedClassifications) {
            this.jobCoordinationValidationService.validateJobDetailsForCoordination();
        }
        this.shippingLeadTimeValidations = exceptions.shippingLeadTimeValidations || [];
    }

    handleJobLockException() {
        this.isJobLockedToCurrentUser = false;
        this.isReadOnly = true;
        this.jobCoordinationValidationService.setJobLockedByMeFlag(false);
    }

    subscribeToSelectedException() {
        this.selectedExceptionSubscription = this.jobCoordinationValidationService.getSelectedException().subscribe((data) => {
            if (data) {
                let exceptionSection;
                let errorClass = 'submission-exception';
                switch (data) {
                    case 'requestedDateNotValid': {
                        exceptionSection = this.pageWidgets.coordinateForm;
                        break;
                    }
                    case 'bidsNotSelected': {
                        exceptionSection = this.pageWidgets.coordinateBids;
                        break;
                    }
                    case 'submissionNotesNotValid': {
                        exceptionSection = this.pageWidgets.submissionNotes;
                        break;
                    }
                    case 'bomDateNotSet': {
                        exceptionSection = this.pageWidgets.bom;
                        errorClass = 'date-not-set';
                        break;
                    }
                    case 'bomDateNotValid': {
                        exceptionSection = this.pageWidgets.bom;
                        errorClass = 'invalid-selection';
                        break;
                    }
                    case 'shipLeadTimeNotValid': {
                        exceptionSection = this.pageWidgets.bom;
                        errorClass = 'lead-time-invalid';
                        break;
                    }
                    case 'jobContactNotValid': {
                        exceptionSection = this.pageWidgets.coordinateForm;
                        errorClass = 'job-contact-invalid';
                        break;
                    }
                    case 'salesPersonNotValid': {
                        if (this.jobCoordinationInput.crmOpportunityId) {
                            window.open(this.appConstants.TRANE_CRM_OPPY_URL + '?OPPORTUNITY_ID=' +
                              this.jobCoordinationInput.crmOpportunityId + '&PAGE=RSF_OPP_DETAIL');
                        }
                        exceptionSection = this.pageWidgets.coordinateForm;
                        errorClass = 'sales-person-invalid';
                        break;
                    }
                }
                if (!(errorClass === 'sales-person-invalid' && this.jobCoordinationInput.crmOpportunityId)) {
                    this.scrollToSection(exceptionSection);
                    this.setFocusOnException(exceptionSection, errorClass);
                }
            }
        });
    }

    scrollToSection(secId) {
        const sectionWithException: HTMLElement = document.getElementById(secId);
        sectionWithException.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
    }

    setFocusOnException(secId, errorClass) {
        const elementWithException: HTMLElement = document.getElementById(secId)
            .getElementsByClassName(errorClass)[0] as HTMLElement;
        elementWithException.focus();
    }

    handleExitJobAttempt(): boolean {
        this.isExitInProgress = true;
        this.checkAndHandleExit();
        return false;
    }

    exitJob() {
        this.exitJobService.CloseAndExitJob(this.jobId, this.drAddressId, this.jobLockUserId);
        const titleElement: HTMLElement = document.querySelector('.job-title');
        titleElement.style.display = 'none';
    }

    checkAndHandleExit() {
        if (this.isExitInProgress && this.widgetsUnderAutoSave.length === 0) {
            this.exitJob();
            this.isExitInProgress = false;
        }
    }
}
