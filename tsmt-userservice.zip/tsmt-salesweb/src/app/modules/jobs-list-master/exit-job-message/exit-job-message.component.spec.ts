import { ComponentFixture, getTestBed, TestBed, waitForAsync } from '@angular/core/testing';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { ExitJobMessageComponent } from './exit-job-message.component';

describe('ExitJobMessageComponent', () => {
  let component: ExitJobMessageComponent;
  let fixture: ComponentFixture<ExitJobMessageComponent>;
  let injector: TestBed;
  let titleService: Title;
  let route: ActivatedRoute;
  const originReset = TestBed.resetTestingModule;

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      declarations: [ExitJobMessageComponent],
      providers: [
        Title,
        {
          provide: ActivatedRoute, useValue: {
            snapshot: {
              params: { isLockedBySomeoneElse: 'true' },
            },
          },
        },
      ],
    });
    injector = getTestBed();
    fixture = TestBed.createComponent(ExitJobMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    titleService = fixture.componentRef.injector.get(Title);
    route = injector.inject(ActivatedRoute);
  }));


  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onPopState', waitForAsync(() => {
    const url = window.location.href;
    history.back();
    expect(window.location.href).toBe(url);
  }));

  it('should set tab title and locked by someone else message on ngOnInit', () => {
    const spyTitle = spyOn(titleService, 'setTitle');
    component.ngOnInit();
    expect(spyTitle).toHaveBeenCalledWith('Exit');
    expect(component.message).toBe('You may close this browser tab');
    route.snapshot.params['isLockedBySomeoneElse'] = 'false';
    component.ngOnInit();
    expect(component.message).toBe('This job has been saved. You may close this browser tab');
  });
});
