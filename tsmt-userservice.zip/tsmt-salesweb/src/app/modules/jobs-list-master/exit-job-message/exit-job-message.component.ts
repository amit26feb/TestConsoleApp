import { PlatformLocation } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-exit-job-message',
  templateUrl: './exit-job-message.component.html',
  styleUrls: ['./exit-job-message.component.scss'],
})
export class ExitJobMessageComponent implements OnInit {
  public message: string;
  constructor(private titleService: Title, private route: ActivatedRoute, location: PlatformLocation) {
    history.pushState(null, null, window.location.href);
    location.onPopState(() => {
      history.pushState(null, null, window.location.href);
    });
   }

  ngOnInit() {
    this.titleService.setTitle('Exit');
    if (this.route.snapshot.params['isLockedBySomeoneElse'] === 'true') {
      this.message = 'You may close this browser tab';
    } else {
      this.message = 'This job has been saved. You may close this browser tab';
    }
  }

}
