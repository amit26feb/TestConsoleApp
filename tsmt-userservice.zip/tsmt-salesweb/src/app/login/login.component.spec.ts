import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { OktaAuthService, OKTA_CONFIG } from '@okta/okta-angular';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { CookieService } from 'ngx-cookie-service';
import { Observable } from 'rxjs';

import oktaConfig from './../.okta.config';
import { IOfficeSelectorModel } from './../modules/jobs-list-master/modal/office-selector-model';
import { AppConstants } from './../shared/constants/constants';
import { GlobalFilterService } from './../shared/services/global-filter.service';
import { ToasterService } from './../shared/services/toaster.service';
import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let oktaAuth: OktaAuthService;
  let router: Router;
  let filterService: GlobalFilterService;
  let toaster: ToasterService;
  let appConstants: AppConstants;
  const oktaRoutingConfig = Object.assign({
    onAuthRequired: ({ oAuth, route }) => {
      // Redirect the user to your custom login page
      router.navigate(['']);
    },
  }, oktaConfig.oidc);
  const routePath = '/jobs-list';

  configureTestSuite((() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [
        LoginComponent
      ],
      providers: [
        CookieService,
        HttpClient,
        HttpHandler,
        AppConstants,
        OktaAuthService,
        ToasterService,
        GlobalFilterService,
        {
          provide: Router,
          useClass: class {
            navigate = jasmine.createSpy('navigate');
          },
        },
        {
          provide: OKTA_CONFIG,
          useValue: oktaRoutingConfig,
        },
      ],
    });

    fixture = TestBed.createComponent(LoginComponent);
    oktaAuth = TestBed.inject(OktaAuthService);
    router = TestBed.inject(Router);
    filterService = TestBed.inject(GlobalFilterService);
    toaster = TestBed.inject(ToasterService);
    appConstants = TestBed.inject(AppConstants);

    component = fixture.componentInstance;
    component.userId = 'lamsp';
    fixture.detectChanges();

    const idToken = {
      idToken: {
        idToken: 'abc', claims: {
          sub: '00uksgcdp2UpmxPd40x7',
          name: 'Swati Tadaka',
          samAccountName: 'ccfbsb',
        },
      },
    };
    localStorage.setItem('okta-token-storage', JSON.stringify(idToken));

    const accessToken = {
      accessToken: {
        accessToken: 'abc',
        tokenType: 'Bearer',
        authorizeUrl: 'https://trane.okta.com/oauth2/00uksgcdp2UpmxPd40x7/v1/authorize',
        userinfoUrl: 'https://trane.okta.com/oauth2/00uksgcdp2UpmxPd40x7/v1/userinfo',
      },
    };
    localStorage.setItem('okta-token-storage', JSON.stringify(accessToken));
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should route to job-list on successful okta authentication', waitForAsync(() => {
    const defaultSalesOffice = {
      drAddressId: 121,
    } as IOfficeSelectorModel;
    const user = {
      name: 'User',
      id: 'lamsp',
    };

    const spyAuth = spyOn(oktaAuth, 'isAuthenticated').and.returnValue(Promise.resolve(true));
    spyOn(oktaAuth, 'getUser').and.returnValue(Promise.resolve(user));
    spyOn(filterService, 'getDefaultOffice').and.returnValue(Observable.of(defaultSalesOffice));

    component.ngOnInit();

    oktaAuth.isAuthenticated().then(() => {
      expect(spyAuth).toHaveBeenCalled();
      expect(router.navigate).toHaveBeenCalledWith([routePath, 121]);
    });
  }));

  it('should throw error for login without office selectors', waitForAsync(() => {
    spyOn(oktaAuth, 'isAuthenticated').and.returnValue(Promise.resolve(true));
    spyOn(filterService, 'getDefaultOffice').and.returnValue(Observable.of(null));
    const spyError = spyOn(component, 'showErrorMessage');
    component.ngOnInit();
    oktaAuth.isAuthenticated().then(() => {
      expect(spyError).toHaveBeenCalled();
    });
  }));

  it('should call showErrorMessage when service throws error on calling ngOnInit', () => {
    spyOn(oktaAuth, 'isAuthenticated').and.returnValue(Promise.resolve(true));
    spyOn(filterService, 'getDefaultOffice').and.returnValue(Observable.throwError({ error: 'error' }));
    const spyError = spyOn(component, 'showErrorMessage');
    component.ngOnInit();
    oktaAuth.isAuthenticated().then(() => {
      expect(spyError).toHaveBeenCalled();
    });
  });

  it('should call renderEl on signIn  widget when there is okta authentication failure', () => {
    spyOn(oktaAuth, 'isAuthenticated').and.returnValue(Promise.resolve(false));
    const spySignIn = spyOn(component.signIn, 'renderEl');
    component.ngOnInit();
    oktaAuth.isAuthenticated().then(() => {
      expect(spySignIn).toHaveBeenCalled();
    });
  });

  it('should call logout on errors', waitForAsync(() => {
    spyOn(oktaAuth, 'logout');
    spyOn(toaster, 'setToaster');
    const spySignIn = spyOn(component.signIn, 'renderEl');
    component.showErrorMessage();
    expect(oktaAuth.logout).toHaveBeenCalled();
    expect(toaster.setToaster).toHaveBeenCalledWith('error', appConstants.ACCESS_DENIED);
    expect(spySignIn).toHaveBeenCalled();
  }));
});
