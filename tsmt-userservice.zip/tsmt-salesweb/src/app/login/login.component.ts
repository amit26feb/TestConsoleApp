import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppConstants } from './../shared/constants/constants';
import { GlobalFilterService } from './../shared/services/global-filter.service';

import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import { IOfficeSelectorModel } from './../modules/jobs-list-master/modal/office-selector-model';

import * as OktaSignIn from '@okta/okta-signin-widget';
import oktaConfig from '../.okta.config';
import { ToasterService } from './../shared/services/toaster.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LoginComponent implements OnInit {
  userId: string;
  signIn: OktaSignIn;

  constructor(
    private filterService: GlobalFilterService,
    private oktaAuth: OktaAuthService,
    private router: Router,
    public toasterService: ToasterService,
    private appConstants: AppConstants) {

    this.signIn = new OktaSignIn({
      logo: '../assets/images/Trane_logo.png',
      baseUrl: oktaConfig.oidc.issuer.split('/oauth2')[0],
      clientId: oktaConfig.oidc.clientId,
      redirectUri: oktaConfig.oidc.redirectUri,
      i18n: {
        en: {
          'primaryauth.title': 'IR Login',
          'primaryauth.username.placeholder': 'Email Address',
          'primaryauth.username.tooltip': 'Email',
          'error.username.required': 'Please enter email address',
        },
      },
      authParams: {
        issuer: oktaConfig.oidc.issuer,
        responseType: ['code'],
        display: 'page',
        scopes: oktaConfig.oidc.scope.split(' '),
        pkce: true,
      },
    });
  }

  ngOnInit() {
    this.oktaAuth.isAuthenticated().then((value) => {
      if (value) {
        this.filterService.getDefaultOffice().subscribe((data: IOfficeSelectorModel) => {
          if (data !== null) {
            this.router.navigate(['/jobs-list', data.drAddressId]);
          } else {
            this.showErrorMessage();
          }
        },
          (error) => {
            this.showErrorMessage();
            console.log(error);
          });
      } else {
        this.signIn.renderEl(
          { el: '#sign-in-widget' },
        );
      }
    });
  }

  showErrorMessage() {
    this.oktaAuth.logout();
    this.toasterService.setToaster('error', this.appConstants.ACCESS_DENIED);
    this.signIn.renderEl(
      { el: '#sign-in-widget' },
    );
  }
}
