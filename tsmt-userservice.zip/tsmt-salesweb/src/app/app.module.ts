// modules
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { enableProdMode, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
//  services
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { OktaAuthGuard, OktaAuthModule, OktaAuthService, OKTA_CONFIG } from '@okta/okta-angular';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { MenuModule } from '@progress/kendo-angular-menu';
import { NotificationModule } from '@progress/kendo-angular-notification';
import { PopupModule } from '@progress/kendo-angular-popup';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { UploadModule } from '@progress/kendo-angular-upload';
import { CostForecastLibraryModule } from '@tsmt/cost-forecast';
import { SaleswebBillingLibraryModule } from '@tsmt/salesweb-billingmodule';
import { TraneSalesBusinessDataService } from '@tsmt/shared-acquisition-dataservices';
import { MessageModule } from '@tsmt/shared-core';
import { RouteGuard } from '@tsmt/shared-core-salesweb';
import { SharedPriceRollupModule } from '@tsmt/shared-price-rollup';
import { CookieService } from 'ngx-cookie-service';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { environment } from './../environments/environment';
import oktaConfig from './.okta.config';
import { AppRoutingModule } from './app-routing.module';
//  components
import { AppComponent } from './app.component';
// interceptor
import { TSMTMenuGuard } from './auth/menu-guard.service';
import { HomePageModule } from './modules/home-page/home-page.module';
import { BidsService } from './modules/jobs-list-master/services/bids.service';
import { SalesCustomerService } from './modules/jobs-list-master/services/sales-customer.service';
import { SelectionService } from './modules/jobs-list-master/services/selection.service';
import { BrowserSupportComponent } from './shared/components/browser-support/browser-support.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { WorkflowPopupCardComponent } from './shared/components/workflow-popup-card/workflow-popup-card.component';
//  constants
import { AppConstants } from './shared/constants/constants';
import { SharedModule } from './shared/modules/shared/shared.module';
import { ApiErrorService } from './shared/services/apierror.service';
import { GlobalFilterService } from './shared/services/global-filter.service';
import { LoginInterceptor } from './shared/services/interceptor';
import { JobHeaderService } from './shared/services/job-header.service';
import { JobSummaryService } from './shared/services/job-summary.service';
import { LoaderService } from './shared/services/loader.service';
import { ToasterService } from './shared/services/toaster.service';
import { TokenServiceLS } from './shared/services/token-service-with-local-storage.service';
import { SessionStorageService } from './shared/services/token-service-with-session-storage.service';
import { TokenServiceCI } from './shared/services/token.service';
import { WorkPackageCommonService } from './shared/services/work-package-common.service';
import { SharedCoreLibraryModule } from './sharedcore-library.module';

enableProdMode();

const oktaRoutingConfig = Object.assign({
  onAuthRequired: ({ oktaAuth, router }) => {
    // Redirect the user to your custom login page
    router.navigate(['']);
  },
}, oktaConfig.oidc);

export function httpLoaderFactory(httpClient: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(httpClient, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BrowserSupportComponent,
    WorkflowPopupCardComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    HttpClientModule,
    MessageModule,
    SharedCoreLibraryModule.forRoot(environment),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    OktaAuthModule,
    RouterModule,
    FormsModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    DialogModule,
    DropDownsModule,
    InputsModule,
    MenuModule,
    AppRoutingModule,
    HomePageModule,
    SharedModule,
    SharedPriceRollupModule,
    ButtonsModule,
    UploadModule,
    PopupModule,
    NotificationModule,
    TreeViewModule,
    InfiniteScrollModule,
    LayoutModule,
    CostForecastLibraryModule.forRoot(environment),
    SaleswebBillingLibraryModule.forRoot(environment),
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: LoginInterceptor, multi: true },
    CookieService,
    TokenServiceCI,
    TokenServiceLS,
    SessionStorageService,
    AppConstants,
    ToasterService,
    JobSummaryService,
    SelectionService,
    JobHeaderService,
    LoaderService,
    ApiErrorService,
    BidsService,
    TSMTMenuGuard,
    RouteGuard,
  { provide: OKTA_CONFIG, useValue: oktaRoutingConfig },
    OktaAuthService,
    OktaAuthGuard,
    GlobalFilterService,
    SalesCustomerService,
    WorkPackageCommonService,
    TraneSalesBusinessDataService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
