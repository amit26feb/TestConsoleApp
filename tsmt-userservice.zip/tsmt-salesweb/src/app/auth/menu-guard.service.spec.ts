import { HttpClientTestingModule, HttpTestingController, TestRequest } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { fakeAsync, getTestBed, inject, TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, Route, Router, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Subscription } from 'rxjs';
import { environment } from './../../environments/environment';

import { TranslateModule } from '@ngx-translate/core';
import { OKTA_CONFIG, OktaAuthService } from '@okta/okta-angular';
import { JobsListComponent } from '@tsmt/salesweb-jobsmodule';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import OktaConfig from '../.okta.config';
import { ToasterService } from '../shared/services/toaster.service';
import { TSMTMenuGuard } from './menu-guard.service';

// tslint:disable-next-line:no-big-function
describe('TSMTMenuGuard', () => {
  let injector: TestBed;
  let service: TSMTMenuGuard;
  const originReset = TestBed.resetTestingModule;
  let route: ActivatedRouteSnapshot;
  let router: Router;
  let oktaAuth: OktaAuthService;
  let httpMock: HttpTestingController;
  let sub: Subscription;
  let req: TestRequest;

  const oktaRoutingConfig = Object.assign({
    onAuthRequired: ({ oAuth }) => {
      // Redirect the user to your custom login page
      router.navigate(['']);
    },
  }, OktaConfig.oidc);

  const testRoutes: Routes = [
    {
      path: '**',
      component: JobsListComponent,
      canActivate: [TSMTMenuGuard],
      data: { routeName: 'home' },
    }];

  const routeConfig: Route = {
    path: '**',
    component: JobsListComponent,
    canLoad: [TSMTMenuGuard],
    data: { routeName: 'home' },
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [TSMTMenuGuard, OktaAuthService,

        {
          provide: OKTA_CONFIG,
          useValue: oktaRoutingConfig,
        },
        ToasterService,
        {
          provide: ActivatedRouteSnapshot,
          useValue: { data: { routeName: 'test' } },
        }
        ,
      ],
      declarations: [JobsListComponent],
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes(testRoutes), TranslateModule.forRoot()],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    });
    injector = getTestBed();
    service = injector.inject(TSMTMenuGuard);
    route = injector.inject(ActivatedRouteSnapshot);
    httpMock = injector.inject(HttpTestingController);

    oktaAuth = injector.inject(OktaAuthService);
    router = injector.inject(Router);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true on subscription of canActivate when route is authorised', fakeAsync(() => {
    sub = service.canActivate(route).subscribe((val) => {
      expect(val).toBe(true);
    });
    req = httpMock.expectOne(`assets/InactiveLinks-${environment.deployedEnv}.json`);
    expect(req.request.method).toBe('GET');
    req.flush({ links: ['bids'] });
  }));

  it('should return false on subscription of canActivate when the route is unauthorised',
    fakeAsync(inject([TSMTMenuGuard, HttpTestingController],
      (service1, httpMock1) => {
        service1.unAuthorisedRoutes = { links: ['test'] };
        service1.canActivate(route).subscribe((val) => {
          expect(val).toBe(false);
        });
        req = httpMock1.expectNone(`assets/InactiveLinks-${environment.deployedEnv}.json`);
      })));

  it(`should not make http call if the unauthorised links are available on calling canActivate`,
    fakeAsync(inject([TSMTMenuGuard, HttpTestingController],
      (service1, httpMock1) => {
        service1.unAuthorisedRoutes = { links: ['test'] };
        service1.canActivate(route).subscribe((val) => {
          expect(val).toBe(false);
        });
        httpMock1.expectNone(`assets/InactiveLinks-${environment.deployedEnv}.json`);
      })));
  it('should return true on subscription of canLoad when route is authorised', fakeAsync(() => {
    service.unAuthorisedRoutes = { links: ['test'] };
    sub = service.canLoad(routeConfig).subscribe((val) => {
      expect(val).toBe(true);
    });
  }));

  it(`should return false on subscription of canLoad when the route is unauthorised`,
    fakeAsync(inject([TSMTMenuGuard, HttpTestingController],
      (service1, httpMock1) => {
        service1.unAuthorisedRoutes = null;
        service1.canLoad(route).subscribe((val) => {
          expect(val).toBe(false);
        });
        req = httpMock1.expectOne(`assets/InactiveLinks-${environment.deployedEnv}.json`);
        expect(req.request.method).toBe('GET');
        req.flush({ links: ['test'] });
      })));

  it(`should not make http call if the unauthorised links are available on calling canLoad`,
    fakeAsync(inject([TSMTMenuGuard, HttpTestingController],
      (service1, httpMock1) => {
        service1.unAuthorisedRoutes = { links: ['test'] };
        service1.canLoad(route).subscribe((val) => {
          expect(val).toBe(false);
        });
        httpMock1.expectNone(`assets/InactiveLinks-${environment.deployedEnv}.json`);
      })));
});
