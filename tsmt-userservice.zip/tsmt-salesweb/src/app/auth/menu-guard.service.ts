import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, CanLoad, Route, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { ToasterService } from '../shared/services/toaster.service';
import { environment } from './../../environments/environment';


@Injectable()
export class TSMTMenuGuard implements CanActivate, CanLoad {
  public disabledRoutes$ = this.httpClient.get(`assets/InactiveLinks-${environment.deployedEnv}.json`);
  public unAuthorisedRoutes: object;
  public routeName: string;

  constructor(
    public toasterService: ToasterService,
    public router: Router,
    public httpClient: HttpClient,
    public activeRoute: ActivatedRoute) {
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    // Routename will be passed from the route config
    this.routeName = route.data.routeName;
    return this.fetchDisabledRoutes();
  }

  canLoad(route: Route): Observable<boolean> {
    this.routeName = route.data.routeName;
    return this.fetchDisabledRoutes();
  }

  fetchDisabledRoutes(): Observable<boolean> {
    // if the asset is loaded previously and the links are already fetched directly check for the route
    if (this.unAuthorisedRoutes) {
      return of(this.validateRoutes());
    } else {
      // fetch the list of disabledroutes
      return this.disabledRoutes$.map((val) => {
        this.unAuthorisedRoutes = val;
        return this.validateRoutes();
      });
    }
  }

  // returns true if the current route is not present in the unAuthorisedRoutes
  // returns false if the current route is unAuthorised and also displays the toaster
  validateRoutes(): boolean {
    const isAuthorisedLink = !this.unAuthorisedRoutes['links'].some((e: string) => {
      return e === this.routeName;
    });
    if (!isAuthorisedLink) {
      this.toasterService.setToaster('error', 'You are not authorized to view this page currently');
    }
    return isAuthorisedLink;
  }
}
