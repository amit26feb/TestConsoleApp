import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { OKTA_CONFIG, OktaAuthService } from '@okta/okta-angular';
import { configureTestSuite } from '@tsmt/shared-core/src/configure-test-suite';
import { RoleService, UserInfoService } from '@tsmt/shared-core-salesweb';

import oktaConfig from './.okta.config';
import { JobHeaderService } from './shared/services/job-header.service';
import { UserInfoResolver } from './user-info-resolver.service';
import { environment } from './../environments/environment';

const oktaRoutingConfig = Object.assign({
  onAuthRequired: ({ oktaAuth, router }) => {
    router.navigate(['']);
  },
}, oktaConfig.oidc);

describe('UserInfoResolver', () => {
  let service: UserInfoResolver;
  let oktaAuth: OktaAuthService;
  let jobHeaderService: JobHeaderService;
  let userInfoService: UserInfoService;
  let roleService: RoleService;
  const originReset = TestBed.resetTestingModule;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [UserInfoResolver, OktaAuthService, JobHeaderService, UserInfoService,
        { provide: OKTA_CONFIG, useValue: oktaRoutingConfig },
        { provide: 'environment', useValue: environment }],
    });
    service = TestBed.inject(UserInfoResolver);
    oktaAuth = TestBed.inject(OktaAuthService);
    jobHeaderService = TestBed.inject(JobHeaderService);
    userInfoService = TestBed.inject(UserInfoService);
    roleService = TestBed.inject(RoleService);
  });

  afterAll(() => {
    TestBed.resetTestingModule = originReset;
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch the user information from okta on calling resolve', () => {
    const userInfo = { samAccountName: 'ccfbsb' };
    spyOn(oktaAuth, 'getUser').and.returnValue(Promise.resolve(userInfo));
    const spyOnJobHeader = spyOn(jobHeaderService, 'setUserId');
    const user = service.resolve();
    user.then((usr) => { expect(usr['samAccountName']).toBe('ccfbsb'); });
    user.then((usr) => { expect(spyOnJobHeader).toHaveBeenCalled(); });
  });

  it('should call okta logout calling resolve', fakeAsync(() => {
    const spy = spyOn(oktaAuth, 'logout');
    spyOn(oktaAuth, 'getUser').and.returnValue(Promise.resolve(null));
    service.resolve();
    tick();
    expect(spy).toHaveBeenCalled();
  }));

  it(`should store the user Id from okta to userinfoservice and the userinfoservice userId can be
  used across the multiple libraries on calling resolve`,
    () => {
      // Arrange
      const userInfo = { samAccountName: 'ccfbsb', Groups: ['tsmt-estimator-approver'] };
      spyOn(oktaAuth, 'getUser').and.returnValue(Promise.resolve(userInfo));
      const spyOnUserInfoService = spyOn(userInfoService, 'setUserId');
      const spyOnUserRoles = spyOn(userInfoService, 'setUserRoles');
      // Act
      const user = service.resolve();
      // Assert
      user.then((usr) => {
        expect(spyOnUserInfoService).toHaveBeenCalled();
        expect(spyOnUserRoles).toHaveBeenCalled();
        expect(usr['samAccountName']).toBe('ccfbsb');
        expect(usr['Groups']).toBe(userInfo.Groups);
      });
    });

  it(`should store the user name & user full name from okta to userinfoservice and the userinfoservice user name & user full name can be
  used across the multiple libraries on calling resolve`,
    () => {
      const userInfo = { given_name: 'ccfbsb', name: 'Test User' };
      spyOn(oktaAuth, 'getUser').and.returnValue(Promise.resolve(userInfo));
      const spyOnUserInfoServiceUserName = spyOn(userInfoService, 'setUserName');
      const spyOnUserInfoServiceFullName = spyOn(userInfoService, 'setFullName');
      const user = service.resolve();
      user.then((usr) => {
        expect(usr['given_name']).toBe('ccfbsb');
        expect(usr['name']).toBe('Test User');
      });
      user.then((usr) => {
        expect(spyOnUserInfoServiceUserName).toHaveBeenCalled();
        expect(spyOnUserInfoServiceFullName).toHaveBeenCalled();
      });
    });

  it(`should call checkUserRoles() with false and user groups in non-prod environment
  and check the user permission with respect to the environments and store doesUserHasEditAccess to roleservice
  so that it can be used across the multiple libraries on calling resolve`,
    () => {
      // Arrange
      const userInfo = { samAccountName: 'ccfbsb', Groups: ['tsmt-orderservices-user-edit-test'] };
      spyOn(oktaAuth, 'getUser').and.returnValue(Promise.resolve(userInfo));
      const spyOnRoleService = spyOn(roleService, 'checkUserRoles');
      // Act
      const userInfoResolver = service.resolve();
      // Assert
      userInfoResolver.then((user) => {
        expect(spyOnRoleService).toHaveBeenCalledWith(false, userInfo.Groups);
      });
    });
});

